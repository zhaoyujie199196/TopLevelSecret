#pragma once

#include <string>
#include "Runtime/Scripting/ScriptingTypes.h"
#include "Runtime/Threads/Mutex.h"

class IAdsIdListener
{
public:
    virtual void OnAdsIdRequestDone(const core::string& adsId, bool trackingEnabled, const core::string& errorMsg) = 0;
    virtual ~IAdsIdListener() {}
};

class AdsIdHandler
{
public:
    AdsIdHandler();

    bool RequestAdsIdAsync(ScriptingObjectPtr adsIdDelegate);
    bool RequestAdsIdAsync(IAdsIdListener& listener);

    void HandleAdsIdAsyncStatus(bool connected);
    void SetStateError(core::string& errorMsg);
    void SetCachedAdsId(const core::string& adsId, bool trackingEnabled);

private:
    enum State { kStateNotReady = 0, kStateError, kStateReady, kStateConnected };

    bool IsCachedAdsIdExpired();
    bool FetchCachedAdsId();
    bool FetchAdsId();
    void FetchAsyncAdsId();

    void AddAdsIdDelegate(ScriptingObjectPtr doneDelegate);
    void AddAdsIdListeners(IAdsIdListener& listener);

    void InvokeAdsIdDoneDelegate(ScriptingGCHandle doneDelegate);
    void InvokeAllAdsIdDelegate();
    void InvokeAllAdsIdListeners();
    void InvokeAllDelegateAndListeners();

    void ScheduleJobToFetchAsyncAdsId();
    void ExecuteAsyncFetchAdsIdJob();

    // JobQueue
    static void ExecuteOnMainThreadAdsIdJobDoneStatic(AdsIdHandler* context);
    static void ExecuteAsyncFetchAdsIdJobStatic(AdsIdHandler* context);

private:
    core::string m_AdsId;
    bool     m_TrackingEnabled;
    core::string m_ErrorMsg;

    float    m_Timestamp;
    bool     m_IsCachedValueValid;
    bool     m_AsyncAdsIdFetchJobStarted;
    State    m_State;

    typedef UNITY_LIST (kMemDefault, ScriptingGCHandle) AdsIdDelegates;
    AdsIdDelegates  m_AdsIdDelegates;

    typedef UNITY_LIST (kMemDefault, IAdsIdListener*) AdsIdListeners;
    AdsIdListeners  m_AdsIdListeners;

    Mutex       m_AdsInfoMutex;
};

AdsIdHandler& GetAdsIdHandler();
