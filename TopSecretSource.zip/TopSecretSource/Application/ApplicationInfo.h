#pragma once

#include <string>

class ApplicationInfo
{
public:
    // Application install mode. Returned by Application.installMode.
    enum InstallMode
    {
        InstallModeUnknown = 0,
        // Application was installed via store.
        Store = 1,
        // Application was installed via developer env.
        DeveloperBuild = 2,
        // Application was installed via adhoc mode.
        Adhoc = 3,
        // Application was installed in enterprise mode.
        Enterprise = 4,
        // Application running in editor.
        Editor = 5
    };

    enum SandboxType
    {
        SandboxTypeUnknown = 0,
        // Application is not sandboxed.
        NotSandboxed = 1,
        // Application is sandboxed.
        Sandboxed = 2,
        // Application sandbox is broken.
        SandboxBroken = 3
    };
    ApplicationInfo() : m_SandboxType(SandboxTypeUnknown), m_InstallMode(InstallModeUnknown) {}

    core::string GetApplicationIdentifier();

    core::string GetVersion();

    core::string GetInstallerName();

    InstallMode GetInstallMode();

    SandboxType GetSandboxType();

private:
    void SetApplicationIdentifier(const char* applicationIdentifier) {m_ApplicationIdentifier = applicationIdentifier; }
    void SetVersion(const char* bundleVersion) {m_BundleVersion = bundleVersion; }
    void SetInstallerName(const char* installerName) {m_InstallerName = installerName; }

private:
    core::string    m_ApplicationIdentifier;
    core::string    m_BundleVersion;
    core::string    m_InstallerName;
    InstallMode m_InstallMode;
    SandboxType m_SandboxType;
};

ApplicationInfo& GetApplicationInfo();
