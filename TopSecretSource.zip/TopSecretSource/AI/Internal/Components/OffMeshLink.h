#pragma once

#include "Runtime/GameCode/Behaviour.h"
#include "Runtime/Transform/Transform.h"
#include "../NavMesh/NavMeshTypes.h"
#include "../NavMeshBindingTypes.h"

class NavMesh;


class OffMeshLink : public Behaviour
{
    REGISTER_CLASS(OffMeshLink);
    DECLARE_OBJECT_SERIALIZE();
public:
    OffMeshLink(MemLabelId label, ObjectCreationMode mode);
    // ~OffMeshLink (); declared by a macro

    inline void SetManagerHandle(int handle);
    inline float GetCostOverride() const;
    void SetCostOverride(float costOverride);

    inline bool GetBiDirectional() const;
    void SetBiDirectional(bool bidirectional);

    inline bool GetActivated() const;
    void SetActivated(bool activated);

    bool GetOccupied() const;

    inline UInt32 GetArea() const;
    void SetArea(UInt32 areaIndex);

    inline Transform* GetStartTransform() const;
    inline void SetStartTransform(Transform* t);

    inline Transform* GetEndTransform() const;
    inline void SetEndTransform(Transform* t);

    void OnNavMeshAdded();
    void OnNavMeshCleanup();
    void UpdatePositions();
    void UpdateMovedPositions();

    inline bool GetAutoUpdatePositions() const;
    inline void SetAutoUpdatePositions(bool autoUpdate);

    inline NavMeshPolyRef GetConnectionPolyRef() const;

protected:
    virtual void AwakeFromLoad(AwakeFromLoadMode mode);
    virtual void AddToManager();
    virtual void RemoveFromManager();
    virtual void Reset();
    virtual void SmartReset();

private:
    void AddConnection();
    void RemoveConnection();
    bool HasEndpointMoved() const;

    NavMeshPolyRef m_ConnectionPolyRef;

    PPtr<Transform> m_Start;
    PPtr<Transform> m_End;

    Vector3f m_EndPosition;
    Vector3f m_StartPosition;
    float m_MoveThreshold;
    float m_CostOverride;
    UInt32 m_AreaIndex;
    int m_AgentTypeID;
    int m_ManagerHandle;

    bool m_AutoUpdatePositions;
    bool m_ShouldUpdatePositions;
    bool m_BiDirectional;
    bool m_Activated;
};


inline void OffMeshLink::SetManagerHandle(int handle)
{
    m_ManagerHandle = handle;
}

inline float OffMeshLink::GetCostOverride() const
{
    return m_CostOverride;
}

inline bool OffMeshLink::GetBiDirectional() const
{
    return m_BiDirectional;
}

inline bool OffMeshLink::GetActivated() const
{
    return m_Activated;
}

inline UInt32 OffMeshLink::GetArea() const
{
    return m_AreaIndex;
}

inline Transform* OffMeshLink::GetStartTransform() const
{
    return m_Start;
}

inline void OffMeshLink::SetStartTransform(Transform* t)
{
    if (t == m_Start)
        return;

    m_Start = t;
    m_ShouldUpdatePositions = m_AutoUpdatePositions;
    SetDirty();
}

inline Transform* OffMeshLink::GetEndTransform() const
{
    return m_End;
}

inline void OffMeshLink::SetEndTransform(Transform* t)
{
    if (t == m_End)
        return;

    m_End = t;
    m_ShouldUpdatePositions = m_AutoUpdatePositions;
    SetDirty();
}

inline bool OffMeshLink::GetAutoUpdatePositions() const
{
    return m_AutoUpdatePositions;
}

inline void OffMeshLink::SetAutoUpdatePositions(bool autoUpdate)
{
    m_AutoUpdatePositions = autoUpdate;
    SetDirty();
}

inline NavMeshPolyRef OffMeshLink::GetConnectionPolyRef() const
{
    return m_ConnectionPolyRef;
}
