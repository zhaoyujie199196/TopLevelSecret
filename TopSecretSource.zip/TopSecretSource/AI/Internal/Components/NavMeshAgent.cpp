#include "UnityPrefix.h"
#include "NavMeshAgent.h"

#include "OffMeshLink.h"
#include "../NavMesh/NavMesh.h"
#include "../Crowd/CrowdManager.h"
#include "../Crowd/CrowdTypes.h"
#include "../NavMeshData.h"
#include "../NavMeshManager.h"
#include "../NavMeshProjectSettings.h"
#include "../NavMeshPath.h"
#include "../NavMeshSettings.h"
#include "Runtime/BaseClasses/IsPlaying.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Geometry/AABBUtility.h"
#include "Runtime/Utilities/ValidateArgs.h"
#include "Runtime/Misc/BuildSettings.h"
#include "Runtime/Serialize/AwakeFromLoadQueue.h"
#include "Runtime/Mono/ExecutionOrderManager.h"
#include "Runtime/BaseClasses/MessageHandlerRegistration.h"

#define REQUIRE_INITIALIZED(FUNC, returnValue) \
if (!InCrowdSystem ()) \
{ \
    ErrorString (#FUNC " can only be called on an active agent that has been placed on a NavMesh."); \
    return returnValue; \
}

NavMeshAgent::NavMeshAgent(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
{
    m_AgentRef = 0;
    m_ManagerHandle = -1;
    Reset();
}

void NavMeshAgent::Reset()
{
    Super::Reset();
    m_AgentTypeID = 0;
    m_Radius = 0.5F;
    m_Height = 2.0F;
    m_BaseOffset = 0.0F;
    m_Speed = 3.5f;
    m_AngularSpeed = 120.0F;
    m_Acceleration = 8.0f;
    m_StoppingDistance = 0.0f;
    m_AvoidancePriority = 50;
    m_ObstacleAvoidanceType = kHighQualityObstacleAvoidance;
    m_UpdatePosition = true;
    m_UpdateRotation = true;
    m_UpdateUpAxis = true;
    m_AutoTraverseOffMeshLink = true;
    m_AutoBraking = true;
    m_AutoRepath = true;
    m_WalkableMask = 0xFFFFFFFF;
    m_OffMeshConnectionInstanceID = 0;
    m_OffMeshConnectionRef = 0;
}

void NavMeshAgent::SmartReset()
{
    Super::SmartReset();

#if ENABLE_RUNTIME_NAVMESH_BUILDING
    // Default values
    int agentTypeID = 0;
    float radius = 0.5f;
    float height = 2.0f;
    float baseOffset = 0.0f;

    // Obtain from bounds from renderer if possible
    AABB aabb;
    if (GetGameObjectPtr() && CalculateLocalAABB(GetGameObject(), &aabb))
    {
        Vector3f extents = aabb.GetCenter() + aabb.GetExtent();
        radius = std::max(extents.x, extents.z);
        height = 2.0F * extents.y;
        baseOffset = extents.y;
    }

    SetBaseOffset(baseOffset);

    // Pick closest matching agent type
    const NavMeshProjectSettings& settings = GetNavMeshProjectSettings();

    const Vector2f scale = CalculateDimensionScales();
    const float scaledRadius = scale.x * radius;
    const float scaledHeight = scale.y * height;

    float maxErr = std::numeric_limits<float>::infinity();
    const int count = settings.GetSettingsCount();
    for (int i = 0; i < count; ++i)
    {
        const NavMeshBuildSettings* bs = settings.GetSettingsByIndex(i);
        const float err = Sqr(bs->agentRadius - scaledRadius) + Abs(bs->agentHeight - scaledHeight);
        if (err < maxErr)
        {
            maxErr = err;
            agentTypeID = bs->agentTypeID;
        }
    }
    m_AgentTypeID = agentTypeID;
#else
    AABB aabb;
    if (GetGameObjectPtr() && CalculateLocalAABB(GetGameObject(), &aabb))
    {
        Vector3f extents = aabb.GetCenter() + aabb.GetExtent();
        SetRadius(std::max(extents.x, extents.z));
        SetHeight(2.0F * extents.y);
        SetBaseOffset(extents.y);
    }
    else
    {
        SetRadius(0.5F);
        SetHeight(2.0F);
        SetBaseOffset(0.0F);
    }
#endif
}

void NavMeshAgent::ThreadedCleanup()
{
}

template<class TransferFunc>
void NavMeshAgent::Transfer(TransferFunc& transfer)
{
    Super::Transfer(transfer);

    TRANSFER(m_AgentTypeID);
    TRANSFER(m_Radius);
    TRANSFER(m_Speed);
    TRANSFER(m_Acceleration);
    transfer.Transfer(m_AvoidancePriority, "avoidancePriority");
    TRANSFER(m_AngularSpeed);
    TRANSFER(m_StoppingDistance);
    TRANSFER(m_AutoTraverseOffMeshLink);
    TRANSFER(m_AutoBraking);
    TRANSFER(m_AutoRepath);
    transfer.Align();
    TRANSFER(m_Height);
    TRANSFER(m_BaseOffset);
    TRANSFER(m_WalkableMask);
    TRANSFER_ENUM(m_ObstacleAvoidanceType);
}

void NavMeshAgent::InitializeClass()
{
    REGISTER_MESSAGE(kTransformChanged, OnTransformChanged, int);

    GetExecutionOrderManager().SetDefaultExecutionOrderFor(TypeOf<NavMeshAgent>(), kMonoBehaviourQueue, -100);
}

void NavMeshAgent::OnTransformChanged(int mask)
{
    if (!InCrowdSystem())
        return;

    if (m_UpdatePosition && (mask & Transform::kPositionChanged))
    {
        const Vector3f npos = GetGroundPositionFromTransform();
        GetCrowdManager()->MoveAgent(m_AgentRef, npos);
    }
    if (mask & Transform::kScaleChanged)
        UpdateActiveAgentParameters();
}

int NavMeshAgent::GetCurrentPolygonMask() const
{
    NavMeshPolyRef polyRef;
    if (IsOnOffMeshLink())
        polyRef = GetCrowdManager()->GetAgentAnimation(m_AgentRef)->polyRef;
    else
        polyRef = GetInternalAgent()->corridor.GetFirstPoly();

    const NavMesh* navmesh = GetInternalNavMesh();
    return navmesh->GetPolyFlags(polyRef);
}

Object* NavMeshAgent::GetCurrentPolygonOwner() const
{
#if ENABLE_RUNTIME_NAVMESH_BUILDING
    if (!InCrowdSystem())
        return NULL;
    NavMeshPolyRef polyRef;
    if (IsOnOffMeshLink())
        polyRef = GetCrowdManager()->GetAgentAnimation(m_AgentRef)->polyRef;
    else
        polyRef = GetInternalAgent()->corridor.GetFirstPoly();

    const int id = GetNavMeshManager().GetUserID(polyRef);
    return dynamic_instanceID_cast<Object*>(id);
#else
    return NULL;
#endif
}

const QueryFilter& NavMeshAgent::GetFilter() const
{
    Assert(InCrowdSystem());
    const CrowdManager* crowd = GetCrowdManager();
    return *crowd->GetAgentFilter(m_AgentRef);
}

const CrowdAgent* NavMeshAgent::GetInternalAgent() const
{
    Assert(InCrowdSystem());
    return GetCrowdManager()->GetAgentByRef(m_AgentRef);
}

bool NavMeshAgent::SetDestination(const Vector3f& targetPos)
{
    REQUIRE_INITIALIZED("SetDestination", false);

    CrowdManager* crowd = GetCrowdManager();
    return crowd->RequestMoveTarget(m_AgentRef, targetPos);
}

Vector3f NavMeshAgent::GetDestination() const
{
    if (!InCrowdSystem())
        return Vector3f::infinityVec;

    return GetCrowdManager()->GetMoveTarget(m_AgentRef);
}

Vector3f NavMeshAgent::GetEndPositionOfCurrentPath() const
{
    if (!InCrowdSystem())
        return GetPosition();

    const CrowdAgent* agent = GetInternalAgent();
    Vector3f endPosition(agent->corridor.GetTarget());
    return endPosition;
}

Vector3f NavMeshAgent::GetPosition() const
{
    const Transform& transform = GetComponent<Transform>();
    if (!InCrowdSystem())
        return transform.GetPosition();

    const Vector3f groundPosition = GetInternalAgent()->npos;
    const Vector3f upAxis = GetInternalUpAxis();
    const Vector3f offset = m_BaseOffset * transform.GetWorldScaleLossy().y * upAxis;
    const Vector3f newPosition = groundPosition + offset;
    return newPosition;
}

void NavMeshAgent::SetPosition(const Vector3f& position)
{
    if (!InCrowdSystem())
        return;

    const Transform& transform = GetComponent<Transform>();

    const Vector3f upAxis = GetInternalUpAxis();
    const Vector3f offset = m_BaseOffset * transform.GetWorldScaleLossy().y * upAxis;
    const Vector3f groundPosition = position - offset;

    GetCrowdManager()->MoveAgent(m_AgentRef, groundPosition);

    if (m_UpdatePosition)
    {
        const CrowdAgent* agent = GetInternalAgent();
        SetTransformFromGroundPosition(agent->npos);
    }
}

Vector3f NavMeshAgent::GetVelocity() const
{
    if (!InCrowdSystem())
        return Vector3f(0, 0, 0);

    return GetInternalAgent()->avel;
}

void NavMeshAgent::SetVelocity(const Vector3f& vel)
{
    if (!InCrowdSystem())
        return;

    ABORT_INVALID_VECTOR3(vel, velocity, navmeshagent);
    GetCrowdManager()->UpdateAgentVelocity(m_AgentRef, vel);
}

Vector3f NavMeshAgent::GetSteeringTarget() const
{
    if (!InCrowdSystem())
        return GetComponent<Transform>().GetPosition();

    return GetCrowdManager()->GetSteerTarget(m_AgentRef);
}

Vector3f NavMeshAgent::GetDesiredVelocity() const
{
    if (!InCrowdSystem())
        return Vector3f(0.0f, 0.0f, 0.0f);

    const CrowdAgent* agent = GetInternalAgent();
    Vector3f desiredVelocity(agent->nvel);
    return desiredVelocity;
}

bool NavMeshAgent::IsOnOffMeshLink() const
{
    if (!InCrowdSystem())
        return false;

    const CrowdAgent* agent = GetInternalAgent();
    return agent->state == kCrowdAgentState_OffMesh;
}

// @TODO: Deprecate (de)activation of baked offmeshlinks.
// We really don't want to be holding an OffMeshLink instance ID here.
// Instead promote use of: NavMeshAgent.currentOffMeshLinkData.offMeshLink
void NavMeshAgent::ActivateCurrentOffMeshLink(bool activated)
{
    if (!IsOnOffMeshLink())
        return;

    // Cache which off-mesh link was deactivated.
    if (!activated)
    {
        // Store both the polyref and instance ID, as the polyref may change
        // for component based off-mesh links when they move.
        m_OffMeshConnectionRef = GetCrowdManager()->GetAgentAnimation(m_AgentRef)->polyRef;
        GetInternalNavMesh()->GetOffMeshConnectionUserID(m_OffMeshConnectionRef, &m_OffMeshConnectionInstanceID);
    }

    if (OffMeshLink* oml = dynamic_instanceID_cast<OffMeshLink*>(m_OffMeshConnectionInstanceID))
        oml->SetActivated(activated);
    else
        GetNavMeshManager().SetOffMeshConnectionActive(m_OffMeshConnectionRef, activated);

    // Forget the off-mesh connection when activated.
    if (activated)
    {
        m_OffMeshConnectionInstanceID = 0;
        m_OffMeshConnectionRef = 0;
    }
}

bool NavMeshAgent::GetCurrentOffMeshLinkData(OffMeshLinkData* data) const
{
    Assert(data);
    memset(data, 0, sizeof(OffMeshLinkData));
    if (!IsOnOffMeshLink())
        return false;

    const CrowdAgentAnimation* agentAnimation = GetCrowdManager()->GetAgentAnimation(m_AgentRef);
    if (agentAnimation == NULL)
        return false;

    if (!SetOffMeshLinkDataFlags(data, agentAnimation->polyRef))
        return false;

    data->m_StartPos = agentAnimation->startPos;
    data->m_EndPos = agentAnimation->endPos;
    return true;
}

bool NavMeshAgent::GetNextOffMeshLinkData(OffMeshLinkData* data) const
{
    Assert(data);
    memset(data, 0, sizeof(OffMeshLinkData));
    if (!InCrowdSystem())
        return false;

    const CrowdAgent* agent = GetInternalAgent();
    const PathCorridor& corridor = agent->corridor;
    if (!corridor.IsPathValid())
        return false;

    const NavMesh* navmesh = GetInternalNavMesh();
    const NavMeshPolyRef* pathPolygons = corridor.GetPath();
    const int pathCount = corridor.GetPathCount();
    int i = 1;
    for (; i < pathCount; ++i)
    {
        if (SetOffMeshLinkDataFlags(data, pathPolygons[i]))
            break;
    }

    // Note: We intentionally fail if pathCount == 1
    // in that case any offmeshlink is not 'next' - but current.
    if (i >= pathCount)
        return false;

    NavMeshPolyRef prevRef = pathPolygons[i - 1];
    NavMeshPolyRef polyRef = pathPolygons[i];
    NavMeshPolyRef nextRef = (i + 1) < pathCount ? pathPolygons[i + 1] : 0;

    const OffMeshConnection* conn = navmesh->GetOffMeshConnection(polyRef);
    if (conn == NULL)
        return false;

    NavMeshStatus status = 0;
    if (conn->width > 0.0f)
    {
        // For wide links we calculate points along the entry and exit segments.
        // We'll need the nearest point to off-mesh start position. Use the corners, or agent position as fallback.
        Vector3f nearestPos = agent->npos;
        for (int j = 0; j < agent->ncorners; j++)
        {
            if (agent->cornerFlags[j] & kStraightPathOffMeshConnection)
            {
                nearestPos = agent->cornerVerts[j];
                break;
            }
        }
        status = navmesh->GetNearestOffMeshConnectionEndPoints(prevRef, polyRef, nextRef, nearestPos, &data->m_StartPos, &data->m_EndPos);
    }
    else
    {
        // Handle point-to-point links
        status = navmesh->GetOffMeshConnectionEndPoints(prevRef, polyRef, &data->m_StartPos, &data->m_EndPos);
    }

    // Having successfully called 'SetOffMeshLinkDataFlags' above should ensure valid endpoints here.
    DebugAssert(NavMeshStatusSucceed(status));
    if (NavMeshStatusFailed(status))
    {
        memset(data, 0, sizeof(OffMeshLinkData));
        return false;
    }

    return true;
}

// Set OffMeshLink data or return false
// Returns false if polyRef is not an offmeshlink
bool NavMeshAgent::SetOffMeshLinkDataFlags(OffMeshLinkData* data, const NavMeshPolyRef polyRef) const
{
    Assert(InCrowdSystem());
    const NavMesh* navmesh = GetInternalNavMesh();
    const OffMeshConnection* con = navmesh->GetOffMeshConnection(polyRef);
    if (con == NULL)
        return false;
    data->m_Valid = 1;
    data->m_Activated = con->flags != 0 ? 1 : 0;
    data->m_LinkType = static_cast<OffMeshLinkType>(con->linkType);
    data->m_InstanceID = con->userID;

    return true;
}

void NavMeshAgent::UpdateActiveAgentParameters()
{
    CheckConsistency();
    if (InCrowdSystem())
    {
        CrowdAgentParams params;
        FillAgentParams(params);
        GetCrowdManager()->UpdateAgentParameters(m_AgentRef, &params);
        GetCrowdManager()->UpdateAgentFilter(m_AgentRef, GetAreaMask(), m_AgentTypeID);
    }
}

void NavMeshAgent::AwakeFromLoad(AwakeFromLoadMode mode)
{
    Super::AwakeFromLoad(mode);
    UpdateActiveAgentParameters();
}

void NavMeshAgent::CheckConsistency()
{
    Super::CheckConsistency();
    m_AvoidancePriority = clamp(m_AvoidancePriority, 0, 99);
    m_Speed = clamp(m_Speed, 0.0f, 1e15f);  // squaring m_Speed keeps it below inf.
    m_StoppingDistance = std::max(0.0f, m_StoppingDistance);
    m_Acceleration = std::max(0.0f, m_Acceleration);
    m_AngularSpeed = std::max(0.0f, m_AngularSpeed);
    m_Height = EnsurePositive(m_Height);
    m_Radius = EnsurePositive(m_Radius);
}

int NavMeshAgent::UpdateTransformGetMessageMask(float deltaTime, Transform** t)
{
    if (!InCrowdSystem())
        return 0;

    Transform& transform = GetComponent<Transform>();
    int changeMessageMask = 0;

    if (m_UpdatePosition)
    {
        const Vector3f groundPosition = GetInternalAgent()->npos;

        const Vector3f upAxis = GetInternalUpAxis();
        const Vector3f offset = m_BaseOffset * transform.GetWorldScaleLossy().y * upAxis;
        const Vector3f newPosition = groundPosition + offset;

        transform.SetPositionWithoutNotification(newPosition);
        changeMessageMask |= Transform::kPositionChanged;
    }

#if ENABLE_RUNTIME_NAVMESH_BUILDING
    if (m_UpdateUpAxis)
    {
        const Vector3f navUp = GetInternalUpAxis();
        const Vector3f up = Vector3f(0.0f, 1.0f, 0.0f);
        const Vector3f transformUp = transform.TransformDirection(up);
        const Quaternionf rot = FromToQuaternion(transformUp, navUp);
        const Quaternionf transformRot = transform.GetRotation();
        transform.SetRotationWithoutNotification(rot * transformRot);
        changeMessageMask |= Transform::kRotationChanged;
    }
#endif

    if (m_UpdateRotation)
    {
        UpdateRotation(transform, deltaTime);
        changeMessageMask |= Transform::kRotationChanged;
    }

    *t = &transform;
    return changeMessageMask;
}

void NavMeshAgent::UpdateRotation(Transform& transform, float deltaTime)
{
    const CrowdAgent* agent = GetInternalAgent();
    const Vector3f vel = transform.InverseTransformDirection(agent->vel);

    float sqrLen = vel.x * vel.x + vel.z * vel.z;
    if (sqrLen <= 0.001f)
        return;

    const float deltaAngle = atan2f(vel.x, vel.z);
    const float maxAngleSpeed = std::min(Abs(deltaAngle) * (1.0f + sqrtf(sqrLen)), Deg2Rad(m_AngularSpeed));
    const float deltaAngleApply = std::min(Abs(deltaAngle), maxAngleSpeed * deltaTime) * Sign(deltaAngle);

    const Vector3f up = Vector3f(0.0f, 1.0f, 0.0f);
    const Quaternionf currentRotation = transform.GetRotation();
    const Quaternionf rotation = AxisAngleToQuaternion(up, deltaAngleApply);

    transform.SetRotationWithoutNotification(currentRotation * rotation);
}

void NavMeshAgent::FillAgentParams(CrowdAgentParams& params)
{
    Vector2f scale = CalculateDimensionScales();
    params.radius = std::max(0.00001F, m_Radius * scale.x);
    params.height = std::max(0.00001F, m_Height * scale.y);
    params.maxAcceleration = m_Acceleration;
    params.maxSpeed = m_Speed;
    params.stoppingDistance = m_StoppingDistance;
    params.priority = 99 - m_AvoidancePriority;
    params.obstacleAvoidanceType = m_ObstacleAvoidanceType;

    params.updateFlags = 0;
    if (m_ObstacleAvoidanceType != kNoObstacleAvoidance)
        params.updateFlags |= kCrowdObstacleAvoidance;
    if (m_AutoTraverseOffMeshLink)
        params.updateFlags |= kCrowdAutoTraverseOffMeshLink;
    if (m_AutoBraking)
        params.updateFlags |= kCrowdAutoBraking;
    if (m_AutoRepath)
        params.updateFlags |= kCrowdAutoRepath;
}

NavMeshPolyRef NavMeshAgent::GetInternalAnimationPolyRef() const
{
    if (InCrowdSystem())
        return GetCrowdManager()->GetAgentAnimation(m_AgentRef)->polyRef;
    return (NavMeshPolyRef)0;
}

void NavMeshAgent::SetInternalAnimationPolyRef(NavMeshPolyRef polyRef)
{
    if (InCrowdSystem())
        GetCrowdManager()->SetAgentAnimationPolyRef(m_AgentRef, polyRef);
}

void NavMeshAgent::OnNavMeshAdded()
{
    if (!InCrowdSystem())
    {
        AddToCrowdSystem();
    }
}

void NavMeshAgent::AddToCrowdSystem()
{
    Assert(!InCrowdSystem());

    if (!IsWorldPlaying())
        return;

    if (!IsAddedToManager())
        return;

    NavMeshManager& manager = GetNavMeshManager();
    if (manager.GetInternalNavMesh() == NULL)
    {
        WarningString("Failed to create agent because there is no valid NavMesh");
        return;
    }

    CrowdManager* crowd = manager.GetCrowdManager();
    AssertMsg(crowd != NULL, "CrowdManager must be available if the internal NavMesh is.");

    Vector3f currentPosition = GetGroundPositionFromTransform();
    CrowdAgentParams params;
    FillAgentParams(params);

    m_AgentRef = crowd->AddAgent(currentPosition, GetAreaMask(), m_AgentTypeID, &params);
    if (m_AgentRef == 0)
    {
        WarningStringObject("Failed to create agent because it is not close enough to the NavMesh", this);
        return;
    }

    // Collect global area costs and apply to created agent
    float areaCosts[NavMeshProjectSettings::kAreaCount];
    const NavMeshProjectSettings& settings = GetNavMeshProjectSettings();
    for (int i = 0; i < NavMeshProjectSettings::kAreaCount; ++i)
    {
        areaCosts[i] = settings.GetAreaCost(i);
    }
    crowd->InitializeAgentFilter(m_AgentRef, areaCosts, NavMeshProjectSettings::kAreaCount);
}

void NavMeshAgent::RemoveFromCrowdSystem()
{
    if (!InCrowdSystem())
        return;

    GetCrowdManager()->RemoveAgent(m_AgentRef);
    m_AgentRef = 0;
}

void NavMeshAgent::AddToManager()
{
    GetNavMeshManager().RegisterAgent(*this, m_ManagerHandle);
    AddToCrowdSystem();
}

void NavMeshAgent::RemoveFromManager()
{
    RemoveFromCrowdSystem();
    GetNavMeshManager().UnregisterAgent(m_ManagerHandle);
}

float NavMeshAgent::GetRemainingDistance() const
{
    REQUIRE_INITIALIZED("GetRemainingDistance", std::numeric_limits<float>::infinity());
    return GetCrowdManager()->CalculateRemainingPath(m_AgentRef);
}

int NavMeshAgent::CalculatePolygonPath(const Vector3f& targetPosition, NavMeshPath* path) const
{
    REQUIRE_INITIALIZED("CalculatePolygonPath", 0)

    if (!IsFinite(targetPosition))
    {
#if UNITY_EDITOR
        ErrorStringObject(Format("CalculatePolygonPath: invalid target position { %s, %s, %s }."
                , FloatToString(targetPosition.x).c_str(), FloatToString(targetPosition.y).c_str(), FloatToString(targetPosition.z).c_str()), this);
#endif
        return 0;
    }

    const CrowdAgent* agent = GetInternalAgent();
    Vector3f sourcePosition(agent->corridor.GetPos());

    const QueryFilter& filter = GetFilter();
    return GetNavMeshManager().CalculatePolygonPath(path, sourcePosition, targetPosition, filter);
}

bool NavMeshAgent::SetPath(const NavMeshPath* path)
{
    REQUIRE_INITIALIZED("SetPath", false)

    const NavMeshPathStatus status = path->GetStatus();
    const int polyCount = path->GetPolygonCount();
    if (status == kPathInvalid || polyCount == 0)
    {
        ResetPath();
        return false;
    }

    const Vector3f targetPos = path->GetTargetPosition();
    const Vector3f sourcePos = path->GetSourcePosition();
    const NavMeshPolyRef* polyPath = path->GetPolygonPath();
    GetCrowdManager()->SetAgentPath(m_AgentRef, sourcePos, targetPos, polyPath, polyCount, status == kPathPartial);
    const CrowdAgent* agent = GetInternalAgent();

    NavMeshPolyRef lastPoly = agent->corridor.GetLastPoly();
    if (lastPoly != polyPath[polyCount - 1])
        return false;

    return true;
}

void NavMeshAgent::CopyPath(NavMeshPath* path) const
{
    Assert(path);
    if (m_AgentRef == 0)
    {
        path->SetPolygonCount(0);
        path->SetStatus(kPathInvalid);
        return;
    }

    const CrowdAgent* agent = GetInternalAgent();

    unsigned int pathCount = agent->corridor.GetPathCount();
    path->ReservePolygons(pathCount);
    memcpy(path->GetPolygonPath(), agent->corridor.GetPath(), sizeof(NavMeshPolyRef) * pathCount);
    path->SetPolygonCount(pathCount);
    path->SetTargetPosition(agent->corridor.GetTarget());
    path->SetSourcePosition(agent->corridor.GetPos());
    path->SetStatus(GetPathStatus());
}

void NavMeshAgent::ResetPath()
{
    REQUIRE_INITIALIZED("ResetPath", )

    GetCrowdManager()->ResetAgentPath(m_AgentRef);
}

bool NavMeshAgent::PathPending() const
{
    return InCrowdSystem() && GetInternalAgent()->pendingRequest;
}

bool NavMeshAgent::HasPath() const
{
    if (!InCrowdSystem())
        return false;

    return GetCrowdManager()->HasPath(m_AgentRef);
}

bool NavMeshAgent::DistanceToEdge(NavMeshHit* hit) const
{
    Assert(hit);
    REQUIRE_INITIALIZED("DistanceToEdge", false);
    const CrowdAgent* agent = GetInternalAgent();
    Vector3f sourcePosition(agent->corridor.GetPos());

    const QueryFilter& filter = GetFilter();
    return GetNavMeshManager().DistanceToEdge(hit, sourcePosition, filter);
}

bool NavMeshAgent::Raycast(const Vector3f& targetPosition, NavMeshHit* hit) const
{
    Assert(hit);
    REQUIRE_INITIALIZED("Raycast", false)
    const CrowdAgent * agent = GetInternalAgent();
    Vector3f sourcePosition(agent->corridor.GetPos());

    const QueryFilter& filter = GetFilter();
    return GetNavMeshManager().Raycast(hit, sourcePosition, targetPosition, filter);
}

// TODO: handle case where: maxDistance > remainingDistance (non-inf).
bool NavMeshAgent::SamplePathPosition(int passableMask, float maxDistance, NavMeshHit* hit) const
{
    Assert(hit);
    REQUIRE_INITIALIZED("SamplePathPosition", false);

    const CrowdAgent* agent = GetInternalAgent();
    const NavMesh* navmesh = GetInternalNavMesh();
    Vector3f agentPosition(agent->npos);

    if (agent->ncorners == 0 || maxDistance <= 0.0f)
    {
        hit->position = agentPosition;
        hit->normal.SetZero();
        hit->distance = 0.0f;
        hit->mask = GetCurrentPolygonMask();
        hit->hit = false;
        return false;
    }

    // Copy and modify agent filter with provided mask
    QueryFilter filter = GetFilter();
    filter.SetIncludeFlags(passableMask & filter.GetIncludeFlags());
    Vector3f sourcePosition(agent->corridor.GetPos());

    if (!filter.PassFilter(navmesh->GetPolyFlags(agent->corridor.GetFirstPoly())))
    {
        hit->position = sourcePosition;
        hit->normal.SetZero();
        hit->distance = 0.0f;
        hit->mask = GetCurrentPolygonMask();
        hit->hit = true;
        return true;
    }

    float totalDistance = 0.0f;
    for (int i = 0; i < agent->ncorners; ++i)
    {
        Vector3f targetPosition = agent->cornerVerts[i];

        // raycast no longer that remaining distance
        // to obtain the final polyon mask correctly
        const float segmentLength = Magnitude(targetPosition - sourcePosition);
        float remainingDistance = maxDistance - totalDistance;
        if (segmentLength >= remainingDistance)
        {
            targetPosition = Lerp(sourcePosition, targetPosition, remainingDistance / segmentLength);
            remainingDistance = 0;
        }

        // position, normal, mask, hit set by Raycast ()
        if (GetNavMeshManager().Raycast(hit, sourcePosition, targetPosition, filter))
        {
            // Terminates prematurely
            // calculate accumulated distance along path
            hit->distance = totalDistance + hit->distance;
            return true;
        }
        if (remainingDistance == 0)
        {
            // Terminates at end
            // accumulated distance is max distance
            hit->distance = maxDistance;
            return false;
        }

        totalDistance += segmentLength;
        sourcePosition = targetPosition;
    }

    // Found end of straight path in "agent->cornerVerts"
    // - this is not necessarily the end of the path.
    return false;
}

bool NavMeshAgent::Warp(const Vector3f& newPosition)
{
    RemoveFromCrowdSystem();
    Transform& transform = GetComponent<Transform>();
    transform.SetPosition(newPosition);
    AddToCrowdSystem();
    return InCrowdSystem();
}

void NavMeshAgent::Move(const Vector3f& motion)
{
    REQUIRE_INITIALIZED("Move", )

    const CrowdAgent * agent = GetInternalAgent();
    Vector3f targetPos = motion + agent->npos;
    GetCrowdManager()->MoveAgent(m_AgentRef, targetPos);

    if (m_UpdatePosition)
    {
        SetTransformFromGroundPosition(agent->npos);
    }
}

void NavMeshAgent::Stop()
{
    REQUIRE_INITIALIZED("Stop", )
    GetCrowdManager()->StopExplicit(m_AgentRef, true);
}

void NavMeshAgent::Resume()
{
    REQUIRE_INITIALIZED("Resume", )
    GetCrowdManager()->StopExplicit(m_AgentRef, false);
}

bool NavMeshAgent::IsStopped() const
{
    REQUIRE_INITIALIZED("IsStopped", false)
    return GetCrowdManager()->GetStopExplicit(m_AgentRef);
}

void NavMeshAgent::CompleteOffMeshLink()
{
    REQUIRE_INITIALIZED("CompleteOffMeshLink", )

    GetCrowdManager()->CompleteOffMeshLink(m_AgentRef);
}

NavMeshPathStatus NavMeshAgent::GetPathStatus() const
{
    if (!InCrowdSystem() || !GetInternalAgent()->corridor.IsPathValid())
        return kPathInvalid;

    if (GetInternalAgent()->corridor.IsPathPartial())
        return kPathPartial;

    return kPathComplete;
}

bool NavMeshAgent::IsPathValid() const
{
    if (!InCrowdSystem())
        return false;

    return GetInternalAgent()->corridor.IsPathValid();
}

bool NavMeshAgent::IsPathPartial() const
{
    if (!InCrowdSystem())
        return false;

    return GetInternalAgent()->corridor.IsPathPartial();
}

bool NavMeshAgent::IsPathStale() const
{
    if (!InCrowdSystem())
        return false;

    return GetInternalAgent()->corridor.IsPathStale();
}

void NavMeshAgent::SetAreaCost(unsigned int areaIndex, float areaCost)
{
    REQUIRE_INITIALIZED("SetAreaCost", )

    if (areaIndex >= NavMeshProjectSettings::kAreaCount)
    {
        ErrorString("Area index out of bounds");
        return;
    }

#if UNITY_EDITOR
    if (areaCost < 1.0f)
    {
        WarningStringObject(NavMeshProjectSettings::s_WarningCostLessThanOne, this);
    }
#endif

    GetCrowdManager()->UpdateAgentFilterCost(m_AgentRef, areaIndex, areaCost);
}

float NavMeshAgent::GetAreaCost(unsigned int areaIndex) const
{
    REQUIRE_INITIALIZED("GetAreaCost", 0.0F)

    if (areaIndex >= NavMeshProjectSettings::kAreaCount)
    {
        ErrorString("Area index out of bounds");
        return 0.0F;
    }

    const QueryFilter& filter = GetFilter();
    return filter.GetAreaCost(areaIndex);
}

Vector2f NavMeshAgent::CalculateDimensionScales() const
{
    Vector3f absScale = Abs(GetComponent<Transform>().GetWorldScaleLossy());
    float scaleWidth = std::max(absScale.x, absScale.z);
    float scaleHeight = absScale.y;
    return Vector2f(scaleWidth, scaleHeight);
}

Vector3f NavMeshAgent::GetGroundPosition() const
{
    if (m_AgentRef == 0)
        return GetGroundPositionFromTransform();

    const CrowdAgent* agent = GetInternalAgent();
    return agent->npos;
}

float NavMeshAgent::CalculateScaledRadius() const
{
    const Vector2f scale = CalculateDimensionScales();
    return m_Radius * scale.x;
}

float NavMeshAgent::CalculateScaledHeight() const
{
    const Vector2f scale = CalculateDimensionScales();
    return m_Height * scale.y;
}

void NavMeshAgent::SetAutoTraverseOffMeshLink(bool inbool)
{
    m_AutoTraverseOffMeshLink = inbool;
    UpdateActiveAgentParameters();
    SetDirty();
}

void NavMeshAgent::SetAutoBraking(bool inbool)
{
    m_AutoBraking = inbool;
    UpdateActiveAgentParameters();
    SetDirty();
}

void NavMeshAgent::SetAutoRepath(bool inbool)
{
    m_AutoRepath = inbool;
    UpdateActiveAgentParameters();
    SetDirty();
}

void NavMeshAgent::SetHeight(float value)
{
    ABORT_INVALID_FLOAT(value, height, navmeshagent);
    m_Height = value;
    UpdateActiveAgentParameters();
    SetDirty();
}

void NavMeshAgent::SetBaseOffset(float baseOffset)
{
    ABORT_INVALID_FLOAT(baseOffset, baseOffset, navmeshagent);
    m_BaseOffset = baseOffset;
    SetDirty();
    if (!InCrowdSystem())
        return;

    if (m_UpdatePosition)
    {
        const CrowdAgent* agent = GetInternalAgent();
        SetTransformFromGroundPosition(agent->npos);
    }
}

void NavMeshAgent::SetAgentTypeID(int value)
{
    if (m_AgentTypeID == value)
        return;

    m_AgentTypeID = value;
    SetDirty();

    RemoveFromCrowdSystem();
    AddToCrowdSystem();
}

int NavMeshAgent::GetAgentTypeID() const
{
    return m_AgentTypeID;
}

void NavMeshAgent::SetRadius(float value)
{
    ABORT_INVALID_FLOAT(value, radius, navmeshagent);
    m_Radius = value;
    UpdateActiveAgentParameters();
    SetDirty();
}

void NavMeshAgent::SetSpeed(float value)
{
    ABORT_INVALID_FLOAT(value, speed, navmeshagent);
    m_Speed = value;
    UpdateActiveAgentParameters();
    SetDirty();
}

void NavMeshAgent::SetAvoidancePriority(int value)
{
    m_AvoidancePriority = value;
    UpdateActiveAgentParameters();
    SetDirty();
}

void NavMeshAgent::SetAngularSpeed(float value)
{
    ABORT_INVALID_FLOAT(value, angularSpeed, navmeshagent);
    m_AngularSpeed = value;
    UpdateActiveAgentParameters();
    SetDirty();
}

void NavMeshAgent::SetAcceleration(float value)
{
    ABORT_INVALID_FLOAT(value, acceleration, navmeshagent);
    m_Acceleration = value;
    UpdateActiveAgentParameters();
    SetDirty();
}

void NavMeshAgent::SetStoppingDistance(float value)
{
    ABORT_INVALID_FLOAT(value, stoppingDistance, navmeshagent);
    m_StoppingDistance = value;
    UpdateActiveAgentParameters();
    SetDirty();
}

void NavMeshAgent::SetAreaMask(UInt32 areaMask)
{
    m_WalkableMask = areaMask;
    UpdateActiveAgentParameters();
    SetDirty();
}

void NavMeshAgent::SetObstacleAvoidanceType(ObstacleAvoidanceType type)
{
    m_ObstacleAvoidanceType = type;
    UpdateActiveAgentParameters();
    SetDirty();
}

const NavMesh* NavMeshAgent::GetInternalNavMesh()
{
    return GetNavMeshManager().GetInternalNavMesh();
}

CrowdManager* NavMeshAgent::GetCrowdManager()
{
    return GetNavMeshManager().GetCrowdManager();
}

Vector3f NavMeshAgent::GetInternalUpAxis() const
{
#if ENABLE_RUNTIME_NAVMESH_BUILDING
    return GetCrowdManager()->GetWorldUpAxis(m_AgentRef);
#else
    return Vector3f(0, 1, 0);
#endif
}

IMPLEMENT_REGISTER_CLASS(NavMeshAgent, 195);
IMPLEMENT_OBJECT_SERIALIZE(NavMeshAgent);
