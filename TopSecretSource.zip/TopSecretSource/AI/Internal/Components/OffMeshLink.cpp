#include "UnityPrefix.h"
#include "OffMeshLink.h"
#include "../NavMeshManager.h"
#include "../NavMeshProjectSettings.h"
#include "Runtime/Utilities/ValidateArgs.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"

OffMeshLink::OffMeshLink(MemLabelId label, ObjectCreationMode mode)
    :   Super(label, mode)
{
    m_AreaIndex = NavMeshProjectSettings::kWalkable;
    m_AgentTypeID = 0;
    m_ConnectionPolyRef = 0;
    m_ManagerHandle = -1;
    m_CostOverride = -1.0f;
    m_BiDirectional = true;
    m_AutoUpdatePositions = false;
    m_ShouldUpdatePositions = false;
    m_Activated = true;

    m_StartPosition = Vector3f::infinityVec;
    m_EndPosition = Vector3f::infinityVec;
    m_MoveThreshold = 0.5f;
}

void OffMeshLink::Reset()
{
    Super::Reset();
}

void OffMeshLink::SmartReset()
{
    Super::SmartReset();
#if UNITY_EDITOR
    m_AreaIndex = GetGameObject().GetNavMeshLayer();
#endif
}

void OffMeshLink::ThreadedCleanup()
{
}

void OffMeshLink::AddToManager()
{
    if (m_ManagerHandle != -1)
        return;
    GetNavMeshManager().RegisterOffMeshLink(*this, m_ManagerHandle);
    m_ShouldUpdatePositions = true;
}

void OffMeshLink::RemoveFromManager()
{
    RemoveConnection();

    if (m_ManagerHandle != -1)
        GetNavMeshManager().UnregisterOffMeshLink(m_ManagerHandle);
}

template<class TransferFunc>
void OffMeshLink::Transfer(TransferFunc& transfer)
{
    Super::Transfer(transfer);

    transfer.SetVersion(3);

    if (transfer.IsOldVersion(2))
        transfer.Transfer(m_AreaIndex, "m_NavMeshLayer");
    else
        TRANSFER(m_AreaIndex);

    TRANSFER(m_AgentTypeID);
    TRANSFER(m_Start);
    TRANSFER(m_End);
    TRANSFER(m_CostOverride);

    transfer.Align();
    TRANSFER(m_BiDirectional);
    TRANSFER(m_Activated);
    TRANSFER(m_AutoUpdatePositions);
}

void OffMeshLink::AwakeFromLoad(AwakeFromLoadMode mode)
{
    Super::AwakeFromLoad(mode);
    UpdatePositions();
}

void OffMeshLink::UpdatePositions()
{
    if (!IsActive() || !GetEnabled())
        return;

    RemoveConnection();
    AddConnection();
    m_ShouldUpdatePositions = false;
}

void OffMeshLink::AddConnection()
{
    AssertMsg(m_ConnectionPolyRef == 0, "Has internal connection already");

    if (!m_End || !m_Start || m_AreaIndex == NavMeshProjectSettings::kNotWalkable)
        return;

    const int instanceID = GetInstanceID();
    const Vector3f startPos = m_Start->GetPosition();
    const Vector3f endPos = m_End->GetPosition();

    NavMeshManager& manager = GetNavMeshManager();

    m_ConnectionPolyRef = manager.AddOffMeshConnection(startPos, endPos, instanceID, m_BiDirectional, (unsigned char)m_AreaIndex, m_AgentTypeID);
    if (m_ConnectionPolyRef)
    {
        manager.SetOffMeshConnectionCostOverride(m_ConnectionPolyRef, m_CostOverride);
        manager.SetOffMeshConnectionActive(m_ConnectionPolyRef, m_Activated);
        manager.GetOffMeshConnectionPositions(m_ConnectionPolyRef, &m_StartPosition, &m_EndPosition);

        const Vector3f ext = manager.GetLinkQueryExtents(m_AgentTypeID);
        m_MoveThreshold = std::min(ext.x, ext.y);
    }
    else
    {
        m_StartPosition = startPos;
        m_EndPosition = endPos;
    }
}

bool OffMeshLink::HasEndpointMoved() const
{
    if (!m_Start || !m_End)
        return false;

    return !CompareApproximately(m_StartPosition, m_Start->GetPosition(), m_MoveThreshold)
        || !CompareApproximately(m_EndPosition, m_End->GetPosition(), m_MoveThreshold);
}

void OffMeshLink::OnNavMeshAdded()
{
    if (!m_ConnectionPolyRef)
    {
        UpdatePositions();
    }
}

void OffMeshLink::OnNavMeshCleanup()
{
    RemoveConnection();
}

void OffMeshLink::UpdateMovedPositions()
{
    if (m_ShouldUpdatePositions || (m_AutoUpdatePositions && HasEndpointMoved()))
        UpdatePositions();
}

void OffMeshLink::RemoveConnection()
{
    if (m_ConnectionPolyRef == 0)
        return;
    GetNavMeshManager().RemoveOffMeshConnection(m_ConnectionPolyRef);
    m_ConnectionPolyRef = 0;
}

void OffMeshLink::SetCostOverride(float costOverride)
{
    ABORT_INVALID_FLOAT(costOverride, costOverride, OffMeshLink);
    if (m_CostOverride == costOverride)
        return;

    m_CostOverride = costOverride;
    if (m_ConnectionPolyRef)
        GetNavMeshManager().SetOffMeshConnectionCostOverride(m_ConnectionPolyRef, m_CostOverride);

    SetDirty();
}

void OffMeshLink::SetBiDirectional(bool bidirectional)
{
    if (m_BiDirectional == bidirectional)
        return;
    m_BiDirectional = bidirectional;
    SetDirty();
}

void OffMeshLink::SetActivated(bool activated)
{
    if (m_Activated == activated)
        return;

    m_Activated = activated;
    if (m_ConnectionPolyRef)
        GetNavMeshManager().SetOffMeshConnectionActive(m_ConnectionPolyRef, m_Activated);

    SetDirty();
}

void OffMeshLink::SetArea(UInt32 areaIndex)
{
    if (m_AreaIndex == areaIndex)
        return;

    m_AreaIndex = areaIndex;
    UpdatePositions();
    SetDirty();
}

bool OffMeshLink::GetOccupied() const
{
    return GetNavMeshManager().IsOffMeshConnectionOccupied(m_ConnectionPolyRef);
}

IMPLEMENT_REGISTER_CLASS(OffMeshLink, 191);
IMPLEMENT_OBJECT_SERIALIZE(OffMeshLink);
