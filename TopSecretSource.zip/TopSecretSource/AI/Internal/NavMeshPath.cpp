#include "UnityPrefix.h"
#include "NavMeshPath.h"


NavMeshPath::NavMeshPath()
    : m_timeStamp(0)
    , m_status(kPathInvalid)
{
}

NavMeshPath::~NavMeshPath()
{
}

void NavMeshPath::ReservePolygons(int size)
{
    static const int kSizeInc = 32;
    int cap = ((size + kSizeInc - 1) / kSizeInc) * kSizeInc;
    m_polygons.reserve(cap);
}
