#pragma once

#include "NavMeshBuildSettings.h"
#include "Runtime/BaseClasses/GameManager.h"


class NavMeshProjectSettings : public GlobalGameManager
{
    REGISTER_CLASS(NavMeshProjectSettings);
    DECLARE_OBJECT_SERIALIZE();
public:
    struct NavMeshAreaData
    {
        DECLARE_SERIALIZE(NavMeshAreaData)
        core::string name;
        float cost;
    };

    enum BuiltinNavMeshProjectSettings
    {
        kWalkable = 0,
        kNotWalkable = 1,
        kJump = 2
    };

    NavMeshProjectSettings(MemLabelId label, ObjectCreationMode mode);
    // ~NavMeshProjectSettings (); declared-by-macro

    virtual void Reset();
    virtual void AwakeFromLoad(AwakeFromLoadMode awakeMode);
    virtual void CheckConsistency();

    void SetAreaCost(unsigned int index, float cost);
    float GetAreaCost(unsigned int index) const;
    int GetAreaFromName(const core::string& areaName) const;
    std::vector<core::string> GetAreaNames() const;

#if ENABLE_RUNTIME_NAVMESH_BUILDING
    // Create build settings and remember the agentTypeID for that
    const NavMeshBuildSettings& CreateSettings();

    // Updates the build settings - unless the agentTypeID of the
    // settings is not known
    void UpdateSettings(const NavMeshBuildSettings& settings);

    // Removes the build settings for agentTypeID unless the settings
    // are the default settings or the id is not known
    void RemoveSettings(int agentTypeID);

    // Gets the build settings for the agentTypeID
    // Returns null if the id is not known
    const NavMeshBuildSettings* GetSettingsByID(int agentTypeID) const;

    // Linear accessors
    // returns upper bound
    int GetSettingsCount() const;

    // Gets value by index
    // Returns null when out of bounds
    const NavMeshBuildSettings* GetSettingsByIndex(int index) const;

    // Settings names:
    // Sets the name unless the id is not known
    void SetSettingsNameForID(int agentTypeID, const core::string& name);

    // The name associated with the build settings for agentTypeID
    // Returns null if the id is not known
    const core::string* GetSettingsNameFromID(int agentTypeID) const;

    enum
    {
        kInvalidAgentTypeID = -1,
        kDefaultAgentTypeID = 0
    };
#endif

    enum
    {
        kBuiltinAreaCount = 3,
        kAreaCount = 32
    };


    static const char* s_WarningCostLessThanOne;
    static const char* s_WarningUsingObsoleteAreaName;

private:

    NavMeshAreaData m_Areas[kAreaCount];

#if ENABLE_RUNTIME_NAVMESH_BUILDING
    int GetUnusedAgentTypeID();
    int m_LastAgentTypeID;

    // This separation of string data and string settings is done purely
    // to save string handling if names are not used - thus saving allocations at runtime.
    // esp. GC allocations in scripts are concerned.
    std::vector<NavMeshBuildSettings> m_Settings;
    std::vector<core::string> m_SettingNames;

#endif
};

NavMeshProjectSettings& GetNavMeshProjectSettings();
