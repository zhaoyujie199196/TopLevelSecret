#pragma once

#include "NavMeshCarveTypes.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Jobs/JobTypes.h"
#include "Runtime/Geometry/AABB.h"
#include <vector>

class NavMeshObstacle;
class NavMesh;

struct CarveResult
{
    unsigned char* carvedData;
    int carvedDataSize;
    int status; // CarveResultStatus
};

class NavMeshCarving
{
    struct ObstacleCarveInfo
    {
        NavMeshCarveShape shape;    // Current shape
        MinMaxAABB bounds;          // Current bounds, cached from shape to allow matching add/remove.
        NavMeshObstacle* obstacle;
        int versionStamp;
    };

public:
    NavMeshCarving();
    ~NavMeshCarving();

    void AddObstacle(NavMeshObstacle& obstacle, int& handle);
    void RemoveObstacle(int& handle);
    void SetSurfaceDirty(int surfaceID);

    void PrepareCarving();
    void Carve();
    void ApplyCarveResults();

private:
    JobFence m_CarveJobFence;

    bool NeedsUpdateCollectCarveData(CarveData& carveData, const MinMaxAABB& bounds,
        const dynamic_array<MinMaxAABB>& updateBounds) const;

    UNITY_VECTOR_SET(kMemAI, int) m_DirtySurfaces;
    UNITY_VECTOR(kMemAI, CarveData) m_TileCarveData;

    dynamic_array<ObstacleCarveInfo> m_ObstacleInfo;
    dynamic_array<int> m_ObstacleFreelist;
    dynamic_array<MinMaxAABB> m_DirtyBounds;
    dynamic_array<CarveResult> m_CarveResults;
};
