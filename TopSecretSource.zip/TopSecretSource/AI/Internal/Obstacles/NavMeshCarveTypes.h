#pragma once

#include "../NavMeshBindingTypes.h"
#include "Runtime/Math/Quaternion.h"
#include "Runtime/Utilities/dynamic_array.h"


struct NavMeshCarveShape
{
    int shape; // NavMeshObstacleShape
    Vector3f center;
    Vector3f extents;
    Vector3f xAxis;
    Vector3f yAxis;
    Vector3f zAxis;
    MinMaxAABB bounds;
};

class CarveData
{
public:
    CarveData(const int surfaceID, const int tileIndex)
        : m_SurfaceID(surfaceID)
        , m_TileIndex(tileIndex)
        , m_Shapes(kMemAI)
    {
    }

    void AddShape(const NavMeshCarveShape& shape)
    {
        m_Shapes.push_back(shape);
    }

    bool Empty() const
    {
        return m_Shapes.empty();
    }

    int m_SurfaceID;
    int m_TileIndex;
    Vector3f m_Position;
    Quaternionf m_Rotation;
    dynamic_array<NavMeshCarveShape> m_Shapes;
};
