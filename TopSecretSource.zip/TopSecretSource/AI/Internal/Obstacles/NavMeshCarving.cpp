#include "UnityPrefix.h"
#include "NavMeshCarving.h"

#include <float.h>
#include <string.h>
#include <algorithm>
#include "../NavMeshData.h"
#include "../NavMeshSettings.h"
#include "../Components/NavMeshObstacle.h"
#include "../NavMesh/NavMesh.h"

#include "NavMeshTileCarving.h"
#include "Runtime/Geometry/AABB.h"
#include "Runtime/Geometry/Intersection.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Jobs/Jobs.h"

// Performance note:
// The performance of the current implementation will be sub-optimal
// in case of many tiles compared to update count.
//
// Consider letting obstacles push themselves to lists of tiles which they cover.

PROFILER_INFORMATION(gNavMeshCarvePrepare, "Carving.Prepare", kProfilerAI)
PROFILER_INFORMATION(gNavMeshCarve, "Carving.Clipping", kProfilerAI)
PROFILER_INFORMATION(gNavMeshCarveApplyResults, "Carving.ApplyResults", kProfilerAI)


NavMeshCarving::NavMeshCarving()
    : m_ObstacleInfo(kMemAI)
    , m_ObstacleFreelist(kMemAI)
    , m_DirtyBounds(kMemAI)
    , m_CarveResults(kMemAI)
{
}

NavMeshCarving::~NavMeshCarving()
{
    SyncFence(m_CarveJobFence);
}

void NavMeshCarving::AddObstacle(NavMeshObstacle& obstacle, int& handle)
{
    Assert(handle == -1);
    if (!m_ObstacleFreelist.empty())
    {
        handle = m_ObstacleFreelist.back();
        m_ObstacleFreelist.pop_back();
    }
    else
    {
        handle = m_ObstacleInfo.size();
        m_ObstacleInfo.push_back();
    }
    ObstacleCarveInfo& info = m_ObstacleInfo[handle];
    info.obstacle = &obstacle;
    info.versionStamp = -1;
    memset(&info.shape, 0, sizeof(info.shape));
}

void NavMeshCarving::RemoveObstacle(int& handle)
{
    Assert(handle >= 0 && handle < (int)m_ObstacleInfo.size());
    m_ObstacleInfo[handle].obstacle = NULL;
    m_DirtyBounds.push_back(m_ObstacleInfo[handle].bounds);
    m_ObstacleFreelist.push_back(handle);
    handle = -1;
}

void NavMeshCarving::SetSurfaceDirty(int surfaceID)
{
    m_DirtySurfaces.insert(surfaceID);
}

void NavMeshCarving::PrepareCarving()
{
    AssertMsg(m_TileCarveData.empty(), "Previously prepared Carve Data is unprocessed");
    if (m_ObstacleInfo.empty() && m_DirtyBounds.empty())
        return;

    PROFILER_AUTO(gNavMeshCarvePrepare, NULL)

    // Update the bounds for carving
    // Dirty previously carved bounds if obstacle moves
    dynamic_array<MinMaxAABB> updateBounds(kMemTempAlloc);
    const size_t obstacleCount = m_ObstacleInfo.size();
    for (size_t i = 0; i < obstacleCount; ++i)
    {
        if (m_ObstacleInfo[i].obstacle == NULL)
            continue;

        // If the obstacle has not changed, no need to update.
        if (m_ObstacleInfo[i].versionStamp == m_ObstacleInfo[i].obstacle->GetVersionStamp())
            continue;
        m_ObstacleInfo[i].versionStamp = m_ObstacleInfo[i].obstacle->GetVersionStamp();

        // Mark previously carved bounds as dirty.
        m_DirtyBounds.push_back(m_ObstacleInfo[i].bounds);

        // Get new carve data and mark the new location to be updated.
        NavMeshCarveShape& shape = m_ObstacleInfo[i].shape;
        m_ObstacleInfo[i].obstacle->GetCarveShape(shape);
        m_ObstacleInfo[i].bounds = shape.bounds;

        updateBounds.push_back(m_ObstacleInfo[i].bounds);
    }

    // No tiles or obstacles changed
    if (updateBounds.empty() && m_DirtyBounds.empty() && m_DirtySurfaces.empty())
        return;

    dynamic_array<TileLocation> locations(kMemTempAlloc);
    const NavMeshManager& manager = GetNavMeshManager();
    manager.GetSourceTileDataBounds(locations);

    int currentSurfaceID = 0;
    bool cachedIsDirty = false;
    Vector3f cachedTilePosition;
    Quaternionf cachedTileRotation;
    Matrix4x4f cachedTileTransform;
    const NavMesh* navmesh = manager.GetInternalNavMesh();

    for (size_t i = 0; i < locations.size(); ++i)
    {
        TileLocation& loc = locations[i];
        MinMaxAABB tileBounds = loc.m_Bounds;

        const NavMeshBuildSettings& settings = manager.GetNavMeshBuildSettings(loc.m_SurfaceID);
        const float walkableHeight = settings.agentHeight;
        const float walkableRadius = settings.agentRadius;

        // Extend the tile bounds by the carving dimensions
        // Note that the asymmetry in the vertical direction - which includes tiles below carving object, but not above
        // Carve hull is expanded so that some corners are offset up to (and a little over) sqrt (2) * radius.
        const float kOffsetRadius = walkableRadius * 1.415f;
        tileBounds.m_Min.x -= kOffsetRadius;
        tileBounds.m_Min.z -= kOffsetRadius;

        tileBounds.m_Max.x += kOffsetRadius;
        tileBounds.m_Max.y += walkableHeight;
        tileBounds.m_Max.z += kOffsetRadius;

        // TODO: clean up - the outer loop should be over surfaces
        if (currentSurfaceID != loc.m_SurfaceID)
        {
            navmesh->GetSurfaceTransform(loc.m_SurfaceID, &cachedTilePosition, &cachedTileRotation);
            cachedTileTransform.SetTR(cachedTilePosition, cachedTileRotation);
            cachedIsDirty = m_DirtySurfaces.find(loc.m_SurfaceID) != m_DirtySurfaces.end();
            currentSurfaceID = loc.m_SurfaceID;
        }
        MinMaxAABB worldTileBounds;
        TransformAABBSlow(tileBounds, cachedTileTransform, worldTileBounds);

        CarveData carveData(loc.m_SurfaceID, loc.m_TileIndex);
        carveData.m_Position = cachedTilePosition;
        carveData.m_Rotation = cachedTileRotation;

        if (cachedIsDirty)
        {
            // Surface is dirty - this tile should be carved if any obstacle overlaps
            for (size_t j = 0; j < m_ObstacleInfo.size(); ++j)
            {
                ObstacleCarveInfo& info = m_ObstacleInfo[j];
                if (info.obstacle != NULL)
                {
                    if (IntersectAABBAABB(info.bounds, worldTileBounds))
                    {
                        carveData.AddShape(info.shape);
                    }
                }
            }
            if (!carveData.Empty())
            {
                m_TileCarveData.push_back(carveData);
            }

            // Intentionally ignore the dirty-bounds vs. dirty-tile overlap (restore tile)
            // assuming the dirty-tile is just loaded - and hence restoring is needless.
        }
        else
        {
            if (NeedsUpdateCollectCarveData(carveData, worldTileBounds, updateBounds))
            {
                m_TileCarveData.push_back(carveData);
            }
        }
    }

    m_CarveResults.resize_initialized(m_TileCarveData.size());

    m_DirtySurfaces.clear();
    m_DirtyBounds.resize_uninitialized(0);
}

static bool CompareCarveShapes(const NavMeshCarveShape& lhs, const NavMeshCarveShape& rhs)
{
    if (lhs.center.x < rhs.center.x)
        return true;
    if (rhs.center.x < lhs.center.x)
        return false;

    // rhs.x == lhs.x
    if (lhs.center.z < rhs.center.z)
        return true;
    if (rhs.center.z < lhs.center.z)
        return false;

    // rhs.x == lhs.x && rhs.z == lhs.z
    if (lhs.center.y < rhs.center.y)
        return true;
    if (rhs.center.y < lhs.center.y)
        return false;

    // all same - favour the biggest
    return SqrMagnitude(lhs.extents) > SqrMagnitude(rhs.extents);
}

struct CarveJobInfo
{
    int count;
    CarveData* carveDatas;
    CarveResult* results;
};

static CarveJobInfo s_info = {};

static void CarveJobMultithreaded(CarveJobInfo* info, unsigned i)
{
    PROFILER_AUTO(gNavMeshCarve, NULL)

    CarveData& carveData = info->carveDatas[i];
    const int surfaceID = carveData.m_SurfaceID;
    const int tileIndex = carveData.m_TileIndex;

    CarveResult& res = info->results[i];
    res.status = kRemoveTile;
    res.carvedData = NULL;
    res.carvedDataSize = 0;

    // Get source tile data
    const NavMeshManager& manager = GetNavMeshManager();
    const NavMeshTileData* sourceTile = manager.GetSourceTileData(surfaceID, tileIndex);
    if (sourceTile == NULL)
        return;

    const NavMeshBuildSettings& settings = manager.GetNavMeshBuildSettings(surfaceID);
    const float height = settings.agentHeight;
    const float radius = settings.agentRadius;
    const float cellSize = settings.cellSize;
    const float quantSize = cellSize / 64.0f;

    // This tile requires carving, carve based on source data.
    const unsigned char* sourceData = sourceTile->m_MeshData.begin();
    const int sourceDataSize = sourceTile->m_MeshData.size();

    std::sort(carveData.m_Shapes.begin(), carveData.m_Shapes.end(), CompareCarveShapes);

    res.status = CarveNavMeshTile(&res.carvedData, &res.carvedDataSize, sourceData, sourceDataSize,
            carveData.m_Shapes.begin(), carveData.m_Shapes.size(),
            height, radius, quantSize, carveData.m_Position, carveData.m_Rotation);
}

void NavMeshCarving::Carve()
{
    Assert(m_TileCarveData.size() == m_CarveResults.size());
    if (m_TileCarveData.empty())
        return;

    s_info.count = m_TileCarveData.size();
    s_info.carveDatas = &m_TileCarveData[0];
    s_info.results = &m_CarveResults[0];

    ScheduleJobForEach(m_CarveJobFence, CarveJobMultithreaded, &s_info, s_info.count, kHighJobPriority);

    // For single threaded testing.
    // for (int i = 0; i < s_info.count; i++)
    //  CarveJobMultithreaded (&s_info, i);
}

void NavMeshCarving::ApplyCarveResults()
{
    PROFILER_AUTO(gNavMeshCarveApplyResults, NULL)

    SyncFence(m_CarveJobFence);
    Assert(m_TileCarveData.size() == m_CarveResults.size());

    NavMeshManager& manager = GetNavMeshManager();
    for (size_t i = 0; i < m_TileCarveData.size(); ++i)
    {
        CarveData& carveData = m_TileCarveData[i];
        const int surfaceID = carveData.m_SurfaceID;
        const int tileIndex = carveData.m_TileIndex;

        CarveResult& res = m_CarveResults[i];
        const CarveResultStatus status = (CarveResultStatus)res.status;

        if (status == kRestoreTile)
        {
            manager.RestoreTile(surfaceID, tileIndex);
        }
        else if (status == kReplaceTile)
        {
            manager.RemoveTile(surfaceID, tileIndex);
            if (res.carvedData != NULL && res.carvedDataSize > 0)
            {
                manager.ReplaceTile(surfaceID, tileIndex, res.carvedData, res.carvedDataSize);
            }
        }
        else
        {
            Assert(status == kRemoveTile);
            manager.RemoveTile(surfaceID, tileIndex);
        }
    }

    m_TileCarveData.clear();
    m_CarveResults.clear();
}

// Does any of the bounds in 'arrayOfBounds' overlap with 'bounds'
static bool AnyOverlaps(const dynamic_array<MinMaxAABB>& arrayOfBounds, const MinMaxAABB& bounds)
{
    const size_t count = arrayOfBounds.size();
    for (size_t i = 0; i < count; ++i)
    {
        if (IntersectAABBAABB(arrayOfBounds[i], bounds))
            return true;
    }
    return false;
}

// Returns true if 'bounds' need update. Collects obstacle information.
bool NavMeshCarving::NeedsUpdateCollectCarveData(CarveData& carveData, const MinMaxAABB& bounds,
    const dynamic_array<MinMaxAABB>& updateBounds) const
{
    AssertMsg(carveData.Empty(), "Expects empty input");
    const bool dirtyOverlaps = AnyOverlaps(m_DirtyBounds, bounds);

    if (dirtyOverlaps || AnyOverlaps(updateBounds, bounds))
    {
        for (size_t i = 0; i < m_ObstacleInfo.size(); ++i)
        {
            if (m_ObstacleInfo[i].obstacle != NULL)
            {
                if (IntersectAABBAABB(m_ObstacleInfo[i].bounds, bounds))
                {
                    carveData.AddShape(m_ObstacleInfo[i].shape);
                }
            }
        }
    }
    return dirtyOverlaps || !carveData.Empty();
}
