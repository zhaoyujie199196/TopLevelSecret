#pragma once

#include "Runtime/Math/Vector3.h"
#include "Runtime/Utilities/dynamic_array.h"

class NavMesh;
class Matrix4x4f;
class MinMaxAABB;
struct NavMeshCarveShape;

enum CarveResultStatus
{
    kReplaceTile,
    kRestoreTile,
    kRemoveTile
};

CarveResultStatus CarveNavMeshTile(unsigned char** tileData, int* tileDataSize, const unsigned char* sourceData, int sourceDataSize,
    const NavMeshCarveShape* shapes, int shapeCount, float carveDepth, float carveWidth, float quantSize,
    const Vector3f& position, const Quaternionf& rotation);

void CalculateHullWireMesh(dynamic_array<Vector3f>& lines, const NavMeshCarveShape& shape,
    const float carveDepth, const float carveWidth);
