#include "UnityPrefix.h"
#include "./DynamicMesh.h"
#include "../MathUtil.h"

#include "Runtime/Utilities/Utility.h"
#include "Runtime/Profiler/Profiler.h"

PROFILER_INFORMATION(gDynamicMeshFindNeighbors, "DynamicMesh.FindNeighbors", kProfilerAI)
PROFILER_INFORMATION(gDynamicMeshClipPolys, "DynamicMesh.ClipPolys", kProfilerAI)
PROFILER_INFORMATION(gDynamicMeshCreate, "DynamicMesh.Create", kProfilerAI)

const int MAX_OUTPUT_VERTICES = 32;
const unsigned char PLANE_FLAG = 0x80;
const unsigned char PLANE_INDEX_MASK = PLANE_FLAG - 1;

static void SplitPolyInternal(size_t vertexCount, float* dist, DynamicMesh::Polygon& inside, const DynamicMesh::Polygon& poly, const Plane& plane, unsigned char* usedEdges, size_t ip);
static int SplitPoly(DynamicMesh::Polygon& inside, const DynamicMesh::Polygon& poly, const Plane& plane, float quantFactor, unsigned char* usedEdges, size_t ip);


// Is triangle degenerate in 3D space
static inline bool DegenerateTriangle(const DynamicMesh::Polygon& tri)
{
    DebugAssert(tri.size() == 3);

    const Vector3f ab = tri[1] - tri[0];
    const Vector3f ac = tri[2] - tri[0];
    const Vector3f n = Cross(ab, ac);
    float areaSq = SqrMagnitude(n);
    return areaSq == 0;
}

// Test if polygon is convex by conservative threshold
static inline bool IsSafeConvex(const dynamic_array<Vector3f>& vertices)
{
    const size_t vertexCount = vertices.size();
    for (size_t i = 0; i < vertexCount; ++i)
    {
        const Vector3f& v0 = vertices[PrevIndex(i, vertexCount)];
        const Vector3f& v1 = vertices[i];
        const Vector3f& v2 = vertices[NextIndex(i, vertexCount)];
        const float triArea = TriArea2D(v0, v1, v2);
        if (triArea <= 1e-2f)
            return false;
    }
    return true;
}

// Locate furthest vertex in positive half-plane or -1 in none found.
static int FindFurthest(const Plane& plane, const dynamic_array<Vector3f>& vertices, float quantFactor)
{
    int bestIndex = -1;
    float bestDist = quantFactor;

    for (size_t iv = 0; iv < vertices.size(); ++iv)
    {
        const float dist = plane.GetDistanceToPoint(vertices[iv]);
        if (dist > bestDist)
        {
            bestDist = dist;
            bestIndex = iv;
        }
    }
    return bestIndex;
}

static inline bool PolygonDegenerate(size_t vertexCount, const UInt16* indices, const Vector3f* vertices, const float quantFactor)
{
    if (vertexCount < 3)
    {
        return true;
    }
    float area = 0.0f;
    float maxSideSq = 0.0f;
    for (size_t i = 2; i < vertexCount; ++i)
    {
        const Vector3f& v0 = vertices[indices[0]];
        const Vector3f& v1 = vertices[indices[i - 1]];
        const Vector3f& v2 = vertices[indices[i]];
        const float triArea = TriArea2D(v0, v1, v2);

        area += triArea;
        maxSideSq = std::max(SqrMagnitude(v1 - v0), maxSideSq);
        maxSideSq = std::max(SqrMagnitude(v2 - v0), maxSideSq);
    }
    if (area <= 0)
    {
        return true;
    }
    const float safety = 1e-2f * quantFactor;
    return area * area <= safety * safety * maxSideSq;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

DynamicMesh::DynamicMesh(const float quantFactor)
    : m_Polygons(kMemTempAlloc)
    , m_Vertices(kMemTempAlloc)
    , m_Data(kMemTempAlloc)
    , m_Welder(kMemTempAlloc, NULL, quantFactor)
    , m_QuantFactor(quantFactor)
{
    PROFILER_AUTO(gDynamicMeshCreate, NULL)
    m_Welder.SetVertexArray(&m_Vertices);
}

DynamicMesh::Poly DynamicMesh::CreatePolygon(const Polygon& vertices, const UInt32 status)
{
    size_t vertexCount = vertices.size();
    DebugAssert(vertexCount <= kNumVerts);
    DebugAssert(vertexCount > 2);

    // Ensure neighbour ids are zero'ed
    Poly newPoly = {{0}, {0}, 0, 0};

    newPoly.m_VertexCount = vertexCount;
    newPoly.m_Status = status;
    for (size_t i = 0; i < vertexCount; ++i)
    {
        size_t vi = (size_t)m_Welder.AddUnique(vertices[i]);
        DebugAssert(vi < 0xffff);  //< vertex overflow
        newPoly.m_VertexIDs[i] = (UInt16)vi;
    }
    return newPoly;
}

void DynamicMesh::RemovePolygonUnordered(size_t i)
{
    DebugAssert(i < m_Polygons.size());
    DebugAssert(m_Data.size() == m_Polygons.size());

    m_Polygons[i] = m_Polygons.back();
    m_Polygons.pop_back();

    m_Data[i] = m_Data.back();
    m_Data.pop_back();
}

void DynamicMesh::CollapseEdge(int va, int vb)
{
    for (int i = 0; i < m_Polygons.size(); i++)
    {
        Poly& poly = m_Polygons[i];
        for (int j = 0; j < (int)poly.m_VertexCount; j++)
        {
            if (poly.m_VertexIDs[j] == va)
                poly.m_VertexIDs[j] = vb;
        }
    }
}

void DynamicMesh::CollapsePolygonUnordered(size_t ip)
{
    DebugAssert(ip < m_Polygons.size());
    DebugAssert(m_Data.size() == m_Polygons.size());

    Poly poly = m_Polygons[ip];
    float edgeLengths[kNumVerts];
    for (int i = 0; i < (int)poly.m_VertexCount; i++)
    {
        int j = i + 1 < (int)poly.m_VertexCount ? i + 1 : 0;
        const Vector3f& va = m_Vertices[poly.m_VertexIDs[i]];
        const Vector3f& vb = m_Vertices[poly.m_VertexIDs[j]];
        edgeLengths[i] = SqrMagnitude(va - vb);
    }

    // Collapse polygon to line, by collapsing the shortest edge at a time.
    while (poly.m_VertexCount > 2)
    {
        // Find shortest edge
        float shortestDist = edgeLengths[0];
        int shortest = 0;
        for (int i = 1; i < (int)poly.m_VertexCount; i++)
        {
            if (edgeLengths[i] < shortestDist)
            {
                shortestDist = edgeLengths[i];
                shortest = i;
            }
        }
        if (shortestDist > m_QuantFactor * m_QuantFactor)
            break;

        int next = shortest + 1 < (int)poly.m_VertexCount ? shortest + 1 : 0;
        int va = poly.m_VertexIDs[shortest];
        int vb = poly.m_VertexIDs[next];

        // Collapse edge va->vb
        if (va != vb)
            CollapseEdge(va, vb);

        for (int i = shortest; i < (int)poly.m_VertexCount - 1; i++)
        {
            edgeLengths[i] = edgeLengths[i + 1];
            poly.m_VertexIDs[i] = poly.m_VertexIDs[i + 1];
        }
        poly.m_VertexCount--;
    }

    RemovePolygonUnordered(ip);
}

// Clip the convex polygon 'poly' by the half-space defined by 'plane'
static int SplitPoly(DynamicMesh::Polygon& inside, const DynamicMesh::Polygon& poly, const Plane& plane, float quantFactor, unsigned char* usedEdges, size_t ip)
{
    const size_t vertexCount = poly.size();

    // Worst case number of vertices is kNumVerts + hull clipping planes
    DebugAssert(vertexCount < MAX_OUTPUT_VERTICES);
    float dist[MAX_OUTPUT_VERTICES];

    // Compute signed distance to plane for each vertex
    float distance = plane.GetDistanceToPoint(poly[0]);
    if (Abs(distance) < quantFactor)
        distance = 0;

    float minDistance, maxDistance;
    minDistance = maxDistance = dist[0] = distance;
    for (size_t iv = 1; iv < vertexCount; ++iv)
    {
        const Vector3f& v = poly[iv];
        distance = plane.GetDistanceToPoint(v);
        if (Abs(distance) < quantFactor)
            distance = 0;

        minDistance = std::min(minDistance, distance);
        maxDistance = std::max(maxDistance, distance);
        dist[iv] = distance;
    }

    // all points inside - accept
    if (maxDistance < 0)
        return -1;

    // all points outside - reject
    if (minDistance > 0)
        return 1;

    // single point co-planar - accept
    if (vertexCount == 1)
        return -1;

    // points are straddling plane - split
    SplitPolyInternal(vertexCount, dist, inside, poly, plane, usedEdges, ip);
    return 0;
}

static void SplitPolyInternal(size_t vertexCount, float* dist, DynamicMesh::Polygon& inside, const DynamicMesh::Polygon& poly, const Plane& plane, unsigned char* usedEdges, size_t ip)
{
    Assert(vertexCount == poly.size());
    Assert(vertexCount > 1);
    Assert(ip < PLANE_FLAG);
    inside.resize_uninitialized(0);

    unsigned char used[MAX_OUTPUT_VERTICES];
    int n = 0;

    Vector3f prevVert = poly[vertexCount - 1];
    float prevDist = dist[vertexCount - 1];

    for (size_t iv = 0; iv < vertexCount; ++iv)
    {
        const Vector3f& currVert = poly[iv];
        const float currDist = dist[iv];

        if (currDist < 0 && prevDist > 0)
        {
            const float absDist = -currDist;
            const float w = absDist / (absDist + prevDist);
            inside.push_back() = Lerp(currVert, prevVert, w);
            DebugAssert(n < MAX_OUTPUT_VERTICES);
            used[n++] = PLANE_FLAG | ip;
        }
        else if (currDist > 0 && prevDist < 0)
        {
            const float absDist = -prevDist;
            const float w = absDist / (absDist + currDist);
            inside.push_back() = Lerp(prevVert, currVert, w);
            DebugAssert(n < MAX_OUTPUT_VERTICES);
            used[n++] = usedEdges[iv];
        }

        if (currDist <= 0)
        {
            inside.push_back(currVert);
            DebugAssert(n < MAX_OUTPUT_VERTICES);
            if (prevDist > 0 && currDist == 0)
                used[n++] = PLANE_FLAG | ip;
            else
                used[n++] = usedEdges[iv];
        }

        prevVert = currVert;
        prevDist = currDist;
    }
    DebugAssert(n == inside.size());

    UNITY_MEMCPY(usedEdges, used, n);
}

// Return the intersection of 'inside' and 'carveHull'
// Assuming convex shapes.
void DynamicMesh::Intersection(Polygon& inside, const Hull& carveHull, Polygon& temp, unsigned char* usedEdges) const
{
    const size_t planeCount = carveHull.size();

    // Prime the edge references for the outer polygon
    for (size_t i = 0; i < inside.size(); ++i)
        usedEdges[i] = (unsigned char)(i);

    for (size_t ip = 0; ip < planeCount; ++ip)
    {
        const Plane& plane = carveHull[ip];
        int result = SplitPoly(temp, inside, plane, m_QuantFactor, usedEdges, ip);
        if (result == 0)
        {
            inside = temp;
        }
        else if (result == 1)
        {
            inside.resize_uninitialized(0);
            return;
        }
    }
}

void DynamicMesh::FromPoly(Polygon& result, const Poly& poly) const
{
    DebugAssert(poly.m_VertexCount > 2);
    DebugAssert(poly.m_VertexCount <= kNumVerts);

    const UInt32 vertexCount = poly.m_VertexCount;
    result.resize_uninitialized(vertexCount);

    for (size_t i = 0; i < vertexCount; ++i)
    {
        result[i] = GetVertex(poly.m_VertexIDs[i]);
    }
}

void DynamicMesh::BuildEdgeConnections(EdgeList& edges) const
{
    const size_t polyCount = m_Polygons.size();
    const size_t maxEdges = polyCount * kNumVerts;

    DebugAssert(edges.empty());
    edges.resize_uninitialized(maxEdges);
    size_t edgeCount = 0;

    dynamic_array<UInt16> buckets(m_Vertices.size(), 0xffff, kMemTempAlloc);
    dynamic_array<UInt16> next(maxEdges, 0xffff, kMemTempAlloc);

    // Add edges for polys when previous vertex index is less than current vertex index
    for (size_t ip = 0; ip < polyCount; ++ip)
    {
        const Poly& poly = m_Polygons[ip];
        const size_t vertexCount = poly.m_VertexCount;
        for (size_t ivp = vertexCount - 1, iv = 0; iv < vertexCount; ivp = iv++)
        {
            UInt16 vp = poly.m_VertexIDs[ivp];
            UInt16 v = poly.m_VertexIDs[iv];
            if (vp < v)
            {
                // add edge info for potential connection
                Edge& e = edges[edgeCount];
                e.v1 = (UInt16)vp;
                e.v2 = (UInt16)v;
                e.p1 = (UInt16)ip;
                e.p2 = 0xffff;
                e.c1 = (UInt16)ivp;
                e.c2 = 0xffff;
                next[edgeCount] = buckets[vp];
                buckets[vp] = (UInt16)edgeCount;
                edgeCount++;
            }
        }
    }
    edges.resize_uninitialized(edgeCount);

    // Look up matching edge when current vertex index is less than previous vertex index
    for (size_t ip = 0; ip < polyCount; ++ip)
    {
        const Poly& poly = m_Polygons[ip];
        const size_t vertexCount = poly.m_VertexCount;
        for (size_t ivp = vertexCount - 1, iv = 0; iv < vertexCount; ivp = iv++)
        {
            UInt16 vp = poly.m_VertexIDs[ivp];
            UInt16 v = poly.m_VertexIDs[iv];
            if (v < vp)
            {
                // add remaining edge info for connection
                for (UInt16 ie = buckets[v]; ie != 0xffff; ie = next[ie])
                {
                    if (edges[ie].v1 == v && edges[ie].v2 == vp)
                    {
                        edges[ie].p2 = (UInt16)ip;
                        edges[ie].c2 = (UInt16)ivp;
                        break;
                    }
                }
            }
        }
    }
}

// Subtracts the 'inner' poly from the 'outer' - the inner poly can be degenerate (eg. line or single point)
// these are handled to make clipping consistent to avoid creation of t-junctions.
void DynamicMesh::Subtract(PolygonContainer& result, const Polygon& outer, Polygon& inner, Polygon& tri, const unsigned char* usedEdges, const Hull& hull) const
{
    const size_t innerVertexCount = inner.size();
    const size_t outerVertexCount = outer.size();
    result.clear();
    tri.resize_uninitialized(3);

    dynamic_array<bool> used(outerVertexCount, false, kMemTempAlloc);
#if 1
    for (size_t i = 0; i < innerVertexCount; ++i)
    {
        if (PLANE_FLAG & usedEdges[i])
            continue;

        DebugAssert(usedEdges[i] < outerVertexCount);
        used[usedEdges[i]] = true;
    }
#endif

    if (innerVertexCount == 1)
    {
        DebugAssert(outerVertexCount > 0);
        for (size_t ov = 0; ov < outerVertexCount; ++ov)
        {
            if (used[ov])
                continue;

            const size_t ovn = NextIndex(ov, outerVertexCount);
            tri[0] = inner[0];
            tri[1] = outer[ov];
            tri[2] = outer[ovn];
            if (DegenerateTriangle(tri))
                continue;

            result.push_back(tri);
        }
        return;
    }

    dynamic_array<int> ol(innerVertexCount, -1, kMemTempAlloc);
    dynamic_array<int> oh(innerVertexCount, -1, kMemTempAlloc);

    for (size_t ivp = innerVertexCount - 1, iv = 0; iv < innerVertexCount; ivp = iv++)
    {
        if ((PLANE_FLAG & usedEdges[iv]) == 0)
            continue;
        const size_t ie = (size_t)(usedEdges[iv] & PLANE_INDEX_MASK);
        const Plane& plane = hull[ie];

        int bestOuter = FindFurthest(plane, outer, m_QuantFactor);
        if (bestOuter == -1)
            continue;

        ol[iv] = bestOuter;
        oh[ivp] = bestOuter;

        tri[0] = inner[iv];
        tri[1] = inner[ivp];
        tri[2] = outer[bestOuter];
        if (DegenerateTriangle(tri))
            continue;

        result.push_back(tri);
    }

    for (size_t iv = 0; iv < innerVertexCount; ++iv)
    {
        int ov;

        ov = ol[iv];
        if (ov != -1)
        {
            while (ov != oh[iv])
            {
                const size_t ovn = NextIndex(static_cast<size_t>(ov), outerVertexCount);
                if (used[ovn])
                    break;

                tri[0] = inner[iv];
                tri[1] = outer[ov];
                tri[2] = outer[ovn];
                if (DegenerateTriangle(tri))
                    break;

                result.push_back(tri);
                used[ovn] = true;
                ov = ovn;
            }
        }

        ov = oh[iv];
        if (ov != -1)
        {
            while (ov != ol[iv])
            {
                const size_t ovp = PrevIndex(static_cast<size_t>(ov), outerVertexCount);
                if (used[ov])
                    break;

                tri[0] = inner[iv];
                tri[1] = outer[ovp];
                tri[2] = outer[ov];
                if (DegenerateTriangle(tri))
                    break;

                result.push_back(tri);
                used[ov] = true;
                ov = ovp;
            }
        }
    }
}

bool DynamicMesh::MergePolygons(Polygon& merged, const Polygon& p1, const Polygon& p2) const
{
    merged.resize_uninitialized(0);
    const size_t count1 = p1.size();
    const size_t count2 = p2.size();

    if (count1 < 3)
        return false;
    if (count2 < 3)
        return false;
    if ((count1 + count2 - 2) > kNumVerts)
        return false;

    for (size_t iv = 0; iv < count1; ++iv)
    {
        const size_t ivn = NextIndex(iv, count1);
        const Vector3f& v1 = p1[iv];
        const Vector3f& v2 = p1[ivn];
        for (size_t jv = 0; jv < count2; ++jv)
        {
            const size_t jvn = NextIndex(jv, count2);
            const Vector3f& w1 = p2[jv];
            const Vector3f& w2 = p2[jvn];
            if ((v1 == w2) && (v2 == w1))
            {
                // Found shared edge

                // Test convexity
                const Vector3f& wn = p2[NextIndex(jvn, count2)];
                const Vector3f& vp = p1[PrevIndex(iv, count1)];
                if (TriArea2D(vp, v1, wn) <= 0)
                {
                    return false;
                }

                // Test convexity
                const Vector3f& wp = p2[PrevIndex(jv, count2)];
                const Vector3f& vn = p1[NextIndex(ivn, count1)];
                if (TriArea2D(v2, vn, wp) <= 0)
                {
                    return false;
                }

                // Merge two polygon parts
                for (size_t k = ivn; k != iv; k = NextIndex(k, count1))
                {
                    merged.push_back(p1[k]);
                }
                for (size_t k = jvn; k != jv; k = NextIndex(k, count2))
                {
                    merged.push_back(p2[k]);
                }
                DebugAssert(merged.size() == count1 + count2 - 2);
                return IsSafeConvex(merged);
            }
        }
    }
    return false;
}

// TODO - merge using connectivity
void DynamicMesh::MergePolygons()
{
    // Merge list of convex non-overlapping polygons assuming identical data.
    Polygon merged(kNumVerts, kMemTempAlloc);
    Polygon poly(kNumVerts, kMemTempAlloc);
    Polygon poly2(kNumVerts, kMemTempAlloc);

    for (size_t ip = 0; ip < m_Polygons.size(); ++ip)
    {
        FromPoly(poly, m_Polygons[ip]);
        for (size_t jp = m_Polygons.size() - 1; jp > ip; --jp)
        {
            bool dataConforms = (m_Data[ip] == m_Data[jp]);
            if (!dataConforms)
                continue;

            FromPoly(poly2, m_Polygons[jp]);
            if (MergePolygons(merged, poly, poly2))
            {
                poly = merged;
                // TODO : consider to remove unordered to avoid memmove here
                m_Polygons.erase(m_Polygons.begin() + jp);
            }
            if (poly.size() == kNumVerts)
                break;
        }
        m_Polygons[ip] = CreatePolygon(poly, kGeneratedPolygon);
    }
}

void DynamicMesh::MergePolygons(PolygonContainer& polys) const
{
    // Merge list of convex non-overlapping polygons assuming identical data.
    Polygon poly(kNumVerts, kMemTempAlloc);
    Polygon merged(kNumVerts, kMemTempAlloc);

    for (size_t ip = 0; ip < polys.size(); ++ip)
    {
        poly = polys[ip];
        for (size_t jp = polys.size() - 1; jp > ip; --jp)
        {
            if (MergePolygons(merged, poly, polys[jp]))
            {
                poly = merged;
                // TODO : consider to remove unordered to avoid memmove here
                polys.erase(polys.begin() + jp);
            }
        }
        polys[ip] = poly;
    }
}

void DynamicMesh::ConnectPolygons()
{
    EdgeList edges(kMemTempAlloc);
    BuildEdgeConnections(edges);

    size_t edgeCount = edges.size();
    for (size_t ie = 0; ie < edgeCount; ++ie)
    {
        const Edge& edge = edges[ie];
        if (edge.c2 == 0xffff)
            continue;
        m_Polygons[edge.p1].m_Neighbours[edge.c1] = edge.p2 + 1;
        m_Polygons[edge.p2].m_Neighbours[edge.c2] = edge.p1 + 1;
    }
}

void DynamicMesh::RemoveDegeneratePolygons()
{
    size_t count = m_Polygons.size();
    for (size_t ip = 0; ip < count; ++ip)
    {
        if (PolygonDegenerate(m_Polygons[ip].m_VertexCount, m_Polygons[ip].m_VertexIDs, &m_Vertices[0], m_QuantFactor))
        {
            CollapsePolygonUnordered(ip);
            --count;
            --ip;
        }
    }
}

void DynamicMesh::RemoveDegenerateEdges()
{
    size_t count = m_Polygons.size();
    for (size_t ip = 0; ip < count; ++ip)
    {
        Poly& poly = m_Polygons[ip];
        for (int i = 0; i < (int)poly.m_VertexCount; i++)
        {
            int j = i + 1 < (int)poly.m_VertexCount ? i + 1 : 0;
            if (poly.m_VertexIDs[i] == poly.m_VertexIDs[j])
            {
                // Shift rest of the polygon.
                for (int k = j; k < (int)poly.m_VertexCount - 1; k++)
                    poly.m_VertexIDs[k] = poly.m_VertexIDs[k + 1];
                poly.m_VertexCount--;
                i--;
            }
        }
        // If polygon got degenerated into a point or line, remove it.
        if (poly.m_VertexCount < 3)
        {
            RemovePolygonUnordered(ip);
            --count;
            --ip;
        }
    }
}

void DynamicMesh::RemoveUnusedVertices()
{
    dynamic_array<int> transVertices(m_Vertices.size(), -1, kMemTempAlloc);
    dynamic_array<Vector3f> newVertices(kMemTempAlloc);
    newVertices.reserve(m_Vertices.size());

    const size_t count = m_Polygons.size();
    for (size_t ip = 0; ip < count; ++ip)
    {
        for (UInt8 iv = 0; iv < m_Polygons[ip].m_VertexCount; ++iv)
        {
            UInt16 oldVertexID = m_Polygons[ip].m_VertexIDs[iv];
            if (transVertices[oldVertexID] == -1)
            {
                transVertices[oldVertexID] = newVertices.size();
                m_Polygons[ip].m_VertexIDs[iv] = (UInt16)newVertices.size();
                newVertices.push_back(m_Vertices[oldVertexID]);
            }
            else
            {
                m_Polygons[ip].m_VertexIDs[iv] = (UInt16)transVertices[oldVertexID];
            }
        }
    }
    m_Vertices = newVertices;

    // NOTE: m_Welder is now out of sync with m_Vertices.
    // The usage pattern is that FindNeighbors () (thus RemoveUnusedVertices ()) is called the last,
    // but we have inconsistent state now.
}

void DynamicMesh::FindNeighbors()
{
    PROFILER_AUTO(gDynamicMeshFindNeighbors, NULL)

    // Remove degenerate polygons by collapsing them into segments.
    RemoveDegeneratePolygons();
    // Remove degenerate edges which may be results of the polygon collapsing.
    RemoveDegenerateEdges();
    RemoveUnusedVertices();
    ConnectPolygons();
}

void DynamicMesh::AddPolygon(const Polygon& vertices, const DataType& data)
{
    AddPolygon(vertices, data, kOriginalPolygon);
}

void DynamicMesh::AddPolygon(const Polygon& vertices, const DataType& data, const UInt32 status)
{
    // Delaying neighbor connections.
    DebugAssert(m_Polygons.size() < 0xffff);   //< poly overflow
    DebugAssert(vertices.size() <= kNumVerts);
    DebugAssert(m_Data.size() == m_Polygons.size());

    Poly newPoly = CreatePolygon(vertices, status);
    m_Polygons.push_back(newPoly);
    m_Data.push_back(data);
}

bool DynamicMesh::ClipPolys(const HullContainer& carveHulls)
{
    PROFILER_AUTO(gDynamicMeshClipPolys, NULL)

    const size_t hullCount = carveHulls.size();
    bool clipped = false;

    PolygonContainer outsidePolygons;
    outsidePolygons.reserve(2 * kNumVerts);

    Polygon currentPoly(kMemTempAlloc);
    Polygon inside(kMemTempAlloc);
    Polygon temp(kMemTempAlloc);
    currentPoly.reserve(kNumVerts);
    inside.reserve(MAX_OUTPUT_VERTICES);
    temp.reserve(MAX_OUTPUT_VERTICES);
    // usedEdges describe to which plane or outer edge is this edge colinear
    unsigned char usedEdges[MAX_OUTPUT_VERTICES];

    for (size_t ih = 0; ih < hullCount; ++ih)
    {
        const Hull& carveHull = carveHulls[ih];

        size_t count = m_Polygons.size();
        size_t first = 0;
        for (size_t ip = 0; ip < count; ++ip)
        {
            FromPoly(inside, m_Polygons[ip]);
            Intersection(inside, carveHull, temp, usedEdges);
            if (inside.empty())
                continue;

            clipped = true;
            DataType currentData = m_Data[ip];
            FromPoly(currentPoly, m_Polygons[ip]);
            Subtract(outsidePolygons, currentPoly, inside, temp, usedEdges, carveHull);
            MergePolygons(outsidePolygons);

            if (ip != first)
            {
                m_Polygons[ip] = m_Polygons[first];
                m_Data[ip] = m_Data[first];
            }
            first++;

            for (size_t io = 0; io < outsidePolygons.size(); ++io)
            {
                AddPolygon(outsidePolygons[io], currentData, kGeneratedPolygon);
            }
        }
        if (first != 0)
        {
            m_Polygons.erase(m_Polygons.begin(), m_Polygons.begin() + first);
            m_Data.erase(m_Data.begin(), m_Data.begin() + first);
        }
    }

    return clipped;
}

bool DynamicMesh::ClipPolys(const DetailHullContainer& carveHulls)
{
    PROFILER_AUTO(gDynamicMeshClipPolys, NULL)

    const size_t hullCount = carveHulls.size();
    bool clipped = false;

    PolygonContainer outsidePolygons;
    outsidePolygons.reserve(2 * kNumVerts);

    Polygon currentPoly(kMemTempAlloc);
    Polygon inside(kMemTempAlloc);
    Polygon temp(kMemTempAlloc);
    currentPoly.reserve(kNumVerts);
    inside.reserve(MAX_OUTPUT_VERTICES);
    temp.reserve(MAX_OUTPUT_VERTICES);
    // usedEdges describe to which plane or outer edge is this edge colinear
    unsigned char usedEdges[MAX_OUTPUT_VERTICES];

    for (size_t ih = 0; ih < hullCount; ++ih)
    {
        const DetailHull& carveHull = carveHulls[ih];

        size_t count = m_Polygons.size();
        size_t first = 0;
        for (size_t ip = 0; ip < count; ++ip)
        {
            DataType currentData = m_Data[ip];
            // If the polygon does not belong to the carve hull, skip.
            bool found = false;
            for (size_t i = 0, ni = carveHull.polysIds.size(); i < ni; i++)
            {
                if (carveHull.polysIds[i] == currentData)
                {
                    found = true;
                    break;
                }
            }
            if (!found)
                continue;

            FromPoly(inside, m_Polygons[ip]);
            Intersection(inside, carveHull.hull, temp, usedEdges);
            if (inside.empty())
                continue;

            clipped = true;
            FromPoly(currentPoly, m_Polygons[ip]);
            Subtract(outsidePolygons, currentPoly, inside, temp, usedEdges, carveHull.hull);
            MergePolygons(outsidePolygons);

            if (ip != first)
            {
                m_Polygons[ip] = m_Polygons[first];
                m_Data[ip] = m_Data[first];
            }
            first++;

            for (size_t io = 0; io < outsidePolygons.size(); ++io)
            {
                AddPolygon(outsidePolygons[io], currentData, kGeneratedPolygon);
            }
        }
        if (first != 0)
        {
            m_Polygons.erase(m_Polygons.begin(), m_Polygons.begin() + first);
            m_Data.erase(m_Data.begin(), m_Data.begin() + first);
        }
    }

    return clipped;
}

void DynamicMesh::Reserve(const int vertexCount, const int polygonCount)
{
    m_Polygons.reserve(polygonCount);
    m_Data.reserve(polygonCount);
    m_Vertices.reserve(vertexCount);
}

void DynamicMesh::AddVertex(const Vector3f& v)
{
    m_Welder.Push(v);
}

void DynamicMesh::AddPolygon(const UInt16* vertexIDs, const DataType& data, size_t vertexCount)
{
    // Ensure neighbour ids are zero'ed
    Poly poly = {{0}, {0}, 0, 0};

    poly.m_Status = kOriginalPolygon;
    poly.m_VertexCount = vertexCount;
    for (size_t iv = 0; iv < vertexCount; ++iv)
    {
        poly.m_VertexIDs[iv] = vertexIDs[iv];
    }
    m_Polygons.push_back(poly);
    m_Data.push_back(data);
}
