#pragma once
#include "HeightMesh/HeightMeshQuery.h"
#include "NavMeshBuildSettings.h"
#include "Runtime/Geometry/AABB.h"
#include "Runtime/Math/Quaternion.h"
#include "Runtime/Utilities/Hash128.h"
#include "Runtime/Utilities/dynamic_array.h"

// OffMeshLinkData is a scripting API type.
struct AutoOffMeshLinkData
{
    DECLARE_SERIALIZE(AutoOffMeshLinkData)
    Vector3f m_Start;
    Vector3f m_End;
    float m_Radius;
    unsigned short m_LinkType;      // Off-mesh poly flags.
    unsigned char m_Area;           // Off-mesh poly  area ids.
    unsigned char m_LinkDirection;  // Off-mesh connection direction flags (NavMeshLinkDirectionFlags)
};

template<class TransferFunction>
void AutoOffMeshLinkData::Transfer(TransferFunction& transfer)
{
    TRANSFER(m_Start);
    TRANSFER(m_End);
    TRANSFER(m_Radius);
    TRANSFER(m_LinkType);
    TRANSFER(m_Area);
    TRANSFER(m_LinkDirection);
}

typedef UNITY_VECTOR (kMemAI, AutoOffMeshLinkData) OffMeshLinkDataVector;

struct NavMeshTileData
{
    DECLARE_SERIALIZE(NavMeshTileData)
    dynamic_array<UInt8> m_MeshData;
    Hash128 m_Hash;
};

typedef UNITY_VECTOR (kMemAI, NavMeshTileData) NavMeshTileDataVector;
class BufferedDebugDraw;

class NavMeshData : public NamedObject
{
    REGISTER_CLASS(NavMeshData);
    DECLARE_OBJECT_SERIALIZE();
public:
    NavMeshData(MemLabelId label, ObjectCreationMode mode);
    // ~NavMeshData - declared by macro

    virtual void AwakeFromLoad(AwakeFromLoadMode mode);
    virtual void MainThreadCleanup();

    static void InitializeClass();
    static void CleanupClass();

    inline const NavMeshTileDataVector& GetNavMeshTiles() const;
    inline void SetNavMeshTiles(const NavMeshTileDataVector& tiles);
    // Updates NavMeshData vector, removes tiles, compacts and adds new tiles.
    //   removeTileIDs - indices tiles to remove (current tile vector)
    //   newTiles - new tiles to add, ownership is transferred to this and array is cleared
    //   newTileIDs - IDs of the newly added tiles (new tile vector)
    void UpdateTiles(const dynamic_array<int>& removeTileIDs, NavMeshTileDataVector& newTiles, dynamic_array<int>& newTileIDs);

    inline const OffMeshLinkDataVector& GetOffMeshLinks() const;
    inline void SetOffMeshLinks(const OffMeshLinkDataVector& links);

    inline const NavMeshBuildSettings& GetNavMeshBuildSettings() const  { return m_NavMeshBuildSettings; }
    inline void SetNavMeshBuildSettings(const NavMeshBuildSettings& settings) { m_NavMeshBuildSettings = settings; }

    inline const HeightmapDataVector& GetHeightmaps() const;
    inline void SetHeightmaps(HeightmapDataVector& heightmaps);

    inline const HeightMeshDataVector& GetHeightMeshes() const;
    inline void SetHeightMeshes(const HeightMeshDataVector& meshes);

    inline int GetAgentTypeID() const { return m_AgentTypeID; }
    inline void SetAgentTypeID(int agentTypeID) { m_AgentTypeID = agentTypeID; }

    inline void SetSourceBounds(const AABB& bounds) { m_SourceBounds = bounds; }
    inline const AABB& GetSourceBounds() const { return m_SourceBounds; }

    inline void SetPosition(const Vector3f& position) { m_Position = position; }
    inline Vector3f GetPosition() const { return m_Position; }

    inline Quaternionf GetRotation() const { return m_Rotation; }
    inline void SetRotation(const Quaternionf& rotation) { m_Rotation = rotation; }

#if UNITY_EDITOR
    const BufferedDebugDraw* GetBuildDebugVisualization() const;
    void AddBuildDebugVisualization(const BufferedDebugDraw* vis);
    void ClearBuildDebugVisualization();
#endif

private:
    NavMeshBuildSettings m_NavMeshBuildSettings;
    NavMeshTileDataVector m_NavMeshTiles;
    HeightmapDataVector m_Heightmaps;
    HeightMeshDataVector m_HeightMeshes;
    OffMeshLinkDataVector m_OffMeshLinks;

    AABB m_SourceBounds;
    Quaternionf m_Rotation;
    Vector3f m_Position;
    int m_AgentTypeID;
    BufferedDebugDraw* m_BuildDebugVis; // Not serialized
};

inline const NavMeshTileDataVector& NavMeshData::GetNavMeshTiles() const
{
    return m_NavMeshTiles;
}

inline void NavMeshData::SetNavMeshTiles(const NavMeshTileDataVector& tiles)
{
    m_NavMeshTiles = tiles;
}

const OffMeshLinkDataVector& NavMeshData::GetOffMeshLinks() const
{
    return m_OffMeshLinks;
}

void NavMeshData::SetOffMeshLinks(const OffMeshLinkDataVector& links)
{
    m_OffMeshLinks = links;
}

inline const HeightmapDataVector& NavMeshData::GetHeightmaps() const
{
    return m_Heightmaps;
}

inline void NavMeshData::SetHeightmaps(HeightmapDataVector& heightmaps)
{
    m_Heightmaps = heightmaps;
}

inline const HeightMeshDataVector& NavMeshData::GetHeightMeshes() const
{
    return m_HeightMeshes;
}

inline void NavMeshData::SetHeightMeshes(const HeightMeshDataVector& meshes)
{
    m_HeightMeshes = meshes;
}
