#pragma once

// This helper class is used to detect if a PPtr<NavMesh> is being stored on 4.x scenes.
class NavMeshObsolete : public NamedObject
{
    REGISTER_CLASS(NavMeshObsolete);
    DECLARE_OBJECT_SERIALIZE();
public:

    NavMeshObsolete(MemLabelId& label, ObjectCreationMode mode)
        : Super(label, mode) {}

    virtual void MainThreadCleanup();
};

void NavMeshObsolete::ThreadedCleanup() {}

void NavMeshObsolete::MainThreadCleanup()
{
    Super::MainThreadCleanup();
}

template<class TransferFunction>
void NavMeshObsolete::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);
}

IMPLEMENT_REGISTER_CLASS(NavMeshObsolete, 194);
IMPLEMENT_OBJECT_SERIALIZE(NavMeshObsolete);
