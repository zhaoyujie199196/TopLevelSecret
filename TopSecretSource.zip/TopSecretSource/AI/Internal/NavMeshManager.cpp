#include "UnityPrefix.h"
#include "NavMeshManager.h"

#include "Crowd/CrowdManager.h"
#include "Crowd/CrowdTypes.h"
#include "NavMesh/NavMesh.h"
#include "NavMesh/NavMeshQuery.h"
#include "HeightMesh/HeightMeshQuery.h"
#include "Runtime/Input/TimeManager.h"
#include "Components/NavMeshAgent.h"
#include "Components/NavMeshObstacle.h"
#include "Components/OffMeshLink.h"
#include "Obstacles/NavMeshCarving.h"
#include "NavMeshData.h"
#include "NavMeshPath.h"
#include "NavMeshBindingTypes.h"
#include "NavMeshProjectSettings.h"
#include "Runtime/BaseClasses/IsPlaying.h"
#include "Runtime/Core/Callbacks/PlayerLoopCallbacks.h"
#include "Runtime/Misc/BuildSettings.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/SceneManager/UnityScene.h"
#include "NavMeshSceneDataRegistry.h"
#include "Runtime/BaseClasses/MessageHandler.h"
#include "Runtime/Jobs/Jobs.h"
#include "Runtime/Scripting/ScriptingInvocation.h"
#include "AIScriptingClasses.h"

#if ENABLE_RUNTIME_NAVMESH_BUILDING
#include "Builder/NavMeshBuildManager.h"
#endif

static const int kNodePoolSize = 4096;
static const int kInitialAgentCount = 4;

static const int kPathfindingIterationsPerFrame = 100;
static const float kAvoidancePredictionTime = 2.0f;

static const int kLinkHandleSaltBits = 16;
static const int kLinkHandleSaltMask = (1 << kLinkHandleSaltBits) - 1;

static Vector3f s_LegacyQueryExtents;
static Vector3f s_LegacyLinkQueryExtents;

PROFILER_INFORMATION(gNavMeshManager, "NavMeshManager", kProfilerAI)
PROFILER_INFORMATION(gNavMeshAgentsUpdateState, "Components.NavMeshAgent.State", kProfilerAI)
PROFILER_INFORMATION(gNavMeshAgentsUpdateTransform, "Components.NavMeshAgent.Transform", kProfilerAI)
PROFILER_INFORMATION(gNavMeshObstaclesUpdateTransform, "Components.NavMeshObstacle.Transform", kProfilerAI)
PROFILER_INFORMATION(gNavMeshOffMeshLinks, "Components.OffMeshLink.Position", kProfilerAI)
PROFILER_INFORMATION(gNavMeshAgentsUpdateTransformChangedMessage, "Components.NavMeshAgent.TransformChangedMessage", kProfilerAI)
PROFILER_INFORMATION(gNavMeshLoadData, "NavMeshManager.LoadData", kProfilerAI)
PROFILER_INFORMATION(gNavMeshUnloadData, "NavMeshManager.UnloadData", kProfilerAI)

// m_CrowdSystem depends on m_NavMesh and m_Agents
//   . m_NavMesh tiles change -> try adding unbound agents.
//   . m_NavMesh tiles change -> try adding unbound links.
// m_CarvingSystem depends on m_NavMesh and m_ObstacleInfo
// m_NavMeshQuery depends on m_NavMesh
// m_HeightMeshQuery depends on m_NavMesh

struct AgentLinkState
{
    int agentIndex;
    unsigned int tileIndex;
    int instanceID;
};

// Extract information from occupied offmeshlinks
// in order to update the stored poly ref. to be valid for new tile
static void ExtractAgentLinkStates(const dynamic_array<NavMeshAgent*>& agents, dynamic_array<AgentLinkState>& states)
{
    DebugAssert(states.empty());   // Assume empty array passed
    const NavMesh* navmesh = GetNavMeshManager().GetInternalNavMesh();

    for (int i = 0; i < agents.size(); ++i)
    {
        const NavMeshPolyRef linkRef = agents[i]->GetInternalAnimationPolyRef();
        if (linkRef == (NavMeshPolyRef)0)
            continue;

        // Store state of off-mesh link components.
        int instanceID = 0;
        navmesh->GetOffMeshConnectionUserID(linkRef, &instanceID);
        if (instanceID != 0)
        {
            AgentLinkState& state = states.push_back();
            state.agentIndex = i;
            state.tileIndex = navmesh->DecodePolyIdTile(linkRef);
            state.instanceID = instanceID;
        }
    }
}

// Based on the stored offmeshlink state
// update the stored poly ref. in the agent animation states
static void UpdateAgentLinkStates(const dynamic_array<AgentLinkState>& states, dynamic_array<NavMeshAgent*>& agents)
{
    for (int i = 0; i < states.size(); ++i)
    {
        OffMeshLink* offmeshLink = dynamic_instanceID_cast<OffMeshLink*>(states[i].instanceID);
        // Restore state of off-mesh link components.
        if (offmeshLink)
        {
            NavMeshPolyRef linkRef = offmeshLink->GetConnectionPolyRef();
            if (linkRef != 0)
            {
                NavMeshAgent* agent = agents[states[i].agentIndex];
                agent->SetInternalAnimationPolyRef(linkRef);
            }
        }
    }
}

template<typename T>
static inline int RegisterInArray(dynamic_array<T*>& array, T& element)
{
    int handle = array.size();
    array.push_back(&element);
    return handle;
}

template<typename T>
static inline void UnregisterFromArray(dynamic_array<T*>& array, int handle)
{
    Assert(handle >= 0 && handle < array.size());
    int last = array.size() - 1;
    if (handle != last)
    {
        T* swap = array[last];
        array[handle] = swap;
        swap->SetManagerHandle(handle);
    }
    array.pop_back();
}

static void InvalidateNavMeshHit(NavMeshHit* hit)
{
    const float inf = std::numeric_limits<float>::infinity();
    hit->position = Vector3f(inf, inf, inf);
    hit->normal.SetZero();
    hit->distance = inf;
    hit->mask = 0;
    hit->hit = false;
}

NavMeshManager::NavMeshManager()
{
    m_NavMesh = NULL;
    m_NavMeshQuery = NULL;
    m_HeightMeshQuery = NULL;
    m_CarvingSystem = NULL;
    m_CrowdSystem = NULL;

    m_AvoidancePredictionTime = kAvoidancePredictionTime;
    m_PathfindingIterationsPerFrame = kPathfindingIterationsPerFrame;
    m_LegacyQueryExtents = Vector3f(0.5f, 2.0f, 0.5f);
    m_LegacyLinkQueryExtents = Vector3f(0.5f, 0.4f, 0.5f);


#if ENABLE_RUNTIME_NAVMESH_BUILDING
    m_BuildManager = UNITY_NEW(NavMeshBuildManager, kMemAI);
#else
    m_BuildManager = NULL;
#endif

#if UNITY_EDITOR
    m_CrowdAgentDebugRequestCount = 0;
    m_CrowdAgentDebugInfos = (CrowdAgentDebugInfo*)UNITY_MALLOC(kMemAI, kDebugAgentCount * sizeof(CrowdAgentDebugInfo));
    memset(m_CrowdAgentDebugInfos, 0, kDebugAgentCount * sizeof(CrowdAgentDebugInfo));
    for (int i = 0; i < kDebugAgentCount; i++)
        m_CrowdAgentDebugInfos[i].agentRef = 0;
#endif

    m_SceneDataRegistry = UNITY_NEW(NavMeshSceneDataRegistry, kMemAI);
}

NavMeshManager::~NavMeshManager()
{
    Cleanup();

#if ENABLE_RUNTIME_NAVMESH_BUILDING
    UNITY_DELETE(m_BuildManager, kMemAI);
#endif
    UNITY_DELETE(m_CrowdSystem, kMemAI);
    UNITY_DELETE(m_CarvingSystem, kMemAI);
#if UNITY_EDITOR
    UNITY_FREE(kMemAI, m_CrowdAgentDebugInfos);
#endif

    UNITY_DELETE(m_SceneDataRegistry, kMemAI);
}

// Instantiates the navmesh data at it's original position
// Returns the navmesh surface instace ID - or zero if the data could not be loaded
// The navmesh system will be initialized before attempting to load the navmesh data
// If no navmesh data is loaded the navmesh system will be de-initialized
int NavMeshManager::LoadData(const NavMeshData* navMeshData)
{
    Assert(navMeshData);

    return LoadData(navMeshData, navMeshData->GetPosition(), navMeshData->GetRotation());
}

int NavMeshManager::LoadData(const NavMeshData* navMeshData, const Vector3f& position, const Quaternionf& rotation)
{
    Assert(navMeshData);

#if DEBUGMODE
    if (!IsFinite(position))
    {
        ErrorStringMsg("Invalid position for navmesh data { %s, %s, %s }"
            , FloatToString(position.x).c_str(), FloatToString(position.y).c_str(), FloatToString(position.z).c_str());
        return 0;
    }
    if (!IsFinite(rotation))
    {
        ErrorStringMsg("Invalid rotation for navmesh data { %s, %s, %s, %s }"
            , FloatToString(rotation.x).c_str(), FloatToString(rotation.y).c_str()
            , FloatToString(rotation.z).c_str(), FloatToString(rotation.w).c_str());
        return 0;
    }
#endif

    if (!m_NavMesh)
    {
        InitializeNavMeshSystems();
        if (!m_NavMesh)
            return 0;
    }

    int surfaceID = LoadDataInternal(navMeshData, position, rotation);

    if (surfaceID != 0)
    {
        Assert(!m_LoadedSurfaces.empty());

        UpdateCarvingImmediately(surfaceID);
        NotifyNavMeshAdded();
    }
    else
    {
        CleanupIfNoData();
    }
    return surfaceID;
}

void NavMeshManager::UpdateCarvingImmediately(int surfaceID)
{
    if (!m_CarvingSystem)
        return;

    m_CarvingSystem->ApplyCarveResults();
    UpdateNavMeshObstacles();
    m_CarvingSystem->SetSurfaceDirty(surfaceID);
    m_CarvingSystem->PrepareCarving();
    m_CarvingSystem->Carve();
    m_CarvingSystem->ApplyCarveResults();
}

void NavMeshManager::GetSourceTileDataBounds(dynamic_array<TileLocation>& locations) const
{
    const NavMeshSurfaceInstanceMap::const_iterator end = m_LoadedSurfaces.end();
    NavMeshSurfaceInstanceMap::const_iterator it;

    size_t totalTileCount = 0;
    for (it = m_LoadedSurfaces.begin(); it != end; ++it)
    {
        const NavMeshData* navMeshData = it->second.m_NavMeshData;
        const NavMeshTileDataVector& tiles = navMeshData->GetNavMeshTiles();
        totalTileCount += tiles.size();
    }
    locations.reserve(totalTileCount);

    for (it = m_LoadedSurfaces.begin(); it != end; ++it)
    {
        const int surfaceID = it->first;
        Assert(surfaceID != 0);
        const NavMeshData* navMeshData = it->second.m_NavMeshData;
        const NavMeshTileDataVector& tiles = navMeshData->GetNavMeshTiles();
        for (int i = 0; i < tiles.size(); ++i)
        {
            const NavMeshDataHeader* header = reinterpret_cast<const NavMeshDataHeader*>(tiles[i].m_MeshData.begin());
            TileLocation& loc = locations.push_back();
            loc.m_Bounds = MinMaxAABB(Vector3f(header->bmin), Vector3f(header->bmax));
            loc.m_SurfaceID = surfaceID;
            loc.m_TileIndex = i;
        }
    }
}

const NavMeshTileData* NavMeshManager::GetSourceTileData(int surfaceID, int tileIndex) const
{
    NavMeshSurfaceInstanceMap::const_iterator found = m_LoadedSurfaces.find(surfaceID);
    if (found == m_LoadedSurfaces.end())
        return NULL;

    const SurfaceInstance& instance = found->second;
    const NavMeshData* navMeshData = instance.m_NavMeshData;
    const NavMeshTileDataVector& tiles = navMeshData->GetNavMeshTiles();
    return &tiles[tileIndex];
}

const NavMeshBuildSettings& NavMeshManager::GetNavMeshBuildSettings(int surfaceID) const
{
    NavMeshSurfaceInstanceMap::const_iterator found = m_LoadedSurfaces.find(surfaceID);
    AssertFormatMsg(found != m_LoadedSurfaces.end(), "The navmesh surface with ID: %d wasn't found", surfaceID);

    const SurfaceInstance& instance = found->second;
    const NavMeshData* navMeshData = instance.m_NavMeshData;
    return navMeshData->GetNavMeshBuildSettings();
}

void NavMeshManager::RemoveTile(int surfaceID, int tileIndex)
{
    Assert(m_NavMesh);
    NavMeshSurfaceInstanceMap::iterator found = m_LoadedSurfaces.find(surfaceID);
    if (found == m_LoadedSurfaces.end())
        return;

    SurfaceInstance& instance = found->second;
    const NavMeshTileRef ref = instance.m_AddedTileRefs[tileIndex];
    m_NavMesh->RemoveTile(ref, surfaceID, NULL, NULL);
    instance.m_AddedTileRefs[tileIndex] = 0;
}

void NavMeshManager::RestoreTile(int surfaceID, int tileIndex)
{
    Assert(m_NavMesh);
    NavMeshSurfaceInstanceMap::iterator found = m_LoadedSurfaces.find(surfaceID);
    if (found == m_LoadedSurfaces.end())
        return;

    SurfaceInstance& instance = found->second;
    const NavMeshData* navMeshData = instance.m_NavMeshData;
    const NavMeshTileDataVector& tiles = navMeshData->GetNavMeshTiles();
    const NavMeshTileData* tileData = &tiles[tileIndex];
    const unsigned char* byteData = tileData->m_MeshData.begin();
    const int dataSize = tileData->m_MeshData.size();

    const NavMeshTileRef ref = instance.m_AddedTileRefs[tileIndex];
    if (ref)
    {
        const NavMeshTile* tile = m_NavMesh->GetTileByRef(ref);
        if (tile->data == byteData)
            return;

        m_NavMesh->RemoveTile(ref, surfaceID, NULL, NULL);
        instance.m_AddedTileRefs[tileIndex] = 0;
    }

    NavMeshTileRef addRef = 0;
    m_NavMesh->AddTile(byteData, dataSize, kTileLeakData, surfaceID, &addRef);
    instance.m_AddedTileRefs[tileIndex] = addRef;

    if (addRef)
        NotifyNavMeshAdded();
}

void NavMeshManager::RemoveTiles(int surfaceID, const dynamic_array<int>& tileIndices)
{
    NavMeshSurfaceInstanceMap::iterator found = m_LoadedSurfaces.find(surfaceID);
    if (found == m_LoadedSurfaces.end())
        return;

    SurfaceInstance& instance = found->second;
    for (int i = 0; i < tileIndices.size(); i++)
    {
        const int tileIndex = tileIndices[i];
        const NavMeshTileRef ref = instance.m_AddedTileRefs[tileIndex];
        m_NavMesh->RemoveTile(ref, surfaceID, NULL, NULL);
        instance.m_AddedTileRefs[tileIndex] = 0;
    }
}

void NavMeshManager::UpdateSurface(int surfaceID, const NavMeshBuildSettings& settings,
    const dynamic_array<int>& tileIndices)
{
    Assert(m_NavMesh);
    NavMeshSurfaceInstanceMap::iterator found = m_LoadedSurfaces.find(surfaceID);
    if (found == m_LoadedSurfaces.end())
        return;

    if (m_CarvingSystem)
    {
        m_CarvingSystem->ApplyCarveResults();
    }

    SurfaceInstance& instance = found->second;
    const NavMeshData* navMeshData = instance.m_NavMeshData;

    SyncTileIndicesFromNavMeshData(instance, surfaceID);

    const NavMeshTileDataVector& tiles = navMeshData->GetNavMeshTiles();
    for (int i = 0; i < tileIndices.size(); i++)
    {
        const int tileIndex = tileIndices[i];
        const NavMeshTileData* tileData = &tiles[tileIndex];
        const unsigned char* byteData = tileData->m_MeshData.begin();
        const int dataSize = tileData->m_MeshData.size();

        const NavMeshTileRef ref = instance.m_AddedTileRefs[tileIndex];
        if (ref)
        {
            const NavMeshTile* tile = m_NavMesh->GetTileByRef(ref);
            if (tile->data == byteData)
                continue;
            m_NavMesh->RemoveTile(ref, surfaceID, NULL, NULL);
            instance.m_AddedTileRefs[tileIndex] = 0;
        }

        if (byteData && dataSize)
        {
            NavMeshTileRef addRef = 0;
            m_NavMesh->AddTile(byteData, dataSize, kTileLeakData, surfaceID, &addRef);
            instance.m_AddedTileRefs[tileIndex] = addRef;
        }
    }

    m_NavMesh->SetSurfaceSettings(surfaceID, settings);

    UpdateCarvingImmediately(surfaceID);

    NotifyNavMeshAdded();
}

// Reorders the loaded tile references to match the order of the NavMeshData
// The tile references will not change.
void NavMeshManager::SyncTileIndicesFromNavMeshData(SurfaceInstance& instance, int surfaceID)
{
    const NavMeshData* navMeshData = instance.m_NavMeshData;
    const NavMeshTileDataVector& tiles = navMeshData->GetNavMeshTiles();

    dynamic_array<NavMeshTileRef> oldAddedTileRefs(kMemTempAlloc);
    oldAddedTileRefs = instance.m_AddedTileRefs;

    instance.m_AddedTileRefs.resize_uninitialized(tiles.size());
    for (int i = 0; i < tiles.size(); i++)
    {
        const NavMeshTileData* currentTileData = &tiles[i];
        const unsigned char* currentByteData = currentTileData->m_MeshData.begin();
        const int currentDataSize = currentTileData->m_MeshData.size();
        // Try to find the data ptr from the current NavMeshData in NavMesh.
        NavMeshTileRef ref = 0;
        for (int j = 0; j < oldAddedTileRefs.size(); j++)
        {
            const NavMeshTile* tile = m_NavMesh->GetTileByRef(oldAddedTileRefs[j]);
            if (tile != NULL && tile->data == currentByteData)
            {
                Assert(tile->dataSize == currentDataSize);
                ref = oldAddedTileRefs[j];
                oldAddedTileRefs[j] = 0; // Clear the ref so that we can later check for orphans.
                break;
            }
        }
        instance.m_AddedTileRefs[i] = ref;
    }

    // Check that we have mapped all the old refs. Unload remaining tiles
    for (int i = 0; i < oldAddedTileRefs.size(); i++)
    {
        if (oldAddedTileRefs[i] != 0)
        {
            // If a tile was not it must've been changed.
            m_NavMesh->RemoveTile(oldAddedTileRefs[i], surfaceID, NULL, NULL);
        }
    }
}

void NavMeshManager::MergeNavMeshScenes(UnityScene* src, UnityScene* dst)
{
    UnitySceneHandle srcHandle = src->GetHandle();
    UnitySceneHandle dstHandle = dst->GetHandle();

    m_SceneDataRegistry->ChangeSceneOwner(srcHandle, dstHandle);
}

void NavMeshManager::ReplaceTile(int surfaceID, int tileIndex, unsigned char* tileData, int tileDataSize)
{
    Assert(m_NavMesh);

    NavMeshSurfaceInstanceMap::iterator found = m_LoadedSurfaces.find(surfaceID);

    Assert(found != m_LoadedSurfaces.end());   //< assumes the surface exists
    Assert(found->second.m_AddedTileRefs[tileIndex] == 0);  //< assumes tile in this place was first removed

    NavMeshTileRef ref = 0;
    NavMeshStatus status = m_NavMesh->AddTile(tileData, tileDataSize, kTileFreeData, surfaceID, &ref);
    if (NavMeshStatusFailed(status))
    {
        UNITY_FREE(kMemAI, (void*)tileData);
    }

    found->second.m_AddedTileRefs[tileIndex] = ref;
    if (ref)
        NotifyNavMeshAdded();
}

bool NavMeshManager::IsValidSurfaceID(int surfaceID) const
{
    return m_LoadedSurfaces.find(surfaceID) != m_LoadedSurfaces.end();
}

bool NavMeshManager::SetSurfaceUserID(int surfaceID, int userID)
{
    NavMeshSurfaceInstanceMap::iterator found = m_LoadedSurfaces.find(surfaceID);
    if (found == m_LoadedSurfaces.end())
        return false;

    SurfaceInstance& instance = found->second;
    instance.m_UserID = userID;

    for (size_t i = 0; i < instance.m_AutoOffMeshConnections.size(); ++i)
        m_NavMesh->SetOffMeshConnectionUserID(instance.m_AutoOffMeshConnections[i], userID);

    return true;
}

int NavMeshManager::GetSurfaceUserID(int surfaceID) const
{
    NavMeshSurfaceInstanceMap::const_iterator found = m_LoadedSurfaces.find(surfaceID);
    if (found == m_LoadedSurfaces.end())
        return 0;

    const SurfaceInstance& instance = found->second;
    return instance.m_UserID;
}

void NavMeshManager::LoadNavMeshData(const UnitySceneHandle sceneID, const NavMeshData* navMeshData)
{
    if (!navMeshData)
        return;

    // Several scenes can point to the same navmesh - we don't load subsequently - but increase ref count.
    int surfaceID = m_SceneDataRegistry->GetSurfaceID(navMeshData);
    if (surfaceID == 0)
        surfaceID = LoadData(navMeshData);

    m_SceneDataRegistry->Add(navMeshData, surfaceID, sceneID);
}

void NavMeshManager::UnloadNavMeshData(const UnitySceneHandle sceneID)
{
    const int surfaceID = m_SceneDataRegistry->GetSurfaceID(sceneID);
    m_SceneDataRegistry->RemoveOneScene(sceneID);

    // When removing the last scene referring to surfaceID - unload that surface
    if (!m_SceneDataRegistry->Contains(surfaceID))
        UnloadData(surfaceID);
}

void NavMeshManager::UnloadData(int surfaceID)
{
    PROFILER_AUTO(gNavMeshUnloadData, NULL)

    if (m_CarvingSystem)
        m_CarvingSystem->ApplyCarveResults();

    NavMeshSurfaceInstanceMap::iterator found = m_LoadedSurfaces.find(surfaceID);
    if (found == m_LoadedSurfaces.end())
        return;

    const SurfaceInstance& instance = found->second;

    // Remove added data from height data.
    m_HeightMeshQuery->RemoveHeightData(surfaceID);

    // Remove added tiles from navmesh
    for (int i = 0; i < instance.m_AddedTileRefs.size(); ++i)
    {
        m_NavMesh->RemoveTile(instance.m_AddedTileRefs[i], surfaceID, NULL, NULL);
    }

    // Remove added off-mesh connections from navmesh
    for (int i = 0; i < instance.m_AutoOffMeshConnections.size(); ++i)
    {
        m_NavMesh->RemoveOffMeshConnection(instance.m_AutoOffMeshConnections[i]);
    }

    m_LoadedSurfaces.erase(found);
    m_NavMesh->RemoveSurface(surfaceID);

    CleanupIfNoData();
}

// return all the surface ids containing data from 'navMeshData'
void NavMeshManager::GetSurfaceIDsFromData(dynamic_array<int>& surfaceIDs, const NavMeshData* navMeshData) const
{
    const NavMeshSurfaceInstanceMap::const_iterator end = m_LoadedSurfaces.end();
    NavMeshSurfaceInstanceMap::const_iterator it = m_LoadedSurfaces.begin();
    for (; it != end; ++it)
    {
        if (navMeshData == it->second.m_NavMeshData)
            surfaceIDs.push_back(it->first);
    }
}

// remove all surfaces containing data from 'navMeshData'
void NavMeshManager::PurgeData(const NavMeshData* navMeshData)
{
    dynamic_array<int> removeIDs(kMemTempAlloc);
    GetSurfaceIDsFromData(removeIDs, navMeshData);

    for (int i = 0; i < removeIDs.size(); ++i)
        UnloadData(removeIDs[i]);

    m_SceneDataRegistry->RemoveAllData(navMeshData);

#if ENABLE_RUNTIME_NAVMESH_BUILDING
    m_BuildManager->Purge(navMeshData);
#endif
}

// Returns the new surface id
int NavMeshManager::LoadDataInternal(const NavMeshData* navMeshData, const Vector3f& position, const Quaternionf& rotation)
{
    PROFILER_AUTO(gNavMeshLoadData, NULL)
    Assert(m_NavMesh);

    SurfaceInstance instance;
    instance.m_NavMeshData = navMeshData;
    instance.m_UserID = 0;

    const NavMeshBuildSettings& settings = navMeshData->GetNavMeshBuildSettings();
    m_LegacyQueryExtents = Vector3f(settings.agentRadius, settings.agentHeight, settings.agentRadius);
    m_LegacyLinkQueryExtents = Vector3f(settings.agentRadius, settings.agentClimb, settings.agentRadius);

    const NavMeshTileDataVector& tiles = navMeshData->GetNavMeshTiles();

    const int surfaceID = m_NavMesh->CreateSurface(tiles.size(), settings, position, rotation);

    for (int i = 0; i < tiles.size(); i++)
    {
        const NavMeshTileData& tile = tiles[i];

        const unsigned char* byteData = tile.m_MeshData.begin();
        const int dataSize = tile.m_MeshData.size();
        if (!byteData || !dataSize)
            continue;

        NavMeshTileRef ref = 0;
        NavMeshStatus status = m_NavMesh->AddTile(byteData, dataSize, kTileLeakData, surfaceID, &ref);

        if (NavMeshStatusFailed(status))
        {
            if (NavMeshStatusDetail(status, kNavMeshWrongMagic) || NavMeshStatusDetail(status, kNavMeshWrongVersion))
            {
                ErrorString("Loading NavMesh failed - wrong format. Please rebake the NavMesh.");
            }
            else if (NavMeshStatusDetail(status, kNavMeshOutOfMemory))
            {
                ErrorString("Loading NavMesh failed - out of memory.");
            }
            else
            {
                ErrorStringMsg("Loading NavMesh tile #%d failed. Error code: %x", i, status);
            }
            return 0;
        }

        if (ref)
        {
            // Keep track of the tile locations that have been added.
            instance.m_AddedTileRefs.push_back(ref);
        }
    }

    // Set up HeightMeshQuery object if the baked data needs it
    const HeightMeshDataVector& heightMeshes = navMeshData->GetHeightMeshes();
    const HeightmapDataVector& heightMaps = navMeshData->GetHeightmaps();
    // Handle up to 2*cs gaps which can be caused by conservative voxelization.

    m_HeightMeshQuery->AddHeightData(surfaceID, settings.cellSize, settings.agentClimb, &heightMeshes, &heightMaps);

    // Add automatically generated offmesh links.
    const OffMeshLinkDataVector& offMeshLinks = navMeshData->GetOffMeshLinks();
    for (int i = 0; i < offMeshLinks.size(); i++)
    {
        const AutoOffMeshLinkData& data = offMeshLinks[i];
        OffMeshConnectionParams conn;
        conn.startPos = data.m_Start;
        conn.endPos = data.m_End;
        conn.up = Vector3f(0, 1, 0);
        conn.width = 0.0f;
        conn.costModifier = -1.0f;
        conn.linkDirection = data.m_LinkDirection;
        conn.flags = 1 << data.m_Area;
        conn.area = data.m_Area;
        conn.linkType = data.m_LinkType;
        conn.userID = 0;
        conn.agentTypeID = navMeshData->GetAgentTypeID();
        const NavMeshPolyRef ref = m_NavMesh->AddOffMeshConnection(&conn, settings.agentRadius, settings.agentClimb);
        if (ref)
        {
            instance.m_AutoOffMeshConnections.push_back(ref);
        }
    }

    Assert(m_LoadedSurfaces.find(surfaceID) == m_LoadedSurfaces.end());
    m_LoadedSurfaces[surfaceID] = instance;

    return surfaceID;
}

void NavMeshManager::InitializeNavMeshSystems()
{
    Assert(m_NavMesh == NULL);
    Assert(m_NavMeshQuery == NULL);
    Assert(m_HeightMeshQuery == NULL);

    Cleanup();

    m_NavMesh = UNITY_NEW(NavMesh, kMemAI)();
    if (!m_NavMesh)
        return CleanupWithError("Out of memory");

    m_NavMeshQuery = UNITY_NEW(NavMeshQuery, kMemAI) (m_NavMesh, kNodePoolSize);
    if (m_NavMeshQuery == NULL)
        return CleanupWithError("Query allocation");

    m_HeightMeshQuery = UNITY_NEW(HeightMeshQuery, kMemAI) ();
    if (m_HeightMeshQuery == NULL)
        return CleanupWithError("Height query allocation");

    if (!InitializeCrowdSystem())
        return CleanupWithError("Crowd initialization");

    InitializeCarvingSystem();

    for (size_t i = 0; i < m_ObstacleInfo.size(); ++i)
        m_ObstacleInfo[i].obstacle->OnNavMeshInitialize();
}

Vector3f NavMeshManager::GetQueryExtents(int agentTypeID) const
{
#if ENABLE_RUNTIME_NAVMESH_BUILDING
    if (const NavMeshBuildSettings* bs = GetNavMeshProjectSettings().GetSettingsByID(agentTypeID))
        return Vector3f(bs->agentRadius, bs->agentHeight, bs->agentRadius);
    else if (agentTypeID != -1)
        ErrorStringMsg("NavMeshBuildSettings for agent type ID: %d wasn't found", agentTypeID);
#else
    UNUSED(agentTypeID);
#endif
    return m_LegacyQueryExtents;
}

Vector3f NavMeshManager::GetLinkQueryExtents(int agentTypeID) const
{
#if ENABLE_RUNTIME_NAVMESH_BUILDING
    if (const NavMeshBuildSettings* bs = GetNavMeshProjectSettings().GetSettingsByID(agentTypeID))
        return Vector3f(bs->agentRadius, bs->agentClimb, bs->agentRadius);
    else if (agentTypeID != -1)
        ErrorStringMsg("NavMeshBuildSettings for agent type ID: %d wasn't found", agentTypeID);
#else
    UNUSED(agentTypeID);
#endif

    return m_LegacyLinkQueryExtents;
}

bool NavMeshManager::Raycast(NavMeshHit* hit, const Vector3f& sourcePosition, const Vector3f& targetPosition, const QueryFilter& filter)
{
    NavMeshPolyRef mappedPolyRef;
    Vector3f mappedPosition;
    const Vector3f ext = GetQueryExtents(filter.GetTypeID());
    if (!MapPosition(&mappedPolyRef, &mappedPosition, sourcePosition, ext, filter))
    {
        InvalidateNavMeshHit(hit);
        return false;
    }

    NavMeshRaycastResult result;
    NavMeshStatus status = m_NavMeshQuery->Raycast(mappedPolyRef, mappedPosition, targetPosition,
            &filter, &result, NULL, NULL, 0);

    if (NavMeshStatusFailed(status))
    {
        InvalidateNavMeshHit(hit);
        return false;
    }

    const Vector3f lpos = Lerp(mappedPosition, targetPosition, result.t);

    Vector3f pos;
    m_NavMeshQuery->ProjectToPoly(&pos, result.lastPoly, lpos);
    bool blocked = result.t < 1.0f;

    m_HeightMeshQuery->SetPositionHeight(&pos);
    hit->position = pos;
    hit->normal = result.normal;
    hit->distance = Magnitude(hit->position - sourcePosition);
    hit->mask = m_NavMesh->GetPolyFlags(result.hitPoly);
    hit->hit = blocked;

    return blocked;
}

bool NavMeshManager::DistanceToEdge(NavMeshHit* hit, const Vector3f& sourcePosition, const QueryFilter& filter)
{
    NavMeshPolyRef mappedPolyRef;
    Vector3f mappedPosition;
    const Vector3f ext = GetQueryExtents(filter.GetTypeID());
    if (!MapPosition(&mappedPolyRef, &mappedPosition, sourcePosition, ext, filter))
    {
        InvalidateNavMeshHit(hit);
        return false;
    }

    unsigned int mask = 0;
    const NavMeshStatus status = m_NavMeshQuery->FindDistanceToWall(mappedPolyRef, mappedPosition, &filter,
            &hit->distance, &hit->position, &hit->normal,
            &mask);
    hit->mask = (int)mask;

    if (NavMeshStatusFailed(status))
    {
        InvalidateNavMeshHit(hit);
        return false;
    }
    hit->hit = true;

    return true;
}

bool NavMeshManager::SamplePosition(NavMeshHit* hit, const Vector3f& sourcePosition, const QueryFilter& filter, float maxDistance)
{
    NavMeshPolyRef mappedPolyRef;
    Vector3f mappedPosition;
    const Vector3f extents = Vector3f(maxDistance, maxDistance, maxDistance);
    if (!MapPosition(&mappedPolyRef, &mappedPosition, sourcePosition, extents, filter))
    {
        InvalidateNavMeshHit(hit);
        return false;
    }

    const float distance = Magnitude(mappedPosition - sourcePosition);
    if (distance > maxDistance)
    {
        InvalidateNavMeshHit(hit);
        return false;
    }

    m_HeightMeshQuery->SetPositionHeight(&mappedPosition);
    hit->position = mappedPosition;
    hit->normal.SetZero();
    hit->distance = distance;
    hit->mask = m_NavMesh->GetPolyFlags(mappedPolyRef);
    hit->hit = true;

    return true;
}

int NavMeshManager::CalculatePolygonPath(NavMeshPath* path, const Vector3f& sourcePosition, const Vector3f& targetPosition, const QueryFilter& filter)
{
    if (m_NavMeshQuery == NULL)
        return 0;

    if (!IsFinite(sourcePosition) || !IsFinite(targetPosition))
    {
#if UNITY_EDITOR
        ErrorString(Format("CalculatePolygonPath: invalid input position(s). Source position { %s, %s, %s }. Target position { %s, %s, %s }"
                , FloatToString(sourcePosition.x).c_str(), FloatToString(sourcePosition.y).c_str(), FloatToString(sourcePosition.z).c_str()
                , FloatToString(targetPosition.x).c_str(), FloatToString(targetPosition.y).c_str(), FloatToString(targetPosition.z).c_str()));
#endif
        return 0;
    }

    Vector3f targetMappedPos;
    Vector3f sourceMappedPos;
    NavMeshQuery* query = m_NavMeshQuery;
    const Vector3f ext = GetQueryExtents(filter.GetTypeID());

    NavMeshPolyRef targetPolyRef;
    query->FindNearestPoly(targetPosition, ext, &filter, &targetPolyRef, &targetMappedPos);
    if (targetPolyRef == 0)
        return 0;

    NavMeshPolyRef sourcePolyRef;
    query->FindNearestPoly(sourcePosition, ext, &filter, &sourcePolyRef, &sourceMappedPos);
    if (sourcePolyRef == 0)
        return 0;

    int polygonCount = 0;

    NavMeshStatus status = query->InitSlicedFindPath(sourcePolyRef, targetPolyRef, sourceMappedPos, targetMappedPos, &filter);
    if (!NavMeshStatusFailed(status))
        status = query->UpdateSlicedFindPath(65535, NULL);
    if (!NavMeshStatusFailed(status))
        status = query->FinalizeSlicedFindPath(&polygonCount);
    path->ReservePolygons(polygonCount);
    if (!NavMeshStatusFailed(status))
        status = query->GetPath(path->GetPolygonPath(), &polygonCount, path->GetPolygonCapacity());

    path->SetTimeStamp(m_NavMesh->GetTimeStamp());
    path->SetPolygonCount(polygonCount);
    path->SetSourcePosition(sourceMappedPos);
    path->SetTargetPosition(targetMappedPos);
    if (NavMeshStatusFailed(status) || polygonCount == 0)
    {
        path->SetStatus(kPathInvalid);
        return 0;
    }

    if (NavMeshStatusDetail(status, kNavMeshPartialResult))
    {
        // when path is partial we project the target position
        // to the last polygon in the path.

        const NavMeshPolyRef* polygonPath = path->GetPolygonPath();
        const NavMeshPolyRef lastPolyRef = polygonPath[polygonCount - 1];
        Vector3f partialTargetPos;
        NavMeshStatus status = query->ClosestPointOnPoly(lastPolyRef, targetMappedPos, &partialTargetPos);
        if (NavMeshStatusFailed(status))
        {
            path->SetStatus(kPathInvalid);
            return 0;
        }

        path->SetStatus(kPathPartial);
        path->SetTargetPosition(partialTargetPos);

        // If the pathfinding req ran out of nodes - we mark the path as stale
        // i.e. outdating the path by settings the time-stamp to 0
        if (NavMeshStatusDetail(status, kNavMeshOutOfNodes))
            path->SetTimeStamp(0);
    }
    else
    {
        path->SetStatus(kPathComplete);
    }

    return polygonCount;
}

int NavMeshManager::CalculatePathCorners(Vector3f* corners, int maxCorners, const NavMeshPath& path) const
{
    if (m_NavMeshQuery == NULL || corners == NULL || maxCorners < 2 || path.GetPolygonCount() < 1)
        return 0;

    int cornerCount = 0;
    NavMeshStatus result;
    const Vector3f sourcePos = path.GetSourcePosition();
    const Vector3f targetPos = path.GetTargetPosition();
    NavMeshPolyRef* refs;
    ALLOC_TEMP(refs, maxCorners);
    unsigned char* flags;
    ALLOC_TEMP(flags, maxCorners);

    const NavMeshQuery* query = m_NavMeshQuery;
    result = query->FindStraightPath(sourcePos, targetPos,
            path.GetPolygonPath(), path.GetPolygonCount(),
            corners, flags, refs, &cornerCount, maxCorners);

    Assert(cornerCount <= maxCorners);
    if (NavMeshStatusFailed(result))
        return 0;

    return cornerCount;
}

bool NavMeshManager::MapPosition(NavMeshPolyRef* mappedPolyRef, Vector3f* mappedPosition, const Vector3f& position, const Vector3f& extents, const QueryFilter& filter) const
{
    if (!m_NavMeshQuery)
        return false;

    m_NavMeshQuery->FindNearestPoly(position, extents, &filter, mappedPolyRef, mappedPosition);
    const NavMeshPolyRef ref = *mappedPolyRef;
    return ref != 0;
}

void NavMeshManager::Triangulate(NavMeshManager::Triangulation& triangulation) const
{
    // Mapping between old and new vertex indices.
    typedef UNITY_MAP (kMemAI, UInt16, SInt32) VertexMap;

    dynamic_array<SInt32>& areas = triangulation.areas;
    dynamic_array<SInt32>& indices = triangulation.indices;
    dynamic_array<Vector3f>& vertices = triangulation.vertices;

    areas.clear();
    indices.clear();
    vertices.clear();

    if (m_NavMesh == NULL)
        return;

    const size_t tileCount = m_NavMesh->GetMaxTiles();
    for (size_t it = 0; it < tileCount; ++it)
    {
        const NavMeshTile* tile = m_NavMesh->GetTile(it);
        if (tile == NULL || tile->header == NULL)
            continue;

        dynamic_array<Vector3f> worldVertices(kMemTempAlloc);
        worldVertices.resize_uninitialized(tile->header->vertCount);
        TileToWorld(worldVertices.begin(), *tile, tile->header->vertCount, tile->verts);

        for (size_t ip = 0; ip < (size_t)tile->header->polyCount; ++ip)
        {
            const NavMeshPoly& p = tile->polys[ip];
            const size_t polyVertCount = p.vertCount;

            // Ignore irregular polygons.
            if (polyVertCount < 3)
                continue;

            VertexMap vertexMap;

            // Find or update new vertex index.
            for (size_t iv = 0; iv < polyVertCount; ++iv)
            {
                UInt16 vi = p.verts[iv];
                VertexMap::iterator found = vertexMap.find(vi);
                if (found != vertexMap.end())
                    continue;

                // Lookup the height for vertex
                NavMeshPolyRef ref = m_NavMesh->GetPolyRefBase(tile) | (NavMeshPolyRef)ip;
                Vector3f vertex;
                m_NavMeshQuery->ProjectToPoly(&vertex, ref, worldVertices[vi]);

                vertexMap[vi] = vertices.size();
                vertices.push_back(vertex);
            }

            // Add triangles for this polygon.
            const SInt32 v0 = vertexMap[p.verts[0]];
            SInt32 v1 = vertexMap[p.verts[1]];
            for (size_t iv = 2; iv < polyVertCount; ++iv)
            {
                const SInt32 v2 = vertexMap[p.verts[iv]];
                indices.push_back(v0);
                indices.push_back(v1);
                indices.push_back(v2);

                v1 = v2;
            }

            // Add the navmesh area for each triangle
            for (size_t iv = 2; iv < polyVertCount; ++iv)
            {
                areas.push_back(p.area);
            }
        }
    }
}

void NavMeshManager::SetAvoidancePredictionTime(float t)
{
    t = std::max(0.0f, t);
    m_AvoidancePredictionTime = t;
    if (m_CrowdSystem)
        m_CrowdSystem->SetAvoidancePredictionTime(t);
}

void NavMeshManager::SetPathfindingIterationsPerFrame(int i)
{
    i = std::max(0, i);
    m_PathfindingIterationsPerFrame = i;
    if (m_CrowdSystem)
        m_CrowdSystem->SetPathfindingIterationsPerFrame(i);
}

void NavMeshManager::RegisterAgent(NavMeshAgent& agent, int& handle)
{
    Assert(handle == -1);

    handle = RegisterInArray(m_Agents, agent);

    // Print warning if the same game object has active agent and obstacle.
    GameObject* agentGameObject = agent.GetGameObjectPtr();
    NavMeshObstacle* obstacle = agentGameObject->QueryComponent<NavMeshObstacle>();
    if (obstacle != NULL && obstacle->IsRegistered())
    {
        WarningStringObject("NavMeshAgent and NavMeshObstacle components are active at the same time. This can lead to errorneous behavior.", agentGameObject);
    }
}

void NavMeshManager::UnregisterAgent(int& handle)
{
    UnregisterFromArray(m_Agents, handle);
    handle = -1;
}

void NavMeshManager::RegisterObstacle(NavMeshObstacle& obstacle, int& handle)
{
    Assert(handle == -1);

    if (!m_NavMesh)
        InitializeNavMeshSystems();

    NavMeshObstacleInfo info;
    info.obstacle = &obstacle;
    info.carveHandle = -1;
    info.obstacleRef = 0;
    m_ObstacleInfo.push_back(info);
    handle = m_ObstacleInfo.size() - 1;

    // Print warning if the same game object has active agent and obstacle.
    GameObject* obstacleGameObject = obstacle.GetGameObjectPtr();
    NavMeshAgent* agent = obstacleGameObject->QueryComponent<NavMeshAgent>();
    if (agent != NULL && agent->IsRegistered())
    {
        WarningStringObject("NavMeshAgent and NavMeshObstacle components are active at the same time. This can lead to errorneous behavior.", obstacleGameObject);
    }
}

void NavMeshManager::UnregisterObstacle(int& handle)
{
    Assert(handle != -1);
    NavMeshObstacleInfo& info = m_ObstacleInfo[handle];

    if (info.carveHandle != -1)
        m_CarvingSystem->RemoveObstacle(info.carveHandle);

    if (info.obstacleRef != 0)
    {
        m_CrowdSystem->RemoveObstacle(info.obstacleRef);
        info.obstacleRef = 0;
    }

    if (handle != m_ObstacleInfo.size() - 1)
    {
        m_ObstacleInfo[handle] = m_ObstacleInfo.back();
        m_ObstacleInfo[handle].obstacle->SetManagerHandle(handle);
    }
    m_ObstacleInfo.pop_back();
    handle = -1;

    CleanupIfNoData();
}

void NavMeshManager::RegisterOffMeshLink(OffMeshLink& link, int& handle)
{
    Assert(handle == -1);

    if (!m_NavMesh)
        InitializeNavMeshSystems();

    handle = RegisterInArray(m_Links, link);
}

void NavMeshManager::UnregisterOffMeshLink(int& handle)
{
    UnregisterFromArray(m_Links, handle);
    handle = -1;

    CleanupIfNoData();
}

void NavMeshManager::SetOffMeshConnectionCostOverride(NavMeshPolyRef ref, float costOverride)
{
    if (m_NavMesh == NULL)
        return;
    m_NavMesh->SetOffMeshConnectionCostModifier(ref, costOverride);
}

void NavMeshManager::SetOffMeshConnectionActive(NavMeshPolyRef ref, bool active)
{
    if (m_NavMesh == NULL)
        return;
    unsigned int flags = 0;
    unsigned char area = 0;
    m_NavMesh->GetPolyFlagsAndArea(ref, &flags, &area);
    if ((flags == 0 && !active) || (flags != 0 && active))
        return;
    if (active)
        m_NavMesh->SetOffMeshConnectionFlags(ref, 1 << (unsigned int)area);
    else
        m_NavMesh->SetOffMeshConnectionFlags(ref, 0);
}

NavMeshPolyRef NavMeshManager::AddOffMeshConnection(const Vector3f& startPos, const Vector3f& endPos,
    int instanceID, bool twoWay, unsigned char areaType, int agentTypeID)
{
    // TODO: fix this - currently one cannot add offmeshlinks if there's no navmesh (no tiles)
    // The NavMesh is lazily created only when navmesh data is (loaded)
    // Currently this means that offmeshlinks added before navmesh will not connect - if navmesh is addded later.
    if (m_NavMesh == NULL)
        return (NavMeshPolyRef)0;

    OffMeshConnectionParams conn;
    conn.startPos = startPos;
    conn.endPos = endPos;
    conn.up = Vector3f(0, 1, 0);
    conn.width = 0.0f;
    conn.costModifier = -1.0f;
    conn.linkDirection = twoWay ? kLinkDirectionTwoWay : kLinkDirectionOneWay;
    conn.flags = 1 << areaType;
    conn.area = areaType;
    conn.linkType = static_cast<unsigned short>(kLinkTypeManual);
    conn.userID = instanceID;
    conn.agentTypeID = agentTypeID;

    const Vector3f query = GetLinkQueryExtents(agentTypeID);
    return m_NavMesh->AddOffMeshConnection(&conn, query.x, query.y);
}

void NavMeshManager::RemoveOffMeshConnection(const NavMeshPolyRef ref)
{
    if (m_NavMesh != NULL)
        m_NavMesh->RemoveOffMeshConnection(ref);
}

bool NavMeshManager::GetOffMeshConnectionPositions(const NavMeshPolyRef ref, Vector3f* startPos, Vector3f* endPos) const
{
    if (m_NavMesh == NULL)
        return false;

    const OffMeshConnection* con = m_NavMesh->GetOffMeshConnection(ref);
    if (con == NULL)
        return false;

    *startPos = Vector3f(con->endPoints[0].pos);
    *endPos = Vector3f(con->endPoints[1].pos);

    return true;
}

bool NavMeshManager::IsOffMeshConnectionOccupied(const NavMeshPolyRef ref) const
{
    if (!m_CrowdSystem)
        return false;
    return m_CrowdSystem->IsRefOccupied(ref);
}

int NavMeshManager::GetUserID(const NavMeshPolyRef ref) const
{
    if (!m_NavMesh)
        return 0;

    if (NavMesh::DecodePolyIdType(ref) == kPolyTypeOffMeshConnection)
    {
        int userID = 0;
        m_NavMesh->GetOffMeshConnectionUserID(ref, &userID);
        return userID;
    }

    if (const NavMeshTile* tile = m_NavMesh->GetTileByRef(ref))
        return GetSurfaceUserID(tile->surfaceID);

    return 0;
}

bool NavMeshManager::IsValidLinkHandle(const NavMeshLinkHandle handle) const
{
    int idx = handle & kLinkHandleSaltMask;

    if (idx < (int)m_LinkInfo.Capacity())
    {
        int salt = (handle >> kLinkHandleSaltBits) & kLinkHandleSaltMask;
        return m_LinkInfo[idx].salt == salt;
    }
    return false;
}

int NavMeshManager::AddLink(const NavMeshLinkData& link, const Vector3f& position, const Quaternionf& rotation)
{
    DebugAssertMsg(link.m_Area >= 0, "Expected non-negative area for link");

    if (!m_NavMesh)
        InitializeNavMeshSystems();

    if (link.m_Area == NavMeshProjectSettings::kNotWalkable)
        return 0;

    unsigned int idx = m_LinkInfo.Alloc();
    if (idx > kLinkHandleSaltMask)
    {
        ErrorStringMsg("Failed to allocate NavMeshLink. Exceeding maximum count of %d", kLinkHandleSaltMask);
        m_LinkInfo.Release(idx);
        return 0;
    }

    if (m_NavMesh != NULL)
    {
        Matrix4x4f mat;
        mat.SetTR(position, rotation);

        OffMeshConnectionParams conn;
        conn.startPos = mat.MultiplyPoint3(link.m_StartPosition);
        conn.endPos = mat.MultiplyPoint3(link.m_EndPosition);
        conn.up = RotateVectorByQuat(rotation, Vector3f(0, 1, 0));
        conn.width = link.m_Width;
        conn.costModifier = link.m_CostModifier;
        conn.linkDirection = link.m_Bidirectional ? kLinkDirectionTwoWay : kLinkDirectionOneWay;
        conn.flags = 1 << link.m_Area;
        conn.area = link.m_Area;
        conn.linkType = static_cast<unsigned short>(kLinkTypeManual);
        conn.agentTypeID = link.m_AgentTypeID;

        const Vector3f query = GetLinkQueryExtents(link.m_AgentTypeID);
        m_LinkInfo[idx].polyRef = m_NavMesh->AddOffMeshConnection(&conn, query.x, query.y);
    }

    int handle = (m_LinkInfo[idx].salt << kLinkHandleSaltBits) | idx;
    return handle;
}

int NavMeshManager::GetLinkUserID(int handle) const
{
    int idx = handle & kLinkHandleSaltMask;
    int salt = (handle >> kLinkHandleSaltBits) & kLinkHandleSaltMask;
    if (idx < 0 || idx >= (int)m_LinkInfo.Capacity())
        return 0;
    if (m_LinkInfo[idx].salt != salt)
        return 0;
    if (m_NavMesh == NULL)
        return 0;

    int userID = 0;
    m_NavMesh->GetOffMeshConnectionUserID(m_LinkInfo[idx].polyRef, &userID);
    return userID;
}

bool NavMeshManager::SetLinkUserID(int handle, int userID)
{
    int idx = handle & kLinkHandleSaltMask;
    int salt = (handle >> kLinkHandleSaltBits) & kLinkHandleSaltMask;
    if (idx < 0 || idx >= (int)m_LinkInfo.Capacity())
        return false;
    if (m_LinkInfo[idx].salt != salt)
        return false;
    if (m_NavMesh == NULL)
        return false;

    m_NavMesh->SetOffMeshConnectionUserID(m_LinkInfo[idx].polyRef, userID);
    return true;
}

void NavMeshManager::RemoveLink(int handle)
{
    int idx = handle & kLinkHandleSaltMask;
    int salt = (handle >> kLinkHandleSaltBits) & kLinkHandleSaltMask;
    if (idx < 0 || idx >= (int)m_LinkInfo.Capacity())
        return;
    if (m_LinkInfo[idx].salt != salt)
        return;
    if (m_NavMesh == NULL)
        return;

    m_NavMesh->RemoveOffMeshConnection(m_LinkInfo[idx].polyRef);
    m_LinkInfo[idx].salt++;
    m_LinkInfo[idx].polyRef = 0;

    m_LinkInfo.Release(idx);

    CleanupIfNoData();
}

void NavMeshManager::UpdateCarving()
{
    if (!m_CarvingSystem)
        return;

    m_CarvingSystem->PrepareCarving();
    m_CarvingSystem->Carve();

    // Apply carve results immediately in edit-mode
    if (!IsWorldPlaying())
        m_CarvingSystem->ApplyCarveResults();
}

void NavMeshManager::UpdateCarvingResults()
{
    if (m_CarvingSystem)
        m_CarvingSystem->ApplyCarveResults();
}

void NavMeshManager::UpdateOffMeshLinks()
{
    if (m_Links.empty())
        return;

    PROFILER_AUTO(gNavMeshOffMeshLinks, NULL)
    if (IsWorldPlaying())
    {
        for (size_t i = 0; i < m_Links.size(); ++i)
            m_Links[i]->UpdateMovedPositions();
    }
    else
    {
        for (size_t i = 0; i < m_Links.size(); ++i)
            m_Links[i]->UpdatePositions();
    }
}

#if UNITY_EDITOR
void NavMeshManager::EditorTick()
{
#if ENABLE_RUNTIME_NAVMESH_BUILDING
    // In edit mode the build-manager needs to be updated explicitly.
    // Otherwise async operations will not complete.
    if (m_BuildManager && !IsWorldPlaying())
        m_BuildManager->UpdateAsyncOperations();
#endif
}

bool NavMeshManager::RequestAgentDebugInfo(const CrowdRef agentRef)
{
    if (m_CrowdAgentDebugRequestCount >= kDebugAgentCount)
        return false;
    // Return true if debug info has already been requested.
    for (int i = 0; i < m_CrowdAgentDebugRequestCount; i++)
    {
        if (m_CrowdAgentDebugRequest[i] == agentRef)
            return true;
    }
    m_CrowdAgentDebugRequest[m_CrowdAgentDebugRequestCount++] = agentRef;
    return true;
}

const CrowdAgentDebugInfo* NavMeshManager::GetAgentDebugInfo(const CrowdRef agentRef) const
{
    for (int i = 0; i < kDebugAgentCount; i++)
    {
        if (m_CrowdAgentDebugInfos[i].agentRef == agentRef)
            return &m_CrowdAgentDebugInfos[i];
    }
    return NULL;
}

bool NavMeshManager::HasPendingAgentDebugInfo() const
{
    for (int i = 0; i < m_CrowdAgentDebugRequestCount; i++)
    {
        if (GetAgentDebugInfo(m_CrowdAgentDebugRequest[i]) == NULL)
            return true;
    }
    return false;
}

#endif

int NavMeshManager::GetLoadedNavMeshDataCount() const
{
    return (int)m_LoadedSurfaces.size();
}

const NavMeshData* NavMeshManager::GetLoadedNavMeshData(int i) const
{
    NavMeshSurfaceInstanceMap::const_iterator it = m_LoadedSurfaces.begin();
    Assert(i < std::distance(it, m_LoadedSurfaces.end()));
    std::advance(it, i);
    return it->second.m_NavMeshData;
}

struct UpdateTransformGetMessagesInfo
{
    NavMeshAgent** m_AgentBase;
    Transform** m_TransformBase;
    int* m_MessageBase;
    int m_Count;
    float m_DeltaTime;
};

static const int MAX_JOBS = 16;
static UpdateTransformGetMessagesInfo s_infos[MAX_JOBS] = {{}};
static void PrepareUpdateTransformsGetMessages(int itemCount, int jobCount, UpdateTransformGetMessagesInfo* infos, NavMeshAgent** agents, Transform** transforms, int* messages, float deltaTime)
{
    Assert(jobCount <= MAX_JOBS);

    int start = 0;
    int remaining = itemCount;
    for (int i = 0; i < jobCount; ++i)
    {
        const int count = remaining / (jobCount - i);

        UpdateTransformGetMessagesInfo& in = infos[i];
        in.m_AgentBase = agents + start;
        in.m_TransformBase = transforms + start;
        in.m_MessageBase = messages + start;
        in.m_Count = count;
        in.m_DeltaTime = deltaTime;

        start += count;
        remaining -= count;
    }
}

static void UpdateTransformsGetMessagesMultiThreaded(UpdateTransformGetMessagesInfo* jobData, unsigned int i)
{
    PROFILER_AUTO(gNavMeshAgentsUpdateTransform, NULL);

    UpdateTransformGetMessagesInfo& info = jobData[i];
    NavMeshAgent** agentBase = info.m_AgentBase;
    Transform** transformBase = info.m_TransformBase;
    int* messageBase = info.m_MessageBase;
    float deltaTime = info.m_DeltaTime;

    const int count = info.m_Count;
    for (int i = 0; i < count; ++i)
    {
        messageBase[i] = agentBase[i]->UpdateTransformGetMessageMask(deltaTime, &transformBase[i]);
    }
}

void NavMeshManager::UpdateCrowdSystem()
{
    const float deltaTime = GetDeltaTime();
    if (deltaTime == 0.0f)
        return;
    CrowdAgentDebugInfo* debugInfos = NULL;
    int debugInfoCount = 0;
#if UNITY_EDITOR
    debugInfos = m_CrowdAgentDebugInfos;
    debugInfoCount = m_CrowdAgentDebugRequestCount;
    for (int i = 0; i < kDebugAgentCount; i++)
        m_CrowdAgentDebugInfos[i].agentRef = (i < m_CrowdAgentDebugRequestCount) ? m_CrowdAgentDebugRequest[i] : 0;
    m_CrowdAgentDebugRequestCount = 0;
#endif

    if (m_Agents.empty())
        return;

    m_CrowdSystem->Update(deltaTime, debugInfos, debugInfoCount);

    // Update all NavMeshAgent transforms and collect changeMask
    dynamic_array<Transform*> transforms(kMemTempAlloc);
    dynamic_array<int> messages(kMemTempAlloc);
    transforms.resize_uninitialized(m_Agents.size());
    messages.resize_uninitialized(m_Agents.size());

    int itemCount = m_Agents.size();
    int jobCount = std::min(1 + itemCount / 10, MAX_JOBS);

    PrepareUpdateTransformsGetMessages(itemCount, jobCount, s_infos, m_Agents.begin(), transforms.begin(), messages.begin(), deltaTime);

    JobFence fence;
    ScheduleJobForEach(fence, UpdateTransformsGetMessagesMultiThreaded, s_infos, jobCount, kHighJobPriority);
    SyncFence(fence);

    // Update the transform hierarchy w/o triggering NavMeshAgents own callback
    PROFILER_BEGIN(gNavMeshAgentsUpdateTransformChangedMessage, NULL);

    MessageHandler::Get().SetMessageEnabled(TypeOf<NavMeshAgent>(), kTransformChanged, false);

    for (size_t i = 0; i < m_Agents.size(); ++i)
    {
        if (messages[i])
        {
            transforms[i]->SendTransformChanged(messages[i]);
#if UNITY_EDITOR
            transforms[i]->SetDirty();
#endif
        }
    }
    MessageHandler::Get().SetMessageEnabled(TypeOf<NavMeshAgent>(), kTransformChanged, true);

    PROFILER_END(gNavMeshAgentsUpdateTransformChangedMessage);
}

void NavMeshManager::UpdateNavMeshObstacles()
{
    if (m_ObstacleInfo.empty())
        return;

    PROFILER_AUTO(gNavMeshObstaclesUpdateTransform, NULL);

    for (size_t i = 0; i < m_ObstacleInfo.size(); ++i)
    {
        NavMeshObstacleInfo& info = m_ObstacleInfo[i];

        info.obstacle->UpdateState();

        if (m_CarvingSystem != NULL)
        {
            bool shouldCarve = info.obstacle->GetCarving() && info.obstacle->GetMoveState() == kObstacleStationary;
            if (shouldCarve)
            {
                if (info.carveHandle == -1)
                    m_CarvingSystem->AddObstacle(*info.obstacle, info.carveHandle);
            }
            else
            {
                if (info.carveHandle != -1)
                    m_CarvingSystem->RemoveObstacle(info.carveHandle);
            }
        }

        if (m_CrowdSystem != NULL)
        {
            bool shouldAvoid = !info.obstacle->GetCarving() || info.obstacle->GetMoveState() == kObstacleMoving;
            if (shouldAvoid)
            {
                if (info.obstacleRef == 0)
                    info.obstacleRef = m_CrowdSystem->AddObstacle();

                const Vector3f extents = info.obstacle->GetWorldExtents();
                const Vector3f velocity = info.obstacle->GetVelocity();

                Vector3f center, xAxis, yAxis, zAxis;
                info.obstacle->GetWorldCenterAndAxes(center, xAxis, yAxis, zAxis);

                m_CrowdSystem->SetObstaclePositionAndVelocity(info.obstacleRef, center, velocity);

                if (info.obstacle->GetShape() == kObstacleShapeCapsule)
                {
                    m_CrowdSystem->SetObstacleCylinder(info.obstacleRef, extents, xAxis, yAxis, zAxis);
                }
                else
                {
                    m_CrowdSystem->SetObstacleBox(info.obstacleRef, extents, xAxis, yAxis, zAxis);
                }
            }
            else
            {
                if (info.obstacleRef != 0)
                {
                    m_CrowdSystem->RemoveObstacle(info.obstacleRef);
                    info.obstacleRef = 0;
                }
            }
        }
    }
}

// Central Update dispatch for navmesh sub-systems, called before script update
void NavMeshManager::Update()
{
#if ENABLE_RUNTIME_NAVMESH_BUILDING
    ScriptingInvocation(GetAIScriptingClasses().internal_CallOnNavMeshPreUpdate).Invoke();
#endif

    if (m_NavMeshQuery != NULL)
    {
        PROFILER_AUTO(gNavMeshManager, NULL)
        UpdateCarvingResults();

        dynamic_array<AgentLinkState> agentLinkStates(kMemTempAlloc);
        ExtractAgentLinkStates(m_Agents, agentLinkStates);
        UpdateOffMeshLinks();
        UpdateAgentLinkStates(agentLinkStates, m_Agents);

        UpdateCrowdSystem();
    }

#if ENABLE_RUNTIME_NAVMESH_BUILDING
    m_BuildManager->UpdateAsyncOperations();
#endif
}

void NavMeshManager::ExitPlayMode()
{
#if ENABLE_RUNTIME_NAVMESH_BUILDING
    m_BuildManager->ReleaseAsyncOperations();

    // Clean up navmesh data added at runtime - that would otherwise leak

    // UnloadData modifies m_LoadedSurfaces - so collect first then unload
    dynamic_array<int> leakedSurfaces(kMemTempAlloc);
    for (NavMeshSurfaceInstanceMap::const_iterator it = m_LoadedSurfaces.begin(); it != m_LoadedSurfaces.end(); ++it)
    {
        // Skip navmesh surfaces coming from scenes - they're unloaded on scene unloading callback
        // which is invoked after exit playmode callback
        if (!m_SceneDataRegistry->Contains(it->first))
            leakedSurfaces.push_back(it->first);
    }

    int leakCount = leakedSurfaces.size();
    if (leakCount != 0)
    {
        for (int i = 0; i < leakCount; ++i)
            UnloadData(leakedSurfaces[i]);

        WarningStringMsg("Removed %d instance%s of leaked navmesh data while exiting play-mode.\nUse NavMesh.RemoveNavMeshData to remove navmesh data that has been added with NavMesh.AddNavMeshData.", leakCount, leakCount > 1 ? "s" : "");
    }

    leakCount = 0;
    for (int i = 0; i < m_LinkInfo.Capacity(); ++i)
    {
        if (m_LinkInfo[i].polyRef)
        {
            leakCount++;
            if (m_NavMesh != NULL)
                m_NavMesh->RemoveOffMeshConnection(m_LinkInfo[i].polyRef);
        }
    }
    m_LinkInfo.Clear();

    if (leakCount != 0)
    {
        WarningStringMsg("Removed %d instance%s of leaked navmesh links while exiting play-mode.\nUse NavMesh.RemoveLink to remove navmesh link that has been added with NavMesh.AddLink.", leakCount, leakCount > 1 ? "s" : "");
    }

    CleanupIfNoData();
#endif
}

// Update dispatch for navmesh sub-systems, called after script update
void NavMeshManager::UpdatePostScript()
{
    PROFILER_AUTO(gNavMeshManager, NULL)
    UpdateNavMeshObstacles();
    UpdateCarving();
}

void NavMeshManager::CleanupWithError(const char* message)
{
    if (message)
        ErrorStringMsg("Creating NavMesh failed: '%s'", message);
    else
        ErrorString("Creating NavMesh failed");
    Cleanup();
}

void NavMeshManager::CleanupIfNoData()
{
    if (m_LoadedSurfaces.empty() && m_Links.empty() && (m_NavMesh == NULL || m_NavMesh->GetFirstOffMeshConnection() == NULL))
    {
        Cleanup();
    }
}

void NavMeshManager::Cleanup()
{
    NotifyNavMeshCleanup();

    if (m_NavMesh)
    {
        UNITY_DELETE(m_NavMesh, kMemAI);
    }
    if (m_NavMeshQuery)
    {
        UNITY_DELETE(m_NavMeshQuery, kMemAI);
    }
    if (m_HeightMeshQuery)
    {
        UNITY_DELETE(m_HeightMeshQuery, kMemAI);
    }

    m_LoadedSurfaces.clear();

    m_PathfindingIterationsPerFrame = kPathfindingIterationsPerFrame;
    m_AvoidancePredictionTime = kAvoidancePredictionTime;
}

void NavMeshManager::InitializeCarvingSystem()
{
    if (!m_CarvingSystem)
        m_CarvingSystem = UNITY_NEW(NavMeshCarving, kMemAI);
}

bool NavMeshManager::InitializeCrowdSystem()
{
    Assert(m_NavMesh);

    // Lazily create crowd manager
    if (m_CrowdSystem == NULL)
    {
        m_CrowdSystem = UNITY_NEW(CrowdManager, kMemAI) ();
        if (m_CrowdSystem == NULL)
            return false;

        if (!m_CrowdSystem->Init(kInitialAgentCount))
            return false;

        // Setup local avoidance params to different qualities.
        ObstacleAvoidanceParams params;
        // Use mostly default settings, copy from CrowdManager.
        memcpy(&params, m_CrowdSystem->GetObstacleAvoidanceParams(0), sizeof(ObstacleAvoidanceParams));

        // Low (11)
        params.adaptiveDivs = 5;
        params.adaptiveRings = 2;
        params.adaptiveDepth = 1;
        m_CrowdSystem->SetObstacleAvoidanceParams(kLowQualityObstacleAvoidance, &params);

        // Medium (22)
        params.adaptiveDivs = 5;
        params.adaptiveRings = 2;
        params.adaptiveDepth = 2;
        m_CrowdSystem->SetObstacleAvoidanceParams(kMedQualityObstacleAvoidance, &params);

        // Good (45)
        params.adaptiveDivs = 7;
        params.adaptiveRings = 2;
        params.adaptiveDepth = 3;
        m_CrowdSystem->SetObstacleAvoidanceParams(kGoodQualityObstacleAvoidance, &params);

        // High (66)
        params.adaptiveDivs = 7;
        params.adaptiveRings = 3;
        params.adaptiveDepth = 3;
        m_CrowdSystem->SetObstacleAvoidanceParams(kHighQualityObstacleAvoidance, &params);
    }

    m_CrowdSystem->SetAvoidancePredictionTime(m_AvoidancePredictionTime);
    m_CrowdSystem->SetPathfindingIterationsPerFrame(m_PathfindingIterationsPerFrame);
    return m_CrowdSystem->SetNavMesh(m_NavMesh, m_HeightMeshQuery, kNodePoolSize);
}

void NavMeshManager::NotifyNavMeshAdded()
{
    // TODO: this should be called only on agents/links that are not connected to navmesh
    // typically 0 or few elements - consider keeping those in end of the array

    for (size_t i = 0; i < m_Agents.size(); ++i)
        m_Agents[i]->OnNavMeshAdded();

    for (size_t i = 0; i < m_Links.size(); ++i)
        m_Links[i]->OnNavMeshAdded();
}

void NavMeshManager::NotifyNavMeshCleanup()
{
    for (size_t i = 0; i < m_Agents.size(); ++i)
        m_Agents[i]->OnNavMeshCleanup();

    for (size_t i = 0; i < m_ObstacleInfo.size(); ++i)
        m_ObstacleInfo[i].obstacle->OnNavMeshCleanup();

    for (size_t i = 0; i < m_Links.size(); ++i)
        m_Links[i]->OnNavMeshCleanup();
}

void NavMeshManager::UpdateAllNavMeshAgentCosts(int areaIndex, float areaCost)
{
    if (m_CrowdSystem != NULL)
    {
        m_CrowdSystem->UpdateFilterCost(areaIndex, areaCost);
    }
}

static NavMeshManager* gManager = NULL;

void InitializeNavMeshManager()
{
    Assert(gManager == NULL);
    gManager = UNITY_NEW(NavMeshManager, kMemAI) ();

    REGISTER_PLAYERLOOP_CALL(PreUpdate, AIUpdate, GetNavMeshManager().Update());
    REGISTER_PLAYERLOOP_CALL(PreLateUpdate, AIUpdatePostScript, GetNavMeshManager().UpdatePostScript());
}

void CleanupNavMeshManager()
{
    UNITY_DELETE(gManager, kMemAI);
}

NavMeshManager& GetNavMeshManager()
{
    return *gManager;
}
