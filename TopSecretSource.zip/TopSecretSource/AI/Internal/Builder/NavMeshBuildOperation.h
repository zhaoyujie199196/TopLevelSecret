#pragma once
#if ENABLE_RUNTIME_NAVMESH_BUILDING
#include "RuntimeNavMeshBuilder.h"
#include "Runtime/Jobs/Jobs.h"
#include "Runtime/Misc/AsyncOperation.h"
#include "Runtime/AI/Internal/NavMeshBuildSettings.h"
#include "Runtime/AI/Internal/NavMeshData.h"

class NavMeshBuildOperation : public AsyncOperation
{
public:
    NavMeshBuildOperation(NavMeshData* data, const NavMeshBuildSettings& buildSettings,
                          const NavMeshBuildSource* sources, size_t nsources, const AABB& localBounds,
                          const NavMeshBuildDebugSettings& debug)
        : m_Data(data), m_LocalBounds(localBounds), m_IsScheduled(false)
    {
        AssertMsg(Thread::CurrentThreadIsMainThread(), "Construction must happen on the main thread");
        AssertMsg(data, "NavMeshBuildOperation must have data");

        m_BuildSettings = buildSettings;
        m_Info = CreateBuildNavMeshInfo(debug);
        AcquireSharedMeshData(m_Info, sources, nsources, data->GetPosition(), data->GetRotation(), localBounds);
    }

    virtual ~NavMeshBuildOperation()
    {
        DestroyBuildNavMeshInfo(m_Info);
        m_Info = NULL;
    }

    virtual float GetProgress()
    {
        return IsDone() ? 1.0f : Progress(m_Info);
    }

    virtual bool IsDone()
    {
        return m_IsScheduled && Done(m_Info);
    }

    const NavMeshData* GetData() const
    {
        return m_Data;
    }

    // Cancel pre-schedule or in-flight if data matches
    void Purge(const NavMeshData* removedData)
    {
        AssertMsg(Thread::CurrentThreadIsMainThread(), "Purge must happen on the main thread");
        if (m_Data == removedData)
        {
            Cancel(m_Info);
            m_Data = NULL;
        }
    }

    void Schedule()
    {
        // Can be called on any thread
        AssertMsg(!m_IsScheduled, "Attempt to doubly schedule an operation.");

        // Handle the case where data is purged before being scheduled
        if (!m_Data)
        {
            DestroyBuildNavMeshInfo(m_Info);
            m_Info = NULL;
            m_IsScheduled = true;
            return;
        }

        NavMeshBuildSettings validatedSettings;
        ValidateNavMeshBuildSettings(validatedSettings, NULL, m_BuildSettings, m_LocalBounds);
        ScheduleNavMeshDataUpdate(m_Data, m_Info, validatedSettings, m_LocalBounds);

        m_IsScheduled = true;
    }

    void Integrate()
    {
        AssertMsg(Thread::CurrentThreadIsMainThread(), "Integrate must happen on the main thread");
        AssertMsg(IsDone(), "The operation must be done when integrating.");

        if (m_Data)
            IntegrateNavMeshDataUpdate(m_Data, m_Info, m_LocalBounds);
        // Consider warning here - currently we don't want to warn after cancel, but after destroying it might make sense.
        //      else
        //          ErrorString ("UpdateNavMeshData failed: the source NavMeshData has been modified while being updated");

        DestroyBuildNavMeshInfo(m_Info);
        m_Info = NULL;
    }

private:
    NavMeshData* m_Data;
    NavMeshBuildSettings m_BuildSettings;
    struct BuildNavMeshInfo* m_Info;
    AABB m_LocalBounds;
    bool m_IsScheduled;
};
#endif
