#pragma once
#if ENABLE_RUNTIME_NAVMESH_BUILDING
#include "External/Recast/Recast/Include/Recast.h"

class RecastDebugContext : public rcContext
{
public:
    RecastDebugContext(bool enable) : rcContext(enable) {}
protected:
    virtual void doStartTimer(const rcTimerLabel label);
    virtual void doStopTimer(const rcTimerLabel label);
};

#endif
