#if ENABLE_RUNTIME_NAVMESH_BUILDING
#include "UnityPrefix.h"
#include "RecastDebugContext.h"
#include "Runtime/Profiler/Profiler.h"

PROFILER_INFORMATION(gRC_TIMER_BUILD_POLYMESH, "NavMesh.Recast.BuildPolyMesh", kProfilerAI);
PROFILER_INFORMATION(gRC_TIMER_BUILD_POLYMESHDETAIL, "NavMesh.Recast.BuildPolyMeshDetail", kProfilerAI);
PROFILER_INFORMATION(gRC_TIMER_MERGE_POLYMESHDETAIL, "NavMesh.Recast.MergePolyMeshDetail", kProfilerAI);
PROFILER_INFORMATION(gRC_TIMER_BUILD_CONTOURS, "NavMesh.Recast.BuildContours", kProfilerAI);
PROFILER_INFORMATION(gRC_TIMER_BUILD_REGIONS, "NavMesh.Recast.BuildRegions", kProfilerAI);
PROFILER_INFORMATION(gRC_TIMER_BUILD_REGIONS_FILTER, "NavMesh.Recast.BuildRegionsFilter", kProfilerAI);
PROFILER_INFORMATION(gRC_TIMER_BUILD_COMPACTHEIGHTFIELD, "NavMesh.Recast.BuildCompactHeightfield", kProfilerAI);
PROFILER_INFORMATION(gRC_TIMER_ERODE_AREA, "NavMesh.Recast.ErodeArea", kProfilerAI);
PROFILER_INFORMATION(gRC_TIMER_FILTER_BORDER, "NavMesh.Recast.FilterBorder", kProfilerAI);
PROFILER_INFORMATION(gRC_TIMER_FILTER_WALKABLE, "NavMesh.Recast.FilterWalkable", kProfilerAI);
PROFILER_INFORMATION(gRC_TIMER_RASTERIZE_TRIANGLES, "NavMesh.Recast.RasterizeTriangles", kProfilerAI);


void RecastDebugContext::doStartTimer(const rcTimerLabel label)
{
    switch (label)
    {
        case RC_TIMER_RASTERIZE_TRIANGLES:
            PROFILER_BEGIN(gRC_TIMER_RASTERIZE_TRIANGLES, NULL); break;
        case RC_TIMER_FILTER_BORDER:
            PROFILER_BEGIN(gRC_TIMER_FILTER_BORDER, NULL); break;
        case RC_TIMER_FILTER_WALKABLE:
            PROFILER_BEGIN(gRC_TIMER_FILTER_WALKABLE, NULL); break;
        case RC_TIMER_BUILD_COMPACTHEIGHTFIELD:
            PROFILER_BEGIN(gRC_TIMER_BUILD_COMPACTHEIGHTFIELD, NULL); break;
        case RC_TIMER_ERODE_AREA:
            PROFILER_BEGIN(gRC_TIMER_ERODE_AREA, NULL); break;
        case RC_TIMER_BUILD_REGIONS:
            PROFILER_BEGIN(gRC_TIMER_BUILD_REGIONS, NULL); break;
        case RC_TIMER_BUILD_REGIONS_FILTER:
            PROFILER_BEGIN(gRC_TIMER_BUILD_REGIONS_FILTER, NULL); break;
        case RC_TIMER_BUILD_CONTOURS:
            PROFILER_BEGIN(gRC_TIMER_BUILD_CONTOURS, NULL); break;
        case RC_TIMER_BUILD_POLYMESH:
            PROFILER_BEGIN(gRC_TIMER_BUILD_POLYMESH, NULL); break;
        case RC_TIMER_BUILD_POLYMESHDETAIL:
            PROFILER_BEGIN(gRC_TIMER_BUILD_POLYMESHDETAIL, NULL); break;
        case RC_TIMER_MERGE_POLYMESHDETAIL:
            PROFILER_BEGIN(gRC_TIMER_MERGE_POLYMESHDETAIL, NULL); break;
        default: break;
    }
}

void RecastDebugContext::doStopTimer(const rcTimerLabel label)
{
    switch (label)
    {
        case RC_TIMER_RASTERIZE_TRIANGLES:
            PROFILER_END(gRC_TIMER_RASTERIZE_TRIANGLES); break;
        case RC_TIMER_FILTER_BORDER:
            PROFILER_END(gRC_TIMER_FILTER_BORDER); break;
        case RC_TIMER_FILTER_WALKABLE:
            PROFILER_END(gRC_TIMER_FILTER_WALKABLE); break;
        case RC_TIMER_BUILD_COMPACTHEIGHTFIELD:
            PROFILER_END(gRC_TIMER_BUILD_COMPACTHEIGHTFIELD); break;
        case RC_TIMER_ERODE_AREA:
            PROFILER_END(gRC_TIMER_ERODE_AREA); break;
        case RC_TIMER_BUILD_REGIONS_FILTER:
            PROFILER_END(gRC_TIMER_BUILD_REGIONS_FILTER); break;
        case RC_TIMER_BUILD_REGIONS:
            PROFILER_END(gRC_TIMER_BUILD_REGIONS); break;
        case RC_TIMER_BUILD_CONTOURS:
            PROFILER_END(gRC_TIMER_BUILD_CONTOURS); break;
        case RC_TIMER_BUILD_POLYMESH:
            PROFILER_END(gRC_TIMER_BUILD_POLYMESH); break;
        case RC_TIMER_BUILD_POLYMESHDETAIL:
            PROFILER_END(gRC_TIMER_BUILD_POLYMESHDETAIL); break;
        case RC_TIMER_MERGE_POLYMESHDETAIL:
            PROFILER_END(gRC_TIMER_MERGE_POLYMESHDETAIL); break;
        default: break;
    }
}

#endif
