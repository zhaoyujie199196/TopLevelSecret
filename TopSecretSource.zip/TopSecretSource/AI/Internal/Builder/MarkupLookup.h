#pragma once
#if ENABLE_RUNTIME_NAVMESH_BUILDING

#include "Runtime/Transform/Transform.h"
#include "Runtime/Utilities/vector_map.h"

class MarkupLookup
{
public:
    MarkupLookup(int defaultAreaType) : m_DefaultAreaType(defaultAreaType) {}
    ~MarkupLookup() {}

    void AddIgnore(int instanceID);
    void AddAreaType(int instanceID, int type);

    // Potentially mutates the lookup map for faster subsequent lookups
    bool IgnoreFromBuild(const Transform* t);
    int GetAreaType(const Transform* t);

private:
    typedef UNITY_VECTOR_MAP (kMemTempAlloc, int, bool) InstanceIDToBool;
    typedef UNITY_VECTOR_MAP (kMemTempAlloc, int, int) InstanceIDToArea;

    const int m_DefaultAreaType;
    InstanceIDToBool m_Ignore;
    InstanceIDToArea m_AreaType;
};


void MarkupLookup::AddIgnore(int instanceID)
{
    AssertMsg(dynamic_instanceID_cast<Transform*>(instanceID) != NULL, "MarkupLookup expects a valid Transform instanceID");
    m_Ignore[instanceID] = true;
}

void MarkupLookup::AddAreaType(int instanceID, int type)
{
    AssertMsg(dynamic_instanceID_cast<Transform*>(instanceID) != NULL, "MarkupLookup expects a valid Transform instanceID");
    m_AreaType[instanceID] = type;
}

bool MarkupLookup::IgnoreFromBuild(const Transform* t)
{
    if (m_Ignore.empty())
        return false;

    dynamic_array<int> hierarchy(kMemTempAlloc);
    bool ignore = false;

    while (t)
    {
        const int instanceID = t->GetInstanceID();
        InstanceIDToBool::const_iterator it = m_Ignore.find(instanceID);
        if (it != m_Ignore.end())
        {
            ignore = it->second;
            break;
        }

        hierarchy.push_back(instanceID);
        t = t->GetParent();
    }

    // Store results along the hierarchy to speed up lookup.
    for (size_t i = 0; i < hierarchy.size(); i++)
        m_Ignore[hierarchy[i]] = ignore;

    return ignore;
}

int MarkupLookup::GetAreaType(const Transform* t)
{
    if (m_AreaType.empty())
        return m_DefaultAreaType;

    dynamic_array<int> hierarchy(kMemTempAlloc);
    int area = m_DefaultAreaType;

    while (t)
    {
        const int instanceID = t->GetInstanceID();
        InstanceIDToArea::const_iterator it = m_AreaType.find(instanceID);
        if (it != m_AreaType.end())
        {
            area = it->second;
            break;
        }

        hierarchy.push_back(instanceID);
        t = t->GetParent();
    }

    // Store results along the hierarchy to speed up lookup.
    for (size_t i = 0; i < hierarchy.size(); i++)
        m_AreaType[hierarchy[i]] = area;

    return area;
}

#endif
