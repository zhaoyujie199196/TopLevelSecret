#pragma once
#if ENABLE_RUNTIME_NAVMESH_BUILDING

#include "Runtime/AI/Internal/NavMeshBindingTypes.h"
#include "Runtime/AI/Internal/NavMeshBuildSettings.h"
#include "Runtime/Utilities/dynamic_array.h"

class JobQueue;
class NavMeshData;
class NavMeshBuildOperation;
class AsyncOperation;
class Transform;

class NavMeshBuildManager
{
public:
    NavMeshBuildManager() : m_JobQueue(NULL), m_AsyncOperations(kMemAI) {}
    virtual ~NavMeshBuildManager();

    void UpdateAsyncOperations();
    void ReleaseAsyncOperations();

    void Purge(const NavMeshData* data);

    // Used for Script API
    static AsyncOperation* UpdateNavMeshDataAsync(NavMeshData* data, const NavMeshBuildSettings& buildSettings,
        const NavMeshBuildSource* sources, size_t nsources, const AABB& localBounds,
        const NavMeshBuildDebugSettings& debug);

    static bool UpdateNavMeshData(NavMeshData* data, const NavMeshBuildSettings& buildSettings,
        const NavMeshBuildSource* sources, size_t nsources, const AABB& localBounds,
        const NavMeshBuildDebugSettings& debug);

    static bool CollectSources(int includedLayerMask, const AABB& includedWorldBounds, const Transform* root, bool useBounds, NavMeshCollectGeometry geometry, int defaultAreaType, const NavMeshBuildMarkup* markups, const int markupsCount, dynamic_array<NavMeshBuildSource>& results);

private:
    void ExecuteAsync(NavMeshBuildOperation* op);

    JobQueue* m_JobQueue;
    dynamic_array<NavMeshBuildOperation*> m_AsyncOperations;
};
#endif
