#pragma once
#if ENABLE_RUNTIME_NAVMESH_BUILDING
#include "Runtime/AI/Internal/NavMeshBindingTypes.h"

class AABB;
class NavMeshData;
struct NavMeshBuildSettings;

// Opaque struct to be used as a handle. Internally it contains the build state
struct BuildNavMeshInfo;

BuildNavMeshInfo* CreateBuildNavMeshInfo(const NavMeshBuildDebugSettings& debug);
void DestroyBuildNavMeshInfo(BuildNavMeshInfo* info);

void AcquireSharedMeshData(BuildNavMeshInfo* info, const NavMeshBuildSource* sources, size_t nsources,
    const Vector3f& position, const Quaternionf& rotation, const AABB& localBounds);
void ReleaseSharedMeshData(BuildNavMeshInfo* info);

void Cancel(BuildNavMeshInfo* info);

bool Done(const BuildNavMeshInfo* info);

float Progress(const BuildNavMeshInfo* info);

void ScheduleNavMeshDataUpdate(const NavMeshData* data, BuildNavMeshInfo* info,
    const NavMeshBuildSettings& settings, const AABB& localBuildBounds);
void IntegrateNavMeshDataUpdate(NavMeshData* data, BuildNavMeshInfo* info, const AABB& localBounds);

#endif
