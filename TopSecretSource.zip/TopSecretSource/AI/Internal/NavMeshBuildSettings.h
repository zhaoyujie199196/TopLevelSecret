#pragma once
#include "Runtime/Serialize/SerializeUtility.h"

class AABB;

struct NavMeshBuildSettings
{
    DECLARE_SERIALIZE(NavMeshBuildSettings)

    NavMeshBuildSettings();

    int agentTypeID;

    float agentRadius;
    float agentHeight;

    float agentSlope;
    float agentClimb;

    float ledgeDropHeight;
    float maxJumpAcrossDistance;

    // Advanced
    float minRegionArea;

    int manualCellSize;
    float cellSize;

    int manualTileSize;
    int tileSize;

    int accuratePlacement;

    // Configuration limits
    static float kMinAgentRadius;
    static float kMinAgentHeight;
    static float kMaxSlopeAngle;
    static float kMinCellSize;
};

void ValidateNavMeshBuildSettings(NavMeshBuildSettings& validated, std::vector<core::string>* errors,
    const NavMeshBuildSettings& settings, const AABB& buildBounds);
