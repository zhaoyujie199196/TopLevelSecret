#pragma once

#include "Runtime/Geometry/AABB.h"
#include "Runtime/Math/Matrix4x4.h"
#include "Runtime/Math/Vector3.h"
#include "Runtime/Scripting/ScriptingTypes.h"

class NavMeshPath;

// Keep this enum in sync with the one defined in "NavMeshAgent.bindings"
enum ObstacleAvoidanceType
{
    kNoObstacleAvoidance = 0,
    kLowQualityObstacleAvoidance = 1,
    kMedQualityObstacleAvoidance = 2,
    kGoodQualityObstacleAvoidance = 3,
    kHighQualityObstacleAvoidance = 4
};

// Keep this struct in sync with the one defined in "NavMesh.bindings"
struct NavMeshHit
{
    Vector3f position;
    Vector3f normal;
    float    distance;
    int      mask;
    int      hit;
};

// Keep this struct in sync with the one defined in "NavMesh.bindings"
enum NavMeshPathStatus
{
    kPathComplete = 0,
    kPathPartial = 1,
    kPathInvalid = 2
};

// Keep this enum in sync with the one defined in "NavMesh.bindings"
enum OffMeshLinkType
{
    kLinkTypeManual = 0,
    kLinkTypeDropDown = 1,
    kLinkTypeJumpAcross = 2
};

// Keep this enum in sync with the one defined in "NavMesh.bindings"
enum NavMeshBuildSourceShape
{
    kNavMeshBuildSourceMesh = 0,
    kNavMeshBuildSourceTerrain = 1,
    kNavMeshBuildSourceBox = 2,
    kNavMeshBuildSourceSphere = 3,
    kNavMeshBuildSourceCapsule = 4,
    kNavMeshBuildSourceModifierBox = 5
};

// Keep this struct in sync with the one defined in "NavMesh.bindings"
struct OffMeshLinkData
{
    int m_Valid;
    int m_Activated;
    int m_InstanceID;
    OffMeshLinkType m_LinkType;
    Vector3f m_StartPos;
    Vector3f m_EndPos;
};

// Keep this enum in sync with the one defined in "NavMesh.bindings"
// TODO: find a way to share with OffMeshLinkData. The current problem is
// that OffMeshLinkData is read-only and also has a link to OffMeshLink component via instance ID.
struct NavMeshLinkData
{
    Vector3f m_StartPosition;
    Vector3f m_EndPosition;
    float m_CostModifier;
    int m_Bidirectional;
    float m_Width;
    int m_Area;
    int m_AgentTypeID;
};

// Used in: NavMesh.bindings, NavMeshAgent.bindings, NavMeshPath.bindings
struct MonoNavMeshPath
{
    MonoNavMeshPath()
        : native(NULL)
        , corners(SCRIPTING_NULL)
    {}

    NavMeshPath* native;
    ScriptingArrayPtr corners;
};

// Keep this enum in sync with the one defined in "NavMeshObstacle.bindings"
enum NavMeshObstacleShape
{
    kObstacleShapeCapsule = 0,
    kObstacleShapeBox = 1
};

// Keep this enum in sync with the one defined in "NavMeshObstacle.bindings"
enum NavMeshObstacleState
{
    kObstacleStationary = 0,
    kObstacleMoving = 1
};

struct NavMeshTriangulation
{
    ScriptingArrayPtr vertices;
    ScriptingArrayPtr indices;
    ScriptingArrayPtr areas;
};


// Keep this struct in sync with the one defined in "NavMesh.bindings"
struct NavMeshBuildSource
{
    Matrix4x4f transform;
    Vector3f size;
    NavMeshBuildSourceShape shape;
    int areaType;
    int instanceID;
    int componentID;
};

// Keep this enum in sync with the one defined in "NavMesh.bindings"
enum NavMeshCollectGeometry
{
    RenderMeshes = 0,
    PhysicsColliders = 1
};

// Keep this struct in sync with the one defined in "NavMesh.bindings"
struct NavMeshBuildMarkup
{
    int overrideArea;
    int area;
    int ignoreFromBuild;
    int instanceID;
};

// Keep this struct in sync with the one defined in "NavMesh.bindings"
struct NavMeshBuildDebugSettings
{
    inline bool HasShowFlags() const
    {
        return showInputGeom ||
            showVoxels ||
            showRegions ||
            showRawContours ||
            showContours ||
            showPolyMesh ||
            showPolyMeshDetail;
    }

    int showInputGeom;
    int showVoxels;
    int showRegions;
    int showRawContours;
    int showContours;
    int showPolyMesh;
    int showPolyMeshDetail;
    int useFocus;
    Vector3f focusPoint;
};
