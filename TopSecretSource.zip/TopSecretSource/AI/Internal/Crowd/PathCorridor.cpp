//
// Copyright (c) 2009-2010 Mikko Mononen memon@inside.org
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//

// The original source code has been modified by Unity Technologies

#include "UnityPrefix.h"
#include "Runtime/Math/Vector3.h"
#include "PathCorridor.h"
#include "../MathUtil.h"
#include "../NavMesh/NavMeshQuery.h"

#include <string.h>


int MergeCorridorStartMoved(NavMeshPolyRef* path, const int npath, const int maxPath,
    const NavMeshPolyRef* visited, const int nvisited)
{
    int furthestPath = -1;
    int furthestVisited = -1;

    // Find furthest common polygon.
    for (int i = npath - 1; i >= 0; --i)
    {
        bool found = false;
        for (int j = nvisited - 1; j >= 0; --j)
        {
            if (path[i] == visited[j])
            {
                furthestPath = i;
                furthestVisited = j;
                found = true;
            }
        }
        if (found)
            break;
    }

    // If no intersection found just return current path.
    if (furthestPath == -1 || furthestVisited == -1)
        return npath;

    // Concatenate paths.

    // Adjust beginning of the buffer to include the visited.
    const int req = nvisited - furthestVisited;
    const int orig = std::min(furthestPath + 1, npath);
    int size = std::max(0, npath - orig);
    if (req + size > maxPath)
        size = maxPath - req;
    if (size)
        memmove(path + req, path + orig, size * sizeof(NavMeshPolyRef));

    // Store visited
    for (int i = 0; i < req; ++i)
        path[i] = visited[(nvisited - 1) - i];

    return req + size;
}

int MergeCorridorEndMoved(NavMeshPolyRef* path, const int npath, const int maxPath,
    const NavMeshPolyRef* visited, const int nvisited)
{
    int furthestPath = -1;
    int furthestVisited = -1;

    // Find furthest common polygon.
    for (int i = 0; i < npath; ++i)
    {
        bool found = false;
        for (int j = nvisited - 1; j >= 0; --j)
        {
            if (path[i] == visited[j])
            {
                furthestPath = i;
                furthestVisited = j;
                found = true;
            }
        }
        if (found)
            break;
    }

    // If no intersection found just return current path.
    if (furthestPath == -1 || furthestVisited == -1)
        return npath;

    // Concatenate paths.
    const int ppos = furthestPath + 1;
    const int vpos = furthestVisited + 1;
    const int count = std::min(nvisited - vpos, maxPath - ppos);
    DebugAssert(ppos + count <= maxPath);
    if (count)
        memcpy(path + ppos, visited + vpos, sizeof(NavMeshPolyRef) * count);

    return ppos + count;
}

int MergeCorridorStartShortcut(NavMeshPolyRef* path, const int npath, const int maxPath,
    const NavMeshPolyRef* visited, const int nvisited)
{
    int furthestPath = -1;
    int furthestVisited = -1;

    // Find furthest common polygon.
    for (int i = npath - 1; i >= 0; --i)
    {
        bool found = false;
        for (int j = nvisited - 1; j >= 0; --j)
        {
            if (path[i] == visited[j])
            {
                furthestPath = i;
                furthestVisited = j;
                found = true;
            }
        }
        if (found)
            break;
    }

    // If no intersection found just return current path.
    if (furthestPath == -1 || furthestVisited == -1)
        return npath;

    // Concatenate paths.

    // Adjust beginning of the buffer to include the visited.
    const int req = furthestVisited;
    if (req <= 0)
        return npath;

    const int orig = furthestPath;
    int size = std::max(0, npath - orig);
    if (req + size > maxPath)
        size = maxPath - req;
    if (size)
        memmove(path + req, path + orig, size * sizeof(NavMeshPolyRef));

    // Store visited
    for (int i = 0; i < req; ++i)
        path[i] = visited[i];

    return req + size;
}

PathCorridor::PathCorridor() :
    m_path(kMemAI),
    m_pathCount(0),
    m_stateFlags(0),
    m_timeStamp(0)
{
}

PathCorridor::~PathCorridor()
{
    FreePath();
}

void PathCorridor::FreePath()
{
    m_pathCount = 0;
}

bool PathCorridor::Init(const NavMesh* mesh, const int pathSizeInc)
{
    DebugAssert(mesh);

    m_mesh = mesh;
    m_pathSizeInc = pathSizeInc;
    m_path.resize_uninitialized(pathSizeInc);
    m_pathCount = 0;
    m_stateFlags = kPathCorridorValid;
    m_timeStamp = mesh->GetTimeStamp();
    return true;
}

void PathCorridor::Reset(NavMeshPolyRef ref, const Vector3f& pos)
{
    if (!ref)
    {
        Invalidate();
        return;
    }

    m_path[0] = ref;
    m_pathCount = 1;
    m_pos = pos;
    m_target = pos;
    m_stateFlags = kPathCorridorValid;
    m_timeStamp = m_mesh->GetTimeStamp();
}

void PathCorridor::Invalidate()
{
    // Preserve the position and target
    m_path[0] = 0;
    m_pathCount = 1;
    m_stateFlags = 0;
    m_timeStamp = m_mesh->GetTimeStamp();
}

void PathCorridor::SetToEnd()
{
    DebugAssert(m_pathCount);

    m_pos = m_target;
    m_path[0] = m_path[m_pathCount - 1];
    m_pathCount = 1;
}

NavMeshStatus PathCorridor::FindCorners(Vector3f* cornerVerts, unsigned char* cornerFlags,
    NavMeshPolyRef* cornerPolys, int* cornerCount, const int maxCorners,
    const NavMeshQuery* navquery) const
{
    DebugAssert(m_pathCount);

    static const float kMinTargetDistSq = 0.0001f;

    int ncorners = 0;
    NavMeshStatus status = navquery->FindStraightPath(m_pos, m_target, m_path.begin(), m_pathCount,
            cornerVerts, cornerFlags, cornerPolys, &ncorners, maxCorners);
    if (!ncorners)
    {
        *cornerCount = 0;
        return kNavMeshSuccess;
    }

    // Prune points in the beginning of the path which are too close.
    int prune;
    for (prune = 0; prune < ncorners; ++prune)
    {
        if ((cornerFlags[prune] & kStraightPathOffMeshConnection) || SqrDistance2D(cornerVerts[prune], m_pos) > kMinTargetDistSq)
            break;
    }
    ncorners -= prune;
    if (prune && ncorners)
    {
        memmove(cornerFlags, cornerFlags + prune, sizeof(unsigned char) * ncorners);
        memmove(cornerPolys, cornerPolys + prune, sizeof(NavMeshPolyRef) * ncorners);
        memmove(cornerVerts, cornerVerts + prune, sizeof(Vector3f) * ncorners);
    }

    // Prune points after an off-mesh connection.
    for (prune = 0; prune < ncorners; ++prune)
    {
        if (cornerFlags[prune] & kStraightPathOffMeshConnection)
        {
            ncorners = prune + 1;
            break;
        }
    }

    *cornerCount = ncorners;

    if (NavMeshStatusDetail(status, kNavMeshPartialResult))
        return kNavMeshSuccess | kNavMeshPartialResult;

    return kNavMeshSuccess;
}

void PathCorridor::OptimizePathVisibility(const Vector3f& next, const NavMeshQuery* navquery, const QueryFilter* filter)
{
    const int kMaxResults = 32;
    NavMeshPolyRef res[kMaxResults];
    int nres = 0;
    NavMeshRaycastResult result;
    navquery->Raycast(m_path[0], m_pos, next, filter, &result, res, &nres, kMaxResults);
    if (nres > 1 && result.t > 0.99f)
    {
        m_pathCount = MergeCorridorStartShortcut(m_path.begin(), m_pathCount, m_path.size(), res, nres);
    }
}

bool PathCorridor::OptimizePathTopology(NavMeshQuery* navquery, const QueryFilter* filter)
{
    if (m_pathCount < 3)
        return false;

    static const int kMaxIterations = 8;
    static const int kMaxResults = 8;

    NavMeshPolyRef res[kMaxResults];
    int nres = 0;

    NavMeshStatus status = navquery->InitSlicedFindPath(m_path[0], m_path[m_pathCount - 1], m_pos, m_target, filter);

    if (!NavMeshStatusFailed(status))
        status = navquery->UpdateSlicedFindPath(kMaxIterations, NULL);

    if (NavMeshStatusSucceed(status))   // dont accept kNavMeshInProgress
    {
        status = navquery->FinalizeSlicedFindPathPartial(&nres, m_path.begin(), m_pathCount);
        if (NavMeshStatusSucceed(status))
            status = navquery->GetPath(res, &nres, kMaxResults);
    }

    if (NavMeshStatusSucceed(status) && nres > 0)
    {
        m_pathCount = MergeCorridorStartShortcut(m_path.begin(), m_pathCount, m_path.size(), res, nres);
        return true;
    }

    return false;
}

bool PathCorridor::MoveOverOffmeshConnection(NavMeshPolyRef offMeshConRef, const Vector3f& currentPos,
    Vector3f& startPos, Vector3f& endPos,
    const NavMeshQuery* navquery)
{
    DebugAssert(navquery);
    DebugAssert(m_pathCount);

    // Advance the path up to and over the off-mesh connection.
    NavMeshPolyRef prevRef = 0, polyRef = m_path[0], nextRef = 0;
    int npos = 0;
    int npath = m_pathCount;
    while (npos < npath && polyRef != offMeshConRef)
    {
        prevRef = polyRef;
        polyRef = m_path[npos];
        if (npos + 1 < npath)
            nextRef = m_path[npos + 1];
        npos++;
    }
    if (npos == npath)
    {
        // Could not find offMeshConRef
        return false;
    }

    // Prune path
    npath -= npos;
    memmove(m_path.begin(), m_path.begin() + npos, sizeof(NavMeshPolyRef) * npath);
    m_pathCount = npath;

    const NavMesh* nav = navquery->GetAttachedNavMesh();
    DebugAssert(nav);

    const OffMeshConnection* conn = nav->GetOffMeshConnection(polyRef);
    if (conn == NULL)
        return false;

    if (conn->width > 0.0f)
    {
        // Handle wide link
        NavMeshStatus status = nav->GetNearestOffMeshConnectionEndPoints(prevRef, polyRef, nextRef, currentPos, &startPos, &endPos);
        if (NavMeshStatusSucceed(status))
        {
            m_pos = endPos;
            return true;
        }
    }
    else
    {
        NavMeshStatus status = nav->GetOffMeshConnectionEndPoints(prevRef, polyRef, &startPos, &endPos);
        if (NavMeshStatusSucceed(status))
        {
            m_pos = endPos;
            return true;
        }
    }

    return false;
}

// TODO : notify callers  - return  success/failure
void PathCorridor::MovePosition(const Vector3f& newPos, const NavMeshQuery* navquery, const QueryFilter* filter)
{
    DebugAssert(m_pathCount);

    if (SqrDistance2D(newPos, m_pos) == 0.0f)
        return;

    // Move along navmesh and update new position.
    Vector3f result;
    static const int kMaxVisited = 16;
    NavMeshPolyRef visited[kMaxVisited];
    int nvisited = 0;
    NavMeshStatus status = navquery->MoveAlongSurface(m_path[0], m_pos, newPos, filter,
            &result, visited, &nvisited, kMaxVisited);
    if (NavMeshStatusFailed(status))
    {
        SetPathValid(false);
        return;
    }
    m_pathCount = MergeCorridorStartMoved(m_path.begin(), m_pathCount, m_path.size(), visited, nvisited);

    // Adjust the position to stay on top of the navmesh.
    navquery->ProjectToPoly(&m_pos, m_path[0], result);
}

bool PathCorridor::UpdateTargetPosition(const NavMeshPolyRef ref, const Vector3f& target)
{
    if (ref != GetLastPoly() || IsPathStale())
        return false;

    m_target = target;

    return true;
}

void PathCorridor::SetCorridor(const Vector3f& target, const NavMeshQuery* navquery, const NavMeshPolyRef* path, const int npath, bool partialPath)
{
    DebugAssert(npath > 0);

    // Resize path if necessary.
    if (npath > m_path.size())
    {
        int cap = ((npath + m_pathSizeInc - 1) / m_pathSizeInc) * m_pathSizeInc;
        m_path.resize_uninitialized(cap);
    }

    m_target = target;
    memcpy(m_path.begin(), path, sizeof(NavMeshPolyRef) * npath);
    m_pathCount = npath;
    m_stateFlags = npath ? kPathCorridorValid : 0;
    SetPathPartial(partialPath);

    // Adjust the position to stay on top of the navmesh.
    navquery->ProjectToPoly(&m_target, m_path[m_pathCount - 1], target);
}

void PathCorridor::SetStateFlag(bool setFlag, unsigned char stateFlag)
{
    if (setFlag)
        m_stateFlags |= stateFlag;
    else
        m_stateFlags &= ~stateFlag;
}

bool PathCorridor::IsPathStale() const
{
    return m_timeStamp == 0 || m_timeStamp != m_mesh->GetTimeStamp();
}

void PathCorridor::SetPathValid(bool inbool)
{
    SetStateFlag(inbool, kPathCorridorValid);
}

void PathCorridor::SetPathPartial(bool inbool)
{
    SetStateFlag(inbool, kPathCorridorPartial);
}

void PathCorridor::SetPathStale(bool inbool)
{
    if (inbool)
        m_timeStamp = 0;
    else
        m_timeStamp = m_mesh->GetTimeStamp();
}
