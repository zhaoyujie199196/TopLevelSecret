//
// Copyright (c) 2009-2010 Mikko Mononen memon@inside.org
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//

// The original source code has been modified by Unity Technologies

#pragma once

#include "Runtime/Math/Vector3.h"
#include "Runtime/Utilities/dynamic_array.h"

#include "../NavMesh/NavMeshTypes.h"

class QueryFilter;
class NavMeshQuery;
class NavMesh;

enum PathCorridorState
{
    kPathCorridorValid = 1 << 0,
    kPathCorridorPartial = 1 << 1
};

class PathCorridor
{
    Vector3f m_pos;
    Vector3f m_target;

    const NavMesh* m_mesh;
    dynamic_array<NavMeshPolyRef> m_path;
    int m_pathCount;
    int m_pathSizeInc;
    unsigned char m_stateFlags;
    unsigned int m_timeStamp;

    void SetStateFlag(bool setFlag, unsigned char stateFlag);

public:
    PathCorridor();
    ~PathCorridor();

    void FreePath();
    bool Init(const NavMesh* mesh, const int pathSizeInc);

    void Reset(NavMeshPolyRef ref, const Vector3f& pos);
    void Invalidate();
    void SetToEnd();

    NavMeshStatus FindCorners(Vector3f* cornerVerts, unsigned char* cornerFlags,
        NavMeshPolyRef* cornerPolys, int* cornerCount,  const int maxCorners,
        const NavMeshQuery* navquery) const;

    void OptimizePathVisibility(const Vector3f& next, const NavMeshQuery* navquery, const QueryFilter* filter);

    bool OptimizePathTopology(NavMeshQuery* navquery, const QueryFilter* filter);

    bool MoveOverOffmeshConnection(NavMeshPolyRef offMeshConRef, const Vector3f& currentPos,
        Vector3f& startPos, Vector3f& endPos,
        const NavMeshQuery* navquery);

    void MovePosition(const Vector3f& newPos, const NavMeshQuery* navquery, const QueryFilter* filter);
    bool UpdateTargetPosition(const NavMeshPolyRef ref, const Vector3f& target);

    void SetCorridor(const Vector3f& target, const NavMeshQuery* navquery, const
        NavMeshPolyRef* path, const int npath, bool partialPath = false);

    inline const Vector3f& GetPos() const { return m_pos; }
    inline const Vector3f& GetTarget() const { return m_target; }

    inline NavMeshPolyRef GetFirstPoly() const { return m_pathCount ? m_path[0] : 0; }
    inline NavMeshPolyRef GetLastPoly() const { return m_pathCount ? m_path[m_pathCount - 1] : 0; }

    inline const NavMeshPolyRef* GetPath() const { return m_path.begin(); }
    inline int GetPathCount() const { return m_pathCount; }

    inline bool IsPathValid() const { return (m_stateFlags & kPathCorridorValid); }
    inline bool IsPathPartial() const { return (m_stateFlags & kPathCorridorPartial) != 0; }
    bool IsPathStale() const;
    void SetPathValid(bool inbool);
    void SetPathStale(bool inbool);
    void SetTimeStamp(unsigned int timeStamp) {m_timeStamp = timeStamp; }
    void SetPathPartial(bool inbool);
};

int MergeCorridorStartMoved(NavMeshPolyRef* path, const int npath, const int maxPath,
    const NavMeshPolyRef* visited, const int nvisited);

int MergeCorridorEndMoved(NavMeshPolyRef* path, const int npath, const int maxPath,
    const NavMeshPolyRef* visited, const int nvisited);

int MergeCorridorStartShortcut(NavMeshPolyRef* path, const int npath, const int maxPath,
    const NavMeshPolyRef* visited, const int nvisited);
