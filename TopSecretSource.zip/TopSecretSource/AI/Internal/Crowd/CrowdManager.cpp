//
// Copyright (c) 2009-2010 Mikko Mononen memon@inside.org
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//

// The original source code has been modified by Unity Technologies

#include "UnityPrefix.h"
#include "./CrowdManager.h"
#include "./CrowdTypes.h"
#include "./CrowdUpdate.h"
#include "./ObstacleAvoidanceQuery.h"
#include "./PathQueryInfo.h"
#include "./ProximityGrid.h"
#include "../MathUtil.h"
#include "../NavMesh/NavMesh.h"
#include "../NavMesh/NavMeshQuery.h"
#include "../HeightMesh/HeightMeshQuery.h"
#include "../Obstacles/HullAvoidance.h"

#include "Runtime/Logging/LogAssert.h"
#include "Runtime/Profiler/Profiler.h"

#include <new>
#include <limits>
#include <string.h>
#include <algorithm>

PROFILER_INFORMATION(gNavMeshProximityInsert, "Crowd.Proximity.Insert", kProfilerAI)
PROFILER_INFORMATION(gNavMeshPathfinding, "Crowd.Pathfinding", kProfilerAI)
PROFILER_INFORMATION(gNavMeshPathOptimization, "Crowd.PathOptimization", kProfilerAI)


static const int MAX_COMMON_NODES = 512;
static const int PATH_SIZE_INCREMENT = 32;

static void InvalidateAgentPath(CrowdAgent* ag, NavMeshPolyRef poly, const Vector3f& pos)
{
    ag->corridor.Reset(poly, pos);
    ag->corridor.SetPathValid(false);
    ag->state = kCrowdAgentState_Passive;
    ag->remainingDistance = -1.0f;
}

CrowdManager::CrowdManager() :
    m_MaxAgents(0),
    m_NextFreeAgent(0),
    m_ActiveAgentCount(0),

    m_MaxObstacles(0),
    m_NextFreeObstacle(0),
    m_ActiveObstacleCount(0),

    m_SharedFilter(0),

    m_Agents(kMemAI),
    m_AgentAnims(kMemAI),
    m_AgentFilters(kMemAI),
    m_PathResult(kMemAI),
    m_Obstacles(kMemAI),
    m_MoveRequestQueue(kMemAI),
    m_ActiveAgentIDs(kMemAI),
    m_ActiveObstacleIDs(kMemAI),
    m_PathInfos(kMemAI),

    m_Grid(0),
    m_LogPathInfo(false),
    m_AvoidancePredictionTime(2.0f),
    m_PathfindingIterationsPerFrame(100),
    m_PathRequestRef(0),
    m_MoveRequestQueueCount(0),

    m_NavQuery(0),
    m_HeightMeshQuery(0)
{
}

CrowdManager::~CrowdManager()
{
    Purge();
}

void CrowdManager::Purge()
{
    UNITY_DELETE(m_SharedFilter, kMemAI);

    for (int i = 0; i < m_MaxAgents; ++i)
        m_Agents[i].~CrowdAgent();

    m_MaxAgents = 0;
    m_MaxObstacles = 0;
    m_MoveRequestQueueCount = 0;

    UNITY_DELETE(m_Grid, kMemAI);
    UNITY_DELETE(m_NavQuery, kMemAI);

    for (int i = 0; i < m_PathInfos.size(); i++)
        UNITY_DELETE(m_PathInfos[i], kMemAI);

    FreeStaticQueries();
}

bool CrowdManager::Init(const int maxAgents)
{
    Purge();

    // Init obstacle query params.
    memset(m_ObstacleQueryParams, 0, sizeof(m_ObstacleQueryParams));
    for (int i = 0; i < kMaxObstacleAvoidanceParams; ++i)
    {
        ObstacleAvoidanceParams* params = &m_ObstacleQueryParams[i];
        params->velBias = 0.70f;
        params->weightDesVel = 0.2f;
        params->weightCurVel = 0.1f;
        params->weightToi = 2.0f;
        params->adaptiveDivs = 7;
        params->adaptiveRings = 3;
        params->adaptiveDepth = 3;
    }

    Assert(m_SharedFilter == 0);
    m_SharedFilter = UNITY_NEW(QueryFilter, kMemAI)();

    if (!ReserveAgents(maxAgents))
        return false;
    if (!ReserveObstacles(maxAgents))
        return false;
    m_PathResult.reserve(PATH_SIZE_INCREMENT);

    return true;
}

bool CrowdManager::SetNavMesh(const NavMesh* nav, const HeightMeshQuery* heightMeshQuery, const int nodePoolSize)
{
    if (!m_PathRequest.Init(PATH_SIZE_INCREMENT, nodePoolSize, nav))
        return false;

    // The navquery is mostly used for local searches, no need for large node pool.
    UNITY_DELETE(m_NavQuery, kMemAI);
    m_NavQuery = UNITY_NEW(NavMeshQuery, kMemAI) (nav, std::min(nodePoolSize, MAX_COMMON_NODES));
    if (!m_NavQuery)
        return false;

    FreeStaticQueries();
    AllocateStaticQueries(nav);

    m_HeightMeshQuery = heightMeshQuery;

    return true;
}

bool CrowdManager::ReserveAgents(int agentCount)
{
    if (agentCount <= m_MaxAgents)
        return false;

    m_Agents.resize_initialized(agentCount);
    m_MoveRequestQueue.resize_uninitialized(agentCount);
    m_AgentFilters.resize_uninitialized(agentCount);
    m_AgentAnims.resize_uninitialized(agentCount);
    m_ActiveAgentIDs.resize_uninitialized(agentCount);

    for (int i = m_MaxAgents; i < agentCount; ++i)
    {
        m_Agents[i].active = 0;
        m_AgentAnims[i].polyRef = 0;
        m_Agents[i].nextFreeAgent = i + 1;
        m_Agents[i].salt = 1;
    }

    m_NextFreeAgent = m_MaxAgents;
    m_MaxAgents = agentCount;
    ResizeProximityGrid();
    return true;
}

bool CrowdManager::ReserveObstacles(int obstacleCount)
{
    if (obstacleCount <= m_MaxObstacles)
        return true;

    m_Obstacles.resize_uninitialized(obstacleCount);
    m_ActiveObstacleIDs.resize_uninitialized(obstacleCount);

    for (int i = m_MaxObstacles; i < obstacleCount; ++i)
    {
        m_Obstacles[i].type = kObstacleTypeUnused;
        m_Obstacles[i].nextFreeObstacle = i + 1;
        m_Obstacles[i].salt = 1;
    }

    m_NextFreeObstacle = m_MaxObstacles;
    m_MaxObstacles = obstacleCount;
    ResizeProximityGrid();
    return true;
}

void CrowdManager::SetObstacleAvoidanceParams(const int idx, const ObstacleAvoidanceParams* params)
{
    Assert(idx >= 0 && idx < kMaxObstacleAvoidanceParams);
    memcpy(&m_ObstacleQueryParams[idx], params, sizeof(ObstacleAvoidanceParams));
}

const ObstacleAvoidanceParams* CrowdManager::GetObstacleAvoidanceParams(const int idx) const
{
    Assert(idx >= 0 && idx < kMaxObstacleAvoidanceParams);
    return &m_ObstacleQueryParams[idx];
}

const CrowdAgentAnimation* CrowdManager::GetAgentAnimation(const CrowdRef agentRef) const
{
    const CrowdAgent* agent = GetAgentByRef(agentRef);
    if (agent == NULL)
        return NULL;
    Assert(agent->active == 1);
    const int idx = GetAgentIndex(agent);
    return &m_AgentAnims[idx];
}

void CrowdManager::SetAgentAnimationPolyRef(const CrowdRef agentRef, NavMeshPolyRef polyRef)
{
    const CrowdAgent* agent = GetAgentByRef(agentRef);
    if (agent == NULL)
        return;
    Assert(agent->active == 1);
    const int idx = GetAgentIndex(agent);
    m_AgentAnims[idx].polyRef = polyRef;
}

const CrowdAgent* CrowdManager::GetAgentByRef(const CrowdRef agentRef) const
{
    unsigned int salt = 0, index = 0, type = 0;
    DecodeCrowdId(&salt, &index, &type, agentRef);
    if (type != kCrowdAgent)
        return NULL;
    if (index >= m_MaxAgents)
        return NULL;
    if (salt != m_Agents[index].salt)
        return NULL;
    return &m_Agents[index];
}

CrowdAgent* CrowdManager::GetMutableAgentByRef(CrowdRef agentRef)
{
    unsigned int salt = 0, index = 0, type = 0;
    DecodeCrowdId(&salt, &index, &type, agentRef);
    if (type != kCrowdAgent)
        return NULL;
    if (index >= m_MaxAgents)
        return NULL;
    if (salt != m_Agents[index].salt)
        return NULL;
    return &m_Agents[index];
}

CrowdRef CrowdManager::GetAgentRef(const CrowdAgent* agent) const
{
    Assert(agent != NULL);
    return EncodeCrowdId(agent->salt, GetAgentIndex(agent), kCrowdAgent);
}

void CrowdManager::UpdateAgentParameters(const CrowdRef agentRef, const CrowdAgentParams* params)
{
    CrowdAgent* agent = GetMutableAgentByRef(agentRef);
    if (agent == NULL)
        return;

    memcpy(&agent->params, params, sizeof(CrowdAgentParams));
}

void CrowdManager::UpdateAgentFilter(const CrowdRef agentRef, unsigned int areaMask, int typeID)
{
    CrowdAgent* agent = GetMutableAgentByRef(agentRef);
    if (agent == NULL)
        return;

    const int agentIdx = GetAgentIndex(agent);
    QueryFilter& filter = m_AgentFilters[agentIdx];

    if (filter.GetTypeID() != typeID)
    {
        // When agent type changes - we need to invalidate the path
        // we attempt to remap the first corridor polygon when resetting
        filter.SetTypeID(typeID);
        NavMeshPolyRef ref;
        Vector3f nearest;
        FindNearestPoly(agent, agent->npos, &ref, &nearest);
        InvalidateAgentPath(agent, ref, nearest);

        return;
    }

    if (filter.GetIncludeFlags() != areaMask)
    {
        filter.SetIncludeFlags(areaMask);
        MarkPathStale(agent);
    }
}

CrowdRef CrowdManager::AddAgent(const Vector3f& pos, unsigned int areaMask, int typeID, const CrowdAgentParams* params)
{
    const NavMesh* navMesh = m_NavQuery->GetAttachedNavMesh();
    if (!navMesh)
        return 0;

    // Find nearest position on navmesh and place the agent there.
    Vector3f nearest;
    NavMeshPolyRef ref;
    QueryFilter filter;
    memcpy(&filter, m_SharedFilter, sizeof(QueryFilter));
    filter.SetIncludeFlags(areaMask);
    filter.SetTypeID(typeID);

    const float queryRange = params->radius;
    const Vector3f ext(20.0f * queryRange, 15.0f * queryRange, 20.0f * queryRange);

    m_NavQuery->FindNearestPoly(pos, ext, &filter, &ref, &nearest);
    if (!ref)
        return 0;

    m_HeightMeshQuery->SetPositionHeight(&nearest);

    // Make room for more agents
    Assert(m_NextFreeAgent >= 0 && m_NextFreeAgent <= m_MaxAgents);
    if (m_NextFreeAgent == m_MaxAgents)
    {
        const int newSize = std::max(2 * m_MaxAgents, 1);
        if (!ReserveAgents(newSize))
            return 0;
    }

    const int idx = m_NextFreeAgent;
    CrowdAgent* agent = &m_Agents[idx];
    Assert(m_Agents[idx].active == 0);

    if (!agent->corridor.Init(navMesh, PATH_SIZE_INCREMENT))
        return 0;

    memcpy(&m_AgentFilters[idx], m_SharedFilter, sizeof(QueryFilter));
    m_AgentFilters[idx].SetIncludeFlags(areaMask);
    m_AgentFilters[idx].SetTypeID(typeID);

    m_NextFreeAgent = m_Agents[idx].nextFreeAgent;
    Assert(m_NextFreeAgent >= 0 && m_NextFreeAgent <= m_MaxAgents);

    // Internal classes/structs
    agent->corridor.Reset(ref, nearest);
    agent->boundary.Reset();

    // Fixed array counts
    agent->nneis = 0;
    agent->ncorners = 0;

    // Internal vectors
    agent->npos = nearest;
    agent->disp.SetZero();
    agent->dvel.SetZero();
    agent->vel.SetZero();
    agent->nvel.SetZero();
    agent->avel.SetZero();

    // Scalars
    agent->topologyOptTime = 0;
    agent->desiredSpeed = 0;
    agent->remainingDistance = -1.0f;

    // Flags
    agent->state = kCrowdAgentState_Passive;
    agent->active = 1;
    agent->braking = false;
    agent->pendingRequest = false;

    agent->stopExplicit = false;
    agent->requested = false;
    agent->repath = false;

    agent->reqPoly = 0;
    agent->reqStatus = MR_INVALID;
    agent->reqWorldPos = nearest;
#if UNITY_EDITOR
    agent->debugInfo = NULL;
#endif

    CrowdRef agentRef = GetAgentRef(agent);

    UpdateAgentParameters(agentRef, params);

    return agentRef;
}

void CrowdManager::UpdateAgentVelocity(const CrowdRef agentRef, const Vector3f& vel)
{
    CrowdAgent* agent = GetMutableAgentByRef(agentRef);
    if (agent == NULL)
        return;
    Assert(agent->active == 1);

    agent->vel = vel;
}

void CrowdManager::RemoveAgent(const CrowdRef agentRef)
{
    CrowdAgent* agent = GetMutableAgentByRef(agentRef);
    if (agent == NULL)
        return;
    Assert(agent->active == 1);
    const int agentIdx = GetAgentIndex(agent);

    CompleteOffMeshLink(agent, false);
    agent->active = 0;
    agent->corridor.FreePath();

    agent->nextFreeAgent = m_NextFreeAgent;
    m_NextFreeAgent = agentIdx;

    // cleanup moverequest
    if (agent->reqStatus != MR_INVALID)
    {
        int i = 0;
        for (; i < m_MoveRequestQueueCount; ++i)
        {
            if (m_MoveRequestQueue[i] == agentIdx)
                break;
        }
        Assert(i < m_MoveRequestQueueCount);

        if (agent->reqStatus == MR_PROCESSING)
        {
            m_PathRequest.Clear();
            m_PathRequestRef = 0;
        }

        m_MoveRequestQueueCount--;
        if (i != m_MoveRequestQueueCount)
            memmove(&m_MoveRequestQueue[i], &m_MoveRequestQueue[i + 1], sizeof(m_MoveRequestQueue[0]) * (m_MoveRequestQueueCount - i));

        agent->reqStatus = MR_INVALID;
    }

    for (int i = 0; i < m_PathInfos.size(); i++)
    {
        Assert(m_PathInfos[i]);
        if (m_PathInfos[i]->GetAgentRef() == agentRef)
        {
            m_PathInfos[i]->Purge();
            break;
        }
    }

    agent->salt++;
    agent->salt &= (unsigned int)kCrowdRefSaltMask;
    if (agent->salt == 0)
        agent->salt = 1;
}

void CrowdManager::FindNearestPoly(CrowdAgent* agent, const Vector3f& worldPos, NavMeshPolyRef* ref, Vector3f* pos) const
{
    Assert(agent != NULL);
    Assert(agent->active == 1);

    const QueryFilter* filter = GetAgentFilter(agent);
    const float queryRange = agent->params.radius;
    const Vector3f ext(20.0f * queryRange, 15.0f * queryRange, 20.0f * queryRange);

    m_NavQuery->FindNearestPoly(worldPos, ext, filter, ref, pos);
}

bool CrowdManager::RequestMoveTarget(const CrowdRef agentRef, const Vector3f& worldPos)
{
    CrowdAgent* agent = GetMutableAgentByRef(agentRef);
    if (agent == NULL)
        return false;
    return RequestMoveTarget(agent, worldPos);
}

bool CrowdManager::RequestMoveTarget(CrowdAgent* agent, const Vector3f& worldPos)
{
    Assert(agent != NULL);
    Assert(agent->active == 1);
    const int idx = GetAgentIndex(agent);

    agent->reqWorldPos = worldPos;
    agent->requested = true;

    NavMeshPolyRef nearestRef;
    Vector3f nearestPos;

    FindNearestPoly(agent, worldPos, &nearestRef, &nearestPos);


    if (!nearestRef)
    {
        agent->reqPoly = 0;
        return false;
    }

    if (agent->state != kCrowdAgentState_OffMesh)
        agent->state = kCrowdAgentState_Walking;

    if (agent->reqStatus == MR_REQUESTING)
    {
        // Adjust pending request
        agent->reqPoly = nearestRef;
        return true;
    }

    if (agent->reqStatus == MR_PROCESSING)
    {
        // Adjust in flight request - if same end poly
        Assert(m_MoveRequestQueue[0] == idx);
        if (agent->reqPoly == nearestRef)
        {
            return true;
        }

        m_PathRequest.Clear();
        m_PathRequestRef = 0;

        // pop existing request from queue - i.e. down-prioritize new request
        Assert(m_MoveRequestQueueCount);
        m_MoveRequestQueueCount--;
        if (m_MoveRequestQueueCount)
            memmove(&m_MoveRequestQueue[0], &m_MoveRequestQueue[1], sizeof(m_MoveRequestQueue[0]) * m_MoveRequestQueueCount);
    }
    else
    {
        Assert(agent->reqStatus == MR_INVALID);
        // updates the target position only if the poly reference matches the last polygon - and the path isn't stale.
        // returns if update is successful - otherwise we need to schedule a new path request.
        if (agent->corridor.UpdateTargetPosition(nearestRef, nearestPos))
        {
            //after moving the target we need to invalidate the cached remaining distance
            agent->remainingDistance = -1.0f;
            return true;
        }
    }

    // Enqueue a new request
    Assert(m_MoveRequestQueueCount < m_MaxAgents);
    m_MoveRequestQueue[m_MoveRequestQueueCount++] = idx;

    agent->reqPoly = nearestRef;
    agent->reqStatus = MR_REQUESTING;
    agent->pendingRequest = true;
    agent->reqNearestPos = nearestPos;

    return true;
}

void CrowdManager::UpdateAgentFilterCost(const CrowdRef agentRef, int areaIndex, float areaCost)
{
    CrowdAgent* agent = GetMutableAgentByRef(agentRef);
    if (agent == NULL)
        return;
    UpdateAgentFilterCost(agent, areaIndex, areaCost);
}

void CrowdManager::UpdateAgentFilterCost(CrowdAgent* agent, int areaIndex, float areaCost)
{
    Assert(agent != NULL);
    Assert(agent->active == 1);

    QueryFilter& filter = m_AgentFilters[GetAgentIndex(agent)];
    if (filter.GetAreaCost(areaIndex) != areaCost)
    {
        filter.SetAreaCost(areaIndex, areaCost);
        MarkPathStale(agent);
    }
}

void CrowdManager::UpdateFilterCost(int areaIndex, float areaCost)
{
    m_SharedFilter->SetAreaCost(areaIndex, areaCost);
    for (int i = 0; i < m_MaxAgents; ++i)
    {
        if (m_Agents[i].active)
        {
            UpdateAgentFilterCost(&m_Agents[i], areaIndex, areaCost);
        }
    }
}

void CrowdManager::InitializeAgentFilter(const CrowdRef agentRef, const float* areaCost, int areaCount)
{
    CrowdAgent* agent = GetMutableAgentByRef(agentRef);
    if (agent == NULL)
        return;

    QueryFilter& filter = m_AgentFilters[GetAgentIndex(agent)];
    const int count = std::min((int)QueryFilter::kMaxAreas, areaCount);
    for (int i = 0; i < count; ++i)
    {
        filter.SetAreaCost(i, areaCost[i]);
    }
}

bool CrowdManager::IsRefOccupied(const NavMeshPolyRef ref) const
{
    return m_Occupied.find(ref) != m_Occupied.end();
}

void CrowdManager::OccupyRef(const NavMeshPolyRef ref)
{
    m_Occupied.insert(ref);
}

const QueryFilter* CrowdManager::GetAgentFilter(const CrowdRef agentRef) const
{
    const CrowdAgent* agent = GetAgentByRef(agentRef);
    if (agent == NULL)
        return NULL;
    return GetAgentFilter(agent);
}

const QueryFilter* CrowdManager::GetAgentFilter(const CrowdAgent* agent) const
{
    Assert(agent != NULL);
    return &m_AgentFilters[GetAgentIndex(agent)];
}

void CrowdManager::MoveAgent(const CrowdRef agentRef, const Vector3f& pos)
{
    CrowdAgent* agent = GetMutableAgentByRef(agentRef);
    if (agent == NULL)
        return;
    Assert(agent->active == 1);

    if (agent->state == kCrowdAgentState_OffMesh)
    {
        agent->remainingDistance = -1.0f;
        agent->npos = pos;
        return;
    }

    const QueryFilter* filter = GetAgentFilter(agent);

    // Move along navmesh.
    agent->corridor.MovePosition(pos, m_NavQuery, filter);

    // Get valid constrained position back.
    agent->npos = agent->corridor.GetPos();

    m_HeightMeshQuery->SetPositionHeight(&agent->npos);

    agent->remainingDistance = -1.0f;

    if (agent->state == kCrowdAgentState_Passive)
    {
        agent->corridor.Reset(agent->corridor.GetFirstPoly(), agent->corridor.GetPos());
        agent->ncorners = 0;
    }
}

void CrowdManager::CompleteOffMeshLink(const CrowdRef agentRef)
{
    CrowdAgent* agent = GetMutableAgentByRef(agentRef);
    if (agent == NULL)
        return;
    CompleteOffMeshLink(agent, true);
}

void CrowdManager::CompleteOffMeshLink(CrowdAgent* agent, bool moveAgent)
{
    Assert(agent != NULL);
    Assert(agent->active == 1);
    const int idx = GetAgentIndex(agent);

    CrowdAgentAnimation* anim = &m_AgentAnims[idx];
    if (anim->polyRef == 0)
        return;

    Assert(agent->state == kCrowdAgentState_OffMesh);

    m_Occupied.erase(anim->polyRef);

    anim->polyRef = 0;
    agent->state = kCrowdAgentState_Walking;
    agent->remainingDistance = -1.0f;
    if (moveAgent)
    {
        agent->npos = anim->endPos;
    }
}

void CrowdManager::ResetAgentPath(const CrowdRef agentRef)
{
    CrowdAgent* agent = GetMutableAgentByRef(agentRef);
    if (agent == NULL)
        return;
    Assert(agent->active == 1);

    CompleteOffMeshLink(agent, false);
    agent->ncorners = 0;
    agent->pendingRequest = false;
    agent->corridor.Reset(agent->corridor.GetFirstPoly(), agent->npos);
    agent->state = kCrowdAgentState_Passive;
    agent->remainingDistance = -1.0f;
    agent->dvel.SetZero();

    agent->stopExplicit = false;
    agent->requested = false;
    agent->repath = false;
    agent->reqPoly = 0;
    agent->reqWorldPos = agent->npos;
}

bool CrowdManager::HasPath(const CrowdRef agentRef) const
{
    const CrowdAgent* agent = GetAgentByRef(agentRef);
    if (agent == NULL)
        return false;
    return HasPath(agent);
}

bool CrowdManager::HasPath(const CrowdAgent* agent) const
{
    Assert(agent != NULL);
    Assert(agent->active == 1);

    return agent->ncorners > 0 || agent->corridor.GetPathCount() > 1 || m_AgentAnims[GetAgentIndex(agent)].polyRef != 0;
}

float CrowdManager::CalculateRemainingPath(const CrowdRef agentRef) const
{
    const CrowdAgent* agent = GetAgentByRef(agentRef);
    if (agent == NULL)
        return 0.0f;

    if (agent->remainingDistance >= 0)
        return agent->remainingDistance;

    if (agent->state == kCrowdAgentState_OffMesh)
        return std::numeric_limits<float>::infinity();

    NavMeshPolyRef cornerPolys[CrowdAgent::kMaxCorners];
    Vector3f cornerVerts[CrowdAgent::kMaxCorners];
    unsigned char cornerFlags[CrowdAgent::kMaxCorners];
    int ncorners = 0;
    agent->corridor.FindCorners(cornerVerts, cornerFlags, cornerPolys, &ncorners,
        CrowdAgent::kMaxCorners, m_NavQuery);

    return CalculateKnownPathLength(agent->npos, ncorners, cornerFlags, cornerVerts, &agent->corridor);
}

Vector3f CrowdManager::GetMoveTarget(const CrowdRef agentRef)
{
    CrowdAgent* agent = GetMutableAgentByRef(agentRef);
    if (agent == NULL)
        return Vector3f(0.0f, 0.0f, 0.0f);
    Assert(agent->active == 1);
    if (agent->pendingRequest)
        return agent->reqNearestPos;
    else
        return agent->corridor.GetTarget();
}

void CrowdManager::StopExplicit(const CrowdRef agentRef, bool stop)
{
    CrowdAgent* agent = GetMutableAgentByRef(agentRef);
    if (agent == NULL)
        return;
    Assert(agent->active == 1);
    agent->stopExplicit = stop;
}

bool CrowdManager::GetStopExplicit(const CrowdRef agentRef) const
{
    const CrowdAgent* agent = GetAgentByRef(agentRef);
    if (agent == NULL)
        return false;
    Assert(agent->active == 1);
    return agent->stopExplicit;
}

void CrowdManager::SetAgentPath(const CrowdRef agentRef, const Vector3f& sourcePos, const Vector3f& targetPos, const NavMeshPolyRef* polygons, int polygonCount, bool partialPath)
{
    CrowdAgent* agent = GetMutableAgentByRef(agentRef);
    if (agent == NULL)
        return;
    Assert(agent->active == 1);
    const int agentIdx = GetAgentIndex(agent);

    // Since an agent on OffMeshLink is already moved to the poly on the other side (moveOverOffmeshConnection)
    // we here remap the agent to current position. That prevents setAgentPath from teleporting the agent across the OffMeshLink.
    CrowdAgentAnimation* anim = &m_AgentAnims[agentIdx];
    if (anim->polyRef != 0)
    {
        m_Occupied.erase(anim->polyRef);
        anim->polyRef = 0;

        Vector3f nearest;
        NavMeshPolyRef ref;
        FindNearestPoly(agent, agent->npos, &ref, &nearest);

        InvalidateAgentPath(agent, ref, nearest);
    }

    agent->ncorners = 0;

    const NavMeshPolyRef currentPoly = agent->corridor.GetFirstPoly();
    const Vector3f currentPos = agent->npos;

    // Bad input path
    if (polygonCount == 0)
    {
        InvalidateAgentPath(agent, currentPoly, currentPos);
        return;
    }

    // Skip polygons in proposed path - until we find our current polygon.
    int matchingIndex = 0;
    if (currentPoly != 0)
    {
        for (; matchingIndex < polygonCount; ++matchingIndex)
        {
            if (polygons[matchingIndex] == currentPoly)
                break;
        }
    }

    const QueryFilter* filter = GetAgentFilter(agent);
    const NavMesh* navMesh = m_NavQuery->GetAttachedNavMesh();
    for (int i = matchingIndex; i < polygonCount; ++i)
    {
        const unsigned int flags = navMesh->GetPolyFlags(polygons[i]);
        if (!filter->PassFilter(flags))
        {
            InvalidateAgentPath(agent, currentPoly, currentPos);
            return;
        }
    }

    // Assign remaining path
    if (matchingIndex < polygonCount)
    {
        polygonCount -= matchingIndex;
        polygons = &polygons[matchingIndex];
        agent->corridor.SetCorridor(targetPos, m_NavQuery, polygons, polygonCount, partialPath);

        agent->corridor.FindCorners(agent->cornerVerts, agent->cornerFlags, agent->cornerPolys, &agent->ncorners,
            CrowdAgent::kMaxCorners, m_NavQuery);

        agent->state = kCrowdAgentState_Walking;
        agent->remainingDistance = -1.0f;

        agent->reqWorldPos = targetPos;
        agent->reqNearestPos = targetPos;
        return;
    }

    // Attempt to prepend path proposed path.
    agent->corridor.Reset(polygons[0], sourcePos);
    agent->corridor.SetCorridor(targetPos, m_NavQuery, polygons, polygonCount, partialPath);
    agent->corridor.MovePosition(agent->npos, m_NavQuery, filter);

    if (agent->corridor.GetFirstPoly() != currentPoly)
    {
        // Failed to prepend to proposed path
        InvalidateAgentPath(agent, currentPoly, currentPos);
        return;
    }
    agent->corridor.FindCorners(agent->cornerVerts, agent->cornerFlags, agent->cornerPolys, &agent->ncorners,
        CrowdAgent::kMaxCorners, m_NavQuery);
    agent->remainingDistance = -1.0f;
    agent->state = kCrowdAgentState_Walking;

    agent->reqWorldPos = targetPos;
    agent->reqNearestPos = targetPos;
}

void CrowdManager::UpdateMoveRequest()
{
    PROFILER_AUTO(gNavMeshPathfinding, NULL)

    int remIter = m_PathfindingIterationsPerFrame;

    for (int i = 0; i < m_MoveRequestQueueCount; ++i)
    {
        const int idx = m_MoveRequestQueue[i];

        Assert(idx >= 0 && idx < m_MaxAgents);
        CrowdAgent* ag = &m_Agents[idx];

        // If agent is not active or expecting result - invalidate the request.
        if (!ag->active || !ag->pendingRequest)
        {
            if (ag->reqStatus == MR_PROCESSING)
            {
                m_PathRequest.Clear();
                m_PathRequestRef = 0;
            }
            ag->reqStatus = MR_INVALID;
        }

        // Verify and schedule request for processing
        if (ag->reqStatus == MR_REQUESTING)
        {
            Assert(!m_PathRequestRef);

            // Verify or attempt to remap the path req polygon
            // the polygon may have changed since request was issued.
            Vector3f nearestPos;
            FindNearestPoly(ag, ag->reqWorldPos, &ag->reqPoly, &nearestPos);

            if (ag->reqPoly)
            {
                const Vector3f& reqPos = ag->corridor.GetPos();     // The location of the request

                const NavMeshPolyRef* path = ag->corridor.GetPath();
                NavMeshPolyRef reqPath = path[0];

                if (reqPath)
                {
                    const QueryFilter* filter = GetAgentFilter(ag);
                    m_PathRequestRef = m_PathRequest.Request(reqPath, ag->reqPoly, reqPos, nearestPos, filter, m_LogPathInfo);
                }

                if (m_PathRequestRef)
                {
                    ag->reqStatus = MR_PROCESSING;
                    ag->corridor.SetCorridor(reqPos, m_NavQuery, &reqPath, 1);
                }
                else
                {
                    ag->reqStatus = MR_INVALID;
                }
            }
            else
            {
                ag->reqStatus = MR_INVALID;
            }
        }

        if (ag->reqStatus == MR_PROCESSING)
        {
            Assert(m_PathRequestRef);

            int iter = 0;
            m_PathRequest.Update(remIter, &iter);
            remIter -= iter;

            NavMeshStatus pathqStatus = m_PathRequest.GetRequestStatus(m_PathRequestRef);

            if (NavMeshStatusFailed(pathqStatus))
            {
                ag->corridor.SetPathValid(false);
                ag->reqStatus = MR_INVALID;
            }
            else if (NavMeshStatusSucceed(pathqStatus))
            {
                const NavMeshPolyRef* path = ag->corridor.GetPath();
                const int npath = ag->corridor.GetPathCount();
                Assert(npath);


                // Make sure we have enough buffer to hold the results.
                const int maxResultPolys = m_PathRequest.GetRequestPathSize(m_PathRequestRef);
                if (maxResultPolys > m_PathResult.size())
                {
                    int cap = ((maxResultPolys + PATH_SIZE_INCREMENT - 1) / PATH_SIZE_INCREMENT) * PATH_SIZE_INCREMENT;
                    m_PathResult.resize_uninitialized(cap);
                }

                NavMeshPolyRef* res = m_PathResult.begin();
                const int maxRes = m_PathResult.size();

                bool valid = true;
                int nres = 0;
                unsigned int timeStamp = 0;
                PathQueryInfo* pathInfo = 0;
                if (m_LogPathInfo)
                    pathInfo = UNITY_NEW(PathQueryInfo, kMemAI);

                Vector3f targetPos;
                NavMeshStatus status = m_PathRequest.GetPathResult(m_PathRequestRef, m_PathResult.begin()
                        , &nres, &targetPos, &timeStamp, pathInfo, maxRes);

                if (NavMeshStatusFailed(status) || !nres)
                    valid = false;

                if (pathInfo)
                {
                    const CrowdRef agentRef = GetAgentRef(ag);
                    pathInfo->SetAgentRef(agentRef);
                    // Only keep one path info per agent.
                    bool found = false;
                    for (int i = 0; i < m_PathInfos.size(); i++)
                    {
                        if (m_PathInfos[i]->GetAgentRef() == agentRef)
                        {
                            UNITY_DELETE(m_PathInfos[i], kMemAI);
                            m_PathInfos[i] = pathInfo;
                            found = true;
                        }
                    }
                    if (!found)
                    {
                        m_PathInfos.push_back(pathInfo);
                    }
                }

                ag->corridor.SetTimeStamp(timeStamp);

                // Merge result and existing path.
                // The agent might have moved whilst the request is
                // being processed, so the path may have changed.
                // We assume that the end of the path is at the same location
                // where the request was issued.

                // The last ref in the old path should be the same as
                // the location where the request was issued..
                if (valid && path[npath - 1] != res[0])
                    valid = false;

                if (valid)
                {
                    // Put the old path infront of the new path.
                    if (npath > 1)
                    {
                        // Make space for the old path.
                        if ((npath - 1) + nres > maxRes)
                            nres = maxRes - (npath - 1);
                        memmove(res + npath - 1, res, sizeof(NavMeshPolyRef) * nres);
                        // Copy old path in the beginning.
                        memcpy(res, path, sizeof(NavMeshPolyRef) * (npath - 1));
                        nres += npath - 1;
                    }

                    // Check for partial path.
                    if (res[nres - 1] != ag->reqPoly)
                    {
                        // Partial path, constrain target position inside the last polygon.
                        Vector3f nearest;

                        if (NavMeshStatusSucceed(m_NavQuery->ClosestPointOnPoly(res[nres - 1], targetPos, &nearest)))
                        {
                            targetPos = nearest;
                        }
                        else
                        {
                            valid = false;
                        }
                    }
                }

                if (valid)
                {
                    ag->corridor.SetCorridor(targetPos, m_NavQuery, res, nres, NavMeshStatusDetail(pathqStatus, kNavMeshPartialResult));
                }

                ag->reqStatus = MR_INVALID;
            }
            else
            {
                // Still being processed
                Assert(NavMeshStatusInProgress(pathqStatus));
            }
        }

        // Remove if the request is invalid (has been processed)
        if (ag->reqStatus == MR_INVALID)
        {
            ag->pendingRequest = false;
            m_PathRequest.Clear();
            m_PathRequestRef = 0;
            m_MoveRequestQueueCount--;
            if (i != m_MoveRequestQueueCount)
                memmove(&m_MoveRequestQueue[i], &m_MoveRequestQueue[i + 1], sizeof(m_MoveRequestQueue[0]) * (m_MoveRequestQueueCount - i));
            --i;
        }

        if (remIter <= 0)
            break;
    }
}

void CrowdManager::UpdateTopologyOptimization(const float dt)
{
    PROFILER_AUTO(gNavMeshPathOptimization, NULL)

    const float OPT_TIME_THR = 0.5f; // seconds

    float optTime = OPT_TIME_THR;
    int optIndex = -1;

    const int nagents = m_ActiveAgentCount;
    for (int i = 0; i < nagents; ++i)
    {
        CrowdAgent& ag = m_Agents[m_ActiveAgentIDs[i]];
        Assert(ag.active == 1);
        if (ag.state != kCrowdAgentState_Walking)
            continue;
        if (ag.corridor.GetPathCount() < 3)
            continue;

        ag.topologyOptTime += dt;

        if (ag.topologyOptTime > optTime)
        {
            optIndex = i;
            optTime = ag.topologyOptTime;
        }
    }

    if (optIndex != -1)
    {
        const int idx = m_ActiveAgentIDs[optIndex];
        CrowdAgent& optAgent = m_Agents[idx];
        const CrowdRef optAgentRef = GetAgentRef(&optAgent);
        const QueryFilter* filter = GetAgentFilter(&optAgent);
        optAgent.corridor.OptimizePathTopology(m_NavQuery, filter);
        optAgent.topologyOptTime = 0.0f;

        if (m_LogPathInfo)
        {
            // Update existing path info.
            PathQueryInfo* info = 0;
            for (int i = 0; i < m_PathInfos.size(); i++)
            {
                if (m_PathInfos[i]->GetAgentRef() == optAgentRef)
                {
                    info = m_PathInfos[i];
                    break;
                }
            }
            if (info)
            {
                info->Set(optAgent.corridor.GetFirstPoly(), optAgent.corridor.GetLastPoly(),
                    optAgent.corridor.GetPos(), optAgent.corridor.GetTarget(), m_NavQuery);
            }
        }
    }
}

void CrowdManager::UpdateProximityGrid()
{
    PROFILER_AUTO(gNavMeshProximityInsert, NULL)
    Assert(m_Grid);

    // Clamp the number of registrations to capacity
    // agents are prioritized over obstacles.
    const int addAgentCount = m_ActiveAgentCount;
    const int addObstacleCount = m_ActiveObstacleCount;

    UpdateProximityGridCellSize(m_Grid, addAgentCount, addObstacleCount);
    InsertActiveAgentsIntoProximityGrid(m_Grid, addAgentCount, addObstacleCount);
}

void CrowdManager::UpdateProximityGridCellSize(ProximityGrid* grid, const int addAgentCount, const int addObstacleCount) const
{
    if ((addAgentCount + addObstacleCount) == 0)
    {
        grid->ResetCellSize(Vector2f::one);
        return;
    }

    // Calculate average AABB for interaction range and resize grid cell size to match average range
    Vector2f range = Vector2f::zero;
    for (int i = 0; i < addAgentCount; ++i)
    {
        const CrowdAgent& ag = m_Agents[m_ActiveAgentIDs[i]];
        Assert(ag.active == 1);
        const Vector2f absVel = Abs(Vector2f(ag.vel.x, ag.vel.z));
        const Vector2f extents = (2.0f * ag.params.radius) * Vector2f::one;

        range += extents + absVel * m_AvoidancePredictionTime;
    }
    for (int i = 0; i < addObstacleCount; ++i)
    {
        const Obstacle& obs = m_Obstacles[m_ActiveObstacleIDs[i]];
        const Vector2f absVel = Abs(Vector2f(obs.velocity.x, obs.velocity.z));
        const Vector2f extents = 2.0f * Vector2f(obs.worldExtents.x, obs.worldExtents.z);

        range += extents + absVel * m_AvoidancePredictionTime;
    }

    const float norm = 1.0f / (addAgentCount + addObstacleCount);
    range = max(Vector2f::one, range * norm);

    grid->ResetCellSize(range);
}

void CrowdManager::InsertActiveAgentsIntoProximityGrid(ProximityGrid* grid, const int addAgentCount, const int addObstacleCount) const
{
    // Register agents and obstacles to proximity grid.
    float bounds[4];
    for (int i = 0; i < addAgentCount; ++i)
    {
        const CrowdAgent& ag = m_Agents[m_ActiveAgentIDs[i]];
        Assert(ag.active == 1);
        const Vector3f extents(ag.params.radius, 0, ag.params.radius);
        CalculateRangeBounds(m_AvoidancePredictionTime, bounds, ag.npos, ag.vel, extents);
        grid->AddItem(GetAgentRef(&ag), bounds);
    }

    for (int i = 0; i < addObstacleCount; ++i)
    {
        const Obstacle& obs = m_Obstacles[m_ActiveObstacleIDs[i]];
        CalculateRangeBounds(m_AvoidancePredictionTime, bounds, obs.position, obs.velocity, obs.worldExtents);
        grid->AddItem(GetObstacleRef(&obs), bounds);
    }
}

void CrowdManager::Update(const float dt, CrowdAgentDebugInfo* agentDebugInfos, int agentDebugInfoCount)
{
    UpdateActiveAgentIDs();

    // Nothing to do if no agents are active
    if (m_ActiveAgentCount == 0)
        return;

    UpdateActiveObstacleIDs();

    // Attach debug info to relevant agents
#if UNITY_EDITOR
    for (int i = 0; i < agentDebugInfoCount; i++)
    {
        CrowdAgent* agent = GetMutableAgentByRef(agentDebugInfos[i].agentRef);
        if (agent != NULL)
            agent->debugInfo = &agentDebugInfos[i];
    }
#endif

    const ReadonlyCrowdInfo crowdInfo =
    {
        m_HeightMeshQuery,
        m_ObstacleQueryParams,
        m_Grid,
        m_AgentFilters.begin(),
        m_Agents.begin(),
        m_Obstacles.begin(),
        m_ActiveAgentIDs.begin(),
        m_ActiveObstacleIDs.begin(),
        m_ActiveAgentCount,
        m_ActiveObstacleCount,
        m_AvoidancePredictionTime
    };

    UpdateCrowdInfo updateAllInfo =
    {
        m_Agents.begin(),
        m_AgentAnims.begin(),
        m_ActiveAgentIDs.begin(),
        m_ActiveAgentCount
    };

    CrowdUpdateMultiThreaded(crowdInfo, updateAllInfo, this, dt);

    // Remove debug info from relevant agents
#if UNITY_EDITOR
    for (int i = 0; i < agentDebugInfoCount; i++)
    {
        CrowdAgent* agent = GetMutableAgentByRef(agentDebugInfos[i].agentRef);
        if (agent != NULL)
            agent->debugInfo = NULL;
    }
#endif
}

Vector3f CrowdManager::GetSteerTarget(const CrowdRef agentRef) const
{
    const CrowdAgent* agent = GetAgentByRef(agentRef);
    if (agent == NULL)
        return Vector3f(0.0f, 0.0f, 0.0f);
    Assert(agent->active == 1);

    if (agent->state == kCrowdAgentState_OffMesh)
    {
        const CrowdAgentAnimation* anim = &m_AgentAnims[GetAgentIndex(agent)];
        return anim->endPos;
    }

    if (agent->ncorners > 0)
    {
        return agent->cornerVerts[0];
    }
    else
    {
        return agent->corridor.GetTarget();
    }
}

Vector3f CrowdManager::GetWorldUpAxis(const CrowdRef agentRef) const
{
    const Vector3f yAxis(0.0f, 1.0f, 0.0f);
    const CrowdAgent* agent = GetAgentByRef(agentRef);
    if (agent == NULL)
        return yAxis;
    Assert(agent->active == 1);

    // Try to obtain ref from link, then polygon
    NavMeshPolyRef ref = m_AgentAnims[GetAgentIndex(agent)].polyRef;
    if (!ref)
        ref = agent->corridor.GetFirstPoly();

    Vector3f result;
    if (NavMeshStatusSucceed(m_NavQuery->GetUpAxis(ref, &result)))
        return result;

    return yAxis;
}

void CrowdManager::MarkPathStale(CrowdAgent* agent)
{
    Assert(agent != NULL);
    Assert(agent->active == 1);

    // Set stale only if the agent has a path or reached end of partial path
    if (agent->ncorners > 0 || agent->corridor.GetPathCount() > 1 || agent->corridor.IsPathPartial())
        agent->corridor.SetPathStale(true);

    if (agent->reqStatus == MR_PROCESSING)
    {
        m_PathRequest.SetStaleInProgress(m_PathRequestRef);
    }
}

void CrowdManager::ResizeProximityGrid()
{
    ProximityGrid* newProximityGrid = UNITY_NEW(ProximityGrid, kMemAI) ();
    if (newProximityGrid == NULL)
        return;

    const int poolSize = 8 * (m_MaxAgents + m_MaxObstacles);
    if (newProximityGrid->Init(poolSize))
    {
        UNITY_DELETE(m_Grid, kMemAI);
        m_Grid = newProximityGrid;
    }
    else
    {
        UNITY_DELETE(newProximityGrid, kMemAI);
    }
}

CrowdRef CrowdManager::AddObstacle()
{
    Assert(m_NextFreeObstacle >= 0 && m_NextFreeObstacle <= m_MaxObstacles);

    if (m_NextFreeObstacle == m_MaxObstacles)
    {
        const int newSize = std::max(2 * m_MaxObstacles, 1);
        if (!ReserveObstacles(newSize))
            return false;
    }
    int idx = m_NextFreeObstacle;
    m_NextFreeObstacle = m_Obstacles[idx].nextFreeObstacle;

    Assert(m_NextFreeObstacle >= 0 && m_NextFreeObstacle <= m_MaxObstacles);

    Obstacle* obstacle = &m_Obstacles[idx];
    unsigned int salt = obstacle->salt;
    memset(obstacle, 0, sizeof(Obstacle));
    obstacle->type = kObstacleTypeCylinder;
    obstacle->salt = salt;

    return GetObstacleRef(obstacle);
}

void CrowdManager::RemoveObstacle(const CrowdRef obstacleRef)
{
    Obstacle* obstacle = GetMutableObstacleByRef(obstacleRef);
    if (obstacle == NULL)
        return;
    Assert(obstacle->type != kObstacleTypeUnused);

    const int idx = GetObstacleIndex(obstacle);
    obstacle->type = kObstacleTypeUnused;
    obstacle->salt++;
    obstacle->salt &= (unsigned int)kCrowdRefSaltMask;
    if (obstacle->salt == 0)
        obstacle->salt = 1;
    m_Obstacles[idx].nextFreeObstacle = m_NextFreeObstacle;
    m_NextFreeObstacle = idx;
}

const Obstacle* CrowdManager::GetObstacleByRef(const CrowdRef obstacleRef) const
{
    unsigned int salt = 0, index = 0, type = 0;
    DecodeCrowdId(&salt, &index, &type, obstacleRef);
    if (type != kCrowdObstacle)
        return NULL;
    if (index >= m_MaxObstacles)
        return NULL;
    if (salt != m_Obstacles[index].salt)
        return NULL;
    return &m_Obstacles[index];
}

Obstacle* CrowdManager::GetMutableObstacleByRef(const CrowdRef obstacleRef)
{
    unsigned int salt = 0, index = 0, type = 0;
    DecodeCrowdId(&salt, &index, &type, obstacleRef);
    if (type != kCrowdObstacle)
        return NULL;
    if (index >= m_MaxObstacles)
        return NULL;
    if (salt != m_Obstacles[index].salt)
        return NULL;
    return &m_Obstacles[index];
}

CrowdRef CrowdManager::GetObstacleRef(const Obstacle* obstacle) const
{
    Assert(obstacle != NULL);
    return EncodeCrowdId(obstacle->salt, GetObstacleIndex(obstacle), kCrowdObstacle);
}

void CrowdManager::SetObstaclePositionAndVelocity(const CrowdRef obstacleRef, const Vector3f& position, const Vector3f& velocity)
{
    Obstacle* obstacle = GetMutableObstacleByRef(obstacleRef);
    if (obstacle == NULL)
        return;
    Assert(obstacle->type != kObstacleTypeUnused);

    obstacle->position = position;
    obstacle->velocity = velocity;
}

void CrowdManager::SetObstacleCylinder(const CrowdRef obstacleRef, const Vector3f& extents, const Vector3f& xAxis, const Vector3f& yAxis, const Vector3f& zAxis)
{
    Obstacle* obstacle = GetMutableObstacleByRef(obstacleRef);
    if (obstacle == NULL)
        return;
    Assert(obstacle->type != kObstacleTypeUnused);

    // Set type to cylinder
    obstacle->type = kObstacleTypeCylinder;

    obstacle->extents = extents;
    obstacle->xAxis = xAxis;
    obstacle->yAxis = yAxis;
    obstacle->zAxis = zAxis;

    // Calcualte world AABB from oriented box.
    CalcCapsuleWorldExtents(&obstacle->worldExtents, extents, xAxis, yAxis, zAxis);
}

void CrowdManager::SetObstacleBox(const CrowdRef obstacleRef, const Vector3f& extents, const Vector3f& xAxis, const Vector3f& yAxis, const Vector3f& zAxis)
{
    Obstacle* obstacle = GetMutableObstacleByRef(obstacleRef);
    if (obstacle == NULL)
        return;
    Assert(obstacle->type != kObstacleTypeUnused);

    // Set type to box
    obstacle->type = kObstacleTypeOBB;

    obstacle->extents = extents;
    obstacle->xAxis = xAxis;
    obstacle->yAxis = yAxis;
    obstacle->zAxis = zAxis;

    // Calculate world AABB from oriented box.
    CalcBoxWorldExtents(&obstacle->worldExtents, extents, xAxis, yAxis, zAxis);
}

void CrowdManager::UpdateActiveAgentIDs()
{
    int activeCount = 0;
    for (int i = 0; i < m_MaxAgents; ++i)
    {
        if (m_Agents[i].active)
            m_ActiveAgentIDs[activeCount++] = i;
    }
    m_ActiveAgentCount = activeCount;

    // reset occupied offmeshlinks registered
    m_Occupied.clear();

    // register occupied offmeshlinks
    for (int i = 0; i < activeCount; ++i)
    {
        const int idx = m_ActiveAgentIDs[i];
        const CrowdAgentAnimation& anim = m_AgentAnims[idx];
        if (anim.polyRef)
        {
            Assert(m_Agents[idx].state == kCrowdAgentState_OffMesh);
            m_Occupied.insert(anim.polyRef);
        }
    }

#if DEBUGMODE
    // Verify that the number of free and active agents add up to the total (max)
    int freeCount = 0;
    int next = m_NextFreeAgent;
    while (next != m_MaxAgents)
    {
        Assert(next < m_MaxAgents);
        next = m_Agents[next].nextFreeAgent;
        freeCount++;
    }
    Assert(freeCount + activeCount == m_MaxAgents);
#endif
}

void CrowdManager::UpdateActiveObstacleIDs()
{
    int count = 0;
    for (int i = 0; i < m_MaxObstacles; ++i)
    {
        if (m_Obstacles[i].type != kObstacleTypeUnused)
            m_ActiveObstacleIDs[count++] = i;
    }
    m_ActiveObstacleCount = count;
}
