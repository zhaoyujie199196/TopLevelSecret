//
// Copyright (c) 2009-2010 Mikko Mononen memon@inside.org
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//

// The original source code has been modified by Unity Technologies

#include "UnityPrefix.h"
#include "PathRequest.h"
#include "../MathUtil.h"
#include "../NavMesh/NavMesh.h"
#include "../NavMesh/NavMeshQuery.h"

#include <string.h>

PathRequest::PathRequest() :
    m_NextHandle(1),
    m_PathSizeInc(0),
    m_Navquery(0)
{
}

PathRequest::~PathRequest()
{
    Purge();
}

void PathRequest::Purge()
{
    UNITY_DELETE(m_Navquery, kMemAI);
    m_Request.path.resize_uninitialized(0);
}

bool PathRequest::Init(const int pathSizeInc, const int maxSearchNodeCount, const NavMesh* nav)
{
    Purge();

    m_Navquery = UNITY_NEW(NavMeshQuery, kMemAI) (nav, maxSearchNodeCount);
    if (!m_Navquery)
        return false;

    m_PathSizeInc = pathSizeInc;
    m_Request.ref = 0;
    m_Request.path.resize_uninitialized(m_PathSizeInc);

    return true;
}

void PathRequest::Clear()
{
    PathQuery& q = m_Request;
    q.ref = 0;
    q.status = 0;
}

void PathRequest::Update(const int maxIters, int* iterations)
{
    static const int MAX_KEEP_ALIVE = 2; // in update ticks.

    // Update path request until there is nothing to update
    // or upto maxIters pathfinder iterations has been consumed.
    int iterCount = maxIters;

    PathQuery& q = m_Request;
    // Skip inactive requests.
    if (q.ref == 0)
        return;

    // Handle completed request.
    if (NavMeshStatusSucceed(q.status) || NavMeshStatusFailed(q.status))
    {
        // If the path result has not been read in few frames, free the slot.
        q.keepAlive++;
        if (q.keepAlive > MAX_KEEP_ALIVE)
        {
            q.ref = 0;
            q.status = 0;
        }
        return;
    }

    // Handle query start.
    if (q.status == 0)
    {
        q.status = m_Navquery->InitSlicedFindPath(q.startRef, q.endRef, q.startPos, q.endPos, &q.filter);
        q.timeStamp = m_Navquery->GetAttachedNavMesh()->GetTimeStamp();
    }
    // Handle query in progress.
    if (NavMeshStatusInProgress(q.status))
    {
        int iters = 0;
        q.status = m_Navquery->UpdateSlicedFindPath(iterCount, &iters);
        iterCount -= iters;
    }
    if (NavMeshStatusSucceed(q.status))
    {
        // preserve the detail mask from the previous call
        const NavMeshStatus details = q.status & kNavMeshStatusDetailMask;

        int npath = 0;
        q.status = m_Navquery->FinalizeSlicedFindPath(&npath);
        if (NavMeshStatusSucceed(q.status))
        {
            // Resize the result array to fit the result.
            if (npath > q.path.size())
            {
                int cap = ((npath + m_PathSizeInc - 1) / m_PathSizeInc) * m_PathSizeInc;
                q.path.resize_uninitialized(cap);
            }
            q.status = m_Navquery->GetPath(q.path.begin(), &q.npath, npath);
        }
        q.status |= details;

        if (q.logInfo)
            q.pathInfo.Set(q.startRef, q.endRef, q.startPos, q.endPos, m_Navquery);
    }

    if (iterations)
    {
        *iterations = maxIters - iterCount;
    }
}

PathQueueRef PathRequest::Request(NavMeshPolyRef startRef, NavMeshPolyRef endRef,
    const Vector3f& startPos, const Vector3f& endPos,
    const QueryFilter* filter, bool logInfo)
{
    Assert(startRef != 0);
    Assert(endRef != 0);
    Assert(filter);

    if (m_Request.ref != 0)
        return 0;

    PathQueueRef ref = m_NextHandle++;
    if (m_NextHandle == 0)
        m_NextHandle++;

    PathQuery& q = m_Request;
    q.ref = ref;
    q.startPos = startPos;
    q.startRef = startRef;
    q.endPos = endPos;
    q.endRef = endRef;

    q.status = 0;
    q.npath = 0;
    memcpy(&q.filter, filter, sizeof(q.filter));
    q.keepAlive = 0;

    q.logInfo = logInfo;
    q.pathInfo.Purge();

    return ref;
}

NavMeshStatus PathRequest::GetRequestStatus(PathQueueRef ref) const
{
    if (m_Request.ref == ref)
        return m_Request.status;
    return kNavMeshFailure;
}

int PathRequest::GetRequestPathSize(PathQueueRef ref) const
{
    if (m_Request.ref == ref)
        return m_Request.npath;
    return 0;
}

void PathRequest::SetStaleInProgress(PathQueueRef ref)
{
    PathQuery& q = m_Request;
    if (q.ref == ref && NavMeshStatusInProgress(q.status))
        q.timeStamp = 0;
}

NavMeshStatus PathRequest::GetPathResult(PathQueueRef ref, NavMeshPolyRef* path, int* pathSize, Vector3f* endPos, unsigned int* timeStamp, PathQueryInfo* pathInfo, const int maxPath)
{
    if (m_Request.ref == ref)
    {
        PathQuery& q = m_Request;
        // preserve the detail mask from the previous call
        const NavMeshStatus detail = q.status & kNavMeshStatusDetailMask;

        // Free request for reuse.
        q.ref = 0;
        q.status = 0;
        // Copy path
        int n = std::min(q.npath, maxPath);
        memcpy(path, q.path.begin(), sizeof(NavMeshPolyRef) * n);
        *endPos = q.endPos;
        *pathSize = n;
        // If the pathfinding req ran out of nodes - we mark the path as stale
        // i.e. outdating the path by settings the time-stamp to 0
        *timeStamp = (detail & kNavMeshOutOfNodes) ? 0 : q.timeStamp;
        // Copy request info
        if (pathInfo)
        {
            pathInfo->CopyFrom(q.pathInfo);
            q.pathInfo.Purge();
        }
        return kNavMeshSuccess;
    }
    return kNavMeshFailure;
}
