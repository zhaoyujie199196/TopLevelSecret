//
// Copyright (c) 2009-2010 Mikko Mononen memon@inside.org
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//

// The original source code has been modified by Unity Technologies

#pragma once

#include "LocalBoundary.h"
#include "PathCorridor.h"
#include "Runtime/Math/Vector2.h"
#include "Runtime/Math/Vector3.h"
#include "Runtime/Math/Matrix4x4.h"

struct CrowdAgentDebugInfo;

// Reference to a crowd agent or obstacle.
typedef unsigned long long CrowdRef;

static const unsigned int kCrowdRefSaltBits = 16;   // Number of salt bits in the crowd ID.
static const unsigned int kCrowdRefIndexBits = 32;  // Number of index bits in the crowd ID.
static const unsigned int kCrowdRefTypeBits = 4;    // Number of type bits in the crowd ID.

static const CrowdRef kCrowdRefSaltMask = ((CrowdRef)1 << kCrowdRefSaltBits) - 1;
static const CrowdRef kCrowdRefIndexMask = ((CrowdRef)1 << kCrowdRefIndexBits) - 1;
static const CrowdRef kCrowdRefTypeMask = ((CrowdRef)1 << kCrowdRefTypeBits) - 1;

struct CrowdNeighbour
{
    CrowdRef ref;
    float dist;
};

inline bool operator<(const CrowdNeighbour& lhs, const CrowdNeighbour& rhs)
{
    return lhs.dist < rhs.dist;
}

enum CrowdRefType
{
    kCrowdNone = 0,
    kCrowdAgent = 1,
    kCrowdObstacle = 2,
};

enum ObstacleType
{
    kObstacleTypeUnused = 0,
    kObstacleTypeCylinder = 1,
    kObstacleTypeOBB = 2
};

struct Obstacle
{
    Vector3f position;  // center of the obstacle
    Vector3f velocity;  // velocity of the obstacle
    Vector3f extents;   // local extents of the obstacle, for cylinder this is the cylinder size, for box this is the extents.
    Vector3f worldExtents;  // bounds of the obstacle, axis aligned world-aligned extents
    Vector3f xAxis;     // OBB axes
    Vector3f yAxis;
    Vector3f zAxis;
    int type;           // enum ObstacleType
    int nextFreeObstacle;
    unsigned int salt;
};

enum UpdateFlags
{
    kCrowdObstacleAvoidance = 1,
    kCrowdAutoTraverseOffMeshLink = 2,
    kCrowdAutoBraking = 4,
    kCrowdAutoRepath = 8
};

struct CrowdAgentParams
{
    float radius;
    float height;
    float maxAcceleration;
    float maxSpeed;
    float stoppingDistance;
    unsigned char priority;
    unsigned char updateFlags;            // enum UpdateFlags
    unsigned char obstacleAvoidanceType;  // enum ObstacleAvoidanceType
};

enum CrowdAgentState
{
    kCrowdAgentState_Passive,
    kCrowdAgentState_Walking,
    kCrowdAgentState_OffMesh,
    kCrowdAgentState_Waiting_OffMesh
};

struct CrowdAgent
{
    enum { kMaxNeighbours = 8 };
    enum { kMaxCorners = 4 };

    PathCorridor corridor;
    LocalBoundary boundary;
    CrowdAgentParams params;

    CrowdNeighbour neis[kMaxNeighbours];

    union
    {
        int nneis;
        int nextFreeAgent;
    };

    NavMeshPolyRef cornerPolys[kMaxCorners];
    Vector3f cornerVerts[kMaxCorners];
    unsigned char cornerFlags[kMaxCorners];
    int ncorners;

    Vector3f npos;
    Vector3f disp;
    Vector3f dvel;
    Vector3f vel;
    Vector3f nvel;
    Vector3f avel;

    float remainingDistance;
    float topologyOptTime;
    float desiredSpeed;

    // path request
    Vector3f reqWorldPos;
    Vector3f reqNearestPos;
    NavMeshPolyRef reqPoly;
    unsigned char reqStatus; // enum MoveRequestState

    // agent state
    unsigned char state;    // enum CrowdAgentState
    bool active : 1;
    bool braking : 1;
    bool pendingRequest : 1;
    bool stopExplicit : 1;
    bool requested : 1;
    bool repath : 1;

    unsigned int salt;

#if UNITY_EDITOR
    CrowdAgentDebugInfo* debugInfo;
#endif
};

struct CrowdAgentAnimation
{
    Vector3f initPos, startPos, endPos;
    NavMeshPolyRef polyRef;
    float s, smax;
};

struct CrowdAgentDebugInfo
{
    CrowdRef agentRef;

    struct Segment
    {
        Vector3f start, end;
        float radius;
    };

    struct Circle
    {
        Vector3f center;
        float radius;
    };

    struct Sample
    {
        Vector2f vel;
        float pen;
        float size;
    };

    enum { kMaxSegmentCount = 12 * 8 };
    Segment segments[kMaxSegmentCount];
    int segmentCount;

    enum { kMaxCircleCount = 12 * 8 };
    Circle circles[kMaxCircleCount];
    int circleCount;

    enum { kMaxVelocitySamples = 100 };
    Sample samples[kMaxVelocitySamples];
    int sampleCount;

    Matrix4x4f transform;
};
