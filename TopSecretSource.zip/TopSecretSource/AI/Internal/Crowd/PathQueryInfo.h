//
// Copyright (c) 2009-2010 Mikko Mononen memon@inside.org
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//

// The original source code has been modified by Unity Technologies

#pragma once

#include "CrowdTypes.h"
#include "../NavMesh/NavMesh.h"
#include "Runtime/Math/Vector3.h"

class NavMeshQuery;

class PathQueryInfo
{
public:
    PathQueryInfo();
    ~PathQueryInfo();

    void Purge();

    void Set(NavMeshPolyRef startRef, NavMeshPolyRef endRef,
        const Vector3f& startPos, const Vector3f& endPos,
        const NavMeshQuery* navquery);

    void SetAgentRef(CrowdRef agentRef);

    void CopyFrom(const PathQueryInfo& info);

    inline bool IsValid() const { return m_Info != 0; }
    inline CrowdRef GetAgentRef() const { return m_Info ? m_Info->agentRef : 0; }
    inline NavMeshPolyRef GetStartRef() const { return m_Info->startRef; }
    inline NavMeshPolyRef GetEndRef() const { return m_Info->endRef; }
    inline Vector3f GetStartPos() const { return m_Info->startPos; }
    inline Vector3f GetEndPos() const { return m_Info->startPos; }
    inline const int* GetNodeParents() const { return m_Info->nodeParents; }
    inline const Vector3f* GetNodePositions() const { return m_Info->nodePositions; }
    inline int GetNodeCount() const { return m_Info->nnodes; }

private:
    struct Info
    {
        CrowdRef agentRef;
        NavMeshPolyRef startRef, endRef;
        Vector3f startPos;
        Vector3f endPos;
        int* nodeParents;
        Vector3f* nodePositions;
        int nnodes;
    };
    Info* m_Info;   // Empty info is just pointer, keep memory usage minimum when not in use.
};
