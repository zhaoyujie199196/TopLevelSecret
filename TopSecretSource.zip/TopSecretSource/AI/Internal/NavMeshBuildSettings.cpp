#include "UnityPrefix.h"
#include "NavMeshBuildSettings.h"
#include "Runtime/BaseClasses/ObjectDefines.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "External/Recast/Recast/Include/Recast.h"
#include "Runtime/Geometry/AABB.h"
#include <cfloat>

float NavMeshBuildSettings::kMinAgentRadius = 0.05f;
float NavMeshBuildSettings::kMinAgentHeight = 0.001f;
float NavMeshBuildSettings::kMaxSlopeAngle = 60.0f;
float NavMeshBuildSettings::kMinCellSize = 0.01f;

NavMeshBuildSettings::NavMeshBuildSettings()
{
    agentTypeID = 0;

    agentRadius = 0.5f;
    agentHeight = 2.0f;

    agentSlope = 45.0f;
    agentClimb = 0.4f;

    ledgeDropHeight = 0.0f;
    maxJumpAcrossDistance = 0.0f;

    // Advanced
    minRegionArea = 2.0f;
    manualCellSize = 0;
    cellSize = agentRadius / 3.0f;
    manualTileSize = 0;
    tileSize = 256;
    accuratePlacement = 0;
}

template<class TransferFunc>
void NavMeshBuildSettings::Transfer(TransferFunc& transfer)
{
    transfer.SetVersion(2);

    TRANSFER(agentTypeID);
    TRANSFER(agentRadius);
    TRANSFER(agentHeight);
    TRANSFER(agentSlope);
    TRANSFER(agentClimb);

    TRANSFER(ledgeDropHeight);
    TRANSFER(maxJumpAcrossDistance);

    TRANSFER(minRegionArea);

    TRANSFER(manualCellSize);
    TRANSFER(cellSize);

    TRANSFER(manualTileSize);
    TRANSFER(tileSize);

    TRANSFER(accuratePlacement);

#if UNITY_EDITOR
    if (transfer.IsOldVersion(1))
    {
        const float kDefaultWidthInaccuracy = 100.0f / 6.0f;

        float widthInaccuracy = kDefaultWidthInaccuracy;
        transfer.Transfer(widthInaccuracy, "widthInaccuracy");

        cellSize = 2.0f * agentRadius * widthInaccuracy / 100.0f;
        cellSize = std::max(cellSize, NavMeshBuildSettings::kMinCellSize);

        // If not close to default setting, assume manual.
        manualCellSize = fabsf(widthInaccuracy - kDefaultWidthInaccuracy) > 0.001f ? 1 : 0;
    }
#endif
}

void ValidateNavMeshBuildSettings(NavMeshBuildSettings& validated, std::vector<core::string>* errors,
    const NavMeshBuildSettings& settings, const AABB& buildBounds)
{
    static const int kMinTileSize = 16;
    static const int kMaxTileSize = 1024;
    static const int kDefaultTileSize = 256;
    static const float kCellSizeToHeightRatio = 0.5f;

    bool badRadius = false;
    validated = settings;

    // Validate agent dimensions
    validated.agentRadius = settings.agentRadius;
    if (settings.manualCellSize)
    {
        // Allow the case where cellsize is specified and agent radius is 0,
        // as some users want to create navmeshes without dilation.
        if (validated.agentRadius < 0.0f)
        {
            validated.agentRadius = 0.0f;
            if (errors)
                errors->push_back(core::string("The agent radius must be larger than 0."));
        }
    }
    else
    {
        if (validated.agentRadius < NavMeshBuildSettings::kMinAgentRadius)
        {
            validated.agentRadius = NavMeshBuildSettings::kMinAgentRadius;
            if (errors)
                errors->push_back(core::string("The agent radius you've set is really small, this can slow down the build.\nIf you intended to allow the agent to move close to the borders and walls, please adjust voxel size in to ensure correct bake."));
            badRadius = true;
        }
    }

    validated.agentHeight = settings.agentHeight;
    if (validated.agentHeight < NavMeshBuildSettings::kMinAgentHeight)
    {
        validated.agentHeight = NavMeshBuildSettings::kMinAgentHeight;
        if (errors)
            errors->push_back(core::string("The agent height must be larger than zero."));
    }

    validated.agentSlope = settings.agentSlope;
    if (validated.agentSlope < 0.0f)
    {
        validated.agentSlope = 0.0f;
        if (errors)
            errors->push_back(core::string("The agent max slope must be larger than zero."));
    }
    if (validated.agentSlope > NavMeshBuildSettings::kMaxSlopeAngle)
    {
        if (errors)
            errors->push_back(Format("The maximum slope should be set to less than %.1f degrees to prevent NavMesh build artifacts on slopes.", NavMeshBuildSettings::kMaxSlopeAngle));
    }

    validated.agentClimb = settings.agentClimb;
    if (validated.agentClimb >= validated.agentHeight)
    {
        if (errors)
            errors->push_back(Format("Step height should be less than agent height.\nClamping step height to %.1f internally when baking.", validated.agentHeight));
        validated.agentClimb = validated.agentHeight - FLT_EPSILON;
    }

    // Validate cell size
    bool validCellSize = false;
    validated.manualCellSize = settings.manualCellSize;
    if (validated.manualCellSize)
    {
        validated.cellSize = settings.cellSize;
        if (validated.cellSize < NavMeshBuildSettings::kMinCellSize)
        {
            validated.cellSize = NavMeshBuildSettings::kMinCellSize;
            if (errors)
                errors->push_back(Format("The voxel size must be larger than %.4f.", NavMeshBuildSettings::kMinCellSize));
        }

        const float voxelsPerRadius = validated.cellSize > 0 ? (validated.agentRadius / validated.cellSize) : 0.0f;
        const float cellHeight = validated.cellSize * kCellSizeToHeightRatio;

        // Some places inside Recast store height as a byte, make sure the ratio between
        // the agent height and cell height does not exceed this limit.
        if ((int)floorf(validated.agentHeight / cellHeight) > 250)
        {
            const float goodValue = (validated.agentHeight / 250.0f) / kCellSizeToHeightRatio;
            if (errors)
                errors->push_back(Format("The number of voxels per agent height is too high. This will reduce the accuracy of the navmesh. Consider using voxel size of at least %.4f.", goodValue));
        }

        if (voxelsPerRadius < 1.0f)
        {
            const float goodValue = validated.agentRadius / 2.0f;
            if (errors)
                errors->push_back(Format("The number of voxels per agent radius is too small. The agent may not avoid walls and ledges properly. Consider using a voxel size less than %.4f (2 voxels per agent radius).", goodValue));
        }
        else if (voxelsPerRadius > 8.0f)
        {
            const float goodValue = validated.agentRadius / 8.0f;
            if (errors)
                errors->push_back(Format("The number of voxels per agent radius is too high. It can cause excessive build times. Consider using voxel size closer to %.4f (8 voxels per radius).", goodValue));
        }

        validCellSize = true;
    }
    else
    {
        validated.cellSize = (2.0f * validated.agentRadius) / 6.0f;
        validCellSize = !badRadius;
    }

    // Validate tile size
    validated.manualTileSize = settings.manualTileSize;
    if (validated.manualTileSize)
    {
        validated.tileSize = settings.tileSize;
        if (validated.tileSize < kMinTileSize)
        {
            validated.tileSize = kMinTileSize;
            if (errors)
                errors->push_back(Format("Tile size must be in range %d - %d.", kMinTileSize, kMaxTileSize));
        }
        if (validated.tileSize > kMaxTileSize)
        {
            validated.tileSize = kMaxTileSize;
            if (errors)
                errors->push_back(Format("Tile size must be in range %d - %d.", kMinTileSize, kMaxTileSize));
        }
    }
    else
    {
        validated.tileSize = kDefaultTileSize;
    }

    // These checks make sense only if we can calculate proper cellsize.
    if (validCellSize)
    {
        // Detect when agent slope and step height conflict.
        const float cs = validated.cellSize;
        const float ch = cs * kCellSizeToHeightRatio;
        const int walkableClimbVx = (int)ceilf(validated.agentClimb / ch);

        // Recast treats voxels whose neighbours min/max height difference is more than step height.
        const float slopeHeightPerVoxel = tanf(validated.agentSlope / 180.0f * kPI) * cs;
        const int slopeVx = (int)ceilf(slopeHeightPerVoxel * 2.0f / ch);
        if (slopeVx > walkableClimbVx)
        {
            // Recommend new values.
            float betterSlope = (walkableClimbVx * ch) / (cs * 2.0f);
            float betterSlopeAngle = atanf(betterSlope) / kPI * 180.0f;
            float betterStep = (slopeVx - 1) * ch;
            if (errors)
                errors->push_back(Format("Step Height conflicts with Max Slope. This makes some slopes unwalkable.\nConsider decreasing Max Slope to < %.3f degrees.\nOr, increase Step Height to > %.3f.", betterSlopeAngle, betterStep));
        }

        // Some places inside Recast store height as a byte, make sure the ratio between
        // the agent height (plus climb) and cell height does not exceed this limit.
        if ((int)ceilf((validated.agentHeight + validated.agentClimb) / ch) > 255)
        {
            const float cellHeight = (settings.agentHeight + settings.agentClimb) / 255.0f;
            const float suggestedCellSize = cellHeight * 2.0f;
            if (errors)
                errors->push_back(Format("The NavMesh may not be generated properly as the ratio between Agent size and voxel size is large. Try setting voxel size to larger than %.3f.", suggestedCellSize));
        }

        // Warn about too large vertical dimension and adjust the cell height to fit the whole world.
        const float worldHeight = buildBounds.GetExtent().y * 2.0f;
        const int worldHeightVoxels = (int)ceilf(worldHeight / ch);
        if (worldHeightVoxels >= RC_SPAN_MAX_HEIGHT)
        {
            const float maxHeight = floorf((RC_SPAN_MAX_HEIGHT)*ch);
            if (errors)
                errors->push_back(Format("The NavMesh may not be generated properly as the vertical dimension of your Scene is too large. Try limiting the vertical size to less than %.1f.", maxHeight));
        }
    }
}

INSTANTIATE_TEMPLATE_TRANSFER(NavMeshBuildSettings);
