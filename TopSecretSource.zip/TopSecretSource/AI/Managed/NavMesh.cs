#if ENABLE_RUNTIME_NAVMESH_BUILDING

using System;
using UnityEngine.Scripting;

namespace UnityEngine.AI
{
    public static partial class NavMesh
    {
        public delegate void OnNavMeshPreUpdate();
        public static OnNavMeshPreUpdate onPreUpdate;

        [RequiredByNativeCode]
        private static void Internal_CallOnNavMeshPreUpdate()
        {
            if (onPreUpdate != null)
                onPreUpdate();
        }
    }
}

#endif
