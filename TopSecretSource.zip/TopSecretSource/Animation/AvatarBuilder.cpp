#include "UnityPrefix.h"

#include "Runtime/Graphics/Mesh/SkinnedMeshRenderer.h"
#include "Runtime/Transform/Transform.h"

#include "Runtime/Profiler/Profiler.h"

#include "AvatarBuilder.h"
#include "Avatar.h"

#include "Runtime/mecanim/math/axes.h"

namespace
{
    int Find(AvatarBuilder::NamedTransforms const& transforms, Transform* parent)
    {
        for (size_t i = 0; i < transforms.size(); i++)
            if (transforms[i].transform == parent)
                return i;
        return -1;
    }

    template<typename TYPE>
    int GetIndexArray(HumanDescription const& humanDescription, AvatarBuilder::NamedTransforms const& namedTransform, std::vector<int> &indexArray)
    {
        int ret = 0;

        for (int i = 0; i < TYPE::GetBoneCount(); ++i)
        {
            HumanBoneList::const_iterator it = std::find_if(humanDescription.m_Human.begin(), humanDescription.m_Human.end(), FindHumanBone(TYPE::GetBoneName(i)));

            if (it != humanDescription.m_Human.end())
            {
                for (size_t j = 0; j < namedTransform.size(); j++)
                {
                    if ((*it).m_BoneName == namedTransform[j].name)
                    {
                        indexArray[j] = i;
                        ret++;
                    }
                }
            }
        }

        return ret;
    }

    mecanim::skeleton::Skeleton* BuildSkeleton(const AvatarBuilder::NamedTransforms & transform, TOSVector& tos, mecanim::memory::Allocator& alloc)
    {
        mecanim::skeleton::Skeleton * skel = mecanim::skeleton::CreateSkeleton(transform.size(), 0, alloc);

        mecanim::uint32_t i;
        for (i = 0; i < skel->m_Count; i++)
        {
            // Find return -1 if transform is not found exactly like our data representation
            // when node doesn't have any parent
            skel->m_Node[i].m_ParentId = Find(transform, transform[i].transform->GetParent());
            skel->m_Node[i].m_AxesId = -1;
            skel->m_ID[i] = ProccessString(tos, transform[i].path);
        }
        return skel;
    }

    void MarkBoneUp(mecanim::skeleton::Skeleton *avatarSkeleton, std::vector<bool> &isMark, int index, int stopIndex)
    {
        isMark[index] = true;

        if (index != stopIndex)
        {
            MarkBoneUp(avatarSkeleton, isMark, avatarSkeleton->m_Node[index].m_ParentId, stopIndex);
        }
    }

    mecanim::skeleton::Skeleton* BuildHumanSkeleton(mecanim::skeleton::Skeleton *avatarSkeleton, std::vector<int> humanBoneIndexArray, std::vector<int> leftHandIndexArray, std::vector<int> rightHandIndexArray, mecanim::memory::Allocator& alloc)
    {
        int humanCount = 0;
        int leftHandCount = 0;
        int rightHandCount = 0;
        int hipsIndex = -1;

        for (size_t i = 0; i < avatarSkeleton->m_Count; i++)
        {
            humanCount += humanBoneIndexArray[i] != -1 ? 1 : 0;
            leftHandCount += leftHandIndexArray[i] != -1 ? 1 : 0;
            rightHandCount += rightHandIndexArray[i] != -1 ? 1 : 0;
            hipsIndex = humanBoneIndexArray[i] == mecanim::human::kHips ? i : hipsIndex;
        }

        std::vector<bool> isHumanBone(avatarSkeleton->m_Count, false);

        for (size_t i = 0; i < avatarSkeleton->m_Count; i++)
        {
            if (humanBoneIndexArray[i] != -1)
            {
                MarkBoneUp(avatarSkeleton, isHumanBone, i, hipsIndex);
            }

            if (leftHandIndexArray[i] != -1)
            {
                MarkBoneUp(avatarSkeleton, isHumanBone, i, hipsIndex);
            }

            if (rightHandIndexArray[i] != -1)
            {
                MarkBoneUp(avatarSkeleton, isHumanBone, i, hipsIndex);
            }
        }

        int boneCount = 0;

        for (size_t i = 0; i < isHumanBone.size(); i++)
        {
            boneCount += isHumanBone[i] ? 1 : 0;
        }

        mecanim::skeleton::Skeleton *skel = mecanim::skeleton::CreateSkeleton(1 + boneCount, humanCount + leftHandCount + rightHandCount, alloc);

        int nodeIndex = 0;
        int axesIndex = 0;

        skel->m_ID[nodeIndex] = avatarSkeleton->m_ID[avatarSkeleton->m_Node[hipsIndex].m_ParentId];
        skel->m_Node[nodeIndex].m_ParentId = -1;
        skel->m_Node[nodeIndex].m_AxesId = -1;

        nodeIndex++;

        for (size_t i = 0; i < avatarSkeleton->m_Count; i++)
        {
            if (isHumanBone[i])
            {
                skel->m_ID[nodeIndex] = avatarSkeleton->m_ID[i];
                skel->m_Node[nodeIndex].m_ParentId = mecanim::skeleton::SkeletonFindNode(skel, avatarSkeleton->m_ID[avatarSkeleton->m_Node[i].m_ParentId]);
                skel->m_Node[nodeIndex].m_AxesId = humanBoneIndexArray[i] != -1 || leftHandIndexArray[i] != -1 || rightHandIndexArray[i] != -1 ? axesIndex++ : -1;

                nodeIndex++;
            }
        }

        return skel;
    }

    mecanim::skeleton::Skeleton* BuildRootMotionSkeleton(mecanim::skeleton::Skeleton *avatarSkeleton, int rootMotionIndex, mecanim::memory::Allocator& alloc)
    {
        std::vector<bool> isRootMotionBone(avatarSkeleton->m_Count, false);

        MarkBoneUp(avatarSkeleton, isRootMotionBone, rootMotionIndex, 0);

        int rootMotionCount = 0;

        for (size_t i = 0; i < isRootMotionBone.size(); i++)
        {
            rootMotionCount += isRootMotionBone[i] ? 1 : 0;
        }

        mecanim::skeleton::Skeleton *skel = mecanim::skeleton::CreateSkeleton(rootMotionCount, 0, alloc);

        int nodeIndex = 0;

        for (size_t i = 0; i < avatarSkeleton->m_Count; i++)
        {
            if (isRootMotionBone[i])
            {
                skel->m_ID[nodeIndex] = avatarSkeleton->m_ID[i];
                skel->m_Node[nodeIndex].m_ParentId = nodeIndex - 1;

                nodeIndex++;
            }
        }

        return skel;
    }

    void SetAxes(mecanim::human::Human* human, SkeletonBoneLimit const& skeletonBoneLimit, int id)
    {
        if (id != -1 && skeletonBoneLimit.m_Modified)
        {
            int axesId = human->m_Skeleton->m_Node[id].m_AxesId;
            if (axesId != -1)
            {
                math::Axes& axes = human->m_Skeleton->m_AxesArray[axesId];

                math::float3 minValue = math::radians(math::float3(skeletonBoneLimit.m_Min[0], skeletonBoneLimit.m_Min[1], skeletonBoneLimit.m_Min[2]));
                math::float3 maxValue = math::radians(math::float3(skeletonBoneLimit.m_Max[0], skeletonBoneLimit.m_Max[1], skeletonBoneLimit.m_Max[2]));
                axes.m_Limit.m_Min = minValue;
                axes.m_Limit.m_Max = maxValue;
            }
        }
    }

    class SetupAxesHelper
    {
    public:
        SetupAxesHelper(mecanim::human::Human* human, bool exist, mecanim::int32_t* index) : mHuman(human), mExist(exist), mIndex(index) {}

        void operator()(HumanBone const& humanBone, int i)
        {
            int index = mExist ? mIndex[i] : -1;
            SetAxes(mHuman, humanBone.m_Limit, index);
        }

    protected:
        mecanim::human::Human* mHuman;
        mecanim::skeleton::SkeletonPose* mPose;
        bool mExist;
        mecanim::int32_t* mIndex;
    };

    template<class Trait, class List, class Function> void for_each(List const& list, Function f)
    {
        for (int i = 0; i < Trait::GetBoneCount(); ++i)
        {
            typename List::const_iterator it = std::find_if(list.begin(), list.end(), FindHumanBone(Trait::GetBoneName(i)));
            if (it != list.end())
            {
                f(*it, i);
            }
        }
    }

    void SetupAxes(mecanim::human::Human* human, HumanDescription const& humanDescription)
    {
        for_each<HumanTrait::Body>(humanDescription.m_Human, SetupAxesHelper(human, true, human->m_HumanBoneIndex));

        for_each<HumanTrait::LeftFinger>(humanDescription.m_Human, SetupAxesHelper(human, human->m_HasLeftHand, human->m_HasLeftHand ? human->m_LeftHand->m_HandBoneIndex : 0));

        for_each<HumanTrait::RightFinger>(humanDescription.m_Human, SetupAxesHelper(human, human->m_HasRightHand, human->m_HasRightHand ? human->m_RightHand->m_HandBoneIndex : 0));
    }

    struct IndexFromBoneName
    {
        core::string m_Predicate;
        IndexFromBoneName(const core::string& predicate) : m_Predicate(predicate) {}

        bool operator()(AvatarBuilder::NamedTransform const& namedTransform) {return namedTransform.name == m_Predicate; }
    };

    static int GetIndexFromBoneName(AvatarBuilder::NamedTransforms::const_iterator start, AvatarBuilder::NamedTransforms::const_iterator stop, const core::string& boneName)
    {
        AvatarBuilder::NamedTransforms::const_iterator it = std::find_if(start, stop, IndexFromBoneName(boneName));
        if (it != stop)
            return it - start;

        return -1;
    }

    static void OverwriteTransforms(mecanim::skeleton::Skeleton* skeleton, mecanim::skeleton::SkeletonPose* pose, const HumanDescription& humanDescription, const AvatarBuilder::NamedTransforms& namedTransforms)
    {
        if (humanDescription.m_Skeleton.size() > 0)
        {
            const SkeletonBone& skeletonBone = humanDescription.m_Skeleton[0];
            pose->m_X[0] = xformFromUnity(skeletonBone.m_Position, skeletonBone.m_Rotation, skeletonBone.m_Scale);

            for (size_t i = 1; i < humanDescription.m_Skeleton.size(); ++i)
            {
                SkeletonBone const& skeletonBone = humanDescription.m_Skeleton[i];
                int skeletonIndex = GetIndexFromBoneName(namedTransforms.begin() + 1, namedTransforms.end(), skeletonBone.m_Name) + 1;
                if (skeletonIndex != 0)
                {
                    pose->m_X[skeletonIndex] = xformFromUnity(skeletonBone.m_Position, skeletonBone.m_Rotation, skeletonBone.m_Scale);
                }
            }
        }
    }
}

HumanBone::HumanBone() :
    m_BoneName(""),
    m_HumanName("")
    //m_ColliderPosition(Vector3f::zero),
    //m_ColliderRotation(Quaternionf::identity()),
    //m_ColliderScale(Vector3f::one)
{
}

HumanBone::HumanBone(core::string const& humanName) :
    m_BoneName(""),
    m_HumanName(humanName)
    //m_ColliderPosition(Vector3f::zero),
    //m_ColliderRotation(Quaternionf::identity()),
    //m_ColliderScale(Vector3f::one)

{
}

class FindBone
{
protected:
    core::string  mName;
public:
    FindBone(const core::string& name) : mName(name) {}
    bool operator()(const AvatarBuilder::NamedTransform & bone) { return mName == bone.name; }
};

class FindBonePath
{
protected:
    core::string  mName;
public:
    FindBonePath(const core::string& name) : mName(name) {}

    bool operator()(const AvatarBuilder::NamedTransform & bone) { return mName == bone.path; }
};

PROFILER_INFORMATION(gAvatarBuilderBuildAvatar, "AvatarBuilder.BuildAvatar", kProfilerAnimation);

core::string AvatarBuilder::BuildAvatar(Avatar& avatar, const GameObject& go, const HumanDescription& humanDescription, Options options)
{
    PROFILER_AUTO(gAvatarBuilderBuildAvatar, NULL)

    core::string error;

    if (options.avatarType == kHumanoid)
    {
        if (!AvatarBuilder::IsValidHumanDescription(humanDescription, error, false))
        {
            return Format("AvatarBuilder '%s': %s", go.GetName(), error.c_str());
        }
    }

    NamedTransforms namedTransforms;
    NamedTransforms humanNamedTransforms;

    if (!GenerateAvatarMap(go, namedTransforms, humanNamedTransforms, humanDescription, options.avatarType, options.useMask, error))
    {
        return Format("AvatarBuilder '%s': %s", go.GetName(), error.c_str());
    }

    BuildAvatarInternal(avatar, namedTransforms, go, humanDescription, options);

    return core::string();
}

void AvatarBuilder::BuildAvatarInternal(Avatar& avatar, const NamedTransforms &namedTransforms, const GameObject& go, const HumanDescription& humanDescription, Options options, bool fixOldRigs)
{
    mecanim::memory::ChainedAllocator alloc(kMemTempAlloc, 30 * 1024);

    TOSVector tos;

    // build avatar skeleton
    mecanim::skeleton::Skeleton         *avatarSK = BuildSkeleton(namedTransforms, tos, alloc);
    mecanim::skeleton::SkeletonPose     *avatarDefaultPose = mecanim::skeleton::CreateSkeletonPose<math::trsX>(avatarSK, alloc);
    mecanim::skeleton::SkeletonPose     *avatarPose  = mecanim::skeleton::CreateSkeletonPose<math::trsX>(avatarSK, alloc);
    mecanim::skeleton::SkeletonPose     *avatarGPose = mecanim::skeleton::CreateSkeletonPose<math::trsX>(avatarSK, alloc);
    mecanim::uint32_t                   *nameIDArray = alloc.ConstructArray<mecanim::uint32_t>(namedTransforms.size());

    for (size_t i = 0; i < namedTransforms.size(); i++)
    {
        nameIDArray[i] = mecanim::processCRC32(GetLastPathNameComponent(namedTransforms[i].path.c_str(), namedTransforms[i].path.size()));
    }

    ReadFromLocalTransformToSkeletonPose(avatarDefaultPose, namedTransforms);

    // Overwrite transform found in human description
    mecanim::skeleton::SkeletonPoseCopy(avatarDefaultPose, avatarPose);
    OverwriteTransforms(avatarSK, avatarPose, humanDescription, namedTransforms);

    mecanim::human::Human*              human = 0;
    mecanim::skeleton::Skeleton*        humanSK    = 0;
    mecanim::skeleton::SkeletonPose*    humanPose  = 0;
    mecanim::skeleton::SkeletonPose*    humanGPose = 0;

    int rootMotionIndex = -1;
    math::trsX  rootMotionX(math::trsIdentity());
    mecanim::skeleton::Skeleton *rootMotionSK = 0;

    if (options.avatarType == kHumanoid)
    {
        // build human skeleton
        std::vector<int> humanIndexArray(avatarSK->m_Count, -1);
        std::vector<int> leftHandIndexArray(avatarSK->m_Count, -1);
        std::vector<int> rightHandIndexArray(avatarSK->m_Count, -1);

        GetIndexArray<HumanTrait::Body>(humanDescription, namedTransforms, humanIndexArray);
        bool leftHandValid = GetIndexArray<HumanTrait::LeftFinger>(humanDescription, namedTransforms, leftHandIndexArray) > 0;
        bool rightHandValid = GetIndexArray<HumanTrait::RightFinger>(humanDescription, namedTransforms, rightHandIndexArray) > 0;

        humanSK    = BuildHumanSkeleton(avatarSK, humanIndexArray, leftHandIndexArray, rightHandIndexArray, alloc);
        humanPose  = mecanim::skeleton::CreateSkeletonPose<math::trsX>(humanSK, alloc);
        humanGPose = mecanim::skeleton::CreateSkeletonPose<math::trsX>(humanSK, alloc);

        // build human. Setup human with 'pose', which will be initialized when HumanSetupAxes will be call

        //@TODO: SHould we remove support for handles in the runtime too?
        human = mecanim::human::CreateHuman(humanSK, humanPose, 0, humanSK->m_AxesCount, alloc);
        mecanim::hand::Hand* leftHand = leftHandValid ? mecanim::hand::CreateHand(alloc) : 0;
        mecanim::hand::Hand* rightHand = rightHandValid ? mecanim::hand::CreateHand(alloc) : 0;
        human->m_LeftHand = leftHand;
        human->m_HasLeftHand = leftHandValid;
        human->m_RightHand = rightHand;
        human->m_HasRightHand = rightHandValid;

        for (size_t i = 0; i < avatarSK->m_Count; i++)
        {
            if (humanIndexArray[i] != -1)
                human->m_HumanBoneIndex[humanIndexArray[i]] = mecanim::skeleton::SkeletonFindNode(humanSK, avatarSK->m_ID[i]);

            if (leftHandValid && leftHandIndexArray[i] != -1)
                leftHand->m_HandBoneIndex[leftHandIndexArray[i]] = mecanim::skeleton::SkeletonFindNode(humanSK, avatarSK->m_ID[i]);

            if (rightHandValid && rightHandIndexArray[i] != -1)
                rightHand->m_HandBoneIndex[rightHandIndexArray[i]] = mecanim::skeleton::SkeletonFindNode(humanSK, avatarSK->m_ID[i]);
        }

        human->m_ArmTwist = humanDescription.m_ArmTwist;
        human->m_ForeArmTwist = humanDescription.m_ForeArmTwist;
        human->m_UpperLegTwist = humanDescription.m_UpperLegTwist;
        human->m_LegTwist = humanDescription.m_LegTwist;
        human->m_ArmStretch = humanDescription.m_ArmStretch;
        human->m_LegStretch = humanDescription.m_LegStretch;
        human->m_FeetSpacing = humanDescription.m_FeetSpacing;

        human->m_HasTDoF = humanDescription.m_HasTranslationDoF;

        // this code is used to support old copy avatar rig setup with hierarchy mis-match error.
        if (fixOldRigs)
        {
            mecanim::int32_t hipsID = humanSK->m_ID[human->m_HumanBoneIndex[mecanim::human::kHips]];
            mecanim::int32_t hipsIndex = mecanim::skeleton::SkeletonFindNode(avatarSK, hipsID);
            mecanim::int32_t rootIndex = avatarSK->m_Node[hipsIndex].m_ParentId;

            mecanim::skeleton::SkeletonPoseComputeGlobal(avatarSK, avatarDefaultPose, avatarGPose, rootIndex, 0);
            mecanim::skeleton::SkeletonPoseComputeLocal(avatarSK, avatarGPose, avatarPose, rootIndex, 0);
        }

        mecanim::skeleton::SkeletonPoseComputeGlobal(avatarSK, avatarPose, avatarGPose);
        mecanim::skeleton::SkeletonPoseCopy(avatarSK, avatarGPose, humanSK, humanGPose);

        humanGPose->m_X[0] = math::trsIdentity();

        mecanim::human::HumanAdjustMass(human);
        mecanim::human::HumanSetupAxes(human, humanGPose);
        mecanim::human::HumanSetupCollider(human, humanGPose);

        if (leftHandValid)
            mecanim::hand::HandSetupAxes(leftHand, humanGPose, humanSK, true);
        if (rightHandValid)
            mecanim::hand::HandSetupAxes(rightHand, humanGPose, humanSK, false);

        SetupAxes(human, humanDescription);
    }
    else
    {
        rootMotionIndex = GetIndexFromBoneName(namedTransforms.begin(), namedTransforms.end(), humanDescription.m_RootMotionBoneName);

        if (rootMotionIndex != -1)
        {
            rootMotionX.q = QuaternionfTofloat4(humanDescription.m_RootMotionBoneRotation);
            rootMotionSK = BuildRootMotionSkeleton(avatarSK, rootMotionIndex, alloc);
        }
    }

    mecanim::animation::AvatarConstant* avatarConstant = mecanim::animation::CreateAvatarConstant(avatarSK, avatarPose, avatarDefaultPose, human, rootMotionSK, rootMotionIndex, rootMotionX, alloc);
    avatarConstant->m_SkeletonNameIDCount = namedTransforms.size();
    avatarConstant->m_SkeletonNameIDArray = nameIDArray;
    avatar.SetAsset(avatarConstant, tos);
}

Transform* AvatarBuilder::GetTransform(int id, HumanDescription const& humanDescription, NamedTransforms const& namedTransform, std::vector<core::string> const& boneName)
{
    HumanBoneList::const_iterator it1 = std::find_if(humanDescription.m_Human.begin(), humanDescription.m_Human.end(), FindHumanBone(boneName[id]));
    if (it1 != humanDescription.m_Human.end())
    {
        NamedTransforms::const_iterator it2 = std::find_if(namedTransform.begin(), namedTransform.end(), FindBone((*it1).m_BoneName));
        if (it2 != namedTransform.end())
        {
            return it2->transform;
        }
    }
    return 0;
}

bool AvatarBuilder::IsValidHumanDescription(HumanDescription const& humanDescription, core::string& error, bool copiedDescription)
{
    if (copiedDescription && humanDescription.m_Human.size() == 0)
    {
        error = Format("No human bone found. Ensure both rig type match");
        return false;
    }

    int i;
    for (i = 0; i < HumanTrait::Body::GetBoneCount(); ++i)
    {
        if (HumanTrait::RequiredBone(i))
        {
            HumanBoneList::const_iterator it1 = std::find_if(humanDescription.m_Human.begin(), humanDescription.m_Human.end(), FindHumanBone(HumanTrait::Body::GetBoneName(i)));
            if (it1 == humanDescription.m_Human.end())
            {
                error = Format("Required human bone '%s' not found", HumanTrait::Body::GetBoneName(i).c_str());
                return false;
            }
        }
    }

    for (i = 0; i < (int)humanDescription.m_Human.size(); i++)
    {
        if (!humanDescription.m_Human[i].m_BoneName.empty())
        {
            HumanBoneList::const_iterator foundDuplicated = std::find_if(humanDescription.m_Human.begin() + i + 1, humanDescription.m_Human.end(), FindHumanBone(humanDescription.m_Human[i].m_HumanName));
            if (foundDuplicated != humanDescription.m_Human.end())
            {
                error = Format("Found duplicate human bone '%s' with transform '%s' and '%s'", humanDescription.m_Human[i].m_HumanName.c_str(), foundDuplicated->m_BoneName.c_str(),  humanDescription.m_Human[i].m_BoneName.c_str());
                return false;
            }
        }
    }

    for (i = 0; i < (int)humanDescription.m_Human.size(); i++)
    {
        if (!humanDescription.m_Human[i].m_BoneName.empty())
        {
            HumanBoneList::const_iterator foundDuplicated = std::find_if(humanDescription.m_Human.begin() + i + 1, humanDescription.m_Human.end(), FindBoneName(humanDescription.m_Human[i].m_BoneName));
            if (foundDuplicated != humanDescription.m_Human.end())
            {
                error = Format("Found duplicate transform '%s' for human bone '%s' and '%s'", humanDescription.m_Human[i].m_BoneName.c_str(), foundDuplicated->m_HumanName.c_str(),  humanDescription.m_Human[i].m_HumanName.c_str());
                return false;
            }
        }
    }

    return true;
}

bool AvatarBuilder::IsValidHuman(HumanDescription const& humanDescription, NamedTransforms const& namedTransform, Transform& rootTransform, core::string& error)
{
    int i;
    for (i = 0; i < HumanTrait::Body::GetBoneCount(); ++i)
    {
        HumanBoneList::const_iterator it1 = std::find_if(humanDescription.m_Human.begin(), humanDescription.m_Human.end(), FindHumanBone(HumanTrait::Body::GetBoneName(i)));
        if (it1 != humanDescription.m_Human.end())
        {
            NamedTransforms::const_iterator it2 = std::find_if(namedTransform.begin(), namedTransform.end(), FindBone((*it1).m_BoneName));
            if (it2 == namedTransform.end())
            {
                error = Format("Transform '%s' for human bone '%s' not found", (*it1).m_BoneName.c_str(), HumanTrait::Body::GetBoneName(i).c_str());
                return false;
            }
        }
    }

    // Look if all the bone hierarchy parenting is valid
    std::vector<core::string> boneName = HumanTrait::GetBoneName();
    Transform* hips = GetTransform(0, humanDescription, namedTransform, boneName);
    if (hips && !hips->GetParent())
    {
        error = Format("Hips bone '%s' must have a parent", hips->GetName());
        return false;
    }
    else if (hips && hips->GetParent())
    {
        if (std::find_if(namedTransform.begin(), namedTransform.end(), FindBone(hips->GetParent()->GetName())) == namedTransform.end())
        {
            error = Format("Hips bone parent '%s' must be included in the HumanDescription Skeleton", hips->GetParent()->GetName());
            return false;
        }
    }

    for (i = 0; i < HumanTrait::HumanBoneCount; ++i)
    {
        Transform* child = GetTransform(i, humanDescription, namedTransform, boneName);
        if (child)
        {
            // find out next required parent bone
            int parentId = HumanTrait::GetParent(i);
            while (parentId != -1 && !HumanTrait::RequiredBone(parentId))
                parentId = HumanTrait::GetParent(parentId);

            if (parentId != -1)
            {
                Transform* parent = GetTransform(parentId, humanDescription, namedTransform, boneName);
                if (!IsChildOrSameTransform(*child, *parent))
                {
                    error = Format("Transform '%s' is not an ancestor of '%s'", parent->GetName(), child->GetName());
                    return false;
                }
            }
        }
    }

    // Check that all named transforms actually have their parents included in the mapping
    for (i = 0; i < namedTransform.size(); ++i)
    {
        const NamedTransform& t = namedTransform[i];
        if (t.transform == &rootTransform)
            continue;
        Transform* parent = t.transform->GetParent();
        if (parent == &rootTransform)
            continue;

        if (Find(namedTransform, parent) == -1)
        {
            error = Format("Transform '%s' parent '%s' must be included in the HumanDescription Skeleton", t.transform->GetName(), t.transform->GetParent()->GetName());
            return false;
        }
    }

    if (humanDescription.m_SkeletonHasParents)
    {
        return IsValidHumanHierarchy(humanDescription, namedTransform, rootTransform, error);
    }

    return error.empty();
}

bool AvatarBuilder::IsValidHumanHierarchy(HumanDescription const& humanDescription, NamedTransforms const& namedTransform, Transform& rootTransform, core::string& error)
{
    for (int i = 0; i < namedTransform.size(); i++)
    {
        const NamedTransform& t = namedTransform[i];
        Transform *parent = t.transform->GetParent();

        if (parent)
        {
            SkeletonBoneList::const_iterator skIt = std::find_if(humanDescription.m_Skeleton.begin(), humanDescription.m_Skeleton.end(), FindSkeletonBone(t.name));

            if (skIt == humanDescription.m_Skeleton.end())
            {
                error = Format("Transform '%s' not found in HumanDescription.", t.name.c_str());
                return false;
            }
            else
            {
                if (!(*skIt).m_ParentName.empty())
                {
                    core::string parentName = parent->GetName();

                    core::string descParentName = (*skIt).m_ParentName;
                    descParentName = descParentName != humanDescription.m_Skeleton[0].m_Name ? descParentName : parentName;

                    if (parentName != descParentName)
                    {
                        error = Format("Parent for '%s' differs from one found in HumanDescription. '%s' was found instead of '%s'.", t.name.c_str(), parentName.c_str(), descParentName.c_str());
                        return false;
                    }
                }
            }
        }
    }

    return error.empty();
}

bool AvatarBuilder::GenerateAvatarMap(GameObject const& go, NamedTransforms& namedTransforms, NamedTransforms& humanNamedTransforms, const HumanDescription& humanDescription, AvatarType avatarType, bool useMask, core::string &error)
{
    Assert(avatarType == kHumanoid || avatarType == kGeneric);

    Transform& rootTransform = go.GetComponent<Transform>();

    if (&rootTransform != &rootTransform.GetRoot())
    {
        error = Format("Transform '%s' must be the top most parent, found '%s'.", rootTransform.GetName(), rootTransform.GetRoot().GetName());
        return false;
    }

    // Get all the transform below root transform
    NamedTransforms namedAllTransforms;
    GetAllChildren(rootTransform, namedAllTransforms);

    if (avatarType == kGeneric && !humanDescription.m_RootMotionBoneName.empty())
    {
        Transform *root = GetRootMotionNode(humanDescription.m_RootMotionBoneName, namedAllTransforms);
        if (root == 0)
        {
            error = Format("Cannot find root motion transform '%s'.", humanDescription.m_RootMotionBoneName.c_str());
            return false;
        }
    }

    // Mask is mainly used for API call, when user want to select only a sub part of a hierarchy
    std::vector<core::string> mask;
    if (useMask)
    {
        SkeletonBoneList::const_iterator it;
        for (it = humanDescription.m_Skeleton.begin(); it != humanDescription.m_Skeleton.end(); ++it)
            mask.push_back(core::string(it->m_Name.c_str()));
    }

    GetAllChildren(rootTransform, namedTransforms, mask);

    if (avatarType == kHumanoid)
    {
        GetAllChildren(rootTransform, humanNamedTransforms, mask);
        RemoveAllNoneHumanLeaf(humanNamedTransforms, humanDescription);

        if (!AvatarBuilder::IsValidHuman(humanDescription, humanNamedTransforms, rootTransform, error))
        {
            return false;
        }
    }

    return true;
}

template<class InputIterator1> bool Include(InputIterator1 first1, InputIterator1 last1, core::string const& e)
{
    while (first1 != last1)
    {
        if ((*first1) == e)
            return true;
        first1++;
    }
    return false;
}

void AvatarBuilder::GetAllChildren(Transform& node, NamedTransforms& transforms, std::vector<core::string> const& mask)
{
    core::string path = CalculateTransformPath(node, &node.GetRoot());
    GetAllChildren(node, path, transforms, mask);
}

void AvatarBuilder::GetAllChildren(Transform& node, core::string& path, NamedTransforms& transforms, std::vector<core::string> const& mask)
{
    // @TODO: Does it make sense that you can exclude a node but it's child can still be included?
    //        That seems like it can only break stuff...
    bool isIncluded = mask.size() == 0 || Include(mask.begin(), mask.end(), core::string(node.GetName()));
    if (isIncluded)
    {
        transforms.push_back(NamedTransform());
        transforms.back().transform = &node;
        transforms.back().path = path;
        transforms.back().name = node.GetName();
    }

    for (int i = 0; i < node.GetChildrenCount(); i++)
    {
        Transform& child = node.GetChild(i);
        size_t pathLength = path.size();
        AppendTransformPath(path, child.GetName());

        GetAllChildren(child, path, transforms, mask);

        path.resize(pathLength);
    }
}

void AvatarBuilder::GetAllParent(Transform& node, NamedTransforms& transforms, std::vector<core::string> const& mask, bool includeSelf)
{
    GetAllParent(node.GetRoot(), node, transforms, mask, includeSelf);
}

void AvatarBuilder::GetAllParent(Transform& root, Transform& node, NamedTransforms& transforms, std::vector<core::string> const& mask, bool includeSelf)
{
    if (node.GetParent() != NULL)
    {
        Transform& parent = *node.GetParent();

        // Insertion order matter, top most node must be inserted first
        GetAllParent(root, parent, transforms, mask);

        bool isIncluded = mask.size() == 0 || Include(mask.begin(), mask.end(), core::string(parent.GetName()));
        if (isIncluded)
        {
            transforms.push_back(NamedTransform());
            transforms.back().transform = &parent;
            transforms.back().path = CalculateTransformPath(parent, &root);
            transforms.back().name = parent.GetName();
        }
    }

    if (includeSelf)
    {
        bool isIncluded = mask.size() == 0 || Include(mask.begin(), mask.end(), core::string(node.GetName()));
        if (isIncluded)
        {
            transforms.push_back(NamedTransform());
            transforms.back().transform = &node;
            transforms.back().path = CalculateTransformPath(node, &root);
            transforms.back().name = node.GetName();
        }
    }
}

Transform*  AvatarBuilder::GetRootMotionNode(const core::string &rootMotionBoneName, NamedTransforms const& transforms)
{
    NamedTransforms::const_iterator it = std::find_if(transforms.begin(), transforms.end(), FindBone(rootMotionBoneName));
    return it != transforms.end() ? it->transform : 0;
}

void AvatarBuilder::ReadFromLocalTransformToSkeletonPose(mecanim::skeleton::SkeletonPose* pose, NamedTransforms const& namedTransform)
{
    math::trsX* ptrXform = pose->m_X.Get();
    size_t j;
    for (j = 0; j < namedTransform.size(); j++)
    {
        Transform& transform = *namedTransform[j].transform;

        math::trsX& x = pose->m_X[j];

        Assert(&x < ptrXform + pose->m_Count);

        x = xformFromUnity(transform.GetLocalPosition(), transform.GetLocalRotation(), transform.GetLocalScale());
    }
}

bool AvatarBuilder::TPoseMatch(mecanim::animation::AvatarConstant const& avatar, NamedTransforms const& namedTransform, core::string& posWarning, core::string& rotWarning)
{
    bool ret = true;

    if (avatar.isHuman())
    {
        mecanim::memory::MecanimAllocator alloc(kMemTempAlloc);

        mecanim::skeleton::SkeletonPose*  avatarHumanPose = mecanim::skeleton::CreateSkeletonPose<math::trsX>(avatar.m_Human->m_Skeleton.Get(), alloc);

        mecanim::skeleton::SkeletonPoseCopy(avatar.m_AvatarSkeleton.Get(), avatar.m_DefaultPose.Get(), avatar.m_Human->m_Skeleton.Get(), avatarHumanPose);

        std::vector<bool> isHumanBone(avatar.m_Human->m_Skeleton->m_Count, false);

        for (size_t boneIter = 0; boneIter < mecanim::human::kLastBone; boneIter++)
        {
            if (avatar.m_Human->m_HumanBoneIndex[boneIter] != -1)
            {
                isHumanBone[avatar.m_Human->m_HumanBoneIndex[boneIter]] = true;
            }
        }

        if (!avatar.m_Human->m_LeftHand.IsNull())
        {
            for (size_t boneIter = 0; boneIter < mecanim::hand::s_BoneCount; boneIter++)
            {
                if (avatar.m_Human->m_LeftHand->m_HandBoneIndex[boneIter] != -1)
                {
                    isHumanBone[avatar.m_Human->m_LeftHand->m_HandBoneIndex[boneIter]] = true;
                }
            }
        }

        if (!avatar.m_Human->m_RightHand.IsNull())
        {
            for (size_t boneIter = 0; boneIter < mecanim::hand::s_BoneCount; boneIter++)
            {
                if (avatar.m_Human->m_RightHand->m_HandBoneIndex[boneIter] != -1)
                {
                    isHumanBone[avatar.m_Human->m_RightHand->m_HandBoneIndex[boneIter]] = true;
                }
            }
        }

        // Do not check for human hips bone lenght, because an animation is not guarantee to start at origin.
        mecanim::uint32_t i = avatar.m_Human->m_HumanBoneIndex[mecanim::human::kHips + 1];
        for (; i < avatar.m_Human->m_Skeleton->m_Count; ++i)
        {
            float positionError = math::length(avatar.m_Human->m_SkeletonPose->m_X[i].t - avatarHumanPose->m_X[i].t) / avatar.m_Human->m_Scale * 1000.0f;

            if (positionError > 1) // normalized millimeter
            {
                posWarning += Format("\t'%s' : position error = %f mm\n", namedTransform[avatar.m_HumanSkeletonIndexArray[i]].transform->GetName(), positionError);
                ret = false;
            }

            if (!isHumanBone[i])
            {
                math::float4 deltaQ = math::normalize(math::quatMul(math::quatConj(avatar.m_Human->m_SkeletonPose->m_X[i].q), avatarHumanPose->m_X[i].q));

                float deltaAngle = 2.0f * math::degrees(math::asin(math::length(deltaQ.xyz)));

                if (deltaAngle > 0.05f) // degree
                {
                    rotWarning += Format("\t'%s' : rotation error = %f deg\n", namedTransform[avatar.m_HumanSkeletonIndexArray[i]].transform->GetName(), deltaAngle);
                    ret = false;
                }
            }
        }

        mecanim::skeleton::DestroySkeletonPose(avatarHumanPose, alloc);
    }

    return ret;
}

void AvatarBuilder::RemoveAllNoneHumanLeaf(NamedTransforms& namedTransform, HumanDescription const & humanDescription)
{
    for (int n = namedTransform.size() - 1; n >= 0; n--)
    {
        Transform& transfom = *namedTransform[n].transform;

        bool hasAnyChildMapped = false;

        for (int i = 0; i < transfom.GetChildrenCount() && !hasAnyChildMapped; i++)
        {
            NamedTransforms::const_iterator ntIt = std::find_if(namedTransform.begin() + n, namedTransform.end(), FindBone(transfom.GetChild(i).GetName()));
            hasAnyChildMapped = ntIt != namedTransform.end();
        }

        if (!hasAnyChildMapped)
        {
            HumanBoneList::const_iterator hdIt = std::find_if(humanDescription.m_Human.begin(), humanDescription.m_Human.end(), FindBoneName(transfom.GetName()));

            if (hdIt == humanDescription.m_Human.end())
            {
                namedTransform.erase(namedTransform.begin() + n);
            }
        }
    }
}
