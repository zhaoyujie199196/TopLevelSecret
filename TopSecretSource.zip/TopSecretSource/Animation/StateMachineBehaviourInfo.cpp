#include "UnityPrefix.h"
#include "StateMachineBehaviourInfo.h"
#include "Runtime/Mono/MonoScript.h"

bool HasInvalidBehaviourPredicate::operator()(PPtr<MonoBehaviour> const& behaviour)
{
    if (behaviour.IsNull())
        return true;

    if (behaviour->GetScript().IsNull())
        return true;

    return false;
}
