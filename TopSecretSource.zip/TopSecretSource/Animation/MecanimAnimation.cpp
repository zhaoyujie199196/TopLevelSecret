#include "UnityPrefix.h"

#include "MecanimAnimation.h"

#include "Animator.h"
#include "Avatar.h"
#include "Runtime/mecanim/animation/avatar.h"
#include "Runtime/mecanim/skeleton/skeleton.h"

#include "Runtime/Logging/LogAssert.h"
#include "Runtime/Utilities/Word.h"

#include "GenericAnimationBindingCache.h"
#include "CalculateAnimatorSkinMatrices.h"

bool MecanimAnimation::PathHashesToIndices(Unity::Component& animatorComponent, const BindingHash* bonePathHashes, size_t count, UInt16* outIndices)
{
    Animator& animator = static_cast<Animator&>(animatorComponent);
    if (animator.GetHasTransformHierarchy())
        return false;

    const mecanim::animation::AvatarConstant* avatarConstant = animator.GetAvatarConstant();
    if (!avatarConstant)
        return false;

    const mecanim::skeleton::Skeleton* skel = avatarConstant->m_AvatarSkeleton.Get();
    if (!skel)
        return false;

    bool doMatchSkeleton = true;
    for (size_t i = 0; i < count && doMatchSkeleton; i++)
    {
        int skeletonIndex = mecanim::skeleton::SkeletonFindNode(skel, bonePathHashes[i]);
        doMatchSkeleton = (skeletonIndex != -1);
        outIndices[i] = (UInt16)skeletonIndex;
    }

    if (!doMatchSkeleton)
    {
        const Avatar* avatar = animator.GetAvatar();
        const char* avatarName = avatar ? avatar->GetName() : "NULL";
        ErrorStringObject(Format("The input bones do not match the skeleton of the Avatar(%s).\n"
                "Please check if the Avatar is generated in optimized mode, or if the Avatar is valid for the attached SkinnedMeshRenderer.",
                avatarName).c_str(),
            avatar);
    }

    return doMatchSkeleton;
}

void MecanimAnimation::RegisterIAnimationBinding(const Unity::Type* type, int inCustomType, IAnimationBinding* bindingInterface)
{
    UnityEngine::Animation::GetGenericAnimationBindingCache().RegisterIAnimationBinding(type, inCustomType, bindingInterface);
}

JobFence& MecanimAnimation::GetReadWriteGlobalSpaceSkeletonPoseFence(Unity::Component* animator)
{
    return static_cast<Animator*>(animator)->GetReadWriteGlobalSpaceSkeletonPoseFence();
}
