#pragma once

#include "Runtime/Animation/Director/AnimationPlayable.h"

class AnimationPosePlayable : public AnimationPlayable
{
public:

    AnimationPosePlayable(DirectorPlayerType playerType);

    virtual void AllocateBindings(AnimationPlayableEvaluationConstant const *constant);
    virtual void DeallocateBindings();

    virtual void ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output);


    virtual void PreProcessAnimation(AnimationPlayableEvaluationConstant const *constant, mecanim::animation::AnimationNodeState const* state);

    bool MustReadPreviousPose() const           { return m_MustReadPreviousPose; }
    void SetMustReadPreviousPose(bool value)    { m_MustReadPreviousPose = value; }

    bool GetApplyFootIK() const                 { return m_ApplyFootIK; }
    void SetApplyFootIK(bool value)             { m_ApplyFootIK = value; }

private:
    friend class PlayableGraph;
    mecanim::animation::AnimationNodeState* m_AnimationNodeState;
    bool m_MustReadPreviousPose;

    bool m_ApplyFootIK;
};
