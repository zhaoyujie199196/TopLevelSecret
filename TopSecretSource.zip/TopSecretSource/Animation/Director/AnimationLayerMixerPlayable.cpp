#include "UnityPrefix.h"
#include "Runtime/Animation/AnimatorConfigure.h"
#include "Runtime/mecanim/animation/controller.h"
#include "Runtime/Animation/Director/AnimationLayerMixerPlayable.h"
#include "Runtime/mecanim/animation/avatar.h"

static void BindSkeletonMask(mecanim::ValueArrayConstant const &valueConstant, mecanim::skeleton::SkeletonMask const *skeletonMask, mecanim::ValueArrayMask &mask);

static void BindControllerRootMotionMask(const mecanim::animation::AvatarConstant &avatar, const mecanim::animation::ControllerConstant &controller, AnimationLayerMixerPlayable::Memory &layerMixerMemory);


ANIMATOR_PROFILER_INFORMATION_DETAIL(gAnimationLayerMixerPlayableProcessAnimation, "AnimationLayerMixerPlayable.ProcessAnimation", kProfilerAnimation);

AnimationLayerMixerPlayable::AnimationLayerMixerPlayable(DirectorPlayerType playerType)
    : AnimationPlayable(playerType)
    , m_ControllerConstant(NULL)
{
#if ANIMATION_PLAYABLE_SANITY_CHECK
    m_Type = eAnimationLayerMixerPlayable;
#endif
}

bool AnimationLayerMixerPlayable::SetInputConnection(Playable* input, int inputPort)
{
    if (!AnimationPlayable::SetInputConnection(input, inputPort))
        return false;

    m_LayerParameters.resize_initialized(m_Connections->m_Inputs.size(), LayerParameters());
    Assert(m_LayerParameters.size() == m_Connections->m_Inputs.size());

    return true;
}

void AnimationLayerMixerPlayable::SetInputWeight(int inputIndex, float weight)
{
    Assert(inputIndex < m_LayerParameters.size());
    Playable::SetInputWeight(inputIndex, weight);

    if (inputIndex < m_LayerParameters.size())
        m_LayerParameters[inputIndex].m_LayerWeight = weight;
}

void AnimationLayerMixerPlayable::MixOutputs(AnimationPlayableEvaluationConstant *constant, AnimationPlayableEvaluationInput *input, AnimationPlayableEvaluationOutput* output,  AnimationPlayableEvaluationOutput* layer, float weight, bool additive,
    bool layerRootMotionMask, mecanim::human::HumanPoseMask const * userDefinedHumanPoseMask)
{
    bool hasRootMotion = constant->hasRootMotion;
    bool isHuman = constant->isHuman;

    mecanim::human::HumanPoseMask const *layerHumanPoseMask =  userDefinedHumanPoseMask ? userDefinedHumanPoseMask : input->humanPoseMask;

    output->m_IKOnFeet |= layer->m_IKOnFeet;

    mecanim::ValueArray const *defaultValues = input->defaultValuesOverride != NULL ?  input->defaultValuesOverride : constant->defaultValues;

    mecanim::ValueArrayAdd(defaultValues, layer->nodeStateOutput->m_DynamicValues, layer->nodeStateOutput->m_DynamicValuesMask, weight, additive, output->nodeStateOutput->m_DynamicValues, output->nodeStateOutput->m_DynamicValuesMask);

    if (!additive && (hasRootMotion || isHuman))
    {
        bool rootMotionMask = hasRootMotion && layerRootMotionMask;

        mecanim::animation::MotionAddOverrideLayer(output->nodeStateOutput->m_MotionOutput,
            layer->nodeStateOutput->m_MotionOutput,
            weight,
            rootMotionMask,
            isHuman,
            *layerHumanPoseMask);
    }

    if (isHuman)
    {
        mecanim::human::Human const *human = constant->avatarConstant->m_Human.Get();

        mecanim::human::HumanPoseMask mask = *layerHumanPoseMask;
        mask.set(mecanim::human::kMaskLeftHand, mask.test(mecanim::human::kMaskLeftHand) && human->m_HasLeftHand);
        mask.set(mecanim::human::kMaskRightHand, mask.test(mecanim::human::kMaskRightHand) && human->m_HasRightHand);

        if (additive)
        {
            mecanim::human::HumanPoseAddAdditiveLayer(*output->nodeStateOutput->m_HumanPose, *layer->nodeStateOutput->m_HumanPose, weight, mask);

            if (output->nodeStateOutput->m_HumanPoseBase != 0 && mask.test(mecanim::human::kMaskRootIndex))
            {
                mecanim::human::HumanPoseAddAdditiveLayer(*output->nodeStateOutput->m_HumanPoseBase, *layer->nodeStateOutput->m_HumanPoseBase, weight, mask);
            }
        }
        else
        {
            mecanim::human::HumanPoseAddOverrideLayer(*output->nodeStateOutput->m_HumanPose, *layer->nodeStateOutput->m_HumanPose, weight, mask);

            if (output->nodeStateOutput->m_HumanPoseBase != 0 && mask.test(mecanim::human::kMaskRootIndex))
            {
                mecanim::human::HumanPoseAddOverrideLayer(*output->nodeStateOutput->m_HumanPoseBase, *layer->nodeStateOutput->m_HumanPoseBase, weight, mask);
            }
        }
    }
}

float AnimationLayerMixerPlayable::GetLayerWeight(unsigned int layerIndex) const
{
    Assert(layerIndex < m_LayerParameters.size());

    return m_LayerParameters[layerIndex].m_LayerWeight;
}

void AnimationLayerMixerPlayable::ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    ANIMATOR_PROFILER_AUTO_DETAIL(gAnimationLayerMixerPlayableProcessAnimation, NULL);

    mecanim::memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);

    bool hasRootMotion = constant->hasRootMotion;
    bool isHuman = constant->isHuman;

    int childCount = m_Connections->m_Inputs.size();

    if (childCount == 1 && !m_LayerParameters[0].m_Additive)
    {
        AnimationPlayable* animationPlayable = GetNextCompatibleDescendant(0);
        LayerParameters& parameters = m_LayerParameters[0];

        mecanim::ValueArrayMask const *layerValuesMask = m_LayerMixerMemory.m_DynamicValuesMaskArray[0];
        mecanim::human::HumanPoseMask const *layerHumanPoseMask = parameters.m_HumanPoseMask != 0 ? parameters.m_HumanPoseMask : input->humanPoseMask;

        AnimationPlayableEvaluationInput childInput;
        childInput = *input;
        childInput.additive = parameters.m_Additive;
        childInput.humanPoseMask = layerHumanPoseMask;
        childInput.lastEvaluationValues =  m_LayerMixerMemory.nodeStateArray[0]->m_DynamicValues;


        animationPlayable->ProcessAnimation(constant, &childInput, output);

        if (layerValuesMask)
        {
            AndValueMask(output->nodeStateOutput->m_DynamicValuesMask, layerValuesMask);
        }

        if (isHuman)
        {
            mecanim::human::HumanPoseClear(*output->nodeStateOutput->m_HumanPose, *childInput.humanPoseMask);
        }


        mecanim::animation::CopyAnimationNodeState(output->nodeStateOutput, m_LayerMixerMemory.nodeStateArray[0], hasRootMotion, isHuman, *childInput.humanPoseMask);
    }
    else
    {
        SetValueMask(output->nodeStateOutput->m_DynamicValuesMask, true);

        if (hasRootMotion || isHuman)
        {
            ClearAnimationNodeState(output->nodeStateOutput, isHuman);
        }

        if (childCount > 0)
        {
            mecanim::animation::AnimationNodeState *nodeState = 0;
            mecanim::memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);
            mecanim::ValueArray* lastEvaluationValues = mecanim::CreateValueArray(constant->values, tempAllocator);
            mecanim::ValueArrayCopy(output->nodeStateOutput->m_DynamicValues, lastEvaluationValues);

            for (int childIndex = 0; childIndex < childCount; childIndex++)
            {
                nodeState = m_LayerMixerMemory.nodeStateArray[childIndex];
                LayerParameters& layerData = m_LayerParameters[childIndex];


                float weight =  m_Connections->m_Inputs[childIndex].weight;

                if (weight > 0)
                {
                    bool layerAdditive = layerData.m_Additive;

                    mecanim::ValueArrayMask const *layerValuesMask = m_LayerMixerMemory.m_DynamicValuesMaskArray[childIndex];
                    mecanim::human::HumanPoseMask layerHumanPoseMask = layerData.m_HumanPoseMask != 0 ? *layerData.m_HumanPoseMask : *input->humanPoseMask;

                    AnimationPlayable* animationPlayable  = GetNextCompatibleDescendant(childIndex);

                    AnimationPlayableEvaluationInput childInput;
                    childInput = *input;
                    childInput.additive = layerAdditive;
                    childInput.humanPoseMask = &layerHumanPoseMask;
                    childInput.lastEvaluationValues = lastEvaluationValues;

                    InvertValueMask(output->nodeStateOutput->m_DynamicValuesMask);
                    mecanim::ValueArrayCopy(output->nodeStateOutput->m_DynamicValues, childInput.lastEvaluationValues, output->nodeStateOutput->m_DynamicValuesMask);
                    InvertValueMask(output->nodeStateOutput->m_DynamicValuesMask);

                    AnimationPlayableEvaluationOutput childOutput;
                    childOutput.nodeStateOutput = nodeState;

                    animationPlayable->ProcessAnimation(constant, &childInput, &childOutput);
                    bool layerRootMotionMask = nodeState->m_MotionReadMask && m_LayerMixerMemory.m_RootMotionLayerMask[childIndex];

                    layerRootMotionMask |= constant->applyMotionX;
                    output->m_IKOnFeet |= childOutput.m_IKOnFeet;

                    if (layerValuesMask)
                    {
                        AndValueMask(childOutput.nodeStateOutput->m_DynamicValuesMask, layerValuesMask);
                    }

                    if (!nodeState->m_HumanReadMask)
                        layerHumanPoseMask.reset();


                    MixOutputs(constant, input, output, &childOutput, weight, layerAdditive, layerRootMotionMask && nodeState->m_MotionReadMask, &layerHumanPoseMask);

                    output->nodeStateOutput->m_MotionReadMask   |= childOutput.nodeStateOutput->m_MotionReadMask;
                    output->nodeStateOutput->m_HumanReadMask    |= childOutput.nodeStateOutput->m_HumanReadMask;
                }
            }

            DestroyValueArray(lastEvaluationValues, tempAllocator);
        }

        InvertValueMask(output->nodeStateOutput->m_DynamicValuesMask);
    }
}

void AnimationLayerMixerPlayable::PrepareAnimationEvents(float weight, AnimationClipEventInfos& eventInfos)
{
    int inputSize = m_Connections->m_Inputs.size();
    for (int i = 0; i < inputSize; ++i)
    {
        const LayerParameters& layerData = m_LayerParameters[i];

        // Skip animation events if layer weight is zero
        // case 812917
        if (layerData.m_LayerWeight > 0)
        {
            AnimationPlayable* childAnimationPlayable = GetNextCompatibleDescendant(i);
            if (childAnimationPlayable != NULL)
            {
                float childWeight = weight * m_Connections->m_Inputs[i].weight;
                childAnimationPlayable->PrepareAnimationEvents(childWeight, eventInfos);
            }
        }
    }
}

void AnimationLayerMixerPlayable::AllocateBindings(AnimationPlayableEvaluationConstant const *constant)
{
    if (!m_BindingsAllocated)
    {
        bool hasRootMotion = constant->hasRootMotion;
        bool isHuman = constant->isHuman;
        bool affectMassCenter = constant->affectMassCenter;

        size_t childCount = m_Connections->m_Inputs.size();
        m_LayerMixerMemory.CreateNodeStateArray(childCount, *constant->values, hasRootMotion, isHuman, affectMassCenter, m_Allocator);

        m_LayerMixerMemory.m_DynamicValuesMaskArray = m_Allocator.ConstructArray<mecanim::ValueArrayMask *>(childCount);
        m_LayerMixerMemory.m_RootMotionLayerMask    = m_Allocator.ConstructArray<bool>(childCount);

        for (int nodeIter = 0; nodeIter < childCount; nodeIter++)
        {
            ValueArrayCopy(constant->defaultValues, m_LayerMixerMemory.nodeStateArray[nodeIter]->m_DynamicValues);
            m_LayerMixerMemory.m_DynamicValuesMaskArray[nodeIter] = mecanim::CreateValueArrayMask(constant->controllerBindingConstant->m_AnimationSet->m_DynamicFullValuesConstant, m_Allocator);


            if (m_ControllerConstant != NULL)
            {
                m_LayerParameters[nodeIter].m_HumanPoseMask = &m_ControllerConstant->m_LayerArray[nodeIter]->m_BodyMask;

                BindSkeletonMask(*constant->controllerBindingConstant->m_AnimationSet->m_DynamicFullValuesConstant, m_ControllerConstant->m_LayerArray[nodeIter]->m_SkeletonMask.Get(), *m_LayerMixerMemory.m_DynamicValuesMaskArray[nodeIter]);

                BindControllerRootMotionMask(*constant->avatarConstant, *m_ControllerConstant, m_LayerMixerMemory);
            }
            else
            {
                mecanim::SetValueMask(m_LayerMixerMemory.m_DynamicValuesMaskArray[nodeIter], true);
                m_LayerMixerMemory.m_RootMotionLayerMask[nodeIter] = true;
            }
        }
    }

    AnimationPlayable::AllocateBindings(constant);
}

void AnimationLayerMixerPlayable::DeallocateBindings()
{
    if (m_BindingsAllocated)
    {
        size_t layerCount = m_Connections->m_Inputs.size();
        for (int layer = 0; layer < layerCount; layer++)
            mecanim::DestroyValueArrayMask(m_LayerMixerMemory.m_DynamicValuesMaskArray[layer], m_Allocator);

        m_Allocator.Deallocate(m_LayerMixerMemory.m_RootMotionLayerMask);
        m_Allocator.Deallocate(m_LayerMixerMemory.m_DynamicValuesMaskArray);
        m_LayerMixerMemory.DestroyNodeStateArray(m_Allocator);

        m_LayerMixerMemory.m_DynamicValuesMaskArray = NULL;
        m_LayerMixerMemory.m_RootMotionLayerMask = NULL;
    }
    AnimationPlayable::DeallocateBindings();
}

void AnimationLayerMixerPlayable::ClearBindings()
{
    DeallocateResources();
}

void AnimationLayerMixerPlayable::Memory::CreateNodeStateArray(int nodeCount, mecanim::ValueArrayConstant const &values, bool hasRootMotion, bool isHuman, bool affectMassCenter, mecanim::memory::Allocator& alloc)
{
    if (nodeStateArray.size() != nodeCount)
    {
        DestroyNodeStateArray(alloc);

        nodeStateArray.resize_uninitialized(nodeCount);

        for (int nodeIter = 0; nodeIter < nodeCount; nodeIter++)
        {
            nodeStateArray[nodeIter] = mecanim::animation::CreateAnimationNodeState(values, hasRootMotion, isHuman, affectMassCenter, alloc);
        }
    }
}

void AnimationLayerMixerPlayable::Memory::DestroyNodeStateArray(mecanim::memory::Allocator& alloc)
{
    for (int nodeIter = 0; nodeIter < nodeStateArray.size(); nodeIter++)
    {
        DestroyAnimationNodeState(nodeStateArray[nodeIter], alloc);
    }

    nodeStateArray.clear();
}

static void BindSkeletonMask(const mecanim::ValueArrayConstant& valueConstant, const mecanim::skeleton::SkeletonMask* skeletonMask, mecanim::ValueArrayMask& mask)
{
    bool emptyMask = skeletonMask == NULL || skeletonMask->m_Count == 0;

    for (size_t maskIter = 0; maskIter < valueConstant.m_Count; maskIter++)
    {
        bool maskValue = false;

        if (emptyMask || (valueConstant.m_ValueArray[maskIter].m_Type == mecanim::kFloatType))
        {
            maskValue = true;
        }
        else
        {
            bool found = false;

            for (size_t skIter = 0; !found && skIter < skeletonMask->m_Count; skIter++)
            {
                if (skeletonMask->m_Data[skIter].m_Weight > 0)
                {
                    found = valueConstant.m_ValueArray[maskIter].m_ID == 0 || valueConstant.m_ValueArray[maskIter].m_ID == skeletonMask->m_Data[skIter].m_PathHash;
                }
            }

            maskValue = found;
        }

        int index = valueConstant.m_ValueArray[maskIter].m_Index;
        switch (valueConstant.m_ValueArray[maskIter].m_Type)
        {
            case mecanim::kPositionType:
                mask.m_PositionValues[index] = maskValue;
                break;
            case mecanim::kQuaternionType:
                mask.m_QuaternionValues[index] = maskValue;
                break;
            case mecanim::kScaleType:
                mask.m_ScaleValues[index] = maskValue;
                break;
            case mecanim::kFloatType:
                mask.m_FloatValues[index] = maskValue;
                break;
            case mecanim::kInt32Type:
                mask.m_IntValues[index] = maskValue;
                break;
            default:
                Assert("Unsupported");
        }
    }
}

static void BindControllerRootMotionMask(const mecanim::animation::AvatarConstant &avatar, const mecanim::animation::ControllerConstant &controller, AnimationLayerMixerPlayable::Memory& layerMixerMemory)
{
    mecanim::uint32_t rootMotionNodePathHash = 0;

    if (avatar.m_RootMotionBoneIndex != -1)
    {
        rootMotionNodePathHash = avatar.m_AvatarSkeleton->m_ID[avatar.m_RootMotionBoneIndex];
    }

    for (mecanim::uint32_t layerIter = 0; layerIter < controller.m_LayerCount; layerIter++)
    {
        bool found = controller.m_LayerArray[layerIter]->m_SkeletonMask.IsNull() || controller.m_LayerArray[layerIter]->m_SkeletonMask->m_Count == 0;
        bool mask =  layerIter == 0 ? true : found;

        for (mecanim::uint32_t maskIter = 0; !found && maskIter < controller.m_LayerArray[layerIter]->m_SkeletonMask->m_Count; maskIter++)
        {
            found = controller.m_LayerArray[layerIter]->m_SkeletonMask->m_Data[maskIter].m_PathHash == rootMotionNodePathHash;

            if (found)
            {
                mask = controller.m_LayerArray[layerIter]->m_SkeletonMask->m_Data[maskIter].m_Weight > 0;
            }
        }

        layerMixerMemory.m_RootMotionLayerMask[layerIter] = mask;
    }
}
