#pragma once

#include "Runtime/Animation/Director/AnimationPlayable.h"

class AnimationMotionXToDeltaPlayable : public AnimationPlayable
{
public:

    AnimationMotionXToDeltaPlayable(DirectorPlayerType playerType);

    virtual void ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output);

    virtual bool GetApplyMotionX() const { return true; }
private:


    math::trsX  m_PreviousX;
    bool        m_IsActive;
};
