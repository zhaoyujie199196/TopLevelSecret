#pragma once

#include "Runtime/Animation/Director/AnimationPlayable.h"

class AnimationMixerPlayable : public AnimationPlayable
{
public:

    DEFINE_PLAYABLE(AnimationMixerPlayable, GetAnimationScriptingClasses().animationMixerPlayable, AnimationPlayable);

    virtual bool SetInputConnection(Playable* input, int inputPort);

    virtual void ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output);

    void SetAutoNormalize(bool enable) { m_AutoNormalize = enable; }
    bool GetAutoNormalize() const { return m_AutoNormalize; }
private:
    friend class PlayableGraph;

    bool    m_AutoNormalize;
};
