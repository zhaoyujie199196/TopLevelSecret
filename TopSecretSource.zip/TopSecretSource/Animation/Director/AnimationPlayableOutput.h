#pragma once

#include "Runtime/Director/Core/PlayableOutput.h"

class Animator;

class AnimationPlayableOutput : public PlayableOutput
{
public:
    AnimationPlayableOutput(UInt32 nameHash, PlayableGraph* parentGraph);
    virtual void Destroy();

    Animator* GetTargetAnimator() const;
    void SetTargetAnimator(Animator* target);

    virtual bool SetSourcePlayable(Playable* source);

    virtual void OnPlayerDestroyed(Object* player);

    virtual DirectorPlayerType GetPlayerType() const { return kAnimation; }
    virtual void GetStages(StageDescriptionArray& out_batches) const;
    virtual void OnConnectionHashChange();

private:

    void Unbind();
    void Bind();

    Animator* m_TargetAnimator;
};
