#include "UnityPrefix.h"
#include "Runtime/Animation/AnimatorConfigure.h"
#include "Runtime/Animation/Director/AnimationClipPlayable.h"
#include "Runtime/Animation/AnimationClip.h"
#include "Runtime/mecanim/animation/avatar.h"
#include "Runtime/mecanim/statemachine/statemachine.h"

#include "Runtime/Animation/MecanimUtility.h"
#include "Runtime/Input/TimeManager.h"
ANIMATOR_PROFILER_INFORMATION_DETAIL(gAnimationClipPlayableProcessAnimation, "AnimationClipPlayable.ProcessAnimation", kProfilerAnimation);
ANIMATOR_PROFILER_INFORMATION_DETAIL(gAnimationClipPlayablePrepareAnimationEvents, "AnimationClipPlayable.PrepareAnimationEvents", kProfilerAnimation);


namespace mecanim
{
namespace animation
{
    void AdjustPoseForMotion(AvatarConstant const& avatarConstant, SkeletonTQSMap const &tqsMap, math::trsX const &motionX, ValueArray &values, skeleton::SkeletonPose &poseWsA, skeleton::SkeletonPose &poseWsB)
    {
        int lastIndex = avatarConstant.m_RootMotionSkeleton->m_Count - 1;

        SkeletonPoseFromValueRecursive(*avatarConstant.m_RootMotionSkeleton.Get(), *avatarConstant.m_AvatarSkeletonPose.Get(), values, &tqsMap, avatarConstant.m_RootMotionSkeletonIndexArray.Get(), poseWsA, lastIndex, 0);

        skeleton::SkeletonPoseComputeGlobal(avatarConstant.m_RootMotionSkeleton.Get(), &poseWsA, &poseWsB);
        poseWsA.m_X[0] = motionX;

        if (avatarConstant.m_RootMotionBoneIndex > 0)
            skeleton::SkeletonPoseComputeGlobal(avatarConstant.m_RootMotionSkeleton.Get(), &poseWsA, &poseWsB, lastIndex - 1, 0);

        skeleton::SkeletonPoseComputeLocal(avatarConstant.m_RootMotionSkeleton.Get(), &poseWsB, &poseWsA, lastIndex, lastIndex);
        poseWsA.m_X[0] = math::trsIdentity();

        ValueFromSkeletonPoseRecursive(*avatarConstant.m_RootMotionSkeleton.Get(), poseWsA, &tqsMap, avatarConstant.m_RootMotionSkeletonIndexArray.Get(), values, lastIndex, 0);
    }

    void ComputeRootMotion(AvatarConstant const& avatarConstant, SkeletonTQSMap const &tqsMap, MotionOutput const &motionOutput, ValueArray &values, ValueArray &startValues, ValueArray &stopValues, skeleton::SkeletonPose &poseWsA, skeleton::SkeletonPose &poseWsB, bool loop)
    {
        if (loop)
        {
            AdjustPoseForMotion(avatarConstant, tqsMap, motionOutput.m_MotionStartX, startValues, poseWsA, poseWsB);
            AdjustPoseForMotion(avatarConstant, tqsMap, motionOutput.m_MotionStopX, stopValues, poseWsA, poseWsB);
        }
        AdjustPoseForMotion(avatarConstant, tqsMap, motionOutput.m_MotionX, values, poseWsA, poseWsB);
    }
}
}

AnimationClipPlayable::AnimationClipPlayable(DirectorPlayerType playerType)
    : AnimationPlayable(playerType)
    , m_AnimationClip(NULL)
    , m_ApplyFootIK(true)
    , m_RemoveStartOffset(false)
    , m_HumanReadMask(false)
    , m_MotionReadMask(false)
{
#if ANIMATION_PLAYABLE_SANITY_CHECK
    m_Type = eAnimationClipPlayable;
#endif
    SetScriptRestrictionFlags(kCantChangeTopology || kCantChangeWeights);
}

void AnimationClipPlayable::SetClip(AnimationClip* clip)
{
    if (m_AnimationClip != clip)
    {
        m_AnimationClip = clip;
        RequestAllocateBindings();
    }
}

NamedObject* AnimationClipPlayable::GetAsset() const
{
    return m_AnimationClip;
}

void AnimationClipPlayable::SetStateMachineMessage(mecanim::statemachine::StateMachineMessage message)
{
    m_AnimationClipMemory.m_MessageID = message;
}

void AnimationClipPlayable::OnAdvanceTime(double delta)
{
    if (!TimeHasBeenSet())
    {
        m_AnimationClipMemory.m_LastTime    = m_LocalTime;

        SetStateMachineMessage(mecanim::statemachine::kInvalid);
        if (m_AnimationClipMemory.m_FirstEval == mecanim::statemachine::kFirstEval)
            m_AnimationClipMemory.m_FirstEval = mecanim::statemachine::kFirstEvalCompleted;

        bool deltaTimeIs0 = delta == 0;
        if (m_AnimationClipMemory.m_FirstEval == mecanim::statemachine::kWaitForTick && !deltaTimeIs0)
        {
            SetStateMachineMessage(mecanim::statemachine::kOnStateEnter);
            m_AnimationClipMemory.m_FirstEval = mecanim::statemachine::kFirstEval;
        }
    }

    Playable::OnAdvanceTime(delta);
}

void AnimationClipPlayable::ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    ANIMATOR_PROFILER_AUTO_DETAIL(gAnimationClipPlayableProcessAnimation, NULL);

    mecanim::memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);

    bool isHuman = constant->isHuman;
    bool hasRootMotion = constant->hasRootMotion;
    output->nodeStateOutput->m_HumanReadMask    |= m_HumanReadMask;
    output->nodeStateOutput->m_MotionReadMask   |= m_MotionReadMask;
    output->m_IKOnFeet          |= m_ApplyFootIK;


    if (m_AnimationClipMemory.muscleConstant == 0)
    {
        if (!m_AnimationClipMemory.m_WriteDefaultValues)
        {
            mecanim::SetValueMask(output->nodeStateOutput->m_DynamicValuesMask, true);
            mecanim::ValueArrayCopy(input->lastEvaluationValues, output->nodeStateOutput->m_DynamicValues, output->nodeStateOutput->m_DynamicValuesMask);
        }
        else
        {
            mecanim::SetValueMask(output->nodeStateOutput->m_DynamicValuesMask, false);
        }

        if (hasRootMotion || isHuman)
        {
            ClearAnimationNodeState(output->nodeStateOutput, isHuman);
        }
    }
    else
    {
        mecanim::animation::ClipMuscleInput muscleInput;

        float clipDuration = m_AnimationClip->GetAverageDuration();
        muscleInput.m_Time = clipDuration != 0 ? m_LocalTime / clipDuration : 0.0f;
        muscleInput.m_PreviousTime = clipDuration != 0 ? m_AnimationClipMemory.m_LastTime / clipDuration : 0.0f;

        muscleInput.m_CycleOffset = m_AnimationClipMemory.m_CycleOffset;
        muscleInput.m_Speed = m_AnimationClipMemory.m_Speed;
        muscleInput.m_Mirror = m_AnimationClipMemory.m_Mirror;
        muscleInput.m_ComputeCycleX = input->applyMotionX;

        mecanim::animation::ClipMuscleConstant const &muscleConstant = *m_AnimationClipMemory.muscleConstant;
        mecanim::animation::Clip const *clip = muscleConstant.m_Clip.Get();
        mecanim::animation::ClipBindings const &clipBindings = *m_AnimationClipMemory.clipBindings;
        mecanim::ValueArray const &defaultValues = input->defaultValuesOverride != NULL ?  *input->defaultValuesOverride : *constant->defaultValues;
        mecanim::animation::AvatarConstant const &avatarConstant = *constant->avatarConstant;
        mecanim::animation::SkeletonTQSMap const &tqsMap = *constant->tqsMap;
        mecanim::int32_t gravityWeightIndex = constant->gravityWeightIndex;
        mecanim::int32_t integerRemapStride = constant->integerRemapStride;

        bool additive = input->additive;
        mecanim::animation::AvatarInput const &avatarInput = *input->avatarInput;

        mecanim::animation::ClipMemory& clipMemory = *m_AnimationClipMemory.clipMemory;

        mecanim::animation::AnimationNodeState &nodeStateOutput = *output->nodeStateOutput;

        mecanim::ValueArray *valuesOutput = nodeStateOutput.m_DynamicValues;
        mecanim::animation::MotionOutput *motionOutput = nodeStateOutput.m_MotionOutput;
        mecanim::human::HumanPose *humanPoseOutput = nodeStateOutput.m_HumanPose;

        mecanim::animation::ClipOutput *clipOutputPrev = 0;
        mecanim::animation::ClipOutput *clipOutput = mecanim::animation::CreateClipOutput(clip, tempAllocator);

        mecanim::animation::ClipInput inPrev;
        float timeIntPrev;
        float normalizedTimePrev = 0;

        mecanim::animation::ClipInput in;
        float timeInt;
        float normalizedTime = 0;

        if (hasRootMotion || isHuman)
        {
            // @TODO: just alloc what is needed to evaluate root motion curvres
            clipOutputPrev = mecanim::animation::CreateClipOutput(clip, tempAllocator);

            inPrev.m_Time = mecanim::animation::ComputeClipTime(muscleInput.m_PreviousTime, muscleConstant.m_StartTime, muscleConstant.m_StopTime,
                    muscleConstant.m_CycleOffset + muscleInput.m_CycleOffset,
                    muscleConstant.m_LoopTime, muscleInput.m_Speed,
                    normalizedTimePrev, timeIntPrev, muscleInput.m_Time < 0);

            // @TODO: just evalute root motion curvres
            EvaluateClip(muscleConstant.m_Clip.Get(), &inPrev, &clipMemory, clipOutputPrev);
        }

        in.m_Time = mecanim::animation::ComputeClipTime(muscleInput.m_Time, muscleConstant.m_StartTime, muscleConstant.m_StopTime,
                muscleConstant.m_CycleOffset + muscleInput.m_CycleOffset,
                muscleConstant.m_LoopTime, muscleInput.m_Speed,
                normalizedTime, timeInt, muscleInput.m_Time < 0);

        EvaluateClip(muscleConstant.m_Clip.Get(), &in, &clipMemory, clipOutput);

        if (hasRootMotion || isHuman)
        {
            muscleInput.m_RemoveStartOffset = m_RemoveStartOffset;
            EvaluateRootMotion(muscleConstant, muscleInput, clipOutputPrev->m_Values, clipOutput->m_Values, *motionOutput, isHuman);
        }

        ValuesFromClip((!additive && !m_AnimationClipMemory.m_WriteDefaultValues && input->lastEvaluationValues) ?  *input->lastEvaluationValues : defaultValues, muscleConstant, *clipOutput, clipBindings, integerRemapStride, *valuesOutput, *nodeStateOutput.m_DynamicValuesMask, !m_AnimationClipMemory.m_WriteDefaultValues);

        mecanim::ValueArray *valuesStartWs = 0;
        mecanim::ValueArray *valuesStopWs = 0;
        mecanim::ValueArray *valuesAdditiveReferencePose = 0;

        const bool loop = muscleConstant.m_LoopTime && muscleConstant.m_LoopBlend;

        if (additive || loop)
        {
            valuesStartWs =  CreateValueArray(constant->values, tempAllocator);
            valuesStopWs =  CreateValueArray(constant->values, tempAllocator);
            valuesAdditiveReferencePose =  CreateValueArray(constant->values, tempAllocator);

            DeltasFromClip(muscleConstant, clipBindings, *nodeStateOutput.m_DynamicValuesMask, *valuesStartWs, *valuesStopWs, *valuesAdditiveReferencePose);
        }

        if (hasRootMotion || isHuman)
        {
            if (isHuman)
            {
                EvaluateHumanPose(muscleConstant, muscleInput, clipOutput->m_Values, *motionOutput, *humanPoseOutput);

                if (additive)
                {
                    mecanim::human::HumanPose humanPoseWs;

                    if (!muscleConstant.m_ValueArrayReferencePose.IsNull())
                        GetHumanPose(muscleConstant, muscleConstant.m_ValueArrayReferencePose.Get(), humanPoseWs);
                    else
                        GetHumanPose(muscleConstant, muscleConstant.m_ValueArrayDelta.Get(), humanPoseWs);

                    if (muscleConstant.m_Mirror)
                    {
                        HumanPoseMirror(humanPoseWs, humanPoseWs);
                    }

                    humanPoseOutput->m_RootX = math::mul(motionOutput->m_MotionX, humanPoseOutput->m_RootX);
                    HumanPoseSub(*humanPoseOutput, *humanPoseOutput, humanPoseWs);

                    for (mecanim::uint32_t i = 0; i < mecanim::human::kLastGoal; i++)
                    {
                        humanPoseOutput->m_GoalArray[i].m_X = math::trsIdentity();
                    }

                    MotionOutputClear(motionOutput);
                }

                if (nodeStateOutput.m_HumanPoseBase != 0)
                {
                    mecanim::human::HumanPoseCopy(*nodeStateOutput.m_HumanPoseBase, *nodeStateOutput.m_HumanPose);
                }
            }
            else if (avatarConstant.m_RootMotionBoneIndex != -1)
            {
                if (additive)
                {
                    MotionOutputClear(motionOutput);
                }
                else
                {
                    mecanim::skeleton::SkeletonPose *rootMotionSkeletonPoseWsA = mecanim::skeleton::CreateSkeletonPose<math::trsX>(constant->avatarConstant->m_RootMotionSkeleton.Get(), tempAllocator);
                    mecanim::skeleton::SkeletonPose *rootMotionSkeletonPoseWsB = mecanim::skeleton::CreateSkeletonPose<math::trsX>(constant->avatarConstant->m_RootMotionSkeleton.Get(), tempAllocator);

                    mecanim::animation::ComputeRootMotion(avatarConstant, tqsMap, *motionOutput, *valuesOutput, *valuesStartWs, *valuesStopWs, *rootMotionSkeletonPoseWsA, *rootMotionSkeletonPoseWsB, loop);

                    mecanim::skeleton::DestroySkeletonPose(rootMotionSkeletonPoseWsA, tempAllocator);
                    mecanim::skeleton::DestroySkeletonPose(rootMotionSkeletonPoseWsB, tempAllocator);
                }
            }

            if (gravityWeightIndex != -1 && nodeStateOutput.m_DynamicValuesMask->m_FloatValues[gravityWeightIndex])
            {
                valuesOutput->ReadData(motionOutput->m_GravityWeight, gravityWeightIndex);
            }
            else if (isHuman || constant->avatarConstant->m_RootMotionBoneIndex != -1)
            {
                motionOutput->m_GravityWeight =  muscleConstant.m_LoopBlendPositionY ? 1 : 0;
            }
            else
            {
                motionOutput->m_GravityWeight =  1.0f;
            }

            if (!avatarInput.m_LinearVelocityBlending)
            {
                motionOutput->m_Velocity *= motionOutput->m_DeltaTime;
                motionOutput->m_AngularVelocity *= motionOutput->m_DeltaTime;
            }

            if (input->avatarInput->m_TargetIndex != -1)
            {
                mecanim::animation::ClipInput targetIn;
                float timeIntTarget;
                float normalizedTimetarget = 0;

                targetIn.m_Time = mecanim::animation::ComputeClipTime(input->avatarInput->m_TargetTime,
                        muscleConstant.m_StartTime, muscleConstant.m_StopTime,
                        muscleConstant.m_CycleOffset + muscleInput.m_CycleOffset,
                        muscleConstant.m_LoopTime,
                        muscleInput.m_Speed,
                        normalizedTimetarget,
                        timeIntTarget,
                        muscleInput.m_Time < 0);

                // this breaks the cache when evaluating target... probably ok compare to allocate an additional cache for target
                EvaluateClip(muscleConstant.m_Clip.Get(), &targetIn, &clipMemory, clipOutput);

                muscleInput.m_ComputeCycleX = true;
                muscleInput.m_PreviousTime = input->avatarInput->m_TargetTime;
                muscleInput.m_Time = input->avatarInput->m_TargetTime;

                mecanim::animation::MotionOutput motionOutputTarget;
                mecanim::human::HumanPose humanPoseTarget;

                EvaluateRootMotion(muscleConstant, muscleInput, clipOutput->m_Values, clipOutput->m_Values, motionOutputTarget, isHuman);

                motionOutput->m_TargetX = motionOutputTarget.m_MotionX;

                if (isHuman && input->avatarInput->m_TargetIndex > mecanim::animation::kTargetReference && input->avatarInput->m_TargetIndex <= mecanim::animation::kTargetRightHand)
                {
                    EvaluateHumanPose(muscleConstant, muscleInput, clipOutput->m_Values, motionOutputTarget, humanPoseTarget);

                    if (input->avatarInput->m_TargetIndex > mecanim::animation::kTargetRoot)
                    {
                        int32_t targetGoalIndex = input->avatarInput->m_TargetIndex - mecanim::animation::kTargetLeftFoot;

                        motionOutput->m_TargetX = math::mul(motionOutput->m_TargetX, humanPoseTarget.m_GoalArray[targetGoalIndex].m_X);
                    }
                    else
                    {
                        motionOutput->m_TargetX = math::mul(motionOutput->m_TargetX, humanPoseTarget.m_RootX);
                    }
                }

                motionOutput->m_TargetX = math::invMul(motionOutput->m_MotionX, motionOutput->m_TargetX);
            }
        }

        if (additive)
            ValueArraySub(*valuesAdditiveReferencePose, *valuesOutput, nodeStateOutput.m_DynamicValuesMask);

        if (loop)
            ValueArrayLoop(*valuesStartWs, *valuesStopWs, *valuesOutput, normalizedTime, *nodeStateOutput.m_DynamicValuesMask);

        if (valuesStartWs != 0)
            DestroyValueArray(valuesStartWs, tempAllocator);
        if (valuesStopWs != 0)
            DestroyValueArray(valuesStopWs, tempAllocator);
        if (valuesAdditiveReferencePose != 0)
            DestroyValueArray(valuesAdditiveReferencePose, tempAllocator);

        mecanim::animation::DestroyClipOutput(clipOutputPrev, tempAllocator);
        mecanim::animation::DestroyClipOutput(clipOutput, tempAllocator);
    }
}

void AnimationClipPlayable::PrepareAnimationEvents(float weight, AnimationClipEventInfos& eventInfos)
{
    if (m_AnimationClip == NULL || m_AnimationClipMemory.muscleConstant == NULL || !m_AnimationClip->HasAnimationEvents())
        return;

    bool isExitingState = FilteredMessageId(m_AnimationClipMemory.m_MessageID, mecanim::statemachine::kOnStateExit) == mecanim::statemachine::kOnStateExit;
    bool isEnteringState = FilteredMessageId(m_AnimationClipMemory.m_MessageID, mecanim::statemachine::kOnStateEnter) == mecanim::statemachine::kOnStateEnter;

    // nothing can be fired until we get a first eval with a delta time != 0
    if (m_AnimationClipMemory.m_FirstEval != mecanim::statemachine::kWaitForTick && (weight > 0  || isExitingState || isEnteringState))
    {
        ANIMATOR_PROFILER_AUTO_DETAIL(gAnimationClipPlayablePrepareAnimationEvents, NULL);

        AnimationClipEventInfo& eventInfo = eventInfos.push_back();
        eventInfo.m_AnimationClip = m_AnimationClip;
        eventInfo.m_StateInfo = m_AnimationClipMemory.m_StateInfo;

        float speedMultiplier = m_AnimationClipMemory.m_StateMachineMemory == NULL ? 1.0f : eventInfo.m_StateInfo.speedMultiplier;
        const float duration = m_AnimationClip->GetAverageDuration();

        eventInfo.m_ClipInfo.clip = m_AnimationClip;
        eventInfo.m_ClipInfo.weight = weight;

        float dummy;
        eventInfo.m_LastTime    = m_AnimationClipMemory.m_LastTime;
        eventInfo.m_CurrenTime  = m_LocalTime;
        eventInfo.m_LastTime    /= duration != 0 ? duration : 1.0f;
        eventInfo.m_CurrenTime  /= duration != 0 ? duration : 1.0f;
        eventInfo.m_PlaybackSpeed = m_AnimationClipMemory.m_Speed * speedMultiplier;
        eventInfo.m_LoopLastTime = true;


        const float cycleOffset = m_AnimationClipMemory.muscleConstant->m_CycleOffset + m_AnimationClipMemory.m_CycleOffset;

        float lastTimeLoop = 0;
        float currentTimeLoop = 0;

        eventInfo.m_LastTime = mecanim::animation::ComputeClipTime(eventInfo.m_LastTime, m_AnimationClipMemory.muscleConstant->m_StartTime, m_AnimationClipMemory.muscleConstant->m_StopTime,
                cycleOffset,
                m_AnimationClipMemory.muscleConstant->m_LoopTime, m_AnimationClipMemory.m_Speed,
                dummy, lastTimeLoop, m_LocalTime < 0);

        eventInfo.m_CurrenTime = mecanim::animation::ComputeClipTime(eventInfo.m_CurrenTime, m_AnimationClipMemory.muscleConstant->m_StartTime, m_AnimationClipMemory.muscleConstant->m_StopTime,
                cycleOffset,
                m_AnimationClipMemory.muscleConstant->m_LoopTime, m_AnimationClipMemory.m_Speed,
                dummy, currentTimeLoop, m_LocalTime < 0);

        // m_LastTime is always is clip range, m_CurrentTime is rebased on it
        if (currentTimeLoop > lastTimeLoop && eventInfo.m_PlaybackSpeed > 0)
        {
            eventInfo.m_CurrenTime += (currentTimeLoop - lastTimeLoop) * duration;
        }
        else if (currentTimeLoop < lastTimeLoop && eventInfo.m_PlaybackSpeed < 0)
        {
            eventInfo.m_CurrenTime -= (lastTimeLoop - currentTimeLoop) * duration;
        }

        // Handle special cases.
        // Clip range is [0, 0] or [1, 1] when we start to play a new state, this is not handled correctly by animation clip FireEvent function.
        // We have to cheat the clip range
        // case 676489
        bool playingForward = math::chgsign(1.0f, eventInfo.m_PlaybackSpeed) > 0.0f;
        if (isEnteringState && playingForward)
        {
            eventInfo.m_LastTime -= math::epsilon_second();
        }
        else if (isEnteringState && !playingForward)
        {
            eventInfo.m_LastTime += math::epsilon_second();
        }
        else if (isExitingState && m_AnimationClipMemory.muscleConstant->m_LoopTime)
        {
            mecanim::statemachine::StateMachineMemory const * stateMachineMemory = m_AnimationClipMemory.m_StateMachineMemory;

            float timeInt = 0.f;
            float denormalizeStartTime = mecanim::animation::ComputeClipTime(stateMachineMemory->m_TransitionStartTime, m_AnimationClipMemory.muscleConstant->m_StartTime, m_AnimationClipMemory.muscleConstant->m_StopTime, cycleOffset, m_AnimationClipMemory.muscleConstant->m_LoopTime, m_AnimationClipMemory.m_Speed, dummy, timeInt, stateMachineMemory->m_TransitionStartTime < 0);

            // case 745781: transitions have exit time of 1 and transitions duration is 0
            timeInt = timeInt != 0.f && denormalizeStartTime == 0.f ? 1.0f : 0.0f;

            float denormalizeTransitionDuration = stateMachineMemory->m_FixedTransition ? stateMachineMemory->m_TransitionDuration : stateMachineMemory->m_TransitionDuration * duration;
            float denormalizeStopTime = (timeInt * duration) + denormalizeStartTime + denormalizeTransitionDuration;


            // Find Transition stop time, do not send event after this time since clip weight should be 0
            if (eventInfo.m_CurrenTime >= denormalizeStopTime)
            {
                eventInfo.m_CurrenTime = denormalizeStopTime;

                // Don't loop when we are exiting and on the end of the clip.
                if (math::modf(eventInfo.m_CurrenTime / duration, dummy) == 0.0f)
                    eventInfo.m_LoopLastTime = false;

                if (eventInfo.m_LastTime > eventInfo.m_CurrenTime)
                {
                    eventInfo.m_LastTime = eventInfo.m_CurrenTime;
                }
            }
        }
    }

    AnimationPlayable::PrepareAnimationEvents(weight, eventInfos);
}

void AnimationClipPlayable::AllocateBindings(AnimationPlayableEvaluationConstant const *constant)
{
    if (!m_BindingsAllocated && m_AnimationClip != NULL)
    {
        for (int i = 0; i < constant->clipCount; ++i)
        {
            mecanim::animation::AnimationSet::Clip const& setClip = constant->clipArray[i];
            if (setClip.m_AnimationClip == m_AnimationClip && m_AnimationClip != 0 && m_AnimationClip->IsMecanimDataValid())
            {
                m_AnimationClipMemory.muscleConstant =  m_AnimationClip->GetRuntimeAsset();

                m_MotionReadMask |= mecanim::animation::HasMotionCurves(*m_AnimationClipMemory.muscleConstant) ||  mecanim::animation::HasRootCurves(*m_AnimationClipMemory.muscleConstant);
                m_HumanReadMask |= m_AnimationClip->IsHumanMotion();

                m_AnimationClipMemory.clipBindings = &setClip.m_Bindings;
                mecanim::uint32_t usedCurves = constant->allowConstantCurveOptimization ? setClip.m_TotalUsedOptimizedCurveCount : mecanim::animation::GetClipCurveCount(*m_AnimationClipMemory.muscleConstant);
                m_AnimationClipMemory.clipMemory = m_AnimationClipMemory.muscleConstant != 0 ? mecanim::animation::CreateClipMemory(m_AnimationClipMemory.muscleConstant->m_Clip.Get(), usedCurves, m_Allocator) : 0;
                break;
            }
        }

        AnimationPlayable::AllocateBindings(constant);
    }
}

void AnimationClipPlayable::DeallocateBindings()
{
    if (m_BindingsAllocated)
    {
        mecanim::animation::DestroyClipMemory(m_AnimationClipMemory.clipMemory, m_Allocator);
        m_AnimationClipMemory.clipMemory        = 0;
        m_AnimationClipMemory.muscleConstant    = 0;
        m_AnimationClipMemory.clipBindings      = 0;
    }
    AnimationPlayable::DeallocateBindings();
}

void AnimationClipPlayable::SetTime(double time)
{
    m_AnimationClipMemory.m_LastTime    = m_LocalTime;
    Playable::SetTime(time);
}

void AnimationClipPlayable::GetAnimationClips(AnimationClips& clips)
{
    if (m_AnimationClip != NULL)
    {
        clips.push_back(m_AnimationClip);
    }
    AnimationPlayable::GetAnimationClips(clips);
}

void AnimationClipPlayable::CollectAnimationClipPlayables(AnimationClipPlayables& clips)
{
    clips.push_back(this);
    AnimationPlayable::CollectAnimationClipPlayables(clips);
}
