#pragma once
#include "Runtime/Animation/Director/AnimationPlayable.h"


class AnimationLayerMixerPlayable : public AnimationPlayable
{
public:

    DEFINE_PLAYABLE(AnimationLayerMixerPlayable, GetAnimationScriptingClasses().animationLayerMixerPlayable, AnimationPlayable);

    struct LayerParameters
    {
        mecanim::human::HumanPoseMask const *m_HumanPoseMask;
        float m_LayerWeight;        // As set by the user, this weight doesn't include the layer autoweight
        bool  m_RootMask;
        bool  m_Additive;
    };

    struct Memory
    {
        dynamic_array<mecanim::animation::AnimationNodeState *> nodeStateArray;
        mecanim::ValueArrayMask**   m_DynamicValuesMaskArray;
        bool*                       m_RootMotionLayerMask;

        void CreateNodeStateArray(int nodeCount, mecanim::ValueArrayConstant const &values, bool hasRootMotion, bool isHuman, bool affectMassCenter, mecanim::memory::Allocator& alloc);
        void DestroyNodeStateArray(mecanim::memory::Allocator& alloc);
    };

    virtual void ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output);

    virtual void PrepareAnimationEvents(float weight, AnimationClipEventInfos& eventInfos);

    virtual void ClearBindings();
    virtual void AllocateBindings(AnimationPlayableEvaluationConstant const *constant);
    virtual void DeallocateBindings();

    static void MixOutputs(AnimationPlayableEvaluationConstant *constant, AnimationPlayableEvaluationInput *input, AnimationPlayableEvaluationOutput* output,  AnimationPlayableEvaluationOutput* layer, float weight, bool additive, bool layerRootMotionMask = true, mecanim::human::HumanPoseMask const * userDefinedHumanPoseMask = 0);


    virtual LayerParameters& GetParameters(unsigned int index) {return m_LayerParameters[index]; }
    virtual const LayerParameters& GetParameters(unsigned int index) const {return m_LayerParameters[index]; }

    void SetControllerConstant(mecanim::animation::ControllerConstant const* controllerConstant) { m_ControllerConstant = controllerConstant; }

    virtual void SetInputWeight(int inputIndex, float weight);
    float GetLayerWeight(unsigned int layerIndex) const;

protected:
    virtual bool SetInputConnection(Playable* input, int inputPort);

public:  // make private

    friend class PlayableGraph;

    Memory                                  m_LayerMixerMemory;
    dynamic_array<LayerParameters>          m_LayerParameters;

    mecanim::animation::ControllerConstant const* m_ControllerConstant;
};
