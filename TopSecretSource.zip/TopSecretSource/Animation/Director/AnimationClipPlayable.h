#pragma once

#include "Runtime/Animation/Director/AnimationPlayable.h"
#include "Runtime/mecanim/statemachine/statemachineenums.h" // StateMachineEvaluation


namespace mecanim
{ namespace statemachine
{ struct StateMachineMemory; } }

class AnimationClip;

class AnimationClipPlayable : public AnimationPlayable
{
public:

    DEFINE_PLAYABLE(AnimationClipPlayable, GetAnimationScriptingClasses().animationClipPlayable, AnimationPlayable);

    class Memory
    {
    public:

        mecanim::animation::ClipMuscleConstant const *muscleConstant;
        mecanim::animation::ClipBindings const *clipBindings;
        mecanim::animation::ClipMemory* clipMemory;

        float   m_LastTime;
        float   m_Speed;
        bool    m_Mirror;
        float   m_CycleOffset;
        bool    m_WriteDefaultValues;

        mecanim::statemachine::StateMachineEvaluation   m_FirstEval;
        mecanim::statemachine::StateMachineMessage      m_MessageID;
        mecanim::statemachine::StateMachineMemory*      m_StateMachineMemory;

        AnimatorStateInfo m_StateInfo;

        Memory() : muscleConstant(0), clipBindings(0), clipMemory(0), m_LastTime(0), m_Speed(1), m_CycleOffset(0), m_Mirror(false), m_WriteDefaultValues(true), m_FirstEval(mecanim::statemachine::kWaitForTick), m_MessageID(mecanim::statemachine::kInvalid), m_StateMachineMemory(0)
        {}
        virtual ~Memory() {}
    };


    virtual void OnAdvanceTime(double delta);

    virtual void ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output);

    virtual void SetStateMachineMessage(mecanim::statemachine::StateMachineMessage message);

    virtual void PrepareAnimationEvents(float weight, AnimationClipEventInfos& eventInfos);

    virtual void AllocateBindings(AnimationPlayableEvaluationConstant const *constant);
    virtual void DeallocateBindings();

    virtual void GetAnimationClips(AnimationClips& clips);
    virtual void CollectAnimationClipPlayables(AnimationClipPlayables& clips);

    virtual void SetTime(double time);

    void SetClip(AnimationClip* clip);
    AnimationClip* GetClip() const { return m_AnimationClip; }

    virtual NamedObject* GetAsset() const;


    bool        GetApplyFootIK() const              { return m_ApplyFootIK; }
    void        SetApplyFootIK(bool value)          { m_ApplyFootIK = value; }

    bool        GetRemoveStartOffset() const        { return m_RemoveStartOffset; }
    void        SetRemoveStartOffset(bool value)    { m_RemoveStartOffset = value; }

    Memory&     GetMemory() { return m_AnimationClipMemory; }

private:

    friend class PlayableGraph;

    Memory                  m_AnimationClipMemory;

    AnimationClip*          m_AnimationClip;

    bool                    m_ApplyFootIK;
    bool                    m_RemoveStartOffset;
    bool                    m_HumanReadMask;
    bool                    m_MotionReadMask;
};
