#pragma once
#include "Runtime/Animation/Director/AnimationMixerPlayable.h"
#include "Runtime/Animation/Director/AnimationPosePlayable.h"
#include "Runtime/Animation/Director/AnimationClipPlayable.h"

class AnimationStateMachineMixerPlayable : public AnimationMixerPlayable
{
public:
    DEFINE_PLAYABLE(AnimationStateMachineMixerPlayable, GetAnimationScriptingClasses().animationMixerPlayable, AnimationMixerPlayable);

    AnimationMixerPlayable* GetStateMixerPlayable(bool currentState) const;
    AnimationPosePlayable* GetInterruptedPosePlayable() const;

    bool IsInInterruptedTransition() const { return m_InterruptedPoseIndex == 0; }

    void SetInterruptedPoseIndex(int index);

    void StartInterruptedTransition(bool applyFootIK);
    void EndTransition();

    void ArrangePlayables(bool isInInterruptedTransition, bool applyFootIK);

private:
    friend class PlayableGraph;
    int m_InterruptedPoseIndex;
};
