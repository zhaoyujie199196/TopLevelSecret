#include "UnityPrefix.h"
#include "Runtime/Animation/Director/AnimationPlayable.h"
#include "Runtime/mecanim/generic/valuearray.h"
#include "Runtime/mecanim/animation/clipmuscle.h"
#include "Runtime/mecanim/animation/avatar.h"
#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/Scripting/ScriptingExportUtility.h"
#include "Runtime/Director/Core/Traversers.h"
#include "Runtime/BaseClasses/NamedObject.h"

void AnimationPlayableEvaluateBegin(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    SetValueMask(output->nodeStateOutput->m_DynamicValuesMask, false);

    bool hasRootMotion = constant->hasRootMotion;
    bool isHuman = constant->isHuman;

    if (hasRootMotion || isHuman)
    {
        ClearAnimationNodeState(output->nodeStateOutput, isHuman);
    }
}

void AnimationPlayableEvaluateEnd(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    bool hasRootMotion = constant->hasRootMotion;
    bool isHuman = constant->isHuman;

    mecanim::InvertValueMask(output->nodeStateOutput->m_DynamicValuesMask);
    ValueArrayCopy(constant->defaultValues, output->nodeStateOutput->m_DynamicValues, output->nodeStateOutput->m_DynamicValuesMask);

    if (hasRootMotion || isHuman)
    {
        output->nodeStateOutput->m_MotionOutput->m_DeltaTime = input->avatarInput->m_DeltaTime;

        if (!input->avatarInput->m_LinearVelocityBlending)
        {
            if (output->nodeStateOutput->m_MotionOutput->m_DeltaTime != 0)
            {
                output->nodeStateOutput->m_MotionOutput->m_Velocity /= output->nodeStateOutput->m_MotionOutput->m_DeltaTime;
                output->nodeStateOutput->m_MotionOutput->m_AngularVelocity /= output->nodeStateOutput->m_MotionOutput->m_DeltaTime;
            }
            else
            {
                output->nodeStateOutput->m_MotionOutput->m_Velocity = math::float3(math::ZERO);
                output->nodeStateOutput->m_MotionOutput->m_AngularVelocity = math::float3(math::ZERO);
            }
        }
    }
}

AnimationPlayable::AnimationPlayable(DirectorPlayerType playerType)
    : Playable((ScriptingClassPtr)SCRIPTING_NULL, playerType)
    , m_Allocator(kMemAnimation)
    , m_NeedsPreProcess(false)
    , m_NeedsAllocateBindings(false)
    , m_ChildsNeedsAllocateBindings(false)
    , m_BindingsAllocated(false)
#if ANIMATION_PLAYABLE_SANITY_CHECK
    , m_Type(eAnimationPlayableInvalid)
#endif
{}


void  AnimationPlayable::AnimationPlayableAllocate(AnimationPlayableEvaluationConstant *constant)
{
    AllocateBindings(constant);
}

void AnimationPlayable::DeallocateResources()
{
    DeallocateBindings();
    Playable::DeallocateResources();
}

void AnimationPlayable::GetAnimationClips(AnimationClips& animationClips)
{
    for (int i = 0; i < m_Connections->m_Inputs.size(); ++i)
    {
        AnimationPlayable* child = GetNextCompatibleDescendant(i);
        if (child != NULL)
        {
            child->GetAnimationClips(animationClips);
        }
    }
}

bool AnimationPlayable::ConnectNoTopologyChange(AnimationPlayable* left, AnimationPlayable* right, int leftOutputPort, int rightInputPort)
{
    bool ret = Playable::Connect(left, right, leftOutputPort, rightInputPort);
    right->SetNeedsBindingRebuilded(false);
    left->SetNeedsBindingRebuilded(false);
    return ret;
}

void AnimationPlayable::DisconnectNoTopologyChange(AnimationPlayable* right, int inputPort)
{
    Playable::Disconnect(right, inputPort);
    right->SetNeedsBindingRebuilded(false);
}

bool AnimationPlayable::SetInputConnection(Playable* input, int inputPort)
{
    bool ret = Playable::SetInputConnection(input, inputPort);
    SetNeedsBindingRebuilded(true);
    return ret;
}

AnimationPlayable* AnimationPlayable::GetNextCompatibleDescendant(int port) const
{
    return static_cast<AnimationPlayable*>(PlayableTraverser::NextByType(this, port, kAnimation));
}

void AnimationPlayable::OwnAsset(NamedObject* asset)
{
    if (asset == NULL)
        m_AssetReference = AssetReference();
    else
        m_AssetReference = AssetReference(asset);
}
