#include "UnityPrefix.h"

#include "Runtime/Animation/AnimatorConfigure.h"
#include "Runtime/Animation/Director/AnimationMixerPlayable.h"
#include "Runtime/mecanim/animation/avatar.h"

#include "Runtime/Scripting/ScriptingManager.h"

ANIMATOR_PROFILER_INFORMATION_DETAIL(gAnimationMixerPlayableProcessAnimation, "AnimationMixerPlayable.ProcessAnimation",   kProfilerAnimation);

AnimationMixerPlayable::AnimationMixerPlayable(DirectorPlayerType playerType)
    : AnimationPlayable(playerType)
    , m_AutoNormalize(false)
{
#if ANIMATION_PLAYABLE_SANITY_CHECK
    m_Type = eAnimationMixerPlayable;
#endif
}

bool AnimationMixerPlayable::SetInputConnection(Playable* input, int inputPort)
{
    bool success = AnimationPlayable::SetInputConnection(input, inputPort);
    if (!success)
        return false;

    return true;
}

void AnimationMixerPlayable::ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    ANIMATOR_PROFILER_AUTO_DETAIL(gAnimationMixerPlayableProcessAnimation, NULL);

    static const float EPS = 0.00000001f;
    const int childCount = m_Connections->m_Inputs.size();

    float* weights;
    ALLOC_TEMP(weights, childCount);

    Playable** playables;
    ALLOC_TEMP(playables, childCount);

    int activeChildCount = 0;
    float sumWeights = 0;
    for (int i = 0; i < childCount; ++i)
    {
        if (m_Connections->m_Inputs[i].playable != NULL && m_Connections->m_Inputs[i].weight > 0)
        {
            playables[activeChildCount] = GetNextCompatibleDescendant(i);
            weights[activeChildCount] = m_Connections->m_Inputs[i].weight;
            activeChildCount++;
            sumWeights += m_Connections->m_Inputs[i].weight;
        }
    }

    if (m_AutoNormalize)
    {
        if (fabsf(sumWeights) < EPS)
        {
            sumWeights = EPS;
        }

        for (int i = 0; i < activeChildCount; i++)
        {
            weights[i] /= sumWeights;
        }
    }

    bool hasRootMotion = constant->hasRootMotion;
    bool isHuman = constant->isHuman;
    bool affectMassCenter = constant->affectMassCenter;

    if (activeChildCount == 0)
    {
        mecanim::SetValueMask(output->nodeStateOutput->m_DynamicValuesMask, false);

        if (hasRootMotion || isHuman)
        {
            ClearAnimationNodeState(output->nodeStateOutput, isHuman);
        }
    }
    else if (activeChildCount == 1 && weights[0] == 1.0f)
    {
        AnimationPlayable* animationPlayable = static_cast<AnimationPlayable*>(playables[0]);
        if (animationPlayable != NULL)
            animationPlayable->ProcessAnimation(constant, input, output);
    }
    else
    {
        mecanim::memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);

        float weightSum = 0;

        ValueArrayBlendBegin(*output->nodeStateOutput->m_DynamicValuesMask);

        if (hasRootMotion || isHuman)
        {
            mecanim::animation::MotionOutputBlendBegin(output->nodeStateOutput->m_MotionOutput, hasRootMotion, isHuman);

            if (isHuman)
            {
                mecanim::human::HumanPoseBlendBegin(*output->nodeStateOutput->m_HumanPose);

                if (output->nodeStateOutput->m_HumanPoseBase != 0)
                {
                    mecanim::human::HumanPoseBlendBegin(*output->nodeStateOutput->m_HumanPoseBase);
                }
            }
        }

        mecanim::ValueArrayWeight *valueArrayWeight = mecanim::CreateValueArrayWeight(constant->values, tempAllocator);
        mecanim::animation::AnimationNodeState *nodeState = mecanim::animation::CreateAnimationNodeState(*constant->values, hasRootMotion, isHuman, affectMassCenter, tempAllocator);

        for (int childIndex = 0; childIndex < activeChildCount; childIndex++)
        {
            const float weight = weights[childIndex];
            AnimationPlayable* animationPlayable = static_cast<AnimationPlayable*>(playables[childIndex]);
            if (animationPlayable == NULL)
                continue;

            weightSum += weight;

            AnimationPlayableEvaluationOutput childOutput;
            childOutput.nodeStateOutput = nodeState;

            animationPlayable->ProcessAnimation(constant, input, &childOutput);
            output->m_IKOnFeet |= childOutput.m_IKOnFeet;

            ValueArrayBlendNode(*output->nodeStateOutput->m_DynamicValues,
                *valueArrayWeight,
                *output->nodeStateOutput->m_DynamicValuesMask,
                *childOutput.nodeStateOutput->m_DynamicValues,
                *childOutput.nodeStateOutput->m_DynamicValuesMask,
                weight);

            if (hasRootMotion || isHuman)
            {
                mecanim::animation::MotionOutputBlendNode(output->nodeStateOutput->m_MotionOutput,
                    childOutput.nodeStateOutput->m_MotionOutput,
                    weight,
                    hasRootMotion,
                    isHuman,
                    *input->humanPoseMask);

                if (isHuman) // always blend even if humandReadMask is false, because of QNaN used in rootX + goals.
                {
                    mecanim::human::HumanPoseBlendNode(*output->nodeStateOutput->m_HumanPose, childOutput.nodeStateOutput->m_HumanPose, weight);

                    if (output->nodeStateOutput->m_HumanPoseBase != 0)
                    {
                        mecanim::human::HumanPoseBlendNode(*output->nodeStateOutput->m_HumanPoseBase, childOutput.nodeStateOutput->m_HumanPoseBase, weight);
                    }
                }
            }

            output->nodeStateOutput->m_MotionReadMask   |= childOutput.nodeStateOutput->m_MotionReadMask;
            output->nodeStateOutput->m_HumanReadMask    |= childOutput.nodeStateOutput->m_HumanReadMask;
        }

        mecanim::ValueArray const *defaultValues = input->defaultValuesOverride != NULL ?  input->defaultValuesOverride : constant->defaultValues;
        ValueArrayBlendEnd(*output->nodeStateOutput->m_DynamicValues,
            *output->nodeStateOutput->m_DynamicValuesMask,
            *valueArrayWeight,
            !input->additive ? defaultValues : NULL);


        if (hasRootMotion || isHuman)
        {
            mecanim::animation::MotionOutputBlendEnd(output->nodeStateOutput->m_MotionOutput, hasRootMotion, isHuman, *input->humanPoseMask, weightSum);

            if (isHuman)
            {
                mecanim::human::HumanPoseBlendEnd(*output->nodeStateOutput->m_HumanPose, weightSum);

                if (output->nodeStateOutput->m_HumanPoseBase != 0)
                {
                    mecanim::human::HumanPoseBlendEnd(*output->nodeStateOutput->m_HumanPoseBase, weightSum);
                }
            }
        }

        mecanim::DestroyValueArrayWeight(valueArrayWeight, tempAllocator);
        mecanim::animation::DestroyAnimationNodeState(nodeState, tempAllocator);
    }
}
