#pragma once

#include "Runtime/Director/Core/Playable.h"
#include "Runtime/mecanim/animation/animationset.h"
#include "Runtime/Animation/AnimatorInfo.h"
#include "Runtime/Animation/AnimatorDefines.h"
#include "Runtime/mecanim/statemachine/statemachinemessage.h"
#include "Runtime/Misc/UserList.h"
#include "Runtime/Scripting/ScriptingExportUtility.h"
#include "Runtime/Misc/AssetReference.h"

typedef dynamic_array<AnimationClip*> AnimationClips;


class AnimationClipPlayable;
class AnimatorControllerPlayable;

namespace mecanim
{
    struct ValueArrayConstant;
    struct ValueArray;
    struct ValueArrayMask;
    struct ValueArrayWeight;

namespace animation
{
    struct AvatarConstant;
    struct AvatarInput;
    struct SkeletonTQSMap;
    struct ClipMuscleInput;
    struct ClipOutput;
    struct AnimationNodeState;
    struct ControllerBindingConstant;
}

namespace skeleton
{
    template<typename transformType> struct SkeletonPoseT;
    typedef SkeletonPoseT<math::trsX> SkeletonPose;
}
}

namespace UnityEngine
{
namespace Animation
{
    struct AnimatorGenericBindingConstant;
    struct GenericBinding;
}
}

struct AnimationPlayableEvaluationConstant
{
    const mecanim::ValueArrayConstant *values;
    const mecanim::ValueArray *defaultValues;
    const mecanim::animation::ControllerBindingConstant *controllerBindingConstant;
    const mecanim::animation::AvatarConstant *avatarConstant;
    size_t genericBindingsSize;
    const UnityEngine::Animation::GenericBinding *genericBindings;
    const mecanim::animation::SkeletonTQSMap *tqsMap;
    const mecanim::animation::AnimationSet::Clip *clipArray;
    mecanim::uint32_t clipCount;
    mecanim::int32_t gravityWeightIndex;
    mecanim::int32_t integerRemapStride;
    bool allowConstantCurveOptimization;
    bool hasRootMotion;
    bool isHuman;
    bool affectMassCenter;
    bool applyMotionX;
    Object* player;

    AnimationPlayableEvaluationConstant()
    {
        Clear();
    }

    void Clear()
    {
        values = 0;
        defaultValues = 0;
        avatarConstant = 0;
        tqsMap = 0;
        clipArray = 0;
        clipCount = 0;
        controllerBindingConstant = 0;
        applyMotionX = false;
        genericBindingsSize = 0;
        genericBindings = 0;
        player = 0;
    }
};

struct AnimationPlayableEvaluationInput
{
    AnimationPlayableEvaluationInput() : avatarInput(0), additive(false), humanPoseMask(0), defaultValuesOverride(0), lastEvaluationValues(0), applyMotionX(false)
    {}

    mecanim::animation::AvatarInput *avatarInput;
    bool additive;
    bool applyMotionX;
    mecanim::human::HumanPoseMask const *humanPoseMask;

    const mecanim::ValueArray *defaultValuesOverride;
    mecanim::ValueArray *lastEvaluationValues;
};

struct AnimationPlayableEvaluationOutput
{
    AnimationPlayableEvaluationOutput() : nodeStateOutput(0),  m_IKOnFeet(false) {}
    mecanim::animation::AnimationNodeState *nodeStateOutput;
    bool m_IKOnFeet;
};

struct AnimationClipEventInfo
{
    AnimationClip*      m_AnimationClip;
    float               m_CurrenTime;
    float               m_LastTime;
    AnimatorStateInfo   m_StateInfo;
    AnimatorClipInfo    m_ClipInfo;
    float               m_PlaybackSpeed;
    bool                m_LoopLastTime;
};

class NamedObject;

typedef dynamic_array<AnimationClipEventInfo> AnimationClipEventInfos;
typedef dynamic_array<AnimatorControllerPlayable*> AnimatorControllerPlayables;
typedef dynamic_array<AnimationClipPlayable*> AnimationClipPlayables;

void AnimationPlayableEvaluateBegin(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output);

void AnimationPlayableEvaluateEnd(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output);

//Set to 1 to enable additional type info and type checking on connections
#define ANIMATION_PLAYABLE_SANITY_CHECK 0
#if ANIMATION_PLAYABLE_SANITY_CHECK
enum AnimationPlayableTypes
{
    eAnimationPlayableInvalid,
    eAnimationClipPlayable,
    eAnimationMixerPlayable,
    eAnimationStateMachineMixerPlayable,
    eAnimationLayerMixerPlayable,
    eAnimationPosePlayable
};
#endif

class AnimationPlayable : public Playable
{
public:

    DEFINE_PLAYABLE(AnimationPlayable, GetAnimationScriptingClasses().animationPlayable, Playable);


    virtual void AnimationPlayableAllocate(AnimationPlayableEvaluationConstant *constant);
    virtual void DeallocateResources();


#define TRAVERSE(FUNC, ...) \
    {\
        int inputSize = m_Connections->m_Inputs.size();\
        for(int i = 0 ; i < inputSize; ++i)\
        {\
            AnimationPlayable* childAnimationPlayable = GetNextCompatibleDescendant(i);\
            if (childAnimationPlayable != NULL)\
                childAnimationPlayable->FUNC(__VA_ARGS__);\
        }\
    }\

#define TRAVERSE_OR_RESULT(FUNC, RESULT, ...) \
    {\
        int inputSize = m_Connections->m_Inputs.size();\
        for(int i = 0 ; i < inputSize; ++i)\
        {\
            AnimationPlayable* childAnimationPlayable = GetNextCompatibleDescendant(i);\
            if (childAnimationPlayable != NULL)\
                RESULT |= childAnimationPlayable->FUNC(__VA_ARGS__);\
        }\
    }\

    virtual void ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output)
    {
        TRAVERSE(ProcessAnimation, constant, input, output);
    }

    virtual void GetAnimationClips(AnimationClips& clips);

    virtual void PreProcessAnimation(AnimationPlayableEvaluationConstant const *constant, mecanim::animation::AnimationNodeState const* state)
    {
        m_NeedsBindingRebuilded = false;
        TRAVERSE(PreProcessAnimation, constant, state);
    }

    virtual void PrepareAnimationEvents(float weight, AnimationClipEventInfos& eventInfos)              TRAVERSE(PrepareAnimationEvents, weight * m_Connections->m_Inputs[i].weight, eventInfos)
    virtual void CollectAnimatorControllerPlayables(AnimatorControllerPlayables& controllerPlayable)    TRAVERSE(CollectAnimatorControllerPlayables, controllerPlayable);
    virtual void CollectAnimationClipPlayables(AnimationClipPlayables& clips)   TRAVERSE(CollectAnimationClipPlayables, clips);

    virtual void AddObjectUser(UserList& user)                                                          TRAVERSE(AddObjectUser, user)

    enum UpdateMode
    {
        kDeallocateBindings = 1 << 0,
        kAllocateBindings = 1 << 1,
        kReallocateBindings = kDeallocateBindings | kAllocateBindings,
    };

private:
    template<int UPDATEMODE> UNITY_FORCEINLINE void UpdateInternalState(AnimationPlayableEvaluationConstant const *constant);
public:
    template<int UPDATEMODE, bool ONLYNEEDSALLOCATE> UNITY_FORCEINLINE void UpdateInternalState(AnimationPlayableEvaluationConstant const *constant)
    {
        Assert(!(NeedsAllocateBindings() && m_BindingsAllocated && (UPDATEMODE & kDeallocateBindings) == 0 && (UPDATEMODE & kAllocateBindings) == kAllocateBindings));

        // In some case we only want to allocate if it needed like when a State start to play
        if (ONLYNEEDSALLOCATE && NeedsAllocateBindings() || !ONLYNEEDSALLOCATE)
        {
            UpdateInternalState<(UPDATEMODE & kDeallocateBindings)>(constant);
            UpdateInternalState<(UPDATEMODE & kAllocateBindings)>(constant);
        }
    }

    template<int UPDATEMODE, bool ONLYNEEDSALLOCATE> void UpdateInternalStateRecursive(AnimationPlayableEvaluationConstant const *constant)
    {
        UpdateInternalState<UPDATEMODE, ONLYNEEDSALLOCATE>(constant);

        int inputSize = m_Connections->m_Inputs.size();
        for (int i = 0; i < inputSize; ++i)
        {
            AnimationPlayable* childAnimationPlayable = GetNextCompatibleDescendant(i);
            if (childAnimationPlayable != NULL)
                childAnimationPlayable->UpdateInternalStateRecursive<UPDATEMODE, ONLYNEEDSALLOCATE>(constant);
        }

        if ((UPDATEMODE & kAllocateBindings) == kAllocateBindings)
            m_ChildsNeedsAllocateBindings = false;
    }

    virtual void AllocateBindings(AnimationPlayableEvaluationConstant const *constant)  { m_BindingsAllocated = true; m_NeedsAllocateBindings = false; }
    virtual void DeallocateBindings()                                                   { m_BindingsAllocated = false; }
    virtual bool ComputeNeedsBindingRebuilded()
    {
        bool ret = m_NeedsBindingRebuilded;
        TRAVERSE_OR_RESULT(ComputeNeedsBindingRebuilded, ret);
        return ret;
    }

    virtual bool GetApplyMotionX() const
    {
        bool ret = false;
        TRAVERSE_OR_RESULT(GetApplyMotionX, ret);
        return ret;
    }

    virtual NamedObject* GetAsset() const { return 0; }
    void OwnAsset(NamedObject* asset);


    virtual void SetStateMachineMessage(mecanim::statemachine::StateMachineMessage message) {}

    static bool ConnectNoTopologyChange(AnimationPlayable* left, AnimationPlayable* right, int leftOutputPort = -1, int rightInputPort = -1);
    static void DisconnectNoTopologyChange(AnimationPlayable* right, int inputPort);
    void SetNeedsBindingRebuilded(bool value) { m_NeedsBindingRebuilded = value; }

    bool NeedsPreProcess() const             { return m_NeedsPreProcess; }
    bool NeedsAllocateBindings() const       { return m_NeedsAllocateBindings || !m_BindingsAllocated; }
    bool ChildsNeedsAllocateBindings() const { return m_ChildsNeedsAllocateBindings; }

    void RequestPreProcess()            { m_NeedsPreProcess = true; }
    void RequestAllocateBindings()      { m_NeedsAllocateBindings = true; }
    void RequestChildAllocateBindings() { m_ChildsNeedsAllocateBindings = true; }

#if ANIMATION_PLAYABLE_SANITY_CHECK
    AnimationPlayableTypes m_Type;
#endif

protected:

    AnimationPlayable* GetNextCompatibleDescendant(int port) const;

    virtual bool SetInputConnection(Playable* input, int inputPort);

    mecanim::memory::MecanimAllocator m_Allocator;

    bool m_NeedsBindingRebuilded;

    bool m_NeedsPreProcess;
    bool m_NeedsAllocateBindings;
    bool m_ChildsNeedsAllocateBindings;

    bool m_BindingsAllocated;
    AssetReference m_AssetReference;
};

template<> UNITY_FORCEINLINE void AnimationPlayable::UpdateInternalState<0>(AnimationPlayableEvaluationConstant const *constant) {}
template<> UNITY_FORCEINLINE void AnimationPlayable::UpdateInternalState<AnimationPlayable::kDeallocateBindings>(AnimationPlayableEvaluationConstant const *constant)  {DeallocateBindings(); }
template<> UNITY_FORCEINLINE void AnimationPlayable::UpdateInternalState<AnimationPlayable::kAllocateBindings>(AnimationPlayableEvaluationConstant const *constant)    {AllocateBindings(constant); }
