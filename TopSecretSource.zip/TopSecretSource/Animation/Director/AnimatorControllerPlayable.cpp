#include "UnityPrefix.h"
#include "Runtime/Animation/AnimatorConfigure.h"
#include "Runtime/Animation/Director/AnimationClipPlayable.h"
#include "Runtime/Animation/Director/AnimatorControllerPlayable.h"
#include "Runtime/Animation/Director/AnimationMixerPlayable.h"
#include "Runtime/Animation/Director/AnimationStateMachineMixerPlayable.h"
#include "Runtime/Animation/Director/AnimationLayerMixerPlayable.h"
#include "Runtime/Animation/Director/AnimationPosePlayable.h"
#include "Runtime/Animation/AnimatorOverrideController.h"
#include "Runtime/Animation/Animator.h"
#include "Runtime/mecanim/animation/controller.h"
#include "Runtime/mecanim/animation/avatar.h"
#include "Runtime/mecanim/statemachine/statemachine.h"
#include "Runtime/Animation/AnimationSetBinding.h"

#include "Runtime/Director/Core/PlayableGraph.h"

#include "Runtime/mecanim/animation/damp.h"

#include "Runtime/GameCode/CloneObject.h"
#include "Runtime/Misc/GameObjectUtility.h"

#include "Runtime/Scripting/ScriptingManager.h"
#include "Runtime/Scripting/CommonScriptingClasses.h"
#include "Runtime/Scripting/ScriptingObjectWithIntPtrField.h"

#include "Runtime/Profiler/Profiler.h"

#include "Runtime/Director/Core/Traversers.h"

PROFILER_INFORMATION(gAnimatorControllerPlayablePrepareFrame, "AnimatorControllerPlayable.PrepareFrame",   kProfilerAnimation);
ANIMATOR_PROFILER_INFORMATION_DETAIL(gAnimatorControllerPlayableGenerateGraph, "AnimatorControllerPlayable.GenerateGraph", kProfilerAnimation);
ANIMATOR_PROFILER_INFORMATION_DETAIL(gAnimatorControllerPlayableUpdateGraph, "AnimatorControllerPlayable.UpdateGraph", kProfilerAnimation);

AnimatorControllerPlayable::AnimatorControllerPlayable(DirectorPlayerType playerType)
    : AnimationPlayable(playerType)
    , m_AnimatorController(NULL)
    , m_BehaviourPlayer(this)
    , m_LayerMixer(NULL)
    , m_Playables(NULL)
    , m_PlayablesCount(0)
    , m_AdditionalIndexArray(NULL)
    , m_DefaultValueOverride(NULL)
    , m_IsMultithreadable(true)
{
    SetScriptRestrictionFlags(kCantChangeWeights | kCantChangeTopology);
    PrepareChildren(false);
}

void AnimatorControllerPlayable::SetPlayState(PlayState state)
{
    m_LocalPlayState = state; // don't traverse, since we want AnimatorController child to be paused so that we drive its their time.
}

NamedObject* AnimatorControllerPlayable::GetAsset() const
{
    return m_AnimatorController;
}

void AnimatorControllerPlayable::AddObjectUser(UserList& user)
{
    if (m_AnimatorController)
        m_AnimatorController->GetUserList().AddUser(user);

    AnimationPlayable::AddObjectUser(user);
}

AnimationStateMachineMixerPlayable* AnimatorControllerPlayable::GetStateMachineMixer(int layerIndex) const
{
    const mecanim::uint32_t stateMachineIndex = m_AnimatorControllerMemory.m_ControllerConstant->m_LayerArray[layerIndex]->m_StateMachineIndex;
    const mecanim::uint32_t motionSetIndex = m_AnimatorControllerMemory.m_ControllerConstant->m_LayerArray[layerIndex]->m_StateMachineMotionSetIndex;

    return m_Playables[stateMachineIndex].m_StateMachineMixers[motionSetIndex];
}

void AnimatorControllerPlayable::PrepareForPlayback(mecanim::memory::Allocator& allocator)
{
    if (m_AnimatorControllerMemory.m_ControllerMemory && m_AnimatorControllerMemory.m_ControllerMemorySize == 0)
    {
        /// Blobify memory to be able to use inplace allocator during playback
        mecanim::animation::ControllerMemory *mem = m_AnimatorControllerMemory.m_ControllerMemory;
        m_AnimatorControllerMemory.m_ControllerMemory = CopyBlob(*mem, allocator, m_AnimatorControllerMemory.m_ControllerMemorySize);
        mecanim::animation::DestroyControllerMemory(mem, allocator);
    }
}

void AnimatorControllerPlayable::SetRecorderData(mecanim::animation::ControllerMemory* runtimeMemory, mecanim::memory::Allocator& allocator)
{
    mecanim::memory::InPlaceAllocator inPlaceAlloc(m_AnimatorControllerMemory.m_ControllerMemory, m_AnimatorControllerMemory.m_ControllerMemorySize);
    mecanim::animation::ControllerMemory* memoryCopy = CopyBlob(*runtimeMemory, inPlaceAlloc, m_AnimatorControllerMemory.m_ControllerMemorySize);
    if (memoryCopy != 0)
        m_AnimatorControllerMemory.m_ControllerMemory = memoryCopy;
    else
    {
        // We don't have enough memory to fulfill the request with the current m_EvaluationDataSet.m_AvatarMemory memory block
        // Let's try another time with a memory block big enough.
        mecanim::animation::DestroyControllerMemory(m_AnimatorControllerMemory.m_ControllerMemory, allocator);

        UInt8* ptr = reinterpret_cast<UInt8*>(allocator.Allocate(m_AnimatorControllerMemory.m_ControllerMemorySize, ALIGN_OF(mecanim::animation::ControllerMemory)));
        mecanim::memory::InPlaceAllocator inPlaceAlloc(ptr, m_AnimatorControllerMemory.m_ControllerMemorySize);
        m_AnimatorControllerMemory.m_ControllerMemory = CopyBlob(*runtimeMemory, inPlaceAlloc, m_AnimatorControllerMemory.m_ControllerMemorySize);
    }

    m_AnimatorControllerMemory.m_ControllerMemory->m_InPlayback = true;

    for (int i = 0; i < m_Playables->m_StateMachineMixersCount; ++i)
    {
        m_Playables->m_StateMachineMixers[i]->ArrangePlayables(m_AnimatorControllerMemory.m_ControllerMemory->m_StateMachineMemory[i]->m_InInterruptedTransition,
            m_AnimatorControllerMemory.m_ControllerWorkspace->m_StateMachineOutput[i]->m_IKOnFeet);
    }
}

mecanim::animation::ControllerMemory* AnimatorControllerPlayable::GetRecorderData()
{
    return m_AnimatorControllerMemory.m_ControllerMemory;
}

void AnimatorControllerPlayable::Memory::Reset(mecanim::memory::MecanimAllocator& allocator)
{
    mecanim::animation::DestroyControllerInput(m_ControllerInput, allocator);

    if (m_ControllerMemorySize == 0)
        mecanim::animation::DestroyControllerMemory(m_ControllerMemory, allocator);
    else
        allocator.Deallocate(m_ControllerMemory);

    mecanim::animation::DestroyControllerWorkspace(m_ControllerWorkspace, allocator);

    m_ControllerInput = 0;
    m_ControllerMemory = 0;
    m_ControllerWorkspace = 0;
    m_ControllerConstant = 0;
    m_ControllerMemorySize = 0;
}

void AnimatorControllerPlayable::SetAnimatorController(RuntimeAnimatorController* controller)
{
    if (m_AnimatorController != controller)
    {
        m_AnimatorController = controller;
        RebuildMemory();
        RequestAllocateBindings();
        m_IsMultithreadable = controller && controller->HasMultiThreadedStateMachine();
    }
}

void AnimatorControllerPlayable::SetOverrideController(AnimatorOverrideController* controller)
{
    m_AnimatorController = controller;
    RequestAllocateBindings();
}

void AnimatorControllerPlayable::OverrideClipPlayables()
{
    using namespace mecanim::statemachine;

    DebugAssert(m_AnimatorControllerMemory.m_ControllerMemory);
    if (m_AnimatorControllerMemory.m_ControllerMemory == NULL)
        return;

    const mecanim::animation::AnimationSet* animationSet = m_AnimatorController->GetAnimationSetBindings()->animationSet;

    uint32_t stateMachineMemCount = m_AnimatorControllerMemory.m_ControllerMemory->m_StateMachineCount;
    for (uint32_t stateMachineIndex = 0; stateMachineIndex < stateMachineMemCount; ++stateMachineIndex)
    {
        StateMachineOutput* stateMachineOutput = m_AnimatorControllerMemory.m_ControllerWorkspace->m_StateMachineOutput[stateMachineIndex];
        StateMachineMemory* stateMachineMemory = m_AnimatorControllerMemory.m_ControllerMemory->m_StateMachineMemory[stateMachineIndex].Get();
        const StateMachineConstant* stateMachineConstant = m_AnimatorControllerMemory.m_ControllerConstant->m_StateMachineArray[stateMachineIndex].Get();

        for (uint32_t motionSet = 0; motionSet < stateMachineMemory->m_MotionSetCount; ++motionSet)
        {
            AnimationStateMachineMixerPlayable* stateMachineMixer = stateMachineOutput->m_Playables->m_StateMachineMixers[motionSet];
            for (UInt8 state = 0; state < 2; state++)
            {
                bool current = (bool)state;
                if (current && stateMachineMixer->IsInInterruptedTransition())
                    continue;

                AnimationMixerPlayable* stateMixer = stateMachineMixer->GetStateMixerPlayable(current);
                uint32_t stateIndex = current ? stateMachineMemory->m_CurrentStateIndex : stateMachineMemory->m_NextStateIndex;
                if (stateMachineConstant->m_StateConstantCount <= stateIndex)
                    continue;

                const mecanim::animation::BlendTreeConstant* blendTree = mecanim::statemachine::GetBlendTreeConstant(*stateMachineConstant->m_StateConstantArray[stateIndex], motionSet);
                if (blendTree)
                {
                    const InputConnections& inputs = stateMixer->GetInputs();
                    int inputIndex = 0;
                    for (int i = 0; i < blendTree->m_NodeCount; ++i)
                    {
                        AnimationClipPlayable* animationClipPlayable = static_cast<AnimationClipPlayable*>(inputs[inputIndex].playable);
                        if (i < blendTree->m_NodeCount && blendTree->m_NodeArray[i]->m_ClipID != 0xffffffff)
                        {
                            AnimationClip* clip = animationSet->m_ClipConstant[blendTree->m_NodeArray[i]->m_ClipID].m_AnimationClip;
                            animationClipPlayable->SetClip(clip);
                            inputIndex++;
                        }
                    }
                }
            }
        }
    }
}

void AnimatorControllerPlayable::ClearFirstEvaluationFlag()
{
    if (!IsInitialized())
        return;

    if (m_AnimatorControllerMemory.m_ControllerMemory->m_FirstEval == mecanim::statemachine::kFirstEval)
        m_AnimatorControllerMemory.m_ControllerMemory->m_FirstEval = mecanim::statemachine::kFirstEvalCompleted;
}

void AnimatorControllerPlayable::GetAnimationClips(AnimationClips& animationClips)
{
    if (!IsInitialized())
        return;

    AnimationClipPPtrVector const& clips = m_AnimatorController->GetAnimationClips();
    for (int i = 0; i < clips.size(); i++)
    {
        if (!clips[i].IsNull())
        {
            animationClips.push_back(clips[i]);
        }
    }
}

void AnimatorControllerPlayable::PrepareFrame(const DirectorVisitorInfo& info)
{
    PrepareFrame(*info.frameInfo, info.rootNode, false);
}

void AnimatorControllerPlayable::PrepareFrame(const FrameData& info, Playable* source, bool forceEvaluation)
{
    if (!IsInitialized() || m_Connections->m_Inputs.size() == 0 || m_Connections->m_Inputs[0].playable == NULL)
        return;

    PROFILER_AUTO(gAnimatorControllerPlayablePrepareFrame, NULL);


    if (!forceEvaluation && m_AnimatorControllerMemory.m_ControllerMemory->m_InPlayback)
        return;

    bool deltaTimeIs0 = info.GetDeltaTime() == 0;
    if (m_AnimatorControllerMemory.m_ControllerMemory->m_FirstEval == mecanim::statemachine::kWaitForTick && !deltaTimeIs0)
        m_AnimatorControllerMemory.m_ControllerMemory->m_FirstEval = mecanim::statemachine::kFirstEval;

    UpdateGraph(info.GetDeltaTime());

    AnimationPlayable *animationPlayable = static_cast<AnimationPlayable*>(PlayableTraverser::RootByType(source, kAnimation));
    if (animationPlayable != NULL)
    {
        if (NeedsAllocateBindings() || ChildsNeedsAllocateBindings())
            animationPlayable->RequestChildAllocateBindings();

        if (NeedsPreProcess())
            animationPlayable->RequestPreProcess();
    }
}

void AnimatorControllerPlayable::ClearPlayable()
{
    if (m_LayerMixer != NULL)
    {
        GetParentGraph()->ScheduleSubgraphDestruction(m_LayerMixer->Handle());
        m_LayerMixer = NULL;
    }

    for (int stateMachine = 0; stateMachine < m_PlayablesCount; ++stateMachine)
    {
        m_Allocator.Deallocate(m_Playables[stateMachine].m_StateMachineMixers);
    }

    m_Allocator.Deallocate(m_Playables);

    m_Playables = 0;
    m_PlayablesCount = 0;
}

void AnimatorControllerPlayable::GenerateGraph()
{
    ANIMATOR_PROFILER_AUTO_DETAIL(gAnimatorControllerPlayableGenerateGraph, NULL);

    ClearPlayable();

    if (m_AnimatorController == 0)
        return;

    mecanim::animation::ControllerConstant* constant = m_AnimatorController->GetAsset();

    if (constant == 0)
        return;

    PlayableGraph* parentGraph = GetParentGraph();

    m_LayerMixer = parentGraph->ConstructPlayable<AnimationLayerMixerPlayable>(kAnimation);


    m_LayerMixer->SetScriptRestrictionFlags(kCantChangeAnything);

    AnimationPlayable::ConnectNoTopologyChange(m_LayerMixer, this, -1, GetInputs().size() == 0 ? -1 : 0);

    m_Playables = m_Allocator.ConstructArray<PlayableInstanceData>(constant->m_StateMachineCount);
    m_PlayablesCount = constant->m_StateMachineCount;

    for (int stateMachine = 0; stateMachine < constant->m_StateMachineCount; ++stateMachine)
    {
        m_Playables[stateMachine].m_StateMachineMixers = m_Allocator.ConstructArray<AnimationStateMachineMixerPlayable*>(constant->m_StateMachineArray[stateMachine]->m_MotionSetCount);
        m_Playables[stateMachine].m_StateMachineMixersCount = constant->m_StateMachineArray[stateMachine]->m_MotionSetCount;
    }

    for (int layer = 0; layer < constant->m_LayerCount; ++layer)
    {
        for (int stateMachine = 0; stateMachine < constant->m_StateMachineCount; ++stateMachine)
        {
            const mecanim::uint32_t stateMachineIndex = constant->m_LayerArray[layer]->m_StateMachineIndex;
            const mecanim::uint32_t motionSetIndex = constant->m_LayerArray[layer]->m_StateMachineMotionSetIndex;

            if (stateMachine == stateMachineIndex)
            {
                mecanim::statemachine::StateMachineWorkspace* stateMachineWorkspace = m_AnimatorControllerMemory.m_ControllerWorkspace->m_StateMachineWorkspace[stateMachineIndex];
                mecanim::statemachine::StateMachineMemory* stateMachineMemory = m_AnimatorControllerMemory.m_ControllerMemory->m_StateMachineMemory[stateMachineIndex].Get();
                // Graph is rebuilded, PosePlayable is added at index 2
                stateMachineMemory->m_InInterruptedTransition = false;

                AnimationStateMachineMixerPlayable* stateMachineMixer = parentGraph->ConstructPlayable<AnimationStateMachineMixerPlayable>(kAnimation);

                AnimationPlayable::ConnectNoTopologyChange(stateMachineMixer, m_LayerMixer);

                m_LayerMixer->SetInputWeight(layer, layer == 0 ? 1.0f : m_AnimatorControllerMemory.m_ControllerMemory->m_LayerWeights[layer]);

                AnimationMixerPlayable* stateMachineMixerLeft = parentGraph->ConstructPlayable<AnimationMixerPlayable>(kAnimation);
                AnimationMixerPlayable* stateMachineMixerRight = parentGraph->ConstructPlayable<AnimationMixerPlayable>(kAnimation);
                AnimationPosePlayable* interruptTransitionPose = parentGraph->ConstructPlayable<AnimationPosePlayable>(kAnimation);

                stateMachineMixerLeft->SetScriptRestrictionFlags(kCantChangeAnything);
                stateMachineMixerRight->SetScriptRestrictionFlags(kCantChangeAnything);
                interruptTransitionPose->SetScriptRestrictionFlags(kCantChangeAnything);

                AnimationPlayable::ConnectNoTopologyChange(stateMachineMixerLeft, stateMachineMixer);
                AnimationPlayable::ConnectNoTopologyChange(stateMachineMixerRight, stateMachineMixer);
                AnimationPlayable::ConnectNoTopologyChange(interruptTransitionPose, stateMachineMixer);
                stateMachineMixer->SetInterruptedPoseIndex(2);

                stateMachineMixer->SetInputWeight(0, 1.0f);
                stateMachineMixer->SetInputWeight(1, 0.0f);
                stateMachineMixer->SetInputWeight(2, 0.0f);

                for (int i = 0; i < stateMachineWorkspace->m_MaxBlendedClipCount; i++)
                {
                    AnimationClipPlayable* animationClipPlayableLeft = parentGraph->ConstructPlayable<AnimationClipPlayable>(kAnimation);
                    AnimationClipPlayable* animationClipPlayableRight = parentGraph->ConstructPlayable<AnimationClipPlayable>(kAnimation);


                    animationClipPlayableLeft->SetScriptRestrictionFlags(kCantChangeAnything);
                    animationClipPlayableRight->SetScriptRestrictionFlags(kCantChangeAnything);

                    AnimationPlayable::ConnectNoTopologyChange(animationClipPlayableLeft, stateMachineMixerLeft);
                    AnimationPlayable::ConnectNoTopologyChange(animationClipPlayableRight, stateMachineMixerRight);

                    stateMachineMixerLeft->SetInputWeight(i, 0.0f);
                    stateMachineMixerRight->SetInputWeight(i, 0.0f);
                }

                AnimationPosePlayable* leftEmptyPose = parentGraph->ConstructPlayable<AnimationPosePlayable>(kAnimation);
                leftEmptyPose->SetScriptRestrictionFlags(kCantChangeAnything);
                AnimationPlayable::ConnectNoTopologyChange(leftEmptyPose, stateMachineMixerLeft);
                stateMachineMixerLeft->SetInputWeight(stateMachineWorkspace->m_MaxBlendedClipCount, 0.0f);

                AnimationPosePlayable* rightEmptyPose = parentGraph->ConstructPlayable<AnimationPosePlayable>(kAnimation);
                rightEmptyPose->SetScriptRestrictionFlags(kCantChangeAnything);
                AnimationPlayable::ConnectNoTopologyChange(rightEmptyPose, stateMachineMixerRight);
                stateMachineMixerRight->SetInputWeight(stateMachineWorkspace->m_MaxBlendedClipCount, 0.0f);

                stateMachineMixer->SetNeedsBindingRebuilded(false);
                stateMachineMixer->SetScriptRestrictionFlags(kCantChangeAnything);
                m_Playables[stateMachine].m_StateMachineMixers[motionSetIndex] = stateMachineMixer;
            }
        }
    }

    for (int stateMachine = 0; stateMachine < constant->m_StateMachineCount; ++stateMachine)
    {
        mecanim::animation::ControllerInput*        controllerInput     = m_AnimatorControllerMemory.m_ControllerInput;
        mecanim::animation::ControllerWorkspace*    controllerWorkspace = m_AnimatorControllerMemory.m_ControllerWorkspace;
        mecanim::animation::ControllerMemory*       controllerMemory    = m_AnimatorControllerMemory.m_ControllerMemory;

        memset(controllerWorkspace->m_TriggerResetArray, 0, sizeof(bool) * controllerMemory->m_Values->m_BoolCount);

        mecanim::statemachine::StateMachineInput stateMachineInput;
        int stateMachineLayerIndex = 0;
        stateMachineInput.m_MotionSetTimingWeightArray = controllerWorkspace->m_MotionSetTimingWeightArray;


        for (mecanim::uint32_t layerIndex = 0; layerIndex < constant->m_LayerCount; layerIndex++)
        {
            const mecanim::uint32_t stateMachineIndex = constant->m_LayerArray[layerIndex]->m_StateMachineIndex;
            const mecanim::uint32_t motionSetIndex = constant->m_LayerArray[layerIndex]->m_StateMachineMotionSetIndex;

            if (stateMachine == stateMachineIndex)
            {
                if (motionSetIndex == 0)
                {
                    stateMachineInput.m_GotoStateInfo = &controllerInput->m_GotoStateInfos[layerIndex];
                    stateMachineLayerIndex = layerIndex;
                }

                if (constant->m_LayerArray[layerIndex]->m_SyncedLayerAffectsTiming || motionSetIndex == 0)
                    stateMachineInput.m_MotionSetTimingWeightArray[motionSetIndex] = motionSetIndex == 0 ? 1 : controllerMemory->m_LayerWeights[layerIndex];
                else
                    stateMachineInput.m_MotionSetTimingWeightArray[motionSetIndex] = 0;
            }
        }


        stateMachineInput.m_DeltaTime                   = 0.0f;
        stateMachineInput.m_FirstEval                   = controllerMemory->m_FirstEval;
        stateMachineInput.m_StateMachineBehaviourPlayer = &m_BehaviourPlayer;
        stateMachineInput.m_AnimationSet                = m_AnimatorController->GetAnimationSetBindings()->animationSet;
        stateMachineInput.m_LayerIndex                  = stateMachineLayerIndex;


        stateMachineInput.m_Values = controllerMemory->m_Values.Get();
        controllerWorkspace->m_StateMachineWorkspace[stateMachine]->m_ValuesConstant = const_cast<mecanim::ValueArrayConstant *>(constant->m_Values.Get());
        controllerWorkspace->m_StateMachineWorkspace[stateMachine]->m_TriggerResetArray = &controllerWorkspace->m_TriggerResetArray;
        controllerWorkspace->m_StateMachineOutput[stateMachine]->m_Playables = &m_Playables[stateMachine];


        mecanim::statemachine::SetStateMachineInInitialState(*constant->m_StateMachineArray[stateMachine],
            stateMachineInput,
            *controllerWorkspace->m_StateMachineOutput[stateMachine],
            *controllerMemory->m_StateMachineMemory[stateMachine],
            *controllerWorkspace->m_StateMachineWorkspace[stateMachine]);
    }

    SetLayerAutoWeight();
}

void AnimatorControllerPlayable::RebuildMemory()
{
    AllocateMemory();
    GenerateGraph();
    SetupStateMachineBehaviours();
}

void AnimatorControllerPlayable::UpdateGraph(float deltaTime)
{
    m_NeedsPreProcess       = false;

    if (!IsInitialized())
        return;


    ANIMATOR_PROFILER_AUTO_DETAIL(gAnimatorControllerPlayableUpdateGraph, NULL);

    const mecanim::animation::ControllerConstant*   constant = m_AnimatorControllerMemory.m_ControllerConstant;

    mecanim::animation::ControllerInput*        controllerInput     = m_AnimatorControllerMemory.m_ControllerInput;
    mecanim::animation::ControllerWorkspace*    controllerWorkspace = m_AnimatorControllerMemory.m_ControllerWorkspace;
    mecanim::animation::ControllerMemory*       controllerMemory    = m_AnimatorControllerMemory.m_ControllerMemory;

    memset(controllerWorkspace->m_TriggerResetArray, 0, sizeof(bool) * controllerMemory->m_Values->m_BoolCount);

    mecanim::uint32_t i;

    for (i = 0; i < constant->m_StateMachineCount; i++)
    {
        mecanim::statemachine::StateMachineInput stateMachineInput;
        stateMachineInput.m_Speed = controllerInput->m_Speed;
        stateMachineInput.m_MotionSetTimingWeightArray = controllerWorkspace->m_MotionSetTimingWeightArray;

        int stateMachineLayerIndex = 0;

        for (mecanim::uint32_t layerIndex = 0; layerIndex < constant->m_LayerCount; layerIndex++)
        {
            const mecanim::uint32_t stateMachineIndex = constant->m_LayerArray[layerIndex]->m_StateMachineIndex;
            const mecanim::uint32_t motionSetIndex = constant->m_LayerArray[layerIndex]->m_StateMachineMotionSetIndex;

            if (i == stateMachineIndex)
            {
                if (motionSetIndex == 0)
                {
                    stateMachineInput.m_GotoStateInfo = &controllerInput->m_GotoStateInfos[layerIndex];
                    stateMachineLayerIndex = layerIndex;
                }

                if (constant->m_LayerArray[layerIndex]->m_SyncedLayerAffectsTiming || motionSetIndex == 0)
                    stateMachineInput.m_MotionSetTimingWeightArray[motionSetIndex] = motionSetIndex == 0 ? 1 : controllerMemory->m_LayerWeights[layerIndex];
                else
                    stateMachineInput.m_MotionSetTimingWeightArray[motionSetIndex] = 0;
            }
        }


        stateMachineInput.m_DeltaTime                   = deltaTime;
        stateMachineInput.m_FirstEval                   = controllerMemory->m_FirstEval;
        stateMachineInput.m_StateMachineBehaviourPlayer = &m_BehaviourPlayer;
        stateMachineInput.m_AnimationSet                = m_AnimatorController->GetAnimationSetBindings()->animationSet;
        stateMachineInput.m_LayerIndex                  = stateMachineLayerIndex;

        stateMachineInput.m_Values = controllerMemory->m_Values.Get();
        controllerWorkspace->m_StateMachineWorkspace[i]->m_ValuesConstant = const_cast<mecanim::ValueArrayConstant *>(constant->m_Values.Get());
        controllerWorkspace->m_StateMachineWorkspace[i]->m_TriggerResetArray = &controllerWorkspace->m_TriggerResetArray;


        controllerWorkspace->m_StateMachineOutput[i]->m_Playables = &m_Playables[i];
        mecanim::statemachine::EvaluateStateMachine(*constant->m_StateMachineArray[i].Get(),
            stateMachineInput,
            *controllerWorkspace->m_StateMachineOutput[i],
            *controllerMemory->m_StateMachineMemory[i].Get(),
            *controllerWorkspace->m_StateMachineWorkspace[i]);

        m_NeedsPreProcess |= controllerMemory->m_StateMachineMemory[i]->m_InInterruptedTransition || controllerWorkspace->m_StateMachineOutput[i]->m_HasPosePlayable;

        if (controllerWorkspace->m_StateMachineOutput[i]->m_RequestAllocateBindings)
            RequestChildAllocateBindings();

        controllerMemory->m_StateMachineMemory[i]->m_ResetPlayableGraph = false;
        if (mecanim::statemachine::IsDisabled(&stateMachineInput))
            return;
    }

    for (i = 0; i < controllerMemory->m_Values->m_BoolCount; i++)
    {
        if (controllerWorkspace->m_TriggerResetArray[i] == true)
        {
            controllerMemory->m_Values->WriteData(false, i);
        }
    }

    SetLayerAutoWeight();
}

void AnimatorControllerPlayable::SetLayerAutoWeight()
{
    const mecanim::animation::ControllerConstant*   constant = m_AnimatorControllerMemory.m_ControllerConstant;
    mecanim::animation::ControllerMemory* controllerMemory  = m_AnimatorControllerMemory.m_ControllerMemory;

    for (int i = 0; i < constant->m_LayerCount; i++)
    {
        const mecanim::uint32_t stateMachineIndex = constant->m_LayerArray[i]->m_StateMachineIndex;
        const mecanim::uint32_t motionSetIndex = constant->m_LayerArray[i]->m_StateMachineMotionSetIndex;
        const float autoWeight = controllerMemory->m_StateMachineMemory[stateMachineIndex]->m_MotionSetAutoWeightArray[motionSetIndex];
        const float layerWeight = controllerMemory->m_LayerWeights[i];

        AnimationLayerMixerPlayable* layerMixerPlayable = static_cast<AnimationLayerMixerPlayable*>(m_Connections->m_Inputs[0].playable);

        if (layerMixerPlayable != NULL)
        {
            AnimationLayerMixerPlayable::LayerParameters& layerParameters = static_cast<AnimationLayerMixerPlayable*>(m_Connections->m_Inputs[0].playable)->GetParameters(i);
            m_Connections->m_Inputs[0].playable->SetInputWeight(i, i == 0 ? 1 : layerWeight * autoWeight);
            layerParameters.m_LayerWeight = i == 0 ? 1.0f : layerWeight;
            layerParameters.m_Additive = constant->m_LayerArray[i].Get()->m_LayerBlendingMode == mecanim::animation::kLayerBlendingModeAdditive;
        }
    }
}

void AnimatorControllerPlayable::PreProcessAnimation(AnimationPlayableEvaluationConstant const *constant, mecanim::animation::AnimationNodeState const* state)
{
    if (!IsInitialized() || GetInputs().size() == 0)
        return;

    const InputConnections& inputs = m_LayerMixer->GetInputs();
    for (int layerIter = 0; layerIter < inputs.size(); layerIter++)
    {
        if (inputs[layerIter].playable != NULL)
        {
            static_cast<AnimationPlayable*>(inputs[layerIter].playable)->PreProcessAnimation(constant, m_LayerMixer->m_LayerMixerMemory.nodeStateArray[layerIter]);
        }
    }


    m_NeedsPreProcess = false;
}

void AnimatorControllerPlayable::CollectAnimatorControllerPlayables(AnimatorControllerPlayables& controllerPlayables)
{
    controllerPlayables.push_back(this);
}

bool AnimatorControllerPlayable::SetupStateMachineBehaviours()
{
    // Already setup, early out
    if (!IsInitialized() || m_StateMachineBehaviours.size() > 0)
        return true;


    const StateMachineBehaviourVector & behaviours = m_AnimatorController->GetBehaviours();
    m_StateMachineBehaviours.reserve(behaviours.size());
    m_BehaviourPlayer.m_Playable = this;

    StateMachineBehaviourVector::const_iterator it;
    PPtr<MonoBehaviour> behaviour = NULL;
    core::string lastBehaviourName;
    for (it = behaviours.begin(); it != behaviours.end() && behaviours.size() > 0; ++it)
    {
        behaviour = *it;
        if (behaviour.IsNull())
        {
            // case 756129, this list must stay in sync with StateMachineBehaviourVectorDescription
            // if we unsync them we will run into trouble at runtime, insert a null behaviour
            m_StateMachineBehaviours.push_back(behaviour);
            continue;
        }

        // check if SharedBetweenAnimatorsAttribute is set
        ScriptingClassPtr klass = behaviour->GetClass();

        // Can happen if mono script has been deleted
        if (klass == SCRIPTING_NULL)
        {
            // case 756129, this list must stay in sync with StateMachineBehaviourVectorDescription
            // if we unsync them we will run into trouble at runtime, insert a null behaviour
            m_StateMachineBehaviours.push_back(behaviour);
            continue;
        }

        lastBehaviourName = behaviour->GetScriptFullClassName();

        if (!scripting_class_has_attribute(klass, GetAnimationScriptingClasses().sharedBetweenAnimatorsAttribute))
        {
            m_StateMachineBehaviours.push_back(dynamic_pptr_cast<MonoBehaviour*>(&CloneObject(*behaviour)));
            (m_StateMachineBehaviours.back())->SetHideFlags(Object::kHideAndDontSave);
        }
        else
            m_StateMachineBehaviours.push_back(behaviour);
    }
    if (behaviours.size() == 0 && m_StateMachineBehaviours.size() != 0)
    {
        m_StateMachineBehaviours.clear();
        m_AnimatorControllerMemory.Reset(m_Allocator);
        ErrorStringMsg("An animator Reset was caused during %s::Awake. This will lead to undefined behaviour", lastBehaviourName.c_str());
    }
    return m_StateMachineBehaviours.size() > 0;
}

void AnimatorControllerPlayable::CleanupStateMachineBehaviours()
{
    StateMachineBehaviourVector::iterator it;
    for (it = m_StateMachineBehaviours.begin(); it != m_StateMachineBehaviours.end(); ++it)
    {
        PPtr<MonoBehaviour> behaviour = *it;
        if (behaviour.IsNull())
            continue;

        // check if SharedBetweenAnimatorsAttribute is set
        ScriptingClassPtr klass = behaviour->GetClass();

        // Can happen if mono script has been deleted
        if (klass == SCRIPTING_NULL)
            continue;

        if (!scripting_class_has_attribute(klass, GetAnimationScriptingClasses().sharedBetweenAnimatorsAttribute))
        {
            DestroyObjectHighLevel(behaviour);
        }
    }

    m_StateMachineBehaviours.clear();
}

void AnimatorControllerPlayable::AllocateMemory()
{
    if (m_AnimatorController != NULL)
    {
        m_AnimatorControllerMemory.m_ControllerConstant     = m_AnimatorController->GetAsset();

        if (m_AnimatorControllerMemory.m_ControllerConstant != 0)
        {
            m_AnimatorControllerMemory.m_ControllerInput        = mecanim::animation::CreateControllerInput(m_AnimatorControllerMemory.m_ControllerConstant, m_Allocator);
            m_AnimatorControllerMemory.m_ControllerMemory       = mecanim::animation::CreateControllerMemory(m_AnimatorControllerMemory.m_ControllerConstant, m_Allocator);
            m_AnimatorControllerMemory.m_ControllerWorkspace    = mecanim::animation::CreateControllerWorkspace(m_AnimatorControllerMemory.m_ControllerConstant, m_Allocator);
            m_AnimatorControllerMemory.m_ControllerMemorySize   = 0;
        }
        else
        {
            WarningStringMsg("The Animator Controller (%s) you have used is not valid. Animations will not play", m_AnimatorController->GetName());
        }
    }
}

void AnimatorControllerPlayable::DeallocateResources()
{
    ClearPlayable();
    CleanupStateMachineBehaviours();
    m_AnimatorControllerMemory.Reset(m_Allocator);
    AnimationPlayable::DeallocateResources();
}

void AnimatorControllerPlayable::AllocateBindings(AnimationPlayableEvaluationConstant const *constant)
{
    if (!m_BindingsAllocated && m_AnimatorController != NULL && IsInitialized())
    {
        mecanim::animation::ControllerConstant const* controllerConstant = m_AnimatorController->GetAsset();

        if (controllerConstant != NULL)
        {
            m_AdditionalIndexArray = m_Allocator.ConstructArray<int32_t>(controllerConstant->m_Values->m_Count, int32_t(-1));

            BindAdditionalCurves(*controllerConstant->m_Values, constant->genericBindingsSize, constant->genericBindings, m_AdditionalIndexArray);
            m_BehaviourPlayer.m_Player = constant->player; // bind the BehaviourPlayer to the Player

            m_LayerMixer->SetControllerConstant(controllerConstant);
            m_DefaultValueOverride = mecanim::CreateValueArray(constant->values, m_Allocator);
            mecanim::ValueArrayCopy(constant->defaultValues, m_DefaultValueOverride);

            ValueArrayReverseCopy(m_AnimatorControllerMemory.m_ControllerConstant->m_Values.Get(), m_AnimatorControllerMemory.m_ControllerMemory->m_Values.Get(),
                constant->values, m_DefaultValueOverride,
                m_AdditionalIndexArray);
        }

        AnimationPlayable::AllocateBindings(constant);
    }
}

void AnimatorControllerPlayable::DeallocateBindings()
{
    if (m_BindingsAllocated)
    {
        m_Allocator.Deallocate(m_AdditionalIndexArray);
        mecanim::DestroyValueArray(m_DefaultValueOverride, m_Allocator);
        m_AdditionalIndexArray = 0;
        m_DefaultValueOverride = 0;
    }
    AnimationPlayable::DeallocateBindings();
}

void AnimatorControllerPlayable::ProcessAnimation(AnimationPlayableEvaluationConstant *constant, AnimationPlayableEvaluationInput *input, AnimationPlayableEvaluationOutput *output)
{
    if (m_AdditionalIndexArray != NULL)
    {
        ValueArrayReverseCopy(m_AnimatorControllerMemory.m_ControllerConstant->m_Values.Get(), m_AnimatorControllerMemory.m_ControllerConstant->m_DefaultValues.Get(),
            constant->values, output->nodeStateOutput->m_DynamicValues,
            m_AdditionalIndexArray);
    }

    AnimationPlayableEvaluationInput localInput = *input;
    localInput.defaultValuesOverride = m_DefaultValueOverride;
    AnimationPlayable::ProcessAnimation(constant, &localInput, output);

    if (!IsInitialized())
        return;

    if (m_AnimatorControllerMemory.m_ControllerMemory->m_StateMachineCount > 0 && m_AnimatorControllerMemory.m_ControllerMemory->m_StateMachineMemory[0]->m_CleanAfterTransition)
    {
        input->avatarInput->m_TargetIndex = -1;
    }

    // Write the Animator.Parameters
    if (m_AdditionalIndexArray != NULL)
        ValueArrayCopy(constant->values, output->nodeStateOutput->m_DynamicValues,
            m_AnimatorControllerMemory.m_ControllerConstant->m_Values.Get(), m_AnimatorControllerMemory.m_ControllerMemory->m_Values.Get(), m_AdditionalIndexArray);
}

GetSetValueResult AnimatorControllerPlayable::SetFloat(int id, const float& value)
{
    return SetValue(id, value);
}

GetSetValueResult AnimatorControllerPlayable::SetBool(int id, const bool& value)
{
    return SetValue(id, value);
}

GetSetValueResult AnimatorControllerPlayable::SetInteger(int id, const int& value)
{
    return SetValue(id, (mecanim::int32_t)value);
}

GetSetValueResult AnimatorControllerPlayable::GetFloat(int id, float& output)
{
    return GetValue(id, output);
}

GetSetValueResult AnimatorControllerPlayable::GetBool(int id, bool& output)
{
    return GetValue(id, output);
}

GetSetValueResult AnimatorControllerPlayable::GetInteger(int id, int& output)
{
    mecanim::int32_t temp;
    GetSetValueResult res = GetValue(id, temp);
    output = temp;
    return res;
}

GetSetValueResult AnimatorControllerPlayable::ResetTrigger(int id)
{
    return SetValue(id, false);
}

GetSetValueResult AnimatorControllerPlayable::SetTrigger(int id)
{
    return SetValue(id, true);
}

template<typename T> inline bool IsTypeMatching(mecanim::ValueConstant const& valueConstant, T const& value)
{
    return valueConstant.m_Type == mecanim::traits<T>::type() ||
        (valueConstant.m_Type == mecanim::kTriggerType && mecanim::traits<T>::type() == mecanim::kBoolType);
}

template<typename T> inline
GetSetValueResult AnimatorControllerPlayable::SetValue(mecanim::uint32_t id, T const& value)
{
    if (!IsInitialized())
        return kAnimatorNotInitialized;

    mecanim::int32_t i = mecanim::FindValueIndex(m_AnimatorControllerMemory.m_ControllerConstant->m_Values.Get(), id);
    if (i == -1)
        return kParameterDoesNotExist;

    bool isCurve = m_AdditionalIndexArray != NULL && m_AdditionalIndexArray[i] != -1;
    if (isCurve)
        return kParameterIsControlledByCurve;

    if (!IsTypeMatching(m_AnimatorControllerMemory.m_ControllerConstant->m_Values->m_ValueArray[i], value))
        return kParameterMismatchFailure;

    m_AnimatorControllerMemory.m_ControllerMemory->m_Values->WriteData(value, m_AnimatorControllerMemory.m_ControllerConstant->m_Values->m_ValueArray[i].m_Index);

    return kGetSetSuccess;
}

template<typename T> inline
GetSetValueResult AnimatorControllerPlayable::GetValue(mecanim::uint32_t id, T& value)
{
    if (!IsInitialized())
    {
        value = T();
        return kAnimatorNotInitialized;
    }

    mecanim::int32_t i = mecanim::FindValueIndex(m_AnimatorControllerMemory.m_ControllerConstant->m_Values.Get(), id);

    if (i == -1)
    {
        value = T();
        return kParameterDoesNotExist;
    }

    if (!IsTypeMatching(m_AnimatorControllerMemory.m_ControllerConstant->m_Values->m_ValueArray[i], value))
    {
        value = T();
        return kParameterMismatchFailure;
    }

    m_AnimatorControllerMemory.m_ControllerMemory->m_Values->ReadData(value, m_AnimatorControllerMemory.m_ControllerConstant->m_Values->m_ValueArray[i].m_Index);
    return kGetSetSuccess;
}

bool AnimatorControllerPlayable::IsInitialized() const
{
    return m_AnimatorControllerMemory.m_ControllerMemory != 0;
}

bool AnimatorControllerPlayable::ValidateLayerIndex(int index) const
{
    if (!IsInitialized())
        return false;

    if (index < 0 || index >= GetLayerCount())
    {
        WarningStringObject(Format("Invalid Layer Index '%d'", index), m_AnimatorController);
        return false;
    }

    return true;
}

void AnimatorControllerPlayable::ValidateParameterID(GetSetValueResult result, int identifier)
{
    ValidateParameterString(result, Format("Hash %d", identifier));
}

void AnimatorControllerPlayable::ValidateParameterString(GetSetValueResult result, const core::string& name)
{
    if (result & kParameterMismatchFailure)
    {
        WarningStringObject(Format("Parameter type '%s' does not match.", name.c_str()), m_AnimatorController);
    }
    if (result & kParameterDoesNotExist)
    {
        WarningStringObject(Format("Parameter '%s' does not exist.", name.c_str()), m_AnimatorController);
    }
    if (result & kAnimatorNotInitialized)
    {
        WarningStringObject("Animator has not been initialized.", m_AnimatorController);
    }
    if (result & kParameterIsControlledByCurve)
    {
        WarningStringObject(Format("Parameter '%s' is controlled by a curve.", name.c_str()), m_AnimatorController);
    }
}

GetSetValueResult AnimatorControllerPlayable::ParameterControlledByCurve(int id)
{
    if (!IsInitialized())
        return kAnimatorNotInitialized;

    mecanim::int32_t index = mecanim::FindValueIndex(m_AnimatorControllerMemory.m_ControllerConstant->m_Values.Get(), id);
    if (index == -1)
        return kParameterDoesNotExist;

    if (m_AdditionalIndexArray[index] != -1)
        return kParameterIsControlledByCurve;
    else
        return kGetSetSuccess;
}

bool AnimatorControllerPlayable::HasParameter(int id)
{
    if (!IsInitialized())
        return false;

    mecanim::int32_t i = mecanim::FindValueIndex(m_AnimatorControllerMemory.m_ControllerConstant->m_Values.Get(), id);
    return i != -1;
}

int AnimatorControllerPlayable::GetLayerCount() const
{
    if (!IsInitialized())
        return 0;

    return m_AnimatorControllerMemory.m_ControllerConstant->m_LayerCount;
}

core::string    AnimatorControllerPlayable::GetLayerName(int layerIndex)
{
    if (!ValidateLayerIndex(layerIndex))
        return "";

    return m_AnimatorController->StringFromID(m_AnimatorControllerMemory.m_ControllerConstant->m_LayerArray[layerIndex]->m_Binding);
}

int AnimatorControllerPlayable::GetLayerIndex(const core::string& layerName)
{
    int id = mecanim::processCRC32(layerName.c_str());

    int index = -1;
    for (int i = 0, count = GetLayerCount(); i < count; ++i)
    {
        if (m_AnimatorControllerMemory.m_ControllerConstant->m_LayerArray[i]->m_Binding == id)
        {
            index = i;
            break;
        }
    }

    return index;
}

float   AnimatorControllerPlayable::GetLayerWeight(int layerIndex)
{
    if (!ValidateLayerIndex(layerIndex))
        return layerIndex == 0 ? 1 : 0;

    return m_AnimatorControllerMemory.m_ControllerMemory->m_LayerWeights[layerIndex];
}

void AnimatorControllerPlayable::SetLayerWeight(int layerIndex, float w)
{
    if (!ValidateLayerIndex(layerIndex))
        return;

    m_AnimatorControllerMemory.m_ControllerMemory->m_LayerWeights[layerIndex] = w;
}

AnimatorControllerParameterVector AnimatorControllerPlayable::GetParameters()
{
    AnimatorControllerParameterVector ret;

    if (!IsInitialized())
        return ret;

    ret.reserve(m_AnimatorControllerMemory.m_ControllerConstant->m_Values->m_Count);

    for (int i = 0; i < m_AnimatorControllerMemory.m_ControllerConstant->m_Values->m_Count; ++i)
    {
        AnimatorControllerParameter parameter;
        parameter.m_Name = ResolveHash(m_AnimatorControllerMemory.m_ControllerConstant->m_Values->m_ValueArray[i].m_ID);
        parameter.m_Type = (AnimatorControllerParameterType)m_AnimatorControllerMemory.m_ControllerConstant->m_Values->m_ValueArray[i].m_Type;

        switch (parameter.m_Type)
        {
            case AnimatorControllerParameterTypeFloat:
                m_AnimatorControllerMemory.m_ControllerConstant->m_DefaultValues->ReadData(parameter.m_DefaultFloat, m_AnimatorControllerMemory.m_ControllerConstant->m_Values->m_ValueArray[i].m_Index);
                break;
            case AnimatorControllerParameterTypeInt:
                m_AnimatorControllerMemory.m_ControllerConstant->m_DefaultValues->ReadData(parameter.m_DefaultInt, m_AnimatorControllerMemory.m_ControllerConstant->m_Values->m_ValueArray[i].m_Index);
                break;
            case AnimatorControllerParameterTypeBool:
                m_AnimatorControllerMemory.m_ControllerConstant->m_DefaultValues->ReadData(parameter.m_DefaultBool, m_AnimatorControllerMemory.m_ControllerConstant->m_Values->m_ValueArray[i].m_Index);
                break;
            default:
                break;
        }

        ret.push_back(parameter);
    }

    return ret;
}

bool AnimatorControllerPlayable::IsInTransitionInternal(int layerIndex) const
{
    mecanim::uint32_t stateMachineIndex = m_AnimatorControllerMemory.m_ControllerConstant->m_LayerArray[layerIndex]->m_StateMachineIndex;

    mecanim::statemachine::StateMachineMemory const* apStateMachineMem = m_AnimatorControllerMemory.m_ControllerMemory->m_StateMachineMemory[stateMachineIndex].Get();
    return apStateMachineMem->m_InTransition;
}

bool AnimatorControllerPlayable::IsInTransition(int layerIndex) const
{
    if (!ValidateLayerIndex(layerIndex))
        return false;

    return IsInTransitionInternal(layerIndex);
}

int AnimatorControllerPlayable::GetAnimatorClipInfoCount(int layerIndex, bool currentState) const
{
    if (!ValidateLayerIndex(layerIndex))
        return 0;


    const mecanim::uint32_t stateMachineIndex = m_AnimatorControllerMemory.m_ControllerConstant->m_LayerArray[layerIndex]->m_StateMachineIndex;

    const bool justExited = m_AnimatorControllerMemory.m_ControllerWorkspace->m_StateMachineOutput[stateMachineIndex]->m_EndTransition;

    AnimationStateMachineMixerPlayable* stateMachineMixer = GetStateMachineMixer(layerIndex);
    if (stateMachineMixer->IsInInterruptedTransition())
        return 0;

    bool left = currentState && !justExited;
    AnimationMixerPlayable* stateMixer = stateMachineMixer->GetStateMixerPlayable(left);

    if (stateMixer == NULL)
        return 0;

    const InputConnections& inputs = stateMixer->GetInputs();
    const int size = inputs.size();

    int count = 0;

    for (int i = 0; i < size - 1; i++)
    {
        if (stateMixer->GetInputWeight(i))
            ++count;
    }

    return count;
}

bool AnimatorControllerPlayable::GetAnimatorClipInfo(int layerIndex, bool currentState, dynamic_array<AnimatorClipInfo>& output)
{
    if (!ValidateLayerIndex(layerIndex))
        return false;

    const mecanim::uint32_t stateMachineIndex = m_AnimatorControllerMemory.m_ControllerConstant->m_LayerArray[layerIndex]->m_StateMachineIndex;

    const mecanim::statemachine::StateMachineMemory* stateMachineMemory = m_AnimatorControllerMemory.m_ControllerMemory->m_StateMachineMemory[stateMachineIndex].Get();

    if (currentState && stateMachineMemory->m_InInterruptedTransition)
        return false;

    const bool justExited = m_AnimatorControllerMemory.m_ControllerWorkspace->m_StateMachineOutput[stateMachineIndex]->m_EndTransition;

    float transitionWeight = 1.f - GetStateMachineMixer(layerIndex)->GetInputWeight(0);

    AnimationStateMachineMixerPlayable* stateMachineMixer = GetStateMachineMixer(layerIndex);
    bool left =  currentState && !justExited;

    float blendFactor = left ? 1 - transitionWeight : transitionWeight;

    AnimationMixerPlayable* stateMixer = stateMachineMixer->GetStateMixerPlayable(left);

    if (stateMixer == NULL)
        return false;

    const InputConnections& inputs = stateMixer->GetInputs();
    output.reserve(inputs.size());

    // As long as we have the AnimationPosePlayable always connected in the last input slot in the graph for write default
    // we must jump over the last input
    //  see void AnimatorControllerPlayable::GenerateGraph()
    for (int i = 0; i < inputs.size() - 1; i++)
    {
        AnimatorClipInfo animInfo;
        AnimationPlayable* playable = static_cast<AnimationPlayable*>(inputs[i].playable);
        AnimationClip* clip = dynamic_pptr_cast<AnimationClip*>(playable->GetAsset());
        if (clip)
        {
            animInfo.clip = clip;
            animInfo.weight = blendFactor * stateMixer->GetInputWeight(i);
            if (stateMixer->GetInputWeight(i))
                output.push_back(animInfo);
        }
    }

    return true;
}

static inline mecanim::uint32_t GetStateIndex(StateInfoIndex stateInfoIndex, mecanim::statemachine::StateMachineMemory const& mem)
{
    switch (stateInfoIndex)
    {
        case kCurrentState:     return mem.m_CurrentStateIndex;
        case kExitState:        return mem.m_ExitStateIndex;
        case kNextState:        return mem.m_InTransition ? mem.m_NextStateIndex : std::numeric_limits<mecanim::uint32_t>::max();
        case kInterruptedState: return mem.m_InterruptedStateIndex;
        default:                return std::numeric_limits<mecanim::uint32_t>::max();
    }
}

static inline float GetStatePreviousTime(StateInfoIndex stateInfoIndex, mecanim::statemachine::StateMachineMemory const& mem)
{
    switch (stateInfoIndex)
    {
        case kCurrentState:     return mem.m_CurrentStatePreviousTime;
        case kExitState:        return mem.m_ExitStatePreviousTime;
        case kNextState:        return mem.m_NextStatePreviousTime;
        case kInterruptedState: return mem.m_InterruptedStatePreviousTime;
        default:                return 0.0f;
    }
}

static inline float GetStateDuration(StateInfoIndex stateInfoIndex, mecanim::statemachine::StateMachineMemory const& mem)
{
    switch (stateInfoIndex)
    {
        case kCurrentState:     return mem.m_CurrentStateDuration;
        case kExitState:        return mem.m_ExitStateDuration;
        case kNextState:        return mem.m_NextStateDuration;
        case kInterruptedState: return mem.m_InterruptedStateDuration;
        default:                return 0.0f;
    }
}

static inline float GetStateSpeedModifier(StateInfoIndex stateInfoIndex, mecanim::statemachine::StateMachineMemory const& mem)
{
    switch (stateInfoIndex)
    {
        case kCurrentState:     return mem.m_CurrentStateSpeedModifier;
        case kExitState:        return mem.m_ExitStateSpeedModifier;
        case kNextState:        return mem.m_NextStateSpeedModifier;
        case kInterruptedState: return mem.m_InterruptedStateSpeedModifier;
        default:                return 0.0f;
    }
}

bool AnimatorControllerPlayable::GetAnimatorStateInfo(int layerIndex, StateInfoIndex stateInfoIndex, AnimatorStateInfo& output) const
{
    if (!ValidateLayerIndex(layerIndex))
        return false;

    mecanim::statemachine::StateMachineConstant const& stateMachineConst    = *GetStateMachineConstant(layerIndex);
    mecanim::statemachine::StateMachineMemory const& stateMachineMem        = *GetStateMachineMemory(layerIndex);

    mecanim::uint32_t stateIndex = GetStateIndex(stateInfoIndex, stateMachineMem);

    if (stateIndex < stateMachineConst.m_StateConstantCount)
    {
        output.nameHash         = stateMachineConst.m_StateConstantArray[stateIndex]->m_NameID;
        output.pathHash         = stateMachineConst.m_StateConstantArray[stateIndex]->m_PathID;
        output.fullPathHash     = stateMachineConst.m_StateConstantArray[stateIndex]->m_FullPathID;
        output.normalizedTime   = GetStatePreviousTime(stateInfoIndex, stateMachineMem);
        output.length           = GetStateDuration(stateInfoIndex, stateMachineMem);
        output.tagHash          = stateMachineConst.m_StateConstantArray[stateIndex]->m_TagID;
        output.loop             = stateMachineConst.m_StateConstantArray[stateIndex]->m_Loop ? 1 : 0;
        output.speed            = stateMachineConst.m_StateConstantArray[stateIndex]->m_Speed;
        output.speedMultiplier  = GetStateSpeedModifier(stateInfoIndex, stateMachineMem);

        return true;
    }
    else
        return false;
}

bool AnimatorControllerPlayable::GetAnimatorTransitionInfo(int layerIndex, AnimatorTransitionInfo& info) const
{
    if (!ValidateLayerIndex(layerIndex))
        return false;

    const mecanim::statemachine::StateMachineConstant* apStateMachineConst = GetStateMachineConstant(layerIndex);
    mecanim::statemachine::StateMachineMemory const* apStateMachineMem = GetStateMachineMemory(layerIndex);

    if (apStateMachineMem->m_InTransition)
    {
        mecanim::statemachine::TransitionConstant const* transition  = mecanim::statemachine::GetTransitionConstant(apStateMachineConst, apStateMachineMem);
        if (transition)
        {
            info.fullPathHash = transition->m_FullPathID;
            info.userNameHash = transition->m_UserID;
            info.nameHash = transition->m_ID;
            info.anyState = mecanim::statemachine::IsCurrentTransitionAnyState(apStateMachineMem);
            info.transitionType = apStateMachineMem->m_TransitionType;
        }
        // Dynamic transition doesn't exist, they are created on demand by user.
        else
        {
            info.fullPathHash = 0;
            info.userNameHash = 0;
            info.nameHash = 0;
            info.anyState = true;
            info.transitionType = 0;
        }
        info.normalizedTime = apStateMachineMem->m_TransitionTime;
        return true;
    }
    else
    {
        return false;
    }
}

bool AnimatorControllerPlayable::HasState(int layerIndex, int stateID) const
{
    if (!ValidateLayerIndex(layerIndex))
        return false;

    const mecanim::statemachine::StateMachineConstant* apStateMachineConst = GetStateMachineConstant(layerIndex);
    for (mecanim::uint32_t stateIndex = 0; stateIndex < apStateMachineConst->m_StateConstantCount; ++stateIndex)
    {
        if (apStateMachineConst->m_StateConstantArray[stateIndex]->m_FullPathID  == stateID ||
            apStateMachineConst->m_StateConstantArray[stateIndex]->m_PathID     == stateID ||
            apStateMachineConst->m_StateConstantArray[stateIndex]->m_NameID     == stateID)
            return true;
    }

    return false;
}

core::string AnimatorControllerPlayable::GetAnimatorStateName(int layerIndex, bool currentState)
{
    if (!ValidateLayerIndex(layerIndex))
        return "";

    const mecanim::statemachine::StateMachineConstant* apStateMachineConst = GetStateMachineConstant(layerIndex);
    mecanim::statemachine::StateMachineMemory const* apStateMachineMem =  GetStateMachineMemory(layerIndex);

    mecanim::uint32_t stateIndex = currentState ? apStateMachineMem->m_CurrentStateIndex : apStateMachineMem->m_InTransition ? apStateMachineMem->m_NextStateIndex : apStateMachineConst->m_StateConstantCount;
    if (stateIndex < apStateMachineConst->m_StateConstantCount)
    {
        return m_AnimatorController->StringFromID(apStateMachineConst->m_StateConstantArray[stateIndex]->m_PathID);
    }

    return "";
}

core::string AnimatorControllerPlayable::ResolveHash(int hash)
{
    if (m_AnimatorController == NULL)
        return "";

    return m_AnimatorController->StringFromID(hash);
}

bool GetLayerAndStateIndex(mecanim::animation::ControllerConstant const* controllerConstant, mecanim::uint32_t id, int* outLayer, int* outStateIndex)
{
    for (int i = 0; i < (int)controllerConstant->m_LayerCount; i++)
    {
        int index = controllerConstant->m_LayerArray[i]->m_StateMachineIndex;

        // Ignore synced layers
        if (controllerConstant->m_LayerArray[i]->m_StateMachineMotionSetIndex != 0)
            continue;

        mecanim::int32_t stateIndex = mecanim::statemachine::GetStateIndex(controllerConstant->m_StateMachineArray[index].Get(), id);
        if (stateIndex != -1)
        {
            *outStateIndex = stateIndex;
            *outLayer = i;
            return true;
        }
    }
    return false;
}

bool AnimatorControllerPlayable::ValidateGoToState(int& layerIndex, int& stateId) const
{
    if (!IsInitialized() || m_AnimatorControllerMemory.m_ControllerConstant == NULL)
        return false;

    const mecanim::animation::ControllerConstant* controllerConstant = m_AnimatorControllerMemory.m_ControllerConstant;
    // Automatically find a good layer index
    if (layerIndex == -1)
    {
        int stateIndex;
        // StateId = 0 means active state
        if (stateId == 0)
            layerIndex = 0;
        else if (!GetLayerAndStateIndex(controllerConstant, stateId, &layerIndex, &stateIndex))
        {
            WarningString("Animator.GotoState: State could not be found");
        }
    }

    if (!ValidateLayerIndex(layerIndex))
        return false;

    const mecanim::uint32_t stateMachineIndex = controllerConstant->m_LayerArray[layerIndex]->m_StateMachineIndex;

    if (stateMachineIndex == 0xffffffff)
        return false;

    if (stateMachineIndex >= controllerConstant->m_StateMachineCount)
    {
        WarningString("Animator.GotoState: Cannot find statemachine");
        return false;
    }

    const mecanim::uint32_t motionSetIndex = controllerConstant->m_LayerArray[layerIndex]->m_StateMachineMotionSetIndex;
    if (motionSetIndex != 0)
    {
        WarningString("Calling Animator.GotoState on Synchronize layer");
        return false;
    }

#if DEBUGMODE
    if (stateId != 0 && mecanim::statemachine::GetStateIndex(controllerConstant->m_StateMachineArray[stateMachineIndex].Get(), stateId) == -1)
    {
        WarningString("Animator.GotoState: State could not be found");
    }
#endif

    return true;
}

void AnimatorControllerPlayable::GotoStateInternal(int layerIndex, int stateId, float time, float duration, float transitionTime, bool isFixedtime)
{
    if (!ValidateGoToState(layerIndex, stateId))
        return;

    const mecanim::animation::ControllerConstant* controllerConstant = m_AnimatorControllerMemory.m_ControllerConstant;

    // When no explicit normalizedTime is specified we will simply start the clip at the start if it is not already playing.
    if (time == -std::numeric_limits<float>::infinity())
    {
        time = 0.0F;

        if (!IsInTransitionInternal(layerIndex))
        {
            AnimatorStateInfo info;
            GetAnimatorStateInfo(layerIndex, kCurrentState, info);

            // If the state is not currently playing -> Start Playing it
            bool nameMatches = info.fullPathHash == stateId || info.pathHash == stateId || info.nameHash == stateId;
            if (nameMatches)
                return;
        }
    }

    const mecanim::uint32_t stateMachineIndex = controllerConstant->m_LayerArray[layerIndex]->m_StateMachineIndex;
    m_AnimatorControllerMemory.m_ControllerMemory->m_StateMachineMemory[stateMachineIndex]->m_ActiveGotoState = true;

    mecanim::animation::ControllerInput* controllerInput = m_AnimatorControllerMemory.m_ControllerInput;
    controllerInput->m_GotoStateInfos[layerIndex].m_StateID = stateId;
    controllerInput->m_GotoStateInfos[layerIndex].m_FixedTransition = isFixedtime;
    controllerInput->m_GotoStateInfos[layerIndex].m_NormalizedTime = isFixedtime ? 0.0f : time;
    controllerInput->m_GotoStateInfos[layerIndex].m_DenormalizedTimeOffset = isFixedtime ? time : 0.0f;
    controllerInput->m_GotoStateInfos[layerIndex].m_TransitionDuration = duration;

    controllerInput->m_GotoStateInfos[layerIndex].m_TransitionTime = transitionTime;
}

void AnimatorControllerPlayable::GotoStateInFixedTime(int layerIndex, int stateId, float fixedTime, float fixedTransitionDuration, float normalizedTransitionTime)
{
    GotoStateInternal(layerIndex, stateId, fixedTime, fixedTransitionDuration, normalizedTransitionTime, true);
}

void AnimatorControllerPlayable::GotoState(int layerIndex, int stateId, float normalizedTime, float transitionDuration, float transitionTime)
{
    GotoStateInternal(layerIndex, stateId, normalizedTime, transitionDuration, transitionTime, false);
}

const mecanim::statemachine::StateMachineConstant* AnimatorControllerPlayable::GetStateMachineConstant(int layerIndex) const
{
    const mecanim::animation::ControllerConstant* controllerConstant = m_AnimatorControllerMemory.m_ControllerConstant;
    if (!controllerConstant)
        return 0;

    return controllerConstant->m_StateMachineArray[controllerConstant->m_LayerArray[layerIndex]->m_StateMachineIndex].Get();
}

const mecanim::statemachine::StateMachineMemory* AnimatorControllerPlayable::GetStateMachineMemory(int layerIndex) const
{
    const mecanim::animation::ControllerConstant* controllerConstant = m_AnimatorControllerMemory.m_ControllerConstant;
    const mecanim::animation::ControllerMemory* controllerMemory = m_AnimatorControllerMemory.m_ControllerMemory;

    return controllerMemory->m_StateMachineMemory[controllerConstant->m_LayerArray[layerIndex]->m_StateMachineIndex].Get();
}

StateMachineBehaviourVector const*  AnimatorControllerPlayable::GetStateMachineBehaviours() const
{
    return &m_StateMachineBehaviours;
}

StateMachineBehaviourVectorDescription const* AnimatorControllerPlayable::GetStateMachineBehaviourVectorDescription() const
{
    return &m_AnimatorController->GetStateMachineBehaviourVectorDescription();
}

MonoBehaviour* AnimatorControllerPlayable::GetBehaviour(ScriptingClassPtr type)
{
    StateMachineBehaviourVector::iterator it;
    for (it = m_StateMachineBehaviours.begin(); it != m_StateMachineBehaviours.end(); ++it)
    {
        PPtr<MonoBehaviour> behaviour = *it;
        if (behaviour.IsNull())
            continue;

        ScriptingClassPtr klass = behaviour->GetClass();
        if (klass == SCRIPTING_NULL)
            continue;

        if (type == klass)
            return (MonoBehaviour*)behaviour;
        else if (scripting_class_is_subclass_of(klass, type))
            return (MonoBehaviour*)behaviour;
    }
    return NULL;
}

StateMachineBehaviourVector AnimatorControllerPlayable::GetBehaviours(ScriptingClassPtr type)
{
    StateMachineBehaviourVector behaviours;

    StateMachineBehaviourVector::iterator it;

    for (it = m_StateMachineBehaviours.begin(); it != m_StateMachineBehaviours.end(); ++it)
    {
        PPtr<MonoBehaviour> behaviour = *it;
        if (behaviour.IsNull() || behaviour->GetClass() == SCRIPTING_NULL)
            continue;

        if (type == behaviour->GetClass())
            behaviours.push_back(behaviour);
        else if (scripting_class_is_subclass_of(behaviour->GetClass(), type))
            behaviours.push_back(behaviour);
    }

    return behaviours;
}

void BindAdditionalCurves(mecanim::ValueArrayConstant const &valueConstant, size_t genericBindingsSize, UnityEngine::Animation::GenericBinding const *genericBindings, mecanim::int32_t *additionalIndexArray)
{
    for (size_t genericIter = 0; genericIter < genericBindingsSize; genericIter++)
    {
        if (genericBindings[genericIter].GetType() ==  TypeOf<Animator>())
        {
            mecanim::int32_t valueIndex = mecanim::FindValueIndex(&valueConstant, mecanim::uint32_t(genericBindings[genericIter].attribute));

            if (valueIndex != -1)
            {
                additionalIndexArray[valueIndex] =  genericIter;
            }
        }
    }
}

void AnimatorControllerPlayable::PrepareAnimationEvents(float weight, AnimationClipEventInfos& eventInfos)
{
    const mecanim::animation::ControllerConstant* constant = m_AnimatorControllerMemory.m_ControllerConstant;
    if (constant == 0)
        return;

    for (int layerIndex = 0; layerIndex < constant->m_LayerCount; ++layerIndex)
    {
        AnimationStateMachineMixerPlayable* stateMachineMixer = GetStateMachineMixer(layerIndex);
        const uint32_t stateMachineIndex = m_AnimatorControllerMemory.m_ControllerConstant->m_LayerArray[layerIndex]->m_StateMachineIndex;
        const mecanim::statemachine::StateMachineOutput* stateMachineOutput = m_AnimatorControllerMemory.m_ControllerWorkspace->m_StateMachineOutput[stateMachineIndex];

        const AnimationLayerMixerPlayable* layerMixerPlayable = static_cast<AnimationLayerMixerPlayable*>(m_Connections->m_Inputs[0].playable);
        const float layerWeight = layerMixerPlayable->GetLayerWeight(layerIndex);

        if (layerWeight == 0)
            continue;

        for (int currentNext = 0; currentNext < 2; ++currentNext)
        {
            bool current = currentNext == 0;

            if (current && stateMachineMixer->IsInInterruptedTransition())
                continue;

            AnimationMixerPlayable *stateMixer = stateMachineMixer->GetStateMixerPlayable(current);

            const float transitionWeight = stateMachineMixer->GetInputWeight(currentNext);

            const InputConnections& inputs = stateMixer->GetInputs();
            uint32_t childCount = inputs.size();

            mecanim::statemachine::StateMachineMessage stateMessage = current ? stateMachineOutput->m_CurrentStateMessage : stateMachineOutput->m_NextStateMessage;
            bool isExitingState = FilteredMessageId(stateMessage, mecanim::statemachine::kOnStateExit) == mecanim::statemachine::kOnStateExit;
            bool isEnteringState = FilteredMessageId(stateMessage, mecanim::statemachine::kOnStateEnter) == mecanim::statemachine::kOnStateEnter;

            for (uint32_t child = 0; child < childCount - 1; ++child)
            {
                const float mixerWeight = stateMixer->GetInputWeight(child);

                if (mixerWeight == 0)
                    continue;

                const float cummulativeWeight = weight * layerWeight * transitionWeight * mixerWeight;
                if (cummulativeWeight == 0 && !isExitingState && !isEnteringState)
                    continue;

                AnimationPlayable* animationClipPlayable = static_cast<AnimationPlayable*>(inputs[child].playable);
                if (animationClipPlayable)
                {
                    animationClipPlayable->PrepareAnimationEvents(cummulativeWeight, eventInfos);
                }
            }
        }
    }
}
