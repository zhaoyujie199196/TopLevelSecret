#include "UnityPrefix.h"
#include "Runtime/Animation/Director/AnimationPosePlayable.h"

#include "Runtime/mecanim/animation/avatar.h"
#include "Runtime/mecanim/generic/valuearray.h"


AnimationPosePlayable::AnimationPosePlayable(DirectorPlayerType playerType) : AnimationPlayable(playerType)
    , m_MustReadPreviousPose(false), m_ApplyFootIK(false)
{
#if ANIMATION_PLAYABLE_SANITY_CHECK
    m_Type = eAnimationPosePlayable;
#endif
}

void AnimationPosePlayable::AllocateBindings(AnimationPlayableEvaluationConstant const *constant)
{
    if (!m_BindingsAllocated)
    {
        m_AnimationNodeState = mecanim::animation::CreateAnimationNodeState(*constant->values, constant->hasRootMotion, constant->isHuman, constant->affectMassCenter, m_Allocator);
    }

    AnimationPlayable::AllocateBindings(constant);
}

void AnimationPosePlayable::DeallocateBindings()
{
    if (m_BindingsAllocated)
    {
        mecanim::animation::DestroyAnimationNodeState(m_AnimationNodeState, m_Allocator);
        m_AnimationNodeState = NULL;
    }
    AnimationPlayable::DeallocateBindings();
}

void AnimationPosePlayable::ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    bool hasRootMotion = constant->hasRootMotion;
    bool isHuman = constant->isHuman;

    mecanim::animation::CopyAnimationNodeState(m_AnimationNodeState, output->nodeStateOutput, hasRootMotion, isHuman, *input->humanPoseMask);

    output->nodeStateOutput->m_MotionReadMask = hasRootMotion;
    output->nodeStateOutput->m_HumanReadMask = isHuman;

    if (isHuman)
        output->m_IKOnFeet = m_ApplyFootIK;
}

void AnimationPosePlayable::PreProcessAnimation(AnimationPlayableEvaluationConstant const *constant, mecanim::animation::AnimationNodeState const* state)
{
    if (MustReadPreviousPose())
    {
        mecanim::animation::CopyAnimationNodeState(state, m_AnimationNodeState, constant->hasRootMotion, constant->isHuman, mecanim::human::FullBodyMask());
        SetMustReadPreviousPose(false);
    }

    AnimationPlayable::PreProcessAnimation(constant, state);
}
