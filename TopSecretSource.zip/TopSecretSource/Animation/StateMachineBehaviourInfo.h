#ifndef STATEMACHINEBEHAVIOURINFO_H
#define STATEMACHINEBEHAVIOURINFO_H


#include "Runtime/BaseClasses/NamedObject.h"
#include "Runtime/Serialize/SerializeTraits.h"

#include "Runtime/Scripting/ScriptingTypes.h"
#include "Runtime/Mono/MonoBehaviour.h"
#include "Runtime/mecanim/types.h"

struct StateKey
{
public:
    DEFINE_GET_TYPESTRING(StateKey)

    StateKey() : m_StateID(0), m_LayerIndex(-1) {}
    StateKey(mecanim::uint32_t stateID, mecanim::int32_t  layerIndex) : m_StateID(stateID), m_LayerIndex(layerIndex) {}

    mecanim::uint32_t m_StateID;
    mecanim::int32_t  m_LayerIndex;

    template<class TransferFunction>
    void Transfer(TransferFunction& transfer)
    {
        TRANSFER(m_StateID);
        TRANSFER(m_LayerIndex);
    }

    bool operator<(StateKey const& key) const{ return m_StateID != key.m_StateID ? m_StateID < key.m_StateID : m_LayerIndex < key.m_LayerIndex; }
};

struct StateRange
{
public:
    DEFINE_GET_TYPESTRING(StateRange)

    StateRange() : m_StartIndex(0), m_Count(0) {}
    StateRange(mecanim::uint32_t startIndex, mecanim::uint32_t count) : m_StartIndex(startIndex), m_Count(count) {}

    mecanim::uint32_t GetStartIndex() const {return m_StartIndex; }
    mecanim::uint32_t GetStopIndex() const {return m_StartIndex + m_Count; }

    template<class TransferFunction>
    void Transfer(TransferFunction& transfer)
    {
        TRANSFER(m_StartIndex);
        TRANSFER(m_Count);
    }

protected:
    mecanim::uint32_t m_StartIndex;
    mecanim::uint32_t m_Count;
};

typedef dynamic_array<PPtr<MonoBehaviour> >    StateMachineBehaviourVector;
typedef vector_map<StateKey, StateRange>        StateMachineBehaviourRanges;
typedef dynamic_array<mecanim::uint32_t>        StateMachineBehaviourIndices;


struct StateMachineBehaviourVectorDescription
{
    DEFINE_GET_TYPESTRING(StateMachineBehaviourVectorDescription)

    StateMachineBehaviourRanges             m_StateMachineBehaviourRanges;
    StateMachineBehaviourIndices            m_StateMachineBehaviourIndices;

    void Clear()
    {
        m_StateMachineBehaviourRanges.clear();
        m_StateMachineBehaviourIndices.clear();
    }

    template<class TransferFunction>
    void Transfer(TransferFunction& transfer)
    {
        TRANSFER(m_StateMachineBehaviourRanges);
        TRANSFER(m_StateMachineBehaviourIndices);
    }
};

struct HasInvalidBehaviourPredicate
{
    bool operator()(PPtr<MonoBehaviour> const& behaviour);
};

#endif
