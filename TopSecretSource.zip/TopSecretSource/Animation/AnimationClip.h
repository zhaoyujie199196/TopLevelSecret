#ifndef ANIMATIONCLIP_H
#define ANIMATIONCLIP_H

#include "Runtime/BaseClasses/NamedObject.h"
#include "Runtime/Serialize/SerializeTraits.h"
#include "Runtime/Utilities/LinkedList.h"
#include "Runtime/Math/Quaternion.h"
#include "Runtime/Math/Vector2.h"
#include "Runtime/Geometry/AABB.h"
#include "Runtime/Math/AnimationCurve.h"
#include "AnimationEvent.h"
#include "Runtime/Mono/MonoScript.h"
#include "Runtime/mecanim/memory.h"
#include "AnimationClipBindings.h"
#include "PPtrKeyframes.h"
#include "Runtime/mecanim/statemachine/statemachinemessage.h"

#include "Motion.h"

#if UNITY_EDITOR
#include "AnimationClipSettings.h"
#endif

namespace mecanim
{
namespace animation
{
    struct ClipMuscleConstant;
    struct ClipBindings;
    struct ClipMemory;
}
}

class Animation;
class AnimationClip;
struct AnimatorClipInfo;
struct AnimationClipStats;
class AnimationState;
struct AnimatorStateInfo;
class BaseAnimationTrack;
class CompressedAnimationCurve;
class GameObject;
class MonoScript;
class NewAnimationTrack;
struct AnimationClipEventInfo;

DECLARE_MESSAGE_IDENTIFIER(kDidModifyMotion);
DECLARE_MESSAGE_IDENTIFIER(kDidDeleteMotion);

typedef dynamic_array<PPtr<AnimationClip> > AnimationClipPPtrVector;
/*
    TODO:
    * We currently don't handle double cover operator automatically for rotation curves
    * We are not synchronizing animation state cached range correctly
    * GetCurve is not implemented yet
*/

class AnimationClip : public Motion
{
    REGISTER_CLASS(AnimationClip);
    DECLARE_OBJECT_SERIALIZE();
public:
    struct QuaternionCurve
    {
        core::string path;
        AnimationCurveQuat curve;
        int            hash;

        QuaternionCurve() { hash = 0; }
        void CopyWithoutCurve(QuaternionCurve& other) const
        {
            other.path = path;
            other.hash = hash;
        }

        DECLARE_SERIALIZE(QuaternionCurve)
    };

    struct Vector3Curve
    {
        core::string path;
        AnimationCurveVec3 curve;
        int            hash;

        Vector3Curve() { hash = 0; }
        void CopyWithoutCurve(Vector3Curve& other) const
        {
            other.path = path;
            other.hash = hash;
        }

        DECLARE_SERIALIZE(Vector3Curve)
    };

public:


    struct PPtrCurve
    {
        core::string        path;
        core::string        attribute;
        const Unity::Type* type;
        MonoScriptPPtr  script;
        PPtrKeyframes   curve;

        PPtrCurve() {}

        DECLARE_SERIALIZE(PPtrCurve)
    };

    struct FloatCurve
    {
        core::string path;
        core::string attribute;
        const Unity::Type* type;
        MonoScriptPPtr script;
        AnimationCurve curve;
        int            hash;

        FloatCurve() { hash = 0; }
        void CopyWithoutCurve(FloatCurve& other) const
        {
            other.path = path;
            other.attribute = attribute;
            other.type = type;
            other.script = script;
            other.hash = hash;
        }

        DECLARE_SERIALIZE(FloatCurve)
    };

    typedef UNITY_VECTOR (kMemAnimation, QuaternionCurve) QuaternionCurves;
    typedef UNITY_VECTOR (kMemAnimation, CompressedAnimationCurve) CompressedQuaternionCurves;
    typedef UNITY_VECTOR (kMemAnimation, Vector3Curve) Vector3Curves;
    typedef UNITY_VECTOR (kMemAnimation, FloatCurve) FloatCurves;
    typedef UNITY_VECTOR (kMemAnimation, PPtrCurve) PPtrCurves;


    static void InitializeClass();
    static void CleanupClass() {}

    AnimationClip(MemLabelId label, ObjectCreationMode mode);
    // virtual ~AnimationClip(); declared-by-macro

    virtual void MainThreadCleanup();

    virtual void AwakeFromLoad(AwakeFromLoadMode mode);
    virtual void CheckConsistency();
    virtual void SetName(char const* name);


    /// Assigns curve to the curve defined by path, classID and attribute
    /// If curve is null the exisiting curve will be removed.
    void SetCurve(const core::string& path, const Unity::Type* type, MonoScriptPPtr script, const core::string& attribute, AnimationCurve* curve, bool syncEditorCurves, bool updateClipSettings = true);
    bool GetCurve(const core::string& path, const Unity::Type* type, MonoScriptPPtr script, const core::string& attribute, AnimationCurve* outCurve);

    void ClearCurves();
    void EnsureQuaternionContinuity();

    bool HasAnimationEvents() const { return m_Events.size() > 0; }
    void FireAnimationEvents(AnimationClipEventInfo* info, Unity::Component& source);

#if UNITY_EDITOR
    void                            SetEditorCurve(const core::string& path, const Unity::Type* type, MonoScriptPPtr script, const core::string& attribute, const AnimationCurve* curve, bool syncEditorCurves = true);
    bool                            GetEditorCurve(const core::string& path, const Unity::Type* type, MonoScriptPPtr script, const core::string& attribute, AnimationCurve* outCurve);
    FloatCurves&                    GetEditorCurvesSync();

    void                            SetEditorPPtrCurve(const core::string& path, const Unity::Type* type, MonoScriptPPtr script, const core::string& attribute, PPtrKeyframes* keyframes);
    bool                            GetEditorPPtrCurve(const core::string& path, const Unity::Type* type, MonoScriptPPtr script, const core::string& attribute, PPtrKeyframes* outKeyframes);
    PPtrCurves&                     GetEditorPPtrCurves() { return m_PPtrCurves; }

    // Callback for telling animation window when an animclip got reloaded
    typedef void                    OnAnimationClipAwake (AnimationClip* clip);
    static void                     SetOnAnimationClipAwake(OnAnimationClipAwake *callback);

    void                            SyncEditorCurves();
    void                            SyncMuscleCurvesBackwardCompatibility();

    void                            SetEvents(const AnimationEvent* events, int size, bool sort = false);
    void                            ClearEvents();
    FloatCurves&                    GetEulerEditorCurves()                                              { return m_EulerEditorCurves; }
    virtual void                    CloneAdditionalEditorProperties(const Object& src);
    FloatCurves&                    GetEditorCurvesNoConversion()                                      { return m_EditorCurves; }


    const AnimationClipSettings&    GetAnimationClipSettings() const                                    { return m_AnimationClipSettings; }
    void                            SetAnimationClipSettingsNoDirty(AnimationClipSettings &clipInfo);
    void                            SetAnimationClipSettings(const AnimationClipSettings&clipInfo)     { m_AnimationClipSettings = clipInfo; SetDirty(); }

    void                            GenerateMuscleClip();

    void                            SetAdditiveReferencePose(AnimationClip const* clip, float time);
private:
    bool                            IsValidAdditiveReferenceClip(AnimationClip const* clip);
#endif
public:
    // overloads from Motion
    virtual float                   GetAverageDuration() const;
    virtual float                   GetAverageAngularSpeed() const;
    virtual Vector3f                GetAverageSpeed() const;
    virtual float                   GetApparentSpeed() const;

    virtual bool                    IsLooping() const;


    void                    SetLegacy(bool legacy);

    // Returns the smallest and largest keyframe time of any channel in the animation
    // if no keyframes are contained make_pair (infinity, -infinity) is returned
    std::pair<float, float> GetRange();

    float GetLength();

    // Animation State support
    typedef List<ListNode<AnimationState> > AnimationStateList;
    typedef void DidModifyClipCallback (AnimationClip* clip, AnimationStateList& states);

    static void SetDidModifyClipCallback(DidModifyClipCallback* callback);
    void AddAnimationState(ListNode<AnimationState>& node) { m_AnimationStates.push_back(node); }

    void SetSampleRate(float s);
    float GetSampleRate() { return m_SampleRate; }

    void SetCompressionEnabled(bool s) { m_Compressed = s; }
    bool GetCompressionEnabled() { return m_Compressed; }
#if UNITY_EDITOR
    void SetUseHighQualityCurve(bool s) { m_UseHighQualityCurve = s; }
    bool GetUseHighQualityCurve() const { return m_UseHighQualityCurve; }
#endif
    void SetWrapMode(WrapMode wrap) { m_WrapMode = wrap; SetDirty(); }
    WrapMode GetWrapMode() { return m_WrapMode; }

    AnimationEvents& GetEvents() { return m_Events; }
    void AddRuntimeEvent(AnimationEvent& event);
    void SetRuntimeEvents(const AnimationEvents& events);

    void AddQuaternionCurve(const AnimationCurveQuat& quat, const core::string& path);
    void AddEulerCurve(const AnimationCurveVec3& euler, const core::string& path);
    void AddPositionCurve(const AnimationCurveVec3& pos, const core::string& path);
    void AddScaleCurve(const AnimationCurveVec3& scal, const core::string& path);
    void AddFloatCurve(const AnimationCurve& curve, const core::string& path, const Unity::Type* type, const core::string& attribute);

    QuaternionCurves& GetQuaternionCurves() { return m_QuaternionCurves; }
    Vector3Curves& GetEulerCurves() { return m_EulerCurves; }
    Vector3Curves& GetPositionCurves() { return m_PositionCurves; }
    Vector3Curves& GetScaleCurves() { return m_ScaleCurves; }
    FloatCurves& GetFloatCurves() { return m_FloatCurves; }

    const QuaternionCurves& GetQuaternionCurves() const { return m_QuaternionCurves; }
    const Vector3Curves& GetEulerCurves() const { return m_EulerCurves; }
    const Vector3Curves& GetPositionCurves() const { return m_PositionCurves; }
    const Vector3Curves& GetScaleCurves() const { return m_ScaleCurves; }
    const FloatCurves& GetFloatCurves() const { return m_FloatCurves; }

    void SetBounds(const AABB& bounds) { m_Bounds = bounds; SetDirty(); }
    const AABB& GetBounds() const { return m_Bounds; }

    static void RevertAllPlaymodeAnimationEvents();

    virtual bool IsHumanMotion() const;

#if UNITY_EDITOR
    bool GetGenerateMotionCurves() { return m_GenerateMotionCurves; }
    void SetGenerateMotionCurves(bool value);
    bool HasGenericRootTransform();
    bool HasMotionFloatCurves();
    bool HasMotionCurves();
    bool HasRootCurves();
    void BuildMecanimDataMainThread();
#endif

    virtual AnimationClipPPtrVector GetAnimationClips() const;

    bool IsLegacy() const { return m_Legacy; }

    ::UnityEngine::Animation::AnimationClipBindingConstant* GetBindingConstant() { return &m_ClipBindingConstant; }

    bool MecanimDataWasBuilt() const;
    bool IsMecanimDataValid() const;
    mecanim::animation::ClipMuscleConstant* GetRuntimeAsset();

    void GetStats(AnimationClipStats& stats);

    void ClipWasModifiedAndUpdateClipSettings();
    void ClipWasModifiedAndUpdateMuscleRange();
    void UpdateMuscleClipRange();

    bool IsEmpty() const;

private:
    void CompressCurves(CompressedQuaternionCurves& compressedRotationCurves);
    void DecompressCurves(CompressedQuaternionCurves& compressedRotationCurves);

    void ClipWasModified(bool cleanupMecanimData = true);

    void ReloadEditorEulerCurves(const core::string& path, const Unity::Type* type);
    void ReloadEditorEulerCurvesRaw(const core::string& path, const Unity::Type* type);
    void ReloadEditorQuaternionCurves(const core::string& path, const Unity::Type* type);

    void ConvertToNewCurveFormat(NewAnimationTrack& curves, const Unity::Type* type, const core::string& path);
    void ConvertToNewCurveFormat();

    void CleanupMecanimData();

    void ClearCachedRange();

    mecanim::memory::ChainedAllocator                   m_ClipAllocator;

private:
    AnimationStateList m_AnimationStates;

    float           m_SampleRate;
    bool            m_Compressed;
    bool            m_UseHighQualityCurve;
    WrapMode        m_WrapMode;///< enum { Default = 0, Once = 1, Loop = 2, PingPong = 4, ClampForever = 8 }

    QuaternionCurves    m_QuaternionCurves;
    Vector3Curves       m_EulerCurves;
    Vector3Curves       m_PositionCurves;
    Vector3Curves       m_ScaleCurves;
    FloatCurves         m_FloatCurves;
    PPtrCurves          m_PPtrCurves;
    AnimationEvents     m_Events;
    bool                m_Legacy;

#if UNITY_EDITOR
    AnimationClipSettings m_AnimationClipSettings;
    bool m_HasGenericRootTransform;
    bool m_HasMotionFloatCurves;
    bool m_GenerateMotionCurves;
#endif//#if UNITY_EDITOR

    mecanim::animation::ClipMuscleConstant*     m_MuscleClip;
    mecanim::uint32_t                           m_MuscleClipSize;
    ::UnityEngine::Animation::AnimationClipBindingConstant m_ClipBindingConstant;

    /// TODO: Serialiaze and do not compute it at all on startup
    std::pair<float, float> m_CachedRange;

    bool IsEulerFromQuaternion(const Unity::Type* type, const core::string& path,  const core::string& attribute);

    AABB m_Bounds;

    #if UNITY_EDITOR

    // Keep a copy of events setup from edit mode so we can safely revert events after playmode
    AnimationEvents     m_EditModeEvents;
    FloatCurves         m_EditorCurves;
    FloatCurves         m_EulerEditorCurves;

    struct ChildTrack
    {
        core::string path;
        const Unity::Type* type;
        PPtr<BaseAnimationTrack> track;
        DECLARE_SERIALIZE(ChildTrack)
    };

    typedef vector_map<const Unity::Type*, PPtr<BaseAnimationTrack> > TypeToTrack;
    typedef TypeToTrack::iterator iterator;
    typedef std::vector<ChildTrack> ChildTracks;
    typedef ChildTracks::iterator child_iterator;

    TypeToTrack     m_TypeToTrack;
    ChildTracks     m_ChildTracks;

    friend class StripCurvesForMecanimClips;

    #endif

    friend class AnimationManager;
};


#if UNITY_EDITOR

// We use this in the editor for the preview animation clip to ensure
// that they cannot be mixed up with normal animation clips
class PreviewAnimationClip : public AnimationClip
{
    REGISTER_CLASS(PreviewAnimationClip);
    DECLARE_OBJECT_SERIALIZE();
public:
    PreviewAnimationClip(MemLabelId label, ObjectCreationMode mode) : AnimationClip(label, mode) {}
};

bool IsAnimationClip(int instanceID);
#endif

#endif
