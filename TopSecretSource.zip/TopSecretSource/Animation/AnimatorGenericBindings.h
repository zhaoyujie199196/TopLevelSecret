#pragma once

#include <limits>
#include "Runtime/Transform/Transform.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/mecanim/animation/avatar.h"
#include "Runtime/mecanim/generic/valuearray.h"
#include "Runtime/mecanim/skeleton/skeleton.h"

typedef UInt32 BindingHash;

class GameObject;

namespace mecanim
{
namespace animation
{
    struct AvatarConstant;
    struct ControllerConstant;
    struct ControllerBindingConstant;
    struct AnimationClipOffset;
}
}

class Animator;

namespace UnityEngine
{
namespace Animation
{
    struct AnimationClipBindingConstant;
    struct AnimationSetBindings;
    struct BoundCurve;


    struct ExposedTransform
    {
        Transform*          transform;
        int                 skeletonIndex;
        int                 skeletonIndexForUpdateTransform;
    };

    struct AvatarBindingConstant
    {
        // For non-optimized mode (the Transform hierarchy is there)
        size_t        skeletonBindingsCount;
        Transform**   skeletonBindings;

        int           transformChangedMask;
        InstanceID    animatorInstanceId;


        // For optimized mode
        size_t              exposedTransformCount;
        ExposedTransform*   exposedTransforms;

        mecanim::skeleton::SkeletonPose*    defaultSkeletonPose;
    };

    struct AnimatorGenericBindingConstant
    {
        AnimatorGenericBindingConstant()
        {}

        size_t              transformBindingsCount;
        BoundCurve*         transformBindings;

        size_t              genericBindingsCount;
        BoundCurve*         genericBindings;

        size_t              genericPPtrBindingsCount;
        BoundCurve*         genericPPtrBindings;

        UInt8*              exposedTransformScaleChangedArray;

        int                 transformChangedMask;

        mecanim::animation::ControllerBindingConstant*  controllerBindingConstant;

        bool                allowConstantClipSamplingOptimization;

        int                 rootPositionValueIndex;
        int                 rootRotationValueIndex;
        int                 rootScaleValueIndex;
    };

    AvatarBindingConstant* CreateAvatarBindingConstant(Transform& root, const mecanim::animation::AvatarConstant* avatar, mecanim::memory::Allocator& allocator);
    AvatarBindingConstant* CreateAvatarBindingConstantOpt(Transform& root, const mecanim::animation::AvatarConstant* avatar, mecanim::memory::Allocator& allocator);
    void DestroyAvatarBindingConstant(AvatarBindingConstant* bindingConstant, mecanim::memory::Allocator& allocator);

    /// Bind multiple animation clips against a GameObject
    /// outputCurveIndexToBindingIndex is an array of arrays that remaps from the curve index of each clip into the bound curves array
    /// returns a binding constant.
    AnimatorGenericBindingConstant* CreateAnimatorGenericBindings(const AnimationSetBindings& animationSet, Transform& root, const mecanim::animation::AvatarConstant* avatar, bool allowConstantClipSamplingOptimization, mecanim::memory::Allocator& allocator, Animator& animator);
    AnimatorGenericBindingConstant* CreateAnimatorGenericBindingsOpt(const AnimationSetBindings& animationSet, Transform& root, const mecanim::animation::AvatarConstant* avatar, const AvatarBindingConstant* avatarBinding, bool allowConstantClipSamplingOptimization, mecanim::memory::Allocator& allocator, Animator& animator);
    void DestroyAnimatorGenericBindings(AnimatorGenericBindingConstant* bindingConstant, mecanim::memory::Allocator& allocator);

    mecanim::animation::SkeletonTQSMap *CreateAvatarTQSMap(const mecanim::animation::AvatarConstant* avatar, const AnimationSetBindings& animationSet, mecanim::memory::Allocator& allocator);

    /// Batch assign an array of values to the bound locations (Also calls AwakeFromLoad)
    /// Must always be called from the main thread
    void SetGenericFloatPropertyValues(const AnimatorGenericBindingConstant& bindings, const mecanim::ValueArray& values);
    void SetGenericPPtrPropertyValues(const AnimatorGenericBindingConstant& bindings, const mecanim::ValueArray& values);

    //  bool HasAnyGenericProperties (const AnimatorGenericBindingConstant& bindings);

    // We set job fences on all Transforms that can be written to
    // This way data will only be read when the job completes.
    //  void SetJobFencesForAnimatorBindings (const AnimatorGenericBindingConstant& genericBindings, const AvatarBindingConstant& avatarBindings, const JobFence& fence);

    /// Retrun true if root has generic transform property bindings
    bool HasGenericRootTransformPropertyValues(const AnimatorGenericBindingConstant& bindings, bool scaleOnly);

    /// assign transform properties to root Transform
    /// Can be invoked from another thread if we are sure no one will delete Transforms at the same time on another thread.
    void SetGenericRootTransformPropertyValues(const AnimatorGenericBindingConstant& bindings, const mecanim::ValueArray &values, Transform &rootTransform, bool scaleOnly, bool animatePhysics);

    /// Batch assign transform properties to the bound Transform components
    /// Can be invoked from another thread if we are sure no one will delete Transforms at the same time on another thread.
    void SetGenericTransformPropertyValues(const AnimatorGenericBindingConstant& bindings, const mecanim::ValueArray& values, Transform *skipTransform, bool animatePhysics);
    void SetHumanTransformPropertyValues(const AvatarBindingConstant& bindings, const mecanim::skeleton::SkeletonPose& pose, bool skipRoot = true, bool animatePhysics = false);

    void GetHumanTransformPropertyValues(const AvatarBindingConstant& bindings, mecanim::skeleton::SkeletonPose& pose);

    /// @TODO: Should be deprecated with new job fence system
    void SetTransformPropertyApplyMainThread(Transform& root, const AnimatorGenericBindingConstant& bindings, const AvatarBindingConstant& avatarBindings, bool animatePhysics);
    void SetFlattenedSkeletonTransformsMainThread(Transform& root, const AvatarBindingConstant& avatarBinding, bool animatePhysics);

    void UnregisterAvatarBindingObjects(AvatarBindingConstant* bindingConstant);
    void UnregisterGenericBindingObjects(AnimatorGenericBindingConstant* bindingConstant);
}
}
