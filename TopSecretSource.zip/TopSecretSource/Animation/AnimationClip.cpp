#include "UnityPrefix.h"
#include "AnimationClip.h"
#include "NewAnimationTrack.h"
#include "Runtime/Math/AnimationCurveUtility.h"
#include "Runtime/Serialize/TransferFunctions/TransferNameConversions.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Graphics/Mesh/CompressedMesh.h"
#include "Runtime/mecanim/generic/stringtable.h"
#include "Runtime/mecanim/generic/crc32.h"
#include "GenericAnimationBindingCache.h"
#include "Animator.h"
#include "AnimationClipStats.h"
#include "MecanimClipBuilder.h"
#include "MecanimUtility.h"
#include "Runtime/Utilities/algorithm_utility.h"
#include "Runtime/Serialize/PersistentManager.h"
#include "Runtime/BaseClasses/TypeInfo.h"


#if UNITY_EDITOR
#include "KeyframeReducer.h"
#include "Runtime/BaseClasses/IsPlaying.h"
#endif

using namespace UnityEngine::Animation;

DEFINE_MESSAGE_IDENTIFIER(kDidModifyMotion, ("OnDidModifyMotion", MessageIdentifier::kDontSendToScripts));
DEFINE_MESSAGE_IDENTIFIER(kDidDeleteMotion, ("OnDidDeleteMotion", MessageIdentifier::kDontSendToScripts));

static AnimationClip::DidModifyClipCallback* gDidModifyClipCallback = NULL;

#if UNITY_EDITOR
static AnimationClip::OnAnimationClipAwake* gOnAnimationClipAwake = NULL;
void AnimationClip::SetOnAnimationClipAwake(OnAnimationClipAwake* callback)
{
    gOnAnimationClipAwake = callback;
}

bool IsAnimationClip(int instanceID)
{
    return GetTypeWithoutLoadingObject(instanceID) == TypeOf<AnimationClip>();
}

void InitClipMuscleAdditivePose(mecanim::animation::ClipMuscleConstant& constant, mecanim::animation::ClipMuscleConstant& additiveConstant, UnityEngine::Animation::AnimationSetBindings* clipsBindings, float time, mecanim::memory::Allocator& allocator)
{
    mecanim::animation::ClipBindings& clipBindings = clipsBindings->animationSet->m_ClipConstant[0].m_Bindings;
    mecanim::animation::ClipBindings& additiveReferenceClipBindings = clipsBindings->animationSet->m_ClipConstant[1].m_Bindings;

    mecanim::memory::MecanimAllocator tempAllocator(kMemTempAlloc);

    mecanim::animation::ClipInput in;
    mecanim::animation::ClipOutput *out = mecanim::animation::CreateClipOutput(additiveConstant.m_Clip.Get(), tempAllocator);
    mecanim::animation::ClipMemory *mem = mecanim::animation::CreateClipMemory(additiveConstant.m_Clip.Get(), tempAllocator);

    in.m_Time = time;
    EvaluateClip(additiveConstant.m_Clip.Get(), &in, mem, out);

    mecanim::ValueArray *values = CreateValueArray(clipsBindings->animationSet->m_DynamicFullValuesConstant, tempAllocator);

    constant.m_ValueArrayReferencePoseCount = constant.m_ValueArrayCount;
    constant.m_ValueArrayReferencePose = allocator.ConstructArray<float>(constant.m_ValueArrayReferencePoseCount);

    mecanim::uint32_t valueIndex;
    if (clipBindings.m_PositionIndex != NULL && additiveReferenceClipBindings.m_PositionIndex != NULL)
    {
        for (valueIndex = 0; valueIndex < values->m_PositionCount; valueIndex++)
        {
            int dstIndex = clipBindings.m_PositionIndex[valueIndex];
            int srcIndex = additiveReferenceClipBindings.m_PositionIndex[valueIndex];


            if (dstIndex != -1 && srcIndex != -1)
            {
                constant.m_ValueArrayReferencePose[dstIndex + 0] = out->m_Values[srcIndex + 0];
                constant.m_ValueArrayReferencePose[dstIndex + 1] = out->m_Values[srcIndex + 1];
                constant.m_ValueArrayReferencePose[dstIndex + 2] = out->m_Values[srcIndex + 2];
            }
        }
    }

    if (clipBindings.m_QuaternionIndex != NULL && additiveReferenceClipBindings.m_QuaternionIndex != NULL)
    {
        for (valueIndex = 0; valueIndex < values->m_QuaternionCount; valueIndex++)
        {
            int dstIndex = -1;
            int srcIndex = -1;

            int dstQuatCurveIndex = clipBindings.m_QuaternionIndex[valueIndex];
            int dstEulerCurveIndex = clipBindings.m_EulerIndex[valueIndex];
            int srcQuatCurveIndex = additiveReferenceClipBindings.m_QuaternionIndex[valueIndex];
            int srcEulerCurveIndex = additiveReferenceClipBindings.m_EulerIndex[valueIndex];

            if ((dstQuatCurveIndex != -1 && dstEulerCurveIndex != -1) || (srcQuatCurveIndex != -1 && srcEulerCurveIndex != -1))
            {
                continue;
            }
            else if (dstQuatCurveIndex != -1 && srcQuatCurveIndex != -1)
            {
                dstIndex = clipBindings.m_QuaternionIndex[valueIndex];
                srcIndex = additiveReferenceClipBindings.m_QuaternionIndex[valueIndex];

                constant.m_ValueArrayReferencePose[dstIndex + 0] = out->m_Values[srcIndex + 0];
                constant.m_ValueArrayReferencePose[dstIndex + 1] = out->m_Values[srcIndex + 1];
                constant.m_ValueArrayReferencePose[dstIndex + 2] = out->m_Values[srcIndex + 2];
                constant.m_ValueArrayReferencePose[dstIndex + 3] = out->m_Values[srcIndex + 3];
            }
            else if (dstEulerCurveIndex != -1 && srcEulerCurveIndex != -1)
            {
                dstIndex = clipBindings.m_EulerIndex[valueIndex];
                srcIndex = additiveReferenceClipBindings.m_EulerIndex[valueIndex];

                constant.m_ValueArrayReferencePose[dstIndex + 0] = out->m_Values[srcIndex + 0];
                constant.m_ValueArrayReferencePose[dstIndex + 1] = out->m_Values[srcIndex + 1];
                constant.m_ValueArrayReferencePose[dstIndex + 2] = out->m_Values[srcIndex + 2];
            }
            else if (dstEulerCurveIndex != -1 && srcQuatCurveIndex != -1)
            {
                dstIndex = clipBindings.m_EulerIndex[valueIndex];
                srcIndex = additiveReferenceClipBindings.m_QuaternionIndex[valueIndex];

                math::float4 inValue = math::vload4f(&out->m_Values[srcIndex + 0]);
                math::float3 outEuler = quatToEuler(inValue, static_cast<math::RotationOrder>(clipBindings.m_EulerOrder[valueIndex]));

                math::vstore3f(&constant.m_ValueArrayReferencePose[dstIndex + 0], outEuler);
            }
            else if (dstQuatCurveIndex != -1 && srcEulerCurveIndex != -1)
            {
                dstIndex = clipBindings.m_QuaternionIndex[valueIndex];
                srcIndex = additiveReferenceClipBindings.m_EulerIndex[valueIndex];

                math::float3 inValue = math::vload3f(&out->m_Values[srcIndex + 0]);
                math::float4 outQuat = eulerToQuat(inValue, static_cast<math::RotationOrder>(additiveReferenceClipBindings.m_EulerOrder[valueIndex]));

                math::vstore4f(&constant.m_ValueArrayReferencePose[dstIndex + 0], outQuat);
            }
        }
    }

    if (clipBindings.m_ScaleIndex != NULL && additiveReferenceClipBindings.m_ScaleIndex != NULL)
    {
        for (valueIndex = 0; valueIndex < values->m_ScaleCount; valueIndex++)
        {
            int dstIndex = clipBindings.m_ScaleIndex[valueIndex];
            int srcIndex = additiveReferenceClipBindings.m_ScaleIndex[valueIndex];
            if (dstIndex != -1 && srcIndex != -1)
            {
                constant.m_ValueArrayReferencePose[dstIndex + 0] = out->m_Values[srcIndex + 0];
                constant.m_ValueArrayReferencePose[dstIndex + 1] = out->m_Values[srcIndex + 1];
                constant.m_ValueArrayReferencePose[dstIndex + 2] = out->m_Values[srcIndex + 2];
            }
        }
    }

    if (clipBindings.m_FloatIndex != NULL && additiveReferenceClipBindings.m_FloatIndex != NULL)
    {
        for (valueIndex = 0; valueIndex < values->m_FloatCount; valueIndex++)
        {
            int dstIndex = clipBindings.m_FloatIndex[valueIndex];
            int srcIndex = additiveReferenceClipBindings.m_FloatIndex[valueIndex];
            if (dstIndex != -1 && srcIndex != -1)
                constant.m_ValueArrayReferencePose[dstIndex] = out->m_Values[srcIndex];
        }
    }

    for (mecanim::int32_t muscleIter = 0; muscleIter < mecanim::animation::s_ClipMuscleCurveCount; muscleIter++)
    {
        int dstIndex = constant.m_IndexArray[muscleIter];
        int srcIndex = additiveConstant.m_IndexArray[muscleIter];
        if (dstIndex != -1 && srcIndex != -1)
            constant.m_ValueArrayReferencePose[dstIndex] = out->m_Values[srcIndex];
    }

    DestroyValueArray(values, tempAllocator);
    DestroyClipOutput(out, tempAllocator);
    DestroyClipMemory(mem, tempAllocator);
}

void PatchMuscleClipWithInfo(AnimationClip* animationClip, const AnimationClipSettings& clipInfo, bool isHumanoid, mecanim::animation::ClipMuscleConstant *cst, mecanim::memory::Allocator& allocator)
{
    Assert(animationClip->MecanimDataWasBuilt());

    cst->m_StartTime = clipInfo.m_StartTime;
    cst->m_StopTime = clipInfo.m_StopTime;
    cst->m_OrientationOffsetY = clipInfo.m_OrientationOffsetY;
    cst->m_Level = clipInfo.m_Level;
    cst->m_CycleOffset = clipInfo.m_CycleOffset;
    cst->m_LoopTime = clipInfo.m_LoopTime;
    cst->m_LoopBlend = clipInfo.m_LoopBlend;
    cst->m_LoopBlendOrientation = clipInfo.m_LoopBlendOrientation;
    cst->m_LoopBlendPositionY = clipInfo.m_LoopBlendPositionY;
    cst->m_LoopBlendPositionXZ = clipInfo.m_LoopBlendPositionXZ;
    cst->m_KeepOriginalOrientation = clipInfo.m_KeepOriginalOrientation;
    cst->m_KeepOriginalPositionY = clipInfo.m_KeepOriginalPositionY;
    cst->m_KeepOriginalPositionXZ = clipInfo.m_KeepOriginalPositionXZ;
    cst->m_HeightFromFeet = clipInfo.m_HeightFromFeet;
    cst->m_Mirror = clipInfo.m_Mirror;

    mecanim::animation::InitClipMuscleDeltaValues(*cst, isHumanoid);
    mecanim::animation::InitClipMuscleAverageSpeed(*cst);

    if (clipInfo.m_HasAdditiveReferencePose && !clipInfo.m_AdditiveReferencePoseClip.IsNull())
    {
        clipInfo.m_AdditiveReferencePoseClip->BuildMecanimDataMainThread();
        mecanim::animation::ClipMuscleConstant *additiveClip = clipInfo.m_AdditiveReferencePoseClip->GetRuntimeAsset();

        mecanim::memory::MecanimAllocator tempAllocator(kMemAnimation);

        AnimationClips clips(kMemTempAlloc);
        clips.push_back(animationClip);
        clips.push_back(clipInfo.m_AdditiveReferencePoseClip);

        UnityEngine::Animation::AnimationSetBindings* clipBindings = UnityEngine::Animation::CreateAnimationSetBindings(clips, tempAllocator);

        if (additiveClip != NULL)
            InitClipMuscleAdditivePose(*cst, *additiveClip, clipBindings, clipInfo.m_AdditiveReferencePoseTime, allocator);

        DestroyAnimationSetBindings(clipBindings, tempAllocator);
    }
}

void CstToAnimationClipSettings(mecanim::animation::ClipMuscleConstant const *cst, AnimationClipSettings &clipInfo)
{
    clipInfo.m_StartTime = cst->m_StartTime;
    clipInfo.m_StopTime = cst->m_StopTime;
    clipInfo.m_OrientationOffsetY = cst->m_OrientationOffsetY;
    clipInfo.m_Level = cst->m_Level;
    clipInfo.m_CycleOffset = cst->m_CycleOffset;
    clipInfo.m_LoopTime = cst->m_LoopTime;
    clipInfo.m_LoopBlend = cst->m_LoopBlend;
    clipInfo.m_LoopBlendOrientation = cst->m_LoopBlendOrientation;
    clipInfo.m_LoopBlendPositionY = cst->m_LoopBlendPositionY;
    clipInfo.m_LoopBlendPositionXZ = cst->m_LoopBlendPositionXZ;
    clipInfo.m_KeepOriginalOrientation = cst->m_KeepOriginalOrientation;
    clipInfo.m_KeepOriginalPositionY = cst->m_KeepOriginalPositionY;
    clipInfo.m_KeepOriginalPositionXZ = cst->m_KeepOriginalPositionXZ;
    clipInfo.m_HeightFromFeet = cst->m_HeightFromFeet;
    clipInfo.m_Mirror = cst->m_Mirror;
}

#endif

AnimationClip::AnimationClip(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
    , m_ClipAllocator(label, 4 * 1024)
    , m_UseHighQualityCurve(true)
    , m_Legacy(false)
    , m_MuscleClip(0)
    , m_MuscleClipSize(0)
    , m_Bounds(Vector3f::zero, Vector3f::zero)
    , m_QuaternionCurves()
    , m_PositionCurves()
    , m_ScaleCurves()
    , m_FloatCurves()
    , m_PPtrCurves()
    , m_Events()
#if UNITY_EDITOR
    , m_EditModeEvents()
    , m_EditorCurves()
    , m_EulerEditorCurves()
#endif
{
    m_SampleRate = 60.0F;
    m_Compressed = false;
    m_WrapMode = kWrapModeDefault;

#if UNITY_EDITOR
    m_HasGenericRootTransform = false;
    m_HasMotionFloatCurves = false;
    m_GenerateMotionCurves = false;
#endif
}

void AnimationClip::AwakeFromLoad(AwakeFromLoadMode mode)
{
    Super::AwakeFromLoad(mode);

    #if UNITY_EDITOR

    ConvertToNewCurveFormat();
    if (gOnAnimationClipAwake)
        gOnAnimationClipAwake(this);

    if (mode & kDidLoadFromDisk)
    {
        if (IsMecanimDataValid())
        {
            // case 476382, need to populate m_AnimationClipSettings manually because it is not transfer for game release asset
            CstToAnimationClipSettings(m_MuscleClip, m_AnimationClipSettings);
        }
        else
        {
            // When loading scenes etc it's a good idea not to have the hiccups all on first access
            BuildMecanimDataMainThread();
        }
    }
    else
    {
        CleanupMecanimData();
    }

    #endif

    ClipWasModified(false);
}

void AnimationClip::ClipWasModifiedAndUpdateClipSettings()
{
    ClipWasModified();
#if UNITY_EDITOR
    std::pair<float, float> range = GetRange();
    AnimationClipSettings clipInfo = GetAnimationClipSettings();
    clipInfo.m_StartTime = 0.0F;
    clipInfo.m_StopTime = range.second;
    m_AnimationClipSettings = clipInfo;
#endif
}

void AnimationClip::ClipWasModifiedAndUpdateMuscleRange()
{
    ClipWasModified();
    UpdateMuscleClipRange();
}

void AnimationClip::UpdateMuscleClipRange()
{
#if UNITY_EDITOR
    ClearCachedRange();
    std::pair<float, float> range = GetRange();

    AnimationClipSettings settings = GetAnimationClipSettings();
    settings.m_StartTime = 0.0F;
    settings.m_StopTime = range.second;

    SetAnimationClipSettingsNoDirty(settings);
#endif
}

void AnimationClip::SetSampleRate(float s)
{
    if (s < 1e-5f)
    {
        LogStringObject("Framerate of 0 or less is not allowed", this);
        return;
    }

    m_SampleRate = s;

#if UNITY_EDITOR
    // case 591793: rebake euler with new sample rate.
    bool needsResync = false;
    for (FloatCurves::iterator i = m_EulerEditorCurves.begin(); i != m_EulerEditorCurves.end(); i++)
    {
        if (BeginsWith(i->attribute, "localEulerAnglesBaked"))
        {
            ReloadEditorQuaternionCurves(i->path, i->type);
            needsResync = true;
        }
    }
    if (needsResync)
        SyncEditorCurves();
#endif

    // Stop time depends on the sample rate
    // because we add an extra frame at the end to cover pptr curves
    ClipWasModifiedAndUpdateMuscleRange();
    SetDirty();
}

void AnimationClip::CheckConsistency()
{
    Super::CheckConsistency();
}

void AnimationClip::SetName(char const* name)
{
    core::string previousName = GetName();
    Super::SetName(name);
    if (previousName != name)
    {
        NotifyObjectUsers(kDidModifyMotion);
    }
}

void AnimationClip::ClipWasModified(bool cleanupMecanimData)
{
    if (cleanupMecanimData)
        CleanupMecanimData();

    NotifyObjectUsers(kDidModifyMotion);

    ClearCachedRange();
    if (gDidModifyClipCallback)
        gDidModifyClipCallback(this, m_AnimationStates);
}

void AnimationClip::ClearCurves()
{
    m_QuaternionCurves.clear();
    m_EulerCurves.clear();
    m_PositionCurves.clear();
    m_ScaleCurves.clear();
    m_FloatCurves.clear();
    m_PPtrCurves.clear();
    #if UNITY_EDITOR
    m_EditorCurves.clear();
    m_EulerEditorCurves.clear();
    #endif

    ClipWasModifiedAndUpdateMuscleRange();
    SetDirty();
}

void AnimationClip::EnsureQuaternionContinuity()
{
    for (QuaternionCurves::iterator i = m_QuaternionCurves.begin(); i != m_QuaternionCurves.end(); i++)
        ::EnsureQuaternionContinuityAndRecalculateSlope(i->curve);

    if (gDidModifyClipCallback)
        gDidModifyClipCallback(this, m_AnimationStates);
    SetDirty();
}

void  AnimationClip::FireAnimationEvents(AnimationClipEventInfo* info, Unity::Component& source)
{
    AnimationEvents& events = GetEvents();
    Assert(!events.empty());

    float lastTime  = info->m_LastTime;
    float now = info->m_CurrenTime;
    AnimatorStateInfo* animatorStateInfo =  &info->m_StateInfo;
    AnimatorClipInfo* animatorClipInfo = &info->m_ClipInfo;
    bool reverse = math::chgsign(1.0f, info->m_PlaybackSpeed) < 0;


    if (lastTime == now)
        return;

    int eventCount = events.size();


    // Simple forward playback.
    if (!reverse && lastTime < now)
    {
        const float duration = GetAverageDuration();
        int loopNeeded = ((now >= duration && IsLooping() && duration != 0)) ? math::floor(now / duration) + 1 : 1;

        for (int loop = 0; loop < loopNeeded; ++loop)
        {
            for (int eventIter = 0; eventIter < eventCount; eventIter++)
            {
                // Dont loop starting events when m_LoopLastTime is false. Only happens on the last loop
                if (!info->m_LoopLastTime && loopNeeded > 1 && loop == loopNeeded - 1 && events[eventIter].time == 0.0f)
                    continue;

                float unrolledEventTime = events[eventIter].time + (loop * duration);
                if (lastTime < unrolledEventTime && now >= unrolledEventTime)
                    FireEvent(events[eventIter], source, 0, animatorStateInfo, animatorClipInfo);

                if (now < unrolledEventTime)
                    break;
            }
        }
    }
    else if (now < lastTime)
    {
        const float duration = GetAverageDuration();
        int loopNeeded = (now >= duration && IsLooping()) ? math::floor(now / GetAverageDuration()) + 1 : 1;

        for (int loop = 0; loop < loopNeeded; ++loop)
        {
            // Play all events that
            for (int eventIter = eventCount - 1; eventIter >= 0; eventIter--)
            {
                float unrolledEventTime = events[eventIter].time - (loop * duration);

                if (lastTime > unrolledEventTime && now <= unrolledEventTime)
                    FireEvent(events[eventIter], source, 0, animatorStateInfo, animatorClipInfo);

                if (now >= unrolledEventTime)
                    break;
            }
        }
    }
}

struct EventSorter
{
    bool operator()(const AnimationEvent& ra, const AnimationEvent& rb) const
    {
        return ra.time < rb.time;
    }
};

static void SortEvents(AnimationEvents& events)
{
    std::sort(events.begin(), events.end(), EventSorter());
}

#if UNITY_EDITOR
void AnimationClip::ReloadEditorEulerCurves(const core::string& path, const Unity::Type* type)
{
    SET_ALLOC_OWNER(this);
    // Find the euler curves we will use to build the quaternion curves
    AnimationCurve* curves[4] = { NULL, NULL, NULL, NULL };
    for (FloatCurves::iterator i = m_EditorCurves.begin(); i != m_EditorCurves.end(); i++)
    {
        if (BeginsWith(i->attribute, "m_LocalRotation") && i->path == path)
        {
            char last = i->attribute[i->attribute.size() - 1];
            if (last == 'x')
                curves[0] = &i->curve;
            else if (last == 'y')
                curves[1] = &i->curve;
            else if (last == 'z')
                curves[2] = &i->curve;
            else if (last == 'w')
                curves[3] = &i->curve;
            else
            {
                ErrorString("Can't set curve because " + i->attribute + " is not a valid Transform property.");
                continue;
            }
        }
    }

    // Remove existing euler curves at path
    for (int i = 0; i != m_EulerEditorCurves.size(); i++)
    {
        if (m_EulerEditorCurves[i].type == type && m_EulerEditorCurves[i].path == path)
        {
            m_EulerEditorCurves[i] = m_EulerEditorCurves.back();
            m_EulerEditorCurves.resize(m_EulerEditorCurves.size() - 1);
            i--;
        }
    }

    if (curves[0] && curves[1] && curves[2] && curves[3])
    {
        // Create combined quaternion curve

        AnimationCurveQuat quatCurve;
        CombineCurve(*curves[0], 0, quatCurve, Zero<Quaternionf>());
        CombineCurve(*curves[1], 1, quatCurve, Zero<Quaternionf>());
        CombineCurve(*curves[2], 2, quatCurve, Zero<Quaternionf>());
        CombineCurve(*curves[3], 3, quatCurve, Zero<Quaternionf>());

        // Create euler curves
        FloatCurve curve;
        curve.path = path;
        curve.type = type;
        int first = m_EulerEditorCurves.size();
        curve.attribute = "localEulerAngles.x";
        m_EulerEditorCurves.push_back(curve);
        curve.attribute = "localEulerAngles.y";
        m_EulerEditorCurves.push_back(curve);
        curve.attribute = "localEulerAngles.z";
        m_EulerEditorCurves.push_back(curve);
        AnimationCurve* eulerCurves[3] = { &m_EulerEditorCurves[first].curve, &m_EulerEditorCurves[first + 1].curve, &m_EulerEditorCurves[first + 2].curve };

        QuaternionCurveToEulerCurve(quatCurve, eulerCurves);
    }
}

struct IsQuaternionTransformAtPath
{
    IsQuaternionTransformAtPath(const core::string& path, const Unity::Type* type) : m_Path(path), m_Type(type)
    {
    }

    bool operator()(AnimationClip::FloatCurve& curve) { return curve.type == m_Type && BeginsWith(curve.attribute, "m_LocalRotation") && curve.path == m_Path; }

    core::string m_Path;
    const Unity::Type* m_Type;
};

void AnimationClip::ReloadEditorEulerCurvesRaw(const core::string& path, const Unity::Type* type)
{
    SET_ALLOC_OWNER(this);

    // Find the euler curves we will use to build the quaternion curves
    AnimationCurve* curves[3] = { NULL, NULL, NULL };
    for (FloatCurves::iterator i = m_EditorCurves.begin(); i != m_EditorCurves.end(); i++)
    {
        char last = i->attribute[i->attribute.size() - 1];

        bool isEuler = BeginsWith(i->attribute, "m_LocalEulerAnglesRaw") || BeginsWith(i->attribute, "localEulerAnglesRaw");
        if (isEuler && i->path == path)
        {
            if (last == 'x')
                curves[0] = &i->curve;
            else if (last == 'y')
                curves[1] = &i->curve;
            else if (last == 'z')
                curves[2] = &i->curve;
            else
            {
                ErrorString("Can't set curve because " + i->attribute + " is not a valid Transform property.");
                continue;
            }
        }
    }

    // Remove existing euler curves at path
    for (int i = 0; i != m_EulerEditorCurves.size(); i++)
    {
        if (m_EulerEditorCurves[i].type == type && m_EulerEditorCurves[i].path == path)
        {
            m_EulerEditorCurves[i] = m_EulerEditorCurves.back();
            m_EulerEditorCurves.resize(m_EulerEditorCurves.size() - 1);
            i--;
        }
    }

    // If all 3 euler curves exist, add the euler editor curve
    if (curves[0] && curves[1] && curves[2])
    {
        // Create temporary quaternion curve
        AnimationCurveVec3 eulerCurve;

        // Create quaternion editor curves from single quaternion curve
        FloatCurve curve;
        curve.path = path;
        curve.type = type;

        curve.attribute = "m_LocalEulerAngles.x";
        m_EulerEditorCurves.push_back(curve);
        curve.attribute = "m_LocalEulerAngles.y";
        m_EulerEditorCurves.push_back(curve);
        curve.attribute = "m_LocalEulerAngles.z";
        m_EulerEditorCurves.push_back(curve);
    }
}

void AnimationClip::ReloadEditorQuaternionCurves(const core::string& path, const Unity::Type* type)
{
    SET_ALLOC_OWNER(this);
    int bakedEulerCurves = -1;

    // Find the euler curves we will use to build the quaternion curves
    AnimationCurve* curves[3] = { NULL, NULL, NULL };
    for (FloatCurves::iterator i = m_EulerEditorCurves.begin(); i != m_EulerEditorCurves.end(); i++)
    {
        char last = i->attribute[i->attribute.size() - 1];

        if (i->path == path)
        {
            DebugAssert(BeginsWith(i->attribute, "localEulerAngles") || BeginsWith(i->attribute, "m_LocalEulerAngles"));
            int curBaked = BeginsWith(i->attribute, "localEulerAnglesBaked") ||  BeginsWith(i->attribute, "m_LocalEulerAnglesBaked");
            if (bakedEulerCurves != -1 && bakedEulerCurves != curBaked)
            {
                ErrorString("localEulerAnglesBaked and localEulerAngles exist at the same time. Please ensure that there is always only one curve type in use on a single transform.");
                continue;
            }

            bakedEulerCurves = curBaked;

            if (last == 'x')
                curves[0] = &i->curve;
            else if (last == 'y')
                curves[1] = &i->curve;
            else if (last == 'z')
                curves[2] = &i->curve;
            else
            {
                ErrorString("Can't set curve because " + i->attribute + " is not a valid Transform property.");
                continue;
            }
        }
    }

    // Remove existing quaternion curves at path
    erase_if(m_EditorCurves, IsQuaternionTransformAtPath(path, type));

    // If all 3 euler curves exist, add the quaternion editor curve
    if (curves[0] && curves[1] && curves[2])
    {
        // Create temporary quaternion curve
        AnimationCurveQuat quatCurve;

        // TODO : these both should use tangents or fitting
        if (bakedEulerCurves)
            EulerToQuaternionCurveBake(*curves[0], *curves[1], *curves[2], quatCurve, GetSampleRate());
        else
            EulerToQuaternionCurve(*curves[0], *curves[1], *curves[2], quatCurve);

        // Create quaternion editor curves from single quaternion curve
        FloatCurve curve;
        curve.path = path;
        curve.type = type;

        int first = m_EditorCurves.size();
        curve.attribute = "m_LocalRotation.x";
        m_EditorCurves.push_back(curve);
        curve.attribute = "m_LocalRotation.y";
        m_EditorCurves.push_back(curve);
        curve.attribute = "m_LocalRotation.z";
        m_EditorCurves.push_back(curve);
        curve.attribute = "m_LocalRotation.w";
        m_EditorCurves.push_back(curve);

        AnimationCurve* quaternionCurves[4] = { &m_EditorCurves[first].curve, &m_EditorCurves[first + 1].curve, &m_EditorCurves[first + 2].curve, &m_EditorCurves[first + 3].curve };
        ExpandQuaternionCurve(quatCurve, quaternionCurves);
    }
}

bool AnimationClip::IsEulerFromQuaternion(const Unity::Type* type, const core::string& path, const core::string& attribute)
{
    if (!type->IsDerivedFrom<Transform>())
        return false;

    if (BeginsWith(attribute, "localEulerAnglesBaked"))
        return true;

    if (BeginsWith(attribute, "localEulerAnglesRaw"))
        return false;

    const bool isLocalEulerAngles = BeginsWith(attribute, "localEulerAngles") ||  BeginsWith(attribute, "m_LocalEulerAngles");

    if (isLocalEulerAngles)
        return true;


    return false;
}

void AnimationClip::SetEditorCurve(const core::string& path, const Unity::Type* type, MonoScriptPPtr script, const core::string& attribute, const AnimationCurve* curve, bool syncEditorCurves)
{
    SET_ALLOC_OWNER(this);
    GetEditorCurvesSync();
    const bool isRotation = BeginsWith(attribute, "m_LocalRotation") || BeginsWith(attribute, "localRotation") || BeginsWith(attribute, "m_LocalEuler") || BeginsWith(attribute, "localEulerAngles");
    const bool isEulerFromQuaternion = isRotation && IsEulerFromQuaternion(type, path, attribute);
    const bool isLocalQuaternion = isRotation && !BeginsWith(attribute, "m_LocalEulerAnglesRaw") && !BeginsWith(attribute, "localEulerAnglesRaw");
    FloatCurves* curveArray = &m_EditorCurves;
    if (isEulerFromQuaternion)
        curveArray = &m_EulerEditorCurves;

    // Find existing curve
    FloatCurves::iterator i;
    for (i = curveArray->begin(); i != curveArray->end(); i++)
    {
        if (i->type == type && i->path == path && i->attribute == attribute && i->script == script)
            break;
    }

    // Shall we remove a curve?
    if (curve == NULL)
    {
        if (i != curveArray->end())
        {
            curveArray->erase(i);

            // Modified euler angle curve, reload editor quaternion curves
            if (isEulerFromQuaternion)
                ReloadEditorQuaternionCurves(path, type);
            // Modified quaternion curve, reload editor euler angle curves
            else if (isLocalQuaternion)
                ReloadEditorEulerCurves(path, type);
            else if (isRotation)
                ReloadEditorEulerCurvesRaw(path, type);

            if (syncEditorCurves)
                SyncEditorCurves();
        }
        return;
    }

    // Add or replace the curve
    AnimationCurve* comboCurve = i != curveArray->end() ? &i->curve : NULL;
    if (comboCurve == NULL)
    {
        curveArray->push_back(FloatCurve());
        curveArray->back().path = path;
        curveArray->back().attribute = attribute;
        curveArray->back().type = type;
        curveArray->back().script = script;
        curveArray->back().curve = *curve;
    }
    else
    {
        math::RotationOrder rotationOrder = comboCurve->GetRotationOrder();
        *comboCurve = *curve;
        comboCurve->SetRotationOrder(rotationOrder);
    }

    // Modified euler angle curve, reload editor quaternion curves
    if (isEulerFromQuaternion)
        ReloadEditorQuaternionCurves(path, type);
    // Modified quaternion curve, reload editor euler angle curves
    else if (isLocalQuaternion)
        ReloadEditorEulerCurves(path, type);
    else if (isRotation)
        ReloadEditorEulerCurvesRaw(path, type);

    if (syncEditorCurves)
        SyncEditorCurves();
}

bool AnimationClip::GetEditorCurve(const core::string& path, const Unity::Type* type, MonoScriptPPtr script, const core::string& attribute, AnimationCurve* curve)
{
    GetEditorCurvesSync();

    // Find existing curve
    FloatCurves::iterator i;
    for (i = m_EditorCurves.begin(); i != m_EditorCurves.end(); i++)
    {
        if (i->type == type && i->path == path && i->attribute == attribute && i->script == script)
        {
            if (curve != NULL)
                *curve = i->curve;
            return true;
        }
    }

    // Find existing curve in euler editor curves array
    for (i = m_EulerEditorCurves.begin(); i != m_EulerEditorCurves.end(); i++)
    {
        if (i->type == type && i->path == path && i->attribute == attribute && i->script == script)
        {
            if (curve != NULL)
                *curve = i->curve;
            return true;
        }
    }

    return false;
}

AnimationClip::FloatCurves& AnimationClip::GetEditorCurvesSync()
{
    SET_ALLOC_OWNER(this);
    if (m_EditorCurves.empty() && m_EulerEditorCurves.empty())
    {
        m_EulerEditorCurves.clear();
        m_EditorCurves = m_FloatCurves;

        for (QuaternionCurves::iterator i = m_QuaternionCurves.begin(); i != m_QuaternionCurves.end(); i++)
        {
            FloatCurve curve;
            curve.path = i->path;
            curve.type = TypeOf<Transform>();
            AssertFormatMsg(i->curve.GetKeyCount() >= 2, "Key count: %d on curve '%s'", i->curve.GetKeyCount(), i->path.c_str());

            // Create quaternion curves
            int first = m_EditorCurves.size();
            curve.attribute = "m_LocalRotation.x";
            m_EditorCurves.push_back(curve);
            curve.attribute = "m_LocalRotation.y";
            m_EditorCurves.push_back(curve);
            curve.attribute = "m_LocalRotation.z";
            m_EditorCurves.push_back(curve);
            curve.attribute = "m_LocalRotation.w";
            m_EditorCurves.push_back(curve);

            AnimationCurve* curves[4] = { &m_EditorCurves[first].curve, &m_EditorCurves[first + 1].curve, &m_EditorCurves[first + 2].curve, &m_EditorCurves[first + 3].curve };
            ExpandQuaternionCurve(i->curve, curves);

            // Create euler curves
            first = m_EulerEditorCurves.size();
            curve.attribute = "localEulerAngles.x";
            m_EulerEditorCurves.push_back(curve);
            curve.attribute = "localEulerAngles.y";
            m_EulerEditorCurves.push_back(curve);
            curve.attribute = "localEulerAngles.z";
            m_EulerEditorCurves.push_back(curve);

            AnimationCurve* eulerCurves[3] = { &m_EulerEditorCurves[first].curve, &m_EulerEditorCurves[first + 1].curve, &m_EulerEditorCurves[first + 2].curve };
            QuaternionCurveToEulerCurve(i->curve, eulerCurves);
        }

        for (Vector3Curves::iterator i = m_EulerCurves.begin(); i != m_EulerCurves.end(); i++)
        {
            FloatCurve curve;
            curve.path = i->path;
            curve.type = TypeOf<Transform>();

            int first = m_EditorCurves.size();
            curve.attribute = "localEulerAnglesRaw.x";
            m_EditorCurves.push_back(curve);
            curve.attribute = "localEulerAnglesRaw.y";
            m_EditorCurves.push_back(curve);
            curve.attribute = "localEulerAnglesRaw.z";
            m_EditorCurves.push_back(curve);

            AnimationCurve* curves[3] = { &m_EditorCurves[first].curve, &m_EditorCurves[first + 1].curve, &m_EditorCurves[first + 2].curve };
            ExpandVector3Curve(i->curve, curves);
        }

        for (Vector3Curves::iterator i = m_PositionCurves.begin(); i != m_PositionCurves.end(); i++)
        {
            FloatCurve curve;
            curve.path = i->path;
            curve.type = TypeOf<Transform>();

            int first = m_EditorCurves.size();
            curve.attribute = "m_LocalPosition.x";
            m_EditorCurves.push_back(curve);
            curve.attribute = "m_LocalPosition.y";
            m_EditorCurves.push_back(curve);
            curve.attribute = "m_LocalPosition.z";
            m_EditorCurves.push_back(curve);

            AnimationCurve* curves[3] = { &m_EditorCurves[first].curve, &m_EditorCurves[first + 1].curve, &m_EditorCurves[first + 2].curve };
            ExpandVector3Curve(i->curve, curves);
        }

        // Create scale curves
        for (Vector3Curves::iterator i = m_ScaleCurves.begin(); i != m_ScaleCurves.end(); i++)
        {
            FloatCurve curve;
            curve.path = i->path;
            curve.type = TypeOf<Transform>();

            int first = m_EditorCurves.size();
            curve.attribute = "m_LocalScale.x";
            m_EditorCurves.push_back(curve);
            curve.attribute = "m_LocalScale.y";
            m_EditorCurves.push_back(curve);
            curve.attribute = "m_LocalScale.z";
            m_EditorCurves.push_back(curve);

            AnimationCurve* curves[3] = { &m_EditorCurves[first].curve, &m_EditorCurves[first + 1].curve, &m_EditorCurves[first + 2].curve };
            ExpandVector3Curve(i->curve, curves);
        }
    }
    return m_EditorCurves;
}

void AnimationClip::SyncEditorCurves()
{
    SET_ALLOC_OWNER(this);
    m_QuaternionCurves.clear();
    m_EulerCurves.clear();
    m_PositionCurves.clear();
    m_ScaleCurves.clear();
    m_FloatCurves.clear();

    for (FloatCurves::iterator i = m_EditorCurves.begin(); i != m_EditorCurves.end(); i++)
    {
        SetCurve(i->path, i->type, i->script, i->attribute, &i->curve, false, false);
    }

    ClipWasModifiedAndUpdateMuscleRange();
    SetDirty();
}

struct CurveHasAnimatorAttributePredicate
{
    CurveHasAnimatorAttributePredicate(core::string &attr)  : m_Attribute(attr) {}

    bool operator()(const AnimationClip::FloatCurve &curve)
    {
        return curve.attribute == m_Attribute && curve.type == TypeOf<Animator>();
    }

    core::string& m_Attribute;
};

void AnimationClip::SyncMuscleCurvesBackwardCompatibility()
{
    for (FloatCurves::iterator i = m_EditorCurves.begin(); i != m_EditorCurves.end(); i++)
    {
        if (i->type == TypeOf<Animator>())
        {
            // check if attribute is already in m_FloatCurves, if not add it.
            if (std::find_if(m_FloatCurves.begin(), m_FloatCurves.end(), CurveHasAnimatorAttributePredicate(i->attribute)) == m_FloatCurves.end())
            {
                m_FloatCurves.push_back(FloatCurve());
                m_FloatCurves.back().path = i->path;
                m_FloatCurves.back().attribute = i->attribute;
                m_FloatCurves.back().type = i->type;
                m_FloatCurves.back().script = i->script;
                m_FloatCurves.back().curve = i->curve;
            }
        }
    }
}

void AnimationClip::SetEvents(const AnimationEvent* events, int size, bool sort)
{
    m_Events.assign(events, events + size);
    if (sort)
        SortEvents(m_Events);
    m_EditModeEvents = m_Events;

    ClipWasModifiedAndUpdateMuscleRange();
    SetDirty();
}

void AnimationClip::ClearEvents()
{
    m_Events.clear();
    m_EditModeEvents.clear();

    ClipWasModifiedAndUpdateMuscleRange();
    SetDirty();
}

void AnimationClip::CloneAdditionalEditorProperties(const Object& src)
{
    Super::CloneAdditionalEditorProperties(src);


    m_Events = static_cast<const AnimationClip&>(src).m_Events;
}

void AnimationClip::RevertAllPlaymodeAnimationEvents()
{
    dynamic_array<AnimationClip*> clips(kMemTempAlloc);
    Object::FindObjectsOfType(clips);
    for (size_t i = 0; i < clips.size(); i++)
    {
        AnimationClip& clip = *clips[i];
        if (clip.m_Events.size() != clip.m_EditModeEvents.size())
        {
            clip.m_Events = clip.m_EditModeEvents;
            clip.ClipWasModifiedAndUpdateMuscleRange();
        }
    }
}

#endif


void AnimationClip::SetRuntimeEvents(const AnimationEvents& events)
{
    float oldLength = GetLength();

    m_Events = events;
    SortEvents(m_Events);

    ClearCachedRange();

    // case 789586.  Only invalidate clip if bounds were modified.
    float modifiedLength = GetLength();
    if (fabsf(oldLength - modifiedLength) > kCurveTimeEpsilon
        || IsLegacy())
    {
        NotifyObjectUsers(kDidModifyMotion);
        if (gDidModifyClipCallback)
            gDidModifyClipCallback(this, m_AnimationStates);
    }

#if UNITY_EDITOR
    if (!IsWorldPlaying())
    {
        ErrorString("Please use Editor.AnimationUtility to add persistent animation events to an animation clip");
    }
#endif
}

void AnimationClip::AddRuntimeEvent(AnimationEvent& event)
{
    float oldLength = GetLength();

    AnimationEvents::iterator i = std::lower_bound(m_Events.begin(), m_Events.end(), event);
    m_Events.insert(i, event);

    ClearCachedRange();

    // case 789586.  Only invalidate clip if bounds were modified.
    float modifiedLength = GetLength();
    if (fabsf(oldLength - modifiedLength) > kCurveTimeEpsilon
        || IsLegacy())
    {
        NotifyObjectUsers(kDidModifyMotion);
        if (gDidModifyClipCallback)
            gDidModifyClipCallback(this, m_AnimationStates);
    }

    #if UNITY_EDITOR
    if (!IsWorldPlaying())
    {
        ErrorString("Please use Editor.AnimationUtility to add persistent animation events to an animation clip");
    }
    #endif
}

#if UNITY_EDITOR
bool AnimationClip::GetEditorPPtrCurve(const core::string& path, const Unity::Type* type, MonoScriptPPtr script, const core::string& attribute, PPtrKeyframes* outKeyframes)
{
    PPtrCurves::iterator i;
    for (i = m_PPtrCurves.begin(); i != m_PPtrCurves.end(); ++i)
    {
        if (i->path == path && i->type == type && i->script == script && i->attribute == attribute)
        {
            *outKeyframes = i->curve;
            return true;
        }
    }

    return false;
}

void AnimationClip::SetEditorPPtrCurve(const core::string& path, const Unity::Type* type, MonoScriptPPtr script, const core::string& attribute, PPtrKeyframes* keyframes)
{
    SET_ALLOC_OWNER(this);

    if (type == NULL || !type->IsDerivedFrom<Unity::Component>())
    {
        ErrorString("Can't assign curve because the type does not inherit from Component.");
        return;
    }

    // Find existing curve
    PPtrCurves::iterator i;
    for (i = m_PPtrCurves.begin(); i != m_PPtrCurves.end(); ++i)
    {
        if (i->path == path && i->type == type && i->script == script && i->attribute == attribute)
            break;
    }

    // Shall we remove a curve?
    if (keyframes == NULL)
    {
        if (i != m_PPtrCurves.end())
        {
            m_PPtrCurves.erase(i);
            ClipWasModifiedAndUpdateMuscleRange();
            SetDirty();
        }
        return;
    }

    // Add or replace the curve
    PPtrCurve* comboCurve = (i != m_PPtrCurves.end()) ? &(*i) : NULL;
    if (comboCurve == NULL)
    {
        m_PPtrCurves.push_back(PPtrCurve());
        comboCurve = &m_PPtrCurves.back();
    }

    comboCurve->path = path;
    comboCurve->attribute = attribute;
    comboCurve->type = type;
    comboCurve->script = script;
    comboCurve->curve = *keyframes;

    ClipWasModifiedAndUpdateMuscleRange();
    SetDirty();
}

#endif

bool AnimationClip::GetCurve(const core::string& path, const Unity::Type* type, MonoScriptPPtr script, const core::string& attribute, AnimationCurve* curve)
{
    AnimationCurve dummy0, dummy1, dummy2, dummy3;

    // Get rotation curve
    if (type == TypeOf<Transform>() && BeginsWith(attribute, "m_LocalRotation"))
    {
        // Find existing curve
        QuaternionCurves::iterator i;
        for (i = m_QuaternionCurves.begin(); i != m_QuaternionCurves.end(); i++)
        {
            if (i->path == path)
                break;
        }

        if (i == m_QuaternionCurves.end())
            return false;

        AnimationCurve* curves[4] = { &dummy0, &dummy1, &dummy2, &dummy3 };

        char last = attribute[attribute.size() - 1];
        if (last == 'x')
            curves[0] = curve;
        else if (last == 'y')
            curves[1] = curve;
        else if (last == 'z')
            curves[2] = curve;
        else if (last == 'w')
            curves[3] = curve;
        else
        {
            ErrorString("Can't get curve because " + attribute + " is not a valid Transform property.");
            return false;
        }

        ExpandQuaternionCurve(i->curve, curves);

        return true;
    }
    // Get Local position / local scale curve
    else if (type == TypeOf<Transform>() && (BeginsWith(attribute, "m_LocalPosition") || BeginsWith(attribute, "m_LocalScale")))
    {
        Vector3Curves::iterator i;

        if (BeginsWith(attribute, "m_LocalPosition"))
        {
            // Find existing curve
            for (i = m_PositionCurves.begin(); i != m_PositionCurves.end(); i++)
            {
                if (i->path == path)
                    break;
            }
            if (i == m_PositionCurves.end())
                return false;
        }
        else
        {
            // Find existing curve
            for (i = m_ScaleCurves.begin(); i != m_ScaleCurves.end(); i++)
            {
                if (i->path == path)
                    break;
            }
            if (i == m_ScaleCurves.end())
                return false;
        }


        AnimationCurve* curves[3] = { &dummy0, &dummy1, &dummy2 };

        char last = attribute[attribute.size() - 1];
        if (last == 'x')
            curves[0] = curve;
        else if (last == 'y')
            curves[1] = curve;
        else if (last == 'z')
            curves[2] = curve;
        else
        {
            ErrorString("Can't get curve because " + attribute + " is not a valid Transform property.");
            return false;
        }

        ExpandVector3Curve(i->curve, curves);

        return true;
    }
    // Get any other type of curve
    else
    {
        // Find existing curve
        FloatCurves::iterator i;
        for (i = m_FloatCurves.begin(); i != m_FloatCurves.end(); i++)
        {
            if (type == i->type && i->path == path && i->attribute == attribute && i->script == script)
                break;
        }

        if (i == m_FloatCurves.end())
            return false;

        *curve = i->curve;
        return true;
    }
}

void AnimationClip::SetCurve(const core::string& path, const Unity::Type* type, MonoScriptPPtr script, const core::string& attribute, AnimationCurve* curve, bool syncEditorCurves, bool updateClipSettings)
{
#if !UNITY_EDITOR
    if (!IsLegacy())
    {
        ErrorString("Can't use AnimationClip::SetCurve at Runtime on non Legacy AnimationClips");
        return;
    }
#endif
    SET_ALLOC_OWNER(this);

    #if UNITY_EDITOR
    if (syncEditorCurves)
    {
        m_EditorCurves.clear();
        m_EulerEditorCurves.clear();
    }
    #endif

    if (type == NULL || !type->IsDerivedFrom<Object>())
    {
        ErrorString("Can't assign curve because the type does not inherit from Object.");
        return;
    }

    if (type->IsDerivedFrom<Transform>() && (BeginsWith(attribute, "m_LocalRotation") || BeginsWith(attribute, "localRotation")))
    {
        // Find existing curve
        QuaternionCurves::iterator i;
        for (i = m_QuaternionCurves.begin(); i != m_QuaternionCurves.end(); i++)
        {
            if (i->path == path)
                break;
        }

        // Shall we remove a curve?
        if (curve == NULL)
        {
            if (attribute == "m_LocalRotation" ||  attribute == "localRotation")
            {
                if (i != m_QuaternionCurves.end())
                {
                    m_QuaternionCurves.erase(i);
                    if (updateClipSettings)
                        ClipWasModifiedAndUpdateClipSettings();

                    SetDirty();
                }
                return;
            }
            else
            {
                ErrorString("Can't remove individual animation rotation curve " + attribute + " you must remove the entire animation curve with m_LocalRotation.");
                return;
            }
        }

        // Add the curve if it doesnt exist already
        AnimationCurveQuat* comboCurve = i != m_QuaternionCurves.end() ? &i->curve : NULL;

        if (comboCurve == NULL)
        {
            m_QuaternionCurves.push_back(QuaternionCurve());
            m_QuaternionCurves.back().path = path;
            comboCurve = &m_QuaternionCurves.back().curve;
        }

        // Combine the curve into a rotation curve
        char last = attribute[attribute.size() - 1];
        if (last == 'x')
            CombineCurve(*curve, 0, *comboCurve, Zero<Quaternionf>());
        else if (last == 'y')
            CombineCurve(*curve, 1, *comboCurve, Zero<Quaternionf>());
        else if (last == 'z')
            CombineCurve(*curve, 2, *comboCurve, Zero<Quaternionf>());
        else if (last == 'w')
            CombineCurve(*curve, 3, *comboCurve, Zero<Quaternionf>());
        else
        {
            ErrorString("Can't assign curve because " + attribute + " is not a valid Transform property.");
        }
    }
    else if (type->IsDerivedFrom<Transform>() && (BeginsWith(attribute, "m_LocalEuler") || BeginsWith(attribute, "localEuler")))
    {
        // Find existing curve
        Vector3Curves::iterator i;
        for (i = m_EulerCurves.begin(); i != m_EulerCurves.end(); i++)
        {
            if (i->path == path)
                break;
        }

        // Shall we remove a curve?
        if (curve == NULL)
        {
            if (attribute == "m_LocalEuler" || attribute == "localEuler")
            {
                if (i != m_EulerCurves.end())
                {
                    m_EulerCurves.erase(i);
                    ClipWasModified();
                    SetDirty();
                }
                return;
            }
            else
            {
                ErrorString("Can't remove individual rotation animation curve " + attribute + " you must remove the entire animation curve with m_LocalEuler.");
                return;
            }
        }

        // Add the curve if it doesnt exist already
        AnimationCurveVec3* comboCurve = i != m_EulerCurves.end() ? &i->curve : NULL;
        if (comboCurve == NULL)
        {
            m_EulerCurves.push_back(Vector3Curve());
            m_EulerCurves.back().path = path;
            comboCurve = &m_EulerCurves.back().curve;
        }

        // Combine the curve into a rotation curve
        char last = attribute[attribute.size() - 1];
        if (last == 'x')
            CombineCurve(*curve, 0, *comboCurve, Vector3f::zero);
        else if (last == 'y')
            CombineCurve(*curve, 1, *comboCurve, Vector3f::zero);
        else if (last == 'z')
            CombineCurve(*curve, 2, *comboCurve, Vector3f::zero);
        else
        {
            ErrorString("Can't assign curve because " + attribute + " is not a valid Transform property.");
        }
    }
    else if (type == TypeOf<Transform>() && (BeginsWith(attribute, "m_LocalPosition") || BeginsWith(attribute, "localPosition")))
    {
        // Find existing curve
        Vector3Curves::iterator i;
        for (i = m_PositionCurves.begin(); i != m_PositionCurves.end(); i++)
        {
            if (i->path == path)
                break;
        }

        // Shall we remove a curve?
        if (curve == NULL)
        {
            if (attribute == "m_LocalPosition" || attribute == "localPosition")
            {
                if (i != m_PositionCurves.end())
                {
                    m_PositionCurves.erase(i);
                    if (updateClipSettings)
                        ClipWasModifiedAndUpdateClipSettings();
                    SetDirty();
                }
                return;
            }
            else
            {
                ErrorString("Can't remove individual position animation curve " + attribute + " you must remove the entire animation curve with m_LocalPosition.");
                return;
            }
        }

        // Add the curve if it doesnt exist already
        AnimationCurveVec3* comboCurve = i != m_PositionCurves.end() ? &i->curve : NULL;
        if (comboCurve == NULL)
        {
            m_PositionCurves.push_back(Vector3Curve());
            m_PositionCurves.back().path = path;
            comboCurve = &m_PositionCurves.back().curve;
        }

        // Combine the curve into a rotation curve
        char last = attribute[attribute.size() - 1];
        if (last == 'x')
            CombineCurve(*curve, 0, *comboCurve, Vector3f::zero);
        else if (last == 'y')
            CombineCurve(*curve, 1, *comboCurve, Vector3f::zero);
        else if (last == 'z')
            CombineCurve(*curve, 2, *comboCurve, Vector3f::zero);
        else
        {
            ErrorString("Can't assign curve because " + attribute + " is not a valid Transform property.");
        }
    }
    else if (type->IsDerivedFrom<Transform>() && (BeginsWith(attribute, "m_LocalScale") || BeginsWith(attribute, "localScale")))
    {
        // Find existing curve
        Vector3Curves::iterator i;
        for (i = m_ScaleCurves.begin(); i != m_ScaleCurves.end(); i++)
        {
            if (i->path == path)
                break;
        }

        // Shall we remove a curve?
        if (curve == NULL)
        {
            if (attribute == "m_LocalScale" || attribute == "localScale")
            {
                if (i != m_ScaleCurves.end())
                {
                    m_ScaleCurves.erase(i);
                    if (updateClipSettings)
                        ClipWasModifiedAndUpdateClipSettings();
                    SetDirty();
                }
                return;
            }
            else
            {
                ErrorString("Can't remove individual scale animation curve " + attribute + " you must remove the entire animation curve with m_LocalScale.");
                return;
            }
        }

        // Add the curve if it doesnt exist already
        AnimationCurveVec3* comboCurve = i != m_ScaleCurves.end() ? &i->curve : NULL;
        if (comboCurve == NULL)
        {
            m_ScaleCurves.push_back(Vector3Curve());
            m_ScaleCurves.back().path = path;
            comboCurve = &m_ScaleCurves.back().curve;
        }

        // Combine the curve into a rotation curve
        char last = attribute[attribute.size() - 1];
        if (last == 'x')
            CombineCurve(*curve, 0, *comboCurve, Vector3f::one);
        else if (last == 'y')
            CombineCurve(*curve, 1, *comboCurve, Vector3f::one);
        else if (last == 'z')
            CombineCurve(*curve, 2, *comboCurve, Vector3f::one);
        else
        {
            ErrorString("Can't assign curve because " + attribute + " is not a valid Transform property.");
        }
    }
    else
    {
        // Find existing curve
        FloatCurves::iterator i;
        for (i = m_FloatCurves.begin(); i != m_FloatCurves.end(); i++)
        {
            if (i->type == type && i->path == path && i->attribute == attribute && i->script == script)
                break;
        }

        // Shall we remove a curve?
        if (curve == NULL)
        {
            if (i != m_FloatCurves.end())
            {
                m_FloatCurves.erase(i);
                if (updateClipSettings)
                    ClipWasModifiedAndUpdateClipSettings();
                SetDirty();
            }

            return;
        }

        // Add or replace the curve
        AnimationCurve* comboCurve = i != m_FloatCurves.end() ? &i->curve : NULL;
        if (comboCurve == NULL)
        {
            m_FloatCurves.push_back(FloatCurve());
            m_FloatCurves.back().path = path;
            m_FloatCurves.back().attribute = attribute;
            m_FloatCurves.back().type = type;
            m_FloatCurves.back().script = script;
            m_FloatCurves.back().curve = *curve;
        }
        else
            *comboCurve = *curve;
    }

    if (updateClipSettings)
        ClipWasModifiedAndUpdateClipSettings();

    SetDirty();
}

#if UNITY_EDITOR

void AnimationClip::ConvertToNewCurveFormat(NewAnimationTrack& track, const Unity::Type* type, const core::string& path)
{
    NewAnimationTrack::Curves& curves = track.m_Curves;
    for (NewAnimationTrack::Curves::iterator i = curves.begin(); i != curves.end(); i++)
    {
        AnimationCurve& curve = i->curve;
        SetCurve(path, type, NULL, i->attributeName, &curve, true);
    }
}

void AnimationClip::ConvertToNewCurveFormat()
{
    for (TypeToTrack::iterator i = m_TypeToTrack.begin(); i != m_TypeToTrack.end(); i++)
    {
        NewAnimationTrack* track = dynamic_pptr_cast<NewAnimationTrack*>(i->second);
        if (track)
            ConvertToNewCurveFormat(*track, i->first, "");

        SetDirty();
    }

    for (ChildTracks::iterator i = m_ChildTracks.begin(); i != m_ChildTracks.end(); i++)
    {
        NewAnimationTrack* track = dynamic_pptr_cast<NewAnimationTrack*>(i->track);
        if (track)
            ConvertToNewCurveFormat(*track, i->type, i->path);

        SetDirty();
    }

    // Just leak the actual animation track objects!
    m_TypeToTrack.clear();
    m_ChildTracks.clear();
}

#endif

void AnimationClip::GetStats(AnimationClipStats& stats)
{
    memset(&stats, 0, sizeof(stats));
    stats.size = m_MuscleClipSize;

    if (IsMecanimDataValid())
    {
        stats.totalCurves = 0;
        for (size_t i = 0; i < m_ClipBindingConstant.genericBindings.size(); i++)
        {
            if (m_ClipBindingConstant.genericBindings[i].GetType() == TypeOf<Transform>())
            {
                switch (m_ClipBindingConstant.genericBindings[i].attribute)
                {
                    case UnityEngine::Animation::kBindTransformPosition:
                        stats.positionCurves++;
                        stats.totalCurves += 3;
                        break;
                    case UnityEngine::Animation::kBindTransformRotation:
                        stats.quaternionCurves++;
                        stats.totalCurves += 4;
                        break;
                    case UnityEngine::Animation::kBindTransformEuler:
                        stats.eulerCurves++;
                        stats.totalCurves += 3;
                        break;
                    case UnityEngine::Animation::kBindTransformScale:
                        stats.scaleCurves++;
                        stats.totalCurves += 3;
                        break;
                }
            }
            else if (m_ClipBindingConstant.genericBindings[i].isPPtrCurve)
            {
                stats.pptrCurves++;
                stats.totalCurves++;
            }
            else if (IsMuscleBinding(m_ClipBindingConstant.genericBindings[i]))
            {
                stats.muscleCurves++;
                stats.totalCurves++;
            }
            else
            {
                stats.genericCurves++;
                stats.totalCurves++;
            }
        }

        stats.constantCurves = m_MuscleClip->m_Clip->m_ConstantClip.curveCount;
        stats.denseCurves = m_MuscleClip->m_Clip->m_DenseClip.m_CurveCount;
        stats.streamCurves = m_MuscleClip->m_Clip->m_StreamedClip.curveCount;
    }
}

bool  AnimationClip::IsHumanMotion() const
{
    for (FloatCurves::const_iterator dynamicCurveIter = m_FloatCurves.begin(); dynamicCurveIter != m_FloatCurves.end(); dynamicCurveIter++)
    {
        if (dynamicCurveIter->type == TypeOf<Animator>())
        {
            mecanim::int32_t muscleIndex = mecanim::animation::FindMuscleIndex(mecanim::processCRC32(dynamicCurveIter->attribute.c_str()));
            if (muscleIndex >= mecanim::animation::s_ClipMuscleCurveRootEnd)
            {
                return true;
            }
        }
    }

    // case 693099 : look into runtime bindings for asset store packages.
    if (m_MuscleClip != 0)
    {
        for (size_t i = 0; i < m_ClipBindingConstant.genericBindings.size(); i++)
        {
            if (m_ClipBindingConstant.genericBindings[i].GetType() == TypeOf<Animator>() && m_ClipBindingConstant.genericBindings[i].attribute >= mecanim::animation::s_ClipMuscleCurveRootEnd)
                return true;
        }
    }

    return false;
}

#if UNITY_EDITOR

void AnimationClip::SetGenerateMotionCurves(bool value)
{
    m_GenerateMotionCurves = value;
    ClipWasModified(true);
}

bool  AnimationClip::HasGenericRootTransform()
{
    if (IsMecanimDataValid())
    {
        return m_HasGenericRootTransform;
    }

    return false;
}

bool AnimationClip::HasMotionFloatCurves()
{
    if (IsMecanimDataValid())
    {
        return m_HasMotionFloatCurves;
    }

    return false;
}

bool  AnimationClip::HasMotionCurves()
{
    if (IsMecanimDataValid())
    {
        return mecanim::animation::HasMotionCurves(*m_MuscleClip);
    }

    return false;
}

bool  AnimationClip::HasRootCurves()
{
    if (IsMecanimDataValid())
    {
        return mecanim::animation::HasRootCurves(*m_MuscleClip);
    }

    return false;
}

void AnimationClip::BuildMecanimDataMainThread()
{
    Assert(Thread::CurrentThreadIsMainThread());

    // m_MuscleClip could be != NULL even if m_MuscleClipSize == 0.
    // No need to regenerate muscle clip since it means it is an already built empty clip.
    if (!MecanimDataWasBuilt())
    {
        GenerateMuscleClip();
    }
}

#endif

bool AnimationClip::MecanimDataWasBuilt() const
{
    // m_MuscleClip should never be NULL when m_MuscleClipSize > 0
    Assert((m_MuscleClipSize > 0 && m_MuscleClip != NULL) || m_MuscleClipSize == 0);

    return m_MuscleClip != NULL;
}

bool AnimationClip::IsMecanimDataValid() const
{
    return MecanimDataWasBuilt() && m_MuscleClipSize > 0;
}

mecanim::animation::ClipMuscleConstant* AnimationClip::GetRuntimeAsset()
{
    Assert(MecanimDataWasBuilt());
    return IsMecanimDataValid() ? m_MuscleClip : NULL;
}

void AnimationClip::CleanupMecanimData()
{
    // Since the m_MuscleClip and all its data is placed on the m_Allocator, the destructor is not needed
    m_MuscleClip = 0;
    m_MuscleClipSize = 0;

    m_ClipAllocator.Reset();

    ///@TODO: Make destory function.
    m_ClipBindingConstant.genericBindings.clear();
    m_ClipBindingConstant.pptrCurveMapping.clear();
}

void AnimationClip::ClearCachedRange()
{
    m_CachedRange = std::make_pair(std::numeric_limits<float>::infinity(), -std::numeric_limits<float>::infinity());
}

AnimationClipPPtrVector AnimationClip::GetAnimationClips() const
{
    AnimationClipPPtrVector  ret;
    ret.push_back(this);
    return ret;
}

#if UNITY_EDITOR

bool AnimationClip::IsValidAdditiveReferenceClip(AnimationClip const* additiveReferenceClip)
{
    mecanim::animation::ClipMuscleConstant *cstClip = GetRuntimeAsset();

    const_cast<AnimationClip*>(additiveReferenceClip)->BuildMecanimDataMainThread();
    mecanim::animation::ClipMuscleConstant *cstAdditiveReferenceClip = const_cast<AnimationClip*>(additiveReferenceClip)->GetRuntimeAsset();

    UnityEngine::Animation::AnimationClipBindingConstant* clipBindingConstant  = GetBindingConstant();
    UnityEngine::Animation::AnimationClipBindingConstant* additiveReferenceBindingConstant = const_cast<AnimationClip*>(additiveReferenceClip)->GetBindingConstant();


    if (cstClip == NULL || clipBindingConstant == NULL || cstAdditiveReferenceClip == NULL || additiveReferenceBindingConstant == NULL)
        return false;

    if (cstClip->m_ValueArrayCount > cstAdditiveReferenceClip->m_ValueArrayCount)
        return false;

    for (int i = 0; i < clipBindingConstant->genericBindings.size(); ++i)
    {
        int j;
        for (j = 0; j < additiveReferenceBindingConstant->genericBindings.size(); ++j)
        {
            if (clipBindingConstant->genericBindings[i] == additiveReferenceBindingConstant->genericBindings[j])
                break;
        }

        if (j == additiveReferenceBindingConstant->genericBindings.size() && i < clipBindingConstant->genericBindings.size())
            return false;
    }

    //todo@sonny do we need to check for pptr binding?

    return true;
}

void AnimationClip::SetAdditiveReferencePose(AnimationClip const* clip, float time)
{
    if (clip != NULL && !IsValidAdditiveReferenceClip(clip))
    {
        ErrorStringObject(Format("AnimationClip '%s' is not a valid additive reference clip", clip->GetName()), this);
        return;
    }

    bool needUpdate = m_AnimationClipSettings.m_AdditiveReferencePoseClip != PPtr<AnimationClip>(clip) || m_AnimationClipSettings.m_AdditiveReferencePoseTime != time;

    if (needUpdate)
    {
        m_AnimationClipSettings.m_HasAdditiveReferencePose = clip != NULL ? true : false;
        m_AnimationClipSettings.m_AdditiveReferencePoseClip = clip;
        m_AnimationClipSettings.m_AdditiveReferencePoseTime = time;
        ClipWasModified();
        SetDirty();
    }
}

void AnimationClip::SetAnimationClipSettingsNoDirty(AnimationClipSettings &clipInfo)
{
    m_AnimationClipSettings = clipInfo;

    BuildMecanimDataMainThread();

    if (IsMecanimDataValid())
    {
        PatchMuscleClipWithInfo(this, m_AnimationClipSettings, IsHumanMotion(), m_MuscleClip, m_ClipAllocator);
    }
}

struct RootMotionCurve
{
    core::string *name;
    AnimationCurve *curve;
};

typedef UNITY_VECTOR (kMemTempAlloc, RootMotionCurve) RootMotionCurves;

void GenerateRootMotionPositionCurves(RootMotionCurves &rootMotionCurves, AnimationCurveVec3 const &positionCurve)
{
    RootMotionCurve rootMotionCurve;

    rootMotionCurve.name = new core::string("MotionT.x");
    AnimationCurve *cx = rootMotionCurve.curve = new AnimationCurve();
    rootMotionCurves.push_back(rootMotionCurve);

    rootMotionCurve.name = new core::string("MotionT.y");
    AnimationCurve *cy = rootMotionCurve.curve = new AnimationCurve();
    rootMotionCurves.push_back(rootMotionCurve);

    rootMotionCurve.name = new core::string("MotionT.z");
    AnimationCurve *cz = rootMotionCurve.curve = new AnimationCurve();
    rootMotionCurves.push_back(rootMotionCurve);

    for (int keyIter = 0; keyIter < positionCurve.GetKeyCount(); keyIter++)
    {
        AnimationCurve::Keyframe kx;
        AnimationCurve::Keyframe ky;
        AnimationCurve::Keyframe kz;

        kx.time = ky.time = kz.time = positionCurve.GetKey(keyIter).time;

        kx.tangentMode = ky.tangentMode = kz.tangentMode = positionCurve.GetKey(keyIter).tangentMode;

        kx.value = positionCurve.GetKey(keyIter).value.x;
        ky.value = positionCurve.GetKey(keyIter).value.y;
        kz.value = positionCurve.GetKey(keyIter).value.z;

        kx.inSlope = positionCurve.GetKey(keyIter).inSlope.x;
        ky.inSlope = positionCurve.GetKey(keyIter).inSlope.y;
        kz.inSlope = positionCurve.GetKey(keyIter).inSlope.z;

        kx.outSlope = positionCurve.GetKey(keyIter).outSlope.x;
        ky.outSlope = positionCurve.GetKey(keyIter).outSlope.y;
        kz.outSlope = positionCurve.GetKey(keyIter).outSlope.z;

        cx->AddKey(kx);
        cy->AddKey(ky);
        cz->AddKey(kz);
    }
}

void GenerateRootMotionRotationCurves(RootMotionCurves &rootMotionCurves, AnimationCurveQuat const &rotationCurve)
{
    RootMotionCurve rootMotionCurve;

    rootMotionCurve.name = new core::string("MotionQ.x");
    AnimationCurve *cx = rootMotionCurve.curve = new AnimationCurve();
    rootMotionCurves.push_back(rootMotionCurve);

    rootMotionCurve.name = new core::string("MotionQ.y");
    AnimationCurve *cy = rootMotionCurve.curve = new AnimationCurve();
    rootMotionCurves.push_back(rootMotionCurve);

    rootMotionCurve.name = new core::string("MotionQ.z");
    AnimationCurve *cz = rootMotionCurve.curve = new AnimationCurve();
    rootMotionCurves.push_back(rootMotionCurve);

    rootMotionCurve.name = new core::string("MotionQ.w");
    AnimationCurve *cw = rootMotionCurve.curve = new AnimationCurve();
    rootMotionCurves.push_back(rootMotionCurve);

    for (int keyIter = 0; keyIter < rotationCurve.GetKeyCount(); keyIter++)
    {
        AnimationCurve::Keyframe kx;
        AnimationCurve::Keyframe ky;
        AnimationCurve::Keyframe kz;
        AnimationCurve::Keyframe kw;

        kx.time = ky.time = kz.time = kw.time = rotationCurve.GetKey(keyIter).time;

        kx.tangentMode = ky.tangentMode = kz.tangentMode = kw.tangentMode = rotationCurve.GetKey(keyIter).tangentMode;

        kx.value = rotationCurve.GetKey(keyIter).value.x;
        ky.value = rotationCurve.GetKey(keyIter).value.y;
        kz.value = rotationCurve.GetKey(keyIter).value.z;
        kw.value = rotationCurve.GetKey(keyIter).value.w;

        kx.inSlope = rotationCurve.GetKey(keyIter).inSlope.x;
        ky.inSlope = rotationCurve.GetKey(keyIter).inSlope.y;
        kz.inSlope = rotationCurve.GetKey(keyIter).inSlope.z;
        kw.inSlope = rotationCurve.GetKey(keyIter).inSlope.w;

        kx.outSlope = rotationCurve.GetKey(keyIter).outSlope.x;
        ky.outSlope = rotationCurve.GetKey(keyIter).outSlope.y;
        kz.outSlope = rotationCurve.GetKey(keyIter).outSlope.z;
        kw.outSlope = rotationCurve.GetKey(keyIter).outSlope.w;

        cx->AddKey(kx);
        cy->AddKey(ky);
        cz->AddKey(kz);
        cw->AddKey(kw);
    }
}

void GenerateRootMotionRotationCurves(RootMotionCurves &rootMotionCurves, AnimationCurveVec3 const &rotationCurve, float sampleRate)
{
    RootMotionCurve rootMotionCurve;

    rootMotionCurve.name = new core::string("MotionQ.x");
    AnimationCurve *cx = rootMotionCurve.curve = new AnimationCurve();
    rootMotionCurves.push_back(rootMotionCurve);

    rootMotionCurve.name = new core::string("MotionQ.y");
    AnimationCurve *cy = rootMotionCurve.curve = new AnimationCurve();
    rootMotionCurves.push_back(rootMotionCurve);

    rootMotionCurve.name = new core::string("MotionQ.z");
    AnimationCurve *cz = rootMotionCurve.curve = new AnimationCurve();
    rootMotionCurves.push_back(rootMotionCurve);

    rootMotionCurve.name = new core::string("MotionQ.w");
    AnimationCurve *cw = rootMotionCurve.curve = new AnimationCurve();
    rootMotionCurves.push_back(rootMotionCurve);

    Quaternionf prevQuat(0, 0, 0, 1);

    int keyCount = rotationCurve.GetKeyCount();

    if (keyCount > 0)
    {
        float startTime = rotationCurve.GetKey(0).time;
        float stopTime = rotationCurve.GetKey(keyCount - 1).time;

        int sampleCount = ceil((stopTime - startTime) * sampleRate) + 1;

        for (int sampleIter = 0; sampleIter < sampleCount; sampleIter++)
        {
            AnimationCurve::Keyframe kx;
            AnimationCurve::Keyframe ky;
            AnimationCurve::Keyframe kz;
            AnimationCurve::Keyframe kw;

            float sampleTime = startTime + float(sampleIter) / sampleRate;

            Vector3f eulerValue = rotationCurve.Evaluate(sampleTime);
            Quaternionf quatValue = EulerToQuaternion(eulerValue * kDeg2Rad, rotationCurve.GetRotationOrder());

            if (Dot(prevQuat, quatValue) < 0.0F)
            {
                quatValue = Quaternionf(-quatValue.x, -quatValue.y, -quatValue.z, -quatValue.w);
            }

            prevQuat = quatValue;

            kx.time = ky.time = kz.time = kw.time = sampleTime;

            kx.value = quatValue.x;
            ky.value = quatValue.y;
            kz.value = quatValue.z;
            kw.value = quatValue.w;

            cx->AddKey(kx);
            cy->AddKey(ky);
            cz->AddKey(kz);
            cw->AddKey(kw);
        }

        RecalculateSplineSlope(*cx);
        RecalculateSplineSlope(*cy);
        RecalculateSplineSlope(*cz);
        RecalculateSplineSlope(*cw);
    }
}

void AnimationClip::GenerateMuscleClip()
{
    CleanupMecanimData();

    if (IsLegacy())
        return;

    MecanimClipBuilder clipBuilder;

    // this should always be initialized before any call to add curve since it does use these varaible to determine how those curve should be represented
    ClearCachedRange();

    clipBuilder.startTime = GetRange().first;
    clipBuilder.stopTime = GetRange().second;
    clipBuilder.hasAnimationEvents = HasAnimationEvents();
    clipBuilder.sampleRate = GetSampleRate();

    GenericAnimationBindingCache& binder = GetGenericAnimationBindingCache();

    RootMotionCurves rootMotionCurves;
    m_HasGenericRootTransform = false;
    m_HasMotionFloatCurves = false;

    //// collect all curves, and count keys

    // Position curves
    for (Vector3Curves::iterator positionCurveIter = m_PositionCurves.begin(); positionCurveIter != m_PositionCurves.end(); positionCurveIter++)
    {
        if (positionCurveIter->path == "")
        {
            m_HasGenericRootTransform = true;

            if (m_GenerateMotionCurves)
            {
                GenerateRootMotionPositionCurves(rootMotionCurves, positionCurveIter->curve);
            }
        }

        AddPositionCurveToClipBuilder(positionCurveIter->curve, positionCurveIter->path, clipBuilder, m_UseHighQualityCurve);
    }

    // Quaternion curves
    for (QuaternionCurves::iterator rotationCurveIter = m_QuaternionCurves.begin(); rotationCurveIter != m_QuaternionCurves.end(); rotationCurveIter++)
    {
        if (rotationCurveIter->path == "")
        {
            m_HasGenericRootTransform = true;

            if (m_GenerateMotionCurves)
            {
                GenerateRootMotionRotationCurves(rootMotionCurves, rotationCurveIter->curve);
            }
        }

        AddRotationCurveToClipBuilder(rotationCurveIter->curve, rotationCurveIter->path, clipBuilder, m_UseHighQualityCurve);
    }

    // Euler curves
    for (Vector3Curves::iterator eulerCurveIter = m_EulerCurves.begin(); eulerCurveIter != m_EulerCurves.end(); eulerCurveIter++)
    {
        if (eulerCurveIter->path == "")
        {
            m_HasGenericRootTransform = true;

            if (m_GenerateMotionCurves)
            {
                GenerateRootMotionRotationCurves(rootMotionCurves, eulerCurveIter->curve, m_SampleRate);
            }
        }

        AddEulerCurveToClipBuilder(eulerCurveIter->curve, eulerCurveIter->path, clipBuilder, m_UseHighQualityCurve);
    }

    // Scale curves
    for (Vector3Curves::iterator scaleCurveIter = m_ScaleCurves.begin(); scaleCurveIter != m_ScaleCurves.end(); scaleCurveIter++)
        AddScaleCurveToClipBuilder(scaleCurveIter->curve, scaleCurveIter->path, clipBuilder, m_UseHighQualityCurve);

    // Root motion curves
    for (int curveIter = 0; curveIter < rootMotionCurves.size(); curveIter++)
    {
        GenericBinding binding;
        binder.CreateGenericBinding("", TypeOf<Animator>(), 0, *rootMotionCurves[curveIter].name, false, binding);
        AddGenericCurveToClipBuilder(*rootMotionCurves[curveIter].curve, binding, clipBuilder, m_UseHighQualityCurve);
    }

    // Dynamic binded curves
    for (FloatCurves::iterator dynamicCurveIter = m_FloatCurves.begin(); dynamicCurveIter != m_FloatCurves.end(); dynamicCurveIter++)
    {
        GenericBinding binding;
        binder.CreateGenericBinding(dynamicCurveIter->path, dynamicCurveIter->type, dynamicCurveIter->script, dynamicCurveIter->attribute, false, binding);
        AddGenericCurveToClipBuilder(dynamicCurveIter->curve, binding, clipBuilder, m_UseHighQualityCurve);

        if (binding.customType == kBindMuscle && int(binding.attribute) >= int(mecanim::animation::s_ClipMuscleCurveMotionBegin) && int(binding.attribute) < int(mecanim::animation::s_ClipMuscleCurveMotionEnd))
        {
            m_HasMotionFloatCurves = true;
        }
    }

    // PPtr curves
    for (PPtrCurves::iterator pptrCurveIter = m_PPtrCurves.begin(); pptrCurveIter != m_PPtrCurves.end(); ++pptrCurveIter)
    {
        GenericBinding binding;
        binder.CreateGenericBinding(pptrCurveIter->path, pptrCurveIter->type, pptrCurveIter->script, pptrCurveIter->attribute, true, binding);
        AddPPtrCurveToClipBuilder(pptrCurveIter->curve, binding, clipBuilder);
    }

    if (PrepareClipBuilder(clipBuilder))
    {
        m_MuscleClip = BuildMuscleClip(clipBuilder, m_AnimationClipSettings, IsHumanMotion(), m_ClipBindingConstant, m_ClipAllocator);

        BlobWrite::container_type blob;
        BlobWrite blobWrite(blob, kNoTransferInstructionFlags, kBuildNoTargetPlatform);
        blobWrite.TransferBase(*m_MuscleClip);

        m_MuscleClipSize = blob.size();

        // This function call must happen after setting m_MuscleClip and m_MuscleClipSize
        // Because the code is reetrant when we do generate the animation set binding for the additive reference pose
        PatchMuscleClipWithInfo(this, m_AnimationClipSettings, IsHumanMotion(), m_MuscleClip, m_ClipAllocator);
    }
    else
    {
        m_MuscleClip = m_ClipAllocator.Construct<mecanim::animation::ClipMuscleConstant>();
        m_MuscleClipSize = 0;
    }

    for (int curveIter = 0; curveIter < rootMotionCurves.size(); curveIter++)
    {
        delete rootMotionCurves[curveIter].curve;
        delete rootMotionCurves[curveIter].name;
    }
}

#endif

float AnimationClip::GetAverageDuration() const
{
#if UNITY_EDITOR
    return m_AnimationClipSettings.m_StopTime - m_AnimationClipSettings.m_StartTime;
#else
    return m_MuscleClip != 0 ? m_MuscleClip->m_StopTime - m_MuscleClip->m_StartTime : 0.0f;
#endif
}

float AnimationClip::GetAverageAngularSpeed() const
{
    return m_MuscleClip != 0 ? m_MuscleClip->m_AverageAngularSpeed : 0;
}

Vector3f AnimationClip::GetAverageSpeed() const
{
    return m_MuscleClip != 0 ? float3ToVector3f(m_MuscleClip->m_AverageSpeed) : Vector3f::zero;
}

float AnimationClip::GetApparentSpeed() const
{
    // approximation of equivalent rectilinear motion speed that conserves kinectic energy ... i'll work on something better
    return Magnitude(GetAverageSpeed()) * (1 + pow(GetAverageAngularSpeed() / 2, 2));
}

bool AnimationClip::IsLooping() const
{
#if UNITY_EDITOR
    return m_AnimationClipSettings.m_LoopTime;
#else
    return m_MuscleClip != 0 ? m_MuscleClip->m_LoopTime : false;
#endif
}

void AnimationClip::ThreadedCleanup()
{
    CleanupMecanimData();
}

void AnimationClip::MainThreadCleanup()
{
    if (gDidModifyClipCallback)
        gDidModifyClipCallback(NULL, m_AnimationStates);
    m_AnimationStates.clear();
    NotifyObjectUsers(kDidDeleteMotion);
    Super::MainThreadCleanup();
}

void  AnimationClip::SetLegacy(bool legacy)
{
    m_Legacy = legacy;
}

float AnimationClip::GetLength()
{
    return GetRange().second;
}

std::pair<float, float> AnimationClip::GetRange()
{
    std::pair<float, float> range = std::make_pair(std::numeric_limits<float>::infinity(), -std::numeric_limits<float>::infinity());

    if (range != m_CachedRange)
        return m_CachedRange;

    // case 753888: for mecanim animation clip in an asset bundle all the curve are discarded so there is no way to get the clip lenght from this information
    // in this case we must rely on m_MuscleClip, which also can be apply to editor.
    // We know that all operation that change the clip will invalid m_MuscleClip, so in this case for the editor we will fallback to GetRange()
    if (!IsLegacy() && m_MuscleClip != 0)
    {
        range.first = m_MuscleClip->m_StartTime;
        range.second =  m_MuscleClip->m_StopTime;
    }

    for (QuaternionCurves::iterator i = m_QuaternionCurves.begin(); i != m_QuaternionCurves.end(); i++)
    {
        std::pair<float, float> curRange = i->curve.GetRange();
        range.first = std::min(curRange.first, range.first);
        range.second = std::max(curRange.second, range.second);
    }

    for (Vector3Curves::iterator i = m_EulerCurves.begin(); i != m_EulerCurves.end(); i++)
    {
        std::pair<float, float> curRange = i->curve.GetRange();
        range.first = std::min(curRange.first, range.first);
        range.second = std::max(curRange.second, range.second);
    }

    for (Vector3Curves::iterator i = m_PositionCurves.begin(); i != m_PositionCurves.end(); i++)
    {
        std::pair<float, float> curRange = i->curve.GetRange();
        range.first = std::min(curRange.first, range.first);
        range.second = std::max(curRange.second, range.second);
    }

    for (Vector3Curves::iterator i = m_ScaleCurves.begin(); i != m_ScaleCurves.end(); i++)
    {
        std::pair<float, float> curRange = i->curve.GetRange();
        range.first = std::min(curRange.first, range.first);
        range.second = std::max(curRange.second, range.second);
    }

    for (FloatCurves::iterator i = m_FloatCurves.begin(); i != m_FloatCurves.end(); i++)
    {
        std::pair<float, float> curRange = i->curve.GetRange();
        range.first = std::min(curRange.first, range.first);
        range.second = std::max(curRange.second, range.second);
    }

    for (PPtrCurves::iterator i = m_PPtrCurves.begin(); i != m_PPtrCurves.end(); i++)
    {
        if (i->curve.empty())
            continue;

        range.first = std::min(i->curve.front().time, range.first);
        range.second = std::max(i->curve.back().time + 1.0F / m_SampleRate, range.second);
    }

    #if UNITY_EDITOR
    // get a valid range for muscle clip when importing
    for (FloatCurves::iterator i = m_EditorCurves.begin(); i != m_EditorCurves.end(); i++)
    {
        std::pair<float, float> curRange = i->curve.GetRange();
        range.first = std::min(curRange.first, range.first);
        range.second = std::max(curRange.second, range.second);
    }
    #endif

    if (!m_Events.empty())
    {
        //ignore events with non-finite times, so we can clamp them to the valid clip range later.
        //Curves are validated elsewhere
        const float front = m_Events.front().time;
        const float back = m_Events.back().time;
        range.first = IsFinite(front) ? std::min(front, range.first) : range.first;
        range.second = IsFinite(back) ? std::max(back, range.second) : range.second;
    }

    if (range.first == std::numeric_limits<float>::infinity() && range.second == -std::numeric_limits<float>::infinity())
    {
        // arbitrary range - the length shouldn't matter because it doesn't have any keys or events anyway
        // TODO : do not allow to create clips without any keys or events or least it show a warning (LocomotionSystem creates such clip now)
        range.first = 0;
        range.second = 1;
    }

    m_CachedRange = range;
    Assert(IsFinite(m_CachedRange.first) && IsFinite(m_CachedRange.second));

    return m_CachedRange;
}

IMPLEMENT_REGISTER_CLASS(AnimationClip, 74);
IMPLEMENT_OBJECT_SERIALIZE(AnimationClip);

#if UNITY_EDITOR

IMPLEMENT_REGISTER_CLASS(PreviewAnimationClip, 1108);
IMPLEMENT_OBJECT_SERIALIZE(PreviewAnimationClip);

void PreviewAnimationClip::ThreadedCleanup()
{
}

template<class TransferFunction>
void PreviewAnimationClip::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);
}

#endif

void AnimationClip::InitializeClass()
{
    // 2.6 beta -> 2.6 final compatibility
    RegisterAllowNameConversion("AnimationClip", "m_UseCompression", "m_Compressed");
    // 4.3
    RegisterAllowNameConversion("AnimationClip", "m_MuscleClipInfo", "m_AnimationClipSettings");
}

#if UNITY_EDITOR
class StripCurvesForMecanimClips
{
public:

    AnimationClip*                    clip;
    AnimationClip::QuaternionCurves   rotationCurves;
    AnimationClip::Vector3Curves      eulerCurves;
    AnimationClip::Vector3Curves      positionCurves;
    AnimationClip::Vector3Curves      scaleCurves;
    AnimationClip::FloatCurves        floatCurves;
    AnimationClip::PPtrCurves         pptrCurves;
    bool                              stripCurves;

    StripCurvesForMecanimClips(AnimationClip& inputClip, bool inStripCurves)
    {
        if (inStripCurves)
        {
            clip = &inputClip;
            SwapCurves(clip);
        }
        else
        {
            clip = NULL;
        }
    }

    ~StripCurvesForMecanimClips()
    {
        if (clip)
        {
            SwapCurves(clip);
        }
    }

private:
    void SwapCurves(AnimationClip* clip)
    {
        rotationCurves.swap(clip->m_QuaternionCurves);
        eulerCurves.swap(clip->m_EulerCurves);
        positionCurves.swap(clip->m_PositionCurves);
        scaleCurves.swap(clip->m_ScaleCurves);
        floatCurves.swap(clip->m_FloatCurves);
        pptrCurves.swap(clip->m_PPtrCurves);
    }
};
#endif

static void RenameMotionCurvesToRootCurvesBackwardCompatibility(AnimationClip::FloatCurves &floatCurves)
{
    for (int curveIter = 0; curveIter < floatCurves.size(); curveIter++)
    {
        AnimationClip::FloatCurve &curve = floatCurves[curveIter];

        if (curve.type == TypeOf<Animator>())
        {
            if (curve.attribute == core::string("MotionT.x"))
                curve.attribute = "RootT.x";
            else if (curve.attribute == core::string("MotionT.y"))
                curve.attribute = "RootT.y";
            else if (curve.attribute == core::string("MotionT.z"))
                curve.attribute = "RootT.z";
            else if (curve.attribute == core::string("MotionQ.x"))
                curve.attribute = "RootQ.x";
            else if (curve.attribute == core::string("MotionQ.y"))
                curve.attribute = "RootQ.y";
            else if (curve.attribute == core::string("MotionQ.z"))
                curve.attribute = "RootQ.z";
            else if (curve.attribute == core::string("MotionQ.w"))
                curve.attribute = "RootQ.w";
        }
    }
}

template<class TransferFunction>
void AnimationClip::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);
    transfer.SetVersion(6);

    // This step need to be done first before the curve get stripped and also to be sure that
    // m_ClipBindingConstant is builded before the remappptr pass made by asset bundle
    // see case 920973
    if (transfer.IsSerializingForGameRelease() && transfer.IsWritingPPtr())
    {
#if UNITY_EDITOR
        // Enforce that there is always a built muscle clip when building for the player.
        BuildMecanimDataMainThread();
#endif
    }


    TRANSFER(m_Legacy);

    // Strip mecanim curve data for non-legacy clips
    #if UNITY_EDITOR
    StripCurvesForMecanimClips revert(*this, transfer.IsWritingGameReleaseData() && !m_Legacy);
    #endif

    // Backwards compatibility with ancient tracks
    #if UNITY_EDITOR
    if (transfer.IsOldVersion(2) || transfer.IsOldVersion(1))
    {
        transfer.Transfer(m_TypeToTrack, "m_ClassIDToTrack", kHideInEditorMask);
        transfer.Transfer(m_ChildTracks, "m_ChildTracks", kHideInEditorMask);
    }
    #endif

    // Rotation curves / potentially compressed
    transfer.Transfer(m_Compressed, "m_Compressed", kNotEditableMask);
    transfer.Transfer(m_UseHighQualityCurve, "m_UseHighQualityCurve", kNotEditableMask);
    transfer.Align();

    // Don't do following transfers if we're inside PPtr transfer,
    // as they don't do anything anyway and we cannot allocate memory during such transfer,
    // while the following lines call vector default ctor which might allocate on certain platforms
    if (!transfer.IsRemapPPtrTransfer())
    {
        if (!m_Compressed)
        {
            transfer.Transfer(m_QuaternionCurves, "m_RotationCurves", kHideInEditorMask);
            CompressedQuaternionCurves empty;
            transfer.Transfer(empty, "m_CompressedRotationCurves", kHideInEditorMask);
        }
        else
        {
            QuaternionCurves empty;
            transfer.Transfer(empty, "m_RotationCurves", kHideInEditorMask);

            if ((transfer.GetFlags() & kPerformUnloadDependencyTracking) == 0)
            {
                TRANSFER_WITH_CUSTOM_GET_SET(CompressedQuaternionCurves, "m_CompressedRotationCurves",
                    CompressCurves(value),
                    DecompressCurves(value),
                    kHideInEditorMask);
            }
        }
    }

    transfer.Transfer(m_EulerCurves, "m_EulerCurves", kHideInEditorMask);
    transfer.Transfer(m_PositionCurves, "m_PositionCurves", kHideInEditorMask);
    transfer.Transfer(m_ScaleCurves, "m_ScaleCurves", kHideInEditorMask);
    transfer.Transfer(m_FloatCurves, "m_FloatCurves", kHideInEditorMask);
    transfer.Transfer(m_PPtrCurves, "m_PPtrCurves", kHideInEditorMask);
    transfer.Transfer(m_SampleRate, "m_SampleRate");
    TransferEnumWithNameForceIntSize(transfer, m_WrapMode, "m_WrapMode");
    transfer.Transfer(m_Bounds, "m_Bounds");

    if (transfer.IsVersionSmallerOrEqual(4))
    {
        if (!IsHumanMotion())
            RenameMotionCurvesToRootCurvesBackwardCompatibility(m_FloatCurves);
    }

    if (transfer.IsVersionSmallerOrEqual(5))
    {
        int m_AnimationType = 1;
        TRANSFER(m_AnimationType);

        m_Legacy = m_AnimationType == 1;
    }

    if (transfer.IsSerializingForGameRelease())
    {
        transfer.SetUserData(&m_ClipAllocator);
        TRANSFER_BLOB(m_MuscleClip, m_MuscleClipSize);
    }

    TRANSFER(m_ClipBindingConstant); // case 594946 : must always be transfered, so that PPtr dependencies follow

    // Editor curves
    #if UNITY_EDITOR
    if (!transfer.IsSerializingForGameRelease())
    {
        transfer.Transfer(m_AnimationClipSettings, "m_AnimationClipSettings");
        transfer.Transfer(m_EditorCurves, "m_EditorCurves", kHideInEditorMask);
        transfer.Transfer(m_EulerEditorCurves, "m_EulerEditorCurves", kHideInEditorMask);

        transfer.Transfer(m_HasGenericRootTransform, "m_HasGenericRootTransform", kNotEditableMask);
        transfer.Transfer(m_HasMotionFloatCurves, "m_HasMotionFloatCurves", kNotEditableMask);
        transfer.Transfer(m_GenerateMotionCurves, "m_GenerateMotionCurves", kNotEditableMask);
        transfer.Align();
    }
    #endif

    // Events
    #if UNITY_EDITOR
    transfer.Transfer(m_EditModeEvents, "m_Events", kHideInEditorMask);
    if (transfer.IsReading())
        m_Events = m_EditModeEvents;
    #else
    transfer.Transfer(m_Events, "m_Events", kHideInEditorMask);
    #endif

    #if UNITY_EDITOR
    if (transfer.IsVersionSmallerOrEqual(3))
    {
        SyncMuscleCurvesBackwardCompatibility();
    }
    #endif
}

void AnimationClip::CompressCurves(CompressedQuaternionCurves& compressedRotationCurves)
{
    bool didShowError = false;
    compressedRotationCurves.resize(m_QuaternionCurves.size());

    for (size_t i = 0; i < compressedRotationCurves.size(); i++)
    {
        compressedRotationCurves[i].CompressQuatCurve(m_QuaternionCurves[i]);
        if (m_QuaternionCurves[i].curve.GetKeyCount() > 0 && !didShowError)
        {
            if (m_QuaternionCurves[i].curve.GetKey(0).time < -kCurveTimeEpsilon)
            {
                LogStringObject(Format("Animation Clip %s contains negative time keys. This may cause your animation to look wrong, as negative time keys are not supported in compressed animation clips!", this->GetName()), this);
                didShowError = true;
            }
        }
    }
}

void AnimationClip::DecompressCurves(CompressedQuaternionCurves& compressedRotationCurves)
{
    SET_ALLOC_OWNER(this);
    m_QuaternionCurves.resize(compressedRotationCurves.size());

    for (size_t i = 0; i < compressedRotationCurves.size(); i++)
        compressedRotationCurves[i].DecompressQuatCurve(m_QuaternionCurves[i]);
}

#if UNITY_EDITOR
template<class TransferFunction>
void AnimationClip::ChildTrack::Transfer(TransferFunction& transfer)
{
    TRANSFER(path);
    TRANSFER_WITH_NAME(type, "classID");
    TRANSFER(track);
}

#endif

template<class TransferFunction>
void AnimationClip::QuaternionCurve::Transfer(TransferFunction& transfer)
{
    TRANSFER(curve);
    TRANSFER(path);
}

template<class TransferFunction>
void AnimationClip::Vector3Curve::Transfer(TransferFunction& transfer)
{
    TRANSFER(curve);
    TRANSFER(path);
}

template<class TransferFunction>
void AnimationClip::FloatCurve::Transfer(TransferFunction& transfer)
{
    TRANSFER(curve);
    TRANSFER(attribute);
    TRANSFER(path);
    TRANSFER_WITH_NAME(type, "classID");
    TRANSFER(script);
}

template<class TransferFunction>
void AnimationClip::PPtrCurve::Transfer(TransferFunction& transfer)
{
    TRANSFER(curve);
    TRANSFER(attribute);
    TRANSFER(path);
    TRANSFER_WITH_NAME(type, "classID");
    TRANSFER(script);
}

template<class TransferFunction>
void PPtrKeyframe::Transfer(TransferFunction& transfer)
{
    TRANSFER(time);
    TRANSFER(value);
}

void AnimationClip::SetDidModifyClipCallback(DidModifyClipCallback* callback)
{
    gDidModifyClipCallback = callback;
}

void AnimationClip::AddQuaternionCurve(const AnimationCurveQuat& quat, const core::string& path)
{
    SET_ALLOC_OWNER(this);
    m_QuaternionCurves.push_back(QuaternionCurve());
    m_QuaternionCurves.back().curve = quat;
    m_QuaternionCurves.back().path = path;
}

void AnimationClip::AddEulerCurve(const AnimationCurveVec3& euler, const core::string& path)
{
    SET_ALLOC_OWNER(this);
    m_EulerCurves.push_back(Vector3Curve());
    m_EulerCurves.back().curve = euler;
    m_EulerCurves.back().path = path;
}

void AnimationClip::AddPositionCurve(const AnimationCurveVec3& pos, const core::string& path)
{
    SET_ALLOC_OWNER(this);
    m_PositionCurves.push_back(Vector3Curve());
    m_PositionCurves.back().curve = pos;
    m_PositionCurves.back().path = path;
}

void AnimationClip::AddScaleCurve(const AnimationCurveVec3& scale, const core::string& path)
{
    SET_ALLOC_OWNER(this);
    m_ScaleCurves.push_back(Vector3Curve());
    m_ScaleCurves.back().curve = scale;
    m_ScaleCurves.back().path = path;
}

void AnimationClip::AddFloatCurve(const AnimationCurve& curve, const core::string& path, const Unity::Type* type, const core::string& attribute)
{
    SET_ALLOC_OWNER(this);
    m_FloatCurves.push_back(FloatCurve());
    FloatCurve& fc = m_FloatCurves.back();
    fc.curve = curve;
    fc.path = path;
    fc.type = type;
    fc.attribute = attribute;
}

bool AnimationClip::IsEmpty() const
{
#if UNITY_EDITOR
    return
        m_QuaternionCurves.size() == 0 &&
        m_EulerCurves.size() == 0 &&
        m_PositionCurves.size() == 0 &&
        m_ScaleCurves.size() == 0 &&
        m_FloatCurves.size() == 0 &&
        m_PPtrCurves.size() == 0 &&
        m_EditorCurves.size() == 0 &&
        m_Events.empty();
#else

    if (m_MuscleClip == NULL)
        return true;
    if (m_MuscleClip->m_ValueArrayCount == 0)
        return true;

    return false;
#endif
}
