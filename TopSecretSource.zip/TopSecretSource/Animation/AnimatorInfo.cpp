#include "UnityPrefix.h"

#include "AnimatorInfo.h"

#include "AnimationClip.h"

#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/Scripting/ScriptingManager.h"

void AnimatorClipInfoToMono(const AnimatorClipInfo& src, MonoAnimatorClipInfo &dest)
{
    dest.clipInstanceID = src.clip.IsValid() ? src.clip.GetInstanceID() : InstanceID_None;
    dest.weight = src.weight;
}
