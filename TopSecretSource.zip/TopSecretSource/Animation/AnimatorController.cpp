#include "UnityPrefix.h"

#include "AnimatorController.h"

#include "Runtime/BaseClasses/MessageHandlerRegistration.h"
#include "Runtime/Animation/RuntimeAnimatorController.h"

#include "Runtime/mecanim/generic/stringtable.h"
#include "Runtime/Animation/AnimationClip.h"
#include "Runtime/Animation/AnimationSetBinding.h"

#include "Runtime/Animation/Animator.h"
#include "Runtime/Animation/StateMachineBehaviourPlayer.h"
#include "Runtime/Animation/AvatarMask.h"

#include "Runtime/mecanim/animation/controller.h"
#include "Runtime/Scripting/CommonScriptingClasses.h"
#include "Runtime/Scripting/ScriptingManager.h"
#include "Runtime/Scripting/ScriptingUtility.h"


#if UNITY_EDITOR
#include "Editor/Src/Animation/StateMachine.h"
#include "Runtime/Scripting/ScriptingManager.h"
#include "Runtime/Mono/MonoManager.h"
#include "Runtime/Misc/BuildSettings.h"
#include "Editor/Src/AssetPipeline/AssetDatabase.h"
#include "Editor/Src/Undo/ObjectUndo.h"
#endif

#define DIRTY_AND_INVALIDATE() OnInvalidateAnimatorController(); SetDirty();


#if UNITY_EDITOR
int StateInfo::GetFullPathHash() const
{
    return mecanim::processCRC32(m_FullPath.c_str());
}

int StateMachineInfo::GetFullPathHash() const
{
    return mecanim::processCRC32(m_FullPath.c_str());
}

bool IsParent(const StateMachineInfo &stateMachineInfo, const StateInfo &stateInfo)
{
    return stateInfo.m_FullPath.size() > stateMachineInfo.m_FullPath.size()  &&
        stateInfo.m_FullPath.compare(0, stateMachineInfo.m_FullPath.size(), stateMachineInfo.m_FullPath) == 0 &&
        stateInfo.m_FullPath[stateMachineInfo.m_FullPath.size()] == '.';
}

#endif

IMPLEMENT_REGISTER_CLASS(AnimatorController, 91);
IMPLEMENT_OBJECT_SERIALIZE(AnimatorController);


AnimatorController::AnimatorController(MemLabelId label, ObjectCreationMode mode)
    :   Super(label, mode),
#if UNITY_EDITOR
    m_Dependencies(this),
    m_ShouldCallPre_5_0_CheckConsistency(false),
#endif
    m_IsAssetBundled(true),
    m_Allocator(label, 1024 * 4),
    m_Controller(0),
    m_ControllerSize(0),
    m_AnimationSetBindings(0),
    m_MultiThreadedStateMachine(true)
{
}

void AnimatorController::ThreadedCleanup()
{
}

void AnimatorController::MainThreadCleanup()
{
    ClearAsset();
#if UNITY_EDITOR
    m_Dependencies.Clear();
#endif
    Super::MainThreadCleanup();
}

void AnimatorController::InitializeClass()
{
    REGISTER_MESSAGE_VOID(kDidModifyMotion, OnInvalidateAnimatorControllerAndRebuildDependencies);
    REGISTER_MESSAGE_VOID(kDidDeleteMotion, OnInvalidateAnimatorController);

#if UNITY_EDITOR
    RegisterAllowNameConversion(TypeOf<AnimatorController>()->GetName(), "m_Layers", "m_AnimatorLayers");
    RegisterAllowNameConversion(TypeOf<AnimatorController>()->GetName(), "m_AnimatorEvents", "m_AnimatorParameters");
#endif
}

void AnimatorController::AwakeFromLoad(AwakeFromLoadMode mode)
{
    Super::AwakeFromLoad(mode);

#if UNITY_EDITOR
    OnInvalidateAnimatorController();
#endif

    if (m_AnimationSetBindings == NULL && m_Controller != NULL)
    {
        RegisterAnimationClips();
        m_AnimationSetBindings = UnityEngine::Animation::CreateAnimationSetBindings(GetAnimationClips(), m_Allocator);
    }
}

#if UNITY_EDITOR
struct HasVectorParameterPredicate
{
    bool operator()(AnimatorControllerParameter& parameter) { return parameter.GetType() == 0; }
};

struct HasNullStatePredicate
{
    bool operator()(StateMotionPair& pair) { return pair.m_State.IsNull(); }
};
#endif


#if UNITY_EDITOR
void AnimatorController::CheckLayersConsistency()
{
    for (int i = m_AnimatorLayers.size() - 1; i >= 0; --i)
    {
        m_AnimatorLayers[i].SetController(this);

        if (m_AnimatorLayers[i].m_BlendingMode == AnimatorLayerBlendingModeAdditive)
        {
            m_AnimatorLayers[i].m_SyncedLayerAffectsTiming = false;
        }

        // Validate that sync layers are not synchronized on other sync layers
        const int syncLayerIndex = m_AnimatorLayers[i].GetSyncedLayerIndex();
        if (syncLayerIndex != -1 && m_AnimatorLayers[syncLayerIndex].GetSyncedLayerIndex() != -1)
        {
            int nextLayer = syncLayerIndex;
            int currentLayer = nextLayer;
            const int maxTries = m_AnimatorLayers.size();
            for (int tries = 0; tries < maxTries && nextLayer != -1; ++tries)
            {
                currentLayer = nextLayer;
                nextLayer = m_AnimatorLayers[currentLayer].GetSyncedLayerIndex();
            }

            if (nextLayer == -1)
                m_AnimatorLayers[i].SetSyncedLayerIndex(currentLayer);
            else
                m_AnimatorLayers.erase(m_AnimatorLayers.begin() + i);
        }
    }
}

#endif

void AnimatorController::CheckConsistency()
{
    Super::CheckConsistency();
#if UNITY_EDITOR

    if (m_ShouldCallPre_5_0_CheckConsistency)
        CheckConsistency_Pre_5_0();

    // This is the old Vector type which is not supported anymore
    m_AnimatorParameters.erase(std::remove_if(m_AnimatorParameters.begin(), m_AnimatorParameters.end(), HasVectorParameterPredicate()), m_AnimatorParameters.end());


    for (int i = 0; i < m_AnimatorParameters.size(); ++i)
    {
        m_AnimatorParameters[i].SetController(this);
    }

    CheckLayersConsistency();
#endif
}

template<typename TransferFunction>
bool IsLoadingFromAssetBundle(TransferFunction& transfer)
{
    return transfer.IsReading() && transfer.IsSerializingForGameRelease();
}

template<class Transferfunction>
void AnimatorController::TransferRuntimeData(Transferfunction& transfer)
{
    bool shouldBuildAll = transfer.IsSerializingForGameRelease();
#if UNITY_EDITOR
    // kBuildPlayerOnlySerializeBuildProperties is used DependencyCollector and we want to make sure the asset is built
    shouldBuildAll |= (transfer.GetFlags() & kBuildPlayerOnlySerializeBuildProperties) == kBuildPlayerOnlySerializeBuildProperties;
#endif
    if (shouldBuildAll)
    {
        TransferRuntimeDataFromEditorForBuild(transfer);

        transfer.SetUserData(&m_Allocator);
        TRANSFER_BLOB(m_Controller, m_ControllerSize);
        TRANSFER(m_TOS);

        TRANSFER(m_AnimationClips);

        TRANSFER(m_StateMachineBehaviourVectorDescription);
        TRANSFER(m_StateMachineBehaviours);

        transfer.Transfer(m_MultiThreadedStateMachine, "m_MultiThreadedStateMachine", kHideInEditorMask);

        transfer.Align();
    }
    else if (m_IsAssetBundled && transfer.IsRemapPPtrTransfer())
    {
        // case 703189, 702197, For bundled controller we cannot extract dependancy like we do for normal controller because editor's
        // object like AnimatorState, AnimatorStateMachine and AnimatorControllerLayer doesn't exist anymore
        TRANSFER(m_AnimationClips);
        TRANSFER(m_StateMachineBehaviours);
    }
}

template<class Transferfunction>
void AnimatorController::TransferRuntimeDataFromEditorForBuild(Transferfunction& transfer)
{
#if UNITY_EDITOR
    if (transfer.IsRemapPPtrTransfer())
    {
        dynamic_array<PPtr<Object> > dependencies(kMemTempAlloc);
        ExtractDependenciesFromGraph(dependencies);
        transfer.Transfer(dependencies, "m_Dependencies");
    }

    // case 597261, always rebuild asset to get all the latest change.
    if (transfer.IsWritingGameReleaseData())
    {
        OnInvalidateAnimatorController();
        BuildAsset();
    }
#endif
}

template<class TransferFunction>
void AnimatorController::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);
    transfer.SetVersion(5);

    TRANSFER_EDITOR_ONLY_HIDDEN(m_AnimatorParameters);
    transfer.Align();
    TRANSFER_EDITOR_ONLY_HIDDEN(m_AnimatorLayers);

#if UNITY_EDITOR
    // case 491674 Crash when avatar is selected in the Hiererchy when in play mode
    // cannot display a controller in UI if it come from an asset bundle
    if (transfer.IsReading())
        m_IsAssetBundled = IsLoadingFromAssetBundle(transfer) && m_AnimatorLayers.size() == 0;

    if (transfer.IsVersionSmallerOrEqual(3))
    {
        m_ShouldCallPre_5_0_CheckConsistency = true;
    }
#endif

    TransferRuntimeData(transfer);
}

#if UNITY_EDITOR

void AnimatorController::ExtractDependenciesFromGraph(dynamic_array<PPtr<Object> >& dependencies)
{
    for (int i = 0; i < m_AnimatorLayers.size(); ++i)
    {
        m_AnimatorLayers[i].ExtractDependenciesFromGraph(dependencies);
    }
}

void AnimatorController::CheckConsistency_Pre_5_0()
{
    for (int i = 0; i < m_AnimatorLayers.size(); ++i)
    {
        AnimatorControllerLayer& layer = m_AnimatorLayers[i];
        AnimatorStateMachine* sm = GetLayerEffectiveStateMachine(i);

        MotionMap motionMap = layer.GetMotionOverrideMap();
        if (motionMap.size() == 0 && sm != 0)
        {
            StateInfoVector states = sm->CollectAllDeprecatedStates();

            int motionSetIndex = std::max(layer.GetDeprecatedStateMachineMotionSetIndex(), 0);

            if (motionSetIndex > 0) // is override
            {
                for (StateInfoVector::iterator it = states.begin(); it != states.end(); ++it)
                {
                    layer.SetOverrideMotion(it->m_State, dynamic_pptr_cast<Motion*>(it->m_State->GetDeprecatedMotion(motionSetIndex)), false);
                }
            }
        }
    }
}

AnimationClipPPtrVector GetAnimationClipsForLayer(const AnimatorControllerLayer& layer, AnimatorStateMachine* const stateMachine)
{
    AnimationClipPPtrVector ret;

    if (stateMachine == 0)
        return ret;

    StateInfoVector states = CollectAllStates("", stateMachine, false);
    for (StateInfoVector::const_iterator stateIt = states.begin(); stateIt != states.end(); ++stateIt)
    {
        Motion* stateMotion = dynamic_pptr_cast<Motion*>(layer.GetEffectiveMotion(stateIt->m_State));
        if (stateMotion)
        {
            AnimationClipPPtrVector toAdd = stateMotion->GetAnimationClips();
            ret.insert(ret.end(), toAdd.begin(), toAdd.end());
        }
    }

    return ret;
}

struct HasInvalidStateMotionPair
{
    HasInvalidStateMotionPair(AnimatorState* state)
    {
        m_State = state;
    }

    bool operator()(StateMotionPair& pair) {return pair.m_State.IsNull() || (pair.m_State == PPtr<AnimatorState>(m_State)); }

    AnimatorState* m_State;
};


void AnimatorController::RemovedDependenciesToDeletingObject()
{
    for (int i = 0; i < m_AnimatorLayers.size(); ++i)
    {
        AnimatorControllerLayer& layer = m_AnimatorLayers[i];
        AnimatorStateMachine* stateMachine = GetLayerEffectiveStateMachine(i);

        StateInfoVector states = CollectAllStates("", stateMachine, false);
        for (StateInfoVector::const_iterator stateIt = states.begin(); stateIt != states.end(); ++stateIt)
        {
            if (stateIt->m_State->IsMarkedForDeletion())
            {
                Motion* stateMotion = layer.GetEffectiveMotion(stateIt->m_State);
                if (stateMotion)
                {
                    BlendTree* blendTree = dynamic_pptr_cast<BlendTree*>(stateMotion);
                    if (blendTree && !IsMainAsset(blendTree->GetInstanceID()))
                    {
                        DestroyObjectUndoable(blendTree, "Deleted BlendTree");
                    }
                }
            }
        }
        stateMachine->RemoveTransitionsWithDeletingObject();

        layer.RemoveStateMachineBehavioursWithDeletingObject();
    }
}

void AnimatorController::RebuildEditorDependencies()
{
    m_Dependencies.Clear();

    for (int i = 0; i < m_AnimatorLayers.size(); i++)
    {
        AnimatorControllerLayer &animatorLayer = m_AnimatorLayers[i];

        if (animatorLayer.GetMask())
            animatorLayer.GetMask()->AddSelfToDependencies(m_Dependencies);
        if (animatorLayer.GetStateMachine())
        {
            animatorLayer.GetStateMachine()->CheckConsistency(); // Move elsewhere ?
            animatorLayer.GetStateMachine()->AddUser(m_Dependencies);
        }

        MotionMap motionMap = animatorLayer.GetMotionOverrideMap();
        for (MotionMap::iterator it = motionMap.begin(); it != motionMap.end(); ++it)
        {
            if (!it->m_Motion.IsNull())
            {
                it->m_Motion->AddSelfToDependencies(m_Dependencies);
            }
        }
    }
}

mecanim::ValueArrayConstant* AnimatorController::BuildParameters(TOSVector& tos, mecanim::memory::Allocator& allocator) const
{
    /// Parameters
    dynamic_array<mecanim::uint32_t> types(kMemTempAlloc);
    dynamic_array<int> eventIds(kMemTempAlloc);
    for (size_t i = 0; i < m_AnimatorParameters.size(); ++i)
    {
        eventIds.push_back(mecanim::processCRC32(m_AnimatorParameters[i].GetName()));
        tos.insert(std::make_pair(eventIds[i],  m_AnimatorParameters[i].GetName()));
        types.push_back(m_AnimatorParameters[i].GetType());
    }

    mecanim::ValueArrayConstant* values = mecanim::CreateValueArrayConstant(types.begin(), types.size(), allocator);

    for (size_t i = 0; i < m_AnimatorParameters.size(); ++i)
        values->m_ValueArray[i].m_ID = eventIds[i];

    return values;
}

mecanim::ValueArray* AnimatorController::BuildParametersDefaultValue(mecanim::ValueArrayConstant* values, mecanim::memory::Allocator& allocator) const
{
    mecanim::ValueArray* defaultValues =  mecanim::CreateValueArray(values, allocator);
    for (size_t i = 0; i < m_AnimatorParameters.size(); ++i)
    {
        switch (m_AnimatorParameters[i].GetType())
        {
            case AnimatorControllerParameterTypeFloat:
            {
                float val = m_AnimatorParameters[i].GetDefaultFloat();
                defaultValues->WriteData(val, values->m_ValueArray[i].m_Index);
                break;
            }
            case AnimatorControllerParameterTypeInt:
            {
                mecanim::int32_t val =  m_AnimatorParameters[i].GetDefaultInt();
                defaultValues->WriteData(val, values->m_ValueArray[i].m_Index);
                break;
            }
            case AnimatorControllerParameterTypeTrigger:
            case AnimatorControllerParameterTypeBool:
            {
                bool val = m_AnimatorParameters[i].GetDefaultBool();
                defaultValues->WriteData(val, values->m_ValueArray[i].m_Index);
                break;
            }
        }
    }
    return defaultValues;
}

void AnimatorController::BuildAsset()
{
    ClearAsset();
    RebuildEditorDependencies();

    m_TOS.clear();

    ValidateParameters();

    // Insert all reserve keyword
    mecanim::ReserveKeyword* staticTable = mecanim::ReserveKeywordTable();
    int i;
    for (i = 0; i < mecanim::eLastString; i++)
    {
        m_TOS.insert(std::make_pair(staticTable[i].m_ID, core::string(staticTable[i].m_Keyword)));
    }

    /// Parameters
    mecanim::ValueArrayConstant* values = BuildParameters(m_TOS, m_Allocator);
    mecanim::ValueArray* defaultValues =  BuildParametersDefaultValue(values, m_Allocator);

    /// Layers

    std::vector<mecanim::animation::LayerConstant*> layerVector;
    std::vector<mecanim::statemachine::StateMachineConstant*> stateMachineVector;

    UNITY_VECTOR(kMemTempAlloc, int) stateMachineIndexVector;
    UNITY_VECTOR(kMemTempAlloc, int) stateMachineMotionSetCount;

    for (int i = 0; i < m_AnimatorLayers.size(); i++)
    {
        int stateMachineIndex  = m_AnimatorLayers[i].GetSyncedLayerIndex() == -1 ? i : m_AnimatorLayers[i].GetSyncedLayerIndex();
        AnimationClipPPtrVector toAdd = GetAnimationClipsForLayer(m_AnimatorLayers[i], m_AnimatorLayers[stateMachineIndex].GetStateMachine());
        m_AnimationClips.insert(m_AnimationClips.end(), toAdd.begin(), toAdd.end());
    }

    int stateMachineIndex  = 0;
    for (int i = 0; i < m_AnimatorLayers.size(); i++)
    {
        if (m_AnimatorLayers[i].GetSyncedLayerIndex() == -1)
        {
            stateMachineIndexVector.push_back(stateMachineIndex++);
            stateMachineMotionSetCount.push_back(-1);
        }
        else
        {
            stateMachineIndexVector.push_back(-1);
        }
    }

    for (int i = 0; i < m_AnimatorLayers.size(); i++)
    {
        int stateMachineIndex  = 0;

        if (m_AnimatorLayers[i].GetSyncedLayerIndex() == -1)
        {
            AnimatorStateMachine* editorStateMachine = m_AnimatorLayers[i].GetStateMachine();
            if (editorStateMachine)
            {
                AnimatorControllerLayerVector layersUsingStateMachine;
                {
                    for (int layerIter = 0; layerIter < m_AnimatorLayers.size(); ++layerIter)
                    {
                        const bool isReferencingStateMachine = m_AnimatorLayers[layerIter].GetSyncedLayerIndex() != -1 &&
                            m_AnimatorLayers[m_AnimatorLayers[layerIter].GetSyncedLayerIndex()].GetStateMachine() == editorStateMachine;

                        const bool isCurrentNonSyncedLayer = (i == layerIter && m_AnimatorLayers[layerIter].GetSyncedLayerIndex() == -1);

                        if (isReferencingStateMachine || isCurrentNonSyncedLayer)
                            layersUsingStateMachine.push_back(m_AnimatorLayers[layerIter]);
                    }
                }

                mecanim::statemachine::StateMachineConstant* stateMachine = editorStateMachine->BuildRuntimeAsset(m_TOS, layersUsingStateMachine, m_AnimationClips, m_Allocator);

                stateMachineVector.push_back(stateMachine);
                stateMachineIndex = stateMachineIndexVector[i];
                stateMachineMotionSetCount[stateMachineIndex]++;
            }
        }
        else
        {
            stateMachineIndex  = stateMachineIndexVector[m_AnimatorLayers[i].GetSyncedLayerIndex()];

            if (stateMachineIndex == -1)
            {
                DebugAssertMsg(false, "Invalid AnimatorController configuration");
                continue;
            }

            stateMachineMotionSetCount[stateMachineIndex]++;
        }


        AnimatorControllerLayer &animatorLayer = m_AnimatorLayers[i];

        mecanim::animation::LayerConstant*  layer   = mecanim::animation::CreateLayerConstant(stateMachineIndex, stateMachineMotionSetCount[stateMachineIndex], m_Allocator);
        layer->m_Binding = mecanim::processCRC32(animatorLayer.GetName());
        m_TOS.insert(std::make_pair(layer->m_Binding,  animatorLayer.GetName()));
        layer->m_IKPass = animatorLayer.GetIKPass();
        layer->m_LayerBlendingMode = animatorLayer.GetBlendingMode();
        layer->m_DefaultWeight = animatorLayer.GetDefaultWeight();
        layer->m_SyncedLayerAffectsTiming = animatorLayer.GetBlendingMode() == AnimatorLayerBlendingModeOverride ? animatorLayer.GetSyncedLayerAffectsTiming() : false;

        AvatarMask* mask = animatorLayer.GetMask();
        layer->m_BodyMask = mask != NULL ? mask->GetHumanPoseMask() : mecanim::human::FullBodyMask();
        layer->m_SkeletonMask = mask != NULL ? mask->GetSkeletonMask(m_Allocator) : 0;

        layerVector.push_back(layer);

        // Build behaviours information for runtime
        int stateMachineLayerIndex = animatorLayer.GetSyncedLayerIndex() == -1 ? i : animatorLayer.GetSyncedLayerIndex();
        AnimatorStateMachine* editorStateMachine = m_AnimatorLayers[stateMachineLayerIndex].GetStateMachine();
        if (editorStateMachine)
        {
            StateInfoVector allStates = CollectAllStates(editorStateMachine->GetName(), editorStateMachine, true);
            StateMachineInfoVector allStateMachines = CollectAllStateMachines(editorStateMachine->GetName(), editorStateMachine);
            BuildStateMachineBehavioursInfo(animatorLayer, i, allStates, allStateMachines);
        }
    }

    // Early exit if no layer or statemachine
    if (layerVector.size() == 0 || stateMachineVector.size() == 0)
        return;


    mecanim::animation::ControllerConstant* controllerConstant  =
        mecanim::animation::CreateControllerConstant(layerVector.size(), layerVector.size() ? &layerVector.front() : 0,
            stateMachineVector.size(), stateMachineVector.size() ? &stateMachineVector.front() : 0,
            values, defaultValues, m_AnimationClips.size(), m_Allocator);
    Assert(controllerConstant != 0);
    if (controllerConstant)
    {
        m_Controller = controllerConstant;

        BlobWrite::container_type data;
        BlobWrite blobWrite(data, kNoTransferInstructionFlags, kBuildNoTargetPlatform);
        blobWrite.TransferBase(*m_Controller);

        m_ControllerSize = data.size();

        RegisterAnimationClips();
        m_AnimationSetBindings = UnityEngine::Animation::CreateAnimationSetBindings(GetAnimationClips(), m_Allocator);
    }
}

void AnimatorController::BuildStateMachineBehavioursInfo(AnimatorControllerLayer const& animatorLayer, mecanim::int32_t  layerIndex, StateInfoVector const& statesInfo, StateMachineInfoVector const& stateMachinesInfo)
{
    /////////////////////////////////////////////////////////////////////
    // Builds the StateMachineBehaviour (SMB) instances indirection tables.
    //
    // m_StateMachineBehaviours : SMB instances
    // m_StateMachineBehaviourIndices: indices to m_StateMachineBehaviours, continuous per State/StateMachine
    // m_StateMachineBehaviourRanges: start and count in m_StateMachineBehaviourIndices. Its a Map and the key is (PathHash, layerIndex)
    //
    // The reason for these indirections is that States inherit their SMB from their parent StateMachines, so they will need to point
    // to the same instances.

    std::vector<int> stateMachineStartIndex;

    for (int i = 0; i < stateMachinesInfo.size(); i++)
    {
        StateMachineBehaviourVector behaviours = stateMachinesInfo[i].m_StateMachine->GetBehaviours();
        behaviours.erase(std::remove_if(behaviours.begin(), behaviours.end(), HasInvalidBehaviourPredicate()), behaviours.end());

        for (StateMachineBehaviourVector::const_iterator it = behaviours.begin(); it < behaviours.end(); ++it)
        {
            PPtr<MonoBehaviour> behaviour = *it;

            m_MultiThreadedStateMachine &= (Scripting::GetOverrideMethodOnly("OnStateMachineEnter", behaviour->GetClass(), GetAnimationScriptingClasses().stateMachineBehaviour).IsNull())
                && (Scripting::GetOverrideMethodOnly("OnStateMachineExit", behaviour->GetClass(), GetAnimationScriptingClasses().stateMachineBehaviour).IsNull());
        }

        stateMachineStartIndex.push_back(m_StateMachineBehaviours.size());

        if (behaviours.size() > 0)
        {
            size_t start = m_StateMachineBehaviours.size();
            size_t indicesStart = m_StateMachineBehaviourVectorDescription.m_StateMachineBehaviourIndices.size();
            size_t count = behaviours.size();

            for (int index = 0; index < count; ++index)
            {
                m_StateMachineBehaviourVectorDescription.m_StateMachineBehaviourIndices.push_back(start + index);
            }
            m_StateMachineBehaviourVectorDescription.m_StateMachineBehaviourRanges.insert(std::make_pair(StateKey(stateMachinesInfo[i].GetFullPathHash(), layerIndex), StateRange(indicesStart, count)));
            m_StateMachineBehaviours.insert(m_StateMachineBehaviours.end(), behaviours.begin(), behaviours.end());
        }
    }

    for (int i = 0; i < statesInfo.size(); i++)
    {
        size_t indicesStart = m_StateMachineBehaviourVectorDescription.m_StateMachineBehaviourIndices.size();
        size_t count = 0;

        // State inherit from parent StateMachines
        for (int j = 0; j < stateMachinesInfo.size(); j++)
        {
            if (IsParent(stateMachinesInfo[j], statesInfo[i]))
            {
                StateMachineBehaviourVector stateMachineBehaviours = stateMachinesInfo[j].m_StateMachine->GetBehaviours();
                stateMachineBehaviours.erase(std::remove_if(stateMachineBehaviours.begin(), stateMachineBehaviours.end(), HasInvalidBehaviourPredicate()), stateMachineBehaviours.end());

                for (int index = 0; index < stateMachineBehaviours.size(); ++index)
                {
                    m_StateMachineBehaviourVectorDescription.m_StateMachineBehaviourIndices.push_back(stateMachineStartIndex[j] + index);
                    count++;
                }
            }
        }

        StateMachineBehaviourVector behaviours = animatorLayer.GetEffectiveBehaviours(statesInfo[i].m_State);
        behaviours.erase(std::remove_if(behaviours.begin(), behaviours.end(), HasInvalidBehaviourPredicate()),  behaviours.end());

        if (behaviours.size() > 0)
        {
            for (int index = 0; index < behaviours.size(); ++index)
            {
                m_StateMachineBehaviourVectorDescription.m_StateMachineBehaviourIndices.push_back(m_StateMachineBehaviours.size() + index);
                count++;
            }

            m_StateMachineBehaviours.insert(m_StateMachineBehaviours.end(), behaviours.begin(), behaviours.end());
        }

        if (count > 0)
            m_StateMachineBehaviourVectorDescription.m_StateMachineBehaviourRanges.insert(std::make_pair(StateKey(statesInfo[i].GetFullPathHash(), layerIndex), StateRange(indicesStart, count)));
    }
}

const AnimatorControllerLayerVector& AnimatorController::GetLayers() const
{
    return m_AnimatorLayers;
}

void AnimatorController::SetLayers(AnimatorControllerLayerVector& layers)
{
    m_AnimatorLayers = layers;

    CheckConsistency();
    m_IsAssetBundled = false;
    DIRTY_AND_INVALIDATE();
}

const AnimatorControllerParameterVector& AnimatorController::GetParameters() const
{
    return m_AnimatorParameters;
}

void AnimatorController::SetParameters(AnimatorControllerParameterVector& parameters)
{
    m_AnimatorParameters = parameters;
    DIRTY_AND_INVALIDATE();
}

void AnimatorController::RenameParameter(const core::string& oldName, const core::string& newName)
{
    // rename all refering the parameter
    int layerCount = m_AnimatorLayers.size();
    for (int i = 0; i < layerCount; i++)
    {
        if (m_AnimatorLayers[i].GetStateMachine())
        {
            m_AnimatorLayers[i].GetStateMachine()->RenameParameter(oldName, newName);
            m_AnimatorLayers[i].RenameParameter(oldName, newName);
        }
    }
}

AnimatorStateMachine* AnimatorController::GetLayerEffectiveStateMachine(int layerIndex) const
{
    if (m_AnimatorLayers[layerIndex].GetSyncedLayerIndex() == -1)
    {
        return m_AnimatorLayers[layerIndex].GetStateMachine();
    }
    else
    {
        return m_AnimatorLayers[m_AnimatorLayers[layerIndex].GetSyncedLayerIndex()].GetStateMachine();
    }
}

std::vector<PPtr<Object> > AnimatorController::CollectObjectsUsingParameter(const core::string& parameterName)
{
    std::vector<PPtr<Object> > ret;
    for (AnimatorControllerLayerVector::iterator it = m_AnimatorLayers.begin(); it != m_AnimatorLayers.end(); ++it)
    {
        AnimatorStateMachine* stateMachine = it->GetStateMachine();

        if (stateMachine)
        {
            std::vector<PPtr<Object> > currentRet = stateMachine->CollectObjectsUsingParameter(parameterName);
            ret.insert(ret.end(), currentRet.begin(), currentRet.end());
        }

        MotionMap motionMap = it->GetMotionOverrideMap();

        for (MotionMap::iterator it = motionMap.begin(); it != motionMap.end(); ++it)
        {
            if (!it->m_Motion.IsNull())
            {
                BlendTree* blendTree = dynamic_pptr_cast<BlendTree*>(it->m_Motion);
                if (blendTree)
                {
                    int parameterCount = blendTree->GetRecursiveBlendParameterCount();
                    for (int i = 0; i < parameterCount; ++i)
                    {
                        if (blendTree->GetRecursiveBlendParameter(i)  == parameterName)
                        {
                            if (std::find(ret.begin(), ret.end(), PPtr<BlendTree>(blendTree)) == ret.end())
                                ret.push_back(blendTree);
                        }
                    }
                }
            }
        }
    }

    return ret;
}

core::string AnimatorController::MakeUniqueParameterName(const core::string& newName) const
{
    core::string attemptName = newName;
    int attempt = 0;
    while (true)
    {
        int i = 0;
        for (i = 0; i < m_AnimatorParameters.size(); i++)
        {
            if (attemptName == m_AnimatorParameters[i].GetName())
            {
                attemptName = newName;
                attemptName += Format(" %d", attempt);
                attempt++;
                break;
            }
        }
        if (i == m_AnimatorParameters.size())
            break;
    }

    return attemptName;
}

core::string AnimatorController::MakeUniqueLayerName(const core::string& newName) const
{
    core::string attemptName = newName;
    int attempt = 0;
    while (true)
    {
        int i = 0;
        for (i = 0; i < m_AnimatorLayers.size(); i++)
        {
            if (attemptName == m_AnimatorLayers[i].GetName())
            {
                attemptName = newName;
                attemptName += Format(" %d", attempt);
                attempt++;
                break;
            }
        }
        if (i == m_AnimatorLayers.size())
            break;
    }

    return attemptName;
}

int AnimatorController::IndexOfParameter(const core::string&name) const
{
    int ret = -1;

    for (int i = 0; i < m_AnimatorParameters.size() && ret == -1; i++)
    {
        if (strcmp(m_AnimatorParameters[i].GetName(), name.c_str()) == 0)
        {
            ret = i;
        }
    }

    return ret;
}

template<typename T> bool ValidateTransitionParameters(AnimatorController const* controller, T const& transitions, char const* state)
{
    bool ret = true;
    for (typename T::const_iterator transitionIt = transitions.begin(); transitionIt !=  transitions.end(); ++transitionIt)
    {
        void* transitionPtr = (void*)(*transitionIt);
        if (transitionPtr == NULL)
        {
            core::string error = Format("Controller '%s': Null transition in state '%s'.", controller->GetName(), state);
            ErrorStringObject(error, controller);
            ret = false;
            continue;
        }

        ConditionVector conditions = (*transitionIt)->GetConditions();

        for (ConditionVector::const_iterator conditionIt = conditions.begin(); conditionIt != conditions.end(); ++conditionIt)
        {
            AnimatorConditionMode mode = (AnimatorConditionMode)conditionIt->m_ConditionMode;

            core::string parameter = conditionIt->m_ConditionEvent;
            int parameterIndex = controller->IndexOfParameter(parameter);

            if (parameterIndex == -1)
            {
                core::string error = Format("Controller '%s': Transition '%s' in state '%s' uses parameter '%s' which does not exist in controller.", controller->GetName(), (*transitionIt)->GetName(), state, parameter.c_str());
                ErrorStringObject(error, (*transitionIt));
                ret = false;
            }
            else
            {
                AnimatorControllerParameterType type = controller->GetParameters()[parameterIndex].GetType();

                if (!IsConditionModeCompatibleWithParameterType(mode, type))
                {
                    core::string error = Format("Controller '%s': Transition '%s' in state '%s' uses parameter '%s' which is not compatible with condition type.", controller->GetName(), (*transitionIt)->GetName(), state, parameter.c_str());
                    ErrorStringObject(error, (*transitionIt));
                    ret = false;
                }
            }
        }
    }

    return ret;
}

bool AnimatorController::ValidateParameters()
{
    bool ret = true;
    for (AnimatorControllerLayerVector::iterator layerIt =  m_AnimatorLayers.begin(); layerIt != m_AnimatorLayers.end(); ++layerIt)
    {
        /////////////////////////////////////////////////////////////////////
        // BlendTrees & Transitions
        if (layerIt->GetSyncedLayerIndex() == -1)
        {
            AnimatorStateMachine* stateMachine = layerIt->GetStateMachine();

            if (stateMachine)
            {
                stateMachine->CheckConsistency();
                StateInfoVector states = CollectAllStates(stateMachine->GetName(), stateMachine, false);
                for (StateInfoVector::iterator stateIt = states.begin(); stateIt != states.end(); ++stateIt)
                {
                    if (stateIt->m_State->IsSpeedParameterActive())
                    {
                        core::string const& parameter = stateIt->m_State->GetSpeedParameter();

                        int parameterIndex = IndexOfParameter(parameter);
                        if (parameterIndex == -1)
                        {
                            core::string warning = core::string("State \"") + stateIt->m_State->GetName() + core::string("\" in Controller \"") + GetName() + core::string("\" uses parameter \"") + parameter + core::string("\" which does not exist.");
                            WarningStringObject(warning, stateIt->m_State);
                        }
                        else if (GetParameters()[parameterIndex].GetType() != AnimatorControllerParameterTypeFloat)
                        {
                            core::string warning = core::string("State \"") + stateIt->m_State->GetName() + core::string("\" in Controller \"") + GetName() + core::string("\" uses parameter \"")  + parameter + core::string("\" which is not float type.");
                            WarningStringObject(warning, stateIt->m_State);
                        }
                    }

                    if (stateIt->m_State->IsMirrorParameterActive())
                    {
                        core::string const& parameter = stateIt->m_State->GetMirrorParameter();

                        int parameterIndex = IndexOfParameter(parameter);
                        if (parameterIndex == -1)
                        {
                            core::string warning = core::string("State \"") + stateIt->m_State->GetName() + core::string("\" in Controller \"") + GetName() + core::string("\" uses parameter \"") + parameter + core::string("\" which does not exist.");
                            WarningStringObject(warning, stateIt->m_State);
                        }
                        else if (GetParameters()[parameterIndex].GetType() != AnimatorControllerParameterTypeBool)
                        {
                            core::string warning = core::string("State \"") + stateIt->m_State->GetName() + core::string("\" in Controller \"") + GetName() + core::string("\" uses parameter \"")  + parameter + core::string("\" which is not bool type.");
                            WarningStringObject(warning, stateIt->m_State);
                        }
                    }


                    Motion* motion = layerIt->GetEffectiveMotion(stateIt->m_State);

                    BlendTree* blendTree = dynamic_pptr_cast<BlendTree*>(motion);
                    if (blendTree)
                    {
                        int parameterCount = blendTree->GetRecursiveBlendParameterCount();
                        for (int i = 0; i < parameterCount; ++i)
                        {
                            core::string parameter = blendTree->GetRecursiveBlendParameter(i);

                            int parameterIndex = IndexOfParameter(parameter);
                            if (parameterIndex == -1)
                            {
                                core::string warning;
                                warning = core::string("BlendTree \"") + blendTree->GetName() + core::string("\" in state \"") + stateIt->m_State->GetName() + core::string("\" in Controller \"") + GetName() + core::string("\" uses parameter \"") + parameter + core::string("\" which does not exist.");
                                ErrorStringObject(warning, blendTree);
                                ret = false;
                            }
                            else if (GetParameters()[parameterIndex].GetType() != AnimatorControllerParameterTypeFloat)
                            {
                                core::string warning = core::string("BlendTree \"") + blendTree->GetName() + core::string("\" in state \"")  + stateIt->m_State->GetName() + core::string("\" in Controller \"") + GetName() + core::string("\" uses parameter \"")  + parameter + core::string("\" which is not float type.");
                                ErrorStringObject(warning, blendTree);
                                ret = false;
                            }
                        }
                    }

                    ret &= ValidateTransitionParameters(this, stateIt->m_State->GetTransitions(), stateIt->m_State->GetName());
                }

                ret &= ValidateTransitionParameters(this, stateMachine->GetAnyStateTransitions(), "AnyState");

                core::string name = core::string(stateMachine->GetName()) + core::string(".Entry");
                ret &= ValidateTransitionParameters(this, stateMachine->GetEntryTransitions(), name.c_str());
            }
        }
    }
    return ret;
}

void AnimatorController::AddStateEffectiveBehaviour(AnimatorState* state, int layerIndex, int instanceID)
{
    if (m_AnimatorLayers[layerIndex].m_SyncedLayerIndex == -1)
    {
        state->AddBehaviour(instanceID);
        DIRTY_AND_INVALIDATE();
    }
    else
    {
        m_AnimatorLayers[layerIndex].AddBehaviour(state, instanceID);
        DIRTY_AND_INVALIDATE();
    }
}

void AnimatorController::RemoveStateEffectiveBehaviour(AnimatorState* state, int layerIndex, int behaviourIndex)
{
    if (m_AnimatorLayers[layerIndex].m_SyncedLayerIndex == -1)
    {
        state->RemoveBehaviour(behaviourIndex);
        DIRTY_AND_INVALIDATE();
    }
    else
    {
        m_AnimatorLayers[layerIndex].RemoveBehaviour(state, behaviourIndex);
        DIRTY_AND_INVALIDATE();
    }
}

StateMachineBehaviourVector AnimatorController::GetEffectiveBehaviours(AnimatorState* state, int layerIndex) const
{
    return m_AnimatorLayers[layerIndex].GetEffectiveBehaviours(state);
}

void    AnimatorController::SetEffectiveBehaviours(AnimatorState* state, int layerIndex, StateMachineBehaviourVector const& behaviours)
{
    m_AnimatorLayers[layerIndex].SetEffectiveBehaviours(state, behaviours);
}

PPtr<MonoScript> AnimatorController::GetBehaviourMonoScript(AnimatorState* state, int layerIndex, int behaviourIndex)
{
    if (m_AnimatorLayers[layerIndex].m_SyncedLayerIndex == -1)
        return state->GetBehaviourMonoScript(behaviourIndex);
    else
        return m_AnimatorLayers[layerIndex].GetBehaviourMonoScript(state, behaviourIndex);
}

#endif


AnimationClipPPtrVector const& AnimatorController::GetAnimationClips() const
{
    const_cast<AnimatorController*>(this)->GetAsset(); // @TODO: Force load the AnimatorController. This is kind of a hack.

    return m_AnimationClips;
}

AnimationClipPPtrVector AnimatorController::GetAnimationClipsToRegister() const
{
    return GetAnimationClips();
}

void AnimatorController::OnInvalidateAnimatorController() {InvalidateAnimatorController(false); }
void AnimatorController::OnInvalidateAnimatorControllerAndRebuildDependencies() {InvalidateAnimatorController(true); }

void AnimatorController::InvalidateAnimatorController(bool rebuildDependencies)
{
#if UNITY_EDITOR
    if (!m_IsAssetBundled)
    {
        ClearAsset();

        {
            ScriptingInvocation invocation(kEditorAssemblyName, "UnityEditor.Animations", "AnimatorController", "OnInvalidateAnimatorController");
            invocation.AddObject(Scripting::ScriptingWrapperFor(this));
            invocation.Invoke();
        }

        {
            // Delegate on AnimatorController are deleted when we go from play mode to stop, so we can't rely on them
            ScriptingInvocation invocation(kEditorGraphsAssemblyName, kGraphsEditorNamespace, "AnimatorControllerCallback", "OnInvalidateAnimatorController");
            invocation.AddObject(Scripting::ScriptingWrapperFor(this));
            invocation.Invoke();
        }
    }

    if (rebuildDependencies)
        RebuildEditorDependencies();
#endif

    NotifyObjectUsers(kDidModifyAnimatorController);
}

mecanim::animation::ControllerConstant* AnimatorController::GetAsset(bool forceBuild)
{
#if UNITY_EDITOR
    if (m_Controller == 0  && forceBuild)
        BuildAsset();
#endif

    return m_Controller;
}

SharedAnimationSetBindingsPtr AnimatorController::GetAnimationSetBindings()
{
#if UNITY_EDITOR
    if (m_AnimationSetBindings == 0)
        BuildAsset();
#endif

    return SharedAnimationSetBindingsPtr(m_AnimationSetBindings);
}

void AnimatorController::ClearAsset()
{
    m_AnimationSetBindings = NULL;
    m_Controller = NULL;
    m_TOS.clear();
    m_Allocator.Reset();

    m_AnimationClips.clear();
    m_StateMachineBehaviours.clear();
    m_StateMachineBehaviourVectorDescription.Clear();

    m_MultiThreadedStateMachine = true;
}

core::string    AnimatorController::StringFromID(unsigned int id) const
{
    TOSVector::const_iterator it = m_TOS.find(id);
    if (it != m_TOS.end())
        return it->second;
    return "";
}

StateMachineBehaviourVector const& AnimatorController::GetBehaviours() const
{
    return m_StateMachineBehaviours;
}

StateMachineBehaviourVectorDescription const& AnimatorController::GetStateMachineBehaviourVectorDescription() const
{
    return m_StateMachineBehaviourVectorDescription;
}

bool AnimatorController::HasMultiThreadedStateMachine() const
{
    return m_MultiThreadedStateMachine;
}

StateMachineBehaviourVector AnimatorController::GetBehaviours(ScriptingClassPtr type)
{
    StateMachineBehaviourVector ret;

    if (!scripting_class_is_subclass_of(type, GetAnimationScriptingClasses().stateMachineBehaviour))
    {
        ErrorStringObject(Format("'%s' is not a sub class of '%s'", scripting_class_get_name(type), scripting_class_get_name(GetAnimationScriptingClasses().stateMachineBehaviour)) , this);
        return ret;
    }

    GetAsset();

    StateMachineBehaviourVector const& behaviours = GetBehaviours();
    StateMachineBehaviourVector::const_iterator it;
    for (it = behaviours.begin(); it != behaviours.end(); ++it)
    {
        PPtr<MonoBehaviour> behaviour = *it;
        if (behaviour.IsNull() || behaviour->GetClass() == SCRIPTING_NULL)
            continue;

        if (type == behaviour->GetClass())
            ret.push_back(behaviour);
        else if (scripting_class_is_subclass_of(behaviour->GetClass(), type))
            ret.push_back(behaviour);
    }

    return ret;
}

#undef DIRTY_AND_INVALIDATE
