#ifndef ANIMATION_H
#define ANIMATION_H

#include "Runtime/GameCode/Behaviour.h"
#include "BoundCurveDeprecated.h"
#include "Runtime/Math/AnimationModes.h"
#include "Runtime/Utilities/LinkedList.h"
#include "Runtime/Utilities/vector_set.h"
#include "Runtime/Geometry/AABB.h"
#include "Runtime/Camera/RendererScene.h"

class AnimationState;
class Transform;

class AnimationClip;
class ShouldRemoveFunctor;

class Animation : public Behaviour
{
    REGISTER_CLASS_TRAITS(kTypeIsSealed);
    REGISTER_CLASS(Animation);
    DECLARE_OBJECT_SERIALIZE();
public:
    enum CullingType
    {
        kCulling_AlwaysAnimate,
        kCulling_BasedOnRenderers,
        kDeprecatedCulling_BasedOnClipBounds,
        kDeprecatedCulling_BasedOnUserBounds
    };

    enum PlayMode
    {
        kStopSameLayer = 0,
        kPlayQueuedDeprecated = 1,
        kPlayMixedDeprecated = 2,
        kStopAll = 4 // This is used as a flag in some places
    };

    struct QueuedAnimation
    {
        PlayMode    mode;
        int         queue;
        float       fadeTime;

        AnimationState* state;
    };

public:
    typedef UNITY_VECTOR (kMemAnimation, PPtr<AnimationClip>) Animations;
    typedef dynamic_array<BoundCurveDeprecated> BoundCurves;
    typedef UNITY_VECTOR (kMemAnimation, AnimationState*) AnimationStates;
    typedef AnimationStates::iterator iterator;
    typedef vector_set<int> SyncedLayers;
    typedef UNITY_VECTOR (kMemAnimation, Renderer*) ContainedRenderers;
    typedef UNITY_VECTOR (kMemAnimation, QueuedAnimation) QueuedAnimations;
    typedef UNITY_VECTOR (kMemAnimation, Transform*) AffectedRootTransforms;
    typedef UNITY_VECTOR_SET (kMemAnimation, PPtr<AnimationClip>) OwnedAnimations;

private:
    WrapMode                     m_WrapMode;///< enum { Default = 0, Once = 1, Loop = 2, PingPong = 4, ClampForever = 8 }
    bool                         m_PlayAutomatically;
    bool                         m_AnimatePhysics;
    bool                         m_Visible;
    CullingType m_CullingType; ///< enum { Always Animate = 0, Based On Renderers = 1 }

    /// When we are animating transforms we cache the affect root transforms
    /// (The top most transform that covers all SendTransformChanged messages that need to sent)
    AffectedRootTransforms   m_CachedAffectedSendToRootTransform;
    int                          m_CachedTransformMessageMask;
    ContainedRenderers           m_ContainedRenderers;

    // new stuff
    BoundCurves                  m_BoundCurves;
    AnimationStates              m_AnimationStates;
    AnimationState*              m_ActiveAnimationStates[32];
    int                          m_ActiveAnimationStatesSize;

    UInt32                       m_DirtyMask;
    ListNode<Animation>    m_AnimationManagerNode;
    SyncedLayers                 m_SyncedLayers;

    PPtr<AnimationClip>          m_Animation;
    Animations                   m_Animations;
    OwnedAnimations              m_OwnedAnimations;

    QueuedAnimations             m_Queued;

#if UNITY_EDITOR
    typedef std::vector<std::pair<core::string, PPtr<AnimationClip> > > OldAnimations;
    OldAnimations                m_OldAnimations;
#endif

    void PlayClip(AnimationClip& animation, PlayMode mode);
    void RecomputeContainedRenderers();
    void RecomputeContainedRenderersRecurse(Transform& transform);
    void ClearContainedRenderers();
    void SampleInternal();
public:
    static void InitializeClass();
    static void CleanupClass();

    Animation(MemLabelId label, ObjectCreationMode mode);
    // virtual ~Animation (); declared-by-macro

    virtual void MainThreadCleanup();

    /// Are any animation states playing?
    /// (Returns true even if the animation state has a zero blend weight)
    /// (Unaffected by animation.enabled or animation.visible)
    bool IsPlaying();

    /// Is the
    /// (Returns true even if the animation state has a zero blend weight)
    /// (Unaffected by animation.enabled or animation.visible)
    bool IsPlaying(const core::string& name);

    /// Is the animation state playing?
    /// (Returns true even if the animation state has a zero blend weight)
    /// (Unaffected by animation.enabled or animation.visible)
    bool IsPlaying(const AnimationState& state);

    /// Is any animation in the layer playing?
    /// (Returns true even if the animation state has a zero blend weight)
    /// (Unaffected by animation.enabled or animation.visible)
    bool IsPlayingLayer(int layer);

    /// Stops all animations that were started from this component with play or play named!
    void Stop();
    /// Stops all animations that were started from this component with name!
    void Stop(const core::string& name);
    void Stop(AnimationState& state);


    void Rewind();
    void Rewind(const core::string& name);
    void Rewind(AnimationState& state);

    void SyncLayer(int layer) { m_SyncedLayers.insert(layer); }

    void SetWrapMode(WrapMode mode);
    WrapMode GetWrapMode() { return m_WrapMode; }

    PPtr<AnimationClip> GetClip() const { return m_Animation; }
    void SetClip(PPtr<AnimationClip> anim);

    const Animations& GetClips() const { return m_Animations; }
    void SetClips(const Animations& anims);

    //  PPtr<AnimationClip> GetNamedClip (const core::string& name);

    virtual void AwakeFromLoad(AwakeFromLoadMode awakeMode);
    virtual void Deactivate(DeactivateOperation operation);

    bool GetPlayAutomatically() const { return m_PlayAutomatically; }
    void SetPlayAutomatically(bool b) { m_PlayAutomatically = b; SetDirty(); }

    void SetCullingType(CullingType type);
    CullingType GetCullingType() const { return m_CullingType; }

    void CheckRendererVisibleState();

    // Exposed for Renderer
    void SetVisibleRenderers(bool visible);
    // Exposed for UnityScene
    void SetVisibleBounds(bool visible);

    virtual void AddToManager();
    virtual void RemoveFromManager();

    bool Play(const core::string& name, PlayMode playMode);
    void Play(AnimationState& fadeIn, PlayMode playMode);
    bool Play(PlayMode playMode);

    ///
    void Blend(const core::string& name, float targetWeight, float time);
    void Blend(AnimationState& fadeIn, float targetWeight, float time);

    void CrossFade(const core::string& name, float time, PlayMode mode);
    void CrossFade(AnimationState& fadeIn, float time, PlayMode mode, bool clearQueuedAnimations);

    enum QueueMode { CompleteOthers = 0, PlayNow = 2 };

    AnimationState* QueueCrossFade(const core::string& name, float time, int queue, PlayMode mode);
    AnimationState* QueueCrossFade(AnimationState& originalState, float time, int queue, PlayMode mode);

    AnimationState* QueuePlay(const core::string& name, int queue, PlayMode mode) { return QueueCrossFade(name, 0.0F, queue, mode); }
    AnimationState* QueuePlay(AnimationState& originalState, int queue, PlayMode mode) { return QueueCrossFade(originalState, 0.0F, queue, mode); }

    /// Adds an animation clip with name newName to the animation.
    /// - If newName is not the clip's name or the animation clip needs to be clipped a new instance of the clip will be created.
    void AddClip(AnimationClip& clip, const core::string& newName, int firstFrame = INT_MIN, int lastFrame = INT_MAX, bool loop = false);

    /// Adds an animation clip to the animation. If it already exists this will do nothing.
    void AddClip(AnimationClip& clip);

    /// Removes an named clip
    void RemoveClip(AnimationClip& clip);
    void RemoveClip(const core::string &clipName);

    /// Get the number of clips in the animation
    int GetClipCount() const;

    void SyncLayerTime(int layer);

    iterator begin() { return m_AnimationStates.begin(); }
    iterator end() { return m_AnimationStates.end(); }

    /// State management
    AnimationState& GetAnimationStateAtIndex(int index) { BuildAnimationStates(); return *m_AnimationStates[index]; }
    int GetAnimationStateCount() { BuildAnimationStates(); return m_AnimationStates.size(); }

    AnimationState* GetState(const core::string& name);
    AnimationState* GetState(AnimationClip* clip);
    AnimationState* GetState(AnimationState* state);

    AnimationState* CloneAnimation(AnimationState* state);

    /// Returns the animation clip named name
    /// - This will onyl search the serialized animation array and not touch animation states at all!
    AnimationClip* GetClipWithNameSerialized(const core::string& name);

    void UpdateAnimation(double time);
    void SampleDefaultClip(double time);

    void RebuildStateForEverything();
    bool RebuildBoundStateMask();

    void Sample();

    void BlendOptimized();
    void BlendGeneric();
    void BlendAdditive();

    void SortAnimationStates();
    void ReleaseAnimationStates();
    void ReleaseOwnedAnimations();

    void ApplyObjectSlow(Object* lastObject);

#if UNITY_EDITOR
    void LoadOldAnimations();  // Deprecated with 1.5
#endif
    void SendTransformChangedToCachedTransform();
    void SetTransformsSetDirty() const;
    void RemoveContainedRenderer(Renderer* renderer);

    void SetAnimatePhysics(bool anim);
    bool GetAnimatePhysics() { return m_AnimatePhysics; }

    void CleanupBoundCurves();
    void ValidateBoundCurves();

    void EnsureDefaultAnimationIsAdded();

    AABB GetLocalAABB() const { return AABB::zero; }
    void SetLocalAABB(const AABB& aabb) {}

    #if UNITY_EDITOR
    /// Forces the inspector auto refresh without setdirty being called but only in debug mode
    virtual bool HasDebugmodeAutoRefreshInspector() { return true; }
    #endif

private:

    AnimationClip* GetClipLegacyWarning(AnimationClip* clip);

    void CheckIsCullingBasedOnBoundsDeprecated() const { Assert(m_CullingType != kDeprecatedCulling_BasedOnClipBounds); Assert(m_CullingType != kDeprecatedCulling_BasedOnUserBounds); }
    void SetVisibleInternal(bool visible);
    void BuildAnimationStates();
    void UpdateQueuedAnimations(bool& needsUpdate);
    void RemoveClip(const ShouldRemoveFunctor& functor, const char * clipName);
};

#endif
