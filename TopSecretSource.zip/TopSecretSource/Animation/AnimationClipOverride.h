#pragma once


#include "Runtime/Serialize/Blobification/offsetptr.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Animation/MecanimArraySerialization.h"
#include "Runtime/Animation/AnimationClip.h"

struct AnimationClipOverride
{
    DEFINE_GET_TYPESTRING(AnimationClipOverride)

    PPtr<AnimationClip> m_OriginalClip;
    PPtr<AnimationClip> m_OverrideClip;

    template<class TransferFunction>
    inline void Transfer(TransferFunction& transfer)
    {
        TRANSFER(m_OriginalClip);
        TRANSFER(m_OverrideClip);
    }

    bool operator==(AnimationClipOverride const& other) const {return m_OriginalClip == other.m_OriginalClip && m_OverrideClip == other.m_OverrideClip; }

    PPtr<AnimationClip> GetEffectiveClip() const {return !m_OverrideClip.IsNull() ? m_OverrideClip : m_OriginalClip; }
};

struct FindClip
{
    PPtr<AnimationClip> const& m_Clip;
    FindClip(PPtr<AnimationClip> const& clip) : m_Clip(clip) {}

    bool operator()(PPtr<AnimationClip> const& clip) { return m_Clip == clip; }
};

struct FindClipByName
{
    char const* m_ClipName;
    FindClipByName(char const* clipName) : m_ClipName(clipName) {}

    bool operator()(PPtr<AnimationClip> const& clip) { return strcmp(clip->GetName(), m_ClipName) == 0; }
};

struct FindOriginalClipByName
{
    char const* m_ClipName;
    FindOriginalClipByName(char const* clipName) : m_ClipName(clipName) {}

    bool operator()(AnimationClipOverride const& overrideClip) { return strcmp(overrideClip.m_OriginalClip->GetName(), m_ClipName) == 0; }
};

struct FindOriginalClip
{
    PPtr<AnimationClip> const& m_Clip;
    FindOriginalClip(PPtr<AnimationClip> const& clip) : m_Clip(clip) {}

    bool operator()(AnimationClipOverride const& overrideClip) { return overrideClip.m_OriginalClip == m_Clip; }
};

PPtr<AnimationClip> return_original(AnimationClipOverride const& overrideClip);
PPtr<AnimationClip> return_override(AnimationClipOverride const& overrideClip);
PPtr<AnimationClip> return_effective(AnimationClipOverride const& overrideClip);


typedef dynamic_array<AnimationClipOverride> AnimationClipOverrideVector;
