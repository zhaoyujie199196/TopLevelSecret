#pragma once

#include "Runtime/BaseClasses/NamedObject.h"
#include "Runtime/Misc/UserList.h"
#include "Runtime/Math/Vector3.h"

class MessageIdentifier;
class AnimationClip;
typedef dynamic_array<PPtr<AnimationClip> > AnimationClipPPtrVector;

class Motion : public NamedObject
{
    REGISTER_CLASS_TRAITS(kTypeIsAbstract);
    REGISTER_CLASS(Motion);
public:

    Motion(MemLabelId label, ObjectCreationMode mode);

    virtual void MainThreadCleanup();

    void NotifyObjectUsers(const MessageIdentifier& msg);
    void AddObjectUser(UserList& user);
    UserList& GetUserList() { return m_ObjectUsers; }

    virtual float GetAverageDuration() const = 0;
    virtual float GetAverageAngularSpeed() const = 0;
    virtual Vector3f GetAverageSpeed() const = 0;
    virtual float GetApparentSpeed() const = 0;
    virtual bool IsHumanMotion() const = 0;
    virtual bool IsLooping() const = 0;

#if UNITY_EDITOR
    virtual AnimationClipPPtrVector GetAnimationClips() const = 0;

    virtual void ExtractDependenciesFromGraph(dynamic_array<PPtr<Object> >& dependencies) { Assert(false); }
#endif

    virtual bool IsLegacy() const = 0;
    virtual void AddSelfToDependencies(UserList& dependencies) { dependencies.AddUser(GetUserList()); }


private:
    UserList         m_ObjectUsers;
};
