#ifndef EDITABLEAVATARCONTROLLER_H
#define EDITABLEAVATARCONTROLLER_H

#include "Runtime/BaseClasses/NamedObject.h"
#include "Runtime/BaseClasses/MessageIdentifier.h"
#include "Runtime/BaseClasses/RefCounted.h"
#include "Runtime/mecanim/memory.h"
#include "Runtime/Animation/MecanimUtility.h"
#include "Runtime/Animation/RuntimeAnimatorController.h"
#include "Runtime/Animation/AnimatorControllerParameter.h"
#include "Runtime/Animation/StateMachineBehaviourInfo.h"
#include "Runtime/Misc/UserList.h"

template<class T> class PPtr;
class AnimationClip;
class StateMachine;
class AvatarMask;
class Animator;

#if UNITY_EDITOR

#include "Editor/Src/Animation/AnimatorControllerLayer.h"
#include "Editor/Src/Animation/StateMachineBehaviourContext.h"

struct StateInfo
{
    PPtr<AnimatorState> m_State;
    core::string            m_Path;
    core::string            m_FullPath;

    int GetFullPathHash() const;
};

struct StateMachineInfo
{
    PPtr<AnimatorStateMachine>  m_StateMachine;
    core::string                    m_FullPath;

    int GetFullPathHash() const;
};

typedef std::vector<StateInfo>          StateInfoVector;
typedef std::vector<StateMachineInfo>   StateMachineInfoVector;

bool IsParent(const StateMachineInfo &stateMachineInfo, const StateInfo &stateInfo);

#endif

class AnimatorController : public RuntimeAnimatorController
{
    REGISTER_CLASS(AnimatorController);
    DECLARE_OBJECT_SERIALIZE();
public:

    AnimatorController(MemLabelId label, ObjectCreationMode mode);

    static void InitializeClass();

    virtual void AwakeFromLoad(AwakeFromLoadMode mode);
    virtual void CheckConsistency();

    virtual void MainThreadCleanup();

#if UNITY_EDITOR

    AnimatorControllerLayer & GetLayer(int index) { return m_AnimatorLayers[index]; }
    const AnimatorControllerLayer & GetLayer(int index) const { return m_AnimatorLayers[index]; }

    const AnimatorControllerLayerVector& GetLayers() const;
    void SetLayers(AnimatorControllerLayerVector& layers);

    const AnimatorControllerParameterVector& GetParameters() const;
    void SetParameters(AnimatorControllerParameterVector& parameters);

    void RenameParameter(const core::string& oldName, const core::string& newName);


    AnimatorStateMachine* GetLayerEffectiveStateMachine(int layerIndex) const;

    std::vector<PPtr<Object> >          CollectObjectsUsingParameter(const core::string& parameterName);
    /////////////////////////////////////////////

    core::string MakeUniqueParameterName(const core::string& newName) const;
    core::string MakeUniqueLayerName(const core::string& newName) const;

    int IndexOfParameter(const core::string& name) const;

    void    RemovedDependenciesToDeletingObject();

    void                        AddStateEffectiveBehaviour(AnimatorState* state, int layerIndex, int instanceID);
    void                        RemoveStateEffectiveBehaviour(AnimatorState* state, int layerIndex, int behaviourIndex);
    StateMachineBehaviourVector GetEffectiveBehaviours(AnimatorState* state, int layerIndex) const;
    void                        SetEffectiveBehaviours(AnimatorState* state, int layerIndex, StateMachineBehaviourVector const& behaviours);


    PPtr<MonoScript> GetBehaviourMonoScript(AnimatorState* state, int layerIndex, int behaviourIndex);


private:
    void RebuildEditorDependencies();
    void CleanStateMotionPair();
    void BuildAsset();
    void BuildStateMachineBehavioursInfo(AnimatorControllerLayer const& animatorLayer, mecanim::int32_t  layerIndex, StateInfoVector const& statesInfo, StateMachineInfoVector const& stateMachinesInfo);


    AnimatorControllerLayerVector           m_AnimatorLayers;
    AnimatorControllerParameterVector       m_AnimatorParameters;
    UserList                                m_Dependencies;

    void                                    CheckConsistency_Pre_5_0();
    bool                                    m_ShouldCallPre_5_0_CheckConsistency;

    bool ValidateParameters();

    mecanim::ValueArrayConstant*    BuildParameters(TOSVector& tos, mecanim::memory::Allocator& allocator) const;
    mecanim::ValueArray*            BuildParametersDefaultValue(mecanim::ValueArrayConstant* values, mecanim::memory::Allocator& allocator) const;

    void ExtractDependenciesFromGraph(dynamic_array<PPtr<Object> >& dependencies);
    void CheckLayersConsistency();
#endif // UNITY_EDITOR

public:

    virtual SharedAnimationSetBindingsPtr GetAnimationSetBindings();
    virtual AnimationClipPPtrVector const& GetAnimationClips() const;

    virtual mecanim::animation::ControllerConstant* GetAsset(bool forceBuild = true);


    virtual core::string    StringFromID(unsigned int ID) const;
    void OnInvalidateAnimatorController();
    void OnInvalidateAnimatorControllerAndRebuildDependencies();
    void InvalidateAnimatorController(bool rebuildDependencies);
    bool IsAssetBundled() { return m_IsAssetBundled; }

    virtual StateMachineBehaviourVector const&  GetBehaviours() const;
    virtual StateMachineBehaviourVectorDescription const&   GetStateMachineBehaviourVectorDescription() const;

    virtual bool                                    HasMultiThreadedStateMachine() const;

    StateMachineBehaviourVector GetBehaviours(ScriptingClassPtr type);

private:

    void ClearAsset();
    void OnAnimationClipDeleted();
    virtual AnimationClipPPtrVector GetAnimationClipsToRegister() const;


    AnimationClipPPtrVector                             m_AnimationClips;
    bool                                                m_IsAssetBundled;

    mecanim::memory::ChainedAllocator                   m_Allocator;
    mecanim::animation::ControllerConstant*             m_Controller;
    UInt32                                              m_ControllerSize;
    UnityEngine::Animation::AnimationSetBindings*       m_AnimationSetBindings;
    TOSVector                                           m_TOS;

    bool                                                m_MultiThreadedStateMachine;

    StateMachineBehaviourVectorDescription              m_StateMachineBehaviourVectorDescription;
    StateMachineBehaviourVector                         m_StateMachineBehaviours;

    template<class Transferfunction> void TransferRuntimeData(Transferfunction& transfer);
    template<class Transferfunction> void TransferRuntimeDataFromEditorForBuild(Transferfunction& transfer);
};


#endif //EDITABLEAVATARCONTROLLER_H
