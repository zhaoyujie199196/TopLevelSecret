#pragma once

#include "Runtime/mecanim/memory.h"
#include "Runtime/Animation/Avatar.h"
#include "Runtime/Transform/Transform.h"

namespace UnityEngine
{ namespace Animation
{ struct AvatarBindingConstant; } }

class HumanPoseHandler
{
    mecanim::memory::MecanimAllocator m_Alloc;

    mecanim::animation::AvatarConstant *m_AvatarConstant;
    Transform *m_Root;
    UnityEngine::Animation::AvatarBindingConstant *m_BindingConstant;

    mecanim::skeleton::SkeletonPoseT<math::trsX> *m_AvatarSkeletonPose;
    mecanim::skeleton::SkeletonPoseT<math::trsX> *m_AvatarSkeletonPoseWs;

    mecanim::skeleton::SkeletonPoseT<math::trsX> *m_HumanSkeletonPose;
    mecanim::skeleton::SkeletonPoseT<math::trsX> *m_HumanSkeletonPoseWsA;
    mecanim::skeleton::SkeletonPoseT<math::trsX> *m_HumanSkeletonPoseWsB;
    mecanim::skeleton::SkeletonPoseT<math::trsX> *m_HumanSkeletonPoseWsC;
    mecanim::skeleton::SkeletonPoseT<math::trsX> *m_HumanSkeletonPoseWsD;

public:

    HumanPoseHandler(Avatar *avatar, Transform *root);
    virtual ~HumanPoseHandler();

    void GetHumanPose(Vector3f &bodyPosition, Quaternionf &bodyRotation, float *muscles);
    void SetHumanPose(Vector3f &bodyPosition, Quaternionf &bodyRotation, float *muscles);
};
