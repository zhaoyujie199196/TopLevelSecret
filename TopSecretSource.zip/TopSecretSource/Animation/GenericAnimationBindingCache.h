#pragma once

#include "Runtime/Utilities/dynamic_array.h"
#include "EditorCurveBinding.h"
#include "Runtime/BaseClasses/TypeInfo.h"
#include "Runtime/Scripting/ScriptingTypes.h"
#include "BoundCurve.h"

typedef UInt32 BindingHash;

class GameObject;
class MonoScript;
class Object;
class Transform;
template<class T> class PPtr;


class IAnimationBinding;

namespace UnityEngine
{
namespace Animation
{
    struct CachedComponentBindings;
    struct GenericBinding;

    struct CachedBinding
    {
        BindingHash   propertyHash;
        int           offset;
        int           bindType;
        const Unity::Type* objectReferenceType;
#if ENABLE_DOTNET
        DotNetField const* field;
        int index;
#endif
    };


    bool IsMuscleBinding(const GenericBinding& binding);
    bool IsTransformType(const Unity::Type* type);

    inline bool AnimationFloatToBool(float result)
    {
        //@TODO: Maybe we should change the behaviour to be that > 0.01F means enabled instead of the close to zero logic....
        return result > 0.001F || result < -0.001F;
    }

    inline float AnimationBoolToFloat(bool value)
    {
        return value ? 1.0F : 0.0F;
    }

    class GenericAnimationBindingCache
    {
    public:

        GenericAnimationBindingCache();
        ~GenericAnimationBindingCache();

        const Unity::Type* BindGeneric(const GenericBinding& inputBinding, Transform& transform, BoundCurve& bound);
        const Unity::Type* BindPPtrGeneric(const GenericBinding& inputBinding, Transform& transform, BoundCurve& bound);

        void            CreateGenericBinding(const core::string& path, const Unity::Type* type, PPtr<MonoScript> script, const core::string& attribute, bool pptrCurve, GenericBinding& outputBinding) const;

        static void     DidReloadDomain();

        void            RegisterIAnimationBinding(const Unity::Type* type, int inCustomType, IAnimationBinding* bindingInterface);

        // Editor API
        void            GetAllAnimatableProperties(GameObject& gameObject, GameObject& root, std::vector<EditorCurveBinding>& outProperties);
        void            GetAnimatableProperties(MonoBehaviour &behaviour, std::vector<EditorCurveBinding>& outProperties);

        core::string        SerializedPropertyPathToCurveAttribute(Object& target, const char* propertyPath) const;
        core::string        CurveAttributeToSerializedPath(GameObject& root, const EditorCurveBinding& binding) const;

    private:

        typedef dynamic_array<CachedComponentBindings*> CachedComponentBindingArray;

        const Unity::Type* BindGenericComponent(const GenericBinding& inputBinding, Transform& transform, BoundCurve& bound);
        const Unity::Type* BindScript(const GenericBinding& inputBinding, Transform& transform, BoundCurve& bound);
        const Unity::Type* BindCustom(const GenericBinding& inputBinding, Transform& transform, BoundCurve& bound) const;

        static void Clear(CachedComponentBindingArray& array);

        struct CustomBinding
        {
            const Unity::Type*  type;
            int                 customBindingType;
        };

        dynamic_array<CustomBinding>        m_CustomBindings;
        dynamic_array<IAnimationBinding*>   m_CustomBindingInterfaces;

        CachedComponentBindingArray         m_Classes;
        CachedComponentBindingArray         m_Scripts;
        BindingHash                         m_IsActiveHash;
    };

    GenericAnimationBindingCache& GetGenericAnimationBindingCache();

    void InitializeGenericAnimationBindingCache(void*);
    void CleanupGenericAnimationBindingCache(void*);

    // Runtime API
    // NOt sure if i like this???
    //  void    CreateGenericBinding (const core::string& path, int typeInfo, PPtr<MonoScript> script, const core::string& attribute, bool pptrCurve, GenericBinding& outputBinding);
    void    CreateTransformBinding(const core::string& path, int bindType, GenericBinding& outputBinding);

    float   GetBoundCurveFloatValue(const BoundCurve& bind);
    // Returns true if BoundCurveValueAwakeGeneric should be called on this object.
    bool    SetBoundCurveFloatValue(const BoundCurve& bind, float value);

    // Returns true if BoundCurveValueAwakeGeneric should be called on this object.
    bool        SetBoundCurveInstanceIDValue(const BoundCurve& bind, InstanceID value);
    InstanceID  GetBoundCurveInstanceIDValue(const BoundCurve& bind);

    void    BoundCurveValueAwakeGeneric(Object& targetObject);

#if UNITY_EDITOR
    // Editor API.
    // Returns the Type of the bound value. (NULL if it could not be bound)
    const Unity::Type* GetFloatValue(GameObject& root, const EditorCurveBinding& binding, float* value);
    const Unity::Type* GetPPtrValue(GameObject& root, const EditorCurveBinding& binding, InstanceID* instanceID);

    bool BindEditorCurve(GameObject& root, const EditorCurveBinding& binding, BoundCurve& boundCurve);

    Object* FindAnimatedObject(GameObject& root, const EditorCurveBinding& inputBinding);

    const Unity::Type* GetEditorCurveValueType(GameObject& root, const EditorCurveBinding& binding);
    const Unity::Type* GetEditorCurveValueType(MonoBehaviour& behaviour, const EditorCurveBinding& binding);
#endif
}
}
