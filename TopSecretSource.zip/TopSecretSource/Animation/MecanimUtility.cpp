#include "UnityPrefix.h"

#include "MecanimUtility.h"

#include "Runtime/mecanim/generic/crc32.h"


core::string BuildTransitionName(core::string srcName, core::string dstName)
{
    return (srcName != "" ? srcName : "Entry") + " -> " + (dstName != "" ? dstName : "Exit");
}

core::string FileName(const core::string &fullpath)
{
    core::string fullpathCopy(fullpath);
    ConvertSeparatorsToUnity(fullpathCopy);
    return GetLastPathNameComponent(StandardizePathName(fullpathCopy));
}

core::string FileNameNoExt(const core::string &fullpath)
{
    return DeletePathNameExtension(FileName(fullpath));
}

unsigned int ProccessString(TOSVector& tos, core::string const& str)
{
    unsigned int crc32 = mecanim::processCRC32(str.c_str());
    TOSVector::iterator it = tos.find(crc32);
    if (it == tos.end())
    {
        tos.insert(std::make_pair(crc32, str));
    }
    return crc32;
}

core::string FindString(TOSVector const& tos, unsigned int crc32)
{
    TOSVector::const_iterator it = tos.find(crc32);
    if (it != tos.end())
        return it->second;

    return core::string("");
}
