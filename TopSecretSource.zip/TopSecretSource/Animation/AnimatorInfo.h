#pragma once

#include "Runtime/BaseClasses/GameObject.h"

class AnimationClip;

struct AnimatorClipInfo
{
    PPtr<AnimationClip> clip;
    float               weight;

    AnimatorClipInfo()
    {
        Clear();
    }

    void Clear()
    {
        weight = 0;
    }
};

struct MonoAnimatorClipInfo
{
    InstanceID clipInstanceID;
    float weight;
};

void AnimatorClipInfoToMono(const AnimatorClipInfo& src, MonoAnimatorClipInfo &dest);

/// This struct must be kept in sync with the C# version in Animator.bindings
struct AnimatorTransitionInfo
{
    int     fullPathHash;
    int     userNameHash;
    int     nameHash;
    float   normalizedTime;
    bool    anyState;
    int     transitionType;

    AnimatorTransitionInfo()
    {
        Clear();
    }

    void Clear()
    {
        fullPathHash = 0;
        userNameHash = 0;
        nameHash = 0;
        normalizedTime = 0;
        anyState = false;
        transitionType = 0;
    }
};

/// This struct must be kept in sync with the C# version in Animator.bindings
struct AnimatorStateInfo
{
    int    nameHash;
    int    pathHash;
    int    fullPathHash;
    float  normalizedTime;
    float  length;
    float  speed;
    float  speedMultiplier;
    int    tagHash;
    int    loop;

    AnimatorStateInfo()
    {
        Clear();
    }

    void Clear()
    {
        pathHash = 0;
        nameHash = 0;
        fullPathHash = 0;
        normalizedTime = 0;
        length = 0;
        speed = 0;
        speedMultiplier = 0;
        tagHash = 0;
        loop = 0;
    }
};
