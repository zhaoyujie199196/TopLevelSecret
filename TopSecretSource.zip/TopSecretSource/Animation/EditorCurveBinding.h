#pragma once

#include "Runtime/Mono/MonoScript.h"

struct EditorCurveBinding
{
    core::string         path;
    core::string         attribute; ///@TODO: Rename to propertyName, thats how it is called in C#
    const Unity::Type*  type;
    MonoScriptPPtr      script;
    bool                isPPtrCurve;
    bool                isPhantom;

    EditorCurveBinding()
    {
        script = NULL;
        isPPtrCurve = false;
        type = 0;
        isPhantom = false;
    }

    EditorCurveBinding(const core::string& inPath, const Unity::Type* inTypeInfo, MonoScriptPPtr inScript, const core::string& inAttribute, bool inIsPPtrCurve)
    {
        path = inPath;
        type = inTypeInfo;
        script = inScript;
        attribute = inAttribute;
        isPPtrCurve = inIsPPtrCurve;
        isPhantom = false;
    }

    friend bool operator==(const EditorCurveBinding& lhs, const EditorCurveBinding& rhs)
    {
        return lhs.path == rhs.path && lhs.attribute == rhs.attribute && lhs.type == rhs.type
            && lhs.script == rhs.script && lhs.isPPtrCurve == rhs.isPPtrCurve;
    }
};
