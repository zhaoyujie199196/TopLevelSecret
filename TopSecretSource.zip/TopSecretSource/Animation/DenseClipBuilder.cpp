#include "UnityPrefix.h"
#include "DenseClipBuilder.h"

void CreateDenseClip(mecanim::animation::DenseClip& clip, UInt32 curveCount, float begin, float end, float sampleRate, mecanim::memory::Allocator& alloc)
{
    // We always need at least two frame to sample the clip
    clip.m_FrameCount = std::max(CeilfToInt((end - begin) * sampleRate) + 1, 2);
    clip.m_CurveCount = curveCount;
    clip.m_SampleRate = sampleRate;
    clip.m_BeginTime = begin;

    clip.m_SampleArraySize = clip.m_FrameCount * clip.m_CurveCount;
    clip.m_SampleArray = alloc.ConstructArray<float>(clip.m_SampleArraySize);
}

template<class T>
void AddCurveToDenseClip(mecanim::animation::DenseClip& clip, int curveIndex, const AnimationCurveTpl<T>& curve)
{
    for (int i = 0; i < clip.m_FrameCount; i++)
    {
        float time = clip.m_BeginTime + ((float)i / clip.m_SampleRate);

        float* dst = &clip.m_SampleArray[i * clip.m_CurveCount + curveIndex];

        T value = curve.EvaluateClamp(time);
        *reinterpret_cast<T*>(dst) = value;
    }
}

template void AddCurveToDenseClip<float>(mecanim::animation::DenseClip& clip, int curveIndex, const AnimationCurveTpl<float>& curve);
template void AddCurveToDenseClip<Vector3f>(mecanim::animation::DenseClip& clip, int curveIndex, const AnimationCurveTpl<Vector3f>& curve);
template void AddCurveToDenseClip<Quaternionf>(mecanim::animation::DenseClip& clip, int curveIndex, const AnimationCurveTpl<Quaternionf>& curve);
