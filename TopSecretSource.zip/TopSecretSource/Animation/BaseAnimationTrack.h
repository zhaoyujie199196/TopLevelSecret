#if UNITY_EDITOR
#ifndef BASEANIMATIONTRACK_H
#define BASEANIMATIONTRACK_H

#include "Runtime/BaseClasses/NamedObject.h"

template<class T> class AnimationCurveTpl;
typedef AnimationCurveTpl<float> AnimationCurve;

class BaseAnimationTrack : public NamedObject
{
    REGISTER_CLASS_TRAITS(kTypeIsAbstract, kTypeIsEditorOnly);
    REGISTER_CLASS(BaseAnimationTrack);
public:


    BaseAnimationTrack(MemLabelId label, ObjectCreationMode mode);
    // ~BaseAnimationTrack (); declared-by-macro
};

#endif
#endif
