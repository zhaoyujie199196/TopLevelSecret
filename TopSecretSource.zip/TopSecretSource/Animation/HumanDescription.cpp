#include "UnityPrefix.h"

#include "HumanDescription.h"

#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/Scripting/ScriptingExportUtility.h"

void SkeletonBoneToMono(const SkeletonBone &src, MonoSkeletonBone &dest)
{
    dest.name = scripting_string_new(src.m_Name);
    dest.parentName = scripting_string_new(src.m_ParentName);
    dest.position = src.m_Position;
    dest.rotation = src.m_Rotation;
    dest.scale = src.m_Scale;
}

void SkeletonBoneFromMono(const MonoSkeletonBone &src, SkeletonBone &dest)
{
    dest.m_Name = scripting_cpp_string_for(src.name);
    dest.m_ParentName = scripting_cpp_string_for(src.parentName);
    dest.m_Position = src.position;
    dest.m_Rotation = src.rotation;
    dest.m_Scale = src.scale;
}

void HumanLimitToMono(const SkeletonBoneLimit &src, MonoHumanLimit &dest)
{
    dest.m_UseDefaultValues = src.m_Modified ? 0 : 1;
    dest.m_Min = src.m_Min;
    dest.m_Max = src.m_Max;
    dest.m_Center = src.m_Value;
    dest.m_AxisLength = src.m_Length;
}

void HumanLimitFromMono(const MonoHumanLimit &src, SkeletonBoneLimit &dest)
{
    dest.m_Modified = src.m_UseDefaultValues == 1 ? false : true;
    dest.m_Min = src.m_Min;
    dest.m_Max = src.m_Max;
    dest.m_Value = src.m_Center;
    dest.m_Length = src.m_AxisLength;
}

void HumanBoneToMono(const HumanBone &src, MonoHumanBone &dest)
{
    dest.m_BoneName = scripting_string_new(src.m_BoneName);
    dest.m_HumanName = scripting_string_new(src.m_HumanName);
    HumanLimitToMono(src.m_Limit, dest.m_Limit);
}

void HumanBoneFromMono(const MonoHumanBone &src, HumanBone &dest)
{
    dest.m_BoneName = scripting_cpp_string_for(src.m_BoneName);
    dest.m_HumanName = scripting_cpp_string_for(src.m_HumanName);
    HumanLimitFromMono(src.m_Limit, dest.m_Limit);
}

void HumanDescriptionToMono(const HumanDescription &src, MonoHumanDescription &dest)
{
    dest.m_Skeleton = VectorToScriptingStructArray<SkeletonBone, MonoSkeletonBone>(src.m_Skeleton,  GetAnimationScriptingClasses().skeletonBone, SkeletonBoneToMono);
    dest.m_Human = VectorToScriptingStructArray<HumanBone, MonoHumanBone>(src.m_Human,  GetAnimationScriptingClasses().humanBone, HumanBoneToMono);

    dest.m_ArmTwist = src.m_ArmTwist;
    dest.m_ForeArmTwist = src.m_ForeArmTwist;

    dest.m_UpperLegTwist = src.m_UpperLegTwist;
    dest.m_LegTwist = src.m_LegTwist;
    dest.m_ArmStretch = src.m_ArmStretch;
    dest.m_LegStretch = src.m_LegStretch;
    dest.m_FeetSpacing = src.m_FeetSpacing;

    dest.m_HasTranslationDoF = src.m_HasTranslationDoF;
}

void HumanDescriptionFromMono(const MonoHumanDescription &src, HumanDescription &dest)
{
    ScriptingStructArrayToVector<SkeletonBone, MonoSkeletonBone>(src.m_Skeleton, dest.m_Skeleton, SkeletonBoneFromMono);
    ScriptingStructArrayToVector<HumanBone, MonoHumanBone>(src.m_Human, dest.m_Human, HumanBoneFromMono);

    dest.m_ArmTwist = src.m_ArmTwist;
    dest.m_ForeArmTwist = src.m_ForeArmTwist;

    dest.m_UpperLegTwist = src.m_UpperLegTwist;
    dest.m_LegTwist = src.m_LegTwist;
    dest.m_ArmStretch = src.m_ArmStretch;
    dest.m_LegStretch = src.m_LegStretch;
    dest.m_FeetSpacing = src.m_FeetSpacing;

    dest.m_HasTranslationDoF = src.m_HasTranslationDoF;
}
