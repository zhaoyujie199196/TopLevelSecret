#ifndef MECANIM_UTILITY_H
#define MECANIM_UTILITY_H

#include "Runtime/Math/Vector3.h"
#include "Runtime/Allocator/BaseAllocator.h"
#include "Runtime/Misc/AllocatorLabels.h"

#include "Runtime/mecanim/memory.h"
#include "Runtime/Math/Simd/vec-trs.h"
#include "Runtime/Math/DeprecatedConversion.h"

#include "Runtime/Serialize/Blobification/BlobWrite.h"

#include <algorithm>

core::string BuildTransitionName(core::string srcStateName, core::string dstStateName);

typedef std::map<mecanim::uint32_t, core::string> TOSVector;

static inline void xform2unity(math::trsX const& x, Vector3f& t, Quaternionf& q, Vector3f& s)
{
    math::vstore3f(t.GetPtr(), x.t);
    math::vstore4f(q.GetPtr(), x.q);
    math::vstore3f(s.GetPtr(), x.s);
}

static inline math::trsX xformFromUnity(Vector3f const& t, Quaternionf const& q, Vector3f const& s)
{
    return math::trsX(Vector3fTofloat3(t), QuaternionfTofloat4(q), Vector3fTofloat3(s));
}

static inline float MakeNiceFloat(float f)
{
    float signf = math::sign(f);
    f = math::abs(f);

    union
    {
        float f;
        UInt32 n;
    } u;
    u.f = f;

    int exponent = ((u.n & 0x7F800000) >> 23) - 127;

    if (exponent >= 24)
        return math::chgsign(f, signf);

    if (exponent <= -24)
        return 0;

    UInt32 v = (UInt32)f;
    float fraction = f - v;

    if (fraction < 0.00001f)
        return math::chgsign(float(v), signf);

    if (fraction > 0.99999f)
        return math::chgsign(float(v + 1), signf);

    return math::chgsign(f, signf);
}

static inline math::float3 MakeNiceFloat3(const math::float3& v)
{
    return math::float3(MakeNiceFloat(v.x), MakeNiceFloat(v.y), MakeNiceFloat(v.z));
}

core::string FileName(const core::string &fullpath);
core::string FileNameNoExt(const core::string &fullpath);

unsigned int ProccessString(TOSVector& tos, core::string const& str);
core::string FindString(TOSVector const& tos, unsigned int crc32);

template<typename T> inline T* CopyBlob(T const& data, mecanim::memory::Allocator& allocator, size_t& size)
{
    // 1. Make a deep copy of 'data' into container 'blob'
    BlobWrite::container_type blob;
    BlobWrite blobWrite(blob, kNoTransferInstructionFlags, kBuildNoTargetPlatform);
    blobWrite.SetReduceCopy(false);
    blobWrite.TransferBase(const_cast<T&>(data));

    // 2. Copy the memory block into a block allocated by allocator.
    // to respect memory alignment for all data we must allocate this memory block with the same alignment constraint than the container
    UInt8* ptr = reinterpret_cast<UInt8*>(allocator.Allocate(blob.size(), BlobWrite::container_type::align));
    if (ptr != 0)
        memcpy(ptr, blob.begin(), blob.size());

    size = blob.size();
    return reinterpret_cast<T*>(ptr);
}

#endif
