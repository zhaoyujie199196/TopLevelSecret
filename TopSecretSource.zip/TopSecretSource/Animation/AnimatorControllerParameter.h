#pragma once

#include "Runtime/BaseClasses/NamedObject.h"
#include "Runtime/Math/Vector3.h"

#include "Runtime/Scripting/ScriptingUtility.h"

class AnimatorController;

// This enum need to match
//  Runtime/mecanim/generic/typetraits.h ValueType enum
//  Editor/Mono/AnimatorController.bindings AnimatorControllerParameterType enum
enum AnimatorControllerParameterType
{
    AnimatorControllerParameterTypeFloat = 1,
    AnimatorControllerParameterTypeInt = 3,
    AnimatorControllerParameterTypeBool = 4,
    AnimatorControllerParameterTypeTrigger = 9,
};


class AnimatorControllerParameter
{
public:

    AnimatorControllerParameter();

    DECLARE_SERIALIZE(AnimatorControllerParameter)

    char const* GetName() const;
    void SetName(char const *name);

    AnimatorControllerParameterType GetType() const;
    void SetType(AnimatorControllerParameterType type);

    float GetDefaultFloat() const;
    void SetDefaultFloat(float val);

    int GetDefaultInt() const;
    void SetDefaultInt(int val);

    bool GetDefaultBool() const;
    void SetDefaultBool(bool val);

    AnimatorController* GetController() const;
    void SetController(AnimatorController* controller);

public: // for bindings
    core::string                        m_Name;
    AnimatorControllerParameterType m_Type;

    float                           m_DefaultFloat;
    int                             m_DefaultInt;
    bool                            m_DefaultBool;

private:

    PPtr<AnimatorController>         m_Controller;  // used to set unique name
};

typedef std::vector<AnimatorControllerParameter>        AnimatorControllerParameterVector;

struct MonoAnimatorControllerParameter
{
public:
    ScriptingStringPtr              m_Name;
    int                             m_Type;
    float                           m_DefaultFloat;
    int                             m_DefaultInt;
    bool                            m_DefaultBool;
};

void AnimatorControllerParameterToMono(const AnimatorControllerParameter& src, MonoAnimatorControllerParameter& dst);
void AnimatorControllerParameterToCpp(const MonoAnimatorControllerParameter& src, AnimatorControllerParameter& dst);
