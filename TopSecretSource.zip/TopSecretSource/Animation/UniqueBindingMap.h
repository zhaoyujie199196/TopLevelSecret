#pragma once
#include "External/google/sparsehash/dense_hash_map.h"
#include "Runtime/Animation/AnimationClipBindings.h"
#include "Runtime/mecanim/generic/typetraits.h"
#include "Runtime/Mono/MonoScript.h"

namespace UnityEngine
{
namespace Animation
{
    struct BoundIndex
    {
        enum { kNotInitialized = 0, kIsConstant = 2, kIsNotConstant = 3 };

        mecanim::ValueType  type;
        int                 index;

        int                 constantType;
        float               constantValue[4];

        BoundIndex()
        {
            constantType = kNotInitialized;
            type = mecanim::kLastType;
            index = -1;
        }
    };

    struct GenericBindingHashFunctor
    {
        inline size_t operator()(GenericBinding x) const
        {
            return (x.AttributeForComparison() * 65537) ^ x.path;
        }
    };

    struct GenericBindingValueArrayUnique
        : public std::binary_function<GenericBinding, GenericBinding, bool>
    {
        bool operator()(const GenericBinding& lhs, const GenericBinding& rhs) const
        {
            if (lhs.path != rhs.path ||
                lhs.AttributeForComparison() != rhs.AttributeForComparison() ||
                lhs.typeID != rhs.typeID ||
                ((lhs.customType != rhs.customType) && (lhs.IsRotation() != rhs.IsRotation())) ||
                lhs.isPPtrCurve != rhs.isPPtrCurve)
                return false;

            if (lhs.script == rhs.script)
                return true;

            if (lhs.script.GetInstanceID() != InstanceID_None && rhs.script.GetInstanceID() != InstanceID_None)
            {
                MonoScript* lhsMonoScript = dynamic_pptr_cast<MonoScript*>(lhs.script);
                MonoScript* rhsMonoScript = dynamic_pptr_cast<MonoScript*>(rhs.script);
                if (lhsMonoScript != NULL && rhsMonoScript != NULL)
                    return lhsMonoScript->GetClass() == rhsMonoScript->GetClass();
            }

            return false;
        }
    };

    typedef UNITY_DENSE_HASH_MAP (kMemTempAlloc, GenericBinding, BoundIndex, GenericBindingHashFunctor, GenericBindingValueArrayUnique) UniqueBindingMap;
}
}
