#pragma once


#include "Runtime/Director/Core/DirectorTypes.h"

#include "Runtime/GameCode/Behaviour.h"
#include "Runtime/Animation/AvatarPlayback.h"
#include "Runtime/Animation/AnimationClipStats.h"
#include "Runtime/Animation/AnimatorControllerParameter.h"
#include "Runtime/Misc/UserList.h"
#include "Runtime/Jobs/JobTypes.h"

#include "Runtime/mecanim/statemachine/statemachinemessage.h"
#include "Runtime/Animation/StateMachineBehaviourInfo.h"
#include "Runtime/Animation/StateMachineBehaviourPlayer.h"
#include "Runtime/Animation/AnimatorInfo.h"
#include "Runtime/Animation/AnimatorDefines.h"
#include "Runtime/Animation/Director/AnimationPlayable.h"
#include "Runtime/Animation/AnimationClipBindings.h"
#include "Runtime/Misc/GarbageCollectSharedAssetsMarking.h"
#include "Runtime/Animation/OptimizeTransformHierarchy.h"

#include "Runtime/Math/Simd/vec-transform.h"

#include "Runtime/BaseClasses/IsPlaying.h"

class AnimatorControllerPlayable;
class AnimationPlayable;
class PlayableGraph;
class AnimationPlayableOutput;
class PlayableOutput;

namespace math
{
    struct trsX;
}

class Avatar;
class Renderer;
class Transform;
class AnimationClip;
class AnimatorController;
class RuntimeAnimatorController;
class AnimatorOverrideController;

namespace mecanim
{
namespace animation
{
    struct AvatarConstant;
    struct AvatarInput;
    struct AvatarOutput;
    struct AvatarMemory;
    struct AvatarWorkspace;
    struct ControllerConstant;
    struct ControllerInput;
    struct ControllerMemory;
    struct ControllerWorkspace;
    struct AnimatorOverrideController;
    struct AnimationSetMemory;
    struct BlendTreeNodeConstant;
    struct BlendTreeWorkspace;
    struct BlendingLayer;
}

namespace skeleton
{
    template<typename transformType> struct SkeletonPoseT;
    typedef SkeletonPoseT<math::trsX> SkeletonPose;
}

namespace human
{
    struct HumanPose;
}

namespace statemachine
{
    struct StateMachineConstant;
    struct StateMachineMemory;
}
}

namespace UnityEngine
{
namespace Animation
{
    struct AvatarBindingConstant;
    struct AnimatorGenericBindingConstant;
    struct AnimatorTransformBindingConstant;
    struct AnimationSetBindings;
}
}

/// This struct must be kept in sync with the C# version in Animator.bindings
struct MatchTargetWeightMask
{
    MatchTargetWeightMask(Vector3f positionXYZWeight, float rotationWeight)
        : m_PositionXYZWeight(positionXYZWeight), m_RotationWeight(rotationWeight) {}

    Vector3f m_PositionXYZWeight;
    float m_RotationWeight;
};

enum AnimatorRecorderMode
{
    eOffline = 0,
    ePlayback = 1,
    eRecord = 2
};

struct WeightedPlayable
{
    WeightedPlayable(HPlayable playable, float weight) : m_Weight(weight), m_Playable(playable) {}

    AnimationPlayable* GetPlayable() const
    {
        if (m_Playable.IsValid())
            return static_cast<AnimationPlayable*>(m_Playable.GetPlayable());

        return NULL;
    }

    bool IsValid() const
    {
        return m_Playable.IsValid();
    }

    float m_Weight;
    HPlayable  m_Playable;
};

struct BoundPlayable
{
    BoundPlayable(PlayableOutput *output);

    PlayableOutput* GetPlayableOutput() const;
    AnimationPlayable* GetPlayable() const;
    int GetPortIndex() const { return m_PortIndex; }
    bool IsValid() const { return m_Playable.IsValid(); }

private:
    HPlayableOutput m_PlayableOutput;
    HPlayable   m_Playable;
    int         m_PortIndex;
};

typedef dynamic_array<PPtr<AnimationClip> > AnimationClipPPtrVector;
typedef dynamic_array<AnimationClip*>      AnimationClips;
typedef dynamic_array<HPlayable>          AnimationPlayables;
typedef dynamic_array<BoundPlayable>      BoundPlayables;
typedef dynamic_array<WeightedPlayable>   WeightedPlayables;

class Animator : public Behaviour
{
    REGISTER_CLASS(Animator);
    DECLARE_OBJECT_SERIALIZE();
public:

    enum CullingMode { kCullNone = 0, kCullRetargetIKWrite = 1, kCullAll = 2 };

    enum UpdateMode { kNormal = 0, kAnimatePhysics = 1, kUnscaledTime = 2 };

    enum AnimatorPass
    {
        kAnimatorPassNone = 1 << 0,
        kOnAnimatorMove = 1 << 1,
        kOnAnimatorIK = 1 << 2,
        kFiringEvents = 1 << 3,
        kWritingFloatPropertyValues = 1 << 4,
        kSampling = 1 << 5,
        kWritingDisallowed = 1 << 6
    };

    struct ScopedAnimatorPass
    {
        ScopedAnimatorPass(int& animatorActivePasses, AnimatorPass pass)
            : m_AnimatorActivePasses(animatorActivePasses), m_Pass(pass)
        {
            m_AnimatorActivePasses |= m_Pass;
        }

        ~ScopedAnimatorPass()
        {
            m_AnimatorActivePasses &= ~m_Pass;
        }

        int& m_AnimatorActivePasses;
        AnimatorPass m_Pass;
    };

    struct AnimatorJob
    {
        AnimatorJob(TransformHierarchy* transformHierarchy, Animator* animator, AnimationPlayable* playable, float weight) :
            m_TransformHierarchy(transformHierarchy), m_Animator(animator), m_Playables(kMemTempJobAlloc),
            m_TempEventInfos(kMemTempJobAlloc)
        {
            m_Playables.push_back(WeightedPlayable(playable->Handle(), weight));
        }

        void AddPlayable(AnimationPlayable * playable, float weight);

        TransformHierarchy*                 m_TransformHierarchy;
        Animator*                           m_Animator;
        WeightedPlayables                   m_Playables;
        AnimationClipEventInfos             m_TempEventInfos;
    };

    typedef dynamic_array<AnimatorJob> AnimatorJobs;
    typedef dynamic_array<AnimatorJobs> AnimatorWriteJobs;

    static void SortJobsBasedOnHierarchy(AnimatorJobs const &jobs, AnimatorWriteJobs &writeJobs);
    static void WriteLoop(AnimatorWriteJobs &writeJobs);


    static void InitializeClass();
    static void CleanupClass();

    Animator(MemLabelId label, ObjectCreationMode mode);

    virtual void AwakeFromLoad(AwakeFromLoadMode mode);
    virtual void Deactivate(DeactivateOperation operation);
    virtual void Reset();
    virtual void CheckConsistency();
    virtual void MainThreadCleanup();

    void Rebind(bool writeDefaultValues);

    void UpdateWithDelta(float deltaTime);
    void EvaluateController(float deltaTime);

    virtual void FixedUpdate() {}
    bool Sample(AnimationClip& clip, float inTime);

    virtual void TransformChanged(int changeMask);

    void OnAddComponent(Component* com);

    RuntimeAnimatorController* GetRuntimeAnimatorController() const;
    void SetRuntimeAnimatorController(RuntimeAnimatorController* animation);

    bool HasBoundPlayables() const;

    AnimatorController* GetAnimatorController() const;
    AnimatorOverrideController* GetAnimatorOverrideController() const;

    Avatar* GetAvatar();
    void SetAvatar(Avatar* avatar);

    const mecanim::animation::AvatarConstant* GetAvatarConstant();

    bool IsOptimizable() const;
    bool IsHuman() const;
    bool HasRootMotion() const;
    bool IsRootTranslationOrRotationControllerByCurves() const;
    float GetHumanScale() const;

    bool        GetMuscleValue(int id, float *value);

    bool        IsInIKPass();

    GetSetValueResult ParameterControlledByCurve(int id);

    Vector3f    GetAvatarPosition();
    Quaternionf GetAvatarRotation();
    Vector3f    GetAvatarScale();

    void        SetAvatarPosition(const Vector3f& rootPosition);
    void        SetAvatarRotation(const Quaternionf& rootRotation);
    void        SetAvatarScale(const Vector3f&rootScale);

    Vector3f    GetDeltaPosition();
    Quaternionf GetDeltaRotation();

    Vector3f    GetVelocity();
    Vector3f    GetAngualrVelocity();

    Vector3f    GetBodyPosition();
    Quaternionf GetBodyRotation();

    void        SetBodyPosition(const Vector3f& rootPosition);
    void        SetBodyRotation(const Quaternionf& rootRotation);

    float       GetPivotWeight();
    Vector3f    GetPivotPosition();

    bool        GetApplyRootMotion() const             { return m_ApplyRootMotion; }
    void        SetApplyRootMotion(bool rootMotion);

    bool        GetLinearVelocityBlending() const       { return m_LinearVelocityBlending; }
    void        SetLinearVelocityBlending(bool linearVelocityBlending);

    UpdateMode              GetUpdateMode() const                   { return m_UpdateMode; }
    void                    SetUpdateMode(UpdateMode mode);
    void                    OnUpdateModeChanged();
    DirectorUpdateMode      GetTimeUpdateMode() const { return m_UpdateMode == kUnscaledTime ? kUnscaledGameTime : kGameTime; }

    float       GetGravityWeight();

    bool        SupportsOnAnimatorMove();

    void        MatchTarget(Vector3f const& matchPosition, Quaternionf const& matchRotation, int targetIndex, const MatchTargetWeightMask& mask,  float startNormalizedTime, float targetNormalizedTime);
    void        InterruptMatchTarget(bool completeMatch = true);
    bool        IsInMatchTargetState() const;
    bool        IsMatchingTarget() const;
    bool        ShouldInterruptMatchTarget() const;

    void        SetTarget(int targetIndex, float targetNormalizedTime);
    Vector3f    GetTargetPosition();
    Quaternionf GetTargetRotation();


    void        SetSpeed(float speed);
    float       GetSpeed() const;

    bool        IsBoneTransform(Transform *transform);
    Transform*  GetBoneTransform(int humanBoneId);

    void        SetBoneLocalRotation(int humanBoneId, Quaternionf rotation);

    Vector3f    GetGoalPosition(int index);
    void        SetGoalPosition(int index, Vector3f const& pos);

    Quaternionf GetGoalRotation(int index);
    void        SetGoalRotation(int index, Quaternionf const& rot);

    void        SetGoalWeightPosition(int index, float value);
    void        SetGoalWeightRotation(int index, float value);

    float       GetGoalWeightPosition(int index);
    float       GetGoalWeightRotation(int index);

    Vector3f    GetHintPosition(int index);
    void        SetHintPosition(int index, Vector3f const& pos);

    void        SetHintWeightPosition(int index, float value);
    float       GetHintWeightPosition(int index);

    void        SetLookAtPosition(Vector3f lookAtPosition);
    void        SetLookAtClampWeight(float weight);
    void        SetLookAtBodyWeight(float weight);
    void        SetLookAtHeadWeight(float weight);
    void        SetLookAtEyesWeight(float weight);


    void        SetCullingMode(CullingMode mode);
    CullingMode GetCullingMode() const             { return m_CullingMode; }
    void        OnCullingModeChanged();


    void        GetRootBlendTreeConstantAndWorkspace(int layerIndex, int stateHash, mecanim::animation::BlendTreeNodeConstant const* & constant, mecanim::animation::BlendTreeWorkspace*& workspace);

    float       GetFeetPivotActive();
    void        SetFeetPivotActive(float value);

    bool        GetStabilizeFeet();
    void        SetStabilizeFeet(bool value);

    float       GetLeftFeetBottomHeight();
    float       GetRightFeetBottomHeight();

    void        WriteHumanPose(mecanim::human::HumanPose &pose);
    void        WriteDefaultPose();
#if UNITY_EDITOR
    void        WriteDefaultValues();
#endif

    void        WriteDefaultValuesNoDirty();
    // This function can be called from a job.
    // If you call this function from a job you must dependency chain it with GetReadWriteGlobalSpaceSkeletonPoseFence with the job that will consume the data.
    // GetGlobalSpaceSkeletonPose might allocate some tempMemory, after the memory has been used you must call FreeGlobalSpaceSkeletonPose.
    const mecanim::skeleton::SkeletonPoseT<math::affineX>* GetGlobalSpaceSkeletonPose(mecanim::skeleton::SkeletonPoseT<math::affineX>** allocatedTempMemory, int rootIndex, math::float4 &rootRotation) const;
    static void FreeGlobalSpaceSkeletonPose(mecanim::skeleton::SkeletonPoseT<math::affineX>* tempMemory);

    inline JobFence& GetReadWriteGlobalSpaceSkeletonPoseFence() { return m_WriteGlobalPoseFence; }

    void StartPlayback();
    void SetPlaybackTime(float time);
    float GetPlaybackTime();
    void StopPlayback();
    AnimatorRecorderMode GetRecorderMode() const;


    ///////////////////////////////////////////
    // DirectorPlayer
    virtual void SetPrepareStage();
    void OnPlayableBind(AnimationPlayableOutput *playableOutput);
    void OnPlayableUnbind(AnimationPlayableOutput *playableOutput);
    void OnGraphTopologyChanged(Playable* root, int outputPort);
    ///////////////////////////////////////////


    void PrepareForPlayback();
    void StartRecording(int frameCount = 0);
    void StopRecording();

    float GetRecorderStartTime();
    float GetRecorderStopTime();

    static void UpdateAvatars(const PlayableOutputArray& jobs, bool doFKMove, bool doRetargetIKWrite, bool updateGraph);

    static void BuildJobs(const PlayableOutputArray& outputs,  AnimatorJobs& animatorJobs, AnimatorJobs* humanoidJobs, bool FKPass, bool updateGraph);

    bool IsAvatarInitialized() const { return m_AvatarDataSet.m_Initialized; }
    bool IsInitialized() const;

    void SetLayersAffectMassCenter(bool value);
    bool GetLayersAffectMassCenter() const;

    void SetHasTransformHierarchy(bool value);
    bool GetHasTransformHierarchy() const { return m_HasTransformHierarchy; }

    void SetAllowConstantClipSamplingOptimization(bool value);
    bool GetAllowConstantClipSamplingOptimization();


    GET_SET(bool, LogWarnings, m_LogWarnings);
    GET_SET(bool, FireEvents, m_FireEvents);

    core::string GetPerformanceHints();
    core::string GetStats();
    AnimationClipStats GetClipStats() const;

    AnimationClips const& GetAnimationClips() const;

    Transform*  GetAvatarRoot();
    TransformHierarchy* GetTransformHierarchy() const;

    virtual StateMachineBehaviourVector const*  GetStateMachineBehaviours() const;

    bool IsVisible() const{return m_Visible; }

    void ApplyBuiltinRootMotion();

    MonoBehaviour* GetBehaviour(ScriptingClassPtr type);
    StateMachineBehaviourVector GetBehaviours(ScriptingClassPtr type);

    AnimatorController* GetEffectiveAnimatorController();
    AnimatorControllerPlayable* FindAnimatorControllerPlayable(AnimatorController* controller);

    static int ScriptingStringToCRC32(ICallString& stringValue);

    ///////////////////////////////////
    // Forwarded to m_ControllerPlayable
    AnimatorControllerPlayable* GetAnimatorControllerPlayable() { return m_ControllerPlayable; }

    GetSetValueResult   GetFloat(int id, float& value, bool sampling = false);
    GetSetValueResult   SetFloat(int id, float value);
    GetSetValueResult   SetFloatDamp(int id, float value, float dampTime, float deltaTime);

    GetSetValueResult   GetInteger(int id, int& output);
    GetSetValueResult   SetInteger(int id, int integer);

    GetSetValueResult   GetBool(int id, bool& output);
    GetSetValueResult   SetBool(int id, bool value);

    GetSetValueResult   ResetTrigger(int id);
    GetSetValueResult   SetTrigger(int id);

    bool                HasParameter(int id);

    void                ValidateParameterString(GetSetValueResult result, const core::string& parameterName);
    void                ValidateParameterID(GetSetValueResult result, int identifier);

    int                 GetLayerCount() const;
    core::string            GetLayerName(int layerIndex);
    int                 GetLayerIndex(const core::string& layerName);
    float               GetLayerWeight(int layerIndex);
    void                SetLayerWeight(int layerIndex, float w);

    AnimatorControllerParameterVector GetParameters();

    bool                IsInTransition(int layerIndex) const;

    bool        GetAnimatorStateInfo(int layerIndex, StateInfoIndex stateInfoIndex, AnimatorStateInfo& output) const;
    bool        GetAnimatorTransitionInfo(int layerIndex, AnimatorTransitionInfo& output) const;
    bool        GetAnimatorClipInfo(int layerIndex, bool currentState, dynamic_array<AnimatorClipInfo>& output);
    int         GetAnimatorClipInfoCount(int layerIndex, bool currentState);

    bool        HasState(int layerIndex, int stateID) const;

    core::string    GetAnimatorStateName(int layerIndex, bool currentState);
    core::string    ResolveHash(int hash);


    void        GotoState(int layer, int stateId, float normalizedTime, float transitionDuration, float transitionTime = 0.0F);
    void        GotoStateInFixedTime(int layerIndex, int stateId, float fixedTime, float fixedTransitionDuration, float normalizedTransitionTime = 0.0F);


    virtual DirectorPlayerType GetPlayerType() const { return kAnimation; }

    const HPlayableGraph& GetGraphHandle() const { return m_PlayableGraph; }

    /////////////////////////////////////////

    static void BatchedFKPass(const PlayableOutputArray& jobs);
    static void BatchedIKPass(const PlayableOutputArray& jobs);

protected:

    struct BindingsDataSet
    {
        BindingsDataSet(MemLabelId label)
            : m_GenericBindingConstant(0)
            , m_AnimationSetBindings(0)
            , m_Alloc(label)
        {}

        UnityEngine::Animation::AnimatorGenericBindingConstant*     m_GenericBindingConstant;
        AnimationSetBindingsPtr                                     m_AnimationSetBindings;
        mecanim::memory::MecanimAllocator                           m_Alloc;

        void Reset();
    };

    struct AvatarDataSet
    {
        AvatarDataSet(MemLabelId label)
            : m_AvatarConstant(0)
            , m_AvatarInput(0)
            , m_AvatarOutput(0)
            , m_AvatarMemory(0)
            , m_AvatarWorkspace(0)
            , m_AvatarBindingConstant(0)
            , m_AvatarMemorySize(0)
            , m_OwnsAvatar(false)
            , m_Initialized(false)

            , m_Alloc(label)

        {}

        mecanim::animation::AvatarConstant const*       m_AvatarConstant;
        mecanim::animation::AvatarInput*                m_AvatarInput;
        mecanim::animation::AvatarOutput*               m_AvatarOutput;
        mecanim::animation::AvatarMemory*               m_AvatarMemory;
        mecanim::animation::AvatarWorkspace*            m_AvatarWorkspace;

        UnityEngine::Animation::AvatarBindingConstant*  m_AvatarBindingConstant;

        size_t                                          m_AvatarMemorySize;
        bool                                            m_OwnsAvatar;
        bool                                            m_Initialized;

        mecanim::memory::MecanimAllocator               m_Alloc;

        void Reset();
    };

    // Used by Animator::Sample to auto unregister bindings.
    struct AutoMecanimDataSet
    {
        AvatarDataSet                                   m_AvatarDataSet;
        BindingsDataSet                                 m_BindingsDataSet;

        mecanim::animation::ControllerConstant*         m_ControllerConstant;
        mecanim::animation::ControllerMemory*           m_ControllerMemory;

        AutoMecanimDataSet(MemLabelId label)
            : m_AvatarDataSet(label)
            , m_BindingsDataSet(label)
            , m_ControllerConstant(0)
            , m_ControllerMemory(0)
        {}

        ~AutoMecanimDataSet();

        void Reset();
    };


    AnimationPlayableEvaluationConstant m_PlayableConstant;

    void ClearAnimatorController();
    void ClearObject();
    void CreateObject();

    void CreateBindings();
    void ClearBindings();
    void UpdateOverrideControllerBindings();

    void CreatePlayableGraph();
    void CreateInternalControllerPlayable();
    void ClearInternalControllerPlayable();

    void CreatePlayableMemory();


    void InitializeAvatar();
    void SetupAvatarDataSet(mecanim::animation::AvatarConstant const* avatarConstant, Animator::AvatarDataSet& outMecanimDataSet, bool sampling);
    void SetupBindingsDataSet(AnimationSetBindingsPtr animationSetBindings,
        Animator::BindingsDataSet& bindings, Animator::AvatarDataSet& avatar);

    void CollectAnimatedRenderers(Animator::BindingsDataSet const& dataSet);


    void WriteSkeletonPose(mecanim::skeleton::SkeletonPose& pose);

    bool Prepare();
    void InitStep(float deltaTime);
    void ProcessAnimationsStep(AnimatorJob& animatorJob);
    void RetargetStep();
    void IKStep();
    void WriteStep();
    void WriteProperties(float deltaTime, float realDeltaTime);
    void ApplyOnAnimatorIK(int layerIndex, AnimatorJob &job);
    void ApplyOnAnimatorMove(AnimatorJob &job);
    void PrepareAnimationEvents(AnimatorJob &job);
    void FireAnimationEvents(AnimatorJob &job);
    bool FireBehaviours(mecanim::statemachine::StateMachineMessage filter, AnimatorJob &job);


    void Record(float deltaTime);

    void ClearRelatedPropertyBlocks();

    // Visibility culling
    void ClearContainedRenderers();
    void RecomputeContainedRenderersRecurse(Transform& transform);
    void InitializeVisibilityCulling();
    void SetVisibleRenderers(bool visible);
    bool IsAnyRendererVisible() const;
    void RemoveContainedRenderer(void* renderer);

    void SyncPlayStateToCulling();

    static void AnimatorVisibilityCallback(void* userData, void* sender, int visibilityEvent);
#ifdef UNITY_EDITOR
    static void RebindOnDomainReload();
#endif


    static void ProcessAnimationsJob(AnimatorJob* jobData, unsigned int i);
    static void RetargeterJob(AnimatorJob* jobData, unsigned int i);
    static void IKJob(AnimatorJob* jobData, unsigned int i);
    static void WriteJob(AnimatorJob* jobData, unsigned int i);
    static void WriteJobs(AnimatorJobs* jobData, unsigned int i);

    BoundPlayables                              m_BoundPlayables;
    AnimationPlayableEvaluationOutput           m_EvaluationOutput;


    bool                                        m_Visible;

    CullingMode                                 m_CullingMode; ///< enum { Always Animate = 0, Cull Update Transforms = 1, Cull Completely = 2 }
    UpdateMode                                  m_UpdateMode;  ///< enum { Normal = 0, Animate Physics = 1, Unscaled Time = 2 };

    int                                         m_AnimatorActivePasses;

    PPtr<Avatar>                                m_Avatar;
    PPtr<RuntimeAnimatorController>             m_Controller;

    mecanim::memory::MecanimAllocator           m_HeapAlloc;

    AvatarDataSet                               m_AvatarDataSet;
    BindingsDataSet                             m_BindingsDataSet;

    JobFence                                    m_WriteGlobalPoseFence;


    AutoMecanimDataSet                          m_SamplingDataSets;

    Vector3f                                    m_DeltaPosition;
    Quaternionf                                 m_DeltaRotation;

    Vector3f                                    m_Velocity;
    Vector3f                                    m_AngularVelocity;

    Vector3f                                    m_PivotPosition;

    Vector3f                                    m_TargetPosition;
    Quaternionf                                 m_TargetRotation;

    float                                       m_MatchStartTime;
    int                                         m_MatchStateID;
    Vector3f                                    m_MatchPosition;
    Quaternionf                                 m_MatchRotation;
    MatchTargetWeightMask                       m_MatchTargetMask;
    bool                                        m_MustCompleteMatch;

    bool                                        m_ApplyRootMotion;
    bool                                        m_LinearVelocityBlending;

    float                                       m_Speed;

    bool                                        m_LogWarnings;
    bool                                        m_FireEvents;
    bool                                        m_HasStateMachineBehaviour;


    void BuildControllerPlayableCache();
    void ClearFirstEvaluationFlag();

    AnimatorControllerPlayables                 m_ControllerPlayableCache;
    int                                         m_ControllerPlayableCacheLayerCount;


#if UNITY_EDITOR
protected:
    // Used by editor to show warning when something happen on the animator
    core::string                                    m_WarningMessage;
public:
    void ClearWarning() {m_WarningMessage = ""; }
    void LogWarning(const core::string& warning) {m_WarningMessage += "\n"; m_WarningMessage += warning; }
    void HandleGenericBindingError(dynamic_array<std::pair<Transform *, BindingHash> > const& transforms, bool isOptimizedHierarchy);
protected:
#endif

    typedef dynamic_array<PPtr<Renderer> >     ContainedRenderers;
    ContainedRenderers                          m_ContainedRenderers;
    ContainedRenderers                          m_RenderersToClear;


    UserListNode    m_AnimatorAvatarNode;
    UserList        m_PlayableNodes;
    UserList        m_AnimatorControllerNode;

    AvatarPlayback          m_AvatarPlayback;
    AnimatorRecorderMode    m_RecorderMode;
    float                   m_PlaybackDeltaTime;
    float                   m_PlaybackTime; // for query back
    bool                    IsPlayingBack();
    bool                    IsAutoPlayingBack();


    bool            m_AllowConstantClipSamplingOptimization;
    bool            m_HasTransformHierarchy;


    void SetPlaybackTimeInternal(float time);


    bool HasOnlySingleLayeredController();

    void TargetMatch();

    bool ValidateHasAnimatorController() const;
    bool ValidateHasPlayable() const;

    bool ValidateGoalIndex(int index);
    bool ValidateTargetIndex(int index);


    template<typename T>
    GetSetValueResult SetValue(mecanim::uint32_t id, T const& value);

    template<typename T>
    GetSetValueResult GetValue(mecanim::uint32_t id, T& value, bool sampling = false);

    void WarningStringIfLoggingActive(const char* warning) const;
    void WarningStringIfLoggingActive(const core::string& warning) const;

    const mecanim::animation::ControllerConstant* GetControllerConstant() const;
    mecanim::animation::ControllerMemory* GetControllerMemory() const;
    mecanim::animation::ControllerWorkspace* GetControllerWorkspace() const;
    mecanim::animation::ControllerInput* GetControllerInput() const;
    const mecanim::statemachine::StateMachineConstant* GetStateMachineConstant(int layerIndex) const;
    const mecanim::statemachine::StateMachineMemory* GetStateMachineMemory(int layerIndex) const;

    void SetupAnimationClipsCache();
    void SetupPlayableConstant();
    mutable AnimationClips m_CachedAnimationClips;

    AnimatorControllerPlayable*     m_ControllerPlayable;
private:

    bool HasAnimatorController() const;
    AnimatorControllerPlayable* GetControllerPlayable() const;

    virtual void AddToManager();
    virtual void RemoveFromManager();

    friend void OptimizeTransformHierarchy(GameObject& root, const core::string* exposedTransforms, size_t exposedTransformCount);

    HPlayableGraph              m_PlayableGraph;
    HPlayableOutput             m_PlayableOutput;
};
