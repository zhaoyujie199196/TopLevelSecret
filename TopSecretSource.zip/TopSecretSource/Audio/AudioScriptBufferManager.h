/*
 *  AudioScriptBufferManager.h
 *  AllTargets.workspace
 *
 *  Created by Søren Christiansen on 8/22/11.
 *  Copyright 2011 Unity Technologies. All rights reserved.
 *
 */
#ifndef UNITY_AUDIOSCRIPTBUFFERMANAGER_H
#define UNITY_AUDIOSCRIPTBUFFERMANAGER_H

#include "Runtime/Scripting/ScriptingTypes.h"
#include "Runtime/Threads/Mutex.h"

struct MonoArray;


class AudioScriptBufferManager
{
public:
    AudioScriptBufferManager();
    ~AudioScriptBufferManager();

    void Init();
    void Cleanup();
    void BeforeDomainReload();
    void DidReloadDomain();


    void GetDSPFilterArray(unsigned length, ScriptingArrayPtr &array);
    void GetPCMReadArray(unsigned length, ScriptingArrayPtr &array);
    inline Mutex& GetDSPFilterArrayMutex() { return m_DSPFilterArrayMutex; }
    inline Mutex& GetPCMReadArrayMutex() { return m_PCMReadArrayMutex; }

private:
    ScriptingGCHandle m_PCMReadArrayGCHandle;
    unsigned m_PCMReadArrayOrigLength;

    ScriptingGCHandle m_DSPFilterArrayGCHandle;
    unsigned m_DSPFilterArrayOrigLength;

    #if ENABLE_MONO
    inline void PatchLength(ScriptingArrayPtr array, unsigned newlength);
    #endif

    // We have 2 separate mutexes here, because it is possible to be running a callback from the mixer thread (AudioSource.OnAudioFilterRead) concurrently with
    // a streamed AudioClip.Create PCM read callback.
    Mutex m_DSPFilterArrayMutex;
    Mutex m_PCMReadArrayMutex;
};

#endif // UNITY_AUDIOSCRIPTBUFFERMANAGER_H
