#ifndef __AUDIOSOURCE_FILTER_H__
#define __AUDIOSOURCE_FILTER_H__

#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "AudioManager.h"
#include "Runtime/GameCode/Behaviour.h"
#include "Runtime/Audio/correct_fmod_includer.h"

using namespace Unity;

class AudioFilter : public Behaviour
{
    REGISTER_CLASS_TRAITS(kTypeIsAbstract);
    REGISTER_CLASS(AudioFilter);
    DECLARE_OBJECT_SERIALIZE();
public:

    AudioFilter(MemLabelId label, ObjectCreationMode mode) : Behaviour(label, mode), m_Type(FMOD_DSP_TYPE_UNKNOWN), m_DSP(NULL) {}

    virtual void MainThreadCleanup();

    FMOD::DSP* GetDSP();

    virtual void RemoveFromManager();
    virtual void AddToManager();
    virtual void AwakeFromLoad(AwakeFromLoadMode mode);

    void Init();
    void Cleanup();
protected:
    FMOD_DSP_TYPE m_Type;
    FMOD::DSP* m_DSP;
    friend class AudioManager;
};

#endif // __AUDIOSOURCE_FILTER_H__
