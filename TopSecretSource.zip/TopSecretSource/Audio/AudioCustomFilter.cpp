/*
 *  AudioCustomFilter.cpp
 *  Xcode
 *
 *  Created by Søren Christiansen on 9/12/10.
 *  Copyright 2010 Unity Technologies. All rights reserved.
 *
 */
#include "UnityPrefix.h"
#include "AudioCustomFilter.h"
#include "AudioSource.h"
#include "Runtime/Mono/MonoBehaviour.h"
#include "Runtime/Mono/MonoIncludes.h"
#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/Mono/MonoScriptCache.h"
#include "Runtime/Scripting/ScriptingScopedThreadAttach.h"
#include "Runtime/Threads/Mutex.h"
#include "Runtime/Threads/Thread.h"
#include "Runtime/Profiler/TimeHelper.h"

#if UNITY_EDITOR
#include "Editor/Src/AssetPipeline/MonoCompile.h"
#endif

#include "Runtime/Scripting/Scripting.h"

MemLabelRootId* gAudioCustomFilterRootContainer = NULL;

static void StaticInitializeAudioCustomFilterRoot(void*)
{
    gAudioCustomFilterRootContainer = UNITY_NEW_AS_ROOT(MemLabelRootId, kMemAudio, "OnAudioFilterRead filters", "") ();
}

static void StaticDestroyAudioCustomFilterRoot(void*)
{
    UNITY_DELETE(gAudioCustomFilterRootContainer, kMemAudio);
}

static RegisterRuntimeInitializeAndCleanup s_AudioCustomFilterRootCallbacks(StaticInitializeAudioCustomFilterRoot, StaticDestroyAudioCustomFilterRoot);

AudioCustomFilter::AudioCustomFilter(MonoBehaviour* behaviour) :
#if SUPPORT_SCRIPTING_THREADS
    scriptingDomain(NULL),
#endif
    m_DSP(NULL),
    m_behaviour(behaviour),
    m_InScriptCallback(false),
    m_SavedBypassState(false),
    m_playingSource(NULL),
    m_playingListener(NULL)
#if UNITY_EDITOR
    ,
    processTime(0.0),
    channelCount(0)
#endif
{
    Init();
}

AudioCustomFilter::~AudioCustomFilter()
{
    Cleanup();
}

void AudioCustomFilter::Init()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    // setup dsp/callbacks
    if (!m_DSP)
    {
        FMOD_DSP_DESCRIPTION  dspdesc;

        memset(&dspdesc, 0, sizeof(FMOD_DSP_DESCRIPTION));

#if UNITY_EDITOR
        const size_t max_name_len = sizeof(dspdesc.name) - 1;
        strncpy(dspdesc.name, m_behaviour->GetScriptClassName().c_str(), max_name_len);
#endif
        dspdesc.channels     = 0;                   // 0 = whatever comes in, else specify.
        dspdesc.read         = AudioCustomFilter::readCallback;
        dspdesc.userdata     = this;

        SET_ALLOC_OWNER(gAudioCustomFilterRootContainer);
        CheckFMODError(GetAudioManager().GetFMODSystem()->createDSP(&dspdesc, &m_DSP));

        m_DSP->setBypass(true);
    }

    #if SUPPORT_SCRIPTING_THREADS
    scriptingDomain = scripting_domain_get();
    #endif
}

void AudioCustomFilter::Cleanup()
{
    if (m_DSP)
    {
        // is this a playing dsp?
        if (m_playingSource)
        {
            // Doesn't matter whether argument is true or false, since sources playing DSP's don't play one-shots at the same time.
            m_playingSource->Stop(true);
        }

        CheckFMODError(m_DSP->release());
        m_DSP = NULL;
    }
}

FMOD::DSP* AudioCustomFilter::GetOrCreateDSP()
{
    if (!m_DSP)
        Init();
    return m_DSP;
}

FMOD::DSP* AudioCustomFilter::GetDSP()
{
    return m_DSP;
}

void AudioCustomFilter::WaitForScriptCallback()
{
    while (m_InScriptCallback)
        Thread::Sleep(0.01); // wait 10ms
}

#if UNITY_EDITOR
float AudioCustomFilter::GetMaxIn(short channel) const
{
    if (m_DSP)
    {
        bool active, bypass;
        m_DSP->getActive(&active);
        m_DSP->getBypass(&bypass);
        return active && !bypass ? maxIn[channel] : 0.0f;
    }
    else
        return 0.0f;
}

float AudioCustomFilter::GetMaxOut(short channel) const
{
    if (m_DSP)
    {
        bool active, bypass;
        m_DSP->getActive(&active);
        m_DSP->getBypass(&bypass);
        return active && !bypass ? maxOut[channel] : 0.0f;
    }
    else
        return 0.0f;
}

#endif // UNITY_EDITOR

FMOD_RESULT F_CALLBACK AudioCustomFilter::readCallback(FMOD_DSP_STATE *dsp_state, float *inbuffer, float *outbuffer, unsigned int length, int inchannels, int outchannels)
{
#if SUPPORT_SCRIPTING_THREADS || ENABLE_DOTNET

#if UNITY_EDITOR
    if (IsCompiling())
        return FMOD_OK;
#endif

    AudioCustomFilter* filter;
    FMOD_RESULT result;
    FMOD::DSP* fmod_dsp = (FMOD::DSP*)dsp_state->instance;
    result = fmod_dsp->getUserData((void**)&filter);

    Assert(filter);

#if UNITY_EDITOR
    TimeFormat start_time = GetProfilerTime();
#endif
    if (!filter->m_behaviour->GetEnabled())
        return FMOD_OK;

    filter->m_InScriptCallback = true;

#if SUPPORT_SCRIPTING_THREADS
    ScopedThreadAttach attach(filter->scriptingDomain);
#endif

    AudioScriptBufferManager& scriptBufferManager = GetAudioManager().GetScriptBufferManager();
    Mutex::AutoLock lock(scriptBufferManager.GetDSPFilterArrayMutex());

    // reuse mono array
    ScriptingArrayPtr array = SCRIPTING_NULL;
    scriptBufferManager.GetDSPFilterArray(length * inchannels, array);

    Assert(array != SCRIPTING_NULL);

    memcpy(&Scripting::GetScriptingArrayElement<float>(array, 0), inbuffer, length * 4 * inchannels);

    ScriptingObjectPtr instance = Scripting::ScriptingWrapperFor(filter->m_behaviour);
    if (instance)
    {
        ScriptingExceptionPtr exception;
        ScriptingInvocation invoke(instance, filter->m_behaviour->GetMethod(MonoScriptCache::kAudioFilterRead));
        invoke.AddArray(array);
        invoke.AddInt(inchannels);
        invoke.objectInstanceIDContextForException = filter->m_behaviour->GetInstanceID();
        invoke.Invoke(&exception);
        if (exception == SCRIPTING_NULL)
            memcpy(outbuffer, &Scripting::GetScriptingArrayElement<float>(array, 0), length * 4 * inchannels);
    }
    filter->m_InScriptCallback = false;

#if UNITY_EDITOR
    filter->processTime = TimeToNanoseconds(ELAPSED_TIME(start_time));
    filter->channelCount = inchannels;
    for (int c = 0; c < inchannels && c < MAX_CHANNELS; c++)
        filter->maxOut[c] = filter->maxIn[c] = -1.0f;
    for (int i = 0; i < length; i += inchannels)
        for (int c = 0; c < inchannels && c < MAX_CHANNELS; c++)
        {
            if (filter->maxIn[c] < inbuffer[i + c])
                filter->maxIn[c] = inbuffer[i + c];
            if (filter->maxOut[c] < outbuffer[i + c])
                filter->maxOut[c] = outbuffer[i + c];
        }
#endif
#endif // SUPPORT_THREADS

    return FMOD_OK;
}
