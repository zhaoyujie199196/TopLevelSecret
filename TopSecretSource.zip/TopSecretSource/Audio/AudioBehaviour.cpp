#include "UnityPrefix.h"
#include "AudioBehaviour.h"

#if ENABLE_AUDIO

IMPLEMENT_REGISTER_CLASS(AudioBehaviour, 180);

AudioBehaviour::AudioBehaviour(MemLabelId label, ObjectCreationMode mode)
    :   Super(label, mode)
{}

void AudioBehaviour::ThreadedCleanup()
{
}

#endif
