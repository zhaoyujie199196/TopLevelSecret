#include "UnityPrefix.h"

#   include "Runtime/Audio/AudioEffectInternal.h"
#   include "Runtime/Audio/AudioManager.h"

extern UnityAudioEffectInternal g_AudioMasterDSPInternal;

UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMasterDSPProcessCallback(UnityAudioEffectState* state, float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int outchannels)
{
    Assert(inchannels == outchannels);

    // Other platforms may just read the DSP tick directly
    g_AudioMasterDSPInternal.currdsptick += length;

#if UNITY_EDITOR
    AudioManager* manager = GetAudioManagerPtr();
    if (manager != NULL) // check because this might be called during AudioManager initialization
    {
        manager->EditorMasterDSPCallback(inbuffer, outbuffer, length, inchannels, outchannels);
        return 0;
    }
#endif

    std::memcpy(outbuffer, inbuffer, length * inchannels * sizeof(float));

    return 0;
}
