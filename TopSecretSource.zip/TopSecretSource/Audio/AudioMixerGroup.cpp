#include "UnityPrefix.h"
#include "AudioMixerGroup.h"
#include "AudioMixer.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"


AudioMixerGroup::AudioMixerGroup(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
{
}

void AudioMixerGroup::ThreadedCleanup()
{
}

template<class TransferFunction>
void AudioMixerGroup::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);

    TRANSFER(m_AudioMixer);
    TRANSFER(m_GroupID);
    TRANSFER(m_Children);
}

void AudioMixerGroup::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);

    //When we create or instantiate this class then set up the GUID
    if (awakeMode & kInstantiateOrCreateFromCodeAwakeFromLoad)
    {
#if UNITY_HAVE_GUID_INIT
        m_GroupID.Init();
#endif // UNITY_HAVE_GUID_INIT
    }
}

void AudioMixerGroup::GetGroupInGUIDListRecursive(const std::vector<UnityGUID>& guids, AudioMixer::GroupList& groups)
{
    for (int i = 0; i < guids.size(); i++)
    {
        if (guids[i] == m_GroupID)
            groups.push_back(this);
    }

    for (int i = 0; i < m_Children.size(); i++)
    {
        m_Children[i]->GetGroupInGUIDListRecursive(guids, groups);
    }
}

IMPLEMENT_REGISTER_CLASS(AudioMixerGroup, 273);
IMPLEMENT_OBJECT_SERIALIZE(AudioMixerGroup);
INSTANTIATE_TEMPLATE_TRANSFER(AudioMixerGroup);
