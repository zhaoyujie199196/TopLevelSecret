#ifndef AUDIO_PROFILER
#define AUDIO_PROFILER

#include "Configuration/UnityConfigure.h"
#include "Runtime/Utilities/dynamic_array.h"

enum AudioProfilerCaptureFlags
{
    AudioProfilerCaptureFlags_Channels = 1,
    AudioProfilerCaptureFlags_DSPNodes = 2,
    AudioProfilerCaptureFlags_Clips = 4
};

struct AudioProfilerGroupInfo
{
    InstanceID         assetInstanceId;
    InstanceID         objectInstanceId;
    int                assetNameOffset;
    int                objectNameOffset;
    int                parentId;
    int                uniqueId;
    int                flags;
    int                playCount;
    float              distanceToListener;
    float              volume;
    float              audibility;
    float              minDist;
    float              maxDist;
    float              time;
    float              duration;
    float              frequency;
};

// The list of AudioProfilerDSPInfo can contain duplicates (i.e. nodes with the same ID). It is up to the rendering backend to identify these and render them as nodes whose output
// is read multiple times.
struct AudioProfilerDSPInfo
{
    UInt32             id;
    UInt32             target;
    UInt32             targetPort;
    UInt32             numChannels;
    UInt32             nameOffset;
    float              weight;
    float              cpuLoad;
    float              level1;
    float              level2;
    UInt32             numLevels;
    UInt32             flags;
};

struct AudioProfilerClipInfo
{
    InstanceID         assetInstanceId;
    int                assetNameOffset;
    int                loadState;
    int                internalLoadState;
    int                age;
    int                disposed;
    int                numChannelInstances;
};

namespace AudioProfiler
{
    void CaptureFrame(dynamic_array<AudioProfilerGroupInfo>& groupData, dynamic_array<AudioProfilerDSPInfo>& dspData, dynamic_array<AudioProfilerClipInfo>& clipData, dynamic_array<char>& names);
}

#endif
