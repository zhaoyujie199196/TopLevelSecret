#include "UnityPrefix.h"
#include "Configuration/UnityConfigure.h"
#if ENABLE_AUDIO
#include "AudioSource.h"
#include "AudioManager.h"
#include "AudioMixer.h"
#include "Runtime/Audio/AudioMixerGroup.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/BaseClasses/IsPlaying.h"
#include "Runtime/BaseClasses/MessageHandlerRegistration.h"
#include "Runtime/Utilities/Utility.h"
#include "Runtime/Profiler/Profiler.h"
#include "AudioClip.h"
#include "Runtime/Video/MoviePlayback.h"
#include "Runtime/Dynamics/Rigidbody.h"
#include "Runtime/Math/AnimationCurveUtility.h"
#include "AudioListener.h"
#include "AudioSourceFilter.h"
#include "AudioLowPassFilter.h"
#include "AudioEchoFilter.h"
#include "AudioChorusFilter.h"
#include "AudioCustomFilter.h"
#include "Runtime/BaseClasses/GameObject.h"
#include "Runtime/Input/TimeManager.h"
#include "Runtime/GameCode/CallDelayed.h"
#include "Runtime/Audio/correct_fmod_includer.h"
#include "Runtime/Misc/BuildSettings.h"
#include "Runtime/Mono/MonoBehaviour.h"
#include "Runtime/Math/AnimationCurveUtility.h"
#include "Runtime/Interfaces/IPhysics.h"
#include "Runtime/Audio/sound/SoundChannel.h"
#include "Runtime/Audio/AudioEffectInternal.h"
#if ENABLE_PROFILER
#include "Runtime/Threads/AtomicOps.h"
#endif

#include "Runtime/Containers/ExtendedRingbuffer.h"

#if PS4_PAD_SPEAKER
#include "Devices/devices.h"
#endif


#define Unity_HiWord(x) ((UInt32)((UInt64)(x) >> 32))
#define Unity_LoWord(x) ((UInt32)(x))

// ------------------------------------------------------------------------


#if ENABLE_PROFILER
int AudioSource::s_GlobalCount = 0;
int AudioSource::s_GlobalActiveCount = 0;
#endif

FMOD_RESULT F_CALLBACK VideoAudioData::PCMReadCallback(FMOD_DSP_STATE *dspState, float *inBuffer, float *outBuffer, unsigned int length, int inChannels, int outChannels)
{
    Assert(inChannels = outChannels);

    VideoAudioData* data = NULL;
    FMOD::DSP* dsp = (FMOD::DSP*)dspState->instance;
    CheckFMODError(dsp->getUserData((void**)&data));

    Assert(data != NULL);

    const UInt32 toReadSampleCount = length * inChannels;
    const UInt32 readSampleCount = RingbufferTemplates::ReadValuesFromRingBuffer(
            data->buffer, outBuffer, toReadSampleCount, inChannels);
    Assert((readSampleCount % inChannels) == 0);

    // If we are not filling the entire read buffer, then 0 out the rest..
    // TODO: ramp out the last 64 samples of what we did read..
    if (readSampleCount < toReadSampleCount)
    {
        const UInt32 bytesRead = readSampleCount * sizeof(float);
        const UInt32 bufferLength = toReadSampleCount * sizeof(float);
        memset((char*)outBuffer + bytesRead, 0, bufferLength - bytesRead);
    }

    return FMOD_OK;
}

bool VideoAudioData::InitFMOD(AudioSource* parent)
{
    FMOD::System* system = GetAudioManager().GetFMODSystem();

    FMOD_DSP_DESCRIPTION  dspDesc;
    memset(&dspDesc, 0, sizeof(FMOD_DSP_DESCRIPTION));
    strcpy(dspDesc.name, "Video Audio");
    dspDesc.channels    = channelCount;
    dspDesc.read        = PCMReadCallback;
    dspDesc.userdata    = (void*)this;

    FMOD::DSP* customdsp = NULL;
    CheckFMODError(system->createDSP(&dspDesc, &customdsp));

    if (customdsp == NULL)
        return false;

    FMOD::Channel* customchannel = NULL;
    CheckFMODError(system->playDSP(FMOD_CHANNEL_FREE, customdsp, true, &customchannel));

    if (customchannel == NULL)
    {
        dsp->release();
        return false;
    }

    FMOD_MODE mode = FMOD_SOFTWARE | FMOD_LOOP_NORMAL | FMOD_3D;
    CheckFMODError(customchannel->setMode(mode));

    // We use the samplerate specified by the
    CheckFMODError(customchannel->setFrequency(sampleRate));

    dsp = customdsp;

    channel = SoundChannel::Create(SoundHandle(), true);
    if (channel.IsValid())
    {
        channel->SetFMODChannel(customchannel);
        channel->SetAudioSource(parent);
    }

    channel.SetPaused(false);

    return true;
}

void VideoAudioData::ReleaseFMOD()
{
    if (channel.IsValid())
    {
        channel.Stop();
        channel.Clear();
    }

    if (dsp != NULL)
    {
        CheckFMODError(dsp->release());
        dsp = NULL;
    }
}

AudioSource::AudioSource(MemLabelId label, ObjectCreationMode mode) :
    Super(label, mode)
    , m_Node(this)
    , m_Channel(NULL)
    , m_ScheduledSource(this)
    , m_dryGroup(NULL)
    , m_wetGroup(NULL)
    , m_IgnoreListenerVolume(false)
    , m_PlayOnAwake(true)
    , m_HasScheduledStartDelay(false)
    , m_HasScheduledEndDelay(false)
    , m_VelocityUpdateMode(kVelocityUpdateModeAuto)
    , m_LastUpdatePosition(Vector3f(0, 0, 0))
    , m_PauseStartClock(0)
    , m_samplePosition(0)
    , m_pause(true)
    , m_PlayingDSP(NULL)
    , m_SpatializerDSP(NULL)
    , m_SpatializerData(NULL)
#if UNITY_WIIU
    , m_WiiUOutputDevice(FMOD_WIIU_CONTROLLER_DEFAULT)
#endif
    , m_DoLegacy3DTransfer(false)
#if PS4_PAD_SPEAKER
    , m_PlayOnDualShock4(false)
    , m_UserId(SCE_USER_SERVICE_USER_ID_INVALID)
#endif
{
    m_AudioParameters.pitch = 1.0;
    m_AudioParameters.volume = 1.0f;
    m_AudioParameters.priority = 128;
    m_AudioParameters.loop = false;
    m_AudioParameters.pan = 0.0f;
    m_AudioParameters.dopplerLevel = 1.0f;
    m_AudioParameters.minDistance = 1.0f;
    m_AudioParameters.maxDistance = 500.0f;
    m_AudioParameters.mute = false;
    m_AudioParameters.spatialize = false;
    m_AudioParameters.spatializePostEffects = false;
    m_AudioParameters.rolloffMode = kRolloffLogarithmic;
    m_AudioParameters.bypassEffects = false;
    m_AudioParameters.bypassListenerEffects = false;
    m_AudioParameters.bypassReverbZones = false;
    m_AudioParameters.ignoreListenerPause = false;
    // curves
    ReplaceOrAddSingleCurveValue(1.0f, m_AudioParameters.spatialBlendCustomCurve);
    ReplaceOrAddSingleCurveValue(0.0f, m_AudioParameters.spreadCustomCurve);
    ReplaceOrAddSingleCurveValue(1.0f, m_AudioParameters.reverbZoneMixCustomCurve);

#if ENABLE_PROFILER
    AtomicIncrement(&s_GlobalCount);
#endif
}

void AudioSource::Reset()
{
    Super::Reset();

    m_AudioParameters.pitch = 1.0;
    m_AudioParameters.volume = 1.0f;
    m_AudioParameters.priority = 128;
    m_AudioParameters.loop = false;
    m_AudioParameters.pan = 0.0f;
    m_AudioParameters.dopplerLevel = 1.0f;
    m_AudioParameters.minDistance = 1.0f;
    m_AudioParameters.maxDistance = 500.0f;
    m_AudioParameters.mute = false;
    m_AudioParameters.spatialize = false;
    m_AudioParameters.spatializePostEffects = false;
    m_AudioParameters.rolloffMode = kRolloffLogarithmic;
    m_AudioParameters.bypassEffects = false;
    m_AudioParameters.bypassListenerEffects = false;
    m_AudioParameters.bypassReverbZones = false;
    m_AudioParameters.ignoreListenerPause = false;

    m_PlayOnAwake = true;

    // Curves initial values will be handled in CheckConsistency
    m_AudioParameters.rolloffCustomCurve.ResizeUninitialized(0);
    m_AudioParameters.spatialBlendCustomCurve.ResizeUninitialized(0);
    m_AudioParameters.spreadCustomCurve.ResizeUninitialized(0);
    m_AudioParameters.reverbZoneMixCustomCurve.ResizeUninitialized(0);

    CheckConsistency();
}

void AudioSource::ThreadedCleanup()
{
    // Do nothing here -- see comment in MainThreadCleanup
}

void AudioSource::MainThreadCleanup()
{
#if ENABLE_PROFILER
    AtomicDecrement(&s_GlobalCount);
#endif

    //Ensure that all creation/destroy logic happens in the AddToManager and RemoveFromManager.
    //It is also important not to call cleanup from here, as components accessed in cleanup
    //may be destroyed.

    KillActiveVideoSinks();

    Assert(m_Channel.IsNull());
    Assert(m_OneShots.empty());
    Assert(m_SharedVideoAudioDataList.empty());
    Super::MainThreadCleanup();
}

void AudioSource::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    // This call is needed to apply changed properties
    if (IsAddedToManager())
    {
        AssignProps();

        if (awakeMode & (kDidLoadFromDisk | kInstantiateOrCreateFromCodeAwakeFromLoad | kActivateAwakeFromLoad))
            m_LastUpdatePosition = GetComponent<Transform>().GetPosition();
    }

    // This calls AddToManager which performs PlayOnAwake
    // Thus we call it at the end after properties have been setup.
    Super::AwakeFromLoad(awakeMode);
}

void AudioSource::CheckConsistency()
{
    const float epsilon = 0.000001f;

    m_AudioParameters.volume = clamp01(m_AudioParameters.volume);
    m_AudioParameters.priority = clamp(m_AudioParameters.priority, 0, 256);
    m_AudioParameters.pitch = clamp(m_AudioParameters.pitch, -3.0f, 3.0f);
    m_AudioParameters.dopplerLevel = clamp(m_AudioParameters.dopplerLevel, 0.0f, 5.0f);
    m_AudioParameters.minDistance = m_AudioParameters.minDistance < 0.0f ? 0.0f : m_AudioParameters.minDistance;
    m_AudioParameters.maxDistance = m_AudioParameters.maxDistance < m_AudioParameters.minDistance + epsilon ? m_AudioParameters.minDistance + epsilon : m_AudioParameters.maxDistance;

    if (m_AudioParameters.rolloffCustomCurve.GetKeyCount() < 1)
    {
        m_AudioParameters.rolloffCustomCurve.AddKey(AnimationCurve::Keyframe(0.0f, 1.0f));
        m_AudioParameters.rolloffCustomCurve.AddKey(AnimationCurve::Keyframe(1.0f, 0.0f));
    }
    if (m_AudioParameters.rolloffCustomCurve.GetKeyCount() == 1)
        m_AudioParameters.rolloffCustomCurve.GetKey(0).value = clamp(m_AudioParameters.rolloffCustomCurve.GetKey(0).value, 0.0f, 1.0f);

    if (m_AudioParameters.spatialBlendCustomCurve.GetKeyCount() < 1)
        ReplaceOrAddSingleCurveValue(0.0f, m_AudioParameters.spatialBlendCustomCurve);
    if (m_AudioParameters.spatialBlendCustomCurve.GetKeyCount() == 1)
        m_AudioParameters.spatialBlendCustomCurve.GetKey(0).value = clamp(m_AudioParameters.spatialBlendCustomCurve.GetKey(0).value, 0.0f, 1.0f);

    if (m_AudioParameters.spreadCustomCurve.GetKeyCount() < 1)
        ReplaceOrAddSingleCurveValue(0.0f, m_AudioParameters.spreadCustomCurve);
    if (m_AudioParameters.spreadCustomCurve.GetKeyCount() == 1)
        m_AudioParameters.spreadCustomCurve.GetKey(0).value = clamp(m_AudioParameters.spreadCustomCurve.GetKey(0).value, 0.0f, 1.0f);

    if (m_AudioParameters.reverbZoneMixCustomCurve.GetKeyCount() < 1)
        ReplaceOrAddSingleCurveValue(1.0f, m_AudioParameters.reverbZoneMixCustomCurve);
    if (m_AudioParameters.reverbZoneMixCustomCurve.GetKeyCount() == 1)
        m_AudioParameters.reverbZoneMixCustomCurve.GetKey(0).value = clamp(m_AudioParameters.reverbZoneMixCustomCurve.GetKey(0).value, 0.0f, 1.1f);

    //Set pan level to 0 for when 2D clips were attached to the AudioSource.
    if (m_DoLegacy3DTransfer && m_AudioClip.IsValid())
    {
        if (m_AudioParameters.spatialBlendCustomCurve.GetKeyCount() == 1 && !m_AudioClip->GetLegacy3D())
        {
            m_AudioParameters.spatialBlendCustomCurve.GetKey(0).value = 0.0f;
            m_AudioParameters.reverbZoneMixCustomCurve.GetKey(0).value = 0.0f;
        }
    }
}

void AudioSource::AssignProps()
{
    ConfigureFMODGroups();

#if UNITY_EDITOR
    bool wasDirty = IsPersistentDirty();
#endif

    SetDopplerLevel(m_AudioParameters.dopplerLevel);
    SetPitch(m_AudioParameters.pitch);

    SetPriority(m_AudioParameters.priority);
    SetMinDistance(m_AudioParameters.minDistance);
    SetMaxDistance(m_AudioParameters.maxDistance);
    SetStereoPan(m_AudioParameters.pan);

    SetVolume(m_AudioParameters.volume);
    SetLoop(m_AudioParameters.loop);
    SetMute(m_AudioParameters.mute);
    SetSpatialize(m_AudioParameters.spatialize);

    SetRolloffMode(m_AudioParameters.rolloffMode);

#if UNITY_EDITOR
    // None of the Set functions should call SetDirty since we are just synchronizing the values with the FMOD objects here
    Assert(wasDirty == IsPersistentDirty());
#endif

#if UNITY_WIIU
    if (m_Channel.IsValid())
    {
        bool isPlaying;
        FMOD_RESULT result = m_Channel->isPlaying(&isPlaying);
        //Assign main source channel
        if (result == FMOD_OK && isPlaying)
            FMOD_WiiU_SetControllerSpeaker((FMOD_CHANNEL*)m_Channel->GetFMODChannel(), m_WiiUOutputDevice);
    }

    //Assign the oneshots
    for (TOneShots::iterator it = m_OneShots.begin(); it != m_OneShots.end(); ++it)
    {
        OneShot& os = **it;
        if (!os.channel.IsValid())
            continue;
        FMOD_WiiU_SetControllerSpeaker((FMOD_CHANNEL*)os.channel->GetFMODChannel(), m_WiiUOutputDevice);
    }
#endif
}

void AudioSource::CorrectScheduledTimeAfterUnpause(UInt64 delay)
{
    if (m_Channel.IsValid())
    {
        unsigned hiclock, loclock;

        if (m_HasScheduledStartDelay)
        {
            m_Channel->getDelay(FMOD_DELAYTYPE_DSPCLOCK_START, &hiclock, &loclock);
            FMOD_64BIT_ADD(hiclock, loclock, Unity_HiWord(delay), Unity_LoWord(delay));
            m_Channel->setDelay(FMOD_DELAYTYPE_DSPCLOCK_START, hiclock, loclock);
        }

        if (m_HasScheduledEndDelay)
        {
            m_Channel->getDelay(FMOD_DELAYTYPE_DSPCLOCK_END, &hiclock, &loclock);
            FMOD_64BIT_ADD(hiclock, loclock, Unity_HiWord(delay), Unity_LoWord(delay));
            m_Channel->setDelay(FMOD_DELAYTYPE_DSPCLOCK_END, hiclock, loclock);
        }
    }
}

void AudioSource::SetAudioClip(AudioClip *clip)
{
    if (m_AudioClip == PPtr<AudioClip>(clip))
        return;
    Stop(true);
    m_AudioClip = clip;
    SetDirty();
}

void AudioSource::SetOutputAudioMixerGroup(PPtr<AudioMixerGroup> mixerGroup)
{
    if (m_OutputAudioMixerGroup == mixerGroup)
        return;

    m_OutputAudioMixerGroup = mixerGroup;
    ConfigureFMODGroups();
}

void AudioSource::CreateFMODGroups()
{
    Assert(GetAudioManagerPtr());

    if (!m_dryGroup)
    {
        // Do not change the name of this -- the audio profiler filters these out
        CheckFMODError(GetAudioManager().GetFMODSystem()->createChannelGroup("ASrcDryGroup", &m_dryGroup));
        Assert(m_dryGroup);
    }

    if (!m_wetGroup)
    {
        // Do not change the name of this -- the audio profiler filters these out
        CheckFMODError(GetAudioManager().GetFMODSystem()->createChannelGroup("ASrcWetGroup", &m_wetGroup));
        Assert(m_wetGroup);
    }

    if (m_AudioParameters.spatialize)
    {
        if (m_SpatializerDSP == NULL)
        {
            if (GetAudioManager().RequiresCustomSpatializer())
            {
                AudioEffectInternalDefinition* def = GetAudioManager().GetCurrentSpatializerDefinition();
                if (def != NULL)
                {
                    m_SpatializerDSP = def->CreateDSP(GetAudioManager().GetFMODSystem(), NULL, NULL, &m_SpatializerData);
                    if (m_SpatializerDSP != NULL)
                        ApplyFilters();
                    else
                        WarningStringObject("Audio source failed to initialize audio spatializer. Please check that the project audio settings and make sure that the selected spatializer is compatible with the target.", this);
                }
                else
                {
                    WarningStringObject("Audio source failed to initialize audio spatializer. An audio spatializer is specified in the audio project settings, but the associated plugin was not found or initialized properly. Please make sure that the selected spatializer is compatible with the target.", this);
                }
            }
        }
    }
    else
    {
        m_SpatializerData = NULL; // Must happen before the release so Unity stops writing into this structure that is allocated by the DSP.

        if (m_SpatializerDSP != NULL)
        {
            m_SpatializerDSP->release();
            m_SpatializerDSP = NULL;
        }
    }

    ConfigureFMODGroups();
    UpdateParameters();

    if (m_OutputAudioMixerGroup.IsValid())
    {
        // Note that UpdateAudioMixerMemory also resumes groups, but in this case we want it to happen
        // before starting to play the sound to avoid artifacts.
        AudioMixer* mixer = m_OutputAudioMixerGroup->GetAudioMixer();
        if (mixer)
            mixer->ResumeProcessing();
    }
}

/**
 * Configure effect and non-effect groups
 **/
void AudioSource::ConfigureFMODGroups()
{
    Assert(GetAudioManagerPtr());

    //If we dont have valid groups to play into, dont update them.
    //They are only created in PLay and PlayOneShot
    if (!(m_dryGroup && m_wetGroup))
        return;

    FMOD::ChannelGroup* newParentGroup = NULL;
    if (m_OutputAudioMixerGroup.IsValid())
        newParentGroup = m_OutputAudioMixerGroup->GetAudioMixer()->GetFMODChannelGroup(m_OutputAudioMixerGroup->GetGroupID());

    if (newParentGroup == NULL)
    {
        if (m_AudioParameters.bypassListenerEffects)
            newParentGroup = (m_IgnoreListenerVolume) ? GetAudioManager().GetChannelGroup_NoFX_IgnoreVolume() : GetAudioManager().GetChannelGroup_NoFX_UseVolume();
        else
            newParentGroup = (m_IgnoreListenerVolume) ? GetAudioManager().GetChannelGroup_FX_IgnoreVolume() : GetAudioManager().GetChannelGroup_FX_UseVolume();
    }

#if PS4_PAD_SPEAKER
    if (m_Channel.IsValid() && m_PlayOnDualShock4)
    {
        newParentGroup = GetAudioManager().GetChannelGroup_DualShock4Speaker(m_UserId);
    }
#endif


    if (m_AudioParameters.bypassEffects)
    {
        // Connect dry group directly to new parent group (thus bypassing wet group)
        FMOD::ChannelGroup* parentGroup;
        CheckFMODError(m_dryGroup->getParentGroup(&parentGroup));
        if (parentGroup != newParentGroup)
            CheckFMODError(newParentGroup->addGroup(m_dryGroup));

        //TODO Need to attach the wet group to a mute group somewhere
    }
    else
    {
        // Connect dry group to wet group (where DSP effects are attached) and add wet group to new parent group
        FMOD::ChannelGroup* parentGroup;
        CheckFMODError(m_dryGroup->getParentGroup(&parentGroup));
        if (parentGroup != m_wetGroup)
            CheckFMODError(m_wetGroup->addGroup(m_dryGroup));
    }

    // Reconnect the wet group, to handle the case where ConfigureFMODGroups gets called after updating the runtime of an audio mixer
    FMOD::ChannelGroup* parentGroup;
    CheckFMODError(m_wetGroup->getParentGroup(&parentGroup));
    if (parentGroup != newParentGroup)
        CheckFMODError(newParentGroup->addGroup(m_wetGroup));

    ApplyFilters();

    UpdateEffectVirtualizationState(false);
}

void AudioSource::Play(double time)
{
    if (GetAudioManager().IsAudioDisabled())
        return;

    if (!IsAddedToManager())
    {
        WarningStringObject("Can not play a disabled audio source", this);
        return;
    }

    CreateFMODGroups();

    AudioClip* clip = m_AudioClip;
    if (clip && clip->GetLoadState() == SoundHandleShared::kUnloaded)
        clip->LoadAudioData();

    /**
     * Play/unpause main clip, if any
     **/
    if (m_Channel.IsValid())
    {
        m_Channel->setChannelGroup(m_dryGroup);

        if (m_Channel->GetPaused())
        {
            AssignProps();

            UnPause();
            return;
        }
        else
            Stop(false);
    }

    if (m_Channel.IsNull())
    {
        if (clip != NULL)
        {
            m_Channel = clip->AllocateChannel(true);
            if (m_Channel.IsValid())
            {
                clip->IncrementPlayCount();
                m_Channel->SetAudioSource(this);
            }
        }
        else
        {
            TFilters filters;
            if (GetFilterComponents(filters, true))
            {
                AudioCustomFilter* customFilter = NULL;
                filters[0]->getUserData((void**)&customFilter);
                if (customFilter)
                {
                    if (customFilter->GetPlayingListener())
                    {
                        WarningStringObject(Format("GameObject has both an AudioSource and an AudioListener attached. While built-in filters like lowpass are instantiated separately, the custom script DSP filter components may only be used by either the AudioSource or AudioListener at a time. In this case it was attached to the AudioListener first, so it remains connected to this."), this);
                        return;
                    }
                    customFilter->SetPlayingSource(this);
                    m_PlayingDSP = filters[0];
                    CheckFMODError(m_PlayingDSP->remove());
                    FMOD::Channel* fmodChannel;
                    FMOD_RESULT result = GetAudioManager().GetFMODSystem()->playDSP(FMOD_CHANNEL_FREE, filters[0], true, &fmodChannel);
                    if (result == FMOD_ERR_CHANNEL_ALLOC)
                    {
                        WarningStringObject("Ran out of virtual channels. Sound will not be played.", this);
                        return;
                    }
                    else if (result != FMOD_OK)
                    {
                        ErrorStringObject(Format("Sound could not be played. FMOD Error: %s", FMOD_ErrorString(result)), this);
                        return;
                    }
                    else
                    {
                        FMOD_MODE mode = FMOD_SOFTWARE | FMOD_LOOP_NORMAL | FMOD_3D;
                        CheckFMODError(fmodChannel->setMode(mode));

                        int samplerate;
                        CheckFMODError(GetAudioManager().GetFMODSystem()->getSoftwareFormat(&samplerate, NULL, NULL, NULL, NULL, NULL));
                        CheckFMODError(fmodChannel->setFrequency(samplerate)); // necessary, otherwise default is 44100 (or whatever the channel that got reused was set to?)

                        m_Channel = SoundChannel::Create(SoundHandle(), true);
                        if (m_Channel.IsValid())
                        {
                            m_Channel->SetFMODChannel(fmodChannel);
                            m_Channel->SetAudioSource(this);
                        }
                    }
                }
                else
                    WarningString(Format("Only custom filters can be played. Please add a custom filter or an audioclip to the audiosource (%s).",
                            GetGameObjectPtr() ? GetGameObjectPtr()->GetName() : ""));
            }
        }
    }

#if ENABLE_MOVIES
    // is this a movie playback - note movieplayback (this is *so* ugly)
    if (clip && clip->GetMovie())
    {
        if (m_Channel.IsValid())
        {
            m_Channel->Stop();
            m_Channel.Clear();
        }

        SoundHandle sound = clip->CreateSound();
        if (!sound.IsNull())
        {
            m_Channel = sound.CreateChannel(m_pause);
            if (m_Channel.IsValid())
                clip->GetMovie()->SetAudioChannel(m_Channel);
        }
    }
#endif

    if (m_Channel.IsValid())
    {
        m_Channel->setChannelGroup(m_dryGroup);
        ApplyFilters();
        AssignProps();

        // Note that we keep the sound paused here and let AudioManager::ProcessScheduledSources update the position-based parameters and unpause the source.
        // This is done in order to make sure that all listener parameters have settled before we start the sound in FMOD (i.e. first play or if an AudioListener
        // was deactivated on one GameObject and another one was activated during a frame).
        // Hence we mark the AudioSource as un-paused here, but wait with the actual channel unpausing until AudioManager::ProcessScheduledSources.
        m_pause = false;

        // set cached position
        m_Channel->SetPositionPCM(m_samplePosition);

        // play in sync (this will add it to the manager as well)
        GetAudioManager().ScheduleSource(this, time);
    }
}

void AudioSource::Pause()
{
    m_pause = true;
    UpdatePauseState();
}

void AudioSource::UnPause()
{
    m_pause = false;
    UpdatePauseState();
}

void AudioSource::UpdatePauseState()
{
    bool managerPaused = GetAudioManager().ShouldSourcePause(m_AudioParameters.ignoreListenerPause);
    bool pause = m_pause || managerPaused;

    if (managerPaused && m_PauseStartClock == 0)
    {
        m_PauseStartClock = GetAudioManager().GetRealDSPTime();
    }

    if (!managerPaused && m_PauseStartClock > 0)
    {
        if (HasScheduledTime())
        {
            UInt64 pauseDelay = GetAudioManager().GetRealDSPTime() - m_PauseStartClock;
            CorrectScheduledTimeAfterUnpause(pauseDelay);
        }
        m_PauseStartClock = 0;
    }

    if (m_Channel.IsValid())
        m_Channel->SetPaused(pause);

    // we also want the oneshots to have the same pause behaviour
    for (TOneShots::iterator it = m_OneShots.begin(); it != m_OneShots.end(); ++it)
        (*it)->channel->SetPaused(pause);

    UpdateEffectVirtualizationState(false);
}

bool AudioSource::AnyChannelPaused()
{
    if (m_Channel.IsValid() && m_Channel->GetPaused())
        return true;

    //Channels can be in the oneshot list too.
    for (TOneShots::iterator it = m_OneShots.begin(); it != m_OneShots.end(); ++it)
    {
        if ((*it)->channel->GetPaused())
            return true;
    }

    return false;
}

void AudioSource::Cleanup()
{
    Stop(true);

    // cleanup filters
    const GameObject* go = GetGameObjectPtr();
    if (go)
    {
        for (int i = 0; i < go->GetComponentCount(); i++)
        {
            AudioFilter* filter = NULL;
            filter = dynamic_pptr_cast<AudioFilter*>(&go->GetComponentAtIndex(i));
            if (filter)
                filter->Cleanup();
            else
            {
                MonoBehaviour* behaviour = dynamic_pptr_cast<MonoBehaviour*>(&go->GetComponentAtIndex(i));
                if (behaviour)
                {
                    AudioCustomFilter* filter = behaviour->GetAudioCustomFilter();
                    if (filter)
                        filter->Cleanup();
                }
            }
        }
    }

    m_SpatializerData = NULL; // Must happen before the release so Unity stops writing into this structure that is allocated by the DSP.

    if (m_SpatializerDSP)
    {
        m_SpatializerDSP->release();
        m_SpatializerDSP = NULL;
    }

    if (m_dryGroup)
    {
        CheckFMODError(m_dryGroup->release());
        m_dryGroup = NULL;
    }

    if (m_wetGroup)
    {
        CheckFMODError(m_wetGroup->release());
        m_wetGroup = NULL;
    }
}

float AudioSource::CalculateDistanceAttenuation() const
{
    float distance = 0.0f;
    const AudioListener* listener = GetAudioManager().GetAudioListener();
    if (listener != NULL)
    {
        const Transform& transform = GetComponent<Transform>();
        const Vector3f p = transform.GetPosition();
        distance = Magnitude(p - listener->GetPosition());
    }

    float distanceattenuationSource = EvaluateAttenuationCurve(distance);
    if (m_SpatializerDSP != NULL && m_SpatializerData != NULL && m_SpatializerData->distanceattenuationcallback != NULL)
    {
        float distanceattenuationOverride = 0.0f;
        AudioEffectInternalInstance* instance = NULL;
        if (m_SpatializerDSP->getUserData((void**)&instance) == FMOD_OK &&
            instance != NULL &&
            m_SpatializerData->distanceattenuationcallback(instance, distance, distanceattenuationSource, &distanceattenuationOverride) == UNITY_AUDIODSP_OK)
            return distanceattenuationOverride;
    }

    return distanceattenuationSource;
}

void AudioSource::CleanAudioSource(bool ignoreSharedVideoAudio)
{
    if (!m_Channel.IsValid() && m_OneShots.empty() && (ignoreSharedVideoAudio || m_SharedVideoAudioDataList.empty()))
    {
        // remove filters
        TFilters filters;
        if (GetFilterComponents(filters, false))
        {
            for (TFilters::const_iterator it = filters.begin(); it != filters.end(); it++)
            {
                FMOD::DSP* dsp = *it;
                CheckFMODError(dsp->remove());
            }

            filters.clear();
        }

        GetAudioManager().RemoveAudioSource(this);
    }
}

void AudioSource::Stop(bool stopOneShots)
{
    m_HasScheduledStartDelay = false;
    m_HasScheduledEndDelay = false;

    if (m_Channel.IsValid())
        m_Channel->Stop();

    m_Channel.Clear();

    if (stopOneShots)
    {
        SoundChannelStopList stopList(m_OneShots.size_slow());
        for (TOneShots::iterator it = m_OneShots.begin(); it != m_OneShots.end(); ++it)
            stopList.Add((*it)->channel);
    }

    if (m_PlayingDSP)
        CheckFMODError(m_PlayingDSP->remove());

    AudioCustomFilter* filter = NULL;
    if (m_PlayingDSP)
        CheckFMODError(m_PlayingDSP->getUserData((void**)&filter));
    if (filter)
        filter->SetPlayingSource(NULL);

    m_PlayingDSP = NULL;

    CleanAudioSource();
}

bool AudioSource::IsPlayingScripting()
{
    return IsPlaying();
}

bool AudioSource::IsPlaying() const
{
    if (m_ScheduledSource.IsScheduled() && !m_pause)
        return true; // Waiting to play on next frame (but for the script user the AudioSource is considered playing)

    if (!m_OneShots.empty() && !m_pause)
        return true;

    if (m_Channel.IsValid())
    {
        if (m_Channel->GetPaused())
            return false;

        bool isPlaying;
        FMOD_RESULT result = m_Channel->isPlaying(&isPlaying);
        if ((result == FMOD_OK) && isPlaying)
            return true;

        return m_Channel->HasPendingPlayRequest();
    }

    return false;
}

bool AudioSource::IsPaused() const
{
    return (m_Channel.IsValid()) ? m_Channel->GetPaused() : false;
}

bool AudioSource::AreAllChannelsVirtual() const
{
    bool allVirtual = true, isVirtual;
    if (m_Channel.IsValid())
    {
        m_Channel->isVirtual(&isVirtual);
        allVirtual &= isVirtual;
    }
    for (TOneShots::const_iterator it = m_OneShots.begin(); it != m_OneShots.end(); ++it)
    {
        (*it)->channel->isVirtual(&isVirtual);
        allVirtual &= isVirtual;
    }

    for (VideoAudioDataList::const_iterator it = m_SharedVideoAudioDataList.begin(); it != m_SharedVideoAudioDataList.end(); ++it)
    {
        it->channel->isVirtual(&isVirtual);
        allVirtual &= isVirtual;
    }
    return allVirtual;
}

/**
 * Update channel properties
 * @param channel The channel to update
 * @param oneshot Is this a oneshot?
 **/

static float EvalAudioSourceCurve(const AnimationCurve& curve, float distance, float maxDistance)
{
    AssertMsg(curve.GetKeyCount() > 0, "AudioSource curve must have at least 1 key");

    if (curve.GetKeyCount() != 1 && (maxDistance > 0.0f))
    {
        float evalTime = (distance / maxDistance);
        return curve.Evaluate(evalTime);
    }
    else
    {
        return curve.GetKey(0).value;
    }
}

void AudioSource::Update3DPanParameters(SoundChannel channel, float distance)
{
    float spatialBlendLevel = clamp01(EvalAudioSourceCurve(m_AudioParameters.spatialBlendCustomCurve, distance, m_AudioParameters.maxDistance));
    float spread = clamp01(EvalAudioSourceCurve(m_AudioParameters.spreadCustomCurve, distance, m_AudioParameters.maxDistance));
    float stereoPan = clamp(m_AudioParameters.pan, -1.0f, 1.0f);

    // In spatializer mode we want to preserve channel mapping, so we set the 3D pan level to zero. To apply distance attenuation and provide a means for the user to override this, we
    // multiply it to the final volume in AudioSource::SetVolume(). This ensures that voice prioritization still works as expected. We must apply Doppler up here at the AudioSource level
    // since it is not applied to 2D sounds by FMOD. It's completely up to the spatializer to implement the spread and 2D panning parameters while it's active.
    if (m_SpatializerDSP)
    {
        CheckFMODError(channel->set3DPanLevel(0.0f));
        CheckFMODError(channel->set3DSpread(spread * 360.0f));
        CheckFMODError(channel->setPan(0.0f));
    }
    else
    {
        CheckFMODError(channel->set3DPanLevel(spatialBlendLevel));
        CheckFMODError(channel->set3DSpread(spread * 360.0f));
        CheckFMODError(channel->setPan(stereoPan));
    }

    if (m_SpatializerData != NULL)
    {
        m_SpatializerData->spatialblend = spatialBlendLevel;
        m_SpatializerData->spread = spread * 360.0f;
        m_SpatializerData->stereopan = stereoPan;
    }
}

void AudioSource::UpdateReverbZoneMix(SoundChannel channel, float distance)
{
    FMOD_REVERB_CHANNELPROPERTIES props;
    CheckFMODError(channel->getReverbProperties(&props));
    props.Room = -10000;

    if (m_SpatializerData == NULL)
    {
        float reverbZoneMix = 0.0f;
        if (!m_AudioParameters.bypassReverbZones)
        {
            // Only eval the mix if we are not bypassing the reverb zones.
            reverbZoneMix = EvalAudioSourceCurve(m_AudioParameters.reverbZoneMixCustomCurve, distance,
                    m_AudioParameters.maxDistance);

            // Clamp to include boost.
            reverbZoneMix = clamp(reverbZoneMix, 0.0f, 1.1f);
        }

        if (reverbZoneMix > 1.0f)
            props.Room = (int)((reverbZoneMix - 1.0f) * 10000.0f); // [1, 1.1] = 10 dB boost range
        else if (reverbZoneMix > 0.0f)
            props.Room = (int)(2000.0f * log10f(reverbZoneMix)); // [0, 1] = linear range
    }

    CheckFMODError(channel->setReverbProperties(&props));
}

void AudioSource::UpdateSpatializer(SoundChannel channel, float distance)
{
    if (m_SpatializerDSP == NULL || m_SpatializerData == NULL)
        return;

    const Transform& transform = GetComponent<Transform>();
    Matrix4x4f sourceMatrix;
    transform.GetLocalToWorldMatrix(sourceMatrix);

    for (int n = 0; n < 16; n++)
        m_SpatializerData->sourcematrix[n] = sourceMatrix.GetPtr()[n];

    // @TODO refactor when we support more than one listener
    // If there is no listener in the scene, assume that source and listener are at the same position.
    const AudioListener* listener = GetAudioManager().GetAudioListener();
    if (listener != NULL)
    {
        // Not using memcpy here because this data is written by the main thread and read from the mixer thread.
        // Thus we write it float by float which is an atomic operation instead of memcpy where we don't know for sure whether the underlying implementation
        // will do a byte-by-byte copy and thus might have only partially written a float when the mixer thread picks it up.
        // Of course not having any mutex protection on the arrays will result in slightly degenerate matrices if only parts of them are updated while the other
        // part has the values from the previous frame, but in practice these are small enough to be ignored.
        const float* listenerMatrix = listener->GetInverseMatrix().GetPtr();
        for (int n = 0; n < 16; n++)
            m_SpatializerData->listenermatrix[n] = listenerMatrix[n];
    }
    else
    {
        for (int n = 0; n < 16; n++)
            m_SpatializerData->listenermatrix[n] = sourceMatrix[n];
    }
}

void AudioSource::UpdateLowpassFilter(float distance)
{
    AudioLowPassFilter* lowPassFilter = QueryComponent<AudioLowPassFilter>();
    if (lowPassFilter != NULL)
    {
        float cutoffLevel = EvalAudioSourceCurve(lowPassFilter->GetCustomLowpassLevelCurve(), distance,
                m_AudioParameters.maxDistance);

        cutoffLevel = clamp01(cutoffLevel);

        float cutoffFreq = 10.0f + 21990.0f * cutoffLevel;
        lowPassFilter->SetCutoffFrequencyInternal(cutoffFreq);
    }
}

void AudioSource::UpdateDoppler(SoundChannel channel, float distance, Vector3f& position, Vector3f& velocity)
{
    float spatialBlendLevel = clamp01(EvalAudioSourceCurve(m_AudioParameters.spatialBlendCustomCurve, distance, m_AudioParameters.maxDistance));
    float dopplerPitch = 1.0f;

    // For spatialized sounds, we are telling FMOD they are 2D. This means that the Doppler effect will not applied to all sounds by FMOD,
    // so we do it here for all sounds using the same algorithm. We explicity turn off FMOD's Doppler via a global scale factor.
    const float kSpeedOfSound = 340.0f;

    AudioListener* listener = GetAudioManager().GetAudioListener();
    if ((listener != NULL) && (m_AudioParameters.dopplerLevel > 0.0f) && (spatialBlendLevel > 0.0f))
    {
        Vector3f relativeVelocity = velocity - listener->GetVelocity();
        Vector3f directionToSound = position - listener->GetPosition();
        float dopplerLevel = GetAudioManager().GetDopplerFactor() * m_AudioParameters.dopplerLevel;

        float length = Magnitude(directionToSound);
        float velocityAwayFromListener = 0.0f;
        if (length > 0.0f)
        {
            velocityAwayFromListener = Dot(relativeVelocity, directionToSound) / length;
        }

        dopplerPitch = kSpeedOfSound;
        dopplerPitch -= (velocityAwayFromListener * dopplerLevel);
        dopplerPitch /= kSpeedOfSound;

        if (dopplerPitch < .000001f)
            dopplerPitch = .000001f;

        // Adjust dopplerPitch based on the spatialBlendLevel. When spatialBlendLevel is 1.0 (fully 3D), dopplerPitch should not be changed.
        dopplerPitch = (1.0f - spatialBlendLevel) + (dopplerPitch * spatialBlendLevel);
    }

    channel->SetDopplerPitch(dopplerPitch);
}

void AudioSource::UpdateParameters()
{
    for (TOneShots::iterator it = m_OneShots.begin(); it != m_OneShots.end(); ++it)
        if ((*it)->channel.IsValid())
            UpdateParameters((*it)->channel);

    for (VideoAudioDataList::iterator it = m_SharedVideoAudioDataList.begin(); it != m_SharedVideoAudioDataList.end(); ++it)
    {
        if (it->channel.IsValid())
            UpdateParameters(it->channel);
    }

    if (m_Channel.IsValid())
        UpdateParameters(m_Channel);
}

void AudioSource::UpdateParameters(SoundChannel channel)
{
    // is this a valid channel?
    bool isPlaying = false;

    FMOD_RESULT result = channel.IsNull() ? FMOD_ERR_INVALID_HANDLE : channel->isPlaying(&isPlaying);

    if (result == FMOD_ERR_INVALID_HANDLE)
        return;

    Transform& transform = GetComponent<Transform>();

    // Position
    Vector3f p = transform.GetPosition();

    // Velocity
    // get velocity from rigidbody if present
    Vector3f v;
#if ENABLE_PHYSICS
    Rigidbody* rb = QueryComponent<Rigidbody>();
    if (rb)
        v = GetIPhysics()->GetRigidBodyVelocity(*rb);
    else
#endif
    v = (p - m_LastUpdatePosition) * GetInvDeltaTime();

    FMOD_VECTOR& pos = UNITYVEC2FMODVEC(p);
    FMOD_VECTOR& vel = UNITYVEC2FMODVEC(v);
    // Update position and velocity
    channel->set3DAttributes(&pos, &vel);

    // update distance animated props
    // distance to listener
    // @TODO refactor when we support more than one listener
    // If there is no listener in the scene, assume that source and listener are at the same position.
    float distance = 0.0f;
    const AudioListener* listener = GetAudioManager().GetAudioListener();
    if (listener != NULL)
        distance = Magnitude(p - listener->GetPosition());

    UpdateLowpassFilter(distance);
    Update3DPanParameters(channel, distance);
    UpdateReverbZoneMix(channel, distance);
    UpdateDoppler(channel, distance, p, v);
    UpdateSpatializer(channel, distance);

    // update last position
    m_LastUpdatePosition = p;

    // Needed because spatializer can modify the volume
    SetVolume(m_AudioParameters.volume);
}

void AudioSource::DoUpdate()
{
    if (!IsAddedToManager())
        return;

    UpdateParameters();
}

void AudioSource::AddToManager()
{
#if ENABLE_PROFILER
    AtomicIncrement(&s_GlobalActiveCount);
#endif

    if (m_PlayOnAwake && IsWorldPlaying())
    {
        Play();
    }

    UnmuteActiveVideoSinks();
}

void AudioSource::RemoveFromManager()
{
    Stop(true);

    Cleanup();

    MuteActiveVideoSinks();

#if ENABLE_PROFILER
    AtomicDecrement(&s_GlobalActiveCount);
#endif
}

PROFILER_INFORMATION(gAudioSourceUpdateProfile, "AudioSource.Update", kProfilerAudio)

void AudioSource::Update()
{
    PROFILER_AUTO(gAudioSourceUpdateProfile, NULL);

    if (m_VelocityUpdateMode == kVelocityUpdateModeAuto)
        m_VelocityUpdateMode = GetAudioManager().GetAutomaticUpdateMode(GetGameObjectPtr());

    if (m_VelocityUpdateMode == kVelocityUpdateModeDynamic)
        DoUpdate();
}

void AudioSource::FixedUpdate()
{
    if (m_VelocityUpdateMode == kVelocityUpdateModeAuto)
        m_VelocityUpdateMode = GetAudioManager().GetAutomaticUpdateMode(GetGameObjectPtr());

    if (m_VelocityUpdateMode == kVelocityUpdateModeFixed)
        DoUpdate();
}

// PROPERTIES
#define SET_FMOD_PARAM(setFunction, value) \
    {\
        if(m_Channel.IsValid())\
            m_Channel->setFunction(value);\
        for (TOneShots::iterator it = m_OneShots.begin(); it != m_OneShots.end();++it)\
            (*it)->channel->setFunction(value);\
        for (VideoAudioDataList::iterator it = m_SharedVideoAudioDataList.begin(); it != m_SharedVideoAudioDataList.end(); ++it)\
            it->channel->setFunction(value);\
    }

#define SET_FMOD_PARAM2(setFunction, value1, value2) \
    {\
        if(m_Channel.IsValid())\
            m_Channel->setFunction(value1, value2);\
        for (TOneShots::iterator it = m_OneShots.begin(); it != m_OneShots.end(); ++it)\
            (*it)->channel->setFunction(value1, value2);\
        for (VideoAudioDataList::iterator it = m_SharedVideoAudioDataList.begin(); it != m_SharedVideoAudioDataList.end(); ++it)\
            it->channel->setFunction(value1, value2);\
    }

#define SET_FMOD_PARAM3(setFunction, value1, value2, value3) \
    {\
        if(m_Channel.IsValid())\
            m_Channel->setFunction(value1, value2, value3);\
        for (TOneShots::iterator it = m_OneShots.begin(); it != m_OneShots.end(); ++it)\
            (*it)->channel->setFunction(value1, value2, value3);\
        for (VideoAudioDataList::iterator it = m_SharedVideoAudioDataList.begin(); it != m_SharedVideoAudioDataList.end(); ++it)\
            it->channel->setFunction(value1, value2, value3);\
    }

/// Get/Set pitch of the sound
float AudioSource::GetPitch() const
{
    return m_AudioParameters.pitch;
}

void AudioSource::SetPitch(float pitch)
{
    AudioClip* clip = m_AudioClip;
    if (!IsFinite(pitch))
    {
        WarningStringObject("Attempt to set pitch to infinite value in AudioSource::SetPitch ignored!", this);
        return;
    }
    if (IsNAN(pitch))
    {
        WarningStringObject("Attempt to set pitch to NaN value in AudioSource::SetPitch ignored!", this);
        return;
    }
    if (clip != NULL)
    {
        if (pitch < 0.0f && !clip->SupportsNegativePitch())
        {
            WarningStringObject("Attempt to set pitch to a negative value in AudioSource::SetPitch ignored! This is only supported for AudioClips which are stored in an uncompressed format or will be decompressed at load time.", this);
            return;
        }
        if (clip->IsMovieAudio())
            pitch = clamp(pitch, 0.0f, 3.0f);
    }
    if (pitch != m_AudioParameters.pitch)
    {
        m_AudioParameters.pitch = pitch;
        SetDirty();
    }
    if (m_Channel.IsValid())
        m_Channel->SetPitch(pitch);
    for (TOneShots::iterator it = m_OneShots.begin(); it != m_OneShots.end(); ++it)
    {
        SoundChannel c = (*it)->channel;
        if (c.IsValid())
            c->SetPitch(pitch);
    }
}

void AudioSource::SetSpatializePostEffectsGain(float gain)
{
    if (m_SpatializerDSP != NULL)
    {
        FMOD::DSPConnection* dspCon = NULL;
        CheckFMODError(m_SpatializerDSP->getInput(0, NULL, &dspCon));
        if (dspCon != NULL)
            CheckFMODError(dspCon->setMix(gain));
    }
}

void AudioSource::SetVolume(float volume)
{
    volume = clamp01(volume);
    if (volume != m_AudioParameters.volume)
    {
        m_AudioParameters.volume = volume;
        SetDirty();
    }

#ifdef UNITY_EXTRA_FUNCTIONALITY

    float audibilityFactor = 1.0f;
    if (m_SpatializerData != NULL && m_SpatializerDSP != NULL)
    {
        // In spatial mode we play all audio unpanned into the effect which then does all panning.
        // Hence we need to apply Unity's (or the overridden) attenuation curve to the source prior to that via the channel volume.
        // We can't let the spatializer apply the volume because FMOD needs to know about the source's volume so that it can cull inaudible sounds correctly.
        float spatializerAttenuation = 1.0f + (CalculateDistanceAttenuation() - 1.0f) * m_SpatializerData->spatialblend;
        if (m_AudioParameters.spatializePostEffects && !m_AudioParameters.bypassEffects)
        {
            SetSpatializePostEffectsGain(spatializerAttenuation);
            audibilityFactor = spatializerAttenuation;
        }
        else
        {
            SetSpatializePostEffectsGain(1.0f);
            volume *= spatializerAttenuation;
            audibilityFactor = 1.0f;
        }
    }

    if (m_dryGroup != NULL)
    {
        CheckFMODError(m_dryGroup->setAudibilityFactor(audibilityFactor));
    }

#endif

    if (m_Channel.IsValid())
        m_Channel->SetVolume(volume);
    for (TOneShots::iterator it = m_OneShots.begin(); it != m_OneShots.end(); ++it)
    {
        SoundChannel c = (*it)->channel;
        if (c.IsValid())
            c->SetVolume(volume);
    }

    for (VideoAudioDataList::iterator it = m_SharedVideoAudioDataList.begin(); it != m_SharedVideoAudioDataList.end(); ++it)
    {
        SoundChannel c = it->channel;
        if (c.IsValid())
            c->SetVolume(volume);
    }
}

// Get/Set volume of the sound
float AudioSource::GetVolume() const
{
    return m_AudioParameters.volume;
}

void AudioSource::SetPlayOnAwake(bool playOnAwake)
{
    if (m_PlayOnAwake != playOnAwake)
    {
        m_PlayOnAwake = playOnAwake;
        SetDirty();
    }
}

void AudioSource::SetIgnoreListenerPause(bool ignoreListenerPause)
{
    if (m_AudioParameters.ignoreListenerPause != ignoreListenerPause)
    {
        m_AudioParameters.ignoreListenerPause = ignoreListenerPause;
        SetDirty();
        UpdatePauseState();
    }
}

bool AudioSource::GetLoop() const
{
    return m_AudioParameters.loop;
}

void AudioSource::SetLoop(bool loop)
{
    if (loop != m_AudioParameters.loop)
    {
        m_AudioParameters.loop = loop;
        SetDirty();
    }

    if (m_Channel.IsValid())
        m_Channel->SetLoop(loop);

    // always turn looping off for oneshots
    for (TOneShots::iterator it = m_OneShots.begin(); it != m_OneShots.end(); ++it)
        (*it)->channel->SetLoop(false);
}

// Sets how much the 3d engine has an effect on the channel.
float AudioSource::GetSpatialBlendMix() const
{
    return m_AudioParameters.spatialBlendCustomCurve.GetKey(0).value;
}

void AudioSource::SetSpatialBlendMix(float level)
{
    // As panlevel is a curve
    // setting level resets the curve to 1 key
    level = clamp01(level);
    ReplaceOrAddSingleCurveValue(level, m_AudioParameters.spatialBlendCustomCurve);
    SetDirty();
}

// Sets how much the 3d engine has an effect on the channel.
float AudioSource::GetReverbZoneMix() const
{
    return m_AudioParameters.reverbZoneMixCustomCurve.GetKey(0).value;
}

void AudioSource::SetReverbZoneMix(float level)
{
    // As reverbZoneMix is a curve
    // setting level resets the curve to 1 key
    level = clamp(level, 0.0f, 1.1f);
    ReplaceOrAddSingleCurveValue(level, m_AudioParameters.reverbZoneMixCustomCurve);
    SetDirty();
}

// Sets the doppler scale for this AudioSource
float AudioSource::GetDopplerLevel() const
{
    return m_AudioParameters.dopplerLevel;
}

void AudioSource::SetDopplerLevel(float level)
{
    level = clamp(level, 0.0F, 5.0F);
    if (level != m_AudioParameters.dopplerLevel)
    {
        m_AudioParameters.dopplerLevel = level;
        SetDirty();
    }
    SET_FMOD_PARAM(set3DDopplerLevel, level);
}

// Sets the spread angle a 3d stereo ogr multichannel cound in speaker space.
// 0 = all sound channels are located at the same speaker location and is 'mono'.
// 360 = all subchannels are located at the opposite speaker location to the speaker location that it should be according to 3D position. Default = 0.
// Sets how much the 3d engine has an effect on the channel.
float AudioSource::GetSpread() const
{
    return m_AudioParameters.spreadCustomCurve.GetKey(0).value * 360.0f;
}

void AudioSource::SetSpread(float spread)
{
    // As spread is a curve
    // setting level resets the curve to 1 key
    spread = clamp(spread, 0.0f, 360.0f);
    ReplaceOrAddSingleCurveValue(spread / 360.0f, m_AudioParameters.spreadCustomCurve);
    SetDirty();
}

// Sets the priority of the [[AudioSource]]
// Unity is virtualizing AudioSources, when there's more AudioSources playing than available hardware channels.
// The AudioSources with lowest priority (and audibility) is virtualized first.
// Priority is an integer between 0 and 256. 0=highest priority, 256=lowest priority
int AudioSource::GetPriority() const
{
    return m_AudioParameters.priority;
}

void AudioSource::SetPriority(int priority)
{
    priority = clamp(priority, 0, 256);
    if (priority != m_AudioParameters.priority)
    {
        m_AudioParameters.priority = priority;
        SetDirty();
    }
    SET_FMOD_PARAM(setPriority, priority);
}

// Applies custom spatialization to the AudioSource.
bool AudioSource::GetSpatialize() const
{
    return m_AudioParameters.spatialize;
}

void AudioSource::SetSpatialize(bool spatialize)
{
    bool changed = false;
    if (spatialize != m_AudioParameters.spatialize)
    {
        m_AudioParameters.spatialize = spatialize;
        SetDirty();
        changed = true;
    }
    if (spatialize != (m_SpatializerDSP != NULL))
    {
        CreateFMODGroups();
        changed = true;
    }
    if (changed)
        ForceRolloffCurveEvaluation();
}

// Determines if the spatializer effect is inserted before or after the effect filters.
bool AudioSource::GetSpatializePostEffects() const
{
    return m_AudioParameters.spatializePostEffects;
}

void AudioSource::SetSpatializePostEffects(bool spatializePostEffects)
{
    bool changed = false;
    if (spatializePostEffects != m_AudioParameters.spatializePostEffects)
    {
        m_AudioParameters.spatializePostEffects = spatializePostEffects;
        SetDirty();
        changed = true;
    }
    if (m_SpatializerDSP != NULL)
    {
        ApplyFilters();
        changed = true;
    }
    if (changed)
        ForceRolloffCurveEvaluation();
}

bool AudioSource::SetSpatializerFloat(int index, float value)
{
    if (m_SpatializerDSP != NULL)
        return m_SpatializerDSP->setParameter(index, value) == FMOD_OK;
    return false;
}

bool AudioSource::GetSpatializerFloat(int index, float* value)
{
    if (m_SpatializerDSP != NULL)
        return m_SpatializerDSP->getParameter(index, value, NULL, 0) == FMOD_OK;
    return false;
}

// Un- / Mutes the AudioSource. Mute sets the volume=0, Un-Mute restore the original volume.
bool AudioSource::GetMute() const
{
    return m_AudioParameters.mute;
}

void AudioSource::SetMute(bool mute)
{
    if (mute != m_AudioParameters.mute)
    {
        m_AudioParameters.mute = mute;
        SetDirty();
    }

    if (m_Channel.IsValid())
        m_Channel->setMute(mute);

    for (TOneShots::iterator it = m_OneShots.begin(); it != m_OneShots.end(); ++it)
        (*it)->channel->setMute(mute);

    for (VideoAudioDataList::iterator it = m_SharedVideoAudioDataList.begin(); it != m_SharedVideoAudioDataList.end(); ++it)
    {
        SoundChannel c = it->channel;
        if (c.IsValid())
            c->setMute(mute);
    }
}

// Within the Min distance the AudioSource will cease to grow louder in volume.
// Outside the min distance the volume starts to attenuate.
float AudioSource::GetMinDistance() const
{
    return m_AudioParameters.minDistance;
}

void AudioSource::SetMinDistance(float minDistance)
{
    minDistance = std::max(minDistance, 0.0F);
    if (minDistance != m_AudioParameters.minDistance)
    {
        m_AudioParameters.minDistance = minDistance;
        SetDirty();
    }
    SET_FMOD_PARAM2(set3DMinMaxDistance, m_AudioParameters.minDistance, m_AudioParameters.maxDistance);
}

// (Logarithmic rolloff) MaxDistance is the distance a sound stops attenuating at.
// (Linear rolloff) MaxDistance is the distance where the sound is completely inaudible.
float AudioSource::GetMaxDistance() const
{
    return m_AudioParameters.maxDistance;
}

void AudioSource::SetMaxDistance(float maxDistance)
{
    maxDistance = std::max(maxDistance, m_AudioParameters.minDistance);
    if (maxDistance != m_AudioParameters.maxDistance)
    {
        m_AudioParameters.maxDistance = maxDistance;
        SetDirty();
    }
    SET_FMOD_PARAM2(set3DMinMaxDistance, m_AudioParameters.minDistance, m_AudioParameters.maxDistance);
}

/// Set/Get rolloff mode
RolloffMode AudioSource::GetRolloffMode() const
{
    return m_AudioParameters.rolloffMode;
}

void AudioSource::SetRolloffMode(RolloffMode mode)
{
    if (mode != m_AudioParameters.rolloffMode)
    {
        m_AudioParameters.rolloffMode = mode;
        SetDirty();
    }
}

/// Set/Get Custom rolloff curve
const AnimationCurve& AudioSource::GetCustomRolloffCurve() const
{
    return m_AudioParameters.rolloffCustomCurve;
}

AnimationCurve* AudioSource::GetCustomRolloffCurveCopy() const
{
    AnimationCurve* copy = new AnimationCurve();

    const AnimationCurve& curve = m_AudioParameters.rolloffCustomCurve;
    copy->Assign(curve.begin(), curve.end());

    return copy;
}

// When the user sets the custom curve and says scale to maxDistance,
// internally we scale it to 0..1 for consistency.
// This means that if a user queries the curve again, it wont be the same as what
// they set.
static void ScaleCurve(AnimationCurve& curve)
{
    float totalTime = curve.GetRange().second;
    ScaleCurveTime(curve, 1 / totalTime);
}

void AudioSource::SetCustomRolloffCurve(const AnimationCurve& curve)
{
    if (curve != m_AudioParameters.rolloffCustomCurve)
    {
        m_AudioParameters.rolloffCustomCurve = curve;
        ScaleCurve(m_AudioParameters.rolloffCustomCurve);

        ForceRolloffCurveEvaluation();
        SetDirty();
    }
}

/// Set/Get spatial blend curve
AnimationCurve* AudioSource::GetCustomSpatialBlendCurveCopy() const
{
    AnimationCurve* copy = new AnimationCurve();

    const AnimationCurve& curve = m_AudioParameters.spatialBlendCustomCurve;
    copy->Assign(curve.begin(), curve.end());

    return copy;
}

void AudioSource::SetCustomSpatialBlendCurve(const AnimationCurve& curve)
{
    if (curve != m_AudioParameters.spatialBlendCustomCurve)
    {
        m_AudioParameters.spatialBlendCustomCurve = curve;
        ScaleCurve(m_AudioParameters.spatialBlendCustomCurve);

        SetDirty();
    }
}

/// Set/Get Reverb Zone Mix curve
AnimationCurve* AudioSource::GetCustomReverbZoneMixCurveCopy() const
{
    AnimationCurve* copy = new AnimationCurve();

    const AnimationCurve& curve = m_AudioParameters.reverbZoneMixCustomCurve;
    copy->Assign(curve.begin(), curve.end());

    return copy;
}

void AudioSource::SetCustomReverbZoneMixCurve(const AnimationCurve& curve)
{
    if (curve != m_AudioParameters.reverbZoneMixCustomCurve)
    {
        m_AudioParameters.reverbZoneMixCustomCurve = curve;
        ScaleCurve(m_AudioParameters.reverbZoneMixCustomCurve);

        SetDirty();
    }
}

/// Set/Get Spread curve
AnimationCurve* AudioSource::GetCustomSpreadCurveCopy() const
{
    AnimationCurve* copy = new AnimationCurve();

    const AnimationCurve& curve = m_AudioParameters.spreadCustomCurve;
    copy->Assign(curve.begin(), curve.end());

    return copy;
}

void AudioSource::SetCustomSpreadCurve(const AnimationCurve& curve)
{
    if (curve != m_AudioParameters.spreadCustomCurve)
    {
        m_AudioParameters.spreadCustomCurve = curve;
        ScaleCurve(m_AudioParameters.spreadCustomCurve);

        SetDirty();
    }
}

/// Sets a channels pan position linearly. Only works for 2D clips.
/// -1.0 to 1.0. -1.0 is full left. 0.0 is center. 1.0 is full right.
/// Only sounds that are mono or stereo can be panned. Multichannel sounds (ie >2 channels) cannot be panned.
float AudioSource::GetStereoPan() const
{
    return m_AudioParameters.pan;
}

void AudioSource::SetStereoPan(float pan)
{
    pan = clamp(pan, -1.0f, 1.0f);
    if (pan != m_AudioParameters.pan)
    {
        m_AudioParameters.pan = pan;
        SetDirty();
    }

    UpdateParameters();
}

/// Bypass/ignore any applied effects on AudioSource
bool AudioSource::GetBypassEffects() const
{
    return m_AudioParameters.bypassEffects;
}

void AudioSource::SetBypassEffects(bool bypassEffect)
{
    if (m_AudioParameters.bypassEffects != bypassEffect)
    {
        m_AudioParameters.bypassEffects = bypassEffect;
        SetDirty();
    }
    ConfigureFMODGroups();
}

/// Bypass/ignore any applied effects on AudioSource
bool AudioSource::GetBypassListenerEffects() const
{
    return m_AudioParameters.bypassListenerEffects;
}

void AudioSource::SetBypassListenerEffects(bool bypassListenerEffect)
{
    if (m_AudioParameters.bypassListenerEffects != bypassListenerEffect)
    {
        m_AudioParameters.bypassListenerEffects = bypassListenerEffect;
        SetDirty();
    }
    ConfigureFMODGroups();
}

bool AudioSource::GetBypassReverbZones() const
{
    return m_AudioParameters.bypassReverbZones;
}

/// Bypass effect of reverb zones on this AudioSource
void AudioSource::SetBypassReverbZones(bool bypassReverbZones)
{
    if (m_AudioParameters.bypassReverbZones != bypassReverbZones)
    {
        m_AudioParameters.bypassReverbZones = bypassReverbZones;
        SetDirty();
    }
    ConfigureFMODGroups();
}

float AudioSource::GetSecPosition() const
{
    if (m_Channel.IsValid())
    {
        unsigned int time = 0;
        return (m_Channel->GetPositionMS(&time) == FMOD_OK) ? (time * 0.001f) : 0.0f;
    }
    else if (m_AudioClip)
    {
        float clipFreq = (float)m_AudioClip->GetFrequency();
        return (clipFreq <= 0.0f) ? 0.0f : ((float)m_samplePosition / clipFreq);
    }

    return 0.0f;
}

void AudioSource::SetSecPosition(float secPosition)
{
    unsigned posPCM = 0;
    AudioClip* clipPtr = m_AudioClip;

    if (clipPtr)
    {
        posPCM = (secPosition * (float)clipPtr->GetFrequency());
        if (m_Channel.IsValid())
            m_Channel->SetPositionPCM(posPCM);
    }

    m_samplePosition = posPCM;
}

UInt32 AudioSource::GetSamplePosition() const
{
    unsigned position = m_samplePosition;
    if (m_Channel.IsValid())
        m_Channel->GetPositionPCM(&position);
    return position;
}

void AudioSource::SetSamplePosition(UInt32 position)
{
    if (m_Channel.IsValid())
        m_Channel->SetPositionPCM(position);
    m_samplePosition = position;
}

void AudioSource::SetScheduledStartTime(double time)
{
    if (m_Channel.IsValid())
    {
        m_HasScheduledStartDelay = true;
        int sampleRate;
        GetAudioManager().GetFMODSystem()->getSoftwareFormat(&sampleRate, NULL, NULL, NULL, NULL, NULL);
        UInt64 sample = (UInt64)(time * sampleRate) + GetAudioManager().GetAccumulatedPauseTicks();
        unsigned hiclock = sample >> 32;
        unsigned loclock = sample & 0xFFFFFFFF;
        m_Channel->setDelay(FMOD_DELAYTYPE_DSPCLOCK_START, hiclock, loclock);
    }
}

void AudioSource::SetScheduledEndTime(double time)
{
    if (m_Channel.IsValid())
    {
        m_HasScheduledEndDelay = true;
        int sampleRate;
        GetAudioManager().GetFMODSystem()->getSoftwareFormat(&sampleRate, NULL, NULL, NULL, NULL, NULL);
        UInt64 sample = (UInt64)(time * sampleRate) + GetAudioManager().GetAccumulatedPauseTicks();
        unsigned hiclock = sample >> 32;
        unsigned loclock = sample & 0xFFFFFFFF;
        m_Channel->setDelay(FMOD_DELAYTYPE_DSPCLOCK_END, hiclock, loclock);
    }
}

void AudioSource::GetOutputData(float* samples, int numSamples, int channelOffset)
{
    if (m_dryGroup != NULL)
    {
        CheckFMODError(m_dryGroup->getWaveData(samples, numSamples, channelOffset));
    }
    else
    {
        // If we have not initialized the channelgroup yet, then
        // just zero out the samples.
        memset(samples, 0, numSamples * sizeof(float));
    }
}

/// Gets the current spectrum data
void AudioSource::GetSpectrumData(float* samples, int numSamples, int channelOffset, FMOD_DSP_FFT_WINDOW windowType)
{
    if (m_dryGroup != NULL)
    {
        CheckFMODError(m_dryGroup->getSpectrum(samples, numSamples, channelOffset, windowType));
    }
    else
    {
        // If we have not initialized the channelgroup yet, then
        // just zero out the samples.
        memset(samples, 0, numSamples * sizeof(float));
    }
}

// Apply filters
void AudioSource::ApplyFilters()
{
    if (!m_wetGroup)
        return;

    TFilters filters;
    GetFilterComponents(filters, true);

    for (TFilters::const_iterator it = filters.begin(); it != filters.end(); it++)
    {
        FMOD::DSP* dsp = *it;

        if (dsp == m_PlayingDSP)
            continue;

        CheckFMODError(dsp->remove());
        CheckFMODError(m_wetGroup->addDSP(dsp, 0));
    }

    if (m_SpatializerDSP != NULL)
    {
        CheckFMODError(m_SpatializerDSP->remove());  // This must always be called before adding the DSP effect, otherwise DSP connections go haywire.
        if (!m_AudioParameters.bypassEffects && m_AudioParameters.spatializePostEffects)
            CheckFMODError(m_wetGroup->addDSP(m_SpatializerDSP, NULL));
        else
            CheckFMODError(m_dryGroup->addDSP(m_SpatializerDSP, NULL));
    }
}

void AudioSource::UpdateEffectVirtualizationState(bool force)
{
    if (!force && !GetAudioManager().IsEffectVirtualizationEnabled())
        return;

    // When turning effect virtualization off, we'll enable all effects.
    // If we just turned it on, force is also true, but in this case we need to toggle the effect activation based on the current channel virtualization state.
    bool active = (force && !GetAudioManager().IsEffectVirtualizationEnabled()) || !AreAllChannelsVirtual();

    if (m_SpatializerDSP != NULL)
    {
        CheckFMODError(m_SpatializerDSP->setActive(active));
    }

    const GameObject* go = GetGameObjectPtr();
    if (go != NULL)
    {
        active &= !m_AudioParameters.bypassEffects;
        for (int i = 0; i < go->GetComponentCount(); i++)
        {
            AudioFilter* filter = dynamic_pptr_cast<AudioFilter*>(&go->GetComponentAtIndex(i));
            if (filter)
                filter->GetDSP()->setActive(active);
        }
    }

    // It's tempting to also call setActive on m_wetGroup and m_dryGroup here, but so far it has led to very erratic behavior because it seems tightly related to the way FMOD starts up
    // the wavetable generators (and probably would completely break PS3 where the mixer is implemented differently). Fortunately the overhead of channel group DSP heads is very small.
}

void AudioSource::PlayOneShot(AudioClip& clip, float volumeScale)
{
    if (GetAudioManager().IsAudioDisabled())
        return;

    if (!IsAddedToManager())
    {
        WarningStringObject("Can not play a disabled audio source", this);
        return;
    }

    CreateFMODGroups();

    if (clip.GetLoadState() == SoundHandleShared::kUnloaded)
        clip.LoadAudioData();

    OneShot* oneshot = UNITY_NEW(OneShot, kMemAudio);
    oneshot->channel = clip.AllocateChannel(true);
    if (oneshot->channel.IsNull())
    {
        UNITY_DELETE(oneshot, kMemAudio);
        return;
    }

    clip.IncrementPlayCount();

    oneshot->channel->SetFlag(SoundChannelInstance::ONESHOT);
    oneshot->channel->SetOneshotVolume(volumeScale);
    oneshot->channel->SetLoop(false);
    oneshot->channel->SetAudioSource(this);

    ApplyFilters();

    if (m_dryGroup != NULL)
        oneshot->channel->setChannelGroup(m_dryGroup);

    Vector3f pos = GetComponent<Transform>().GetPosition();
    FMOD_VECTOR fpos = UNITYVEC2FMODVEC(pos);
    oneshot->channel->set3DAttributes(&fpos, 0);

    // start!
    m_OneShots.push_back(*oneshot);
    AssignProps(); // Apply all parameters
    UpdateParameters(oneshot->channel);

    //If this source is in a paused state, then dont play the oneshot.. yet
    GetAudioManager().AddAudioSource(this);
    UnPause();
}

void AudioSource::SetIgnoreListenerVolume(bool ignore)
{
    if (m_IgnoreListenerVolume == ignore)
        return;

    m_IgnoreListenerVolume = ignore;
    ConfigureFMODGroups();
}

VideoAudioData* AudioSource::CreateSharedVideoAudioData(UInt32 numChannels, UInt32 sampleRate)
{
    // Create the data structure and set up the fmod DSP and channel.
    // make sure that the position and routing etc are updated for this sound too

    CreateFMODGroups();

    VideoAudioData* data = UNITY_NEW(VideoAudioData, kMemVideo)(numChannels, sampleRate);
    if (!data->InitFMOD(this))
    {
        UNITY_DELETE(data, kMemVideo);
        return NULL;
    }

    m_SharedVideoAudioDataList.push_back(*data);

    data->channel->setChannelGroup(m_dryGroup);
    ApplyFilters();
    AssignProps();

    UpdateParameters(data->channel);

    //If this source is in a paused state, then dont play the oneshot.. yet
    GetAudioManager().AddAudioSource(this);

    return data;
}

void AudioSource::ReleaseSharedVideoAudioData(VideoAudioData* data)
{
    // Kill the FMOD stuff and delete the data structure.
    // This is ok because this is called from the video side, so will not be used
    // again by that side

    Assert(data != NULL);
    data->ReleaseFMOD();
    data->RemoveFromList();

    UNITY_DELETE(data, kMemVideo);

    CleanAudioSource();
}

void AudioSource::MuteActiveVideoSinks()
{
    if (!m_SharedVideoAudioDataList.empty())
    {
        for (VideoAudioDataList::iterator it = m_SharedVideoAudioDataList.begin(); it != m_SharedVideoAudioDataList.end(); ++it)
        {
            SoundChannel c = it->channel;
            if (c.IsValid())
                c->setMute(true);
        }

        CleanAudioSource(true);
    }
}

void AudioSource::UnmuteActiveVideoSinks()
{
    if (!m_SharedVideoAudioDataList.empty())
    {
        CreateFMODGroups();

        for (VideoAudioDataList::iterator it = m_SharedVideoAudioDataList.begin(); it != m_SharedVideoAudioDataList.end(); ++it)
        {
            SoundChannel c = it->channel;
            if (c.IsValid())
            {
                c->setChannelGroup(m_dryGroup);
                UpdateParameters(c);

                c->setMute(GetMute());
            }
        }

        ApplyFilters();
        AssignProps();
    }
}

void AudioSource::KillActiveVideoSinks()
{
    const bool hadSharedVideoAudioData = !m_SharedVideoAudioDataList.empty();
    while (!m_SharedVideoAudioDataList.empty())
    {
        VideoAudioData& data = m_SharedVideoAudioDataList.front();
        data.ReleaseFMOD();
        data.RemoveFromList();

        // We do not actually want to delete here because the VideoPlayback could be writing
        // into it. Let the video playback destroy it.
        data.delayedDestroy = true;
    }

    if (hadSharedVideoAudioData)
        CleanAudioSource();
}

#if PS4_PAD_SPEAKER
bool AudioSource::SetPS4DualShock4OutputDevice(SceUserServiceUserId userId)
{
    if (userId == DUALSHOCK4_OUTPUT_DISABLED)
    {
        m_PlayOnDualShock4 = false;
        return true;
    }


    // As this is called from user script code we need validate the supplied userId
    //
    if (SCE_USER_SERVICE_USER_ID_INVALID == userId)
    {
        return false;
    }

    // ... and ensure it matches one of the currently logged in users
    //
    SceUserServiceLoginUserIdList userIdList;
    if (sceUserServiceGetLoginUserIdList(&userIdList) < 0)
    {
        return false;
    }
    for (int i = 0; i < SCE_USER_SERVICE_MAX_LOGIN_USERS; ++i)
    {
        if (userId == userIdList.userId[i])
        {
            m_UserId = userId;
            m_PlayOnDualShock4 = true;

            return true;
        }
    }

    return false;
}

bool AudioSource::SetPS4DualShock4OutputDevicePadIndex(int padIndex)
{
    if (padIndex == DUALSHOCK4_OUTPUT_DISABLED)
    {
        m_PlayOnDualShock4 = false;
        return true;
    }


    if (padIndex < SCE_USER_SERVICE_MAX_LOGIN_USERS)
    {
        struct PS4LoggedInUser& GetLoggedInUser(int slot);
        SceUserServiceUserId userId = GetLoggedInUser(padIndex).userId;
        if (SCE_USER_SERVICE_USER_ID_INVALID != userId)
        {
            m_UserId = userId;
            m_PlayOnDualShock4 = true;

            return true;
        }
    }

    return false;
}

static int GetPadIndex(SceUserServiceUserId userId)
{
    SceUserServiceLoginUserIdList userIdList;
    if (SCE_OK == sceUserServiceGetLoginUserIdList(&userIdList))
    {
        for (int i = 0; i < SCE_USER_SERVICE_MAX_LOGIN_USERS; ++i)
        {
            if (userId == userIdList.userId[i])
            {
                return i;
            }
        }
    }

    return -1;
}

// Mix level API
bool AudioSource::SetPS4DualShock4PadSpeakerMixLevel(SceUserServiceUserId userId, int mixLevel)
{
    // As this is called from user script code we need validate the supplied userId
    //
    if (SCE_USER_SERVICE_USER_ID_INVALID == userId)
    {
        return false;
    }

    return SetPS4DualShock4PadSpeakerMixLevelPadIndex(GetPadIndex(userId), mixLevel);
}

bool AudioSource::SetPS4DualShock4PadSpeakerMixLevelPadIndex(int padIndex, int mixLevel)
{
    return GetAudioManager().SetDualShock4PadSpeakerMixLevel(padIndex, mixLevel);
}

// Mix level API - reset to default
//
bool AudioSource::SetPS4DualShock4PadSpeakerMixLevelDefault(SceUserServiceUserId userId)
{
    return SetPS4DualShock4PadSpeakerMixLevel(userId, SCE_AUDIO_OUT_MIXLEVEL_PADSPK_DEFAULT);
}

bool AudioSource::SetPS4DualShock4PadSpeakerMixLevelDefaultPadIndex(int padIndex)
{
    return SetPS4DualShock4PadSpeakerMixLevelPadIndex(padIndex, SCE_AUDIO_OUT_MIXLEVEL_PADSPK_DEFAULT);
}

// Restricted audio API
//
bool AudioSource::SetPS4DualShock4PadSpeakerRestrictedAudio(SceUserServiceUserId userId, bool restricted)
{
    return SetPS4DualShock4PadSpeakerRestrictedAudioPadIndex(GetPadIndex(userId), restricted);
}

bool AudioSource::SetPS4DualShock4PadSpeakerRestrictedAudioPadIndex(int padIndex, bool restricted)
{
    return GetAudioManager().SetDualShock4PadSpeakerRestrictedAudioPadIndex(padIndex, restricted);
}

#endif

float inline CalcOALGain(float rolloffFactor, float volume, float minVolume, float maxVolume, float distance)
{
    float gain = 1.0f;
    if (1.0f + rolloffFactor * (distance - 1.0f) >  0.0f)
        gain = 1.0f / (1.0f + rolloffFactor * (distance - 1.0f));

    gain *= volume;
    gain = std::min(gain, maxVolume);
    gain = std::max(gain, minVolume);
    return gain;
}

/**
 * Create a custom rolloff curve from old <3.0 parameters
 **/

void AudioSource::CreateOpenALRolloff(float rolloffFactor, float minVolume, float maxVolume)
{
    AnimationCurve& curve = m_AudioParameters.rolloffCustomCurve;
    curve.RemoveKeys(curve.begin(), curve.end());

    // insert first key
    AnimationCurve::Keyframe key;
    key.time = 0.0f;
    key.value = CalcOALGain(rolloffFactor, m_AudioParameters.volume, minVolume, maxVolume, 0.0f);
    curve.AddKey(key);

    for (float distance = 0.1f; distance < m_AudioParameters.maxDistance; distance *= 2)
    {
        AnimationCurve::Keyframe key;
        key.time = distance;
        key.value = CalcOALGain(rolloffFactor, m_AudioParameters.volume, minVolume, maxVolume, distance);
        // add some sensible in/out slopes
        float s = distance / 10.0f;
        key.inSlope = (key.value - CalcOALGain(rolloffFactor, m_AudioParameters.volume, minVolume, maxVolume, distance - s)) / s;
        key.outSlope = (CalcOALGain(rolloffFactor, m_AudioParameters.volume, minVolume, maxVolume, distance + s) - key.value) / s;
        curve.AddKey(key);
    }

    key.time = m_AudioParameters.maxDistance;
    key.value = CalcOALGain(rolloffFactor, m_AudioParameters.volume, minVolume, maxVolume, m_AudioParameters.maxDistance);
    curve.AddKey(key);
}

bool AudioSource::GetFilterComponents(TFilters& filters, bool create) const
{
    const GameObject* go = GetGameObjectPtr();

    if (!go)
        return false;

    for (int i = 0; i < go->GetComponentCount(); i++)
    {
        AudioFilter* filter = NULL;
        FMOD::DSP* dsp = NULL;
        filter = dynamic_pptr_cast<AudioFilter*>(&go->GetComponentAtIndex(i));
        // built-in filter are only available in PRO
        if (filter)
            dsp = filter->GetDSP();

        if (!dsp)
        {
            MonoBehaviour* behaviour = dynamic_pptr_cast<MonoBehaviour*>(&go->GetComponentAtIndex(i));
            if (behaviour)
            {
                if (create)
                    dsp = behaviour->GetOrCreateDSP();
                else
                    dsp = behaviour->GetDSP();
            }
        }

        if (dsp)
            filters.push_back(dsp);
    }

    return !filters.empty();
}

#if UNITY_WIIU
void AudioSource::SetWiiUOutputDevice(FMOD_WIIU_CONTROLLER controller)
{
    m_WiiUOutputDevice = controller;
    AssignProps();
}

#endif

template<class TransferFunc>
void AudioSource::Transfer(TransferFunc& transfer)
{
    Super::Transfer(transfer);

    // 3.5  3: Normalized curve values
    // 3.0  2: FMOD custom rolloff data
    // <3.0 1: OpenAL rolloff data
    transfer.SetVersion(4);

    //Check if we need to try and copy the Legacy 3D information from the attached AudioClip
    if (!transfer.IsCurrentVersion())
        m_DoLegacy3DTransfer = true;

    if (transfer.IsOldVersion(1))
    {
        transfer.Transfer(m_AudioClip, "m_audioClip");
        TRANSFER(m_PlayOnAwake);
        transfer.Align();

        transfer.Transfer(m_AudioParameters.volume, "m_Volume");
        transfer.Transfer(m_AudioParameters.pitch, "m_Pitch");

        float minVolume, maxVolume;
        transfer.Transfer(minVolume, "m_MinVolume");
        transfer.Transfer(maxVolume, "m_MaxVolume");
        float rolloffFactor;
        transfer.Transfer(rolloffFactor, "m_RolloffFactor");

        transfer.Transfer(m_AudioParameters.loop, "Loop");      // repeat sound

        CreateOpenALRolloff(rolloffFactor, minVolume, maxVolume);

        m_AudioParameters.rolloffMode = kRolloffCustom;
    }
    else
    {
        transfer.Transfer(m_OutputAudioMixerGroup, "OutputAudioMixerGroup");
        transfer.Transfer(m_AudioClip, "m_audioClip");
        TRANSFER(m_PlayOnAwake);
        transfer.Align();

        transfer.Transfer(m_AudioParameters.volume, "m_Volume");
        transfer.Transfer(m_AudioParameters.pitch, "m_Pitch");

        transfer.Transfer(m_AudioParameters.loop, "Loop");      // repeat sound
        transfer.Transfer(m_AudioParameters.mute, "Mute");
        transfer.Transfer(m_AudioParameters.spatialize, "Spatialize");
        transfer.Transfer(m_AudioParameters.spatializePostEffects, "SpatializePostEffects");
        transfer.Align();

        transfer.Transfer(m_AudioParameters.priority, "Priority");
        transfer.Transfer(m_AudioParameters.dopplerLevel, "DopplerLevel");

        transfer.Transfer(m_AudioParameters.minDistance, "MinDistance");
        transfer.Transfer(m_AudioParameters.maxDistance, "MaxDistance");

        transfer.Transfer(m_AudioParameters.pan, "Pan2D");

        SInt32 mode = (SInt32)m_AudioParameters.rolloffMode;
        transfer.Transfer(mode, "rolloffMode");
        m_AudioParameters.rolloffMode = (RolloffMode)mode;

        transfer.Transfer(m_AudioParameters.bypassEffects, "BypassEffects");
        transfer.Transfer(m_AudioParameters.bypassListenerEffects, "BypassListenerEffects");
        transfer.Transfer(m_AudioParameters.bypassReverbZones, "BypassReverbZones");

        transfer.Align();

        // @TODO strip these from the player build if they're empty?
        transfer.Transfer(m_AudioParameters.rolloffCustomCurve, "rolloffCustomCurve");
        transfer.Transfer(m_AudioParameters.spatialBlendCustomCurve, "panLevelCustomCurve");
        transfer.Transfer(m_AudioParameters.spreadCustomCurve, "spreadCustomCurve");
        transfer.Transfer(m_AudioParameters.reverbZoneMixCustomCurve, "reverbZoneMixCustomCurve");

        if (transfer.IsOldVersion(2))
        {
            // Normalize curves so time goes from 0 to 1
            ScaleCurveTime(m_AudioParameters.rolloffCustomCurve, 1.0f / m_AudioParameters.maxDistance);
            ScaleCurveTime(m_AudioParameters.spatialBlendCustomCurve, 1.0f / m_AudioParameters.maxDistance);
            ScaleCurveTime(m_AudioParameters.spreadCustomCurve, 1.0f / m_AudioParameters.maxDistance);
        }
    }
}

void AudioSource::UnbindFromChannelInstance(const WeakPtr<SoundChannelInstance>& weakptr)
{
    if (m_Channel.Equals(weakptr))
    {
        m_Channel.Clear();

        m_HasScheduledStartDelay = false;
        m_HasScheduledEndDelay = false;

        GetAudioManager().UnScheduleSource(this);
    }
    else
    {
        TOneShots::iterator it = m_OneShots.begin();
        while (it != m_OneShots.end())
        {
            OneShot* oneshot = &(**it++);
            if (oneshot->channel.Equals(weakptr))
                UNITY_DELETE(oneshot, kMemAudio);
        }
    }
}

void AudioSource::OnAddComponent()
{
    ApplyFilters();
}

void AudioSource::InitializeClass()
{
    REGISTER_MESSAGE_VOID(kDidAddComponent, OnAddComponent);
}

void AudioSource::CleanupClass()
{
}

IMPLEMENT_REGISTER_CLASS(AudioSource, 82);
IMPLEMENT_OBJECT_SERIALIZE(AudioSource);

#endif //ENABLE_AUDIO
