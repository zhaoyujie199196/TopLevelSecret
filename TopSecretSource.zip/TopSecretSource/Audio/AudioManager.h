#ifndef AUDIOMANAGER_H
#define AUDIOMANAGER_H

#include "Configuration/UnityConfigure.h"
#include "Runtime/BaseClasses/GameManager.h"
#include "Runtime/Math/Vector3.h"
#include "Runtime/Utilities/GUID.h"
#include "Runtime/Utilities/LinkedList.h"
#include "Runtime/Profiler/ProfilerStats.h"
#include "Runtime/Misc/Player.h"
#include "Runtime/Audio/AudioTypes.h"
#include "Runtime/Audio/AudioConfiguration.h"
#include "Runtime/Mono/MonoIncludes.h"

#include "Runtime/Audio/AudioScriptBufferManager.h"
#include "Runtime/Audio/sound/SoundChannel.h"
#include "Runtime/Audio/sound/SoundManager.h"

#if UNITY_PS4
#include "PlatformDependent/PS4/Source/Audio/AudioDspPS4.h" // contains DualShock4_DSPRead / DualShock4_DSPCreate / DualShock4_DSPRelease / DualShock4_DSPFeeder implementation
#endif

#if ENABLE_AUDIO

#include "Runtime/Audio/correct_fmod_includer.h" // can't forward declare enums (@TODO use ints?)

#if UNITY_EDITOR
#include "Editor/Src/Audio/Mixer/AudioMixerDescription.h"
#endif

class AudioSource;
class AudioListener;
class AudioClip;
class AudioMixer;
class IWWWStream;
class AudioFilter;
class AudioReverbZone;
class AudioEffectInternalDefinition;
class GameObject;
struct MonoDomain;
struct MonoThread;
namespace FMOD
{ class System; class Sound; class Channel; class ChannelGroup; }

enum
{
    kVelocityUpdateModeAuto = 0,
    kVelocityUpdateModeFixed = 1,
    kVelocityUpdateModeDynamic = 2,
};

class AudioManager : public GlobalGameManager
{
    REGISTER_CLASS(AudioManager);
    DECLARE_OBJECT_SERIALIZE();
public:
    AudioManager(MemLabelId label, ObjectCreationMode mode);
    // virtual ~AudioManager (); declared-by-macro

    virtual void Reset();

    virtual void MainThreadCleanup();

    void FixMasterGroupRouting();

    void Update();
    void FixedUpdate();

    void AddAudioSource(AudioSource* s);
    void RemoveAudioSource(AudioSource* s);
    void StopSources();
    void RebindAudioSourcesToMixer(AudioMixer* mixer);
    void OnMixerChanged();
    void OnEnterPlayModePreStart();
    void OnExitPlayMode();

    void AddAudioListener(AudioListener* newListener);
    void RemoveAudioListener(AudioListener* newListener);
    AudioListener* GetAudioListener() const;

    void AddAudioMixer(AudioMixer* mixer);
    void RemoveAudioMixer(AudioMixer* mixer);
    void CleanupDependentMixers(AudioMixer* mixer);
    bool GroupGUIDHasDependentMixers(const UnityGUID& guid);

    void SetVolume(float volume);
    float GetVolume() const;
    void SetListenerPause(bool pause);
    bool GetListenerPause() const;
    void SetApplicationPause(bool pause);
    bool ShouldSourcePause(bool ignoreListenerPause);

    int GetAutomaticUpdateMode(GameObject *go);

    bool SetActiveOutputDriver(FMOD_GUID* guid);
    void SetDefaultMicrophoneDriver(FMOD_GUID* guid);

    // Manager implementation
    void AwakeFromLoad(AwakeFromLoadMode awakeMode);
    static void InitializeClass();
    static void CleanupClass();
    static void DidReloadDomain();
    static void BeforeDomainUnload();

    void UpdateListener(const Vector3f& position,
        const Vector3f& velocity,
        const Vector3f& up,
        const Vector3f& forward);

    class AudioScheduledSource : public ListElement
    {
    public:
        AudioScheduledSource(AudioSource* src) : source(src), time(0.0) {}
        inline ~AudioScheduledSource() { ListElement::RemoveFromList(); }
        inline bool IsScheduled() const { return IsInList(); }
        AudioSource* source;
        double time;
    };

private:

    float m_DefaultVolume;
    float m_Volume;  ///< Global attenuation setting.
    float m_Rolloffscale;  ///< TransferName{Rolloff Scale} The scaling factor at which distance rolloff curves are applied.
    bool  m_IsPaused;
    bool  m_IsApplicationPaused;
    bool  m_ProfilingEnabled;

    typedef List<ListNode<AudioSource> > TAudioSources;
    typedef List<ListNode<AudioListener> > TAudioListeners;
    typedef List<AudioScheduledSource> TScheduledSources;
    typedef List<ListNode<AudioMixer> > TAudioMixers;
    typedef TAudioSources::iterator TAudioSourcesIterator;
    typedef TAudioListeners::iterator TAudioListenersIterator;
    typedef TScheduledSources::iterator TScheduledSourcesIterator;
    typedef TAudioMixers::iterator TAudioMixersIterator;

    TAudioSources m_Sources;
    TAudioListeners m_Listeners;
    TScheduledSources m_ScheduledSources;
    TAudioMixers m_Mixers;
#if ENABLE_AUDIO_MANAGER_BASED_SCHEDULING
    UInt64 m_lastDSPClock;
#endif

    void ProcessScheduledSources();
#if ENABLE_MICROPHONE
    SoundHandle::Instance* CreateSound(int deviceID, int lengthSec, int frequency, SampleClip* sampleClip);
#endif // ENABLE_MICROPHONE

    void UpdatePauseState();

public:
    float GetDopplerFactor() const { return m_DopplerFactor; }
    float GetRolloffScale() const { return m_Rolloffscale; }
    bool IsAudioDisabled() const { return m_DisableAudio; }
    bool IsEffectVirtualizationEnabled() const { return m_VirtualizeEffects; }

#if UNITY_EDITOR
    bool IsAudioDisabledInStandalone() const { return false; }
#else
    bool IsAudioDisabledInStandalone() const { return m_DisableAudio; }
#endif

    void SetProfilerCaptureFlags(int flags) { m_ProfilerCaptureFlags = flags; }
    int GetProfilerCaptureFlags() const { return m_ProfilerCaptureFlags; }

    /// Schedule source to be played in sync. In this frame (if delay==0) or later
    inline UInt64 GetAccumulatedPauseTicks() const { return m_accPausedTicks; }
    void ScheduleSource(AudioSource* s, double time);
    void UnScheduleSource(AudioSource* s);
    double GetDSPTime() const;
    UInt64 GetRealDSPTime() const;

    UInt32 GetNumDevices() const;

    SoundManager* GetSoundManager();
    dynamic_array<AudioEffectInternalDefinition*>& GetAudioEffectInternalDefinitions();

    void AddAudioReverbZone(AudioReverbZone* z);
    void RemoveAudioReverbZone(AudioReverbZone* z);

#if UNITY_EDITOR
    void EditorMasterDSPCallback(float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int outchannels);
    inline bool IsUsingRMSMetering() const { return m_IsUsingRMSMetering; }
    inline bool CanUseSpatializerEffect() const { return m_CanUseSpatializerEffect; }
    void GetSpatializerNames(std::vector<core::string>& pluginNames);
    void SetSpatializerName(core::string pluginName);
#endif

    bool RequiresCustomSpatializer() const;
    AudioEffectInternalDefinition* GetCurrentSpatializerDefinition();
    const char* GetCurrentSpatializerDefinitionName();

    // FMOD
    bool ValidateFMODResult(FMOD_RESULT result, const char* errmsg);
    bool InitFMOD();
    void ShutdownReinitializeAndReload();

    bool InitNormal();
#if UNITY_ANDROID || UNITY_TIZEN || UNITY_SWITCH
    bool StopOutput();
    bool StartOutput();
    void OverrideVolume(float);
#endif

    void CloseFMOD();
    inline FMOD::System* GetFMODSystem() const { return m_FMODSystem; }
    static FMOD_RESULT F_CALLBACK systemCallback(FMOD_SYSTEM* c_system, FMOD_SYSTEM_CALLBACKTYPE type, void* data1, void* data2);

    // groups
    inline FMOD::ChannelGroup* GetChannelGroup_FMOD_Master() const { return m_ChannelGroup_FMODMaster; }
    inline FMOD::ChannelGroup* GetChannelGroup_FX_IgnoreVolume() const { return m_ChannelGroup_FX_IgnoreVolume; }
    inline FMOD::ChannelGroup* GetChannelGroup_FX_UseVolume() const { return m_ChannelGroup_FX_UseVolume; }
    inline FMOD::ChannelGroup* GetChannelGroup_NoFX_IgnoreVolume() const { return m_ChannelGroup_NoFX_IgnoreVolume; }
    inline FMOD::ChannelGroup* GetChannelGroup_NoFX_UseVolume() const { return m_ChannelGroup_NoFX_UseVolume; }

    inline bool GetProfilingEnabled() const { return m_ProfilingEnabled; }

#if PS4_PAD_SPEAKER
    FMOD::ChannelGroup* CreateNewDualShock4DSP(SceUserServiceUserId userId, DualShock4Speaker& speaker);
    FMOD::ChannelGroup* GetChannelGroup_DualShock4Speaker(SceUserServiceUserId userId);
    bool SetDualShock4PadSpeakerMixLevel(int padIndex, int mixLevel);
    bool SetDualShock4PadSpeakerRestrictedAudioPadIndex(int padIndex, bool restricted);
#endif

    // FMOD profiling
    int GetMemoryAllocated() const;
    float GetCPUUsage() const;
    int GetPlayingSourceCount() const;
    #if ENABLE_PROFILER
    void GetProfilerData(AudioStats& audioStats);
    #endif


    SoundHandle::Instance* CreateFMODSoundFromWWW(IWWWStream* webStream,
        FMOD_SOUND_TYPE suggestedtype,
        FMOD_SOUND_FORMAT format,
        unsigned freq,
        unsigned channels,
        bool stream,
        bool compressed,
        SampleClip* sampleClip);

    SoundHandle::Instance* CreateFMODSoundFromMovie(AudioClip* clip);

    unsigned GetPlayingChannelsForSound(FMOD::Sound* sound);
    const core::string& GetLastError() const { return m_LastErrorString; }

    FMOD_SPEAKERMODE GetSpeakerMode() const { return m_speakerMode; }
    FMOD_SPEAKERMODE GetSpeakerModeCaps() const { return m_speakerModeCaps; }
    int GetSpeakerCount() const;

    void CheckConsistency();

    AudioConfigurationScripting GetConfiguration();
    bool SetConfiguration(const AudioConfigurationScripting& config);

public:

#if ENABLE_MICROPHONE
    // Microphone
    const std::vector<core::string> GetRecordDevices() const;
    bool EndRecord(int deviceID);
    PPtr<AudioClip> StartRecord(int deviceID, bool loop, int lengthSec, int frequency);
    bool IsRecording(int deviceID) const;
    unsigned GetRecordPosition(int deviceID) const;
    int GetMicrophoneDeviceIDFromName(const core::string& name) const;
    void GetDeviceCaps(int deviceID, int *minFreq, int *maxFreq) const;

    mutable std::map<core::string, int> m_MicrophoneNameToIDMap;

    PPtr<AudioClip> GetMicAudioClip(int deviceID);

    typedef std::map<int, PPtr<AudioClip> > TMicAudioClipsMap;
    typedef TMicAudioClipsMap::iterator TMicAudioClipsMapItr;

    TMicAudioClipsMap m_MicAudioClips;

#endif // ENABLE_MICROPHONE


private:
    float m_DopplerFactor;  ///< TransferName{Doppler Factor} The scaling factor at which doppler is calculated.

    typedef List<ListNode<AudioReverbZone> > TAudioReverbZones;
    typedef TAudioReverbZones::iterator TAudioReverbZonesIterator;
    TAudioReverbZones m_ReverbZones;

    // FMOD
    FMOD::System* m_FMODSystem;

    /*                                         +----------------+
     *                                         | NoFX_UseVolume |
     *                                        /+----------------+
     *                 _+-------------------+/
     *                / | NoFX_IgnoreVolume |
     *  +-----------+/  +-------------------+
     *  |FMOD Master|                                             ...............
     *  +-----------+\  +------------------+                      : AudioSource :
     *     ^          \_| FX_IgnoreVolume  |                    __:__+-----+    :
     *     |            +------------------+\ +--------------+ /  :  | Wet |    :
     *     |                                 \| FX_UseVolume |/   :  +-----+    :
     *     |                                  +--------------+\   :             :
     *     Zone reverbs                           ^            \__:__+-----+    :
     *                                            |               :  | Dry |    :
     *                                          mixers            :  +-----+    :
     *                                                            ...............
     *       The AudioSource's Wet and Dry groups can be attached to the Listener, IgnoreVolume, IgnoreVolNoFX, or ListenerNoFX groups depending on the combinations of the bypassEffects and bypassListenerEffects properties.
     *       Note that zone reverbs are applied by FMOD after the downmix of the master channel group, so in order to avoid reverb on previews the ignoreVolumeGroupNoFX uses FMOD's overrideReverbProperties to turn off the reverb.
     */

    FMOD::ChannelGroup* m_ChannelGroup_FMODMaster;

    FMOD::ChannelGroup* m_ChannelGroup_FX_IgnoreVolume;
    FMOD::ChannelGroup* m_ChannelGroup_FX_UseVolume;
    FMOD::ChannelGroup* m_ChannelGroup_NoFX_IgnoreVolume;
    FMOD::ChannelGroup* m_ChannelGroup_NoFX_UseVolume;

#if PS4_PAD_SPEAKER
    DualShock4Speaker   m_DualShock4Speaker[SCE_USER_SERVICE_MAX_LOGIN_USERS];
#endif

    FMOD_CAPS m_driverCaps;
    FMOD_SPEAKERMODE m_speakerModeCaps;

    FMOD_SPEAKERMODE m_speakerMode; ///< TransferName{Default Speaker Mode} enum { Raw = 0, Mono = 1, Stereo = 2, Quad = 3, Surround = 4, Surround 5.1 = 5, Surround 7.1 = 6, Prologic DTS = 7 } Preferred Speaker Mode used in the editor and player.
    int m_SampleRate; ///< Output sample rate. If set to 0, the sample rate of the system will be used. Also note that this only serves as a reference as only certain platforms allow changing this, such as IOS or Android.
    int m_DSPBufferSize; ///< enum { Default = 0, Best latency = 256, Good latency = 512, Best performance = 1024 } Size of sample output buffer.
    int m_VirtualVoiceCount; ///< Number of virtual voices that the audio system manages. This value should always be larger than the number of voices played by the game. If not, warnings will be shown in the console.
    int m_RealVoiceCount; ///< Number of real voices that can be played at the same time. Every frame the loudest voices will be picked.

    core::string m_SpatializerPlugin; ///< The Spatializer Plugin currently active for this project. All Spatialized AudioSources will use this plugin.

    FMOD_SPEAKERMODE m_activeSpeakerMode;
    int m_activeSampleRate;
    int m_activeDSPBufferSize;
    int m_activeVirtualVoiceCount;
    int m_activeRealVoiceCount;
    bool m_activeVirtualizeEffects;

    // error handling
    core::string m_LastErrorString;
    FMOD_RESULT m_LastFMODErrorResult;

    UInt64 m_accPausedTicks;
    UInt64 m_pauseStartTicks;
    int m_DefaultDSPBufferSize;
    SoundManager* m_SoundManager;
    bool m_DisableAudio; ///< Completely disable audio (in standalone builds only)
    bool m_VirtualizeEffects; ///< When enabled dynamically turn off effects and spatializers on AudioSources that are culled in order to save CPU.
    bool m_PendingAudioConfigurationCallback;
    bool m_DeviceChanged;
    bool m_DeviceChangeNeedsReset;
    int m_InvokeOnAudioConfigurationChangedRecursionDepth;
    FMOD::DSP* m_MasterDSP;
    dynamic_array<AudioEffectInternalDefinition*> m_AudioEffectInternalDefs;
    FMOD_GUID m_DefaultRecordingDriver;
    FMOD_GUID m_DefaultOutputDriver;

private:
    int m_ProfilerCaptureFlags;
    AudioScriptBufferManager* m_ScriptBufferManager;
    void InitScriptBufferManager();

    FMOD_RESULT CreateAllocationBoundSound(const char* data, FMOD_MODE mode, FMOD_CREATESOUNDEXINFO* exInfo, SoundHandle::Instance** instance, SampleClip* sampleClip);
    void HandlePendingAudioConfigurationCallback();

public:
    AudioScriptBufferManager& GetScriptBufferManager();
    AudioScriptBufferManager* GetScriptBufferManagerPtr();
    bool ScriptBufferManagerIsInitialized();

#if UNITY_EDITOR
private:
    bool m_ResetAllAudioClipPlayCountsOnPlay;
    bool m_MasterGroupMute;
    bool m_IsUsingRMSMetering;
    bool m_CanUseSpatializerEffect;
    float m_MasterGroupFade;
    float m_MasterGroupLevel;
    float m_MasterGroupClipping;
    FMOD::ChannelGroup* m_ChannelGroup_Preview;
    SoundHandle m_PreviewSound;
    SoundChannel m_PreviewChannel;
    bool m_EditingInPlaymode;
    audio::mixer::EffectDefinitions m_MixerEffectDefinitions;

public:
    static FMOD_RESULT F_CALLBACK EditorMasterDSPCallback(FMOD_DSP_STATE* dsp_state, float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int outchannels);
    void ResetAllAudioClipPlayCounts();
    bool GetResetAllAudioClipPlayCountsOnPlay() const { return m_ResetAllAudioClipPlayCountsOnPlay; }
    void SetResetAllAudioClipPlayCountsOnPlay(bool value) { m_ResetAllAudioClipPlayCountsOnPlay = value; }
    void PlayClip(AudioClip& clip, int startSample = 0, bool loop = false, bool twoD = true);
    void StopClip(const AudioClip& clip);
    void PauseClip(const AudioClip& clip);
    void ResumeClip(const AudioClip& clip);
    bool IsClipPlaying(const AudioClip& clip);
    void StopAllClips();
    float GetClipPosition(const AudioClip& clip);
    unsigned int GetClipSamplePosition(const AudioClip& clip);
    void SetClipSamplePosition(const AudioClip& clip, unsigned int iSamplePosition);
    void LoopClip(const AudioClip& clip, bool loop);
    void ListenerCheck();
    void ClearPreviewChannel(SoundChannel channel);
    float GetMasterGroupLevel() const;
    float GetMasterGroupClippingAmount() const;
    bool GetMasterGroupMute() const;
    void SetMasterGroupMute(bool mute);
    float GetDSPLoad() const;
    float GetStreamLoad() const;
    FMOD::ChannelGroup* GetChannelGroup_Preview() const { return m_ChannelGroup_Preview; }
    void SetEditingInPlaymode(bool enable);
    bool IsEditingInPlaymode() const;
    inline audio::mixer::EffectDefinitions& GetMixerEffectDefinitions() { return m_MixerEffectDefinitions; }

#endif //UNITY_EDITOR
};

AudioManager& GetAudioManager();
AudioManager* GetAudioManagerPtr();

extern "C" bool UnityAudioSupportsPositiveGains();

#endif // ENABLE_AUDIO
#endif // AUDIOMANAGER_H
