#include "UnityPrefix.h"
#include "Runtime/Interfaces/IAudio.h"
#include "Runtime/Video/BaseVideoTexture.h"
#include "Runtime/Video/MovieTexture.h"
#include "Runtime/Audio/AudioClip.h"
#include "Runtime/Export/WWW.h"
#include "Runtime/Audio/AudioCustomFilter.h"
#include "Runtime/Audio/sound/SoundManager.h"
#include "Runtime/Core/Callbacks/PlayerLoopCallbacks.h"
#include "Runtime/Testing/Faking.h"

class AudioModule FINAL : public IAudio
{
    virtual void SetListenerPause(bool paused)
    {
        GetAudioManager().SetListenerPause(paused);
    }

    virtual void SetApplicationPause(bool paused)
    {
        GetAudioManager().SetApplicationPause(paused);
    }

    virtual void FixedUpdate()
    {
        GetAudioManager().FixedUpdate();
    }

    virtual void Update()
    {
        GetAudioManager().Update();

        SoundManager* soundmanager = GetSoundManager();
        if (soundmanager != NULL)
            soundmanager->Update();
    }

    virtual void StopVideoTextures()
    {
        BaseVideoTexture::StopVideoTextures();
    }

    virtual void PauseVideoTextures()
    {
        BaseVideoTexture::PauseVideoTextures();
    }

    virtual void UpdateVideoTextures()
    {
        BaseVideoTexture::UpdateVideoTextures();
    }

    virtual void SuspendVideoTextures()
    {
        BaseVideoTexture::SuspendVideoTextures();
    }

    virtual void ResumeVideoTextures()
    {
        BaseVideoTexture::ResumeVideoTextures();
    }

#if ENABLE_WWW
#if ENABLE_MOVIES
    virtual MovieTexture* CreateMovieTextureFromWWW(WWW& www)
    {
        MovieTexture* tex = NEW_OBJECT(MovieTexture);
        SET_ALLOC_OWNER(tex);
        tex->Reset();
        tex->InitStream(&www);
        tex->AwakeFromLoad(kInstantiateOrCreateFromCodeAwakeFromLoad);
        return tex;
    }

#endif
    virtual AudioClip* CreateAudioClipFromWWW(IWWWStream* iwstream, const char* url, bool stream, bool compressed, int audioType)
    {
        AudioClip* clip = NEW_OBJECT(AudioClip);

        clip->EnableLegacyMode();
        clip->Reset();

        if (!clip->InitStream(iwstream, url, NULL, stream, compressed, static_cast<FMOD_SOUND_TYPE>(audioType)))
        {
            UNITY_DELETE(iwstream, kMemAudio);
            DestroySingleObject(clip);
            return NULL;
        }

        return clip;
    }

#endif

    virtual bool IsFormatSupportedByPlatform(const char* type)
    {
        return AudioClip::IsFormatSupportedByPlatform(type);
    }

    virtual FMOD::DSP* GetOrCreateDSPFromCustomFilter(AudioCustomFilter* filter)
    {
        return filter->GetOrCreateDSP();
    }

    virtual void DeleteAudioCustomFilter(AudioCustomFilter* filter)
    {
        delete filter;
    }

    virtual AudioCustomFilter* CreateAudioCustomFilter(MonoBehaviour* mb)
    {
        return new AudioCustomFilter(mb);
    }

    virtual FMOD::DSP* GetDSPFromAudioCustomFilter(AudioCustomFilter* filter)
    {
        return filter->GetDSP();
    }

    virtual void SetBypassOnDSP(FMOD::DSP* dsp, bool state)
    {
        dsp->setBypass(state);
    }

#if ENABLE_PROFILER
    virtual void GetProfilerStats(AudioStats& stats)
    {
        GetAudioManager().GetProfilerData(stats);

        SoundManager* soundmanager = GetSoundManager();
        if (soundmanager != NULL)
            soundmanager->GetProfilerData(stats);
    }

    virtual void CaptureFrame(dynamic_array<AudioProfilerGroupInfo>& groupData, dynamic_array<AudioProfilerDSPInfo>& dspData, dynamic_array<AudioProfilerClipInfo>& clipData, dynamic_array<char>& names)
    {
        AudioProfiler::CaptureFrame(groupData, dspData, clipData, names);
    }

    virtual void SetProfilerCaptureFlags(int flags)
    {
        GetAudioManager().SetProfilerCaptureFlags(flags);
    }

#endif

    virtual void AudioManagerAwakeFromLoad(AwakeFromLoadMode mode)
    {
        GetAudioManager().AwakeFromLoad(mode);
    }

    virtual bool SetActiveOutputDriver(void* guid)
    {
        __FAKEABLE_METHOD__(AudioModule, SetActiveOutputDriver, (guid));
        AudioManager* audioManager = GetAudioManagerPtr();
        if (audioManager != NULL)
        {
            return audioManager->SetActiveOutputDriver(static_cast<FMOD_GUID*>(guid));
        }
        return false;
    }

    virtual void SetDefaultMicrophoneDriver(void* guid)
    {
        __FAKEABLE_METHOD__(AudioModule, SetDefaultMicrophoneDriver, (guid));
        AudioManager* audioManager = GetAudioManagerPtr();
        if (audioManager != NULL)
        {
            audioManager->SetDefaultMicrophoneDriver(static_cast<FMOD_GUID*>(guid));
        }
    }

    virtual UInt32 GetNumDevices()
    {
        AudioManager* audioManager = GetAudioManagerPtr();
        if (audioManager != NULL)
            return audioManager->GetNumDevices();

        return 0;
    }

    virtual bool IsAudioDisabled()
    {
        __FAKEABLE_METHOD__(AudioModule, IsAudioDisabled, ());
        AudioManager* audioManager = GetAudioManagerPtr();
        if (audioManager != NULL)
            return audioManager->IsAudioDisabled();

        return true;
    }
};


static void InitializeAudioManagerCallbacks()
{
    REGISTER_PLAYERLOOP_CALL(FixedUpdate, AudioFixedUpdate,
    {
        if (!IsWorldPlayingThisFrame())
            return;
        IAudio* audioModule = GetIAudio();
        AssertMsg(audioModule != NULL, "Failed to retrieve AudiomoduleInterface");
        audioModule->FixedUpdate();
    });

    REGISTER_PLAYERLOOP_CALL(PostLateUpdate, UpdateAudio,
    {
        IAudio* audioModule = GetIAudio();
        AssertMsg(audioModule != NULL, "Failed to retrieve AudiomoduleInterface");
        audioModule->Update();
    });

#if ENABLE_MOVIES || ENABLE_WEBCAM
    REGISTER_PLAYERLOOP_CALL(PostLateUpdate, UpdateVideoTextures,
    {
        // movies touch graphics resources; only do that when device is not lost
        if (!NeedToPerformRendering() || !GetGfxDevice().IsValidState())
            return;
        IAudio* audioModule = GetIAudio();
        AssertMsg(audioModule != NULL, "Failed to retrieve AudiomoduleInterface");
        audioModule->UpdateVideoTextures();
    });
#endif
}

static void CleanupAudioManagerCallbacks()
{
    UNREGISTER_PLAYERLOOP_CALL(FixedUpdate, AudioFixedUpdate);
    UNREGISTER_PLAYERLOOP_CALL(PostLateUpdate, UpdateAudio);

#if ENABLE_MOVIES || ENABLE_WEBCAM
    UNREGISTER_PLAYERLOOP_CALL(PostLateUpdate, UpdateVideoTextures);
#endif
}

void InitializeAudioModule()
{
    SetIAudio(UNITY_NEW_AS_ROOT_NO_LABEL(AudioModule, kMemAudio, "AudioModuleInterface", ""));
    AssertMsg(GetIAudio() != NULL, "Failed to retrieve AudiomoduleInterface after just registering it");
    InitializeAudioManagerCallbacks();
}

void CleanupAudioModule()
{
    CleanupAudioManagerCallbacks();
    AudioModule* module = reinterpret_cast<AudioModule*>(GetIAudio());
    UNITY_DELETE(module, kMemAudio);
    SetIAudio(NULL);
}
