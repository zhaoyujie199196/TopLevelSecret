#pragma once

// This has to be kept in sync with AudioMixerGroup.bindings
enum DuckingMode
{
    NoDucking,
    MeasureLevel,
    RadioDucking,
};
