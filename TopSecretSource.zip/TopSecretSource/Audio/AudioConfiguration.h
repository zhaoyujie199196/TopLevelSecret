#ifndef ___AUDIOCONFIGURATION_H__
#define ___AUDIOCONFIGURATION_H__

#include "Runtime/Audio/correct_fmod_includer.h"

struct AudioConfigurationScripting
{
    FMOD_SPEAKERMODE speakerMode;
    int dspBufferSize;
    int sampleRate;
    int numRealVoices;
    int numVirtualVoices;
};

#endif // ___AUDIOCONFIGURATION_H__
