#include "UnityPrefix.h"
#include "Configuration/UnityConfigure.h"

#include "AudioClip.h"
#include "AudioSource.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Serialize/SwapEndianArray.h"
#include "AudioManager.h"
#include "Runtime/Video/MoviePlayback.h"
#include "Runtime/Serialize/PersistentManager.h"
#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/Misc/UTF8.h"
#include "Runtime/Scripting/ScriptingManager.h"
#include "Runtime/Utilities/PathNameUtility.h"

#include "sound/SoundManager.h"

#include "WavReader.h"
#include "OggReader.h"

#if UNITY_EDITOR
#include "Editor/Src/EditorUserBuildSettings.h"
#include "Editor/Src/AssetPipeline/AudioImporter.h"
#endif


#include "Runtime/Audio/correct_fmod_includer.h"

#if ENABLE_WWW
#include "Runtime/Export/WWW.h"
#endif

#include "Runtime/Misc/BuildSettings.h"

#define Unity_HiWord(x) ((UInt32)((UInt64)(x) >> 32))
#define Unity_LoWord(x) ((UInt32)(x))

#if UNITY_EDITOR
#include <fstream>
#endif

SampleClip::SampleClip(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
    , m_Frequency(0)
    , m_Channels(0)
    , m_BitsPerSample(0)
    , m_IsTrackerFormat(false)
    , m_Length(0)
    , m_LoadType(kDecompressOnLoad)
    , m_SubsoundIndex(0)
    , m_PreloadAudioData(true)
    , m_LoadInBackground(false)
    , m_Legacy3D(false)
    , m_CompressionFormat(kPCM)
#if UNITY_EDITOR
    , m_EditorCompressionFormat(kPCM)
#endif
    , m_WeakPtr(this, kMemAudio)
    , m_NodeInModifiedClipList(this)
    , m_PlayCount(0)
{
}

void SampleClip::ThreadedCleanup()
{
}

void SampleClip::MainThreadCleanup()
{
    m_NodeInModifiedClipList.RemoveFromList();
    Super::MainThreadCleanup();
    m_WeakPtr.Clear();
}

void SampleClip::InitializeClass()
{
}

void SampleClip::CleanupClass()
{
}

bool SampleClip::LoadAudioData()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return true;

    LoadBaseSound();

    if (!m_PreloadAudioData)
        GetSoundManager()->RegisterModifiedClip(this);

    return true;
}

bool SampleClip::UnloadAudioData()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return true;

    if (!m_Sound.IsNull() && m_Sound->GetLoadState() != SoundHandle::kLoaded && m_Sound->GetLoadState() != SoundHandle::kFailed)
    {
        WarningStringObject("Dynamically unloading a sound that hasn't finished loading yet. If you see this message a lot, some scripts may be doing too many dynamic load/unload operations which will negatively affect performance.", this);
    }

    GetSoundManager()->UnloadClip(this);

    if (m_PreloadAudioData)
        GetSoundManager()->RegisterModifiedClip(this);

    return true;
}

bool SampleClip::GetPreloadAudioData() const
{
    return m_PreloadAudioData;
}

SoundHandle::LoadState SampleClip::GetLoadState() const
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return SoundHandle::kUnloaded;

    return m_Sound->GetLoadState();
}

SoundChannel SampleClip::AllocateChannel(bool paused, UInt64 startTime)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return SoundChannel();

    if (m_Sound.IsNull())
        LoadBaseSound();

    SoundChannel channel = m_Sound.CreateChannel(paused);
    if (channel.IsValid() && startTime != 0)
        CheckFMODError(channel->setDelay(FMOD_DELAYTYPE_DSPCLOCK_START, Unity_HiWord(startTime), Unity_LoWord(startTime)));

    return channel;
}

static bool CompressionFormatRequiresHardware(SampleClip::CompressionFormat format)
{
    switch (format)
    {
        case SampleClip::kPSMVAG:
        case SampleClip::kHEVAG:
        case SampleClip::kGCADPCM:
            return true;
        default:
            return false;
    }
}

#if UNITY_EDITOR
SoundHandle SampleClip::AllocatePreviewSound()
{
    // FMOD's streaming system has problems with very short files. It seems that too much data will be decoded and this results in noise at the end.
    FMOD_MODE mode = FMOD_CREATESTREAM;
    if (m_Channels <= 2 && m_Length < 0.5f)
        mode = FMOD_CREATESAMPLE;

    // Create blocking and without any flags (in particular WITHOUT kAllowSharing or kPersistent), so that the sound ready to play right after AllocatePreviewSound has
    // been called and will be automatically unloaded when done playing.
    return GetSoundManager()->GetHandle(GetResource(), m_SubsoundIndex, mode | FMOD_SOFTWARE | FMOD_2D | FMOD_LOOP_NORMAL, 0, this, true);
}

#endif

FMOD_MODE SampleClip::CalculateFMODMode() const
{
    FMOD_MODE mode = CompressionFormatRequiresHardware(GetCompressionFormat()) ? FMOD_HARDWARE : FMOD_SOFTWARE;
    mode |= (FMOD_LOOP_NORMAL | FMOD_3D);

    if (m_IsTrackerFormat)
    {
        mode |= FMOD_ACCURATETIME;
        if (m_LoadInBackground)
            ErrorStringObject("At present background loading of tracked music files is not supported and will therefore block the system. Consider changing the load type of the AudioClip such that it is loaded when the scene is initialized.", this);
    }
    else if (m_LoadInBackground)
        mode |= FMOD_NONBLOCKING;

    LoadType actualLoadType = m_LoadType;
    if (m_Channels > 2 && GetCompressionFormat() != kPCM && m_LoadType == kCompressedInMemory)
        actualLoadType = kStreaming;

    // FMOD's streaming system has problems with very short files. It seems that too much data will be decoded and this results in noise at the end.
    if (m_Channels <= 2 && m_Length < 0.5f && m_LoadType == kStreaming)
        actualLoadType = kCompressedInMemory;

    switch (actualLoadType)
    {
        case kDecompressOnLoad:
            mode |= FMOD_CREATESAMPLE;
            break;
        case kCompressedInMemory:
            mode |= FMOD_CREATECOMPRESSEDSAMPLE;
            break;
        case kStreaming:
            mode |= FMOD_CREATESTREAM;
            break;
        default:
            AssertMsg(false, "Unhandled load type");
    }

    return mode;
}

UInt32 SampleClip::CalculateFlags() const
{
    UInt32 flags = 0;

    if (m_IsTrackerFormat && (m_LoadType == kCompressedInMemory))
        flags |= SoundHandle::kInstanceLimitation;

    FMOD_MODE mode = CalculateFMODMode();

    if ((mode & FMOD_CREATESTREAM) != 0)
        flags |= SoundHandle::kInstanceLimitation;

    return flags;
}

void SampleClip::LoadBaseSound()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    if (GetResource().m_Source.empty())
        return;

    FMOD_MODE mode = CalculateFMODMode();
    UInt32 flags = CalculateFlags();

    m_Sound = GetSoundManager()->GetHandle(GetResource(), m_SubsoundIndex, mode, flags, this, false);
}

void SampleClip::ReleaseIfEqual(SoundHandle handle)
{
    if (m_Sound == handle)
        m_Sound.Release();
}

const StreamedResource& SampleClip::GetResource() const
{
#if UNITY_EDITOR
    return m_EditorResource.m_Source.empty() ? m_Resource : m_EditorResource;
#else
    return m_Resource;
#endif
}

SampleClip::CompressionFormat SampleClip::GetCompressionFormat() const
{
#if UNITY_EDITOR
    return m_EditorResource.m_Source.empty() ? m_CompressionFormat : m_EditorCompressionFormat;
#else
    return m_CompressionFormat;
#endif
}

template<class TransferFunc>
void SampleClip::Transfer(TransferFunc& transfer)
{
    Super::Transfer(transfer);
    // See AudioClip::Transfer
}

IMPLEMENT_REGISTER_CLASS(SampleClip, 271);
IMPLEMENT_OBJECT_SERIALIZE(SampleClip);
INSTANTIATE_TEMPLATE_TRANSFER(SampleClip);

#if ENABLE_PROFILER
int AudioClip::s_GlobalCount = 0;
#endif

Mutex AudioClip::LegacyData::m_AudioQueueMutex;

AudioClip::AudioClip(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
    , m_ThreadedLoadInstance(NULL)
{
#if ENABLE_PROFILER
    AtomicIncrement(&s_GlobalCount);
#endif
#if UNITY_EDITOR
    m_Resource.m_AssetType = TypeOf<AudioClip>();
#endif
}

void AudioClip::InitializeClass()
{
}

void AudioClip::EnableLegacyMode()
{
    if (!IsLegacyFormat())
    {
        m_legacy.reset(new LegacyData());
        m_legacy->m_Type = FMOD_SOUND_TYPE_UNKNOWN;
        m_legacy->m_Format = FMOD_SOUND_FORMAT_NONE;
        m_legacy->m_UserGenerated = false;
        m_legacy->m_UserLengthSamples = 0;
        m_legacy->m_UserIsStream = true;
#if ENABLE_WWW
        m_legacy->m_StreamData = NULL;
#endif
        m_legacy->m_ExternalStream = false;
        m_legacy->m_MoviePlayback = NULL;
        m_legacy->m_OpenState = FMOD_OPENSTATE_CONNECTING;
#if SUPPORT_SCRIPTING_THREADS
        m_legacy->scriptingDomain = NULL;
#endif
        m_legacy->m_PCMArray = SCRIPTING_NULL;
        m_legacy->m_PCMArrayGCHandle = 0;
        m_legacy->m_CachedPCMReaderCallbackMethod = NULL;
        m_legacy->m_CachedSetPositionCallbackMethod = NULL;
        m_legacy->m_DecodeBufferSize = 0;
        m_legacy->m_WWWStreamed = false;
    }
}

#if ENABLE_WWW
bool AudioClip::InitStream(IWWWStream* streamData, const char* url, MoviePlayback* movie, bool realStream /* = false */, bool compressed /* = false */, FMOD_SOUND_TYPE fmodSoundType /* = FMOD_SOUND_TYPE_UNKNOWN */)
{
    MAKE_LEGACY_AUDIOCLIP();

    Assert(m_legacy->m_MoviePlayback == NULL);
    Assert(m_legacy->m_StreamData == NULL);

    // Web streaming
    if (streamData)
    {
        // If the audiotype isn't specified, guess the audio type from the url to avoid going thru all available codecs (this seriously hit performance for a net stream)
        core::string ext = ToLower(GetPathNameExtension(url));

        if (fmodSoundType == FMOD_SOUND_TYPE_UNKNOWN)
            m_legacy->m_Type = GetFormatFromExtension(ext);
        else
            m_legacy->m_Type = fmodSoundType;

        if (m_legacy->m_Type == FMOD_SOUND_TYPE_UNKNOWN)
        {
            ErrorStringObject(Format("Unable to determine the audio type from the URL (%s) . Please specify the type.", url), this);
            // right now we're trying to load sound in AwakeFromLoad (and do only that) - so we skip the call
            SetAwakeCalledInternal();
            return false;
        }

        if (realStream)
        {
            if (m_legacy->m_Type == FMOD_SOUND_TYPE_XM || m_legacy->m_Type == FMOD_SOUND_TYPE_IT || m_legacy->m_Type == FMOD_SOUND_TYPE_MOD || m_legacy->m_Type == FMOD_SOUND_TYPE_S3M)
            {
                ErrorStringObject("Tracker files (XM/IT/MOD/S3M) cannot be streamed in realtime but must be fully downloaded before they can play.", this);
                SetAwakeCalledInternal(); // to avoid error message: "Awake has not been called '' (AudioClip). Figure out where the object gets created and call AwakeFromLoad correctly."
                return false;
            }
        }

#if UNITY_EDITOR
        BuildTargetPlatform targetPlatform = GetEditorUserBuildSettings().GetActiveBuildTarget();
        if (
            (m_legacy->m_Type == FMOD_SOUND_TYPE_OGGVORBIS && (targetPlatform == kBuildTizen) || (targetPlatform == kBuildSamsungTV))
            ||
            (m_legacy->m_Type == FMOD_SOUND_TYPE_MPEG && !((targetPlatform == kBuild_Android) || (targetPlatform == kBuild_iPhone) || (targetPlatform == kBuildtvOS) || (targetPlatform == kBuildTizen || (targetPlatform == kBuildSamsungTV))))
            )
#else
        if (
            (m_legacy->m_Type == FMOD_SOUND_TYPE_OGGVORBIS && (UNITY_TIZEN | UNITY_STV | UNITY_WEBGL) != 0)
            ||
            (m_legacy->m_Type == FMOD_SOUND_TYPE_MPEG && (UNITY_ANDROID | UNITY_IPHONE | UNITY_TVOS | UNITY_TIZEN | UNITY_STV | UNITY_WEBGL) == 0)
            )
#endif
        {
            ErrorStringObject(Format("Streaming of '%s' on this platform is not supported", ext.c_str()), this);
            // right now we're trying to load sound in AwakeFromLoad (and do only that) - so we skip the call
            SetAwakeCalledInternal();
            return false;
        }

        m_legacy->m_StreamData = streamData;
        m_legacy->m_ExternalStream = true;
        m_legacy->m_WWWStreamed = realStream;
        m_legacy->m_WWWCompressed = compressed;
        // reserve queue space
        m_legacy->m_AudioQueueMutex.Lock();
        m_legacy->m_AudioBufferQueue.reserve(kAudioQueueSize);
        m_legacy->m_AudioQueueMutex.Unlock();
        LoadSound();
    }

    SetMoviePlayback(movie);

    if (movie)
    {
        m_legacy->m_ExternalStream = true;
        LoadSound();
    }

    // Right now we're trying to load sound in AwakeFromLoad (and do only that) - so we skip the call
    SetAwakeCalledInternal();

    return true;
}

#endif

bool AudioClip::CreateUserSound(const core::string& name, unsigned lengthSamples, short channels, unsigned frequency, bool stream)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return false;

    MAKE_LEGACY_AUDIOCLIP();

    Reset();
    Cleanup();

    m_Channels = channels;
    m_Frequency = frequency;
    m_BitsPerSample = 32;

#if UNITY_WEBGL
    if (stream)
    {
        ErrorStringObject("Creating streamed audio clips is not supported in WebGL. Creating the clip as non-streamed.", this);
        stream = false;
    }
#endif
    m_legacy->m_UserGenerated = true;
    m_legacy->m_UserLengthSamples = lengthSamples;
    m_legacy->m_UserIsStream = stream;
    m_legacy->m_Format = FMOD_SOUND_FORMAT_PCMFLOAT;
    SetName(name.c_str());

    CreateScriptCallback();

    m_Sound = CreateSound();

    // Right now we're trying to load sound in AwakeFromLoad (and do only that) - so we skip the call
    SetAwakeCalledInternal();

    return true;
}

bool AudioClip::InitWSound(SoundHandle::Instance* instance)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return false;

    MAKE_LEGACY_AUDIOCLIP();

    Assert(instance);
    Cleanup();
    CreateScriptCallback();

    m_Sound = GetSoundManager()->GetHandleFromFMODSound(instance, 0, this);
    m_legacy->m_OpenState = FMOD_OPENSTATE_READY;

    return true;
}

void AudioClip::ThreadedCleanup()
{
}

void AudioClip::MainThreadCleanup()
{
#if ENABLE_PROFILER
    AtomicDecrement(&s_GlobalCount);
#endif

    Cleanup();

    Assert(m_ThreadedLoadInstance == NULL);

    if (IsLegacyFormat())
    {
#if ENABLE_WWW
        if (m_legacy->m_StreamData)
            UNITY_DELETE(m_legacy->m_StreamData, kMemAudio);
#endif
        if (m_legacy->m_MoviePlayback)
            m_legacy->m_MoviePlayback->SetMovieAudioClip(NULL);
    }
    Super::MainThreadCleanup();
}

FMOD_SOUND_TYPE AudioClip::GetFormatFromExtension(const core::string& ext)
{
    core::string ext_lower = ToLower(ext);
    FMOD_SOUND_TYPE type = FMOD_SOUND_TYPE_UNKNOWN;
    if (ext_lower == "ogg")
        type = FMOD_SOUND_TYPE_OGGVORBIS;
    else if (ext_lower == "mp2" || ext_lower == "mp3")
        type = FMOD_SOUND_TYPE_MPEG;
    else if (ext_lower == "wav")
        type = FMOD_SOUND_TYPE_WAV;
    else if (ext_lower == "it")
        type = FMOD_SOUND_TYPE_IT;
    else if (ext_lower == "xm")
        type = FMOD_SOUND_TYPE_XM;
    else if (ext_lower == "s3m")
        type = FMOD_SOUND_TYPE_S3M;
    else if (ext_lower == "mod")
        type = FMOD_SOUND_TYPE_MOD;

    return type;
}

bool AudioClip::IsFormatSupportedByPlatform(const core::string& ext)
{
    // Since this is a static function, we have to report anything either the old or new format supports...

    FMOD_SOUND_TYPE type = GetFormatFromExtension(ext);
    if (type == FMOD_SOUND_TYPE_UNKNOWN)
        return false;
#if (UNITY_TIZEN || UNITY_STV)
    if (type == FMOD_SOUND_TYPE_OGGVORBIS)
        return false;
#else
    if (type == FMOD_SOUND_TYPE_MPEG)
        return false;
#endif

    return true;
}

void AudioClip::Cleanup()
{
    // When audio is not used GetAudioManagerPtr() is NULL
    AudioManager* manager = GetAudioManagerPtr();
    if (manager && manager->IsAudioDisabledInStandalone())
        return;

    m_Sound.Release();

    if (!GetResource().m_Source.empty() && GetAudioManagerPtr() != NULL)
        GetSoundManager()->UnloadClip(this);
}

void AudioClip::CleanupClass()
{
}

bool AudioClip::ReadyToPlay()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return false;

    // In WebGL, we always need to check the load state, as any type of audio clip
    // needs to be loaded by the browser before we can play it.
    if (!IsLegacyFormat() || UNITY_WEBGL)
    {
        if (!m_Sound.IsNull() && m_Sound->GetLoadState() == SoundHandle::kLoaded)
            return true;

        return false;
    }

    if (
#if ENABLE_WWW
        !m_legacy->m_StreamData &&
#endif
        !m_legacy->m_MoviePlayback)
        return true;

    if (m_legacy->m_UserGenerated)
        return true;

    if (m_legacy->m_OpenState == FMOD_OPENSTATE_READY)
        return true;


    // try to...
    LoadSound();

    if (m_Sound.IsNull())
    {
        m_legacy->m_OpenState = FMOD_OPENSTATE_CONNECTING;
        return false;
    }

    m_legacy->m_OpenState = FMOD_OPENSTATE_READY;

    return true;
}

bool AudioClip::SetData(const float* data, unsigned lengthSamples, unsigned offsetSamples)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return false;

    if (!m_Sound->SetData(data, lengthSamples, offsetSamples))
        return false;

    GetSoundManager()->RegisterModifiedClip(this);
    return true;
}

bool AudioClip::GetData(float* data, unsigned lengthSamples, unsigned offsetSamples) const
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return false;

    return m_Sound->GetData(data, lengthSamples, offsetSamples);
}

// Set the attached movie clip
void AudioClip::SetMoviePlayback(MoviePlayback* movie)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    MAKE_LEGACY_AUDIOCLIP();

    m_legacy->m_MoviePlayback = movie;

    if (!movie)
        return;

    m_legacy->m_ExternalStream = true;

    // unload any attached www data
#if ENABLE_WWW
    if (m_legacy->m_StreamData)
        UNITY_DELETE(m_legacy->m_StreamData, kMemAudio);
#endif

    m_Channels = movie->GetMovieAudioChannelCount();
    m_Frequency = movie->GetMovieAudioRate();
    m_BitsPerSample = 16;

    m_legacy->m_Format = FMOD_SOUND_FORMAT_PCM16;
    m_legacy->m_Type = FMOD_SOUND_TYPE_RAW;

    m_legacy->m_OpenState = FMOD_OPENSTATE_CONNECTING;
}

MoviePlayback* AudioClip::GetMoviePlayback() const
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return NULL;

    CHECK_LEGACY_AUDIOCLIP();
    return m_legacy->m_MoviePlayback;
}

/**
 * Queue PCM data into clip
 * This is read by streamed sound
 * @param buffer Audio data to queue
 * @param size Size of Audio data
 **/
bool AudioClip::QueueAudioData(const void* const buffer, unsigned size)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return false;

    CHECK_LEGACY_AUDIOCLIP();

    Mutex::AutoLock lock(m_legacy->m_AudioQueueMutex);
    if (m_legacy->m_AudioBufferQueue.size() + size < kAudioQueueSize)
    {
        m_legacy->m_AudioBufferQueue.insert(m_legacy->m_AudioBufferQueue.end(), (UInt8*)buffer, (UInt8*)buffer + size);
        return true;
    }

    return false;
}

/**
 * Top audio data from the quene
 * @note buf must allocate size bytes
 * @param size The size in bytes you want to top
 * @return The audio data
 **/
bool AudioClip::GetQueuedAudioData(void** buf, unsigned size)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return false;

    CHECK_LEGACY_AUDIOCLIP();

    Mutex::AutoLock lock(m_legacy->m_AudioQueueMutex);
    if (m_legacy->m_AudioBufferQueue.size() < size)
        return false;

    memcpy(*buf, &m_legacy->m_AudioBufferQueue[0], size);

    m_legacy->m_AudioBufferQueue.erase(m_legacy->m_AudioBufferQueue.begin(), m_legacy->m_AudioBufferQueue.begin() + size);

    return true;
}

void AudioClip::ClearQueue()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    CHECK_LEGACY_AUDIOCLIP();

    Mutex::AutoLock lock(m_legacy->m_AudioQueueMutex);

    m_legacy->m_AudioBufferQueue.clear();
}

unsigned int AudioClip::GetSampleCount() const
{
    if (GetAudioManager().IsAudioDisabledInStandalone() || !IsLegacyFormat())
        return (unsigned int)(m_Length * m_Frequency);

    if (m_legacy->m_MoviePlayback)
    {
        if (m_legacy->m_MoviePlayback->GetMovieTotalDuration() < 0)
            return 0;
        else
            return (unsigned int)(m_legacy->m_MoviePlayback->GetMovieTotalDuration() * m_Frequency * m_Channels);
    }

    return m_Sound->GetLengthPCM();
}

unsigned int AudioClip::GetChannelCount() const
{
    if (GetAudioManager().IsAudioDisabledInStandalone() || !IsLegacyFormat())
        return m_Channels;

    return m_Sound->GetNumChannels();
}

unsigned int AudioClip::GetBitRate() const
{
    if (GetAudioManager().IsAudioDisabledInStandalone() || !IsLegacyFormat())
        return m_Frequency * m_BitsPerSample;

    return (unsigned int)(m_Sound->GetNumChannels() * m_Sound->GetBitsPerSample() * m_Sound->GetFrequency());
}

unsigned int AudioClip::GetBitsPerSample() const
{
    if (GetAudioManager().IsAudioDisabledInStandalone() || !IsLegacyFormat())
        return m_BitsPerSample;

    return m_Sound->GetBitsPerSample();
}

unsigned int AudioClip::GetFrequency() const
{
    if (GetAudioManager().IsAudioDisabledInStandalone() || !IsLegacyFormat())
        return m_Frequency;

    if (m_Sound.IsNull())
        return m_Frequency;

    return (unsigned int)m_Sound->GetFrequency();
}

unsigned int AudioClip::GetSoundSize() const
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return 0;

    return m_Sound->GetMemoryInfo(true);
}

unsigned int AudioClip::GetLength() const
{
    if (GetAudioManager().IsAudioDisabledInStandalone() || !IsLegacyFormat())
        return (unsigned int)(m_Length * 1000.0f);

    if (m_legacy->m_MoviePlayback)
        return (unsigned int)(m_legacy->m_MoviePlayback->GetMovieTotalDuration() * 1000.0f);

    return (unsigned int)m_Sound->GetLengthMS();
}

float AudioClip::GetLengthSec() const
{
    if (GetAudioManager().IsAudioDisabledInStandalone() || !IsLegacyFormat())
        return m_Length;

    if (m_legacy->m_MoviePlayback)
        return m_legacy->m_MoviePlayback->GetMovieTotalDuration();

    return m_Sound->GetLengthMS() * 0.001f;
}

MoviePlayback* AudioClip::GetMovie() const
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return NULL;

    return IsLegacyFormat() ? m_legacy->m_MoviePlayback : NULL;
}

SoundHandle AudioClip::CreateSound()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return SoundHandle();

    SET_ALLOC_OWNER(this);

    // if external streaming (WWW or movie)
    if (IsLegacyFormat() && m_legacy->m_ExternalStream)
    {
#if ENABLE_WWW
        if (m_legacy->m_StreamData)
        {
            // Recreate sound if it's streamed WWW/Custom (reusing a sound will trigger a seek - which is not supported)
            // Wait for the entire file to download before reporting ready
            // @TODO we need a proper net stream solution
            if (!m_legacy->m_WWWStreamed && !m_legacy->m_StreamData->IsDone())
                return SoundHandle();

            SoundHandle::Instance* instance = GetAudioManager().CreateFMODSoundFromWWW(
                    m_legacy->m_StreamData,
                    m_legacy->m_Type,
                    m_legacy->m_Format,
                    m_Frequency,
                    m_Channels,
                    m_legacy->m_WWWStreamed,
                    m_legacy->m_WWWCompressed,
                    this);

            return GetSoundManager()->GetHandleFromFMODSound(instance, 0, this);
        }
        else
#endif
        if (m_legacy->m_MoviePlayback)
        {
            SoundHandle::Instance* instance = GetAudioManager().CreateFMODSoundFromMovie(this);
            return GetSoundManager()->GetHandleFromFMODSound(instance, 0, this);
        }
    }
    else if (IsLegacyFormat() && m_legacy->m_UserGenerated)
    {
        FMOD_CREATESOUNDEXINFO exinfo;
        memset(&exinfo, 0, sizeof(exinfo));
        exinfo.cbsize = sizeof(FMOD_CREATESOUNDEXINFO);
        exinfo.suggestedsoundtype = m_legacy->m_Type;
        exinfo.format = m_legacy->m_Format;
        exinfo.defaultfrequency = m_Frequency;
        exinfo.numchannels = m_Channels;
        exinfo.length = m_legacy->m_UserLengthSamples * m_Channels * 4;
        exinfo.pcmreadcallback = AudioClip::ScriptPCMReadCallback;
        exinfo.pcmsetposcallback = AudioClip::ScriptPCMSetPositionCallback;
        FMOD_MODE mode = FMOD_3D | FMOD_SOFTWARE | FMOD_LOOP_NORMAL | FMOD_OPENUSER;
        mode |= (m_legacy->m_UserIsStream) ? FMOD_CREATESTREAM : FMOD_CREATESAMPLE;
        CheckFMODError(GetSoundManager()->CreateSoundInternal(GetName(), mode, &exinfo, m_Sound, 0, this));
    }
    else
    {
        LoadBaseSound();
    }

    return m_Sound;
}

void AudioClip::Reload()
{
    m_NodeInModifiedClipList.RemoveFromList();
    if (IsPersistent())
    {
        GetPersistentManager().ReloadFromDisk(*this);
    }
}

bool AudioClip::LoadSound()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return false;

    Cleanup();

    Assert(m_Sound.IsNull());
    m_Sound = CreateSound();

    if (m_Sound.IsNull())
    {
        return false;
    }

    if (IsLegacyFormat())
    {
        m_legacy->m_OpenState = FMOD_OPENSTATE_READY;

        if (m_legacy->m_ExternalStream && m_Sound.IsNull())
        {
            m_legacy->m_OpenState = FMOD_OPENSTATE_CONNECTING;
            return false; // file problably doesnt exist
        }
    }

    return true;
}

int AudioClip::GetMusicChannelCount() const
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return 0;

    return m_Sound->GetMusicChannelCount();
}

void AudioClip::CreateScriptCallback()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    MAKE_LEGACY_AUDIOCLIP();

    #if SUPPORT_SCRIPTING_THREADS
    m_legacy->scriptingDomain = scripting_domain_get();
    #endif

    // cache script methods
    ScriptingObjectPtr instance = Scripting::ScriptingWrapperFor(this);

    if (instance)
    {
        // cache delegate invokers
        m_legacy->m_CachedPCMReaderCallbackMethod = GetAudioScriptingClasses().invokePCMReaderCallback_Internal;
        m_legacy->m_CachedSetPositionCallbackMethod = GetAudioScriptingClasses().invokePCMSetPositionCallback_Internal;
    }
}

template<class TransferFunc>
void AudioClip::Transfer(TransferFunc& transfer)
{
    Super::Transfer(transfer);

    TRANSFER_ENUM(m_LoadType);

    TRANSFER(m_Channels);
    TRANSFER(m_Frequency);
    TRANSFER(m_BitsPerSample);
    TRANSFER(m_Length);
    TRANSFER(m_IsTrackerFormat);

    transfer.Align();

    TRANSFER(m_SubsoundIndex);  // This has to be  determined at gamerelease pack time
    TRANSFER(m_PreloadAudioData);
    TRANSFER(m_LoadInBackground);
    TRANSFER(m_Legacy3D);

    transfer.Align();

    TRANSFER(m_Resource);
    TRANSFER_ENUM(m_CompressionFormat);

#if UNITY_EDITOR
    TRANSFER_EDITOR_ONLY(m_EditorResource);
    TRANSFER_EDITOR_ONLY_ENUM(m_EditorCompressionFormat);
#endif

    transfer.Align();
}

void AudioClip::AwakeFromLoadThreaded()
{
    Super::AwakeFromLoadThreaded();

    // When audio is not used GetAudioManagerPtr() is NULL
    AudioManager* manager = GetAudioManagerPtr();
    if (manager && manager->IsAudioDisabledInStandalone())
        return;

    // We don't preload streams because this can lead to an excessive number of open file handles
    if (m_PreloadAudioData && m_LoadType != kStreaming && !GetResource().m_Source.empty())
    {
        const char* path    = GetResource().m_Source.c_str();
        unsigned int size   = (unsigned int)GetResource().m_Size;
        unsigned int offset = (unsigned int)GetResource().m_Offset;

        LoadFMODSound(&m_ThreadedLoadInstance, path, CalculateFMODMode(), this, size, offset);
    }
}

void AudioClip::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);

    // Currently Disabled because AwakeFromLoadThreaded is where the loading happens.
    // We need to be able to check this condition in AwakeFromLoadThreaded
    //if (awakeMode & kWillUnloadAfterWritingBuildData)
    //  return;

    // Load data if not done from another thread already
    if ((awakeMode & kDidLoadThreaded) == 0)
    {
        // We don't preload streams because this can lead to an excessive number of open file handles
        if (m_PreloadAudioData && m_LoadType != kStreaming)
            LoadSound();
    }
    else if (m_ThreadedLoadInstance)
    {
        m_Sound = GetSoundManager()->IntegrateFMODSound(m_ThreadedLoadInstance, GetResource(), CalculateFlags(),
                m_SubsoundIndex, SoundHandle::kLoadingBase);

        m_ThreadedLoadInstance = NULL;
    }
}

#if UNITY_EDITOR
SoundHandle AudioClip::AllocatePreviewSound()
{
    if (m_legacy.get() != NULL)
    {
        m_Sound = CreateSound();
        return m_Sound;
    }

    return SampleClip::AllocatePreviewSound();
}

#endif

IMPLEMENT_REGISTER_CLASS(AudioClip, 83);
IMPLEMENT_OBJECT_SERIALIZE(AudioClip);
