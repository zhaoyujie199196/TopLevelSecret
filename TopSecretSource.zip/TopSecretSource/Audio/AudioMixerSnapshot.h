#pragma once

#include "Runtime/BaseClasses/NamedObject.h"
#include "Runtime/Utilities/GUID.h"

class AudioMixer;

class AudioMixerSnapshot : public NamedObject
{
    REGISTER_CLASS(AudioMixerSnapshot);
    DECLARE_OBJECT_SERIALIZE();
public:
    AudioMixerSnapshot(MemLabelId label, ObjectCreationMode mode);
    // virtual ~AudioMixerSnapshot (); - declared-by-macro

    virtual void AwakeFromLoad(AwakeFromLoadMode awakeMode);

    PPtr<AudioMixer> GetAudioMixer() const { return m_AudioMixer; }
    const UnityGUID& GetSnapshotID() const { return m_SnapshotID; }

protected:
    PPtr<AudioMixer> m_AudioMixer;

private:
    UnityGUID        m_SnapshotID;
};
