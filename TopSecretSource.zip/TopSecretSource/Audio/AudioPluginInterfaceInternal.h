#ifndef UnityAudioEffectInternal_defined
#define UnityAudioEffectInternal_defined

#include <stddef.h>
#include "Runtime/Allocator/MemoryMacros.h"

// This entire structure must be a multiple of 16 bytes (and an instance 16 byte aligned) for PS3 SPU DMA requirements
struct ALIGN_TYPE(16)UnityAudioEffectInternal
{
    UInt64 currdsptick;
    UInt32 flags;
    UInt32 samplerate;
    UInt32 dspbuffersize;
};

#endif
