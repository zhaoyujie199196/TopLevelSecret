/*
 *  AudioScriptBufferManager.cpp
 *  AllTargets.workspace
 *
 *  Created by Søren Christiansen on 8/22/11.
 *  Copyright 2011 Unity Technologies. All rights reserved.
 *
 */
#include "UnityPrefix.h"
#include "AudioScriptBufferManager.h"
#include "AudioManager.h"
#include "Runtime/Scripting/ScriptingExportUtility.h"
#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/Mono/MonoManager.h"
#include "Runtime/ScriptingBackend/ScriptingApi.h"

AudioScriptBufferManager::AudioScriptBufferManager() :
    m_PCMReadArrayGCHandle()
    , m_PCMReadArrayOrigLength(0)
    , m_DSPFilterArrayGCHandle()
    , m_DSPFilterArrayOrigLength(0)
{
    Init();
}

AudioScriptBufferManager::~AudioScriptBufferManager()
{
}

void AudioScriptBufferManager::BeforeDomainReload()
{
    Cleanup();
}

void AudioScriptBufferManager::DidReloadDomain()
{
    Init();
}

void AudioScriptBufferManager::Init()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    Mutex::AutoLock lock1(m_DSPFilterArrayMutex);
    Mutex::AutoLock lock2(m_PCMReadArrayMutex);

    unsigned DSPBufferSize;
    int maxOutputChannels, maxInputChannels;
    FMOD::System* system = GetAudioManager().GetFMODSystem();
    system->getDSPBufferSize(&DSPBufferSize, NULL);
    system->getSoftwareFormat(NULL, NULL, &maxOutputChannels, &maxInputChannels, NULL, NULL);
    unsigned PCMArraySize = 16384 / 4;
    unsigned DSPFilterArraySize = DSPBufferSize * std::max(maxOutputChannels, maxInputChannels);

    // Create shared MonoArray for callbacks and DSPs
    m_PCMReadArrayOrigLength = PCMArraySize;

    ScriptingClassPtr klass = GetCommonScriptingClasses().floatSingle;
    m_PCMReadArrayGCHandle.AcquireStrong((ScriptingObjectPtr)CreateScriptingArray<float>(klass, m_PCMReadArrayOrigLength));

    m_DSPFilterArrayOrigLength = DSPFilterArraySize;
    m_DSPFilterArrayGCHandle.AcquireStrong((ScriptingObjectPtr)CreateScriptingArray<float>(klass, m_DSPFilterArrayOrigLength));
}

void AudioScriptBufferManager::Cleanup()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    // Cleanup mono arrays
    if (m_PCMReadArrayGCHandle.HasTarget())
    {
        #if ENABLE_MONO
        PatchLength(m_PCMReadArrayGCHandle.Resolve(), m_PCMReadArrayOrigLength);
        #endif
        m_PCMReadArrayGCHandle.ReleaseAndClear();
    }
    if (m_DSPFilterArrayGCHandle.HasTarget())
    {
        #if ENABLE_MONO
        PatchLength(m_DSPFilterArrayGCHandle.Resolve(), m_DSPFilterArrayOrigLength);
        #endif
        m_DSPFilterArrayGCHandle.ReleaseAndClear();
    }
}

void AudioScriptBufferManager::GetPCMReadArray(unsigned length, ScriptingArrayPtr &array)
{
    Assert(length <= m_PCMReadArrayOrigLength);
    ScriptingArrayPtr PCMReadArray = m_PCMReadArrayGCHandle.Resolve();
    unsigned curLength = GetScriptingArraySize(PCMReadArray);
    if (length != curLength)
    {
        #if ENABLE_MONO
        PatchLength(PCMReadArray, length);
        #else
        ScriptingClassPtr klass = GetScriptingManager().GetCommonClasses().floatSingle;
        array = CreateScriptingArray(Scripting::GetScriptingArrayStart<float>(PCMReadArray), length, klass);
        return;
        #endif
    }
    array = PCMReadArray;
}

void AudioScriptBufferManager::GetDSPFilterArray(unsigned length, ScriptingArrayPtr &array)
{
    Assert(length <= m_DSPFilterArrayOrigLength);
    ScriptingArrayPtr DSPFilterArray = m_DSPFilterArrayGCHandle.Resolve();
    unsigned curLength = GetScriptingArraySize(DSPFilterArray);
    if (length != curLength)
    {
        #if ENABLE_MONO
        PatchLength(DSPFilterArray, length);
        #else
        ScriptingClassPtr klass = GetScriptingManager().GetCommonClasses().floatSingle;
        array = CreateScriptingArray(Scripting::GetScriptingArrayStart<float>(DSPFilterArray), length, klass);
        return;
        #endif
    }
    array = DSPFilterArray;
}

#if ENABLE_MONO

void AudioScriptBufferManager::PatchLength(ScriptingArrayPtr array, unsigned newlength)
{
    char* pos = sizeof(uintptr_t) * 3 + (char*)UnsafeExtractPointerFromScriptingObjectPtr((ScriptingObjectPtr)array);
    *((UInt32*)pos) = (UInt32)newlength;
}

#endif
