#ifndef __AUDIOLISTENER_H__
#define __AUDIOLISTENER_H__

#if ENABLE_AUDIO

#include "Runtime/GameCode/Behaviour.h"
#include "Runtime/Math/Vector3.h"
#include "Runtime/Transform/Transform.h"
#include "AudioBehaviour.h"

class Transform;

class AudioListener : public AudioBehaviour
{
    REGISTER_CLASS(AudioListener);
    DECLARE_OBJECT_SERIALIZE();
public:
    AudioListener(MemLabelId label, ObjectCreationMode mode);
    // virtual ~AudioListener (); declared-by-macro

    void AwakeFromLoad(AwakeFromLoadMode awakeMode);
    int GetVelocityUpdateMode() const         { return m_VelocityUpdateMode; }
    void SetVelocityUpdateMode(int update) { m_VelocityUpdateMode = update; }

    // Behaviour
    virtual void Update();
    virtual void FixedUpdate();

    ListNode<AudioListener>& GetNode() { return m_Node; }

    const Vector3f& GetPosition() const { return m_LastPosition; }
    const Vector3f& GetVelocity() const { return m_Velocity; }

    void OnAddComponent();

    static void InitializeClass();
    static void CleanupClass();

    void Cleanup();

    void SetAlternativeTransform(Transform* t);

    inline const Matrix4x4f& GetInverseMatrix() const { return m_InverseMatrix; }

private:
    virtual void AddToManager();
    virtual void RemoveFromManager();
    void DoUpdate();
    void ApplyFilters();
    void InitialiseMixer();
    void TeardownMixer();

private:
    Vector3f    m_LastPosition;
    Vector3f    m_Velocity;
    int         m_VelocityUpdateMode;

    PPtr<Transform> m_AltTransform;
    const Transform& GetCurrentTransform() const;

    Matrix4x4f m_InverseMatrix;

    ListNode<AudioListener> m_Node;

    friend class AudioManager;
};

#endif //ENABLE_AUDIO
#endif // __AUDIOLISTENER_H__
