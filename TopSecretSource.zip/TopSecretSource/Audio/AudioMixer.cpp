#include "UnityPrefix.h"
#include "AudioMixer.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/Audio/mixer/audiomixerdata.h"
#include "Runtime/Audio/mixer/audiomixerruntime.h"
#include "Runtime/Threads/Mutex.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Animation/MecanimArraySerialization.h"

#include "Runtime/Audio/AudioMixerGroup.h"
#include "Runtime/Audio/AudioMixerSnapshot.h"

#include "Runtime/Audio/AudioManager.h"
#include "Runtime/Math/Simd/vec-math.h"

#if UNITY_EDITOR
#include "Editor/Src/Application.h"
#endif

#define ENSURE_VALID_RUNTIME_ERROR()           do { if (!EnsureValidRuntime ()) { ErrorString("Mixer is not initialized"); return; } } while (false)
#define ENSURE_VALID_RUNTIME_ERROR_RETURN(x)   do { if (!EnsureValidRuntime ()) { ErrorString("Mixer is not initialized"); return x; } } while (false)


AudioMixer::AudioMixer(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
    , m_Alloc(label)
    , m_MixerConstant(0)
    , m_MixerMemory(0)
    , m_Node(this)
    , m_SuspendThreshold(-80.0f)
    , m_EnableSuspend(true)
    , m_UpdateMode(kNormalTime)
{
}

void AudioMixer::ThreadedCleanup()
{
}

void AudioMixer::MainThreadCleanup()
{
    Cleanup();

    if (m_Node.IsInList())
        GetAudioManager().RemoveAudioMixer(this);

    Super::MainThreadCleanup();
}

void AudioMixer::CheckConsistency()
{
    //If we are loading an old project with no start snapshot, then set it here to the first in the list
    if (!m_StartSnapshot.IsValid())
    {
        m_StartSnapshot = m_Snapshots[0];
        SetDirty();
    }
}

void AudioMixer::Reset()
{
    Super::Reset();

    m_SuspendThreshold = -80.0f;
    m_EnableSuspend = true;
}

#define TRANSFER_NULLABLE2(x, TYPE) \
if (transfer.IsReading () || transfer.IsWriting ()) \
{ \
    if (x == NULL) \
    { \
        mecanim::memory::MecanimAllocator* allocator = static_cast<mecanim::memory::MecanimAllocator*> (transfer.GetUserData()); \
        x = allocator->Construct<TYPE>(); \
    } \
    transfer.Transfer(*x, #x); \
} \
else \
{ \
    TYPE p; \
    transfer.Transfer(p, #x); \
}

// janm: had to move this here from the .cpp file to avoid weird linker errors in release (build server) builds (on Mac only)
// this is probably caused by some incorrect stripping
template<class TransferFunction>
void AudioMixer::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);

    TRANSFER(m_OutputGroup);
    TRANSFER(m_MasterGroup);
    TRANSFER(m_Snapshots);
    TRANSFER(m_StartSnapshot);
    TRANSFER(m_SuspendThreshold);
    TRANSFER(m_EnableSuspend);
    transfer.Align();
    TRANSFER_ENUM(m_UpdateMode);

    transfer.Align();

    if (transfer.IsSerializingForGameRelease())
    {
        if (transfer.IsWritingGameReleaseData() && !EnsureValidConstant())
            ErrorString(Format("Unable to generate valid runtime data for serialization of AudioMixer: %s.", GetName()));

        transfer.SetUserData(&m_Alloc);
        TRANSFER_NULLABLE2(m_MixerConstant, audio::mixer::AudioMixerConstant);
        transfer.Align();
    }
}

void AudioMixer::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);
    GetAudioManager().AddAudioMixer(this);
}

void AudioMixer::Cleanup()
{
    CleanupMemory();

    if (m_MixerConstant != NULL)
    {
        DestroyAudioMixerConstant(m_MixerConstant, m_Alloc);
        m_MixerConstant = NULL;
    }

    GetAudioManager().CleanupDependentMixers(this);
}

void AudioMixer::CleanupMemory()
{
    if (m_MixerMemory)
    {
        DestroyAudioMixerMemory(m_MixerMemory, *m_MixerConstant,
            GetAudioManager().GetFMODSystem(), m_Alloc);
        m_MixerMemory = NULL;
    }
}

bool AudioMixer::PatchLiveLinkValue(UInt32 snapshotIndex, UInt32 snapshotParameterIndex, float value)
{
    if (m_MixerConstant == NULL)
        return false;

    if (snapshotIndex >= m_MixerConstant->snapshotCount)
        return false;
    if (snapshotParameterIndex >= m_MixerConstant->snapshots[snapshotIndex].valueCount)
        return false;

    m_MixerConstant->snapshots[snapshotIndex].values[snapshotParameterIndex] = value;
    return true;
}

void AudioMixer::OnEnterPlayModePreStart()
{
    if (m_MixerMemory)
        audio::mixer::ClearExposedParameterValues(*m_MixerConstant, *m_MixerMemory);

    SetCurrentSnapshot(m_StartSnapshot);
}

void AudioMixer::OnExitPlayMode()
{
    if (m_MixerMemory)
        audio::mixer::ClearExposedParameterValues(*m_MixerConstant, *m_MixerMemory);
}

bool AudioMixer::EnsureValidConstant()
{
    // Create a constant (Only supported in the editor)
    if (m_MixerConstant == NULL)
    {
        m_MixerConstant = BuildMixerConstant();
        if (m_MixerConstant == NULL)
            return false;
    }
    return true;
}

bool AudioMixer::EnsureValidRuntime()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return false;

    // We already have a valid runtime created
    if (m_MixerMemory != NULL)
        return true;

    if (!EnsureValidConstant())
        return false;

    // Create a memory from the constant
    SET_ALLOC_OWNER(this);
    m_MixerMemory = audio::mixer::CreateAudioMixerMemory(*m_MixerConstant, GetAudioManager().GetFMODSystem(), m_Alloc, GetInitialSnapshotIndex(), m_EnableSuspend);

    if (!m_MixerMemory)
    {
        return false;
    }

    OnRuntimeChanged();

    //This will call onMixerchange which will also reparent the new memory to the correct channelgroup
    UpdateMuteSolo();
    UpdateBypass();

    return true;
}

void AudioMixer::SetupGroups()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    ENSURE_VALID_RUNTIME_ERROR();

    FMOD::ChannelGroup* outputGroup = GetAudioManager().GetChannelGroup_FX_UseVolume();
    if (m_OutputGroup.IsValid())
    {
        FMOD::ChannelGroup* group = m_OutputGroup->GetAudioMixer()->GetFMODChannelGroup(m_OutputGroup->GetGroupID());
        if (group)
        {
            outputGroup = group;
        }
        else
        {
            ErrorString(Format("Invalid AudioMixerGroup output for mixer: %s, routing directly to device output.", GetName()));
        }
    }

    audio::mixer::AssignOutputGroup(*m_MixerConstant, *m_MixerMemory, outputGroup);

    GetAudioManager().RebindAudioSourcesToMixer(this);
}

void AudioMixer::ResumeProcessing()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    ENSURE_VALID_RUNTIME_ERROR();
    audio::mixer::SetSuspended(*m_MixerMemory, false);
    if (m_OutputGroup.IsValid())
        m_OutputGroup->GetAudioMixer()->ResumeProcessing();
}

bool AudioMixer::IsSuspended()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return true;

    if (m_MixerMemory == NULL)
        return true;

    return audio::mixer::IsSuspended(*m_MixerMemory);
}

bool AudioMixer::SetFloat(const char* name, float value)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return false;

    ENSURE_VALID_RUNTIME_ERROR_RETURN(false);

    // User is currently editing snapshot
    if (!AllowSnapshotTransitionsFromAPI())
    {
        // Return without outputting a warning here because this will spam the console otherwise
        return false;
    }

    int index = GetExposedPropertyIndex(*m_MixerConstant, name);
    if (index == -1)
    {
        WarningStringObject(Format("Exposed name does not exist: %s", name), this);
        return false;
    }

    audio::mixer::SetExposedProperty(*m_MixerMemory, index, value);
    return true;
}

bool AudioMixer::ClearFloat(const char* name)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return false;

    ENSURE_VALID_RUNTIME_ERROR_RETURN(false);

    int index = GetExposedPropertyIndex(*m_MixerConstant, name);
    if (index == -1)
    {
        WarningStringObject(Format("Exposed name does not exist: %s", name), this);
        return false;
    }

    audio::mixer::ClearExposedProperty(*m_MixerMemory, index);
    return true;
}

bool AudioMixer::GetFloat(const char* name, float* value)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return false;

    if (value == 0)
        return false;

    ENSURE_VALID_RUNTIME_ERROR_RETURN(false);

    int index = GetExposedPropertyIndex(*m_MixerConstant, name);
    if (index == -1)
    {
        WarningStringObject(Format("Exposed name does not exist: %s", name), this);
        return false;
    }

    float exval = audio::mixer::GetExposedPropertyValue(*m_MixerMemory, index);
    if (exval == audio::mixer::UNINITIALIZED_SNAPSHOT)
        return false;

    *value = exval;

    return true;
}

// Called from AudioManager
void AudioMixer::Update(float deltaTime)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    ENSURE_VALID_RUNTIME_ERROR();

    float suspendThreshold = (float)math::powr(math::float1(10.0f), math::float1(0.1f * m_SuspendThreshold));
    audio::mixer::UpdateAudioMixerMemory(*m_MixerConstant, *m_MixerMemory, deltaTime, GetAudioManager().GetFMODSystem(), m_EnableSuspend ? suspendThreshold : 0.0f);
}

void AudioMixer::TransitionToSnapshot(const PPtr<AudioMixerSnapshot>& snapshot, float timeToReachState)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    ENSURE_VALID_RUNTIME_ERROR();

    // User is currently editing snapshot
    if (!AllowSnapshotTransitionsFromAPI())
        return;

    UInt32 index = GetSnapshotIndex(*snapshot);
    audio::mixer::TransitionToSnapshot(*m_MixerMemory, index, timeToReachState);
    UpdateCurrentSnapshot(snapshot);
}

void AudioMixer::SetWeightedMix(AudioMixer::SnapshotList& snapshots, float* weights, float timeToReachState)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    ENSURE_VALID_RUNTIME_ERROR();

    // User is currently editing snapshot
    if (!AllowSnapshotTransitionsFromAPI())
        return;

    dynamic_array<int> indices;
    const int numWeights = snapshots.size();
    indices.resize_uninitialized(numWeights);

    for (int n = 0; n < numWeights; n++)
    {
        indices[n] = audio::mixer::GetSnapshotIndex(*m_MixerConstant, snapshots[n]->GetName());
        if (indices[n] == -1)
        {
            ErrorString(Format("Snapshot name does not exist: %s", snapshots[n]->GetName()));
            return;
        }
    }

    audio::mixer::SetWeightedMix(*m_MixerConstant, *m_MixerMemory, indices.data(), &weights[0], numWeights, timeToReachState);
}

void AudioMixer::SetCurrentSnapshot(const PPtr<AudioMixerSnapshot>& snapshot)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    Assert(snapshot.IsValid() && (snapshot->GetAudioMixer() == PPtr<AudioMixer>(this)));
    ENSURE_VALID_RUNTIME_ERROR();

    UInt32 index = GetSnapshotIndex(*snapshot);
    audio::mixer::TransitionToSnapshot(*m_MixerMemory, index, 0.0f);
    UpdateCurrentSnapshot(snapshot);
}

int AudioMixer::GetGroupVUInfo(const UnityGUID& guid, bool fader, audio::mixer::VUInfo* vuInfo)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return 0;

    ENSURE_VALID_RUNTIME_ERROR_RETURN(0.0f);
    return audio::mixer::GetGroupVUInfo(*m_MixerConstant, *m_MixerMemory, guid, fader, vuInfo);
}

void AudioMixer::ReassignAllChannelGroups()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    // Used to call GetAudioManager().OnMixerChanged() here but this leads to a huge amount of recursive calls to SetupGroups, doing way too much work and eventually
    // overloading FMOD with requests which can cause crashes with projects containing a large amount of mixers.

    if (m_OutputGroup.IsValid())
        m_OutputGroup->GetAudioMixer()->SetupGroups();

    SetupGroups();
}

FMOD::ChannelGroup* AudioMixer::GetFMODChannelGroup(const UnityGUID& guid)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return NULL;

    ENSURE_VALID_RUNTIME_ERROR_RETURN(NULL);
    return audio::mixer::FindChannelGroup(*m_MixerConstant, *m_MixerMemory, guid);
}

void AudioMixer::FindGroupsWithPartialPath(const char* subString, GroupList& groups)
{
    groups.clear();
    if (!EnsureValidRuntime())
        return;

    std::vector<UnityGUID> guids;

    //FIXME: Replace this logic when we remove the use of guids from the runtime. calculate it from the
    //natural hierarchy.
    audio::mixer::GetGroupGUIDsContainingSubString(*m_MixerConstant, subString, guids);

    m_MasterGroup->GetGroupInGUIDListRecursive(guids, groups);
}

PPtr<AudioMixerSnapshot> AudioMixer::FindSnapshotFromName(const char* name)
{
    for (int i = 0; i < m_Snapshots.size(); i++)
    {
        if (strcmp(m_Snapshots[i]->GetName(), name) == 0)
            return m_Snapshots[i];
    }

    return PPtr<AudioMixerSnapshot>();
}

core::string AudioMixer::GetGroupNameFromGUID(const UnityGUID& guid)
{
    if (!EnsureValidConstant())
        return "";

    return audio::mixer::GetGroupNameFromGUID(*m_MixerConstant, guid);
}

core::string AudioMixer::GetGroupPathFromGUID(const UnityGUID& guid)
{
    if (!EnsureValidConstant())
        return "";

    return audio::mixer::GetGroupPathFromGUID(*m_MixerConstant, guid);
}

UInt32 AudioMixer::GetSnapshotIndex(const AudioMixerSnapshot& snapshot)
{
    if (!EnsureValidConstant())
        return 0;

    int index = audio::mixer::GetSnapshotIndex(*m_MixerConstant, snapshot.GetName());
    if (index == -1)
    {
        ErrorString(Format("Snapshot name does not exist: %s", snapshot.GetName()));
        return 0;
    }
    Assert(index >= 0 && "Snapshot index is not valid.");
    return (UInt32)index;
}

UInt32 AudioMixer::GetInitialSnapshotIndex()
{
    Assert(m_StartSnapshot.IsValid());
    return GetSnapshotIndex(*m_StartSnapshot);
}

bool AudioMixer::CheckForCyclicReferences(AudioMixer* mixer, AudioMixerGroup* outputGroup)
{
    if (mixer == 0 || outputGroup == 0)
        return false;

    AudioMixer* outputMixer = outputGroup->GetAudioMixer();
    AssertMsg(outputMixer != 0, "AudioMixerGroup does not contain a valid parent AudioMixer");

    if (mixer == outputMixer)
        return true;

    return CheckForCyclicReferences(mixer, outputMixer->GetOutputAudioMixerGroup());
}

void AudioMixer::SetOutputAudioMixerGroup(const PPtr<AudioMixerGroup>& group)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    if (m_OutputGroup == group)
        return;

    if (CheckForCyclicReferences(this, group))
    {
        ErrorString(Format("Cannot set Output Mixer for AudioMixer: %s, creates curcular routing.", GetName()));
        return;
    }

    m_OutputGroup = group;
    SetDirty();

    SetupGroups();
}

void AudioMixer::UpdateMuteSolo()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    audio::mixer::GroupConstant* allGroups = &(m_MixerConstant->groups[0]);

    bool anyGroupSoloed = false;
    for (int n = 0; n < m_MixerConstant->groupCount; n++)
        anyGroupSoloed |= allGroups[n].solo;

    for (int n = 0; n < m_MixerConstant->groupCount; n++)
    {
        int index = n;
        if (anyGroupSoloed)
        {
            while (!allGroups[index].solo && allGroups[index].parentConstantIndex >= 0)
                index = allGroups[index].parentConstantIndex;
            audio::mixer::SetResultingMuteState(*m_MixerConstant, *m_MixerMemory, n, !allGroups[index].solo);
        }
        else
        {
            while (!allGroups[index].mute && allGroups[index].parentConstantIndex >= 0)
                index = allGroups[index].parentConstantIndex;
            audio::mixer::SetResultingMuteState(*m_MixerConstant, *m_MixerMemory, n, allGroups[index].mute);
        }
    }

    ReassignAllChannelGroups();
}

void AudioMixer::UpdateBypass()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;

    audio::mixer::UpdateBypass(*m_MixerConstant, *m_MixerMemory);
}

IMPLEMENT_REGISTER_CLASS(AudioMixer, 240);
IMPLEMENT_OBJECT_SERIALIZE(AudioMixer);
INSTANTIATE_TEMPLATE_TRANSFER(AudioMixer);
