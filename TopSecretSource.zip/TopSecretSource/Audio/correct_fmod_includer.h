#if UNITY_WIN && !defined(UNITY_WIN_API_SUBSET)
#include "Modules/Baselib/Public/UndefinePlatforms.h"
    #include "External/FMOD/builds/win32/include/fmod.hpp"
    #include "External/FMOD/builds/win32/include/fmod_errors.h"
    #include "External/FMOD/builds/win32/include/fmod_types.h"
#include "Modules/Baselib/Public/RedefinePlatforms.h"
#elif UNITY_OSX
#include "Modules/Baselib/Public/UndefinePlatforms.h"
    #include "External/FMOD/builds/macosx/include/fmod.hpp"
    #include "External/FMOD/builds/macosx/include/fmod_errors.h"
    #include "External/FMOD/builds/macosx/include/fmod_types.h"
#include "Modules/Baselib/Public/RedefinePlatforms.h"
#elif UNITY_LINUX
#include "Modules/Baselib/Public/UndefinePlatforms.h"
    #if defined(__LP64__) || defined(_LP64)
        #include "External/FMOD/builds/linux64/include/fmod.hpp"
        #include "External/FMOD/builds/linux64/include/fmod_errors.h"
        #include "External/FMOD/builds/linux64/include/fmod_types.h"
    #else
        #include "External/FMOD/builds/linux32/include/fmod.hpp"
        #include "External/FMOD/builds/linux32/include/fmod_errors.h"
        #include "External/FMOD/builds/linux32/include/fmod_types.h"
    #endif
#include "Modules/Baselib/Public/RedefinePlatforms.h"
#elif UNITY_IPHONE || UNITY_TVOS
#include "Modules/Baselib/Public/UndefinePlatforms.h"
    #include "External/FMOD/builds/iphone/include/fmod.hpp"
    #include "External/FMOD/builds/iphone/include/fmod_errors.h"
    #include "External/FMOD/builds/iphone/include/fmod_types.h"
#include "Modules/Baselib/Public/RedefinePlatforms.h"
#elif UNITY_WIIU
#include "Modules/Baselib/Public/UndefinePlatforms.h"
    #include <fmod.hpp>
    #include <fmod_errors.h>
#include "Modules/Baselib/Public/RedefinePlatforms.h"
#elif UNITY_PSP2
#include "Modules/Baselib/Public/UndefinePlatforms.h"
    #include "PlatformDependent/PSP2Player/External/FMOD/builds/psp2/include/fmod.hpp"
    #include "PlatformDependent/PSP2Player/External/FMOD/builds/psp2/include/fmod_errors.h"
//#include "PlatformDependent/PSP2Player/External/FMOD/builds/psp2/include/fmod_types.h"
#include "Modules/Baselib/Public/RedefinePlatforms.h"
#elif UNITY_TIZEN
#include "Modules/Baselib/Public/UndefinePlatforms.h"
    #include "PlatformDependent/TizenPlayer/External/FMOD/builds/tizen/include/fmod.hpp"
    #include "PlatformDependent/TizenPlayer/External/FMOD/builds/tizen/include/fmod_errors.h"
    #include "PlatformDependent/TizenPlayer/External/FMOD/builds/tizen/include/fmod_types.h"
#include "Modules/Baselib/Public/RedefinePlatforms.h"
#elif UNITY_XBOXONE
#include "Modules/Baselib/Public/UndefinePlatforms.h"
    #include "PlatformDependent/XboxOne/External/FMOD/builds/xboxone/include/fmod.hpp"
    #include "PlatformDependent/XboxOne/External/FMOD/builds/xboxone/include/fmod_errors.h"
    #include "PlatformDependent/XboxOne/External/FMOD/builds/xboxone/include/fmod_types.h"
#include "Modules/Baselib/Public/RedefinePlatforms.h"
#elif UNITY_STV
#include "Modules/Baselib/Public/UndefinePlatforms.h"
    #include "External/FMOD/builds/stv/include/fmod.hpp"
    #include "External/FMOD/builds/stv/include/fmod_errors.h"
    #include "External/FMOD/builds/stv/include/fmod_types.h"
#include "Modules/Baselib/Public/RedefinePlatforms.h"
#elif UNITY_WEBGL
#include "Modules/Baselib/Public/UndefinePlatforms.h"
// FMOD files are the same on all platforms, we need to properly fix the correct_fmod_includer.h to reflect this at some point.
    #include "External/FMOD/builds/android/include/fmod.hpp"
    #include "External/FMOD/builds/android/include/fmod_errors.h"
    #include "External/FMOD/builds/android/include/fmod_types.h"
#include "Modules/Baselib/Public/RedefinePlatforms.h"
#else
#include "Modules/Baselib/Public/UndefinePlatforms.h"
    #include <fmod.hpp>
    #include <fmod_errors.h>
    #include <fmod_types.h>
#include "Modules/Baselib/Public/RedefinePlatforms.h"
#endif
