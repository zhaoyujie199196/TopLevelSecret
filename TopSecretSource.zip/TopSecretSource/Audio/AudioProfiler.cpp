#define ENABLE_AUDIO_PROFILER !UNITY_WEBGL

#include "UnityPrefix.h"
#include "AudioProfiler.h"
#include "Runtime/Audio/AudioManager.h"
#include "Runtime/Audio/AudioClip.h"
#include "Runtime/Audio/AudioSource.h"
#include "Runtime/Utilities/PlayerPrefs.h"

namespace AudioProfiler
{
    typedef std::vector<Object*> ObjectList;

    static const UInt32 AUDIOPROFILER_STREAM_VERSION         = 0x00000002;
    static const UInt32 AUDIOPROFILER_STREAM_TAIL            = 0xAFAFAFAF;
    static const UInt32 AUDIOPROFILER_FLAGS_3D               = 0x00000001;
    static const UInt32 AUDIOPROFILER_FLAGS_ISSPATIAL        = 0x00000002;
    static const UInt32 AUDIOPROFILER_FLAGS_PAUSED           = 0x00000004;
    static const UInt32 AUDIOPROFILER_FLAGS_MUTED            = 0x00000008;
    static const UInt32 AUDIOPROFILER_FLAGS_VIRTUAL          = 0x00000010;
    static const UInt32 AUDIOPROFILER_FLAGS_ONESHOT          = 0x00000020;
    static const UInt32 AUDIOPROFILER_FLAGS_GROUP            = 0x00000040;
    static const UInt32 AUDIOPROFILER_FLAGS_STREAM           = 0x00000080;
    static const UInt32 AUDIOPROFILER_FLAGS_COMPRESSED       = 0x00000100;
    static const UInt32 AUDIOPROFILER_FLAGS_LOOPED           = 0x00000200;
    static const UInt32 AUDIOPROFILER_FLAGS_OPENMEMMORY      = 0x00000400;
    static const UInt32 AUDIOPROFILER_FLAGS_OPENMEMMORYPOINT = 0x00000800;
    static const UInt32 AUDIOPROFILER_FLAGS_OPENUSER         = 0x00001000;
    static const UInt32 AUDIOPROFILER_FLAGS_NONBLOCKING      = 0x00002000;

    static const UInt32 AUDIOPROFILER_DSPFLAGS_ACTIVE        = 0x00000001;
    static const UInt32 AUDIOPROFILER_DSPFLAGS_BYPASS        = 0x00000002;

    static inline int ConvertHandleToUniqueID(void* handle, int mask)
    {
        return (unsigned int)((uintptr_t)handle & 0x7FFFFFF0) | mask; // filter out FMOD's 4 system bits
    }

    class AudioProfilerCaptureContext
    {
    public:
        AudioProfilerCaptureContext(dynamic_array<AudioProfilerGroupInfo>& _groupData, dynamic_array<AudioProfilerDSPInfo>& _dspData, dynamic_array<AudioProfilerClipInfo>& _clipData, dynamic_array<char>& _names)
            : groupData(_groupData)
            , dspData(_dspData)
            , clipData(_clipData)
            , names(_names)
        {
        }

        dynamic_array<AudioProfilerGroupInfo>& groupData;
        dynamic_array<AudioProfilerDSPInfo>& dspData;
        dynamic_array<AudioProfilerClipInfo>& clipData;
        dynamic_array<char>& names;

        FMOD_VECTOR listenerPos;
        FMOD_VECTOR listenerFwd;
        FMOD_VECTOR listenerUp;
    };

    // Returns the accumulated number of channels throughout the channel groups
    int CaptureChannelGroup(FMOD::ChannelGroup* group, AudioProfilerCaptureContext& context, int parentID)
    {
        const int groupMask = 1;
        const int channelMask = 2;

        char nameBuffer[64];
        if (group->getName(nameBuffer, sizeof(nameBuffer) - 1) != FMOD_OK)
            return 0;

        AudioProfilerGroupInfo groupInfo;
        memset(&groupInfo, 0, sizeof(groupInfo));
        if (group->getVolume(&groupInfo.volume) != FMOD_OK)
            return 0;

        if (group->getPitch(&groupInfo.frequency) != FMOD_OK)
            return 0;

        bool muted, paused;
        if (group->getMute(&muted) != FMOD_OK)
            return 0;

        if (group->getPaused(&paused) != FMOD_OK)
            return 0;

        groupInfo.flags = AUDIOPROFILER_FLAGS_GROUP;
        if (muted)
            groupInfo.flags |= AUDIOPROFILER_FLAGS_MUTED;
        if (paused)
            groupInfo.flags |= AUDIOPROFILER_FLAGS_PAUSED;
        groupInfo.parentId = parentID;
        groupInfo.uniqueId = ConvertHandleToUniqueID(group, groupMask);
        groupInfo.objectNameOffset = context.names.size();

        if (strcmp(nameBuffer, "FMOD master group") == 0)
            memcpy(nameBuffer, "Audio Listener", 15);

        if (
#if UNITY_EDITOR
            EditorPrefs::GetBool("AudioProfilerShowAllGroups") ||
#endif
            (
                strcmp(nameBuffer, "ASrcDryGroup") != 0 &&
                strcmp(nameBuffer, "ASrcWetGroup") != 0 &&
                strcmp(nameBuffer, "FX_IgnoreVol") != 0 &&
                strcmp(nameBuffer, "FX_UseVol") != 0 &&
                strcmp(nameBuffer, "NoFX_IgnoreVol") != 0 &&
                strcmp(nameBuffer, "NoFX_UseVol") != 0))
        {
            const char* s = nameBuffer;
            while (*s)
                context.names.push_back(*s++);
            context.names.push_back(0);

            parentID = groupInfo.uniqueId;
            context.groupData.push_back(groupInfo);
        }

        int numChannels = 0, actualChannels = 0;
        if (group->getNumChannels(&numChannels) != FMOD_OK)
            return 0;

        if (numChannels > 0)
        {
            AudioProfilerGroupInfo channelInfo;
            memset(&channelInfo, 0, sizeof(channelInfo));
            channelInfo.parentId = parentID;

            for (int i = 0; i < numChannels; i++)
            {
                FMOD::Channel* channel = NULL;
                if (group->getChannel(i, &channel) == FMOD_OK)
                {
                    FMOD_MODE mode;
                    if (channel->getMode((FMOD_MODE*)&mode) != FMOD_OK)
                        continue;

                    channelInfo.uniqueId = ConvertHandleToUniqueID(channel, channelMask);

                    float panlevel;
                    bool is3D = (mode & FMOD_3D) != 0 && channel->get3DPanLevel(&panlevel) == FMOD_OK && panlevel > 0.0f;
                    bool isSpatial = false;

                    SoundUserDataGeneric* userdata = NULL;
                    if (channel->getUserData((void**)&userdata) != FMOD_OK || userdata == NULL)
                        continue;

                    AudioSource* source = NULL;
                    SoundChannelInstance* soundchannel = userdata->TryGet<SoundChannelInstance>();
                    if (soundchannel != NULL)
                    {
                        source = soundchannel->GetAudioSource();
                        if (soundchannel->GetFlag(SoundChannelInstance::ONESHOT))
                            channelInfo.flags |= AUDIOPROFILER_FLAGS_ONESHOT;
                        if (source != NULL)
                        {
                            isSpatial = source->IsSpatializerActive();
                            is3D |= isSpatial;
                            is3D &= source->GetSpatialBlendMix() > 0.0f;
                        }
                    }
                    else
                    {
                        channelInfo.assetInstanceId = InstanceID_None;
                        channelInfo.assetNameOffset = 1;
                        channelInfo.objectInstanceId = InstanceID_None;
                        channelInfo.objectNameOffset = 1;
                    }

                    if (is3D)
                    {
                        FMOD_VECTOR pos;
                        if (channel->get3DAttributes(&pos, NULL) != FMOD_OK)
                            continue;

                        if (channel->get3DMinMaxDistance(&channelInfo.minDist, &channelInfo.maxDist) != FMOD_OK)
                            continue;

                        float dx = pos.x - context.listenerPos.x;
                        float dy = pos.y - context.listenerPos.y;
                        float dz = pos.z - context.listenerPos.z;
                        channelInfo.distanceToListener = sqrtf(dx * dx + dy * dy + dz * dz);
                    }
                    else
                    {
                        channelInfo.distanceToListener = -1.0f;
                        channelInfo.minDist = 1000000.0f;
                        channelInfo.maxDist = 1000000.0f;
                    }

                    if (channel->getVolume(&channelInfo.volume) != FMOD_OK)
                        continue;

                    if (channel->getAudibility(&channelInfo.audibility) != FMOD_OK)
                        continue;

                    bool isPlaying, isPaused, isVirtual, isMuted;
                    if (channel->isPlaying(&isPlaying) != FMOD_OK)
                        continue;

                    if (channel->getPaused(&isPaused) != FMOD_OK)
                        continue;

                    if (channel->isVirtual(&isVirtual) != FMOD_OK)
                        continue;

                    if (channel->getMute(&isMuted) != FMOD_OK)
                        continue;

                    if (is3D)
                        channelInfo.flags |= AUDIOPROFILER_FLAGS_3D;
                    if (isSpatial)
                        channelInfo.flags |= AUDIOPROFILER_FLAGS_ISSPATIAL;
                    if (isPaused)
                        channelInfo.flags |= AUDIOPROFILER_FLAGS_PAUSED;
                    if (isMuted)
                        channelInfo.flags |= AUDIOPROFILER_FLAGS_MUTED;
                    if (isVirtual)
                        channelInfo.flags |= AUDIOPROFILER_FLAGS_VIRTUAL;
                    if ((mode & FMOD_CREATESTREAM) != 0)
                        channelInfo.flags |= AUDIOPROFILER_FLAGS_STREAM;
                    if ((mode & FMOD_CREATECOMPRESSEDSAMPLE) != 0)
                        channelInfo.flags |= AUDIOPROFILER_FLAGS_COMPRESSED;
                    if ((mode & FMOD_OPENMEMORY) != 0)
                        channelInfo.flags |= AUDIOPROFILER_FLAGS_OPENMEMMORY;
                    if ((mode & FMOD_OPENMEMORY_POINT) != 0)
                        channelInfo.flags |= AUDIOPROFILER_FLAGS_OPENMEMMORYPOINT;
                    if ((mode & FMOD_OPENUSER) != 0)
                        channelInfo.flags |= AUDIOPROFILER_FLAGS_OPENUSER;
                    if ((mode & FMOD_NONBLOCKING) != 0)
                        channelInfo.flags |= AUDIOPROFILER_FLAGS_NONBLOCKING;
                    if ((mode & (FMOD_LOOP_NORMAL | FMOD_LOOP_BIDI)) != 0)
                        channelInfo.flags |= AUDIOPROFILER_FLAGS_LOOPED;

                    unsigned int playPos = 0;
                    if (channel->getPosition(&playPos, FMOD_TIMEUNIT_MS) != FMOD_OK)
                        continue;

                    channelInfo.time = playPos * 0.001f;

                    if (channel->getFrequency(&channelInfo.frequency) != FMOD_OK)
                        continue;

                    FMOD::Sound* sound = NULL;
                    if (channel->getCurrentSound(&sound) != FMOD_OK)
                        continue;

                    if (sound != NULL)
                    {
                        unsigned int duration = 0;
                        SoundUserDataGeneric* sounduserdata = NULL;
                        if (sound->getUserData((void**)&sounduserdata) != FMOD_OK)
                            continue;

                        if (sounduserdata == NULL)
                        {
                            channelInfo.assetInstanceId = InstanceID_None;
                            channelInfo.assetNameOffset = 1;
                            channelInfo.objectInstanceId = InstanceID_None;
                            channelInfo.objectNameOffset = 1;
                            continue;
                        }

                        SoundHandle::Instance* instance = sounduserdata->TryGet<SoundHandle::Instance>();
                        if (instance == NULL)
                            continue;

                        if (sound->getLength(&duration, FMOD_TIMEUNIT_MS) != FMOD_OK)
                            continue;

                        channelInfo.duration = duration * 0.001f;

                        SampleClip* clip = GetParentSampleClipFromInstance(instance);
                        if (clip != NULL)
                        {
                            channelInfo.playCount = clip->GetPlayCount();
                            channelInfo.assetInstanceId = clip->GetInstanceID();
                            channelInfo.assetNameOffset = context.names.size();
                            const char* s = clip->GetName();
                            while (*s)
                                context.names.push_back(*s++);
                            context.names.push_back(0);
                        }
                    }

                    if (source != NULL)
                    {
                        channelInfo.objectInstanceId = source->GetGameObject().GetInstanceID();
                        channelInfo.objectNameOffset = context.names.size();
                        const char* s = source->GetName();
                        while (*s)
                            context.names.push_back(*s++);
                        context.names.push_back(0);
                    }

                    context.groupData.push_back(channelInfo);
                    actualChannels++;
                }
            }
        }

        int numChildGroups = 0;
        FMOD::ChannelGroup* childGroup;
        if (group->getNumGroups(&numChildGroups) == FMOD_OK)
            for (int i = 0; i < numChildGroups; i++)
                if (group->getGroup(i, &childGroup) == FMOD_OK)
                    actualChannels += CaptureChannelGroup(childGroup, context, parentID);

        return actualChannels;
    }

    int CaptureDSPNodes(FMOD::DSP* dsp, AudioProfilerCaptureContext& context, UInt32 targetID, UInt32 targetPort, float mixToTarget)
    {
        AudioProfilerDSPInfo node;
        node.target = targetID;
        node.targetPort = targetPort;
        node.weight = mixToTarget;
        node.id = (uintptr_t)(((UInt64)dsp & 0xFFFFFFFF) ^ ((UInt64)dsp >> 32));
        char namebuffer[40]; memset(namebuffer, 0, sizeof(namebuffer)); // from FMOD docs: "This will be a maximum of 32bytes. If the DSP unit has filled all 32 bytes with the name with no terminating \0 null character it is up to the caller to append a null character. Optional. Specify 0 or NULL to ignore."
        int numInputs = 0, numChannels = 0;
        dsp->getNumInputs(&numInputs);
        dsp->getInfo(namebuffer, NULL, &numChannels, NULL, NULL);
        node.numChannels = numChannels;
        node.nameOffset = context.names.size();

        unsigned short usage = 0;
#if !UNITY_N3DS
        dsp->getCPUUsage(&usage);
#endif
        node.cpuLoad = usage;

        bool active, bypass;
        dsp->getActive(&active);
        dsp->getBypass(&bypass);
        node.flags = (active ? AUDIOPROFILER_DSPFLAGS_ACTIVE : 0) | (bypass ? AUDIOPROFILER_DSPFLAGS_BYPASS : 0);

#ifdef UNITY_EXTRA_FUNCTIONALITY_PEAKLEVELS
        static const float scale = 1.0f / 31.0f;
        int numPeakLevels = 0;
        unsigned char peakLevels[16];
        dsp->getPeakLevels(peakLevels, &numPeakLevels);
        Assert(numPeakLevels <= 16);
        node.level1 = (numPeakLevels >= 1) ? peakLevels[0] * scale : 0.0f;
        node.level2 = (numPeakLevels >= 2) ? peakLevels[1] * scale : 0.0f;
        node.numLevels = (numPeakLevels > 2) ? 2 : numPeakLevels;
#endif

        const char* s = namebuffer;
        while (*s)
            context.names.push_back(*s++);
        context.names.push_back(0);

        context.dspData.push_back(node);

        for (int n = 0; n < numInputs; n++)
        {
            FMOD::DSP* dspInput = NULL;
            FMOD::DSPConnection* dspInputConnection = NULL;
            dsp->getInput(n, &dspInput, &dspInputConnection);
            dspInputConnection->getMix(&mixToTarget);
            CaptureDSPNodes(dspInput, context, node.id, n, mixToTarget);
        }

        return numInputs;
    }

    void CaptureAudioClips(AudioProfilerCaptureContext& context)
    {
        GetSoundManager()->CaptureProfilerInfo(context.clipData, context.names);
    }

    void CaptureFrame(dynamic_array<AudioProfilerGroupInfo>& groupData, dynamic_array<AudioProfilerDSPInfo>& dspData, dynamic_array<AudioProfilerClipInfo>& clipData, dynamic_array<char>& names)
    {
        groupData.clear();
        dspData.clear();
        clipData.clear();
        names.clear();

#if ENABLE_AUDIO_PROFILER

        names.reserve(4096);

        // first nameOffset must point to empty string
        names.push_back(0);

        const char* s = "UNKNOWN";
        while (*s)
            names.push_back(*s++);
        names.push_back(0);

        FMOD::System* fmodSystem = GetAudioManager().GetFMODSystem();

        FMOD::ChannelGroup* masterGroup = NULL;
        fmodSystem->getMasterChannelGroup(&masterGroup);

        FMOD::DSP* masterDSP = NULL;
        masterGroup->getDSPHead(&masterDSP);

        AudioProfilerCaptureContext context(groupData, dspData, clipData, names);

        if (GetAudioManager().GetProfilerCaptureFlags() & AudioProfilerCaptureFlags_Channels)
        {
            fmodSystem->get3DListenerAttributes(0, &context.listenerPos, NULL, &context.listenerFwd, &context.listenerUp);
            context.groupData.reserve(128);
            CaptureChannelGroup(masterGroup, context, 0);
        }

        if (GetAudioManager().GetProfilerCaptureFlags() & AudioProfilerCaptureFlags_DSPNodes)
        {
            context.dspData.reserve(128);
            CaptureDSPNodes(masterDSP, context, 0, 0, 1.0f);
        }

        if (GetAudioManager().GetProfilerCaptureFlags() & AudioProfilerCaptureFlags_Clips)
        {
            context.clipData.reserve(128);
            CaptureAudioClips(context);
        }

        // Pad with zeros to make byteswapping easy
        while (names.size() & 3)
            names.push_back(0);

#endif
    }
}
