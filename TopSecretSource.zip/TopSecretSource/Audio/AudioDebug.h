#ifndef AUDIODEBUG_H
#define AUDIODEBUG_H

#ifdef UNITY
    #include "Runtime/Profiler/TimeHelper.h"
#else
    #include <stdlib.h>
    #include <stdio.h>
    #include <stdarg.h>
    #include <string.h>
    #include <assert.h>
    #include <string>
    #define UInt32 unsigned int
    #define ProfileTimeFormat __int64
    #define TimeFormat __int64
    #define GetProfilerTime() 0
    #define ELAPSED_TIME 0
    #define TimeToNanoseconds(x) (x)
    #define printf_console printf
    #define AssertMsg(cond, ...) assert(cond)
    #define Assert(cond) assert(cond)
    #define GetStacktrace() ""
#endif

#ifndef AUDIOFEATUREDEFINES_H
#error Do not include AudioDebug.h directly, instead include AudioFeatureDefines.h
#endif

#define AUDIO_DEBUG_FILTER_SMARTPTR             (1 << 0)
#define AUDIO_DEBUG_FILTER_FMODAPI              (1 << 1)
#define AUDIO_DEBUG_FILTER_SIMPLEGETTER         (1 << 2)
#define AUDIO_DEBUG_FILTER_SOURCETRANSFER       (1 << 3)
#define AUDIO_DEBUG_FILTER_ONESHOT              (1 << 4)
#define AUDIO_DEBUG_FILTER_CACHEDSOUND          (1 << 5)
#define AUDIO_DEBUG_FILTER_CHANNEL              (1 << 6)
#define AUDIO_DEBUG_FILTER_AUDIOSOURCE          (1 << 7)
#define AUDIO_DEBUG_FILTER_AUDIOCLIP            (1 << 8)
#define AUDIO_DEBUG_FILTER_FAKEMOD_SYSTEM       (1 << 9)
#define AUDIO_DEBUG_FILTER_FAKEMOD_SOUND        (1 << 10)
#define AUDIO_DEBUG_FILTER_FAKEMOD_CHANNEL      (1 << 11)
#define AUDIO_DEBUG_FILTER_FAKEMOD_CHANNELGROUP (1 << 12)
#define AUDIO_DEBUG_FILTER_FAKEMOD_DSP          (1 << 13)
#define AUDIO_DEBUG_FILTER_FAKEMOD_REVERB       (1 << 14)
#define AUDIO_DEBUG_FILTER_FAKEMOD_CORE         (1 << 15)
#define AUDIO_DEBUG_FILTER_FAKEMOD_HANDLE       (1 << 16)
#define AUDIO_DEBUG_FILTER_FAKEMOD_ALL          (255 << 9)

#define AUDIO_DEBUG_FILTER_IGNORE               AUDIO_DEBUG_FILTER_FAKEMOD_ALL //(0 * (AUDIO_DEBUG_FILTER_SMARTPTR | AUDIO_DEBUG_FILTER_SIMPLEGETTER | AUDIO_DEBUG_FILTER_FMODAPI | AUDIO_DEBUG_FILTER_SOURCETRANSFER | AUDIO_DEBUG_FILTER_ONESHOT | AUDIO_DEBUG_FILTER_CACHEDSOUND))
#define AUDIO_DEBUG_BREAKONINSTANCE             (0 * (AUDIO_DEBUG_FILTER_CACHEDSOUND))

#define AUDIO_DEBUG_TIMETHRESHOLD               15000000 // Output a warning if an FMOD call takes longer than this (nanoseconds)

#if AUDIO_ENABLE_DEBUGGING

    #if !UNITY
        #define AudioDebugThreadID int
        #define AudioDebugGetThreadID 0
        #define AudioDebugMainThreadID 0
        #define AudioDebugEqualsCurrentThreadID(...) true
        #define AudioDebugFMODErrorString(...) "[AudioDebugFMODErrorString does not work outside of Unity]"
    #else
        #define AudioDebugThreadID Thread::ThreadID
        #define AudioDebugGetThreadID Thread::GetCurrentThreadID()
        #define AudioDebugMainThreadID Thread::mainThreadId
        #define AudioDebugEqualsCurrentThreadID(...) Thread::EqualsCurrentThreadID(__VA_ARGS__)
        #define AudioDebugFMODErrorString(...) FMOD_ErrorString(__VA_ARGS__)
    #endif

// Fallback for global scope. When called inside a class, the member function will be used instead.
inline bool AudioDebug_ValidateMarkers(const void* thisptr, const char* filename, int line, const char* expr) { return true; }

inline unsigned long AudioDebug_GetInstanceCount() { return 0; }

// Return something that enables us to discern between real NULL ptrs and static functions that don't have this ptrs
inline const void* AudioDebug_GetThisPtr() { return (const void*)-1; }

inline unsigned long AudioDebug_GetScopeBaseFlags() { return 0; }

class AudioDebugTypeData
{
public:
    AudioDebugTypeData(const char* pInitMarker, const char* pClearMarker, const char* pName);
public:
    static bool InstanceCountChanged;
    UInt32 INITMARKER1;
    UInt32 INITMARKER2;
    UInt32 CLEARMARKER1;
    UInt32 CLEARMARKER2;
    int INSTANCECOUNTER;
    int INSTANCECOUNTERFRAMEPEAK;
    int INSTANCECOUNTERTOTALPEAK;
    const char* m_pName;
    AudioDebugTypeData* m_pNext;
};

extern char aAudioDebugPrintBuf[8192];

extern void AudioDebug_Indent(signed int tabdelta);
extern void AudioDebugDumpInstanceData(const char* title, bool clearcounters);
extern void AudioDebugDumpInstanceDataIfChanged(const char* title, bool clearcounters);

class AudioDebug_IndentScope
{
public:
    inline AudioDebug_IndentScope(int tabdelta = 0)
        : m_tabdelta(tabdelta)
    {
        AudioDebug_Indent(m_tabdelta);
    }

    inline ~AudioDebug_IndentScope()
    {
        AudioDebug_Indent(-m_tabdelta);
    }

protected:
    int m_tabdelta;
};

template<typename T, const int BREAKFILTER>
class AudioDebugInstanceData
{
public:
    AudioDebugInstanceData()
    {
            #if AUDIO_DEBUG_BREAKONINSTANCE > 0
        if (AUDIO_DEBUG_BREAKONINSTANCE & BREAKFILTER)
            __debugbreak();
            #endif
        AudioDebugTypeData& t = T::GetAudioDebugTypeData();
        m_audio_marker[0] = t.INITMARKER1;
        m_audio_marker[1] = t.INITMARKER2;
        ++t.INSTANCECOUNTER;
        t.InstanceCountChanged = true;
        if (t.INSTANCECOUNTER > t.INSTANCECOUNTERFRAMEPEAK) t.INSTANCECOUNTERFRAMEPEAK = t.INSTANCECOUNTER;
        if (t.INSTANCECOUNTER > t.INSTANCECOUNTERTOTALPEAK) t.INSTANCECOUNTERTOTALPEAK = t.INSTANCECOUNTER;
    }

    AudioDebugInstanceData(const AudioDebugInstanceData& c)
    {
            #if AUDIO_DEBUG_BREAKONINSTANCE > 0
        if (AUDIO_DEBUG_BREAKONINSTANCE & BREAKFILTER)
            __debugbreak();
            #endif
        AudioDebugTypeData& t = T::GetAudioDebugTypeData();
        m_audio_marker[0] = t.INITMARKER1;
        m_audio_marker[1] = t.INITMARKER2;
        ++t.INSTANCECOUNTER;
        t.InstanceCountChanged = true;
        if (t.INSTANCECOUNTER > t.INSTANCECOUNTERFRAMEPEAK) t.INSTANCECOUNTERFRAMEPEAK = t.INSTANCECOUNTER;
        if (t.INSTANCECOUNTER > t.INSTANCECOUNTERTOTALPEAK) t.INSTANCECOUNTERTOTALPEAK = t.INSTANCECOUNTER;
    }

    ~AudioDebugInstanceData()
    {
            #if AUDIO_DEBUG_BREAKONINSTANCE > 0
        if (AUDIO_DEBUG_BREAKONINSTANCE & BREAKFILTER)
            __debugbreak();
            #endif
        AudioDebugTypeData& t = T::GetAudioDebugTypeData();
        m_audio_marker[0] = t.CLEARMARKER1;
        m_audio_marker[1] = t.CLEARMARKER2;
        t.InstanceCountChanged = true;
        --t.INSTANCECOUNTER;
    }

public:
    unsigned long m_audio_marker[2];
    unsigned long m_audio_padding[2];
};

// Change first argument to true in FMOD_CHECK(...) in order to halt on FMOD error codes.
// FMOD_TEST should be used when the following code is performing error handling.
    #define AUDIO_ASSERT(...) { if(!(__VA_ARGS__)) AudioDebug_Error(AudioDebug_GetThisPtr(), "Audio assert: ", __FILE__, __LINE__, #__VA_ARGS__, true); }
    #define AUDIO_MARKER_DATA(filter, init, clear, classname) \
        public:\
            AudioDebugInstanceData<classname, filter> m_AudioDebugInstanceData;\
            static inline AudioDebugTypeData& GetAudioDebugTypeData() { static AudioDebugTypeData data(init, clear, GetClassName()); return data; }\
            static const char* GetClassName() { static char buf[512] = { 0 }; if(buf[0] == 0) { sprintf(buf, __FUNCTION__); int l = strlen(buf) - 1; while(buf[--l] != ':'); buf[--l] = 0; } return buf; }\
            inline bool AudioDebug_ValidateMarkers(const void* thisptr, const char* filename, int line, const char* expr) const\
            {\
                if(m_AudioDebugInstanceData.m_audio_marker[0] != GetAudioDebugTypeData().INITMARKER1 || m_AudioDebugInstanceData.m_audio_marker[1] != GetAudioDebugTypeData().INITMARKER2)\
                {\
                    AudioDebug_ValidateMarkersError(thisptr, m_AudioDebugInstanceData.m_audio_marker[0], m_AudioDebugInstanceData.m_audio_marker[1], GetAudioDebugTypeData().INITMARKER1, GetAudioDebugTypeData().INITMARKER2, GetAudioDebugTypeData().CLEARMARKER1, GetAudioDebugTypeData().CLEARMARKER2, filename, line, expr);\
                    return false;\
                }\
                return true;\
            }\
            inline unsigned long AudioDebug_GetInstanceCount() const { return GetAudioDebugTypeData().INSTANCECOUNTER; }\
            inline const void* AudioDebug_GetThisPtr() const { assert(this != NULL); return this; }\
            inline unsigned long AudioDebug_GetScopeBaseFlags() const { return filter; }
extern void AudioDebug_Log(const void* thisptr, const char* filename, int line, int tabdelta, const char* pFmtStr, ...);
inline TimeFormat AudioDebugTimingStart() { return GetProfilerTime(); }
inline FMOD_RESULT AudioDebugTimingEnd(TimeFormat nStartTicks1, FMOD_RESULT nResult, TimeFormat nStartTicks2, const char* pFileName, int nLine, const char* pExpression)
{
    ProfileTimeFormat nTime = TimeToNanoseconds(ELAPSED_TIME((nStartTicks1 < nStartTicks2) ? nStartTicks1 : nStartTicks2));
    if (nTime > AUDIO_DEBUG_TIMETHRESHOLD)
    {
        sprintf_s(aAudioDebugPrintBuf, sizeof(aAudioDebugPrintBuf) - 1, "WARNING: FMOD call %s took %d ms" , pExpression, nTime / 1000000);
        AudioDebug_Log(AudioDebug_GetThisPtr(), pFileName, nLine, 0, aAudioDebugPrintBuf);
    }
    return nResult;
}

    #define AUDIO_DEBUG_TIMING(...)                         AudioDebugTimingEnd             (AudioDebugTimingStart(),   (__VA_ARGS__), AudioDebugTimingStart(), __FILE__, __LINE__, #__VA_ARGS__)
    #define AUDIO_MARKER_TEST()                             AudioDebug_ValidateMarkers      (AudioDebug_GetThisPtr(),                                           __FILE__, __LINE__, __FUNCTION__);
    #define AUDIO_ASSERT_ON_MAINTHREAD()                    AudioDebug_AssertOnMainThread   (AudioDebug_GetThisPtr(),   "",                                     __FILE__, __LINE__, "FMOD calls may only be executed on the main thread!", true)
    #define AUDIO_WARNING_ON_MAINTHREAD()                   AudioDebug_AssertOnMainThread   (AudioDebug_GetThisPtr(),   "",                                     __FILE__, __LINE__, "FMOD calls may only be executed on the main thread!", false)
    #define FMOD_TEST(...)                                  AudioDebug_CheckFMODResult      (AudioDebug_GetThisPtr(),   false,                                  __FILE__, __LINE__, #__VA_ARGS__, AUDIO_ASSERT_ON_MAINTHREAD(),     AUDIO_DEBUG_TIMING(__VA_ARGS__), AUDIO_ASSERT_ON_MAINTHREAD())
    #define FMOD_CHECK(...)                                 AudioDebug_CheckFMODResult      (AudioDebug_GetThisPtr(),   AUDIO_ENABLE_BREAK_ON_FMOD_ERROR != 0,  __FILE__, __LINE__, #__VA_ARGS__, AUDIO_ASSERT_ON_MAINTHREAD(),     AUDIO_DEBUG_TIMING(__VA_ARGS__), AUDIO_ASSERT_ON_MAINTHREAD())
    #define FMOD_TEST_NOTHREADTEST(...)                     AudioDebug_CheckFMODResult      (AudioDebug_GetThisPtr(),   false,                                  __FILE__, __LINE__, #__VA_ARGS__, true,                             AUDIO_DEBUG_TIMING(__VA_ARGS__), true)
    #define FMOD_CHECK_NOTHREADTEST(...)                    AudioDebug_CheckFMODResult      (AudioDebug_GetThisPtr(),   AUDIO_ENABLE_BREAK_ON_FMOD_ERROR != 0,  __FILE__, __LINE__, #__VA_ARGS__, true,                             AUDIO_DEBUG_TIMING(__VA_ARGS__), true)
    #define FMOD_TEST_NOTHREADTEST_STATIC(...)              AudioDebug_CheckFMODResult      (::AudioDebug_GetThisPtr(), false,                                  __FILE__, __LINE__, #__VA_ARGS__, true,                             AUDIO_DEBUG_TIMING(__VA_ARGS__), true)
    #define FMOD_CHECK_NOTHREADTEST_STATIC(...)             AudioDebug_CheckFMODResult      (::AudioDebug_GetThisPtr(), AUDIO_ENABLE_BREAK_ON_FMOD_ERROR != 0,  __FILE__, __LINE__, #__VA_ARGS__, true,                             AUDIO_DEBUG_TIMING(__VA_ARGS__), true)
    #define AUDIO_LOGSCOPE(...)                             AudioDebug_LogScope __audiolog  (AudioDebug_GetThisPtr(),                                           __FILE__, __LINE__, __FUNCTION__, AudioDebug_GetScopeBaseFlags(),   ##__VA_ARGS__); AUDIO_MARKER_TEST();
    #define AUDIO_LOGSCOPE_HANDLE(...)                      AudioDebug_LogScope __audiolog  (this,                                                              __FILE__, __LINE__, __FUNCTION__, ::AudioDebug_GetScopeBaseFlags(), ##__VA_ARGS__);
    #define AUDIO_LOGSCOPE_STATIC(...)                      AudioDebug_LogScope __audiolog  (::AudioDebug_GetThisPtr(),                                         __FILE__, __LINE__, __FUNCTION__, ::AudioDebug_GetScopeBaseFlags(), ##__VA_ARGS__);
    #define AUDIO_LOGMSG(...)                               { sprintf_s(aAudioDebugPrintBuf, sizeof(aAudioDebugPrintBuf) - 1, __VA_ARGS__);         AudioDebug_Log(AudioDebug_GetThisPtr(),     __FILE__, __LINE__, 0, aAudioDebugPrintBuf); }
    #define AUDIO_LOGMSG_STATIC(...)                        { sprintf_s(aAudioDebugPrintBuf, sizeof(aAudioDebugPrintBuf) - 1, __VA_ARGS__);         AudioDebug_Log(::AudioDebug_GetThisPtr(),   __FILE__, __LINE__, 0, aAudioDebugPrintBuf); }
    #define AUDIO_LOGPTR(ptr)                               { sprintf_s(aAudioDebugPrintBuf, sizeof(aAudioDebugPrintBuf) - 1, "%s = %p", #ptr, ptr);    AudioDebug_Log(AudioDebug_GetThisPtr(),     __FILE__, __LINE__, 0, aAudioDebugPrintBuf); }
    #define AUDIO_LOGPTR_STATIC(ptr)                        { sprintf_s(aAudioDebugPrintBuf, sizeof(aAudioDebugPrintBuf) - 1, "%s = %p", #ptr, ptr);    AudioDebug_Log(::AudioDebug_GetThisPtr(),   __FILE__, __LINE__, 0, aAudioDebugPrintBuf); }
    #define AUDIO_VALIDATEOBJECT(obj)                       { (obj)->AudioDebug_ValidateMarkers(AudioDebug_GetThisPtr(),                                        __FILE__, __LINE__, __FUNCTION__); }
    #define AUDIO_GETINSTANCECOUNT(obj)                     ((obj)->AudioDebug_GetInstanceCount())
    #define AUDIO_DUMPINSTANCEDATA(title, clear)             AudioDebugDumpInstanceData(title, clear)
    #define AUDIO_DUMPINSTANCEDATAIFCHANGED(title, clear)    AudioDebugDumpInstanceDataIfChanged(title, clear)
    #define AUDIO_INDENT(tabdelta)                          AudioDebug_Indent(tabdelta)
    #define AUDIO_INDENTSCOPE                               AudioDebug_IndentScope __indentscope

void AudioDebug_Error(const void* thisptr, const char* msg, const char* filename, int line, const char* expr, bool bFatal);
void AudioDebug_Log(const void* thisptr, const char* filename, int line, int tabdelta, const char* pFmtStr, ...);
bool AudioDebug_AssertOnMainThread(const void* thisptr, const char* msg, const char* filename, int line, const char* expr, bool bFatal);
void AudioDebug_ValidateMarkersError(const void* thisptr, unsigned long m1, unsigned long m2, unsigned long i1, unsigned long i2, unsigned long c1, unsigned long c2, const char* filename, int line, const char* expr);
FMOD_RESULT AudioDebug_CheckFMODResult(const void* thisptr, bool bBreak, const char* filename, int line, const char* expr, bool bPreCheck, FMOD_RESULT result, bool bPostCheck);                       // pre- and post-check because we can't rely on argument evaluation order

template<typename T>
inline T* AUDIO_NULLCHECK(T* obj)
{
    AUDIO_ASSERT(obj != NULL);
    AUDIO_VALIDATEOBJECT(obj);
    return obj;
}

class AudioDebug_LogScope
{
public:
    inline AudioDebug_LogScope(const void* thisptr, const char* filename, int line, const char* func, unsigned long basefilter, unsigned long customfilter = 0)
        : m_thisptr(thisptr)
        , m_filename(filename)
        , m_line(line)
        , m_func(func)
        , m_filter(basefilter | customfilter)
    {
        if ((m_filter & AUDIO_DEBUG_FILTER_IGNORE) == 0)
            AudioDebug_Log(thisptr, filename, line, 2, func);
    }

    inline ~AudioDebug_LogScope()
    {
        if ((m_filter & AUDIO_DEBUG_FILTER_IGNORE) == 0)
            AudioDebug_Log(m_thisptr, m_filename, m_line, -2, m_func);
    }

protected:
    const void* m_thisptr;
    const char* m_filename;
    int m_line;
    const char* m_func;
    unsigned long m_filter;
};

#else

    #define FMOD_TEST_NOTHREADTEST(...)                     (__VA_ARGS__)
    #define FMOD_TEST(...)                                  (__VA_ARGS__)
    #define FMOD_CHECK(...)                                 (__VA_ARGS__)
    #define FMOD_TEST_NOTHREADTEST(...)                     (__VA_ARGS__)
    #define FMOD_CHECK_NOTHREADTEST(...)                    (__VA_ARGS__)
    #define FMOD_TEST_NOTHREADTEST_STATIC(...)              (__VA_ARGS__)
    #define FMOD_CHECK_NOTHREADTEST_STATIC(...)             (__VA_ARGS__)
    #define AUDIO_LOGSCOPE(...)                             {}
    #define AUDIO_LOGSCOPE_HANDLE(...)                      {}
    #define AUDIO_LOGSCOPE_STATIC(...)                      {}
    #define AUDIO_LOGMSG(...)                               {}
    #define AUDIO_LOGMSG_STATIC(...)                        {}
    #define AUDIO_LOGPTR(ptr)                               {}
    #define AUDIO_LOGPTR_STATIC(ptr)                        {}
    #define AUDIO_VALIDATEOBJECT(obj)                       {}
    #define AUDIO_MARKER_TEST()                             {}
    #define AUDIO_ASSERT_ON_MAINTHREAD()                    {}
    #define AUDIO_WARNING_ON_MAINTHREAD()                   {}
    #define AUDIO_ASSERT(...)                               {}
    #define AUDIO_MARKER_DATA(filter, init, clear, classname)
    #define AUDIO_DUMPINSTANCEDATA(title, clear)             {}
    #define AUDIO_DUMPINSTANCEDATAIFCHANGED(title, clear)    {}
    #define AUDIO_INDENT(tabdelta)                          {}
    #define AUDIO_INDENTSCOPE()                             {}

#endif


#endif
