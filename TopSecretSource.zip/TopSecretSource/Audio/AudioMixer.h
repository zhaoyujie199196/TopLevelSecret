#pragma once

#include "Runtime/BaseClasses/NamedObject.h"
#include "Runtime/Utilities/LinkedList.h"
#include "Runtime/Utilities/GUID.h"

//FIXME: Make our own allocator.
#include "Runtime/mecanim/memory.h"

namespace FMOD
{
    class ChannelGroup;
}

namespace audio
{
namespace mixer
{
    struct AudioMixerConstant;
    struct AudioMixerMemory;
    struct VUInfo;
}
}

class AudioMixerGroup;
class AudioMixerSnapshot;

enum AudioMixerUpdateMode
{
    kNormalTime   = 0,
    kUnscaledTime = 1
};

class AudioMixer : public NamedObject
{
    REGISTER_CLASS(AudioMixer);
    DECLARE_OBJECT_SERIALIZE();
public:
    typedef dynamic_array<PPtr<AudioMixerGroup> > GroupList;
    typedef dynamic_array<PPtr<AudioMixerSnapshot> > SnapshotList;

    AudioMixer(MemLabelId label, ObjectCreationMode mode);
    // virtual ~AudioMixer (); - declared-by-macro

    virtual void MainThreadCleanup();

    virtual void CheckConsistency();

    virtual void Reset();

    // Cleanup should be called whenever anything in the editor representation is changed.
    // The constant & memory will automatically be recreated on first access.
    void Cleanup();
    void CleanupMemory();

    /// *** Script APIs ***
    void TransitionToSnapshot(const PPtr<AudioMixerSnapshot>& snapshot, float timeToReachState);
    void SetWeightedMix(SnapshotList& snapshots, float* weights, float timeToReachState);

    void SetCurrentSnapshot(const PPtr<AudioMixerSnapshot>& snapshot);
    virtual void UpdateCurrentSnapshot(const PPtr<AudioMixerSnapshot>& snapshot) {}


    void SetUpdateMode(AudioMixerUpdateMode mode) { m_UpdateMode = mode; }
    AudioMixerUpdateMode GetUpdateMode() const { return m_UpdateMode; }

    // Set an exposed property float
    virtual bool SetFloat(const char* name, float value);
    virtual bool ClearFloat(const char* name);
    bool GetFloat(const char* name, float* value);

    // Called from AudioManager
    void Update(float deltaTime);

    /// *** Live editor connection ***
    bool PatchLiveLinkValue(UInt32 snapshotIndex, UInt32  snapshotParameterIndex, float value);
    int GetGroupVUInfo(const UnityGUID& guid, bool fader, audio::mixer::VUInfo* vuInfo);
    void ReassignAllChannelGroups();
    void UpdateMuteSolo();
    void UpdateBypass();
    void SetupGroups();

    void ResumeProcessing();
    bool IsSuspended();

    virtual void AwakeFromLoad(AwakeFromLoadMode awakeMode);

    FMOD::ChannelGroup* GetFMODChannelGroup(const UnityGUID& guid);

    void GetGroupGUIDsContainingSubString(const char* subString, std::vector<UnityGUID>& guids);
    void FindGroupsWithPartialPath(const char* subString, GroupList& groups);

    PPtr<AudioMixerSnapshot> FindSnapshotFromName(const char* name);

    core::string GetGroupNameFromGUID(const UnityGUID& guid);
    core::string GetGroupPathFromGUID(const UnityGUID& guid);

    virtual bool AllowSnapshotTransitionsFromAPI() const { return true; } // Overridden by AudioMixerController
    virtual void OnEditingInPlayModeChanged() {}

    UInt32 GetSnapshotIndex(const AudioMixerSnapshot& snapshot);
    virtual UInt32 GetInitialSnapshotIndex();

    void SetOutputAudioMixerGroup(const PPtr<AudioMixerGroup>& group);
    PPtr<AudioMixerGroup> GetOutputAudioMixerGroup() const {return m_OutputGroup; }

    static bool CheckForCyclicReferences(AudioMixer* mixer, AudioMixerGroup* group);

protected:
    void SetMixerConstant(audio::mixer::AudioMixerConstant* data) { m_MixerConstant = data; }
    audio::mixer::AudioMixerConstant* GetMixerConstant() const { return m_MixerConstant; }
    audio::mixer::AudioMixerMemory* GetMixerMemory() const { return m_MixerMemory; }

    virtual void OnRuntimeChanged() {}
    virtual void OnEnterPlayModePreStart();
    virtual void OnExitPlayMode();

    bool EnsureValidConstant();
    bool EnsureValidRuntime();
    virtual audio::mixer::AudioMixerConstant* BuildMixerConstant() { return NULL; }

    mecanim::memory::MecanimAllocator  m_Alloc;

protected:
    PPtr<AudioMixerGroup>              m_MasterGroup;
    SnapshotList                       m_Snapshots;
    PPtr<AudioMixerSnapshot>           m_StartSnapshot;


private:
    audio::mixer::AudioMixerConstant*  m_MixerConstant;
    audio::mixer::AudioMixerMemory*    m_MixerMemory;

    ListNode<AudioMixer>               m_Node;

    PPtr<AudioMixerGroup>              m_OutputGroup;

    float                              m_SuspendThreshold;
    bool                               m_EnableSuspend;
    AudioMixerUpdateMode               m_UpdateMode;///< enum { Normal = 0, UnscaledTime = 1 }

    friend class AudioManager;
};
