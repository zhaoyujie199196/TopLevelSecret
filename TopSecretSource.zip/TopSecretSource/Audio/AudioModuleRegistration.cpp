#include "UnityPrefix.h"
#if ENABLE_AUDIO
#include "Runtime/Modules/ModuleRegistration.h"
#include "Runtime/BaseClasses/ClassRegistration.h"
#include "Runtime/Interfaces/IAudio.h"

#define UNITY_MODULE_NAME    Audio
#define UNITY_MODULE_STRIPPABLE
#define UNITY_MODULE_INCLUDE "Runtime/Audio/AudioModule.inc.h"
    #include "Runtime/Modules/ModuleTemplate.inc.h"
#undef UNITY_MODULE_NAME
#undef UNITY_MODULE_INCLUDE

extern void InitializeAudioModule();
extern void CleanupAudioModule();

UNITY_MODULE_INITIALIZE(Audio)
{
    InitializeAudioModule();
}

UNITY_MODULE_CLEANUP(Audio)
{
    CleanupAudioModule();
}

#endif //ENABLE_AUDIO
