#include "UnityPrefix.h"
#include "AudioListener.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Input/TimeManager.h"
#include "Runtime/BaseClasses/IsPlaying.h"
#include "Runtime/BaseClasses/MessageHandlerRegistration.h"
#include "AudioSourceFilter.h"
#include "AudioCustomFilter.h"
#include "AudioLowPassFilter.h"
#include "Runtime/Misc/BuildSettings.h"
#include "Runtime/Mono/MonoBehaviour.h"

AudioListener::AudioListener(MemLabelId label, ObjectCreationMode mode)
    :   Super(label, mode)
    ,   m_LastPosition(Vector3f(0, 0, 0))
    ,   m_Velocity(Vector3f(0, 0, 0))
    ,   m_VelocityUpdateMode(kVelocityUpdateModeAuto)
    ,   m_InverseMatrix(Matrix4x4f::kIdentity)
    ,   m_Node(this)
{
}

void AudioListener::ThreadedCleanup()
{
    Assert(!m_Node.IsInList());
}

void AudioListener::Cleanup()
{
    const GameObject* go = GetGameObjectPtr();
    if (!go)
        return;
    for (int i = 0; i < go->GetComponentCount(); i++)
    {
        AudioFilter* filter = dynamic_pptr_cast<AudioFilter*>(&go->GetComponentAtIndex(i));
        if (filter != NULL)
            filter->Cleanup();
        else
        {
            MonoBehaviour* behaviour = dynamic_pptr_cast<MonoBehaviour*>(&go->GetComponentAtIndex(i));
            if (behaviour)
            {
                AudioCustomFilter* filter = behaviour->GetAudioCustomFilter();
                if (filter)
                    filter->Cleanup();
            }
        }
    }
}

void AudioListener::RemoveFromManager()
{
    GetAudioManager().RemoveAudioListener(this);
}

void AudioListener::AddToManager()
{
    m_LastPosition = GetCurrentTransform().GetPosition();
    GetAudioManager().AddAudioListener(this);
    ApplyFilters();
    DoUpdate(); // Need to initialize values that may be queried by AudioSource for spatialization
}

void AudioListener::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);
}

void AudioListener::SetAlternativeTransform(Transform* t)
{
    m_AltTransform = t;
}

const Transform& AudioListener::GetCurrentTransform() const
{
#if UNITY_EDITOR
    if (!IsWorldPlaying())
    {
        Transform* altTransform = m_AltTransform;
        if (altTransform)
            return *altTransform;
    }
#endif
    return GetComponent<Transform>();
}

void AudioListener::DoUpdate()
{
    const Transform& transform = GetCurrentTransform();
    const Vector3f pos = transform.GetPosition();

    m_InverseMatrix = transform.GetWorldToLocalMatrix();

    //FIXME: Refactor this to go through the AudioMixer instead of directly on the
    //MasterChannelGroup.
    m_Velocity = (pos - m_LastPosition) * GetInvDeltaTime();
    GetAudioManager().UpdateListener(
        pos,
        m_Velocity,
        NormalizeSafe(transform.TransformDirection(Vector3f(0.0f, 1.0f, 0.0f))),
        NormalizeSafe(transform.TransformDirection(Vector3f(0.0f, 0.0f, 1.0f)))
        );
    m_LastPosition = pos;

    AudioLowPassFilter* lowPassFilter = QueryComponent<AudioLowPassFilter>();
    if (lowPassFilter != NULL)
    {
        lowPassFilter->SetCutoffFrequencyInternal(lowPassFilter->GetCutoffFrequency());
    }
}

void AudioListener::Update()
{
    if (m_VelocityUpdateMode == kVelocityUpdateModeAuto)
        m_VelocityUpdateMode = GetAudioManager().GetAutomaticUpdateMode(GetGameObjectPtr());

    if (m_VelocityUpdateMode == kVelocityUpdateModeDynamic)
        DoUpdate();
}

void AudioListener::FixedUpdate()
{
    if (m_VelocityUpdateMode == kVelocityUpdateModeAuto)
        m_VelocityUpdateMode = GetAudioManager().GetAutomaticUpdateMode(GetGameObjectPtr());

    if (m_VelocityUpdateMode == kVelocityUpdateModeFixed)
        DoUpdate();
}

// Apply filters
void AudioListener::ApplyFilters()
{
    const GameObject& go = GetGameObject();
    for (int i = 0; i < go.GetComponentCount(); i++)
    {
        FMOD::DSP* dsp = NULL;

        AudioFilter* filter = NULL;
        filter = dynamic_pptr_cast<AudioFilter*>(&go.GetComponentAtIndex(i));
        if (filter)
            dsp = filter->GetDSP();

        if (!dsp)
        {
            MonoBehaviour* behaviour = dynamic_pptr_cast<MonoBehaviour*>(&go.GetComponentAtIndex(i));
            if (behaviour)
                dsp = behaviour->GetOrCreateDSP();
        }

        if (dsp == NULL)
            continue;

        AudioCustomFilter* customFilter = NULL;
        dsp->getUserData((void**)&customFilter);
        if (customFilter)
        {
            if (customFilter->GetPlayingSource())
            {
                WarningStringObject(Format("GameObject has both an AudioSource and an AudioListener attached. While built-in filters like lowpass are instantiated separately, the custom script DSP filter components may only be used by either the AudioSource or AudioListener at a time. In this case it was attached to the AudioListener first, so it remains connected to this."), this);
                continue;
            }
            else
                customFilter->SetPlayingListener(this);
        }

        CheckFMODError(dsp->remove());
        CheckFMODError(GetAudioManager().GetChannelGroup_FX_IgnoreVolume()->addDSP(dsp, 0));
    }
}

void AudioListener::OnAddComponent()
{
    ApplyFilters();
}

void AudioListener::InitializeClass()
{
    REGISTER_MESSAGE_VOID(kDidAddComponent, OnAddComponent);
}

void AudioListener::CleanupClass()
{
}

template<class TransferFunc>
void AudioListener::Transfer(TransferFunc& transfer)
{
    Super::Transfer(transfer);
}

IMPLEMENT_REGISTER_CLASS(AudioListener, 81);
IMPLEMENT_OBJECT_SERIALIZE(AudioListener);
