#include "UnityPrefix.h"
#include "AudioSourceFilter.h"

IMPLEMENT_REGISTER_CLASS(AudioFilter, 181);
IMPLEMENT_OBJECT_SERIALIZE(AudioFilter);
INSTANTIATE_TEMPLATE_TRANSFER(AudioFilter);

MemLabelRootId* gAudioSourceFilterRootContainer = NULL;

static void StaticInitializeAudioSourceFilterRoot(void*)
{
    gAudioSourceFilterRootContainer = UNITY_NEW_AS_ROOT(MemLabelRootId, kMemAudio, "AudioSource filters", "") ();
}

static void StaticDestroyAudioSourceFilterRoot(void*)
{
    UNITY_DELETE(gAudioSourceFilterRootContainer, kMemAudio);
}

static RegisterRuntimeInitializeAndCleanup s_AudioSourceFilterRootCallbacks(StaticInitializeAudioSourceFilterRoot, StaticDestroyAudioSourceFilterRoot);

void AudioFilter::ThreadedCleanup()
{
}

void AudioFilter::MainThreadCleanup()
{
    Cleanup();
    Super::MainThreadCleanup();
}

void AudioFilter::Cleanup()
{
    if (m_DSP)
    {
        m_DSP->release();
        m_DSP = NULL;
    }
}

void AudioFilter::AddToManager()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;
    if (!m_DSP)
        Init();
    Update();
    Assert(m_DSP);
    Assert(m_Type != FMOD_DSP_TYPE_UNKNOWN);
    m_DSP->setBypass(false);
}

void AudioFilter::RemoveFromManager()
{
    if (m_DSP)
        m_DSP->setBypass(true);
}

void AudioFilter::AwakeFromLoad(AwakeFromLoadMode mode)
{
    Super::AwakeFromLoad(mode);
    Update();
}

void AudioFilter::Init()
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
        return;
    if (m_DSP == NULL && m_Type != FMOD_DSP_TYPE_FORCEINT)
    {
        SET_ALLOC_OWNER(gAudioSourceFilterRootContainer);
        FMOD_RESULT result = GetAudioManager().GetFMODSystem()->createDSPByType(m_Type, &m_DSP);
        Assert(result == FMOD_OK);
        result = m_DSP->setBypass(!GetEnabled());
        Assert(result == FMOD_OK);
    }
}

FMOD::DSP* AudioFilter::GetDSP()
{
    if (!m_DSP)
        Init();
    return m_DSP;
}

template<class TransferFunction>
void AudioFilter::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);
}
