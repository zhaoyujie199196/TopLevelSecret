#ifndef __AUDIODISTORTION_FILTER_H__
#define __AUDIODISTORTION_FILTER_H__

#include "AudioSourceFilter.h"

class AudioDistortionFilter : public AudioFilter
{
    REGISTER_CLASS(AudioDistortionFilter);
    DECLARE_OBJECT_SERIALIZE();
public:
    AudioDistortionFilter(MemLabelId label, ObjectCreationMode mode);

    virtual void CheckConsistency();
    virtual void Update();
    virtual void AddToManager();
    virtual void Reset();

    float GetDistortionLevel() const { return m_DistortionLevel; }
    void SetDistortionLevel(const float distortionLevel) { m_DistortionLevel = distortionLevel; Update(); SetDirty(); }

private:
    float m_DistortionLevel; // Distortion value. 0.0 to 1.0. Default = 0.5.
};

#endif // AUDIODISTORTION
