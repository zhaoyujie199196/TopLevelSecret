#include "UnityPrefix.h"
#include "AudioMixerSnapshot.h"
#include "AudioMixer.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"


AudioMixerSnapshot::AudioMixerSnapshot(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
{
}

void AudioMixerSnapshot::ThreadedCleanup()
{
}

template<class TransferFunction>
void AudioMixerSnapshot::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);

    TRANSFER(m_AudioMixer);
    TRANSFER(m_SnapshotID);
}

void AudioMixerSnapshot::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);

    //When we create or instantiate this class then set up the GUID
    if (awakeMode & kInstantiateOrCreateFromCodeAwakeFromLoad)
    {
#if UNITY_HAVE_GUID_INIT
        m_SnapshotID.Init();
#endif // UNITY_HAVE_GUID_INIT
    }
}

IMPLEMENT_REGISTER_CLASS(AudioMixerSnapshot, 272);
IMPLEMENT_OBJECT_SERIALIZE(AudioMixerSnapshot);
INSTANTIATE_TEMPLATE_TRANSFER(AudioMixerSnapshot);
