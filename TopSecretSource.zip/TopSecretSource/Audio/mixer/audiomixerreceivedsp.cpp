#include "UnityPrefix.h"
#include "audiomixerreceivedsp.h"
#include "audiomixerruntime.h"

UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMixerReceiveProcessCallback(UnityAudioEffectState* state, float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int outchannels)
{
    Assert(state->effectdata != 0);
    Assert(state->internal != 0);
    Assert(inchannels == outchannels);

    float* sideChain = state->sidechainbuffer;

    Assert(sideChain && "Sidechain buffer missing in Receive");

    length *= inchannels;
    for (int n = 0; n < length; n++)
        outbuffer[n] = inbuffer[n] + sideChain[n];

    return UNITY_AUDIODSP_OK;
}
