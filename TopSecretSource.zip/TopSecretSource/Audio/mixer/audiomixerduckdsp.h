#include "Runtime/Audio/AudioPluginInterface.h"

UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMixerDuckingCreateCallback(UnityAudioEffectState* state);
UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMixerDuckingDestroyCallback(UnityAudioEffectState* state);

UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMixerDuckingSetParameterCallback(UnityAudioEffectState* state, int index, float value);
UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMixerDuckingGetFloatBufferCallback(UnityAudioEffectState* state, const char* name, float* buffer, int numsamples);
UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMixerDuckingProcessCallback(UnityAudioEffectState* state, float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int outchannels);
