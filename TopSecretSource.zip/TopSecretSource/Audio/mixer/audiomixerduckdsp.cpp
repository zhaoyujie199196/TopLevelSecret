#include "UnityPrefix.h"
#include "audiomixerduckdsp.h"
#include "audiomixerruntime.h"

//Parameters used within the Ducking System
struct DuckVolumeParameters
{
    union
    {
        struct
        {
            float duckEnvelope;
            float duckGain;
            float duckThreshold;
            float duckRatio;
            float duckAttackTime;
            float duckReleaseTime;
            float duckMakeupGain;
            float duckKnee;
            float duckSidechainMix;
        };
        unsigned char padding[64];
    };
};

#include "Runtime/Math/Simd/vec-quat.h"
#include "Runtime/Math/Simd/vec-scalar.h"
#include "Runtime/Math/Simd/vec-math.h"

// Cannot use the one defined in AudioManager here, since this code needs to be compiled for SPU
static inline float AudioDuckingGetTimeConstant(float accuracy, float numSamples)
{
    /*
     Derivation of time constant from transition length specified as numSamples and desired accuracy within which target is reached:

     y(n) = y(n-1) + [x(n) - y(n-1)] * alpha
     y(0) = 1, x(n) = 0   =>
     y(1) = 1 + [0 - 1] * alpha = 1-alpha
     y(2) = 1-alpha + [0 - (1-alpha)] * alpha = (1-alpha)*(1-alpha) = (1-alpha)^2
     y(3) = (1-alpha)^2 + [0 - (1-alpha)^2] * alpha = (1-alpha) * (1-alpha)^2 = (1-alpha)^3
     ...
     y(n) = (1-alpha)^n = 1-accuracy   =>
     1-alpha = (1-accuracy)^(1/n)
     alpha = 1 - (1-accuracy)^(1/n)
     */
    if (numSamples <= 0.0f)
        return 1.0f;
    return 1.0f - std::pow(1.0f - accuracy, 1.0f / numSamples);
}

static const float kDuckMeteringAccuracy =   0.99f;


UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMixerDuckingCreateCallback(UnityAudioEffectState* state)
{
    Assert(state->effectdata != 0);
    Assert(state->internal != 0);
    DuckVolumeParameters* params = UNITY_NEW(DuckVolumeParameters, kMemAudio);
    state->effectdata = (void*)params;
    memset(state->effectdata, 0, sizeof(DuckVolumeParameters));

    return UNITY_AUDIODSP_OK;
}

UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMixerDuckingDestroyCallback(UnityAudioEffectState* state)
{
    Assert(state->effectdata != 0);
    Assert(state->internal != 0);
    DuckVolumeParameters* params = (DuckVolumeParameters*)state->effectdata;

    UNITY_DELETE(params, kMemAudio);
    state->effectdata = 0;

    return UNITY_AUDIODSP_OK;
}

UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMixerDuckingSetParameterCallback(UnityAudioEffectState* state, int index, float value)
{
    Assert(state->effectdata != 0);
    Assert(state->internal != 0);
    DuckVolumeParameters* params = (DuckVolumeParameters*)state->effectdata;
    if (params)
    {
        switch (index)
        {
            case 0: params->duckThreshold = value; break;
            case 1: params->duckRatio = value; break;
            case 2: params->duckAttackTime = value; break;
            case 3: params->duckReleaseTime = value; break;
            case 4: params->duckMakeupGain = value; break;
            case 5: params->duckKnee = value; break;
            case 6: params->duckSidechainMix = value; break;
            default: break;
        }
    }

    return UNITY_AUDIODSP_OK;
}

UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMixerDuckingGetFloatBufferCallback(UnityAudioEffectState* state, const char* name, float* buffer, int numsamples)
{
    Assert(state->effectdata != 0);
    Assert(state->internal != 0);
    DuckVolumeParameters* params = (DuckVolumeParameters*)state->effectdata;

    buffer[0] = 10.0f * log10f(params->duckEnvelope); // Multiply by 10 because envelope is an RMS signal
    buffer[1] = 20.0f * log10f(params->duckGain);

    return UNITY_AUDIODSP_OK;
}

UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMixerDuckingProcessCallback(UnityAudioEffectState* state, float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int outchannels)
{
    Assert(state->effectdata != 0);
    Assert(state->internal != 0);
    Assert(inchannels == outchannels);

    Assert(state->effectdata != 0);
    DuckVolumeParameters* params = (DuckVolumeParameters*)state->effectdata;

    float* sideChain = state->sidechainbuffer;

    Assert(sideChain && "Sidechain buffer missing in DuckVolume effect");

    float duckAttackTimeConstant = AudioDuckingGetTimeConstant(kDuckMeteringAccuracy, params->duckAttackTime * state->samplerate * inchannels);
    float duckReleaseTimeConstant = AudioDuckingGetTimeConstant(kDuckMeteringAccuracy, params->duckReleaseTime * state->samplerate * inchannels);
    float duckMakeupGain = std::pow(10.0f, 0.05f * params->duckMakeupGain);
    float duckGradient = 0.5f * ((1.0f / params->duckRatio) - 1.0f);
    float duckGradientKnee = duckGradient * 0.025f / ((params->duckKnee > 0.0f) ? params->duckKnee : 1.0f);
    float duckThreshold = std::pow(10.0f, -0.1f * params->duckThreshold);
    float duckKneeCmp1 = std::pow(10.0f, -0.1f * params->duckKnee);
    float duckKneeCmp2 = 1.0f / duckKneeCmp1;

    length *= inchannels;
    for (int n = 0; n < length; n++)
    {
        float gain = duckMakeupGain;
        float x = inbuffer[n];
        float s = x + (sideChain[n] - x) * params->duckSidechainMix;
        s = s * s + 1.0e-11f;
        float timeConst = (s > params->duckEnvelope) ? duckAttackTimeConstant : duckReleaseTimeConstant;
        params->duckEnvelope += (s - params->duckEnvelope) * timeConst + 1.0e-16f; // add small constant to always positive number to avoid denormal numbers
        float t = params->duckEnvelope * duckThreshold;
        if (t >= duckKneeCmp1)
        {
            if (t < duckKneeCmp2)
            {
                t = 10.0f * std::log10(t) + params->duckKnee;
                gain *= std::pow(10.0f, duckGradientKnee * t * t);
            }
            else
                gain *= std::pow(t, duckGradient);
        }
        params->duckGain = gain;
        outbuffer[n] = x * gain;
    }


    return UNITY_AUDIODSP_OK;
}
