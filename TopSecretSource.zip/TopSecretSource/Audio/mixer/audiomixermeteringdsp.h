// Be careful when editing this file -- it's compiled both for the CPUs and the PS3 SPU

#pragma once

#include "Runtime/Math/Simd/vec-quat.h"
#include "Runtime/Math/Simd/vec-scalar.h"
#include "Runtime/Math/Simd/vec-math.h"
#include "Runtime/Audio/correct_fmod_includer.h"
#include "Runtime/Utilities/StaticAssert.h"
#include "Runtime/Audio/AudioPluginInterface.h"

static const float kClipThreshold = 0.99f;

// Calculates separate RMS values for VU and ducking.
// The reason for this is that VU envelopes are much more smooth than ducking envelopes in that VU's fall to 1% or -20 dB (RMS) of the original value over 0.3 seconds, while
// ducking attack and release times can be much smaller than that for explosion sounds. However we also need to take into account that the ducking values should be smoothed according to the minimal expected
// frame rate. In this case we expect it to be 30 FPS, yielding a resampling of the ducking envelope at jittered intervals of 33 ms. It is this resampled envelope which gets then further smoothed according
// to the ducking time constants specified on the target group. This allows the same pre-filtered ducking signal to be post-filtered differently by multiple duck targets.
struct LevelDetectorChannel
{
    float                currPeak, maxPeak;
    float                currRMS, maxRMS;
    int                  holdSamplesLeftPeak;
    int                  holdSamplesLeftRMS;
};

struct ChannelGroupData
{
    enum
    {
        ApplyAttenuation = 1,
        EnableMetering   = 2,
        EnableSuspend    = 4,
    };

    static const int kMaxMeteringChannels = 8;
    static const int kGlobalMeteringChannel = kMaxMeteringChannels; // global metering channel comes after the regular channels
    struct Data
    {
        float                mixLevel; // Attenuation level
        float                prevMixLevel; // For ramping

        // Data read and written by the general metering code used for both VUs and ducking master
        float                vuMeasureTimeConstRMS;
        float                vuMeasureTimeConstPeak;
        float                peakDetectTimeConstant;
        float                suspendRMS;
        int                  peakHoldSamples;
        int                  flags;
        int                  resumeGracePeriodSamplesLeft;
        LevelDetectorChannel levelDetector[kMaxMeteringChannels + 1];   // one extra channel for global metering
    };

    union
    {
        Data data;
        unsigned char pad[(sizeof(Data) + 15) & ~15]; // Padding for PS3 SPU
    };

    inline Data* operator->() { return &data; }

    float GetMeasuredVULevel(int index) const;
    float GetMeasuredPeakLevel(int index) const;
};

UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMixerFaderProcessCallback(UnityAudioEffectState* state, float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int outchannels);
