// Be careful when editing this file -- it's compiled both for the CPUs and the PS3 SPU
// The functions have to be statically forced inlined so we are sure that only one function is emitted which does the work for the SPU callback.
// Hence the fader and head callbacks are implemented using the same function.

#include "UnityPrefix.h"
#include "Runtime/Audio/AudioPluginInterface.h"

#   include "Runtime/Audio/AudioManager.h"
#   include "audiomixermeteringdsp.h"

#include "Runtime/Math/Simd/vec-quat.h"
#include "Runtime/Math/Simd/vec-scalar.h"
#include "Runtime/Math/Simd/vec-math.h"

UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMixerFaderProcessCallback(UnityAudioEffectState* state, float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int outchannels)
{
    Assert(state->effectdata != 0);
    Assert(state->internal != 0);
    Assert(inchannels == outchannels);

    ChannelGroupData::Data* data = (ChannelGroupData::Data*)state->effectdata;

    if ((data->flags & ChannelGroupData::ApplyAttenuation) && fabsf(data->mixLevel - 1.0f) >= 0.001f)
    {
        const float* src = inbuffer;
        float* dst = outbuffer;
        float mixLevel = data->prevMixLevel;
        float mixDelta = (data->mixLevel - data->prevMixLevel) / (float)length;
        for (int n = 0; n < length; n++)
        {
            for (int i = 0; i < outchannels; i++)
                *dst++ = (*src++) * mixLevel;
            mixLevel += mixDelta;
        }
        data->prevMixLevel = mixLevel;
    }
    else if (outbuffer != inbuffer)
    {
        std::memcpy(outbuffer, inbuffer, sizeof(float) * length * outchannels);
    }

    if (data->flags & ChannelGroupData::EnableMetering)
    {
        // limit the number of metered channels to the space we have storage for in LevelDetectorChannel
        int numMeteringChannels = (outchannels > ChannelGroupData::kMaxMeteringChannels) ? ChannelGroupData::kMaxMeteringChannels : outchannels;

        // RMS metering
        float* src = outbuffer;
        for (int n = 0; n < length; n++)
        {
            float globalCurrRMS = 0.0f;
            float globalMaxRMS = 0.0f;
            for (int i = 0; i < numMeteringChannels; i++)
            {
                LevelDetectorChannel& ch = data->levelDetector[i];
                float input = *src++;
                ch.currRMS += (input * input - ch.currRMS) * data->vuMeasureTimeConstRMS + 1.0e-16f; // add small constant to always positive number to avoid denormal numbers
                if (ch.currRMS > ch.maxRMS)
                {
                    ch.maxRMS = ch.currRMS;
                    ch.holdSamplesLeftRMS = data->peakHoldSamples;
                }
                else if (--ch.holdSamplesLeftRMS < 0)
                    ch.maxRMS = ch.maxRMS * data->peakDetectTimeConstant + 1.0e-16f;
                globalCurrRMS = math::max(globalCurrRMS, ch.currRMS);
                globalMaxRMS = math::max(globalMaxRMS, ch.maxRMS);
            }
            LevelDetectorChannel& ch = data->levelDetector[ChannelGroupData::kGlobalMeteringChannel];
            ch.currRMS = globalCurrRMS;
            ch.maxRMS = globalMaxRMS;
        }

        // Peak metering
        src = outbuffer;
        for (int n = 0; n < length; n++)
        {
            float globalCurrPeak = 0.0f;
            float globalMaxPeak = 0.0f;
            for (int i = 0; i < numMeteringChannels; i++)
            {
                LevelDetectorChannel& ch = data->levelDetector[i];
                float input = *src++;
                float a = math::abs(input);
                if (a >= ch.currPeak)
                    ch.currPeak = a;
                else
                    ch.currPeak = ch.currPeak * data->vuMeasureTimeConstPeak + 1.0e-16f; // add small constant to always positive number to avoid denormal numbers
                if (ch.currPeak > ch.maxPeak)
                {
                    ch.maxPeak = ch.currPeak;
                    ch.holdSamplesLeftPeak = data->peakHoldSamples;
                }
                else if (--ch.holdSamplesLeftPeak < 0)
                    ch.maxPeak = ch.maxPeak * data->peakDetectTimeConstant + 1.0e-16f;
                globalCurrPeak = math::max(globalCurrPeak, ch.currPeak);
                globalMaxPeak = math::max(globalMaxPeak, ch.maxPeak);
            }
            LevelDetectorChannel& ch = data->levelDetector[ChannelGroupData::kGlobalMeteringChannel];
            ch.currPeak = globalCurrPeak;
            ch.maxPeak = globalMaxPeak;
        }
    }

    if (data->flags & ChannelGroupData::EnableSuspend)
    {
        float* src = outbuffer;
        for (int n = 0; n < length; n++)
        {
            float input = 0.0f;
            for (int i = 0; i < outchannels; i++)
                input = math::max(input, fabsf(*src++));
            data->suspendRMS += (input * input - data->suspendRMS) * data->vuMeasureTimeConstRMS + 1.0e-16f; // add small constant to always positive number to avoid denormal numbers
        }
        if (data->resumeGracePeriodSamplesLeft > 0)
        {
            data->resumeGracePeriodSamplesLeft -= length;
            if (data->resumeGracePeriodSamplesLeft < 0)
                data->resumeGracePeriodSamplesLeft = 0;
        }
    }

    return FMOD_OK;
}

float ChannelGroupData::GetMeasuredVULevel(int index) const
{
#if UNITY_EDITOR
    if (!GetAudioManager().IsUsingRMSMetering())
        return data.levelDetector[index].currPeak;
#endif
    return math::sqrt(data.levelDetector[index].currRMS);
}

float ChannelGroupData::GetMeasuredPeakLevel(int index) const
{
#if UNITY_EDITOR
    if (!GetAudioManager().IsUsingRMSMetering())
        return data.levelDetector[index].maxPeak;
#endif
    return math::sqrt(data.levelDetector[index].maxRMS);
}
