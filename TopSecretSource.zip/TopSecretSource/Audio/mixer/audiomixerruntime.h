#pragma once

#include "Runtime/Serialize/SerializeUtility.h"
#include "Runtime/Serialize/Blobification/offsetptr.h"

struct UnityGUID;
namespace FMOD
{
    class DSP;
    class DSPConnection;
    class System;
    class ChannelGroup;
}

namespace audio
{
namespace mixer
{
    struct EffectMemory
    {
        union
        {
            struct
            {
                FMOD::DSP*           dsp;
                FMOD::DSPConnection* wetCon;
                FMOD::DSPConnection* dryCon;
                float                wet;
                float                prevWet; // Currently only used (and updated) by send effect for ramping to avoid clicks.
                float*               sideChainBuffer; //For the cases where side chain buffers are required.
            };
            unsigned char padding[32];      // Needs to be multiple of 16 bytes / 16 byte aligned for PS3 SPU DMA
        };
    };

    static const float UNINITIALIZED_SNAPSHOT = -std::numeric_limits<float>::infinity();

    struct AudioMixerConstant;
    struct AudioMixerMemory;

    struct VUInfo;

    void DestroyAudioMixerMemory(AudioMixerMemory* memory, const AudioMixerConstant& constant, FMOD::System* system, mecanim::memory::Allocator& alloc);
    void DestroyAudioMixerConstant(AudioMixerConstant* constant, mecanim::memory::Allocator& alloc);

    AudioMixerMemory* CreateAudioMixerMemory(const AudioMixerConstant& constant, FMOD::System* system, mecanim::memory::Allocator& alloc, int snapshotIndex, bool enableSuspend);
    void UpdateAudioMixerMemory(const AudioMixerConstant& constant, AudioMixerMemory& memory, float deltaTime, FMOD::System* system, float suspendThreshold);
    void SetSuspended(AudioMixerMemory& memory, bool state);
    bool IsSuspended(const AudioMixerMemory& memory);

    bool ValidateSnapshotIndex(AudioMixerConstant& constant, int targetSnapshotIndex);
    int GetSnapshotIndex(AudioMixerConstant& constant, const char* name);
    void TransitionToSnapshot(AudioMixerMemory& memory, int targetSnapshotIndex, float timeToReachState);
    void SetWeightedMix(const AudioMixerConstant& constant, AudioMixerMemory& memory, int* indices, float* weights, int numWeights, float timeToReachState);

    int GetGroupVUInfo(const AudioMixerConstant& constant, const AudioMixerMemory& memory, const UnityGUID& guid, bool fader, audio::mixer::VUInfo* vuInfo);
    void UpdateBypass(AudioMixerConstant& constant, AudioMixerMemory& memory);
    void SetResultingMuteState(const AudioMixerConstant& constant, const AudioMixerMemory& memory, int index, bool muted);
    float GetLiveValue(AudioMixerMemory& memory, int snapshotParameterIndex);

    int GetExposedPropertyIndex(const AudioMixerConstant& constant, const char* name);
    void SetExposedProperty(const AudioMixerMemory& memory, int index, float value);
    void ClearExposedProperty(const AudioMixerMemory& memory, int index);
    float GetExposedPropertyValue(const AudioMixerMemory& memory, int index);

    int FindGroupIndex(const AudioMixerConstant& constant, const UnityGUID& guid);
    int FindEffectIndex(const AudioMixerConstant& constant, const UnityGUID& guid);
    FMOD::ChannelGroup* FindChannelGroup(const AudioMixerConstant& constant, const AudioMixerMemory& memory, const UnityGUID& guid);
    void AssignOutputGroup(const AudioMixerConstant& constant, const AudioMixerMemory& memory, FMOD::ChannelGroup* parent);

    void GetGroupGUIDsContainingSubString(const AudioMixerConstant& constant, const char* subString, std::vector<UnityGUID>& guids);
    const char* GetGroupNameFromGUID(const AudioMixerConstant& constant, const UnityGUID& guid);
    core::string GetGroupPathFromGUID(const AudioMixerConstant& constant, const UnityGUID& guid);

    bool GetFloatBuffer(const AudioMixerConstant& constant, const AudioMixerMemory& memory, const UnityGUID& guid, const char* name, float* data, int numsamples);
    float GetCPUUsage(const AudioMixerConstant& constant, const AudioMixerMemory& memory, const UnityGUID& guid);

    bool CopyExposedParameterValues(const AudioMixerConstant& constant, const AudioMixerMemory& memory, float* values, int valuesCount);
    bool SetExposedParameterValues(const AudioMixerConstant& constant, const float* values, int valuesCount, AudioMixerMemory& memory);
    void ClearExposedParameterValues(const AudioMixerConstant& constant, const AudioMixerMemory& memory);
}
}
