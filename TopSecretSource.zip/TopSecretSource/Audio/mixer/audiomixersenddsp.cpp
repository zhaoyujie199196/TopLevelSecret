#include "UnityPrefix.h"
#include "audiomixersenddsp.h"
#include "audiomixerruntime.h"

UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMixerSendProcessCallback(UnityAudioEffectState* state, float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int outchannels)
{
    Assert(state->effectdata != 0);
    Assert(state->internal != 0);
    Assert(inchannels == outchannels);

    audio::mixer::EffectMemory* effectMem = (audio::mixer::EffectMemory*)state->effectdata;

    length *= inchannels;

    float wetLevel = effectMem->prevWet;
    float wetLevelDelta = (effectMem->wet - effectMem->prevWet) / (float)length;
    float* sideChain = state->sidechainbuffer;

    Assert(sideChain && "Sidechain buffer missing in Send");

    for (int n = 0; n < length; n++)
    {
        float x = inbuffer[n];
        outbuffer[n] = x;
        sideChain[n] += x * wetLevel;
        wetLevel += wetLevelDelta;
    }

    effectMem->prevWet = wetLevel;

    return UNITY_AUDIODSP_OK;
}
