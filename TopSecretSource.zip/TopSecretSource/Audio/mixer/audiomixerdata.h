#pragma once

#include "Runtime/Serialize/SerializeUtility.h"
#include "Runtime/Serialize/Blobification/offsetptr.h"
#include "Runtime/Utilities/GUID.h"

namespace audio
{
namespace mixer
{
    const float kMinVolumeLevel = -80.0f;

    struct VUInfo
    {
        float level[9];
        float peak[9];
    };

    typedef UInt32 NameHash;

    struct SnapshotConstant
    {
        enum TransitionType
        {
            kLerp,
            kSmoothstep,
            kSquared,
            kSquareRoot,
            kBrickwallStart,
            kBrickwallEnd
        };

        DEFINE_GET_TYPESTRING(SnapshotConstant)

        SnapshotConstant()
            : nameHash(0)
            , valueCount(0)
            , defaultTransition(kLerp)
            , transitionCount(0)
        {}

        NameHash                    nameHash;
        UInt32                      valueCount;
        OffsetPtr<float>            values;

        UInt32                      defaultTransition;
        UInt32                      transitionCount;
        OffsetPtr<UInt32>           transitionTypes;
        OffsetPtr<UInt32>           transitionIndices;

        template<class TransferFunction>
        inline void Transfer(TransferFunction& transfer)
        {
            TRANSFER(nameHash);

            TRANSFER_OFFSETPTR(values, valueCount);

            TRANSFER_OFFSETPTR(transitionTypes, transitionCount);
            TRANSFER_OFFSETPTR_MANUAL(transitionIndices, transitionCount);
        }
    };

    struct EffectConstant
    {
        enum UnityEffectType
        {
            kUnknown    = -1,
            kFader      = -2,
            kSend       = -3,
            kReceive    = -4,
            kDuckVolume = -5
        };

        DEFINE_GET_TYPESTRING(EffectConstant)

        EffectConstant()
            : type(kUnknown)
            , groupConstantIndex(-1)
            , sendTargetEffectIndex(-1)
            , wetMixLevelIndex(-1)
            , prevEffectIndex(-1)
            , parameterCount(0)
        {}

        SInt32                type;
        UInt32                groupConstantIndex;
        UInt32                sendTargetEffectIndex;

        UInt32                wetMixLevelIndex;
        UInt32                prevEffectIndex;

        bool                  bypass;

        UInt32                parameterCount;
        OffsetPtr<UInt32>     parameterIndices;

        template<class TransferFunction>
        inline void Transfer(TransferFunction& transfer)
        {
            TRANSFER(type);
            TRANSFER(groupConstantIndex);
            TRANSFER(sendTargetEffectIndex);
            TRANSFER(wetMixLevelIndex);
            TRANSFER(prevEffectIndex);
            TRANSFER(bypass);
            transfer.Align();

            TRANSFER_OFFSETPTR(parameterIndices, parameterCount);
        }
    };

    struct GroupConstant
    {
        DEFINE_GET_TYPESTRING(GroupConstant)

        GroupConstant()
            : parentConstantIndex(-1)
            , volumeIndex(0)
            , pitchIndex(0)
            , mute(false)
            , solo(false)
            , bypassEffects(false)
        {}

        SInt32              parentConstantIndex;

        UInt32              volumeIndex;
        UInt32              pitchIndex;

        bool                mute;
        bool                solo;
        bool                bypassEffects;

        template<class TransferFunction>
        inline void Transfer(TransferFunction& transfer)
        {
            TRANSFER(parentConstantIndex);
            TRANSFER(volumeIndex);
            TRANSFER(pitchIndex);
            TRANSFER(mute);
            TRANSFER(solo);
            TRANSFER(bypassEffects);
            transfer.Align();
        }
    };

    //Flatten the topology, and define relationships via array.
    struct AudioMixerConstant
    {
        DEFINE_GET_TYPESTRING(AudioMixerConstant)

        AudioMixerConstant()
            : groupCount(0)
            , effectCount(0)
            , startSnapshot(0)
            , snapshotCount(0)
            , groupNameBufferLength(0)
            , snapshotNameBufferLength(0)
            , pluginEffectNameBufferLength(0)
            , exposedParameterCount(0)
        {}

        UInt32                        groupCount;
        OffsetPtr<GroupConstant>      groups;
        OffsetPtr<UnityGUID>          groupGUIDs;

        UInt32                        effectCount;
        OffsetPtr<EffectConstant>     effects;
        OffsetPtr<UnityGUID>          effectGUIDs;

        UInt32                        numSideChainBuffers;

        UInt32                        startSnapshot;
        UInt32                        snapshotCount;
        OffsetPtr<SnapshotConstant>   snapshots;
        OffsetPtr<UnityGUID>          snapshotGUIDs;

        UInt32                        groupNameBufferLength;
        OffsetPtr<char>               groupNameBuffer;

        UInt32                        snapshotNameBufferLength;
        OffsetPtr<char>               snapshotNameBuffer;

        UInt32                        pluginEffectNameBufferLength;
        OffsetPtr<char>               pluginEffectNameBuffer;

        UInt32                        exposedParameterCount;
        OffsetPtr<NameHash>           exposedParameterNames;
        OffsetPtr<UInt32>             exposedParameterIndices;

        template<class TransferFunction>
        inline void Transfer(TransferFunction& transfer)
        {
            TRANSFER_OFFSETPTR(groups, groupCount);
            TRANSFER_OFFSETPTR_MANUAL(groupGUIDs, groupCount);

            TRANSFER_OFFSETPTR(effects, effectCount);
            TRANSFER_OFFSETPTR_MANUAL(effectGUIDs, effectCount);

            TRANSFER(numSideChainBuffers);

            TRANSFER_OFFSETPTR(snapshots, snapshotCount);
            TRANSFER_OFFSETPTR_MANUAL(snapshotGUIDs, snapshotCount);

            TRANSFER_OFFSETPTR(groupNameBuffer, groupNameBufferLength);
            transfer.Align();
            TRANSFER_OFFSETPTR(snapshotNameBuffer, snapshotNameBufferLength);
            transfer.Align();
            TRANSFER_OFFSETPTR(pluginEffectNameBuffer, pluginEffectNameBufferLength);
            transfer.Align();

            TRANSFER_OFFSETPTR(exposedParameterNames, exposedParameterCount);
            TRANSFER_OFFSETPTR_MANUAL(exposedParameterIndices, exposedParameterCount);
        }
    };
}
}
