#include "Runtime/Audio/AudioPluginInterface.h"

UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMixerReceiveProcessCallback(UnityAudioEffectState* state, float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int outchannels);
