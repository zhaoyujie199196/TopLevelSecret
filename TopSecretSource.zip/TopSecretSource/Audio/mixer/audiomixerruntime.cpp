#include "UnityPrefix.h"
#include "audiomixerruntime.h"
#include "Runtime/Math/Simd/vec-quat.h"
#include "Runtime/Math/Simd/vec-scalar.h"
#include "Runtime/Math/Simd/vec-math.h"
#include "Runtime/Serialize/SerializeUtility.h"
#include "Runtime/Serialize/Blobification/offsetptr.h"
#include "Runtime/Audio/mixer/audiomixerdata.h"
#include "Runtime/Audio/mixer/audiomixermeteringdsp.h"
#include "Runtime/Audio/correct_fmod_includer.h"
#include "Runtime/mecanim/generic/crc32.h"
#include "Runtime/Utilities/PathNameUtility.h"
#include "Runtime/Audio/AudioManager.h"
#include "Runtime/Audio/AudioEffectInternal.h"
#include "Runtime/Audio/AudioMixer.h"
#include "Runtime/Audio/mixer/audiomixersenddsp.h"
#include "Runtime/Audio/mixer/audiomixerreceivedsp.h"
#include "Runtime/Audio/mixer/audiomixerduckdsp.h"

// Create and connect all effects as bypassed -- PS3 seems to require this, otherwise some of the effects are muted.
#define BYPASS_UNTIL_READY 1

extern float AudioMeasurement_GetTimeConstant(float accuracy, float numSamples);

namespace audio
{
namespace mixer
{
    //TODO FLESH THIS OUT
#define CHECK_FMOD_RETURN(...) do { FMOD_RESULT res = __VA_ARGS__; if(res != FMOD_OK) printf_console("FMOD error in %s line %d: code=%s (%d)\n", __FILE__, __LINE__, FMOD_ErrorString(res), res); Assert(res == FMOD_OK); } while(false)

    // Accuracy within which target values are reached given the specified time
    static const float kVUMeteringAccuracyRMS  =   0.99f;// 99% is the standard in VU RMS metering
    static const float kVUResponseTimeRMS      =   0.30f;// over 300ms
    static const float kVUMeteringAccuracyPeak =   0.90f;// falling 20 dB in standard peak metering
    static const float kVUResponseTimePeak     =   1.70f;// over 1.7s
    static const float kPeakHoldTime           =   2.00f;
    static const float kPeakReleaseSpeed       = -10.00f;// dB/s

    struct TransitionMemory
    {
        size_t   valueCount;

        float*   startingValues;
        float*   currentValues;
        float*   previousValues;
        bool*    changedValues;

        float*   exposedValues;

        float    weight;
        float    timeToReachState;
        float*   weightedMix;
        bool     usingWeightedMix;
        int      targetSnapshotIndex;
    };

    struct AudioMixerMemory
    {
        FMOD::ChannelGroup**      channelGroups;
        FMOD::DSP**               headDSPs;
        ChannelGroupData*         embeddedFaderGroupData;
        ChannelGroupData*         headGroupData;
        EffectMemory*             effects;

        TransitionMemory          transition;

        bool*                     muteState;
        FMOD::ChannelGroup*       muteGroup;

        float*                    sideChainBuffers;

        const AudioMixerConstant* constant;
    };

    static FMOD_DSP_TYPE TranslateEffectType(int type)
    {
        if (type < 0)
        {
            // TODO return internal effects or plugin types?
            return FMOD_DSP_TYPE_MIXER;
        }

        if (type >= 1000)
        {
            // Custom plugin DSP effect
            return FMOD_DSP_TYPE_UNKNOWN;
        }

        // Built-in effect
        return (FMOD_DSP_TYPE)type;
    }

    static inline float DbToLin(float x)
    {
        // This check needs to be kept in sync with the runtime. It serves as a cutoff point at which connections can be cut or effects bypassed.
        if (x <= kMinVolumeLevel)
            return 0.0f;
        return (float)math::powr(math::float1(10.0f), math::float1(x * 0.05f));
    }

    static const char* GetGroupNameFromIndex(const AudioMixerConstant& constant, int index)
    {
        const char* nameBlob = &constant.groupNameBuffer[0];
        for (int i = 0; i < constant.groupCount && i != index; i++)
            nameBlob += strlen(nameBlob) + 1;
        return nameBlob;
    }

    static const char* GetEffectName(const AudioMixerConstant& constant, UInt32 type)
    {
        Assert(type >= 1000);
        type -= 1000;
        const char* effectName = &(constant.pluginEffectNameBuffer[0]);
        while (type > 0)
        {
            effectName += strlen(effectName) + 1;
            type--;
        }
        return effectName;
    }

    AudioEffectInternalDefinition* FindAudioEffectDefinition(const AudioMixerConstant& constant, UInt32 type)
    {
        const char* effectName = GetEffectName(constant, type);
        int numDefs = 0;
        AudioEffectInternalDefinition** defs = GetAudioEffectDefinitions(&numDefs);
        for (int n = 0; n < numDefs; n++)
            if (strcmp(defs[n]->m_desc->m_unity.name, effectName) == 0)
                return defs[n];
        return NULL;
    }

    static void SetupChannelGroupData(ChannelGroupData& data, int sampleRate)
    {
        data->vuMeasureTimeConstRMS = AudioMeasurement_GetTimeConstant(kVUMeteringAccuracyRMS, kVUResponseTimeRMS * sampleRate);
        data->vuMeasureTimeConstPeak = 1.0f - AudioMeasurement_GetTimeConstant(kVUMeteringAccuracyPeak, kVUResponseTimePeak * sampleRate);
        data->peakDetectTimeConstant = (float)math::powr(math::float1(10.0f), math::float1(0.05f * kPeakReleaseSpeed / sampleRate));
        data->peakHoldSamples = (int)(sampleRate * kPeakHoldTime);
    }

    static bool DSPRequiresSidechain(SInt32 type, const AudioMixerConstant& constant)
    {
        //TODO: Clean this up with the effect definition refactor work
        if (type == EffectConstant::kReceive || type == EffectConstant::kDuckVolume)
            return true;

        if (TranslateEffectType(type) == FMOD_DSP_TYPE_UNKNOWN)
        {
            AudioEffectInternalDefinition* definition = FindAudioEffectDefinition(constant, type);
            if (definition != NULL && (definition->m_desc->m_unity.flags & UnityAudioEffectDefinitionFlags_IsSideChainTarget) != 0)
                return true;
        }

        return false;
    }

    AudioMixerMemory* CreateAudioMixerMemory(const AudioMixerConstant& constant, FMOD::System* system, mecanim::memory::Allocator& alloc, int snapshotIndex
        , bool enableSuspend
        )
    {
        Assert(snapshotIndex >= 0 && snapshotIndex < constant.snapshotCount);
        snapshotIndex = clamp<int>(snapshotIndex, 0, constant.snapshotCount - 1);

        //Get number of parameters from first (default) snapshot
        size_t snapshotParameterCount = constant.snapshots[0].valueCount;

        AudioMixerMemory& memory = *alloc.Construct<AudioMixerMemory>();

        memory.embeddedFaderGroupData = alloc.ConstructArray<ChannelGroupData>(constant.groupCount);
        memory.headGroupData = alloc.ConstructArray<ChannelGroupData>(constant.groupCount);

        memory.channelGroups = alloc.ConstructArray<FMOD::ChannelGroup*>(constant.groupCount);
        memory.headDSPs = alloc.ConstructArray<FMOD::DSP*>(constant.groupCount);
        memset(memory.headDSPs, 0, sizeof(FMOD::DSP*) * constant.groupCount);

        memset(memory.embeddedFaderGroupData, 0, sizeof(ChannelGroupData) * constant.groupCount);
        memset(memory.headGroupData, 0, sizeof(ChannelGroupData) * constant.groupCount);

        memory.effects = alloc.ConstructArray<EffectMemory>(constant.effectCount);
        memset(memory.effects, 0, sizeof(EffectMemory) * constant.effectCount);

        memory.muteState = alloc.ConstructArray<bool>(constant.groupCount);
        memset(memory.muteState, 0, sizeof(bool) * constant.groupCount);

        memory.constant = &constant;

        CHECK_FMOD_RETURN(system->createChannelGroup("MuteGroup", &memory.muteGroup));
        CHECK_FMOD_RETURN(memory.muteGroup->setMute(true));

        int sampleRate = 48000;
        int maxSpeakers = 8;
        CHECK_FMOD_RETURN(system->getSoftwareFormat(&sampleRate, NULL, &maxSpeakers, NULL, NULL, NULL));

        unsigned int dspBlockSize = 0;
        CHECK_FMOD_RETURN(system->getDSPBufferSize(&dspBlockSize, NULL));

        // Create groups
        const char* nameBlob = &constant.groupNameBuffer[0];

        // Note that we create callbacks for all groups. This is so, because we need to be sure that all data has been mixed before entering the attenuation block
        // wherever in the signal chain it is located. With the mixer supporting wet/dry mixes which uses a complex DSP connection layout (see below) as well as
        // send/return blocks that can route the signal across groups, we cannot use ChannelGroup::setVolume for this, as this will just traverse the channel groups
        // and delegate the volume level to the channels at the leaf nodes.
        for (int i = 0; i < constant.groupCount; i++)
        {
            FMOD::ChannelGroup* group = NULL;
            if (UNITY_EDITOR != 0 || i == 0) // The root is a special case, as we need the RMS measurement for automatic suspension.
            {
                ChannelGroupData& data = memory.headGroupData[i];
                SetupChannelGroupData(data, sampleRate);
                data->flags |= ChannelGroupData::EnableMetering;
            }
            memory.headGroupData[i]->flags |= ChannelGroupData::ApplyAttenuation;
            CHECK_FMOD_RETURN(system->createChannelGroup(nameBlob, &group));
            memory.channelGroups[i] = group;
            nameBlob += strlen(nameBlob) + 1;
        }

        // Parent master group
        CHECK_FMOD_RETURN(memory.muteGroup->addGroup(memory.channelGroups[0]));

        // Parent groups
        for (int i = 1; i < constant.groupCount; i++)
        {
            int parentIndex = constant.groups[i].parentConstantIndex;
            CHECK_FMOD_RETURN(memory.channelGroups[parentIndex]->addGroup(memory.channelGroups[i]));
        }

        // Allocate sidechain buffers
        UInt32 sideChainBufferSize = dspBlockSize * maxSpeakers;
        memory.sideChainBuffers = alloc.ConstructArray<float>(sideChainBufferSize * constant.numSideChainBuffers);
        memset(memory.sideChainBuffers, 0, sideChainBufferSize * constant.numSideChainBuffers * sizeof(float));
        float* sideChainPtr = memory.sideChainBuffers;

        const float* sideChainBufferEnd = sideChainPtr + constant.numSideChainBuffers * sideChainBufferSize;
        for (int i = 0; i < constant.effectCount; i++)
        {
            const EffectConstant& effectConstant = constant.effects[i];
            if (DSPRequiresSidechain(effectConstant.type, constant))
            {
                memory.effects[i].sideChainBuffer = sideChainPtr;
                sideChainPtr += sideChainBufferSize;
                Assert(sideChainPtr <= sideChainBufferEnd);
            }
        }

        // Create effects
        for (int i = 0; i < constant.effectCount; i++)
        {
            const EffectConstant& effectConstant = constant.effects[i];
            FMOD_DSP_TYPE type = TranslateEffectType(effectConstant.type);

            memory.effects[i].dsp = NULL;


            if (effectConstant.type == EffectConstant::kSend)
            {
                FMOD::ChannelGroup* channelGroup = memory.channelGroups[effectConstant.groupConstantIndex];
                UInt32 sendTargetIndex = effectConstant.sendTargetEffectIndex;
                if (sendTargetIndex == -1 || !memory.effects[sendTargetIndex].sideChainBuffer)
                    continue;

                UnityAudioEffectDefinition effectdef;
                memset(&effectdef, 0, sizeof(effectdef));
                memcpy(effectdef.name, "Send", 5);
                memory.effects[i].sideChainBuffer = memory.effects[sendTargetIndex].sideChainBuffer;

                effectdef.structsize = sizeof(UnityAudioEffectDefinition);
                effectdef.paramstructsize = sizeof(UnityAudioParameterDefinition);

                Assert(memory.effects[i].sideChainBuffer && "Send target sidechain buffer == 0");

                effectdef.process = AudioMixerSendProcessCallback;
                AudioEffectInternalDefinition internalDef(&effectdef, false);
                memory.effects[i].dsp = internalDef.CreateDSP(system, &memory.effects[i], memory.effects[i].sideChainBuffer, NULL);
                Assert(memory.effects[i].dsp != NULL);

#if BYPASS_UNTIL_READY
                CHECK_FMOD_RETURN(memory.effects[i].dsp->setBypass(true));
#endif
                CHECK_FMOD_RETURN(channelGroup->addDSP(memory.effects[i].dsp, NULL));
            }
            else if (effectConstant.type == EffectConstant::kReceive)
            {
                FMOD::ChannelGroup* channelGroup = memory.channelGroups[effectConstant.groupConstantIndex];

                UnityAudioEffectDefinition effectdef;
                memset(&effectdef, 0, sizeof(effectdef));
                memcpy(effectdef.name, "Receive", 8);
                effectdef.structsize = sizeof(UnityAudioEffectDefinition);
                effectdef.paramstructsize = sizeof(UnityAudioParameterDefinition);
                effectdef.flags = UnityAudioEffectDefinitionFlags_IsSideChainTarget; //This is not necessary with the current setup, but will change with proper effect definition handling

                Assert(memory.effects[i].sideChainBuffer && "Receive sidechain buffer == 0");

                effectdef.process = AudioMixerReceiveProcessCallback;
                AudioEffectInternalDefinition internalDef(&effectdef, false);
                memory.effects[i].dsp = internalDef.CreateDSP(system, &memory.effects[i], memory.effects[i].sideChainBuffer, NULL);
                Assert(memory.effects[i].dsp != NULL);

#if BYPASS_UNTIL_READY
                CHECK_FMOD_RETURN(memory.effects[i].dsp->setBypass(true));
#endif
                CHECK_FMOD_RETURN(channelGroup->addDSP(memory.effects[i].dsp, NULL));
            }
            else if (effectConstant.type == EffectConstant::kDuckVolume)
            {
                FMOD::ChannelGroup* channelGroup = memory.channelGroups[effectConstant.groupConstantIndex];

                UnityAudioEffectDefinition effectdef;
                memset(&effectdef, 0, sizeof(effectdef));
                memcpy(effectdef.name, "Duck Volume", 12);
                effectdef.structsize = sizeof(UnityAudioEffectDefinition);
                effectdef.paramstructsize = sizeof(UnityAudioParameterDefinition);
                effectdef.flags = UnityAudioEffectDefinitionFlags_IsSideChainTarget; //This is not necessary with the current setup, but will change with proper effect definition handling

                Assert(memory.effects[i].sideChainBuffer && "Ducking sidechain buffer == 0");

                const int numparams = 7;
                static UnityAudioParameterDefinition paramdefs[numparams] =
                {
                    { "Threshold", "dB", "Sidechain threshold above which ducking is applied", -80.0f, 0.0f, -10.0f, 1.0f, 1.0f },
                    { "Ratio", "%", "Ducking ratio", 0.2f, 10.0f, 2.0f, 1.0f, 1.0f },
                    { "Attack Time", "s", "Attack time for sidechain level detector", 0.0f, 10.0f, 0.1f, 1.0f, 3.0f },
                    { "Release Time", "s", "Release time for sidechain level detector", 0.0f, 10.0f, 0.3f, 1.0f, 3.0f },
                    { "Make-up Gain", "dB", "Make-up gain", -80.0f, 40.0f, 0.0f, 1.0f, 1.0f },
                    { "Knee", "dB", "Sharpness of compression curve knee", 0.0f, 50.0f, 10.0f, 1.0f, 1.0f },
                    { "Sidechain Mix", "%", "Sidechain/source mix. If set to 100% the compressor detects level entirely from sidechain signal.", 0.0f, 1.0f, 1.0f, 100.0f, 1.0f },
                };
                effectdef.structsize = sizeof(effectdef);
                effectdef.paramstructsize = sizeof(UnityAudioParameterDefinition);
                effectdef.create = AudioMixerDuckingCreateCallback;
                effectdef.release = AudioMixerDuckingDestroyCallback;
                effectdef.setfloatparameter = AudioMixerDuckingSetParameterCallback;
                effectdef.getfloatbuffer = AudioMixerDuckingGetFloatBufferCallback;
                effectdef.numparameters = numparams;
                effectdef.paramdefs = paramdefs;
                effectdef.process = AudioMixerDuckingProcessCallback;
                AudioEffectInternalDefinition internalDef(&effectdef, false);
                memory.effects[i].dsp = internalDef.CreateDSP(system, &memory.effects[i], memory.effects[i].sideChainBuffer, NULL);
                Assert(memory.effects[i].dsp != NULL);
#if BYPASS_UNTIL_READY
                CHECK_FMOD_RETURN(memory.effects[i].dsp->setBypass(true));
#endif
                CHECK_FMOD_RETURN(channelGroup->addDSP(memory.effects[i].dsp, NULL));
            }
            else if (effectConstant.type == EffectConstant::kFader)
            {
                FMOD::ChannelGroup* channelGroup = memory.channelGroups[effectConstant.groupConstantIndex];

                UnityAudioEffectDefinition effectdef;
                memset(&effectdef, 0, sizeof(effectdef));
                memcpy(effectdef.name, "EmbeddedFader", 14);
                effectdef.structsize = sizeof(UnityAudioEffectDefinition);
                effectdef.paramstructsize = sizeof(UnityAudioParameterDefinition);

                effectdef.process = AudioMixerFaderProcessCallback;
                AudioEffectInternalDefinition internalDef(&effectdef, false);
                memory.effects[i].dsp = internalDef.CreateDSP(system, &memory.embeddedFaderGroupData[effectConstant.groupConstantIndex], NULL, NULL);
                Assert(memory.effects[i].dsp != NULL);
                SetupChannelGroupData(memory.embeddedFaderGroupData[effectConstant.groupConstantIndex], sampleRate);
                if (UNITY_EDITOR != 0)
                    memory.embeddedFaderGroupData[effectConstant.groupConstantIndex]->flags |= ChannelGroupData::EnableMetering;
                memory.embeddedFaderGroupData[effectConstant.groupConstantIndex]->flags |= ChannelGroupData::ApplyAttenuation;
                memory.headGroupData[effectConstant.groupConstantIndex]->flags &= ~ChannelGroupData::ApplyAttenuation;

#if BYPASS_UNTIL_READY
                CHECK_FMOD_RETURN(memory.effects[i].dsp->setBypass(true));
#endif
                CHECK_FMOD_RETURN(channelGroup->addDSP(memory.effects[i].dsp, NULL));
            }
            else if (type == FMOD_DSP_TYPE_UNKNOWN)
            {
                AudioEffectInternalDefinition* internalDesc = FindAudioEffectDefinition(constant, effectConstant.type);
                if (internalDesc == NULL)
                {
                    ErrorStringMsg("Audio effect %s could not be found. Check that the project contains the correct native audio plugin libraries and that the importer settings are set up correctly.", GetEffectName(constant, effectConstant.type));
                    continue;
                }
                memory.effects[i].dsp = internalDesc->CreateDSP(system, NULL, memory.effects[i].sideChainBuffer, NULL);
                if (memory.effects[i].dsp != NULL)
                {
                    FMOD::ChannelGroup* channelGroup = memory.channelGroups[effectConstant.groupConstantIndex];
                    CHECK_FMOD_RETURN(channelGroup->addDSP(memory.effects[i].dsp, 0));
                }
                else
                {
                    ErrorStringMsg("Audio effect %s could not be found. Check that the project contains the correct native audio plugin libraries and that the importer settings are set up correctly.", internalDesc->m_desc->m_unity.name);
                }
            }
            else if (system->createDSPByType(type, &(memory.effects[i].dsp)) == FMOD_OK)
            {
                FMOD::ChannelGroup* channelGroup = memory.channelGroups[effectConstant.groupConstantIndex];
                CHECK_FMOD_RETURN(channelGroup->addDSP(memory.effects[i].dsp, 0));
            }
            else
            {
                ErrorStringMsg("Could not initialise internal audio effect");
            }

            if (memory.effects[i].dsp == NULL)
            {
                ErrorStringMsg("AudioMixer: Instantiation of DSP effect of type %d failed. The target platform does not seem to support it.\n", type);
            }
        }

        // Add VU meters and attenuation faders at end of groups -- this must happen before we setting up wet/dry connections
        for (int i = 0; i < constant.groupCount; i++)
        {
            if ((memory.headGroupData[i]->flags & (ChannelGroupData::EnableMetering | ChannelGroupData::ApplyAttenuation)) == 0)
                continue;

            FMOD::ChannelGroup* channelGroup = memory.channelGroups[i];

            UnityAudioEffectDefinition effectdef;
            memset(&effectdef, 0, sizeof(effectdef));
            memcpy(effectdef.name, "VUFader", 8);
            effectdef.structsize = sizeof(UnityAudioEffectDefinition);
            effectdef.paramstructsize = sizeof(UnityAudioParameterDefinition);

            effectdef.process = AudioMixerFaderProcessCallback;
            AudioEffectInternalDefinition internalDef(&effectdef, false);
            memory.headDSPs[i] = internalDef.CreateDSP(system, &memory.headGroupData[i], NULL, NULL);
            Assert(memory.headDSPs[i] != NULL);

#if BYPASS_UNTIL_READY
            CHECK_FMOD_RETURN(memory.headDSPs[i]->setBypass(true));
#endif
            CHECK_FMOD_RETURN(channelGroup->addDSP(memory.headDSPs[i], NULL));
        }

        // Setup wet mix connections
        for (int i = 0; i < constant.effectCount; i++)
        {
            memory.effects[i].wetCon = NULL;
            memory.effects[i].dryCon = NULL;
            memory.effects[i].wet = (memory.effects[i].dsp != NULL) ? 1.0f : 0.0f;

            FMOD::DSP* dspInput = NULL;
            FMOD::DSP* dspOutput = NULL;
            switch (constant.effects[i].type)
            {
                case EffectConstant::kSend:
                case EffectConstant::kReceive:
                case EffectConstant::kDuckVolume:
                    // No wet/dry routing for these
                    break;
                default:
                    if (memory.effects[i].dsp != NULL && constant.effects[i].wetMixLevelIndex != -1)
                    {
                        CHECK_FMOD_RETURN(memory.effects[i].dsp->getInput(0, &dspInput, NULL));
                        CHECK_FMOD_RETURN(memory.effects[i].dsp->getOutput(0, &dspOutput, &memory.effects[i].wetCon));
                        CHECK_FMOD_RETURN(dspOutput->addInput(dspInput, &memory.effects[i].dryCon));
                    }
            }
        }

        memory.transition.targetSnapshotIndex = snapshotIndex;
        memory.transition.valueCount = snapshotParameterCount;
        memory.transition.startingValues = alloc.ConstructArray<float>(snapshotParameterCount);
        memory.transition.previousValues = alloc.ConstructArray<float>(snapshotParameterCount);
        memory.transition.currentValues = alloc.ConstructArray<float>(snapshotParameterCount);
        memory.transition.changedValues = alloc.ConstructArray<bool>(snapshotParameterCount);
        memory.transition.weightedMix = alloc.ConstructArray<float>(snapshotParameterCount);

        // Initialize with values so that ApplyBlendedSnapshots will initialize all values...
        for (int i = 0; i < constant.snapshots[0].valueCount; i++)
            memory.transition.previousValues[i] = UNINITIALIZED_SNAPSHOT;

        memory.transition.exposedValues = alloc.ConstructArray<float>(constant.exposedParameterCount);
        for (int i = 0; i < constant.exposedParameterCount; i++)
            memory.transition.exposedValues[i] = UNINITIALIZED_SNAPSHOT;

        //Prime the starting transition to the default snapshot
        memory.transition.weight = 1;
        memory.transition.timeToReachState = 0;
        memory.transition.usingWeightedMix = false;
        memcpy(memory.transition.startingValues, constant.snapshots[0].values.Get(), sizeof(float) * memory.transition.valueCount);

#if BYPASS_UNTIL_READY
        for (int i = 0; i < constant.effectCount; i++)
            if (memory.effects[i].dsp != NULL)
                CHECK_FMOD_RETURN(memory.effects[i].dsp->setBypass(false));

        for (int i = 0; i < constant.groupCount; i++)
            if (memory.headDSPs[i] != NULL)
                CHECK_FMOD_RETURN(memory.headDSPs[i]->setBypass(false));
#endif

        if (enableSuspend)
            memory.headGroupData[0]->flags |= ChannelGroupData::EnableSuspend;
        UpdateAudioMixerMemory(constant, memory, 0.0f, system, 10000.0f); // High threshold to force into suspended state

        return &memory;
    }

    void DestroyAudioMixerMemory(AudioMixerMemory* memory, const AudioMixerConstant& constant, FMOD::System* system, mecanim::memory::Allocator& alloc)
    {
        if (memory == NULL)
            return;

        for (int i = 0; i < constant.effectCount; i++)
            if (memory->effects[i].dsp != NULL)
                CHECK_FMOD_RETURN(memory->effects[i].dsp->release());

        for (int i = 0; i < constant.groupCount; i++)
        {
            if (memory->headDSPs[i] != NULL)
                CHECK_FMOD_RETURN(memory->headDSPs[i]->release());
            CHECK_FMOD_RETURN(memory->channelGroups[i]->release());
        }

        CHECK_FMOD_RETURN(memory->muteGroup->release());

        CHECK_FMOD_RETURN(system->update());

        alloc.Deallocate(memory->muteState);
        alloc.Deallocate(memory->headGroupData);
        alloc.Deallocate(memory->embeddedFaderGroupData);
        alloc.Deallocate(memory->channelGroups);
        alloc.Deallocate(memory->headDSPs);
        alloc.Deallocate(memory->effects);

        alloc.Deallocate(memory->transition.startingValues);
        alloc.Deallocate(memory->transition.currentValues);
        alloc.Deallocate(memory->transition.previousValues);
        alloc.Deallocate(memory->transition.changedValues);
        alloc.Deallocate(memory->transition.weightedMix);
        alloc.Deallocate(memory->transition.exposedValues);

        alloc.Deallocate(memory->sideChainBuffers);

        alloc.Deallocate(memory);
    }

    inline static float BlendValue(float from, float to, float weight, SnapshotConstant::TransitionType transition)
    {
        if (from == to)
            return to;

        switch (transition)
        {
            case SnapshotConstant::kLerp:
                return math::lerp(from, to, weight);
            case SnapshotConstant::kSmoothstep:
                return from + (to - from) * SmoothStep(0.0f, 1.0f, weight);
            case SnapshotConstant::kSquared:
                return from + (to - from) * (weight * weight);
            case SnapshotConstant::kSquareRoot:
                return from + (to - from) * math::sqrt(weight);
            case SnapshotConstant::kBrickwallStart:
                if (weight > 1.0e-9f)
                    return to;
                else
                    return from;
            case SnapshotConstant::kBrickwallEnd:
                if (weight < (1.0f - 1.0e-9f))
                    return from;
                else
                    return to;
            default:
                return 0.0f;
        }
    }

    static void BlendSnapshots(const AudioMixerConstant& constant, TransitionMemory& memory)
    {
        if (memory.usingWeightedMix)
        {
            const float* from = memory.startingValues;
            const float* to = memory.weightedMix;
            float* dst = memory.currentValues;
            float weight = memory.weight;
            for (int i = 0; i < memory.valueCount; i++)
                dst[i] = BlendValue(from[i], to[i], weight, SnapshotConstant::kLerp);
            return;
        }

        int targetSnapshotIndex = memory.targetSnapshotIndex;
        const SnapshotConstant& snapshot = constant.snapshots[targetSnapshotIndex];
        SnapshotConstant::TransitionType defaultTransition = (SnapshotConstant::TransitionType)snapshot.defaultTransition;

        const float* from = memory.startingValues;
        const float* to = snapshot.values.Get();
        float* dst = memory.currentValues;
        float weight = memory.weight;

        for (int i = 0; i < memory.valueCount; i++)
            dst[i] = BlendValue(from[i], to[i], weight, (SnapshotConstant::TransitionType)defaultTransition);

        //Override some of the values using different transition types.
        for (int i = 0; i < snapshot.transitionCount; i++)
        {
            int transitionIndex = snapshot.transitionIndices[i];
            dst[transitionIndex] = BlendValue(from[transitionIndex], to[transitionIndex], weight, (SnapshotConstant::TransitionType)snapshot.transitionTypes[i]);
        }
    }

    static void OverrideExposedProperties(const AudioMixerConstant& constant, TransitionMemory& memory)
    {
        for (int i = 0; i < constant.exposedParameterCount; i++)
        {
            if (memory.exposedValues[i] == UNINITIALIZED_SNAPSHOT)
                continue;

            int index = constant.exposedParameterIndices[i];
            memory.currentValues[index] = memory.exposedValues[i];
        }
    }

    static bool IsAnyChannelPlaying(FMOD::ChannelGroup* group)
    {
        int numChannels = 0;
        if (group->getNumChannels(&numChannels) == FMOD_OK)
        {
            for (int i = 0; i < numChannels; i++)
            {
                FMOD::Channel* channel = NULL;
                if (group->getChannel(i, &channel) != FMOD_OK)
                    continue;
                bool isPlaying = false;
                if (channel->isPlaying(&isPlaying) != FMOD_OK)
                    continue;
                if (isPlaying)
                    return true;
            }
        }
        int numChildGroups = 0;
        if (group->getNumGroups(&numChildGroups) == FMOD_OK)
        {
            FMOD::ChannelGroup* childGroup;
            for (int i = 0; i < numChildGroups; i++)
                if (group->getGroup(i, &childGroup) == FMOD_OK)
                    if (IsAnyChannelPlaying(childGroup))
                        return true;
        }
        return false;
    }

    static void CalculateChangedValues(const AudioMixerConstant& constant, TransitionMemory& memory)
    {
        const float* currentValues = memory.currentValues;
        float* previousValues = memory.previousValues;
        bool* changedValues = memory.changedValues;

        // Determine all changed parameters
        for (int i = 0; i < memory.valueCount; i++)
        {
            Assert(UNINITIALIZED_SNAPSHOT != currentValues[i]);

            float currentValue = currentValues[i];
            changedValues[i] = previousValues[i] != currentValue;
        }
    }

    static void ApplyBlendedSnapshots(FMOD::System* system, const AudioMixerConstant& constant, AudioMixerMemory& memory, float deltaTime)
    {
        if (deltaTime <= 0.0f)
            deltaTime = 1.0f;

        const float* currentValues = memory.transition.currentValues;
        float* previousValues = memory.transition.previousValues;
        const bool* changedValues = memory.transition.changedValues;

        int sampleRate = 48000;
        CHECK_FMOD_RETURN(system->getSoftwareFormat(&sampleRate, NULL, NULL, NULL, NULL, NULL));

        // Apply volume & pitch for all groups
        for (int i = 0; i < constant.groupCount; i++)
        {
            const GroupConstant& groupConstant = constant.groups[i];

            if (changedValues[groupConstant.volumeIndex])
            {
                float vol = DbToLin(currentValues[groupConstant.volumeIndex]);
                if (memory.headGroupData[i]->flags & ChannelGroupData::ApplyAttenuation)
                {
                    memory.headGroupData[i]->mixLevel = vol;
#ifdef UNITY_EXTRA_FUNCTIONALITY
                    CHECK_FMOD_RETURN(memory.channelGroups[i]->setAudibilityFactor(vol));
#endif
                }
                if (memory.embeddedFaderGroupData[i]->flags & ChannelGroupData::ApplyAttenuation)
                {
                    memory.embeddedFaderGroupData[i]->mixLevel = vol;
#ifdef UNITY_EXTRA_FUNCTIONALITY
                    CHECK_FMOD_RETURN(memory.channelGroups[i]->setAudibilityFactor(vol));
#endif
                }
            }

            if (changedValues[groupConstant.pitchIndex])
                memory.channelGroups[i]->setPitch(currentValues[groupConstant.pitchIndex]);
        }

        // Apply effect parmaters
        for (int i = 0; i < constant.effectCount; i++)
        {
            const EffectConstant& effectConstant = constant.effects[i];
            EffectMemory& effectMem = memory.effects[i];
            UInt32 wetMixIndex = effectConstant.wetMixLevelIndex;
            if (wetMixIndex != -1 && changedValues[wetMixIndex] && effectMem.dsp != NULL)
            {
                float wet = DbToLin(currentValues[wetMixIndex]);
                effectMem.wet = wet;
                if (effectMem.wetCon != NULL)
                {
                    if (effectMem.wetCon != NULL)
                        effectMem.wetCon->setMix(wet);
                    if (effectMem.dryCon != NULL)
                    {
                        /*
                        A, B, C and D are effects.
                        Each DSP effect has a wet level parameter in the range 0..1 called w_X in the diagram below.
                        The effects also have the a toggle for turning on or off the wet level. When it's off, the connection does not apply any gain which is equivalent
                        to w_X = 1. We now focus on effect block C. Since C is reading through a connection to effect B which applies the wet level of B to the signal
                        before it reaches C, but the dry path (that bypasses the wet signal from C and carries the dry signal of B directly to D) does not apply the wet
                        level of B to the signal, we need to factor in w_B into the dry amount 1-w_C (lower connection).
                        If the wet level is disabled on the previous effect, it won't have a dry connection.

                                                                                             +-------------+
                                                                                      +------| (1-w_B)*w_A |<---+
                                                                                      |      +-------------+    |
                                                                                      |                         |
                                               +-------+               +-------+      |         +-------+       |    +-------+
                                               |       |               |       |<-----+         |       |       |    |       |
                                               |       |               |       |                |       |       |    |       |
                                               |       |   +-----+     |       |   +-----+      |       |       |    |       |
                                               |   D   |<--+ w_C +-----|   C   |<--| w_B |<--+--|   B   |<------+----|   A   |
                                               |       |   +-----+     |       |   +-----+   |  |       |            |       |
                                               |       |               |       |             |  |       |            |       |
                                               |       |<-----+        |       |             |  |       |            |       |
                                               +-------+      |        +-------+             |  +-------+            +-------+
                                                              |                              |
                                                              |     +-------------+          |
                                                              +-----| (1-w_C)*w_B |<---------+
                                                                    +-------------+
                        */
                        float prevWet = DbToLin((effectConstant.prevEffectIndex != -1 && memory.effects[effectConstant.prevEffectIndex].dryCon != NULL) ? memory.effects[effectConstant.prevEffectIndex].wet : 0.0f);
                        effectMem.dryCon->setMix((1.0f - wet) * prevWet);
                    }
                }
                bool wasEffectBypassed, isEffectBypassed = (wet == 0.0f) || constant.groups[effectConstant.groupConstantIndex].bypassEffects || effectConstant.bypass;
                isEffectBypassed &= (effectConstant.type >= 0) || (wet == 0.0f && effectConstant.type == EffectConstant::kSend);
                // Calling getBypass/setBypass is cheap and doesn't require any waiting for FMOD
                CHECK_FMOD_RETURN(effectMem.dsp->getBypass(&wasEffectBypassed));
                if (isEffectBypassed != wasEffectBypassed)
                    CHECK_FMOD_RETURN(effectMem.dsp->setBypass(isEffectBypassed));
            }

            for (int p = 0; p < effectConstant.parameterCount; p++)
            {
                UInt32 parameterIndex = effectConstant.parameterIndices[p];
                if (changedValues[parameterIndex] && effectMem.dsp != NULL)
                {
                    FMOD_RESULT result = effectMem.dsp->setParameter(p, currentValues[parameterIndex]);
                    if (result != FMOD_ERR_INVALID_FLOAT)
                        CHECK_FMOD_RETURN(result);
                }
            }
        }

        memcpy(previousValues, currentValues, sizeof(currentValues[0]) * memory.transition.valueCount);
    }

    bool ValidateSnapshotIndex(AudioMixerConstant& constant, int targetSnapshotIndex)
    {
        return targetSnapshotIndex >= 0 && targetSnapshotIndex < constant.snapshotCount;
    }

    static void SetSnapshotTransition(TransitionMemory& memory, int targetSnapshotIndex, float timeToReachState)
    {
        if (memory.targetSnapshotIndex != targetSnapshotIndex || memory.usingWeightedMix)
        {
            memcpy(memory.startingValues, memory.currentValues, sizeof(float) * memory.valueCount);
            memory.weight = 0.0f;
            memory.usingWeightedMix = false;
            memory.targetSnapshotIndex = targetSnapshotIndex;
        }

        memory.timeToReachState = timeToReachState;
    }

    int GetSnapshotIndex(AudioMixerConstant& constant, const char* name)
    {
        NameHash hash = mecanim::processCRC32(name);

        for (int i = 0; i < constant.snapshotCount; i++)
        {
            if (constant.snapshots[i].nameHash == hash)
                return i;
        }

        return -1;
    }

    void TransitionToSnapshot(AudioMixerMemory& memory, int targetSnapshotIndex, float timeToReachState)
    {
        SetSnapshotTransition(memory.transition, targetSnapshotIndex, timeToReachState);
    }

    void SetWeightedMix(const AudioMixerConstant& constant, AudioMixerMemory& memory, int* indices, float* weights, int numWeights, float timeToReachState)
    {
        memset(memory.transition.weightedMix, 0, sizeof(float) * memory.transition.valueCount);
        float scale = 0.0f;
        for (int i = 0; i < numWeights; i++)
            scale += math::max(weights[i], 0.0f);
        scale = (scale > 0.0f) ? (1.0f / scale) : 0.0f;
        for (int i = 0; i < numWeights; i++)
        {
            const SnapshotConstant& snapshot = constant.snapshots[indices[i]];
            const float* src = &(snapshot.values[0]);
            const float w = math::max(weights[i], 0.0f) * scale;
            for (int n = 0; n < memory.transition.valueCount; n++)
                memory.transition.weightedMix[n] += src[n] * w;
        }
        memcpy(memory.transition.startingValues, memory.transition.currentValues, sizeof(float) * memory.transition.valueCount);
        memory.transition.weight = 0.0f;
        memory.transition.usingWeightedMix = true;
        memory.transition.timeToReachState = timeToReachState;
    }

    static void UpdateTransition(TransitionMemory& memory, float deltaTime)
    {
        if (memory.timeToReachState <= 0.0f)
            memory.weight = 1.0f;
        else
            memory.weight += (deltaTime / memory.timeToReachState);

        memory.weight = math::min(1.0f, memory.weight);
    }

    void UpdateAudioMixerMemory(const AudioMixerConstant& constant, AudioMixerMemory& memory, float deltaTime, FMOD::System* system
        , float suspendThreshold
        )
    {
        UpdateTransition(memory.transition, deltaTime);
        BlendSnapshots(constant, memory.transition);
        OverrideExposedProperties(constant, memory.transition);
        CalculateChangedValues(constant, memory.transition);

        ApplyBlendedSnapshots(system, constant, memory, deltaTime);

        bool anyChannelPlaying = IsAnyChannelPlaying(memory.channelGroups[0]);
        if (anyChannelPlaying)
        {
            // This may happen if the user is changing the output group of an already playing AudioSource
            SetSuspended(memory, false);
        }
        else if (
            (memory.headGroupData[0]->flags & ChannelGroupData::EnableSuspend) != 0 &&
            memory.headGroupData[0]->suspendRMS < suspendThreshold &&
            memory.headGroupData[0]->resumeGracePeriodSamplesLeft == 0)
        {
            // No channels playing, the suspend level detector RMS signal is below the threshold.
            // Set resumeGracePeriodSamplesLeft to a negative value so that it isn't counted down.
            memory.headGroupData[0]->resumeGracePeriodSamplesLeft = -1;
            SetSuspended(memory, true);
        }
    }

    void SetSuspended(AudioMixerMemory& memory, bool state)
    {
        FMOD::DSP* dspHead = NULL;
        memory.channelGroups[0]->getDSPHead(&dspHead);
        if (dspHead == NULL)
            return;
        bool prevActiveState = false;
        dspHead->getActive(&prevActiveState);

        if (!state && prevActiveState)
        {
            // If we just went from inactive to active, we give the mixer a grace-period of 1 second to propagate signals through
            // its hierarchy including send/receive connections and routing to other mixers that may cause various latencies.
            // It's important that we set the new value of resumeGracePeriodSamplesLeft before activating the DSP again to avoid
            // the mixer thread from overwriting it.
            FMOD::System* system = NULL;
            dspHead->getSystemObject(&system);
            int samplerate;
            system->getSoftwareFormat(&samplerate, NULL, NULL, NULL, NULL, NULL);
            memory.headGroupData[0]->resumeGracePeriodSamplesLeft = samplerate;
        }
        dspHead->setActive(!state);
    }

    bool IsSuspended(const AudioMixerMemory& memory)
    {
        FMOD::DSP* dspHead = NULL;
        if (memory.channelGroups[0] == NULL)
            return false;
        memory.channelGroups[0]->getDSPHead(&dspHead);
        if (dspHead == NULL)
            return false;
        bool isActive = false;
        return (dspHead->getActive(&isActive) == FMOD_OK) ? !isActive : true;
    }

    int FindGroupIndex(const AudioMixerConstant& constant, const UnityGUID& guid)
    {
        for (int i = 0; i < constant.groupCount; i++)
        {
            if (constant.groupGUIDs[i] == guid)
                return i;
        }

        return -1;
    }

    int FindEffectIndex(const AudioMixerConstant& constant, const UnityGUID& guid)
    {
        for (int i = 0; i < constant.effectCount; i++)
        {
            if (constant.effectGUIDs[i] == guid)
                return i;
        }

        return -1;
    }

    static int FindGroupIndexWithParent(const AudioMixerConstant& constant, const char* name, int parentIndex)
    {
        const char* nameBlob = &constant.groupNameBuffer[0];
        for (int i = 0; i < constant.groupCount; i++)
        {
            int parent = constant.groups[i].parentConstantIndex;
            if (strcmp(nameBlob, name) == 0 && parent == parentIndex)
                return i;

            nameBlob += strlen(nameBlob) + 1;
        }
        return -1;
    }

    static void GetGroupGUIDsContainingSubString(const AudioMixerConstant& constant, const char* subString, const core::string& prefix, int parentIndex, std::vector<UnityGUID>& guids)
    {
        if (strstr(prefix.c_str(), subString) != NULL && parentIndex >= 0)
            guids.push_back(constant.groupGUIDs[parentIndex]);
        const char* name = &constant.groupNameBuffer[0];
        for (int i = 0; i < constant.groupCount; i++)
        {
            if (constant.groups[i].parentConstantIndex == parentIndex)
                GetGroupGUIDsContainingSubString(constant, subString, prefix + "/" + name, i, guids);
            name += strlen(name) + 1;
        }
    }

    void GetGroupGUIDsContainingSubString(const AudioMixerConstant& constant, const char* subString, std::vector<UnityGUID>& guids)
    {
        guids.clear();
        GetGroupGUIDsContainingSubString(constant, subString, "", -1, guids);
    }

    static const char* ExtractGroupNameFromIndex(const AudioMixerConstant& constant, int index)
    {
        const char* name = &constant.groupNameBuffer[0];
        for (int i = 0; i < index; i++)
            name += strlen(name) + 1;

        return name;
    }

    const char* GetGroupNameFromGUID(const AudioMixerConstant& constant, const UnityGUID& guid)
    {
        int index = FindGroupIndex(constant, guid);
        if (index == -1)
            return "";

        return ExtractGroupNameFromIndex(constant, index);
    }

    core::string GetGroupPathFromGUID(const AudioMixerConstant& constant, const UnityGUID& guid)
    {
        int index = FindGroupIndex(constant, guid);
        if (index == -1)
            return "";

        core::string path = "";
        while (index != -1)
        {
            path.insert(0, ExtractGroupNameFromIndex(constant, index));
            path.insert(0, "/");

            index = constant.groups[index].parentConstantIndex;
        }

        return path;
    }

    static int FindSnapshotIndex(const AudioMixerConstant& constant, const UnityGUID& guid)
    {
        for (int i = 0; i < constant.snapshotCount; i++)
        {
            if (constant.snapshotGUIDs[i] == guid)
                return i;
        }

        return -1;
    }

    static const char* ExtractSnapshotNameFromIndex(const AudioMixerConstant& constant, int index)
    {
        const char* name = &constant.snapshotNameBuffer[0];
        for (int i = 0; i < index; i++)
            name += strlen(name) + 1;

        return name;
    }

    FMOD::ChannelGroup* FindChannelGroup(const AudioMixerConstant& constant, const AudioMixerMemory& memory, const UnityGUID& guid)
    {
        int index = FindGroupIndex(constant, guid);
        if (index == -1)
            return NULL;

        if (memory.muteState != NULL)
            if (memory.muteState[index])
                return memory.muteGroup;

        return memory.channelGroups[index];
    }

    void AssignOutputGroup(const AudioMixerConstant& constant, const AudioMixerMemory& memory, FMOD::ChannelGroup* parent)
    {
        Assert(constant.groupCount > 0);
        CHECK_FMOD_RETURN(parent->addGroup(memory.channelGroups[0]));
    }

    bool GetFloatBuffer(const AudioMixerConstant& constant, const AudioMixerMemory& memory, const UnityGUID& guid, const char* name, float* data, int numsamples)
    {
        for (int i = 0; i < constant.effectCount; i++)
        {
            if (constant.effectGUIDs[i] == guid)
            {
                AudioEffectInternalInstance* state = NULL;
                if (memory.effects[i].dsp->getUserData((void**)&state) == FMOD_OK && state != NULL && state->m_desc->m_unity.getfloatbuffer != NULL)
                    return state->m_desc->m_unity.getfloatbuffer(state, name, data, numsamples);
                return false;
            }
        }

        return false;
    }

    float GetCPUUsage(const AudioMixerConstant& constant, const AudioMixerMemory& memory, const UnityGUID& guid)
    {
#ifdef UNITY_EXTRA_FUNCTIONALITY
        for (int i = 0; i < constant.effectCount; i++)
        {
            if (constant.effectGUIDs[i] == guid)
            {
                unsigned short usage;
                memory.effects[i].dsp->getCPUUsage(&usage);
                return usage;
            }
        }
#endif // UNITY_EXTRA_FUNCTIONALITY
        return 0.0f;
    }

    int GetGroupVUInfo(const AudioMixerConstant& constant, const AudioMixerMemory& memory, const UnityGUID& guid, bool fader, audio::mixer::VUInfo* vuInfo)
    {
        static const float threshold = (float)math::powr(math::float1(10.0f), math::float1(0.05f * kMinVolumeLevel));

        int index = FindGroupIndex(constant, guid);
        if (index == -1)
            return 0;

        bool faderGroupData = fader && (memory.embeddedFaderGroupData[index]->flags & ChannelGroupData::ApplyAttenuation);

        ChannelGroupData& data = (faderGroupData) ? memory.embeddedFaderGroupData[index] : memory.headGroupData[index];
        // Snapping all meters of suspended mixers back to -inf dB.
        // The mixer does actually still contains signals in it's effect buffers (echo, reverb etc.)
        if (audio::mixer::IsSuspended(memory))
        {
            for (int i = 0; i < 9; i++)
            {
                vuInfo->level[i] = kMinVolumeLevel;
                vuInfo->peak[i] = kMinVolumeLevel;
            }
        }
        else
        {
            for (int i = 0; i < 9; i++)
            {
                float l = data.GetMeasuredVULevel(i);
                vuInfo->level[i] = (l < threshold) ? kMinVolumeLevel : (20.0f * log10f(l));

                float p = data.GetMeasuredPeakLevel(i);
                vuInfo->peak[i] = (p < threshold) ? kMinVolumeLevel : (20.0f * log10f(p));
            }
        }

        return GetAudioManager().GetSpeakerCount();
    }

    void UpdateBypass(AudioMixerConstant& constant, AudioMixerMemory& memory)
    {
        for (int i = 0; i < constant.effectCount; i++)
        {
            const EffectConstant& effectConstant = constant.effects[i];
            EffectMemory& effectMem = memory.effects[i];
            // Calling getBypass/setBypass is cheap and doesn't require any waiting for FMOD
            bool wasEffectBypassed, isEffectBypassed = (effectMem.wet == 0.0f) || constant.groups[effectConstant.groupConstantIndex].bypassEffects || effectConstant.bypass;
            isEffectBypassed &= (effectConstant.type >= 0) || (effectMem.wet == 0.0f && effectConstant.type == EffectConstant::kSend);
            if (effectMem.dsp != NULL)
            {
                CHECK_FMOD_RETURN(effectMem.dsp->getBypass(&wasEffectBypassed));
                if (isEffectBypassed != wasEffectBypassed)
                    CHECK_FMOD_RETURN(effectMem.dsp->setBypass(isEffectBypassed));
            }
        }
    }

    void SetResultingMuteState(const AudioMixerConstant& constant, const AudioMixerMemory& memory, int index, bool muted)
    {
        memory.muteState[index] = muted;
        for (int n = 0; n < constant.effectCount; n++)
        {
            if (constant.effects[n].groupConstantIndex == index && constant.effects[n].type >= 0)
            {
                AudioEffectInternalInstance* state = NULL;
                if (memory.effects[n].dsp != NULL && memory.effects[n].dsp->getUserData((void**)&state) == FMOD_OK && state != NULL)
                {
                    state->flags = muted ? (state->flags | UnityAudioEffectStateFlags_IsMuted) : (state->flags & ~UnityAudioEffectStateFlags_IsMuted);
                }
            }
        }
    }

    float GetLiveValue(AudioMixerMemory& memory, int snapshotParameterIndex)
    {
        return memory.transition.currentValues[snapshotParameterIndex];
    }

    void DestroyAudioMixerConstant(AudioMixerConstant* constant, mecanim::memory::Allocator& alloc)
    {
        alloc.Deallocate(constant->groups);

        for (int i = 0; i < constant->effectCount; i++)
        {
            alloc.Deallocate(constant->effects[i].parameterIndices);
        }
        alloc.Deallocate(constant->effects);
        alloc.Deallocate(constant->effectGUIDs);
        alloc.Deallocate(constant->groupGUIDs);

        for (int i = 0; i < constant->snapshotCount; i++)
        {
            SnapshotConstant& snapshot = constant->snapshots[i];
            alloc.Deallocate(snapshot.values);
            alloc.Deallocate(snapshot.transitionTypes);
            alloc.Deallocate(snapshot.transitionIndices);
        }
        alloc.Deallocate(constant->snapshots);
        alloc.Deallocate(constant->groupNameBuffer);
        alloc.Deallocate(constant->pluginEffectNameBuffer);
        alloc.Deallocate(constant->exposedParameterNames);
        alloc.Deallocate(constant->exposedParameterIndices);

        alloc.Deallocate(constant->snapshotNameBuffer);
        alloc.Deallocate(constant->snapshotGUIDs);

        alloc.Deallocate(constant);
    }

    int GetExposedPropertyIndex(const AudioMixerConstant& constant, const char* name)
    {
        NameHash hash = mecanim::processCRC32(name);

        for (int i = 0; i < constant.exposedParameterCount; i++)
        {
            if (constant.exposedParameterNames[i] == hash)
                return i;
        }
        return -1;
    }

    void SetExposedProperty(const AudioMixerMemory& memory, int index, float value)
    {
        memory.transition.exposedValues[index] = value;
    }

    void ClearExposedProperty(const AudioMixerMemory& memory, int index)
    {
        memory.transition.exposedValues[index] = UNINITIALIZED_SNAPSHOT;
    }

    float GetExposedPropertyValue(const AudioMixerMemory& memory, int index)
    {
        if (memory.transition.exposedValues[index] != UNINITIALIZED_SNAPSHOT)
            return memory.transition.exposedValues[index];

        int snapshotIndex = memory.constant->exposedParameterIndices[index];
        return memory.transition.currentValues[snapshotIndex];
    }

    bool CopyExposedParameterValues(const AudioMixerConstant& constant, const AudioMixerMemory& memory, float* values, int valuesCount)
    {
        if (valuesCount != constant.exposedParameterCount)
            return false;

        memcpy(values, memory.transition.exposedValues, sizeof(float) * constant.exposedParameterCount);
        return true;
    }

    bool SetExposedParameterValues(const AudioMixerConstant& constant, const float* values, int valuesCount, AudioMixerMemory& memory)
    {
        if (valuesCount != constant.exposedParameterCount)
            return false;

        memcpy(memory.transition.exposedValues, values, sizeof(float) * constant.exposedParameterCount);
        return true;
    }

    void ClearExposedParameterValues(const AudioMixerConstant& constant, const AudioMixerMemory& memory)
    {
        for (int i = 0; i < constant.exposedParameterCount; i++)
        {
            memory.transition.exposedValues[i] = UNINITIALIZED_SNAPSHOT;
        }
    }
}
}
