#include "UnityPrefix.h"
#include "AudioManager.h"
#include "Runtime/Audio/correct_fmod_includer.h"
#include "Runtime/Audio/sound/SoundManager.h"
#include "Runtime/Profiler/ProfilerImpl.h"

#ifdef UNITY_EXTRA_FUNCTIONALITY_CPUPROFILER
static inline void AudioProfilerBegin(const char* name)
{
#if ENABLE_PROFILER
    if (UnityProfilerPerThread::ms_InstanceTLS != NULL)
    {
        ProfilerInformation& profilerInfo = *profiler_get_info_for_name(name, kProfilerAudio);
        PROFILER_BEGIN(profilerInfo, NULL);
    }
#endif // ENABLE_PROFILER
}

static inline void AudioProfilerEnd()
{
#if ENABLE_PROFILER
    //Check that the begin has been called before calling end
    if (UnityProfilerPerThread::ms_InstanceTLS != NULL)
        PROFILER_END
#endif // ENABLE_PROFILER
}

#endif


FMOD_RESULT F_CALLBACK AudioManager::systemCallback(FMOD_SYSTEM* c_system, FMOD_SYSTEM_CALLBACKTYPE type, void* data1, void* data2)
{
    FMOD::System* system = (FMOD::System*)c_system;
    FMOD_RESULT result = FMOD_OK;

    switch (type)
    {
        case FMOD_SYSTEM_CALLBACKTYPE_DEVICELISTCHANGED:
            // Get available sound cards
            // If no device is found fall back on the NOSOUND driver
            // @TODO Enable user to choose driver
            int numDrivers;
            result = system->getNumDrivers(&numDrivers);

            if ((result == FMOD_OK) && (numDrivers != 0))
            {
                // Set driver to the new default driver and autodetect output.
                // We don't invoke the scripting callback here as this callback function is called from within FMOD, so we just note that the driver was changed and handle it later in AudioManager::Update().
                // Note that this callback gets invoked even when just unplugging headphones from a Macbook (Pro Retina), so we treat this like a device change too, as this could be useful to let the game popup
                // a dialog asking the user whether to switch to HRTF mode or not, since we can't detect headphones specifically and both setups are just stereo configurations.
                AudioManager* manager = GetAudioManagerPtr();
                bool success = false;
                if (manager != NULL)
                {
                    success = manager->SetActiveOutputDriver(&manager->m_DefaultOutputDriver);
                    if (success)
                    {
                        manager->m_DeviceChanged = true;
                        manager->m_PendingAudioConfigurationCallback = true;
                    }
                }

                if (!success)
                {
                    // If the manager has not been fully created (IE: this callback is being triggered by FMOD initializing during audio manager awake)
                    // We don't want to be warning devs about system failures. However, if the manager is alive then we need to try to reset FMOD.
                    if (manager != NULL)
                    {
                        WarningString(Format("Default audio device was changed, but the audio system failed to initialize it (%s). Attempting to reset sound system.", FMOD_ErrorString(result)));
                        manager->m_DeviceChangeNeedsReset = true;
                    }
                }
            }
            return result;
#if !UNITY_N3DS // N3DS is currently not built by katana, but also the platform handles sound loading totally different due to hardware .support
        case FMOD_SYSTEM_CALLBACKTYPE_SOUNDALLOCATION:
            if (!data2)
                return SoundManager::OnCreateSoundPopAllocation();
            else
                return SoundManager::OnCreateSoundPushAllocation(data1);
#endif
#ifdef UNITY_EXTRA_FUNCTIONALITY_CPUPROFILER
            /*
                    // Not in a working state -- requires more work in the profiler to enable profiling of other threads than those maintained by the job system.
                    case FMOD_SYSTEM_CALLBACKTYPE_THREADSTARTED:
                    {
                        profiler_initialize_thread ("FMOD", (const char*)data2);
                        return FMOD_OK;
                    }
                    case FMOD_SYSTEM_CALLBACKTYPE_THREADSTOPPED:
                    {
                        return FMOD_OK;
                    }
                    case FMOD_SYSTEM_CALLBACKTYPE_THREADLOOP:
                    {
                        return FMOD_OK;
                    }
                    case FMOD_SYSTEM_CALLBACKTYPE_BEGINMIX:
                    {
                        // On OSX audio the mixer is driven by a thread setup by the system rather than FMOD.
                        // FIXME: There is no cleanup code for the TLS.
                        if (UnityProfilerPerThread::ms_InstanceTLS == NULL)
                            profiler_initialize_thread ("FMOD", "FMOD mixer");
                        AudioProfilerBegin ("FMOD mixer");
                        return FMOD_OK;
                    }
                    case FMOD_SYSTEM_CALLBACKTYPE_ENDMIX:
                    {
                        AudioProfilerEnd();
                        return FMOD_OK;
                    }
                    case FMOD_SYSTEM_CALLBACKTYPE_BEGINDSP:
                    {
                        AudioProfilerBegin ("FMOD DSP");
                        return FMOD_OK;
                    }
                    case FMOD_SYSTEM_CALLBACKTYPE_ENDDSP:
                    {
                        AudioProfilerEnd();
                        return FMOD_OK;
                    }
                    case FMOD_SYSTEM_CALLBACKTYPE_BEGINCODEC:
                    {
                        AudioProfilerBegin ("FMOD codec");
                        return FMOD_OK;
                    }
                    case FMOD_SYSTEM_CALLBACKTYPE_ENDCODEC:
                    {
                        AudioProfilerEnd();
                        return FMOD_OK;
                    }
                    case FMOD_SYSTEM_CALLBACKTYPE_BEGINSUBMIX:
                    {
                        AudioProfilerBegin ("FMOD submix");
                        return FMOD_OK;
                    }
                    case FMOD_SYSTEM_CALLBACKTYPE_ENDSUBMIX:
                    {
                        AudioProfilerEnd();
                        return FMOD_OK;
                    }
            */
#endif

        default:
            return result;
    }
}
