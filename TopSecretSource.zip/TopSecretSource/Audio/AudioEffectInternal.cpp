#include "UnityPrefix.h"
#include "Runtime/Audio/AudioEffectInternal.h"
#include "Runtime/Audio/AudioManager.h"
#include "Runtime/BaseClasses/IsPlaying.h"
#include "Runtime/Misc/Plugins.h"

UnityAudioEffectInternal g_AudioMasterDSPInternal
;

// TODO: AudioEffectInternalDefinition needs to be ref-counted by the data associated with FMOD::DSP instances
// Otherwise we may run into the situation where a plugin is still playing via an instanced DSP, but the plugin DLL has been unloaded
// (and therefore the effect definition gets invalidated, so it cannot be read anymore).

#define BOILERPLATE() \
    AudioEffectInternalInstance* instance = NULL;\
    FMOD::DSP* dsp = (FMOD::DSP*)dsp_state->instance;\
    FMOD_RESULT result_getuserdata = dsp->getUserData((void**)&instance);\
    if(result_getuserdata != FMOD_OK)\
        return result_getuserdata;\
    if(instance == NULL)\
        return FMOD_ERR_INVALID_HANDLE;\
    UnityAudioEffectDefinition* effectdef = (UnityAudioEffectDefinition*)&instance->m_desc->m_unity

static FMOD_RESULT F_CALLBACK UnityAudioEffect_InternalCreateCallback(FMOD_DSP_STATE* dsp_state)
{
    BOILERPLATE();

    UnityAudioEffectInternal* internal = (UnityAudioEffectInternal*)instance->internal;
    Assert(internal);

    // Creation of the effect may depend on knowing the system sample rate, so it's important we fill out these field, otherwise the effects can allocate zero-sized arrays which will end up as valid
    // memory addresses and therefore easily cause memory corruption.
    instance->flags =
        (instance->flags & ~(UnityAudioEffectStateFlags_IsPlaying | UnityAudioEffectStateFlags_IsPaused)) |
        (internal->flags &  (UnityAudioEffectStateFlags_IsPlaying | UnityAudioEffectStateFlags_IsPaused));
    instance->currdsptick = internal->currdsptick;
    instance->samplerate = internal->samplerate;
    instance->dspbuffersize = internal->dspbuffersize;

    //If the effect is a spatializer, then we need to create the data struct for it here
    if (effectdef->flags & UnityAudioEffectDefinitionFlags_IsSpatializer)
    {
        AssertMsg(instance->spatializerdata == NULL, "Spatializer data should not be assigned.");
        instance->spatializerdata = UNITY_NEW(UnityAudioSpatializerData, kMemAudio);

        //Initialize the struct members here.
        memset(instance->spatializerdata, 0, sizeof(UnityAudioSpatializerData));
        float* m = instance->spatializerdata->listenermatrix;
        float* s = instance->spatializerdata->sourcematrix;

        // Identity matrix
        m[0] = m[5] = m[10] = m[15] =
                        s[0] = s[5] = s[10] = s[15] = 1.0f;
    }

    FMOD_RESULT result = (effectdef->create == NULL || effectdef->create(instance) == UNITY_AUDIODSP_OK) ? FMOD_OK : FMOD_ERR_UNSUPPORTED;
    dsp_state->plugindata = instance;
    return result;
}

static FMOD_RESULT F_CALLBACK UnityAudioEffect_InternalReleaseCallback(FMOD_DSP_STATE* dsp_state)
{
    BOILERPLATE();
    dsp->setUserData(NULL);
    FMOD_RESULT result = (effectdef->release == NULL || effectdef->release(instance) == UNITY_AUDIODSP_OK) ? FMOD_OK : FMOD_ERR_UNSUPPORTED;

    if (effectdef->flags & UnityAudioEffectDefinitionFlags_IsSpatializer)
    {
        AssertMsg(instance->spatializerdata != NULL, "Spatializer data should be assigned.");
        UNITY_DELETE(instance->spatializerdata, kMemAudio);
    }

    UNITY_DELETE(instance, kMemAudio);
    return result;
}

static FMOD_RESULT F_CALLBACK UnityAudioEffect_InternalResetCallback(FMOD_DSP_STATE* dsp_state)
{
    BOILERPLATE();
    return (effectdef->reset == NULL || effectdef->reset(instance) == UNITY_AUDIODSP_OK) ? FMOD_OK : FMOD_ERR_UNSUPPORTED;
}

static FMOD_RESULT F_CALLBACK UnityAudioEffect_InternalReadCallback(FMOD_DSP_STATE* dsp_state, float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int outchannels)
{
    BOILERPLATE();

    UnityAudioEffectInternal* internal = (UnityAudioEffectInternal*)instance->internal;
    Assert(internal);

    instance->flags =
        (instance->flags & ~(UnityAudioEffectStateFlags_IsPlaying | UnityAudioEffectStateFlags_IsPaused)) |
        (internal->flags &  (UnityAudioEffectStateFlags_IsPlaying | UnityAudioEffectStateFlags_IsPaused));
    instance->currdsptick = internal->currdsptick;
    instance->samplerate = internal->samplerate;
    instance->dspbuffersize = internal->dspbuffersize;

    bool sideChainNeedsClearing = (instance->sidechainbuffer != NULL) && (instance->flags & UnityAudioEffectStateFlags_IsSideChainTarget);
    if (sideChainNeedsClearing && instance->currdsptick - instance->prevdsptick != length)
    {
        // DSPs are not updating while bypassed, so a gap in the sample count means that the DSP just went from bypassed to active, so we need to clear any accumulated
        // data in the sidechain buffer that was added during the time the DSP was bypassed.
        sideChainNeedsClearing = false;
        memset(instance->sidechainbuffer, 0, length * inchannels * sizeof(float));
    }

    FMOD_RESULT result = (effectdef->process == NULL || effectdef->process(instance, inbuffer, outbuffer, length, inchannels, outchannels) == UNITY_AUDIODSP_OK) ? FMOD_OK : FMOD_ERR_UNSUPPORTED;
    instance->prevdsptick = instance->currdsptick;

    // Reset the sidechainbuffer if it exists for this effect
    if (sideChainNeedsClearing)
        memset(instance->sidechainbuffer, 0, length * inchannels * sizeof(float));

    return result;
}

static FMOD_RESULT F_CALLBACK UnityAudioEffect_InternalSetPositionCallback(FMOD_DSP_STATE* dsp_state, unsigned int pos)
{
    BOILERPLATE();
    return (effectdef->setposition == NULL || effectdef->setposition(instance, pos) == UNITY_AUDIODSP_OK) ? FMOD_OK : FMOD_ERR_UNSUPPORTED;
}

static FMOD_RESULT F_CALLBACK UnityAudioEffect_InternalSetFloatParameterCallback(FMOD_DSP_STATE* dsp_state, int index, float value)
{
    BOILERPLATE();
    return (effectdef->setfloatparameter == NULL || effectdef->setfloatparameter(instance, index, value) == UNITY_AUDIODSP_OK) ? FMOD_OK : FMOD_ERR_UNSUPPORTED;
}

static FMOD_RESULT F_CALLBACK UnityAudioEffect_InternalGetFloatParameterCallback(FMOD_DSP_STATE* dsp_state, int index, float* value, char *valuestr)
{
    BOILERPLATE();
    return (effectdef->getfloatparameter == NULL || effectdef->getfloatparameter(instance, index, value, valuestr) == UNITY_AUDIODSP_OK) ? FMOD_OK : FMOD_ERR_UNSUPPORTED;
}

#undef BOILERPLATE

AudioEffectInternalDescription::AudioEffectInternalDescription(UnityAudioEffectDefinition* from)
    : m_refcount(0)
{
    Assert(from->structsize == sizeof(UnityAudioEffectDefinition));
    Assert(from->paramstructsize == sizeof(UnityAudioParameterDefinition));

    memset(&m_fmod, 0, sizeof(m_fmod));
    memcpy(&m_unity, from, sizeof(m_unity));

    strncpy(m_fmod.name, from->name, sizeof(m_fmod.name));
    strncpy(m_unity.name, from->name, sizeof(m_unity.name));
    m_fmod.numparameters = from->numparameters;
    m_fmod.paramdesc = new FMOD_DSP_PARAMETERDESC[m_fmod.numparameters];
    memset(m_fmod.paramdesc, 0, sizeof(FMOD_DSP_PARAMETERDESC) * from->numparameters);

    m_fmod.create = UnityAudioEffect_InternalCreateCallback;
    m_fmod.release = UnityAudioEffect_InternalReleaseCallback;
    m_fmod.reset = UnityAudioEffect_InternalResetCallback;
    m_fmod.read = UnityAudioEffect_InternalReadCallback;
    m_fmod.setposition = UnityAudioEffect_InternalSetPositionCallback;
    m_fmod.setparameter = UnityAudioEffect_InternalSetFloatParameterCallback;
    m_fmod.getparameter = UnityAudioEffect_InternalGetFloatParameterCallback;

    m_unity.paramdefs = new UnityAudioParameterDefinition[from->numparameters];
    memcpy(m_unity.paramdefs, from->paramdefs, sizeof(UnityAudioParameterDefinition) * from->numparameters);

    for (int n = 0; n < from->numparameters; n++)
    {
        m_fmod.paramdesc[n].defaultval = from->paramdefs[n].defaultval;
        m_unity.paramdefs[n].defaultval = from->paramdefs[n].defaultval;
        size_t bufSize = strlen(from->paramdefs[n].description) + 1;
        m_fmod.paramdesc[n].description = new char[bufSize];
        strncpy((char*)m_fmod.paramdesc[n].description, from->paramdefs[n].description, bufSize);
        strncpy(m_fmod.paramdesc[n].label, from->paramdefs[n].unit, sizeof(m_fmod.paramdesc[n].label));
        m_fmod.paramdesc[n].min = from->paramdefs[n].min;
        m_fmod.paramdesc[n].max = from->paramdefs[n].max;
        strncpy(m_fmod.paramdesc[n].name, from->paramdefs[n].name, sizeof(m_fmod.paramdesc[n].name));
    }
}

AudioEffectInternalDescription::AudioEffectInternalDescription(FMOD_DSP_TYPE from, bool* failed)
    : m_refcount(0)
{
    memset(&m_fmod, 0, sizeof(m_fmod));
    memset(&m_unity, 0, sizeof(m_unity));

    *failed = false;

    FMOD::System* system = GetAudioManager().GetFMODSystem();
    FMOD::DSP* dsp = NULL;
    FMOD_RESULT result = system->createDSPByType(from, &dsp);
    if (result != FMOD_OK)
    {
        *failed = true;
        ErrorStringMsg("Instantiation of FMOD effect type %d failed", from);
        Assert(0);
    }

    dsp->getNumParameters(&m_fmod.numparameters);
    dsp->getInfo(m_fmod.name, NULL, NULL, NULL, NULL);
    strncpy(m_unity.name, m_fmod.name + ((strncmp(m_fmod.name, "FMOD ", 5) == 0) ? 5 : 0), sizeof(m_unity.name) - 1);
    strncpy(m_fmod.name, m_unity.name, sizeof(m_fmod.name) - 1);

    m_fmod.paramdesc = new FMOD_DSP_PARAMETERDESC[m_fmod.numparameters];
    memset(m_fmod.paramdesc, 0, sizeof(FMOD_DSP_PARAMETERDESC) * m_fmod.numparameters);

    m_unity.structsize = sizeof(UnityAudioEffectDefinition);
    m_unity.paramstructsize = sizeof(UnityAudioParameterDefinition);
    m_unity.numparameters = m_fmod.numparameters;
    m_unity.paramdefs = new UnityAudioParameterDefinition[m_fmod.numparameters];

    char buf[256];
    for (int n = 0; n < m_fmod.numparameters; n++)
    {
        dsp->getParameterInfo(n, m_fmod.paramdesc[n].name, m_fmod.paramdesc[n].label, buf, sizeof(buf) - 1, &m_fmod.paramdesc[n].min, &m_fmod.paramdesc[n].max);
        dsp->getParameter(n, &m_fmod.paramdesc[n].defaultval, NULL, 0);
        size_t bufSize = strlen(buf) + 1;
        if (strcmp(m_fmod.paramdesc[n].label, "hz") == 0)
            memcpy(m_fmod.paramdesc[n].label, "Hz", 3);
        m_fmod.paramdesc[n].description = new char[bufSize];
        strncpy((char*)m_fmod.paramdesc[n].description, buf, bufSize);
        strncpy(m_unity.paramdefs[n].name, m_fmod.paramdesc[n].name, sizeof(m_unity.paramdefs[n].name));
        strncpy(m_unity.paramdefs[n].unit, m_fmod.paramdesc[n].label, sizeof(m_unity.paramdefs[n].unit));
        m_unity.paramdefs[n].description = m_fmod.paramdesc[n].description;
        m_unity.paramdefs[n].min = m_fmod.paramdesc[n].min;
        m_unity.paramdefs[n].max = m_fmod.paramdesc[n].max;
        m_unity.paramdefs[n].defaultval = m_fmod.paramdesc[n].defaultval;
        m_unity.paramdefs[n].displayscale = (strcmp(m_unity.paramdefs[n].unit, "%") == 0 && m_unity.paramdefs[n].max == 1.0f) ? 100.0f : 1.0f; // Fix up errors in FMODs parameter definitions
        m_unity.paramdefs[n].displayexponent = (StrIEquals(m_unity.paramdefs[n].unit, "ms") || StrIEquals(m_unity.paramdefs[n].unit, "Hz")) ? 3.0f : 1.0f;
    }

    dsp->release();
}

AudioEffectInternalDescription::AudioEffectInternalDescription(FMOD_DSP_DESCRIPTION* from)
    : m_refcount(0)
{
    memcpy(&m_fmod, from, sizeof(m_fmod));
    memset(&m_unity, 0, sizeof(m_unity));

    strncpy(m_fmod.name, from->name, sizeof(m_fmod.name));
    m_fmod.numparameters = from->numparameters;
    m_fmod.paramdesc = new FMOD_DSP_PARAMETERDESC[m_fmod.numparameters];
    memset(m_fmod.paramdesc, 0, sizeof(FMOD_DSP_PARAMETERDESC) * m_fmod.numparameters);

    m_fmod.create = UnityAudioEffect_InternalCreateCallback;
    m_fmod.release = UnityAudioEffect_InternalReleaseCallback;
    m_fmod.reset = UnityAudioEffect_InternalResetCallback;
    m_fmod.read = UnityAudioEffect_InternalReadCallback;
    m_fmod.setposition = UnityAudioEffect_InternalSetPositionCallback;
    m_fmod.setparameter = UnityAudioEffect_InternalSetFloatParameterCallback;
    m_fmod.getparameter = UnityAudioEffect_InternalGetFloatParameterCallback;

    m_unity.structsize = sizeof(UnityAudioEffectDefinition);
    m_unity.paramstructsize = sizeof(UnityAudioParameterDefinition);
    m_unity.paramdefs = new UnityAudioParameterDefinition[from->numparameters];
    memcpy(m_fmod.paramdesc, from->paramdesc, sizeof(FMOD_DSP_PARAMETERDESC) * from->numparameters);

    for (int n = 0; n < from->numparameters; n++)
    {
        m_unity.paramdefs[n].defaultval = from->paramdesc[n].defaultval;
        size_t bufSize = strlen(from->paramdesc[n].description) + 1;
        m_unity.paramdefs[n].description = new char[bufSize];
        m_fmod.paramdesc[n].description = m_unity.paramdefs[n].description;
        if (strcmp(m_fmod.paramdesc[n].label, "hz") == 0)
            memcpy(m_fmod.paramdesc[n].label, "Hz", 3);
        strncpy((char*)m_unity.paramdefs[n].description, from->paramdesc[n].description, bufSize);
        strncpy(m_unity.paramdefs[n].unit, from->paramdesc[n].label, sizeof(m_unity.paramdefs[n].unit));
        m_unity.paramdefs[n].min = from->paramdesc[n].min;
        m_unity.paramdefs[n].max = from->paramdesc[n].max;
        strncpy(m_unity.paramdefs[n].name, from->paramdesc[n].name, sizeof(m_unity.paramdefs[n].name));
        m_unity.paramdefs[n].displayscale = (strcmp(m_unity.paramdefs[n].unit, "%") == 0 && m_unity.paramdefs[n].max == 1.0f) ? 100.0f : 1.0f; // Fix up errors in FMODs parameter definitions
        m_unity.paramdefs[n].displayexponent = (StrIEquals(m_unity.paramdefs[n].unit, "ms") || StrIEquals(m_unity.paramdefs[n].unit, "Hz")) ? 3.0f : 1.0f;
    }
}

AudioEffectInternalDescription::~AudioEffectInternalDescription()
{
    for (int n = 0; n < m_fmod.numparameters; n++)
        delete[] m_fmod.paramdesc[n].description;

    delete[] m_fmod.paramdesc;
    delete[] m_unity.paramdefs;
}

AudioEffectInternalDefinition::AudioEffectInternalDefinition(FMOD_DSP_TYPE type)
    : m_failed(false)
    , m_used(true)
    , m_internalEffectType(type)
{
    m_desc = UNITY_NEW(AudioEffectInternalDescription, kMemAudio)(type, &m_failed);
}

AudioEffectInternalDefinition::AudioEffectInternalDefinition(UnityAudioEffectDefinition* from, bool registerDefinition)
    : m_failed(false)
    , m_used(true)
    , m_internalEffectType(FMOD_DSP_TYPE_UNKNOWN)
{
    m_desc = UNITY_NEW(AudioEffectInternalDescription, kMemAudio)(from);
}

AudioEffectInternalDefinition::~AudioEffectInternalDefinition()
{
    // There is no code freeing DSPs that have been instantiated by this AudioEffectInternalDefinition.
    // If this is needed and the plugins are to be kept in a linked list, beware that FMOD releases DSPs on a different thread than the main thread,
    // so any management code needs to properly handle concurrent access.
    // Note also that Unity's generic native plugin system currently doesn't support hot reloading, so this is at the time of writing not a real issue.
}

FMOD::DSP* AudioEffectInternalDefinition::CreateDSP(FMOD::System* system, void* effectdata, float* sideChainBuffer, UnityAudioSpatializerData** spat)
{
    FMOD::DSP* dsp = NULL;
    if (m_internalEffectType == FMOD_DSP_TYPE_UNKNOWN)
    {
        AudioEffectInternalInstance* instance = UNITY_NEW(AudioEffectInternalInstance, kMemAudio);
        memset(instance, 0, sizeof(AudioEffectInternalInstance));
        instance->structsize = sizeof(UnityAudioEffectState); // Note that this is the size of the struct we are deriving from. Used for allowing plugin to check it's the right version of the API.
        instance->effectdata = effectdata;
        instance->m_desc = m_desc;
        instance->sidechainbuffer = sideChainBuffer;
        instance->internal = &g_AudioMasterDSPInternal;
        instance->hostapiversion = UNITY_AUDIO_PLUGIN_API_VERSION;
        if (m_desc->m_unity.flags & UnityAudioEffectDefinitionFlags_IsSideChainTarget)
            instance->flags |= UnityAudioEffectStateFlags_IsSideChainTarget;

        // CAUTION: This _should_ be safe to do as userdata only needs to be set during creation. If there should be problems with effects causing interference,
        // add a FMOD_DSP_DESCRIPTION m_fmod member to AudioEffectInternalInstance, memcpy m_desc->m_fmod to it, then set the userdata on this and pass it
        // to createDSP instead of m_desc->m_fmod.
        m_desc->m_fmod.userdata = instance;
        if (system->createDSP(&m_desc->m_fmod, &instance->m_dsp) != FMOD_OK || instance->m_dsp == NULL)
        {
            UNITY_DELETE(instance, kMemAudio);
            return NULL;
        }

        if (instance->spatializerdata != NULL && spat != NULL)
            *spat = instance->spatializerdata;

        dsp = instance->m_dsp;
    }
    else if (system->createDSPByType(m_internalEffectType, &dsp) != FMOD_OK)
        return NULL;
    return dsp;
}

AudioEffectInternalDefinition** GetAudioEffectDefinitions(int* numDefs)
{
    if (GetAudioManager().IsAudioDisabledInStandalone())
    {
        *numDefs = 0;
        return NULL;
    }

    dynamic_array<AudioEffectInternalDefinition*>& internalDefs = GetAudioManager().GetAudioEffectInternalDefinitions();

#if UNITY_EDITOR

    // The first time this is called, initialize the internal FMOD effects.
    // Only do this in the editor, because in order to scan the internal plugins, we need to create and destroy the effects once at startup.
    if (internalDefs.size() == 0)
    {
        for (int i = FMOD_DSP_TYPE_LOWPASS; i <= FMOD_DSP_TYPE_HIGHPASS_SIMPLE; i++)
        {
            switch (i)
            {
                case FMOD_DSP_TYPE_TREMOLO:
                case FMOD_DSP_TYPE_LADSPAPLUGIN:
                case FMOD_DSP_TYPE_VSTPLUGIN:
                case FMOD_DSP_TYPE_ITLOWPASS:
                case FMOD_DSP_TYPE_ITECHO:
                case FMOD_DSP_TYPE_WINAMPPLUGIN:
                case FMOD_DSP_TYPE_DELAY:
                    break;
                default:
                {
                    AudioEffectInternalDefinition* def = UNITY_NEW(AudioEffectInternalDefinition, kMemAudio)((FMOD_DSP_TYPE)i);
                    if (!def->m_failed)
                        internalDefs.push_back(def);
                    else
                        UNITY_DELETE(def, kMemAudio);
                }
            }
        }
    }

#endif

    // Mark all registered plugins as unused. Internal (FMOD) effects are always kept
    for (int i = 0; i < internalDefs.size(); i++)
        internalDefs[i]->m_used = (internalDefs[i]->m_internalEffectType != FMOD_DSP_TYPE_UNKNOWN);

    for (size_t n = 0; n < PluginsGetCount(); n++)
    {
        UnityAudioEffectDefinition** defs = NULL;
        size_t numDefs = GetAudioEffectDefinitions(n, &defs);

        for (size_t i = 0; i < numDefs; i++)
        {
            UnityAudioEffectDefinition* srcDef = defs[i];
            int k;
            for (k = 0; k < internalDefs.size(); k++)
                if (strcmp(internalDefs[k]->m_desc->m_unity.name, srcDef->name) == 0)
                    break;
            if (k != internalDefs.size())
                internalDefs[k]->m_used = true;
            else
            {
                AudioEffectInternalDefinition* def = UNITY_NEW(AudioEffectInternalDefinition, kMemAudio)(srcDef, true);
                if (!def->m_failed)
                    internalDefs.push_back(def);
                else
                    UNITY_DELETE(def, kMemAudio);
            }
        }
    }

    // Clean up plugins that are no longer there
    for (size_t i = 0; i < internalDefs.size(); i++)
    {
        if (!internalDefs[i]->m_used)
        {
            UNITY_DELETE(internalDefs[i], kMemAudio);
            internalDefs[i--] = internalDefs[internalDefs.size() - 1];
            internalDefs.pop_back();
        }
    }

    if (numDefs != NULL)
        *numDefs = internalDefs.size();

    return (internalDefs.size() > 0) ? &internalDefs[0] : NULL;
}

AudioEffectInternalDefinition* GetAudioEffectDefinition(const char* name, AudioEffectInternalDefinition** effectDefs, int numEffectDefs)
{
    if (effectDefs == NULL || numEffectDefs == 0)
        effectDefs = GetAudioEffectDefinitions(&numEffectDefs);
    for (int n = 0; n < numEffectDefs; n++)
        if (strcmp(effectDefs[n]->m_desc->m_unity.name, name) == 0)
            return effectDefs[n];
    return NULL;
}

void GetAudioSpatializerDefinitions(AudioEffectInternalDefinitionArray& definitions)
{
    int numDefs = 0;
    AudioEffectInternalDefinition** defs = GetAudioEffectDefinitions(&numDefs);
    for (int n = 0; n < numDefs; n++)
        if (defs[n]->m_desc->m_unity.flags & UnityAudioEffectDefinitionFlags_IsSpatializer)
            definitions.push_back(defs[n]);
}
