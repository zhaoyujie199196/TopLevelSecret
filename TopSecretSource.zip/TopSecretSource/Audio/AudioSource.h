#ifndef AUDIOSOURCE_H
#define AUDIOSOURCE_H

#if ENABLE_AUDIO
#include "Runtime/GameCode/Behaviour.h"
#include "Runtime/Containers/Ringbuffer.h"
#include "AudioManager.h"
#include "AudioParameters.h"
#include "AudioSourceFilter.h"
#include "Runtime/Math/Vector3.h"
#include <vector>
#include "AudioClip.h"
#include "AudioLowPassFilter.h"
#include "AudioBehaviour.h"
#include "AudioMixerGroup.h"
#include "Runtime/Utilities/GUID.h"

#if UNITY_WIIU
#include "fmodwiiu.h"
#endif

#if PS4_PAD_SPEAKER
#include <user_service.h>
#define DUALSHOCK4_OUTPUT_DISABLED (-1)
#endif

struct UnityAudioSpatializerData;

inline void ReplaceOrAddSingleCurveValue(float value, AnimationCurve& curve)
{
    AnimationCurve::Keyframe key(0.0f, value);
    curve.Assign(&key, &key + 1);
}

struct VideoAudioData : public ListElement
{
    FMOD::DSP*     dsp;
    SoundChannel   channel;
    Ringbuffer     buffer;
    UInt32         channelCount;
    UInt32         sampleRate;

    bool           delayedDestroy;

    VideoAudioData(UInt32 channelCount, UInt32 sampleRate)
        : dsp(NULL)
        , buffer(kMemAudio, channelCount * sampleRate * sizeof(float))
        , channelCount(channelCount)
        , sampleRate(sampleRate)
        , delayedDestroy(false)
    {}

    ~VideoAudioData()
    {
        Assert(dsp == NULL && !channel.IsValid());
    }

    static FMOD_RESULT F_CALLBACK PCMReadCallback(FMOD_DSP_STATE *dspState, float *inBuffer, float *outBuffer, unsigned int length, int inChannels, int outChannels);

    bool InitFMOD(AudioSource* parent);
    void ReleaseFMOD();
};


class AudioSource : public AudioBehaviour
{
    REGISTER_CLASS(AudioSource);
    DECLARE_OBJECT_SERIALIZE();
public:

    /**
     * Construction/Destruction
     **/
    AudioSource(MemLabelId label, ObjectCreationMode mode);
    // virtual ~AudioSource (); declared-by-macro
    virtual void MainThreadCleanup();

    /**
     * Transport
     **/
    /// Plays a sound one time, then forgets about it (You cannot stop a one shot sound)
    void PlayOneShot(AudioClip& clip, float volumeMultiplier = 1.0F);
    /// Plays the active audioclip at (future) scheduled time. If time < 0 it specifies a delay
    void Play(double time = 0.0);
    /// Pauses the active audioclip
    void Pause();
    void UnPause();
    /// Stops the active audio clip
    void Stop(bool stopOneShots);
    /// Is the audio source currently playing? (Only looks at the main audio source, OneShots are ignored)
    bool IsPlaying() const;
    /// Is the audio source currently paused? (Only looks at the main audio source, OneShots are ignored)
    bool IsPaused() const;

    bool IsPlayingScripting();

    /// Are all channels of the audio source virtual?
    bool AreAllChannelsVirtual() const;

    // positions
    // seconds
    float GetSecPosition() const;
    void SetSecPosition(float secPosition);

    UInt32 GetSamplePosition() const;
    void SetSamplePosition(UInt32 position);
    void SetScheduledStartTime(double time);
    void SetScheduledEndTime(double time);
    void CorrectScheduledTimeAfterUnpause(UInt64 delay);

    // Get Length
    float GetLength() const;

    /// Get/Set PlayOnAwake
    bool GetPlayOnAwake() const { return m_PlayOnAwake; }
    void SetPlayOnAwake(bool playOnAwake);
    bool GetIgnoreListenerPause() const { return m_AudioParameters.ignoreListenerPause; }
    void SetIgnoreListenerPause(bool ignoreListenerPause);
    bool HasScheduledStartDelay() const { return m_HasScheduledStartDelay; }
    bool HasScheduledEndDelay() const { return m_HasScheduledEndDelay; }
    bool HasScheduledTime() const { return m_HasScheduledStartDelay || m_HasScheduledEndDelay; }

    /**
     * Behaviour implementation
     **/
    virtual void AwakeFromLoad(AwakeFromLoadMode awakeMode);
    virtual void CheckConsistency();
    virtual void Update();
    virtual void FixedUpdate();

    static void InitializeClass();
    static void CleanupClass();

    /**
     *
     **/
    void AddToManager();
    void RemoveFromManager();

    void OnAddComponent();


    virtual void Reset();

    void Cleanup();

    float CalculateDistanceAttenuation() const;

    // GET/SETTERS
    bool GetLoop() const;
    void SetLoop(bool loop);

    /// Get/Set pitch of the sound
    float GetPitch() const;
    void  SetPitch(float pitch);

    // Get/Set volume of the sound
    float GetVolume() const;
    void  SetVolume(float volume);

    // Sets how much the 3d engine has an effect on the channel.
    float GetSpatialBlendMix() const;
    void SetSpatialBlendMix(float level);

    // Sets how much the 3d engine has an effect on the channel.
    float GetReverbZoneMix() const;
    void SetReverbZoneMix(float level);

    // Sets the doppler scale for this AudioSource
    float GetDopplerLevel() const;
    void SetDopplerLevel(float level);

    // Sets the spread angle of a 3d stereo or multichannel sound in speaker space.
    // 0 = all sound channels are located at the same speaker location and is 'mono'.
    // 360 = all subchannels are located at the opposite speaker location to the speaker location that it should be according to 3D position. Default = 0.
    float GetSpread() const;
    void SetSpread(float spread);

    // Sets the priority of the [[AudioSource]]
    // Unity is virtualizing AudioSources, when there's more AudioSources playing than available hardware channels.
    // The AudioSources with lowest priority (and audibility) is virtualized first.
    // Priority is an integer between 0 and 256. 0=highest priority, 256=lowest priority
    int GetPriority() const;
    void SetPriority(int priority);

    // Un- / Mutes the AudioSource. Mute sets the volume=0, Un-Mute restore the original volume.
    bool GetMute() const;
    void SetMute(bool mute);

    // Enables or disables spatialization (if enabled in audio project settings)
    bool GetSpatialize() const;
    void SetSpatialize(bool spatialize);

    // Determines if the spatializer effect is inserted before or after the effect filters.
    bool GetSpatializePostEffects() const;
    void SetSpatializePostEffects(bool spatializePostEffects);

    inline bool IsSpatializerActive() const { return m_SpatializerDSP != NULL; }

    // Change user parameters on spatialization effect
    bool SetSpatializerFloat(int index, float value);
    bool GetSpatializerFloat(int index, float* value);

    // Within the Min distance the AudioSource will cease to grow louder in volume.
    // Outside the min distance the volume starts to attenuate.
    float GetMinDistance() const;
    void SetMinDistance(float minDistance);

    // (Logarithmic rolloff) MaxDistance is the distance a sound stops attenuating at.
    // (Linear rolloff) MaxDistance is the distance where the sound is completely inaudible.
    float GetMaxDistance() const;
    void SetMaxDistance(float maxDistance);

    /// Set/Get rolloff mode
    RolloffMode GetRolloffMode() const;
    void SetRolloffMode(RolloffMode mode);

    /// Set/Get Custom rolloff curve
    const AnimationCurve& GetCustomRolloffCurve() const;
    AnimationCurve* GetCustomRolloffCurveCopy() const;
    void SetCustomRolloffCurve(const AnimationCurve&);

    /// Set/Get spatialBlend distance curve
    AnimationCurve* GetCustomSpatialBlendCurveCopy() const;
    void SetCustomSpatialBlendCurve(const AnimationCurve&);

    /// Set/Get spread distance curve
    AnimationCurve* GetCustomSpreadCurveCopy() const;
    void SetCustomSpreadCurve(const AnimationCurve&);

    /// Set/Get reverb zone mix distance curve
    AnimationCurve* GetCustomReverbZoneMixCurveCopy() const;
    void SetCustomReverbZoneMixCurve(const AnimationCurve&);

    /// Sets a audiosource stereo pan position linearly. Only works for 2D clips.
    /// -1.0 to 1.0. -1.0 is full left. 0.0 is center. 1.0 is full right.
    /// Only sounds that are mono or stereo can be panned. Multichannel sounds (ie >2 channels) cannot be panned.
    float GetStereoPan() const;
    void SetStereoPan(float pan);

    /// Bypass/ignore any applied effects on AudioSource
    bool GetBypassEffects() const;
    void SetBypassEffects(bool bypassEffect);

    /// Bypass/ignore any applied effects on listener
    bool GetBypassListenerEffects() const;
    void SetBypassListenerEffects(bool bypassListenerEffects);

    /// Bypass effect of reverb zones on this AudioSource
    bool GetBypassReverbZones() const;
    void SetBypassReverbZones(bool bypassReverbZones);

    /// Gets the current output pcm data
    void GetOutputData(float* samples, int numSamples, int channelOffset);

    /// Gets the current spectrum data
    void GetSpectrumData(float* samples, int numSamples, int channelOffset, FMOD_DSP_FFT_WINDOW windowType);

    /// Sets the currently active audio clip
    void    SetAudioClip(AudioClip *clip);
    AudioClip *GetAudioClip() const {return m_AudioClip; }

    void SetOutputAudioMixerGroup(PPtr<AudioMixerGroup> mixerGroup);
    PPtr<AudioMixerGroup> GetOutputAudioMixerGroup() const { return m_OutputAudioMixerGroup; }

    int GetVelocityUpdateMode() const         { return m_VelocityUpdateMode; }
    void SetVelocityUpdateMode(int update) { m_VelocityUpdateMode = update; }

    bool GetIgnoreListenerVolume() const { return m_IgnoreListenerVolume; }
    void SetIgnoreListenerVolume(bool ignore);

    VideoAudioData* CreateSharedVideoAudioData(UInt32 numChannels, UInt32 sampleRate);
    void ReleaseSharedVideoAudioData(VideoAudioData* data);

    void MuteActiveVideoSinks();
    void UnmuteActiveVideoSinks();
    void KillActiveVideoSinks();

#if UNITY_WIIU
    void SetWiiUOutputDevice(FMOD_WIIU_CONTROLLER controller);
    FMOD_WIIU_CONTROLLER GetWiiUOutputDevice() const { return m_WiiUOutputDevice; }
#endif

#if PS4_PAD_SPEAKER
    bool SetPS4DualShock4OutputDevice(SceUserServiceUserId userId);
    bool SetPS4DualShock4OutputDevicePadIndex(int padIndex);

    bool SetPS4DualShock4PadSpeakerMixLevel(SceUserServiceUserId userId, int mixLevel);
    bool SetPS4DualShock4PadSpeakerMixLevelPadIndex(int padIndex, int mixLevel);

    bool SetPS4DualShock4PadSpeakerMixLevelDefault(SceUserServiceUserId userId);
    bool SetPS4DualShock4PadSpeakerMixLevelDefaultPadIndex(int padIndex);

    bool SetPS4DualShock4PadSpeakerRestrictedAudio(SceUserServiceUserId userId, bool restricted);
    bool SetPS4DualShock4PadSpeakerRestrictedAudioPadIndex(int padIndex, bool restricted);
#endif

protected:
    void SetSpatializePostEffectsGain(float gain);

private:
#if DOXYGEN
    int Priority; ///< Sets the priority of the source. A sound with a lower priority will more likely be stolen by high priorities sounds.
    float DopplerLevel; ///< Sets the specific doppler scale for the source.
    float MinDistance; ///< Within the minDistance, the volume will stay at the loudest possible.  Outside of this mindistance it begins to attenuate.
    float MaxDistance; ///< MaxDistance is the distance a sound stops attenuating at.
    float Pan2D; ///< Sets a source's pan position linearly. Only applicable on 2D sounds.

    float m_Pitch; ///< Sets the frequency of the sound. Use this to slow down or speed up the sound.
    float m_Volume; ///< Sets the volume of the sound.

    // rolloff
    RolloffMode rolloffMode; ///< enum { Logarithmic Rolloff=0, Linear Rolloff, Custom Rolloff }

    bool Loop; ///< Set the source to loop. If loop points are defined in the clip, these will be respected.
    bool Mute; ///< Mutes the sound.
    bool Spatialize; ///< Apply spatialized panning
    bool SpatializePostEffects; ///< Applies spatialization after effect filters

    bool BypassEffects; ///< Bypass/ignore any applied effects on AudioSource
    bool BypassListenerEffects; ///< Bypass/ignore any applied effects from listener
    bool BypassReverbZones; ///< Bypass/ignore any reverb zones
    bool IgnoreListenerPause; ///< Allow source to play even though AudioListener is paused (for GUI sounds)

#else
    AudioParameters m_AudioParameters;
#endif

    struct OneShot : public ListNode<OneShot>
    {
        inline OneShot() : ListNode<OneShot>(this) {}
        inline ~OneShot() { ListNode<OneShot>::RemoveFromList(); }
        SoundChannel channel;
    };

    typedef List<OneShot> TOneShots;

    TOneShots m_OneShots;

    void UpdateParameters();
    void UpdateParameters(SoundChannel channel);

    void UpdatePauseState();
    bool AnyChannelPaused();

    /**
     * Create a custom rolloff curve from old <3.0 parameters
     **/
    void CreateOpenALRolloff(float rolloffFactor, float minVolume, float maxVolume);

    /**
     * Setup effect and non-effect groups
     **/
    void CreateFMODGroups();
    void ConfigureFMODGroups();

    void SetChannelGroup(SoundChannel channel);

    /**
     * Apply filters
     **/
    void ApplyFilters();

    void UpdateEffectVirtualizationState(bool force);

    PPtr<AudioClip>        m_AudioClip;
    PPtr<AudioMixerGroup>  m_OutputAudioMixerGroup;

    ListNode<AudioSource>  m_Node;
    SoundChannel           m_Channel;

    AudioManager::AudioScheduledSource m_ScheduledSource;

    // channel group, filter/non-filter group and for oneshot
    FMOD::ChannelGroup* m_dryGroup; // No Effect unit
    FMOD::ChannelGroup* m_wetGroup; // Effect unit

    /**
     * backward compatibility props
     **/
    bool m_IgnoreListenerVolume;

    bool    m_PlayOnAwake;      ///<Play the sound when the scene loads.
    bool    m_HasScheduledStartDelay;
    bool    m_HasScheduledEndDelay;
    int     m_VelocityUpdateMode;
    Vector3f m_LastUpdatePosition;

    UInt64  m_PauseStartClock;

    // cached position
    unsigned m_samplePosition;
    // cache pause
    bool m_pause;

    void DoUpdate();
    void UpdateQueue();
    void SetupQueue();
    void AssignProps();
    float EvaluateAttenuationCurve(float distance) const;

    void Update3DPanParameters(SoundChannel channel, float distance);
    void UpdateReverbZoneMix(SoundChannel channel, float distance);
    void UpdateLowpassFilter(float distance);
    void UpdateDoppler(SoundChannel channel, float distance, Vector3f& position, Vector3f& velocity);

    void UpdateSpatializer(SoundChannel channel, float distance);

    void ForceRolloffCurveEvaluation();

    FMOD::DSP* m_PlayingDSP;
    FMOD::DSP* m_SpatializerDSP;
    UnityAudioSpatializerData* m_SpatializerData;
    typedef std::vector<FMOD::DSP*> TFilters;
    bool GetFilterComponents(TFilters &filters, bool create) const;

    void UnbindFromChannelInstance(const WeakPtr<SoundChannelInstance>& weakptr);

    typedef List<VideoAudioData> VideoAudioDataList;
    VideoAudioDataList m_SharedVideoAudioDataList;

    void CleanAudioSource(bool ignoreSharedVideoAudio = false);

#if UNITY_WIIU
    FMOD_WIIU_CONTROLLER m_WiiUOutputDevice;
#endif

#if PS4_PAD_SPEAKER
    bool m_PlayOnDualShock4;
    SceUserServiceUserId m_UserId;
#endif

    friend class AudioManager;

#if ENABLE_PROFILER
    static int s_GlobalCount;
    static int s_GlobalActiveCount;
#endif

    //Bool to hold if we should perform legacy transfer of 3D property from AudioClip
    bool m_DoLegacy3DTransfer;

private: // callbacks
    //static FMOD_RESULT F_CALLBACK channelCallback(
    //  FMOD_CHANNEL *channel, FMOD_CHANNEL_CALLBACKTYPE type, void *commanddata1, void *commanddata2);
    static float F_CALLBACK rolloffCallback(
        FMOD_CHANNEL *  channel,
        float  distance
        );

    friend class SoundChannelInstance;
};

#endif //ENABLE_AUDIO
#endif
