#include "UnityPrefix.h"
#include "AudioClip.h"
#include "Runtime/Scripting/ScriptingScopedThreadAttach.h"
#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/Audio/AudioManager.h"
#include "Runtime/Audio/sound/SoundUserData.h"

#if ENABLE_WWW
#include "Runtime/Export/WWW.h"
#endif

#if UNITY_EDITOR
#include "Editor/Src/AssetPipeline/MonoCompile.h"
#endif

/**
 * Streaming callbacks
 **/

/**
 * file callback function used by FMOD
 * we're using this to stream data from WWW stream
 **/

#if ENABLE_WWW
FMOD_RESULT F_CALLBACK AudioClip::WWWOpen(
    const char *  wwwstream,
    int  unicode,
    unsigned int *  filesize,
    void **  handle,
    void **  userdata
    )
{
    IWWWStream* stream = (IWWWStream*)wwwstream;

    if (stream)
    {
        // predict filesize
        stream->LockPartialData();
        // make sure we've read enough to determine filesize
        if (stream->GetPartialSize() == 0)
        {
            stream->UnlockPartialData();
            return FMOD_ERR_NOTREADY;
        }
        *filesize = stream->GetCapacity();
        wwwUserData* ud = new wwwUserData();
        ud->pos = 0;
        ud->filesize = *filesize;
        ud->stream = stream;
        *userdata = (void*)ud;
        *handle = (void*)wwwstream;
        stream->UnlockPartialData();

        return FMOD_OK;
    }

    return FMOD_ERR_INVALID_PARAM;
}

FMOD_RESULT F_CALLBACK AudioClip::WWWClose(
    void *  handle,
    void *  userdata
    )
{
    if (!handle)
    {
        return FMOD_ERR_INVALID_PARAM;
    }

    wwwUserData* ud = (wwwUserData*)userdata;
    delete ud;
    return FMOD_OK;
}

FMOD_RESULT F_CALLBACK AudioClip::WWWRead(
    void *  handle,
    void *  buffer,
    unsigned int  sizebytes,
    unsigned int *  bytesread,
    void *  userdata
    )
{
    if (!handle)
    {
        return FMOD_ERR_INVALID_PARAM;
    }

    wwwUserData* ud = (wwwUserData*)userdata;

    Assert(ud->stream);

    ud->stream->LockPartialData();

    // read sizebytes
    const UInt8* bufferStart = ud->stream->GetPartialData();
    unsigned avail = ud->stream->GetPartialSize();

    if (ud->pos > avail)
    {
        ud->stream->UnlockPartialData();
        return FMOD_ERR_NOTREADY;
    }

    *bytesread = avail - ud->pos < sizebytes ? (avail - ud->pos) : sizebytes;
    memcpy(buffer, bufferStart + ud->pos, *bytesread);

    // update pos
    ud->pos = ud->pos + *bytesread;

    ud->stream->UnlockPartialData();

    if (*bytesread < sizebytes)
        return FMOD_ERR_FILE_EOF;

    return FMOD_OK;
}

FMOD_RESULT F_CALLBACK AudioClip::WWWSeek(
    void *  handle,
    unsigned int  pos,
    void *  userdata
    )
{
    if (!handle)
    {
        return FMOD_ERR_INVALID_PARAM;
    }

    wwwUserData* ud = (wwwUserData*)userdata;

    Assert(ud->stream);

    ud->stream->LockPartialData();
    unsigned avail = ud->stream->GetPartialSize();

    if (avail < pos || ud->filesize < pos)
    {
        ud->stream->UnlockPartialData();
        return FMOD_ERR_FILE_COULDNOTSEEK;
    }

    ud->pos = pos;

    ud->stream->UnlockPartialData();

    return FMOD_OK;
}

#endif

/**
 * Buffer streaming callbacks
 **/

/**
 * Callbacks for PCM streaming
 **/
FMOD_RESULT F_CALLBACK AudioClip::moviepcmread(
    FMOD_SOUND *  sound,
    void *  data,
    unsigned int  datalen
    )
{
    FMOD::Sound* pSound = (FMOD::Sound*)sound;

    SoundUserData<SoundHandle::Instance>* userdata;
    pSound->getUserData((void**)&userdata);

    if (userdata == NULL)
        return FMOD_ERR_FILE_NOTFOUND;

    SoundHandle::Instance* instance = userdata->Get();
    AudioClip* ac = (AudioClip*)GetParentSampleClipFromInstance(instance);
    if (ac == NULL)
        return FMOD_ERR_FILE_NOTFOUND;

    CHECK_LEGACY_AUDIOCLIP_(ac);

    if (ac->GetQueuedAudioData(&data, datalen))
        return FMOD_OK;

    return FMOD_ERR_NOTREADY;
}

/**
 * Callbacks for PCM streaming
 **/
FMOD_RESULT F_CALLBACK AudioClip::ScriptPCMReadCallback(
    FMOD_SOUND *  sound,
    void *  data,
    unsigned int  datalen
    )
{
#if UNITY_EDITOR
    if (IsCompiling())
        return FMOD_OK;
#endif

    FMOD::Sound* pSound = (FMOD::Sound*)sound;

    SoundUserData<SoundHandle::Instance>* userdata;
    pSound->getUserData((void**)&userdata);
    if (userdata == NULL)
        return FMOD_ERR_FILE_EOF;

    SoundHandle::Instance* instance = userdata->Get();
    AudioClip* ac = (AudioClip*)GetParentSampleClipFromInstance(instance);
    if (ac == NULL)
        return FMOD_ERR_FILE_EOF;

    CHECK_LEGACY_AUDIOCLIP_(ac);

#if SUPPORT_SCRIPTING_THREADS
    ScopedThreadAttach attach(ac->m_legacy->scriptingDomain);
#endif

    AudioScriptBufferManager& scriptBufferManager = GetAudioManager().GetScriptBufferManager();
    Mutex::AutoLock lock(scriptBufferManager.GetPCMReadArrayMutex());

    // reuse mono array
    ScriptingArrayPtr array = SCRIPTING_NULL;
    scriptBufferManager.GetPCMReadArray(datalen / 4, array);

    Assert(array != SCRIPTING_NULL);

    // invoke
    ScriptingObjectPtr scriptingWrapper = Scripting::ScriptingWrapperFor(ac);
    ScriptingExceptionPtr exception;

    ScriptingInvocation invocation(scriptingWrapper, ac->m_legacy->m_CachedPCMReaderCallbackMethod);
    invocation.AddArray(array);
    invocation.objectInstanceIDContextForException = ac->GetInstanceID();
    invocation.Invoke(&exception);
    if (exception == SCRIPTING_NULL)
        memcpy(data, &Scripting::GetScriptingArrayElement<float>(array, 0), datalen);

    return FMOD_OK;
}

FMOD_RESULT F_CALLBACK AudioClip::ScriptPCMSetPositionCallback(
    FMOD_SOUND *  sound,
    int  subsound,
    unsigned int  position,
    FMOD_TIMEUNIT  postype)
{
    Assert(postype == FMOD_TIMEUNIT_PCM);

#if UNITY_EDITOR
    if (IsCompiling())
        return FMOD_OK;
#endif

    FMOD::Sound* pSound = (FMOD::Sound*)sound;

    SoundUserData<SoundHandle::Instance>* userdata;
    pSound->getUserData((void**)&userdata);
    if (userdata == NULL)
        return FMOD_ERR_FILE_COULDNOTSEEK;

    SoundHandle::Instance* instance = userdata->Get();
    AudioClip* ac = (AudioClip*)GetParentSampleClipFromInstance(instance);
    if (ac == NULL)
        return FMOD_ERR_FILE_COULDNOTSEEK;

    CHECK_LEGACY_AUDIOCLIP_(ac);

#if SUPPORT_SCRIPTING_THREADS
    ScopedThreadAttach attach(ac->m_legacy->scriptingDomain);
#endif

    // invoke
    ScriptingObjectPtr scriptingWrapper = Scripting::ScriptingWrapperFor(ac);

    ScriptingInvocation invocation(scriptingWrapper, ac->m_legacy->m_CachedSetPositionCallbackMethod);
    invocation.AddInt(position);
    invocation.objectInstanceIDContextForException = ac->GetInstanceID();
    invocation.Invoke();

    return FMOD_OK;
}
