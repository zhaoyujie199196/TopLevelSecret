#ifndef __AUDIOEFFECTINTERNAL_H__
#define __AUDIOEFFECTINTERNAL_H__

#include "Runtime/Audio/correct_fmod_includer.h"

#include "Runtime/Audio/AudioPluginInterface.h"
#include "Runtime/Audio/AudioPluginInterfaceInternal.h"
#include "Runtime/Utilities/dynamic_array.h"


// Wrapper for FMOD and Unity descriptions of effects and their parameters.
// This object is ref-counted in order to bind it to the lifetimes of AudioEffectInternalInstance and AudioEffectInternalDefinition.
// The reason we do not just use a plain pointer to FMOD_DSP_DESCRIPTION is that FMOD expects it to be accessible for the whole lifetime of
// the FMOD::DSP created from it.
struct AudioEffectInternalDescription
{
    AudioEffectInternalDescription(FMOD_DSP_TYPE from, bool* failed); // when instanced from a built-in effect
    AudioEffectInternalDescription(FMOD_DSP_DESCRIPTION* from); // when instanced from a custom effect (i.e. ducking effect in mixer)
    AudioEffectInternalDescription(UnityAudioEffectDefinition* from); // when instanced from an external plugin

    FMOD_DSP_DESCRIPTION m_fmod;
    UnityAudioEffectDefinition m_unity;

protected:
    ~AudioEffectInternalDescription();

    void AddRef()  { ++m_refcount; }
    void Release()
    {
        if (--m_refcount == 0)
        {
            this->~AudioEffectInternalDescription();
            UNITY_FREE(kMemAudio, (void*)this);
        }
    }

    int m_refcount;

    friend class AudioEffectInternalDescriptionPtr;
};

// Accessor for AudioEffectInternalDescription
class AudioEffectInternalDescriptionPtr
{
public:
    AudioEffectInternalDescriptionPtr() : m_ptr(NULL) {}
    AudioEffectInternalDescriptionPtr(const AudioEffectInternalDescriptionPtr& p) : m_ptr(p.m_ptr)
    {
        if (m_ptr)
            m_ptr->AddRef();
    }

    AudioEffectInternalDescriptionPtr(AudioEffectInternalDescription* p) : m_ptr(p)
    {
        if (m_ptr)
            m_ptr->AddRef();
    }

    ~AudioEffectInternalDescriptionPtr()
    {
        if (m_ptr)
            m_ptr->Release();
        m_ptr = NULL;
    }

    AudioEffectInternalDescription* operator->() const { return m_ptr; }

    void operator=(AudioEffectInternalDescription* p)
    {
        if (p)
            p->AddRef();
        if (m_ptr)
            m_ptr->Release();
        m_ptr = p;
    }

    void operator=(const AudioEffectInternalDescriptionPtr& p)
    {
        if (p.m_ptr)
            p.m_ptr->AddRef();
        if (m_ptr)
            m_ptr->Release();
        m_ptr = p.m_ptr;
    }

protected:
    AudioEffectInternalDescription* m_ptr;
};

// Wrapper allocated for each FMOD::DSP instance. Also the object being passed to the callbacks (hence the inheritance from UnityAudioEffectState)
struct AudioEffectInternalInstance : public UnityAudioEffectState
{
    UInt8 m_zerodata[32]; // When extending UnityAudioEffectState we keep these zero such that newer API plugins run on older versions of Unity can detect version mismatches.
    AudioEffectInternalDescriptionPtr m_desc;
    FMOD::DSP* m_dsp;
};

// Registry information for keeping track of internal FMOD and external effects.
// Also supports temporary creation for untracked effects (i.e. effects that don't show up in the mixer, such as Send/Receive/DuckVolume)
// by setting registerDefinition to false.
class AudioEffectInternalDefinition
{
public:
    AudioEffectInternalDefinition(FMOD_DSP_TYPE type);
    AudioEffectInternalDefinition(UnityAudioEffectDefinition* def, bool registerDefinition);
    ~AudioEffectInternalDefinition();

public:
    FMOD::DSP* CreateDSP(FMOD::System* system, void* effectdata, float* sideChainBuffer, UnityAudioSpatializerData** spat);
    // Calling dsp->release() will automatically free the AudioEffectInternalInstance associated with the DSP.

public:
    AudioEffectInternalDescriptionPtr m_desc;
    bool m_failed;
    bool m_used;
    FMOD_DSP_TYPE m_internalEffectType;
};

typedef dynamic_array<AudioEffectInternalDefinition*> AudioEffectInternalDefinitionArray;

AudioEffectInternalDefinition** GetAudioEffectDefinitions(int* numdefs);
AudioEffectInternalDefinition* GetAudioEffectDefinition(const char* name, AudioEffectInternalDefinition** effectDefs = NULL, int numEffectDefs = 0);
void GetAudioSpatializerDefinitions(AudioEffectInternalDefinitionArray& definitions);

#endif
