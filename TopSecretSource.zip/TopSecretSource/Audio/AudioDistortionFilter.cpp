#include "UnityPrefix.h"
#include "AudioDistortionFilter.h"

AudioDistortionFilter::AudioDistortionFilter(MemLabelId label, ObjectCreationMode mode) :
    Super(label, mode),
    m_DistortionLevel(0.5f)
{
    m_Type = FMOD_DSP_TYPE_DISTORTION;
}

void AudioDistortionFilter::Reset()
{
    Super::Reset();
    m_DistortionLevel = 0.5f;
}

void AudioDistortionFilter::ThreadedCleanup()
{}

void AudioDistortionFilter::AddToManager()
{
    Super::AddToManager();
}

void AudioDistortionFilter::CheckConsistency()
{
    Super::CheckConsistency();
    m_DistortionLevel = clamp(m_DistortionLevel, 0.0f, 1.0f);
}

void AudioDistortionFilter::Update()
{
    if (m_DSP)
        m_DSP->setParameter(FMOD_DSP_DISTORTION_LEVEL, m_DistortionLevel);
}

template<class TransferFunc>
void AudioDistortionFilter::Transfer(TransferFunc& transfer)
{
    Super::Transfer(transfer);
    TRANSFER(m_DistortionLevel);
}

IMPLEMENT_REGISTER_CLASS(AudioDistortionFilter, 170);
IMPLEMENT_OBJECT_SERIALIZE(AudioDistortionFilter);
