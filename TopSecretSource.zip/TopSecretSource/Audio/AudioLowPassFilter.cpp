#include "UnityPrefix.h"
#include "AudioLowPassFilter.h"

AudioLowPassFilter::AudioLowPassFilter(MemLabelId label, ObjectCreationMode mode) :
    Super(label, mode),
    m_LowpassResonanceQ(1.0f),
    m_NeedToNormalizeCurve(false)
{
    m_Type = FMOD_DSP_TYPE_LOWPASS;
}

void AudioLowPassFilter::ThreadedCleanup()
{}

void AudioLowPassFilter::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);

    if (m_NeedToNormalizeCurve)
    {
        AudioSource* source = QueryComponent<AudioSource>();
        if (source)
            ScaleCurveTime(m_LowpassLevelCustomCurve, 1 / source->GetMaxDistance());
    }
}

void AudioLowPassFilter::Reset()
{
    Super::Reset();

    m_LowpassResonanceQ = 1.0f;
    m_NeedToNormalizeCurve = false;

    // Curve initial values will be handled in CheckConsistency
    m_LowpassLevelCustomCurve.ResizeUninitialized(0);
    CheckConsistency();
}

void AudioLowPassFilter::AddToManager()
{
    Super::AddToManager();
}

void AudioLowPassFilter::CheckConsistency()
{
    Super::CheckConsistency();
    // @TODO get output freq from audiomanager
    m_LowpassResonanceQ = clamp(m_LowpassResonanceQ, 1.0f, 10.0f);

    if (m_LowpassLevelCustomCurve.GetKeyCount() < 1)
        ReplaceOrAddSingleCurveValue(5000.0f / 22000.0f, m_LowpassLevelCustomCurve);
}

void AudioLowPassFilter::Update()
{
    if (m_DSP)
        m_DSP->setParameter(FMOD_DSP_LOWPASS_RESONANCE, m_LowpassResonanceQ);
}

void AudioLowPassFilter::SetCutoffFrequencyInternal(float cutoffFrequency)
{
    if (m_DSP)
        m_DSP->setParameter(FMOD_DSP_LOWPASS_CUTOFF, cutoffFrequency);
}

// Sets how much the 3d engine has an effect on the channel.
float AudioLowPassFilter::GetCutoffFrequency() const
{
    AssertMsg(m_LowpassLevelCustomCurve.GetKeyCount() > 0, "AudioLowPassFilter custom cutoff curve must have at least 1 key");

    float level = m_LowpassLevelCustomCurve.GetKey(0).value;
    level = clamp01(level);

    return 10.0f + 21990.0f * level;
}

void AudioLowPassFilter::SetCutoffFrequency(float freq)
{
    float level = (freq - 10.0f) / 21990.0f;

    // As Cuttoff Freq is a curve
    // setting level resets the curve to 1 key
    level = clamp01(level);
    ReplaceOrAddSingleCurveValue(level, m_LowpassLevelCustomCurve);

    SetDirty();
}

AnimationCurve* AudioLowPassFilter::GetCustomLowpassLevelCurveCopy() const
{
    AnimationCurve* copy = UNITY_NEW(AnimationCurve, kMemAudio);

    const AnimationCurve& curve = GetCustomLowpassLevelCurve();
    copy->Assign(curve.begin(), curve.end());

    return copy;
}

const AnimationCurve& AudioLowPassFilter::GetCustomLowpassLevelCurve() const
{
    return m_LowpassLevelCustomCurve;
}

void AudioLowPassFilter::SetCustomLowpassLevelCurve(const AnimationCurve& curve)
{
    if (curve != m_LowpassLevelCustomCurve)
    {
        m_LowpassLevelCustomCurve = curve;

        float totalTime = m_LowpassLevelCustomCurve.GetRange().second;
        ScaleCurveTime(m_LowpassLevelCustomCurve, 1 / totalTime);

        SetDirty();
    }
}

template<class TransferFunc>
void AudioLowPassFilter::Transfer(TransferFunc& transfer)
{
    Super::Transfer(transfer);

    // 3.5  3: Normalized curve values
    // <3.5 2: Non-Normalized curves
    transfer.SetVersion(3);

    TRANSFER(m_LowpassResonanceQ);

    transfer.Transfer(m_LowpassLevelCustomCurve, "lowpassLevelCustomCurve");

    if (transfer.IsVersionSmallerOrEqual(2))
    {
        m_NeedToNormalizeCurve = true;
    }
}

IMPLEMENT_REGISTER_CLASS(AudioLowPassFilter, 169);
IMPLEMENT_OBJECT_SERIALIZE(AudioLowPassFilter);
