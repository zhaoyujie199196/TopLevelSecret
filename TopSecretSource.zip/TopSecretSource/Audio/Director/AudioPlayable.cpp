#include "UnityPrefix.h"
#include "AudioPlayable.h"

#if ENABLE_DIRECTOR_AUDIO

#include "Runtime/Audio/AudioManager.h"

const PointerHash kCreateNewChannelGroup = Director::hash("CreateNewChannelGroup");
const PointerHash kParentToChannelGroup = Director::hash("ParentToChannelGroup");

AudioPlayable::AudioPlayable(ScriptingObjectPtr instance)
    : Playable(instance)
    , m_ChannelGroup(0)
    , m_OwnsChannelGroup(false)
    , m_Volume(1.0f)
    , m_Pitch(1.0f)
{}

AudioPlayable::~AudioPlayable()
{
    //Currently we need to check that the AudioManager has not been shut down already.
    // This is probably not the best way to do this.
    if (m_ChannelGroup && m_OwnsChannelGroup && GetAudioManagerPtr())
    {
        CheckFMODError(m_ChannelGroup->release());
    }
}

void AudioPlayable::SetData(PointerHash hash, void* data)
{
    if (hash == kParentToChannelGroup || hash == kCreateNewChannelGroup)
    {
        if (hash == kParentToChannelGroup)
        {
            m_ChannelGroup = (FMOD::ChannelGroup*)data;
            m_OwnsChannelGroup = false;
        }
        else if (hash == kCreateNewChannelGroup)
        {
            FMOD::ChannelGroup* channelGroup = (FMOD::ChannelGroup*)data;
            CheckFMODError(GetAudioManager().GetFMODSystem()->createChannelGroup("AudioPlayable", &m_ChannelGroup));
            CheckFMODError(channelGroup->addGroup(m_ChannelGroup));
            m_OwnsChannelGroup = true;
        }

        if (m_Connections->m_Inputs.size() > 1)
            Playable::SetData(kCreateNewChannelGroup, (void*)m_ChannelGroup);
        else
            Playable::SetData(kParentToChannelGroup, (void*)m_ChannelGroup);
    }
    else
    {
        Playable::SetData(hash, data);
    }
}

//Called from the FMOD Mixer thread
void AudioPlayable::ProcessAudio(int outputPort, const EvaluationInfo& info, AudioPlayer* player, void* audioData)
{
    // Process;

    // @todo: recurse
    // foreach input in  Inputs
    //input.PrepareFrame(info, player);
}

void AudioPlayable::SetVolumeLinear(float volume)
{
    m_Volume = volume;
    ApplyVolumeInternal();
}

void AudioPlayable::SetPitch(float pitch)
{
    m_Pitch = pitch;
    ApplyPitchInternal();
}

//FIXME;
// This introduces an interesting problem. With the current design, any node can be a mixer.
// This means that any node can be the owner or the user of a channelgroup and also have control
// over the volume and pitch.
// This means that you can set the volume and pitch on a DSP effect. What should happen here?
// Should it apply the volume change at the connection mix level, or should it forward it off
// to the parent channelGroup..
// Maybe a simpler and more explicit option is to have mixer audio playables that are explicit.
// And you can set volume etc on those guys and the clip instances

void AudioPlayable::ApplyPitchInternal()
{
    //TODO Apply the pitch to the correct channelGroup...
}

void AudioPlayable::ApplyVolumeInternal()
{
    //TODO Apply the volume to the correct channelGroup...
}

#endif //ENABLE_DIRECTOR_AUDIO
