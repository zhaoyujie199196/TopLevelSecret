#include "UnityPrefix.h"
#include "AudioClipInstance.h"

#if ENABLE_DIRECTOR_AUDIO

#include "Runtime/Audio/AudioManager.h"


AudioClipInstance::AudioClipInstance(AudioClip* clip)
    : AudioPlayable(SCRIPTING_NULL)
    , m_Clip(clip)
    , m_Looped(false)
    , m_StartTime(0)
{}

AudioClipInstance::~AudioClipInstance()
{
}

void AudioClipInstance::SetData(PointerHash hash, void* data)
{
    if (hash == kParentToChannelGroup || hash == kCreateNewChannelGroup)
    {
        m_ChannelGroup = (FMOD::ChannelGroup*)data;
        m_OwnsChannelGroup = false;
    }
    else
    {
        AudioPlayable::SetData(hash, data);
    }

    AssertMsg(m_Connections->m_Inputs.size() == 0, "AudioClipInstances should have no inputs");
}

void AudioClipInstance::PrepareFrame(const EvaluationInfo& info, Playable* source)
{
}

void AudioClipInstance::ApplyVolumeInternal()
{
    //TODO: Set the volume on the Channel instead of the channelgroup..
}

#endif //ENABLE_DIRECTOR_AUDIO
