#include "UnityPrefix.h"
#include "AudioPlayer.h"

#if ENABLE_DIRECTOR_AUDIO

#include "Runtime/Audio/Director/AudioPlayable.h"
#include "Runtime/Director/Core/PlayableController.h"
#include "Runtime/Audio/AudioManager.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"

AudioPlayer::AudioPlayer(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
    , m_ChannelGroup(0)
{
}

template<class TransferFunction>
void AudioPlayer::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);
    transfer.Align();
}

void AudioPlayer::ThreadedCleanup()
{
    if (m_ChannelGroup)
    {
        CheckFMODError(m_ChannelGroup->release());
        m_ChannelGroup = 0;
    }
}

void AudioPlayer::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    if (!m_ChannelGroup)
    {
        CheckFMODError(GetAudioManager().GetFMODSystem()->createChannelGroup("AudioPlayer", &m_ChannelGroup));
        CheckFMODError(GetAudioManager().GetChannelGroup_FX_UseVolume()->addGroup(m_ChannelGroup));
    }

    //Create FMOD ChannelGroup here
    Super::AwakeFromLoad(awakeMode);
}

void AudioPlayer::GetStages(dynamic_array<StageDesc>& out_batches)
{
    StageDesc topologyCheckPass;
    StageDesc applyToFModPass;

    topologyCheckPass.stage = kUpdateStage;
    topologyCheckPass.callback = AudioPlayer::OnTopologyCheck;

    applyToFModPass.stage = kLateUpdateStage;
    applyToFModPass.callback = AudioPlayer::OnApplyToFMOD;

    out_batches.push_back(topologyCheckPass);
    out_batches.push_back(applyToFModPass);
}

void AudioPlayer::OnTopologyCheck(const dynamic_array<DirectorJob>& jobs)
{
    for (size_t a = 0; a < jobs.size(); a++)
    {
        if (jobs[a].controller->GetEvaluationInfo().TopologyChanged())
        {
            AudioPlayer* player = (AudioPlayer*)jobs[a].player;
            jobs[a].root->SetData(kParentToChannelGroup, player->m_ChannelGroup);
        }
    }
}

void AudioPlayer::OnApplyToFMOD(const dynamic_array<DirectorJob>& jobs)
{
}

IMPLEMENT_REGISTER_CLASS(AudioPlayer, 323);
IMPLEMENT_OBJECT_SERIALIZE(AudioPlayer);

#endif //ENABLE_DIRECTOR_AUDIO
