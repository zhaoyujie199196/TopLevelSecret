#pragma once

#if ENABLE_DIRECTOR_AUDIO

#include "Runtime/Director/Core/Playable.h"

namespace FMOD
{
    class ChannelGroup;
}

class AudioPlayer;

extern const PointerHash kCreateNewChannelGroup;
extern const PointerHash kParentToChannelGroup;

class AudioPlayable : public Playable
{
public:

    AudioPlayable(ScriptingObjectPtr instance);
    ~AudioPlayable();

    virtual void SetData(PointerHash hash, void* data);

    //FIXME: the inputs to this are not correct, considering this will be run on the
    // mixer thread
    virtual void ProcessAudio(int outputPort, const EvaluationInfo& info, AudioPlayer* player, void* audioData);

    float GetVolumeLinear() const { return m_Volume; }
    void  SetVolumeLinear(float volume);

    float GetPitch() const { return m_Pitch; }
    void  SetPitch(float pitch);

protected:
    virtual void ApplyPitchInternal();
    virtual void ApplyVolumeInternal();

    FMOD::ChannelGroup* m_ChannelGroup;
    bool                m_OwnsChannelGroup;

    float               m_Volume;
    float               m_Pitch;
};

#endif //ENABLE_DIRECTOR_AUDIO
