#pragma once

#if ENABLE_DIRECTOR_AUDIO

#include "Runtime/Audio/Director/AudioPlayable.h"
#include "Runtime/Audio/AudioClip.h"

namespace FMOD
{
    class ChannelGroup;
}

class AudioPlayer;

class AudioClipInstance : public AudioPlayable
{
public:
    AudioClipInstance(AudioClip* clip);
    ~AudioClipInstance();

    virtual void SetData(PointerHash hash, void* data);
    virtual void PrepareFrame(const EvaluationInfo& info, Playable* source);

    //Audio related
    GET_SET(bool,   Looped,    m_Looped);
    GET_SET(UInt64, StartTime, m_StartTime);

protected:
    virtual void ApplyVolumeInternal();

private:
    AudioClip*  m_Clip;
    bool        m_Looped;
    UInt64      m_StartTime;

    //Need channel and sound stuff here.
};

#endif //ENABLE_DIRECTOR_AUDIO
