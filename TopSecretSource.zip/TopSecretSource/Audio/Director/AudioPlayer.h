#pragma once

#if ENABLE_DIRECTOR_AUDIO

#include "Runtime/GameCode/Behaviour.h"

namespace FMOD
{
    class ChannelGroup;
}

class AudioPlayer : public Behaviour
{
    REGISTER_CLASS(AudioPlayer);
    DECLARE_OBJECT_SERIALIZE();
public:
    AudioPlayer(MemLabelId label, ObjectCreationMode mode);

    virtual void AwakeFromLoad(AwakeFromLoadMode awakeMode);

    void GetStages(dynamic_array<StageDesc>& out_batches);

    // If the topology has changed, we need to do a pass over the graph to ensure that the
    // FMOD structure is up to date.
    static void OnTopologyCheck(const dynamic_array<DirectorJob>& jobs);

    // In prepare frame we want to do calulations about weights, etc. we want a separate pass
    // to push those calulated values to FMOD.
    static void OnApplyToFMOD(const dynamic_array<DirectorJob>& jobs);

private:
    //Here we will have player data, like min max spheres, cone angles etc.

    FMOD::ChannelGroup* m_ChannelGroup;
};

#endif //ENABLE_DIRECTOR_AUDIO
