#include "UnityPrefix.h"
#if ENABLE_AUDIO
#include "AudioManager.h"
#include "AudioListener.h"
#include "AudioSource.h"
#include "AudioMixer.h"
#include "AudioMixerGroup.h"
#include "AudioReverbZone.h"
#include "AudioCustomFilter.h"
#include "Runtime/BaseClasses/ManagerContext.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Dynamics/Rigidbody.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Mono/MonoBehaviour.h"
#include "Runtime/BaseClasses/GameObject.h"
#include "Runtime/Audio/correct_fmod_includer.h"
#include "Runtime/Video/MoviePlayback.h"
#include "Runtime/Utilities/PathNameUtility.h"
#include "Runtime/VirtualFileSystem/VirtualFileSystem.h"
#include "WavReader.h"
#include "Runtime/Profiler/ProfilerStats.h"
#include "Runtime/Misc/UTF8.h"
#include "Runtime/Misc/BuildSettings.h"
#include "Runtime/Utilities/Argv.h"
#include "Runtime/Input/TimeManager.h"
#include "Runtime/Core/Callbacks/GlobalCallbacks.h"
#include "Runtime/Allocator/MemoryManager.h"
#include "Runtime/Audio/sound/SoundChannel.h"
#include "Runtime/Audio/sound/SoundManager.h"
#include "Runtime/Math/Simd/vec-math.h"
#include "Runtime/Scripting/ScriptingManager.h"
#include "Runtime/Utilities/DiagnosticSwitch.h"
#include "Runtime/Utilities/ReflectableEnum.h"

#if ENABLE_PROFILER
#include "Runtime/Threads/AtomicOps.h"
#include "Runtime/Network/PlayerCommunicator/GeneralConnection.h"
// PSP2 redefines "close" in its platform network headers
#undef close
#endif

#if UNITY_IPHONE || UNITY_TVOS
#include "External/FMOD/builds/iphone/include/fmodiphone.h"
#include <AudioToolbox/AudioFile.h>
#include <AudioToolbox/AudioQueue.h>
#include <AudioToolbox/AudioServices.h>
#include "Runtime/Misc/PlayerSettings.h"
#endif

#if UNITY_EDITOR
#include "Runtime/BaseClasses/IsPlaying.h"
#if UNITY_WIN
#include "PlatformDependent/Win/WinUnicode.h"
#endif
#include "Editor/Platform/Interface/EditorUtility.h"
#include "Editor/Src/AssetPipeline/AssetInterface.h"
#include "Runtime/Utilities/PlayerPrefs.h"
#endif

#if UNITY_PSP2
#include "PlatformDependent/PSP2Player/External/FMOD/builds/psp2/include/fmodngp.h"
#endif

#if UNITY_PS4
#include "PlatformDependent/PS4/External/FMOD/builds/ps4/include/fmodorbis.h"
#include "PlatformDependent/PS4/Source/PlatformUtils.h"
#endif

#if UNITY_ANDROID
#include "PlatformDependent/AndroidPlayer/Source/FMOD_FileIO.h"
#include "PlatformDependent/AndroidPlayer/Source/AndroidAudio.h"
#endif

#if UNITY_METRO
#include "PlatformDependent/MetroPlayer/AppCallbacks.h"
#include "PlatformDependent/MetroPlayer/MetroCapabilities.h"
#endif

#if UNITY_WIIU
#include "PlatformDependent/WiiU/Source/WiiUAudio.h"
#endif

#include "Runtime/Audio/AudioEffectInternal.h"
extern UnityAudioEffectInternal g_AudioMasterDSPInternal;

extern UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK AudioMasterDSPProcessCallback(UnityAudioEffectState* state, float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int outchannels);

#if UNITY_EDITOR
static const core::string kAudioMixerUseRMSMetering = "AudioMixerUseRMSMetering";
#endif

REFLECTABLE_FLAGS_ENUM(FMODDebugTypes,
    (None,      FMOD_DEBUG_LEVEL_NONE)
        (Logs,      FMOD_DEBUG_LEVEL_LOG)
        (Errors,    FMOD_DEBUG_LEVEL_ERROR)
        (Warnings,  FMOD_DEBUG_LEVEL_WARNING)
        (Hints,     FMOD_DEBUG_LEVEL_HINT)
        (Memory,    FMOD_DEBUG_TYPE_MEMORY)
        (Thread,    FMOD_DEBUG_TYPE_THREAD)
        (File,      FMOD_DEBUG_TYPE_FILE)
        (Network,   FMOD_DEBUG_TYPE_NET)
        (Event,     FMOD_DEBUG_TYPE_EVENT)
    );

REFLECTABLE_FLAGS_ENUM(FMODDebugDisplayOptions,
    (None,                          0)
        (DisplayTimestamps,             FMOD_DEBUG_DISPLAY_TIMESTAMPS)
        (DisplayFMODExSourceCodeRefs,   FMOD_DEBUG_DISPLAY_LINENUMBERS)
        (CollapseRepeatedMessages,      FMOD_DEBUG_DISPLAY_COMPRESS)
        (DisplayThreadIDs,              FMOD_DEBUG_DISPLAY_THREAD)
    );

DEFINE_DIAGNOSTIC_SWITCH_ENUM(FMODDebugTypes, gDiagFMODDebugTypes, "Message categories that FMOD should report to the debugger's output window.", FMODDebugTypes::None);
DEFINE_DIAGNOSTIC_SWITCH_ENUM(FMODDebugDisplayOptions, gDiagFMODDebugDisplayOptions, "Options that control how FMOD's debug output messages are formatted.", FMODDebugDisplayOptions::DisplayTimestamps | FMODDebugDisplayOptions::DisplayThreadIDs);

// this global is used instead of GetAudioManagerPtr() because the FMod thread does allocations
// before the AudioManager pointer is set in the ManagerContext on startup. this lead to GetAudioManagerPtr()
// returning zero inside FMODMemoryAlloc().
static AudioManager* gAudioManager = 0;

static MemLabelId GetLabelForMemoryType(FMOD_MEMORY_TYPE type)
{
    MemLabelId label;
    switch (type & 0x0000FFFF) //Clear out the top word which does not contain information we want.
    {
        case FMOD_MEMORY_STREAM_FILE:
        case FMOD_MEMORY_STREAM_DECODE:
            label = kMemFMODStream;
            break;
        case FMOD_MEMORY_SAMPLEDATA:
            label = kMemFMODSample;
            break;
        case FMOD_MEMORY_DSP_OUTPUTBUFFER:
            label = kMemFMODExtraDSP;
            break;
        default:
            label = kMemFMOD;
    }

    return label;
}

//Allocations
void*  F_CALLBACK FMODMemoryAlloc(unsigned int size, FMOD_MEMORY_TYPE type, const char *sourcestr)
{
    Assert(!gAudioManager->IsAudioDisabledInStandalone());

#if ENABLE_MEM_PROFILER
    bool haveAllocationOwner = HAS_ROOT_REFERENCE(GET_CURRENT_ALLOC_ROOT_REFERENCE());
#else
    bool haveAllocationOwner = false;
#endif
    if (!haveAllocationOwner)
    {
        SET_ALLOC_OWNER(gAudioManager);
        return UNITY_MALLOC_ALIGNED(GetLabelForMemoryType(type), size, 16);
    }
    else
        return UNITY_MALLOC_ALIGNED(GetLabelForMemoryType(type), size, 16);
}

void F_CALLBACK FMODMemoryFree(void *ptr, FMOD_MEMORY_TYPE type, const char *sourcestr);

void*  F_CALLBACK FMODMemoryRealloc(void *ptr, unsigned int size, FMOD_MEMORY_TYPE type, const char *sourcestr)
{
    Assert(!gAudioManager->IsAudioDisabledInStandalone());

    return UNITY_REALLOC_ALIGNED(GetLabelForMemoryType(type), ptr, size, 16);
}

void  F_CALLBACK FMODMemoryFree(void *ptr, FMOD_MEMORY_TYPE type, const char *sourcestr)
{
    Assert(!gAudioManager->IsAudioDisabledInStandalone());

    UNITY_FREE(GetLabelForMemoryType(type), ptr);
}

#if ENABLE_PROFILER
static volatile int s_FMOD_FileAccessor_GlobalCount = 0;
#endif

//File systems
FMOD_RESULT F_CALLBACK FMOD_FILE_Open(const char *name, int unicode, unsigned int *filesize, void **handle, void **userdata)
{
    Assert(!gAudioManager->IsAudioDisabledInStandalone());

    FileAccessor* reader = UNITY_NEW(FileAccessor, kMemAudio);
    if (!reader)
        return FMOD_ERR_MEMORY;

#if ENABLE_PROFILER
    AtomicIncrement(&s_FMOD_FileAccessor_GlobalCount);
#endif

    if (!reader->Open(PathToAbsolutePath(name).c_str(), kReadPermission))
    {
        UNITY_DELETE(reader, kMemAudio);
        return FMOD_ERR_FILE_NOTFOUND;
    }

    if (filesize)
        *filesize = (unsigned int)reader->Size();

    if (handle)
        *handle = reader;

    return FMOD_OK;
}

FMOD_RESULT F_CALLBACK FMOD_FILE_Close(void *handle, void *userdata)
{
    Assert(!gAudioManager->IsAudioDisabledInStandalone());

    FileAccessor* reader = static_cast<FileAccessor*>(handle);

    FMOD_RESULT result = FMOD_OK;

    if (!(reader && reader->Close()))
        result = FMOD_ERR_FILE_BAD;

    UNITY_DELETE(reader, kMemAudio);

#if ENABLE_PROFILER
    AtomicDecrement(&s_FMOD_FileAccessor_GlobalCount);
#endif

    return result;
}

FMOD_RESULT F_CALLBACK FMOD_FILE_Read(void *handle, void *buffer, unsigned int sizebytes, unsigned int *bytesread, void *userdata)
{
    Assert(!gAudioManager->IsAudioDisabledInStandalone());

    FileAccessor* reader = static_cast<FileAccessor*>(handle);

    if (!reader)
        return FMOD_ERR_INTERNAL;

    UInt64 actual = 0;
    if (!reader->Read((UInt64)sizebytes, buffer, &actual))
        return FMOD_ERR_FILE_BAD;

    if (bytesread)
        *bytesread = (unsigned int)actual;

    //Necessary to handle wierdness inside FMOD with EOF
    if (actual < (UInt64)sizebytes)
        return FMOD_ERR_FILE_EOF;

    return FMOD_OK;
}

FMOD_RESULT F_CALLBACK FMOD_FILE_Seek(void *handle, unsigned int pos, void *userdata)
{
    Assert(!gAudioManager->IsAudioDisabledInStandalone());

    FileAccessor* reader = static_cast<FileAccessor*>(handle);

    if (!reader)
        return FMOD_ERR_INTERNAL;

    if (!reader->Seek((UInt64)pos, kBeginning))
        return FMOD_ERR_FILE_BAD;

    return FMOD_OK;
}

#if 0
FMOD_RESULT F_CALLBACK FMOD_FILE_AsyncRead(FMOD_ASYNCREADINFO* info, void* userdata)
{
    Assert(!gAudioManager->IsAudioDisabledInStandalone());
}

FMOD_RESULT F_CALLBACK FMOD_FILE_AsyncCancel(void* handle, void* userdata)
{
    Assert(!gAudioManager->IsAudioDisabledInStandalone());
}

#endif


float AudioMeasurement_GetTimeConstant(float accuracy, float numSamples)
{
    /*
     Derivation of time constant from transition length specified as numSamples and desired accuracy within which target is reached:

     y(n) = y(n-1) + [x(n) - y(n-1)] * alpha
     y(0) = 1, x(n) = 0   =>
     y(1) = 1 + [0 - 1] * alpha = 1-alpha
     y(2) = 1-alpha + [0 - (1-alpha)] * alpha = (1-alpha)*(1-alpha) = (1-alpha)^2
     y(3) = (1-alpha)^2 + [0 - (1-alpha)^2] * alpha = (1-alpha) * (1-alpha)^2 = (1-alpha)^3
     ...
     y(n) = (1-alpha)^n = 1-accuracy   =>
     1-alpha = (1-accuracy)^(1/n)
     alpha = 1 - (1-accuracy)^(1/n)
     */
    if (numSamples <= 0.0f)
        return 1.0f;
    return 1.0f - (float)math::powr(math::float1(1.0f - accuracy), math::float1(1.0f / numSamples));
}

extern double GetTimeSinceStartup();

// ---------------------------------------------------------------------------

void AudioManager::InitializeClass()
{
#if UNITY_EDITOR
    RegisterAllowNameConversion(TypeOf<AudioManager>()->GetName(), "iOS DSP Buffer Size", "m_DSPBufferSize");
#endif
}

void AudioManager::CleanupClass()
{
}

AudioManager::AudioManager(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
    , m_Volume(1.0f)
    , m_IsPaused(false)
    , m_IsApplicationPaused(false)
    , m_FMODSystem(NULL)
    , m_ChannelGroup_FMODMaster(NULL)
    , m_ChannelGroup_FX_IgnoreVolume(NULL)
    , m_ChannelGroup_FX_UseVolume(NULL)
    , m_ChannelGroup_NoFX_IgnoreVolume(NULL)
    , m_ChannelGroup_NoFX_UseVolume(NULL)
#if PS4_PAD_SPEAKER
    , m_DualShock4Speaker()
#endif
    , m_driverCaps(0)
    , m_speakerModeCaps(FMOD_SPEAKERMODE_STEREO)
    , m_activeSpeakerMode(FMOD_SPEAKERMODE_STEREO)
    , m_activeSampleRate(0)
    , m_activeDSPBufferSize(0)
    , m_activeVirtualVoiceCount(512)
    , m_activeRealVoiceCount(32)
    , m_activeVirtualizeEffects(false)
    , m_accPausedTicks(0)
    , m_pauseStartTicks(0)
    , m_DefaultDSPBufferSize(0)
    , m_SoundManager(NULL)
    , m_PendingAudioConfigurationCallback(false)
    , m_DeviceChanged(false)
    , m_DeviceChangeNeedsReset(false)
    , m_InvokeOnAudioConfigurationChangedRecursionDepth(0)
    , m_MasterDSP(NULL)
    , m_ProfilerCaptureFlags(AudioProfilerCaptureFlags_Channels)
    , m_ScriptBufferManager(NULL)
#if UNITY_EDITOR
    , m_ResetAllAudioClipPlayCountsOnPlay(false)
    , m_MasterGroupMute(false)
    , m_IsUsingRMSMetering(true)
    , m_MasterGroupFade(1.0f)
    , m_MasterGroupLevel(0.0f)
    , m_MasterGroupClipping(0.0f)
    , m_ChannelGroup_Preview(NULL)
    , m_EditingInPlaymode(false)
#endif
#if ENABLE_AUDIO_MANAGER_BASED_SCHEDULING
    , m_lastDSPClock(0)
#endif
{
    // Zero this to indicate that we are using the default audio device to start.
    memset(&m_DefaultOutputDriver, 0, sizeof(FMOD_GUID));

    gAudioManager = this;
#if ENABLE_MICROPHONE
    m_MicAudioClips.clear();
#endif

    GlobalCallbacks::Get().didReloadMonoDomain.Register(&AudioManager::DidReloadDomain);
#if UNITY_EDITOR
    GlobalCallbacks::Get().beforeDomainUnload.Register(&AudioManager::BeforeDomainUnload);
#endif
}

void AudioManager::Reset()
{
    Super::Reset();

    m_DefaultVolume = 1.0f;
    m_Rolloffscale = 1.0f;
    m_DopplerFactor = 1.0f;
    m_speakerMode = FMOD_SPEAKERMODE_STEREO;
    m_SampleRate = 0;
    m_DSPBufferSize = 0;
    m_VirtualVoiceCount = 512;
    m_RealVoiceCount = 32;
    m_SpatializerPlugin = "";
    m_DisableAudio = false;
    m_VirtualizeEffects = true;
    memset(&m_DefaultRecordingDriver, 0, sizeof(FMOD_GUID));
    memset(&m_DefaultOutputDriver, 0, sizeof(FMOD_GUID));
}

void AudioManager::ThreadedCleanup()
{
}

void AudioManager::MainThreadCleanup()
{
    m_ReverbZones.clear();
    m_Sources.clear();
    m_Listeners.clear();
    m_ScheduledSources.clear();
    m_Mixers.clear();

    if (m_FMODSystem != NULL)
    {
        CloseFMOD();
        m_FMODSystem->release();
        m_FMODSystem = NULL;
    }

    if (m_ScriptBufferManager)
    {
        delete m_ScriptBufferManager;
        m_ScriptBufferManager = NULL;
    }

    for (int n = 0; n < m_AudioEffectInternalDefs.size(); n++)
    {
        UNITY_DELETE(m_AudioEffectInternalDefs[n], kMemAudio);
    }

    m_AudioEffectInternalDefs.clear();

    Super::MainThreadCleanup();
    gAudioManager = 0;
}

bool AudioManager::ValidateFMODResult(FMOD_RESULT result, const char* errmsg)
{
    if (result != FMOD_OK)
    {
        m_LastErrorString = FMOD_ErrorString(result);
        m_LastFMODErrorResult = result;
        ErrorString(core::string(errmsg) + m_LastErrorString);
        return false;
    }
    return true;
}

#if UNITY_METRO
namespace FMOD
{
    delegate void FMODAppCallbackItem();
    extern void(*FMODInvokeOnUIThread) (FMODAppCallbackItem^ item, bool waitUntilDone);
} // namespace FMOD

void _FMODInvokeOnUIThread(FMOD::FMODAppCallbackItem^ item, bool waitUntilDone)
{
    UnityPlayer::AppCallbacks::Instance->InvokeOnUIThread(ref new UnityPlayer::AppCallbackItem(item), waitUntilDone);
}

#endif // UNITY_METRO

#if UNITY_EDITOR
void AudioManager::EditorMasterDSPCallback(float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int outchannels)
{
    float tc = AudioMeasurement_GetTimeConstant(0.99f, 0.3f * g_AudioMasterDSPInternal.samplerate);
    float fadetarget = m_MasterGroupMute ? 1.0e-11f : 1.0f;
    length *= inchannels;
    for (int n = 0; n < length; n++)
    {
        float x = inbuffer[n] * m_MasterGroupFade;
        float ax = fabsf(x);
        outbuffer[n] = math::clamp(x, -1.0f, 1.0f);
        m_MasterGroupLevel += (ax * ax - m_MasterGroupLevel) * tc + 1.0e-11f;
        m_MasterGroupClipping += ((ax > 1.0f ? 1.0f : 0.0f) - m_MasterGroupClipping) * tc + 1.0e-11f;
        m_MasterGroupFade += (fadetarget - m_MasterGroupFade) * tc + 1.0e-11f;
    }
}

#endif

PROFILER_INFORMATION(gInitFMOD, "Init FMOD", kProfilerLoading)

bool AudioManager::InitFMOD()
{
    PROFILER_AUTO(gInitFMOD, NULL);

    if (IsAudioDisabledInStandalone())
        return false;

    FMOD_RESULT result;

    // Make sure the debug level API is supported (only logging-versions of FMOD have this).
    FMOD_DEBUGLEVEL oldDebugLevel = 0;
    if (FMOD::Debug_GetLevel(&oldDebugLevel) == FMOD_OK)
    {
        FMOD_DEBUGLEVEL newDebugLevel = (FMODDebugTypes)gDiagFMODDebugTypes | (FMODDebugDisplayOptions)gDiagFMODDebugDisplayOptions;
        if (newDebugLevel != oldDebugLevel)
        {
            result = FMOD::Debug_SetLevel(newDebugLevel);
            if (result == FMOD_ERR_UNSUPPORTED)
                ErrorString("This version of FMOD does not support debug output. Please rebuild Unity with the Debug (-D postfixed) version of the FMOD libraries, or turn off the FMOD logging switches.");
        }
    }

    if (!m_FMODSystem) // not loaded yet
    {
        #if UNITY_METRO
        FMOD::FMODInvokeOnUIThread = _FMODInvokeOnUIThread;
        #endif

        FMOD::Memory_Initialize(NULL, 0, FMODMemoryAlloc, FMODMemoryRealloc, FMODMemoryFree);
        result = FMOD::System_Create(&m_FMODSystem);          // Create the main system object.
        if (!ValidateFMODResult(result, "FMOD failed to initialize ... "))
            return false;
        //#if UNITY_ANDROID
        //  m_FMODSystem->setFileSystem(FMOD_FileOpen, FMOD_FileClose, FMOD_FileRead, FMOD_FileSeek, 0,0,-1);
        //#endif
        m_FMODSystem->setFileSystem(FMOD_FILE_Open, FMOD_FILE_Close, FMOD_FILE_Read, FMOD_FILE_Seek, 0, 0, -1);
    }

    unsigned int version = 0;
    CheckFMODError(m_FMODSystem->getVersion(&version));

    // 64k for streaming buffer sizes - we're streaming from memory so this should be sufficient
    // when we're streaming from a www/movie class, buffer sizes are set independently
    result = m_FMODSystem->setStreamBufferSize(64000, FMOD_TIMEUNIT_RAWBYTES);
    if (!ValidateFMODResult(result, "FMOD failed to initialize ... "))
        return false;

    // Setup system callbacks
    result = m_FMODSystem->setCallback(AudioManager::systemCallback);
    if (!ValidateFMODResult(result, "FMOD failed to setup system callbacks ... "))
        return false;

    // Setup channel callbacks
    result = m_FMODSystem->set3DRolloffCallback(AudioSource::rolloffCallback);
    if (!ValidateFMODResult(result, "FMOD failed to setup channel callbacks ... "))
        return false;

    if (!InitNormal())
    {
        // Initialization failed hard. Don't even audio.
        CloseFMOD();
        m_FMODSystem->release();
        m_FMODSystem = NULL;
#if !UNITY_EDITOR
        m_DisableAudio = true;
#endif
        return false;
    }

    // setup channel groups

    Assert(m_ChannelGroup_FMODMaster == NULL);
    result = m_FMODSystem->getMasterChannelGroup(&m_ChannelGroup_FMODMaster);
    if (!ValidateFMODResult(result, "FMOD failed to setup channel groups ... "))
        return false;

    // MasterDSP effect at the very root of the mixing graph. This serves two purposes:
    // 1) It updates global information from the host such as samplerate, current DSP tick and global flags
    // 2) It performs clip detection, metering and hard clipping in the editor. Hard clipping causes problems with levels that are too hot noticeable during development of the game.
    // The problem here is that platforms such as the Mac have a built-in limiter which prevents audio signals outside the [-1..1] range from causing clipping.
    // However, on Windows there is no such built-in clipper (or at least it depends on the driver), so if a user authors a game on Mac that sounds fine it could sound
    // horribly clipped on Windows. Therefore it is better to make clipping really obvious by having the same hardclipping DSP on both the Mac and Win editors.
    // We could consider enabling this for other platforms too, but since some platforms like the Wii use hardware mixing, I only enabled this for the mixer for now.

    int samplerate = 0;
    m_FMODSystem->getSoftwareFormat(&samplerate, NULL, NULL, NULL, NULL, NULL);
    g_AudioMasterDSPInternal.samplerate = samplerate;

    m_FMODSystem->getDSPBufferSize(&g_AudioMasterDSPInternal.dspbuffersize, NULL);

    unsigned clockLo, clockHi;
    m_FMODSystem->getDSPClock(&clockHi, &clockLo);
    g_AudioMasterDSPInternal.currdsptick = ((UInt64)clockHi << 32) + clockLo;

    UnityAudioEffectDefinition effectdef;
    memset(&effectdef, 0, sizeof(effectdef));
    memcpy(effectdef.name, "MasterDSP", 10);
    effectdef.structsize = sizeof(UnityAudioEffectDefinition);
    effectdef.paramstructsize = sizeof(UnityAudioParameterDefinition);
    effectdef.process = AudioMasterDSPProcessCallback;

    AudioEffectInternalDefinition internalDef(&effectdef, false);
    m_MasterDSP = internalDef.CreateDSP(m_FMODSystem, &g_AudioMasterDSPInternal, NULL, NULL);
    Assert(m_MasterDSP != NULL);
    CheckFMODError(m_ChannelGroup_FMODMaster->addDSP(m_MasterDSP, NULL));

#if UNITY_EDITOR
    Assert(m_ChannelGroup_Preview == NULL);
    result = m_FMODSystem->createChannelGroup("Preview", &m_ChannelGroup_Preview);
    if (!ValidateFMODResult(result, "FMOD failed to setup channel groups ... "))
        return false;
#endif

    Assert(m_ChannelGroup_FX_IgnoreVolume == NULL);
    result = m_FMODSystem->createChannelGroup("FX_IgnoreVol", &m_ChannelGroup_FX_IgnoreVolume);
    if (!ValidateFMODResult(result, "FMOD failed to setup channel groups ... "))
        return false;

    Assert(m_ChannelGroup_FX_UseVolume == NULL);
    result = m_FMODSystem->createChannelGroup("FX_UseVol", &m_ChannelGroup_FX_UseVolume);
    if (!ValidateFMODResult(result, "FMOD failed to setup channel groups ... "))
        return false;

    Assert(m_ChannelGroup_NoFX_IgnoreVolume == NULL);
    result = m_FMODSystem->createChannelGroup("NoFX_IgnoreVol", &m_ChannelGroup_NoFX_IgnoreVolume);
    if (!ValidateFMODResult(result, "FMOD failed to setup channel groups ... "))
        return false;

    Assert(m_ChannelGroup_NoFX_UseVolume == NULL);
    result = m_FMODSystem->createChannelGroup("NoFX_UseVol", &m_ChannelGroup_NoFX_UseVolume);
    if (!ValidateFMODResult(result, "FMOD failed to setup channel groups ... "))
        return false;

    result = m_ChannelGroup_FMODMaster->addGroup(m_ChannelGroup_FX_IgnoreVolume);
    if (!ValidateFMODResult(result, "FMOD failed to setup channel groups ... "))
        return false;

    result = m_ChannelGroup_FX_IgnoreVolume->addGroup(m_ChannelGroup_FX_UseVolume);
    if (!ValidateFMODResult(result, "FMOD failed to setup channel groups ... "))
        return false;

    result = m_ChannelGroup_FMODMaster->addGroup(m_ChannelGroup_NoFX_IgnoreVolume);
    if (!ValidateFMODResult(result, "FMOD failed to setup channel groups ... "))
        return false;

    result = m_ChannelGroup_NoFX_IgnoreVolume->addGroup(m_ChannelGroup_NoFX_UseVolume);
    if (!ValidateFMODResult(result, "FMOD failed to setup channel groups ... "))
        return false;

    FixMasterGroupRouting();

    m_activeSampleRate = m_SampleRate;
    m_activeDSPBufferSize = m_DSPBufferSize;
    m_activeSpeakerMode = m_speakerMode;
    m_activeVirtualVoiceCount = m_VirtualVoiceCount;
    m_activeRealVoiceCount = m_RealVoiceCount;
    m_activeVirtualizeEffects = m_VirtualizeEffects;

    m_SoundManager = UNITY_NEW(SoundManager, kMemAudio);

    return true;
}

// We need to re-route the global SFX Reverb and preview groups to the tail of the master group, so that they route the reverb signal through the AudioMasterDSPCallback too
// (otherwise Scene View audio mute and correct signal level measurement won't work)
void AudioManager::FixMasterGroupRouting()
{
    if (!m_FMODSystem)
        return;

    // Need to synchronize FMOD graph if this happens right after we performed a change (such as adding a reverb zone)
    m_FMODSystem->update();

    FMOD::DSP* dspMaster = NULL;
    CheckFMODError(m_ChannelGroup_FMODMaster->getDSPHead(&dspMaster));
    if (dspMaster == NULL)
        return;

    FMOD::DSP* dspMasterParent = NULL;
    CheckFMODError(dspMaster->getOutput(0, &dspMasterParent, NULL));
    if (dspMasterParent == NULL)
        return;

    FMOD::DSP* dspTarget = NULL;
    CheckFMODError(dspMaster->getInput(0, &dspTarget, NULL)); // Get MasterDSP unit
    if (dspTarget == NULL)
        return;
    CheckFMODError(dspTarget->getInput(0, &dspTarget, NULL)); // Get FMOD master group tail
    if (dspTarget == NULL)
        return;

    char namebuf[64];
    int numInputs = 0;
    CheckFMODError(dspMasterParent->getNumInputs(&numInputs));
    for (int n = 0; n < numInputs; n++)
    {
        FMOD::DSP* dspToBeRerouted = NULL;
        CheckFMODError(dspMasterParent->getInput(n, &dspToBeRerouted, NULL));
        if (dspToBeRerouted == NULL)
            continue;
        CheckFMODError(dspToBeRerouted->getInfo(namebuf, NULL, NULL, NULL, NULL));
        if (memcmp(namebuf, "SFX Reverb", 11) == 0)
        {
            CheckFMODError(dspToBeRerouted->disconnectAll(false, true));
            CheckFMODError(dspTarget->addInput(dspToBeRerouted, NULL));
        }
    }
}

void AudioManager::InitScriptBufferManager()
{
    if (m_ScriptBufferManager == 0)
    {
        m_ScriptBufferManager = new AudioScriptBufferManager();
    }
}

void AudioManager::ShutdownReinitializeAndReload()
{
    if (!m_FMODSystem)
        return;

    CloseFMOD();
    InitFMOD();

    // reload any loaded audio clips
    {
        dynamic_array<AudioClip*> audioClips(kMemTempAlloc);
        Object::FindObjectsOfType(audioClips);
        for (size_t i = 0; i < audioClips.size(); ++i)
            audioClips[i]->Reload();
    }

    // Awake sources
    {
        dynamic_array<AudioSource*> audioSources(kMemTempAlloc);
        Object::FindObjectsOfType(audioSources);
        for (size_t i = 0; i < audioSources.size(); ++i)
            audioSources[i]->AwakeFromLoad(kDefaultAwakeFromLoad);
    }

    // reload listener filters (if any)
    TAudioListenersIterator i = m_Listeners.begin();
    for (; i != m_Listeners.end(); ++i)
    {
        AudioListener& curListener = **i;
        curListener.ApplyFilters();
    }

    // Recreate Filters on Monobehaviours
    dynamic_array<MonoBehaviour*> monoBehaviours(kMemTempAlloc);
    Object::FindObjectsOfType(monoBehaviours);
    for (size_t i = 0; i < monoBehaviours.size(); ++i)
    {
        MonoBehaviour* behaviour = monoBehaviours[i];
        FMOD::DSP* dsp = behaviour->GetOrCreateDSP();
        if (dsp)
        {
            AudioCustomFilter* customFilter = NULL;
            FMOD_RESULT result;
            CheckFMODError(result = dsp->getUserData((void**)&customFilter));
            if (result == FMOD_OK)
                CheckFMODError(dsp->setBypass(customFilter->m_SavedBypassState));
            else
                CheckFMODError(dsp->setBypass(!behaviour->GetEnabled()));
        }
    }

    // reload reverb zones (if any)
    TAudioReverbZonesIterator j = m_ReverbZones.begin();
    for (; j != m_ReverbZones.end(); ++j)
    {
        AudioReverbZone& curReverbZone = **j;
        curReverbZone.Init();
    }

    // We handle this here as this function may get called from a number of places (changing global audio settings in inspector, AudioSettings.Reset or caused by external device changes).
    m_PendingAudioConfigurationCallback = true;
    HandlePendingAudioConfigurationCallback();
}

void AudioManager::HandlePendingAudioConfigurationCallback()
{
#if UNITY_EDITOR
    // Only do this in play mode, as this function also gets called by AwakeFromLoad which is called by ManagerBackup::ResetUserEditableManagers when the editor goes out of play mode.
    // In this case, if the user has not unregistered the callback, it will try to call it on the now invalidated mono object.
    if (!IsWorldPlaying())
        return;
#endif

    if (!m_PendingAudioConfigurationCallback)
        return;

    m_PendingAudioConfigurationCallback = false;

    bool deviceWasChanged = m_DeviceChanged;
    m_DeviceChanged = false;

    // We allow a maximal recursion depth of 2 which can happen if the game needs to further tweak the audio configuration in response to an externally triggered configuration change (HDMI monitor or USB headset connected/disconnected).
    if (++m_InvokeOnAudioConfigurationChangedRecursionDepth > 2)
    {
        ErrorString("It appears that OnAudioConfigurationChanged is being called recursively and therefore the calls have been aborted after two recursions. Use the deviceWasChanged argument to only call AudioSettings.SetConfiguration in response to device changes.");
    }
    else
    {
        GlobalCallbacks::Get().audioConfigurationChanged.Invoke();

        ScriptingExceptionPtr exception = SCRIPTING_NULL;
        ScriptingInvocation invocation(GetAudioScriptingClasses().invokeOnAudioConfigurationChanged);
        invocation.AddBoolean(deviceWasChanged);
        invocation.Invoke(&exception);
    }
    --m_InvokeOnAudioConfigurationChangedRecursionDepth;
}

double AudioManager::GetDSPTime() const
{
    if (!m_FMODSystem)
        return 0.0;

    int sampleRate;
    m_FMODSystem->getSoftwareFormat(&sampleRate, NULL, NULL, NULL, NULL, NULL);
    if (m_IsApplicationPaused || m_IsPaused)
        return (double)(m_pauseStartTicks - m_accPausedTicks) / (double)sampleRate;

    unsigned clockLo, clockHi;
    m_FMODSystem->getDSPClock(&clockHi, &clockLo);

    return (double)(((UInt64)clockHi << 32) + clockLo - m_accPausedTicks) / (double)sampleRate;
}

UInt64 AudioManager::GetRealDSPTime() const
{
    if (!m_FMODSystem)
        return 0;

    unsigned clockLo, clockHi;
    m_FMODSystem->getDSPClock(&clockHi, &clockLo);
    return ((((UInt64)clockHi << 32) + clockLo));
}

UInt32 AudioManager::GetNumDevices() const
{
    if (!m_FMODSystem)
        return 0;

    int numDrivers = 0;
    CheckFMODError(m_FMODSystem->getNumDrivers(&numDrivers));

    return (UInt32)numDrivers;
}

#if UNITY_LINUX
static void LogDriverDetails(FMOD::System *system, int driverID)
{
    char driverName[BUFSIZ];
    FMOD_GUID guid;
    FMOD_OUTPUTTYPE output;
    char *outputName;

    system->getOutput(&output);
    system->getDriverInfo(driverID, driverName, BUFSIZ, &guid);

    switch (output)
    {
        case FMOD_OUTPUTTYPE_PULSEAUDIO:
            outputName = "PulseAudio";
            break;
        case FMOD_OUTPUTTYPE_ALSA:
            outputName = "ALSA";
            break;
        case FMOD_OUTPUTTYPE_OSS:
            outputName = "OSS";
            break;
        case FMOD_OUTPUTTYPE_ESD:
            outputName = "ESD";
            break;
        default:
            outputName = "Unknown";
            break;
    }
    printf_console("AudioManager: Using %s: %s\n", outputName, driverName);
}

#endif

bool AudioManager::InitNormal()
{
    CheckConsistency();

    // Get available sound cards
    // If no device is found fall back on the NOSOUND driver
    // @TODO Enable user to choose driver
    int numDrivers;
    FMOD_RESULT result = m_FMODSystem->getNumDrivers(&numDrivers);
    if (!ValidateFMODResult(result, "FMOD failed to get number of drivers ... "))
        numDrivers = 0; // Since we cannot load any set the num drivers to 0

    bool disableAudio = (0 == numDrivers); // no suitable audio devices/drivers
#if !UNITY_EDITOR
    disableAudio = disableAudio || m_DisableAudio; // audio is disabled in the player
#if UNITY_LINUX
    disableAudio = disableAudio || !ENABLE_SDL2; // linux headless player
#endif
#endif

    if (disableAudio)
    {
        result = m_FMODSystem->setOutput(FMOD_OUTPUTTYPE_NOSOUND);
        if (!ValidateFMODResult(result, "FMOD failed to initialize nosound device ... "))
            return false;
    }
#if UNITY_PS4
    else
    {
        extern bool g_UseAudio3dBackend;
        if (g_UseAudio3dBackend)
        {
            printf_console("Switching FMOD to Audio3d output backend (Morpheus HRTF support)\n");
            result = m_FMODSystem->setOutput(FMOD_OUTPUTTYPE_AUDIO3D);
            if (!ValidateFMODResult(result, "FMOD failed to initialize audio3d device ... "))
                return false;
        }
    }
#endif

    // get driver id
    int driverID;
    m_FMODSystem->getDriver(&driverID);

    // setup speakermode
    // check if current hw is capable of the current speakerMode
    result = m_FMODSystem->getDriverCaps(driverID, &m_driverCaps, 0, &m_speakerModeCaps);
    if (!ValidateFMODResult(result, "FMOD failed to get driver capabilities ... "))
        return false;

    m_activeSampleRate = m_SampleRate;
    m_activeDSPBufferSize = m_DSPBufferSize;
    m_activeSpeakerMode = m_speakerMode;
    m_activeVirtualVoiceCount = m_VirtualVoiceCount;
    m_activeRealVoiceCount = m_RealVoiceCount;
    m_activeVirtualizeEffects = m_VirtualizeEffects;

#if UNITY_WIIU
    // For Wii U we modify caps so it's the best of what is selected for TV and DRC
    if (!disableAudio)
        m_speakerModeCaps = cafe::DetermineMinimalSpeakerMode(m_speakerModeCaps);
#endif


#if UNITY_PS4
    {
        extern bool g_UseAudio3dBackend;
        extern int g_Audio3dVirtualSpeakerCount;
        if (g_UseAudio3dBackend)
        {
            m_activeSpeakerMode = FMOD_SPEAKERMODE_VIRTUAL14;
            if (g_Audio3dVirtualSpeakerCount == 12)
                m_activeSpeakerMode = FMOD_SPEAKERMODE_VIRTUAL12;
            if (g_Audio3dVirtualSpeakerCount == 8)
                m_activeSpeakerMode = FMOD_SPEAKERMODE_VIRTUAL8;
            printf_console("Setting FMOD to mix to %d virutal speakers for Audio3d.\n", m_activeSpeakerMode == FMOD_SPEAKERMODE_VIRTUAL14 ? 14 : (m_activeSpeakerMode == FMOD_SPEAKERMODE_VIRTUAL12 ? 12 : 8));
        }
    }
#else
    if (m_speakerModeCaps < m_activeSpeakerMode)
    {
        if (m_activeSpeakerMode != FMOD_SPEAKERMODE_SRS5_1_MATRIX)
            // hardware is not capable of the current speakerMode
            m_activeSpeakerMode = m_speakerModeCaps;
    }
#endif

    FMOD_INITFLAGS initFlags = FMOD_INIT_NORMAL;

    if (HasARGV("fmodprofiler"))
        initFlags |= FMOD_INIT_ENABLE_PROFILE;

#if UNITY_EDITOR
    // enable in order to read out effect cpu usage
    //FIXME: This is not necessarily true, needs investigating
    initFlags |= FMOD_INIT_ENABLE_PROFILE;
#endif

    FMOD_SPEAKERMODE speakerMode = m_activeSpeakerMode;
    bool SupportDifferentDSPBufferSizes = true;
    void* extradriverdataptr = NULL;

#if UNITY_IPHONE || UNITY_TVOS

    FMOD_IPHONE_EXTRADRIVERDATA extradriverdata;
    memset(&extradriverdata, 0, sizeof(FMOD_IPHONE_EXTRADRIVERDATA));

    // Case 790589: on tvOS setting audio session category to AVAudioSessionCategoryPlaybackAndRecord for some reason
    // freezes video playing on [AVPlayer play] call. Not sure if this is tvOS bug, or our video playback implementation.
    // Since tvOS doesn't provide access to microphone, we just disable it.
    if (GetPlayerSettings().prepareIOSForRecording && !UNITY_TVOS)
        extradriverdata.sessionCategory = FMOD_IPHONE_SESSIONCATEGORY_PLAYANDRECORD;
    else if (GetPlayerSettings().muteOtherAudioSources)
        extradriverdata.sessionCategory = FMOD_IPHONE_SESSIONCATEGORY_SOLOAMBIENTSOUND;
    else
        extradriverdata.sessionCategory = FMOD_IPHONE_SESSIONCATEGORY_AMBIENTSOUND;

    extradriverdata.forceMixWithOthers = !GetPlayerSettings().muteOtherAudioSources;
    extradriverdataptr = &extradriverdata;


#elif UNITY_PSP2

    FMOD_NGP_EXTRADRIVERDATA extradriverdata;
    memset(&extradriverdata, 0, sizeof(FMOD_NGP_EXTRADRIVERDATA));
    extradriverdata.maxSimultaneousAT9Channels = 16;
    extradriverdataptr = &extradriverdata;
    speakerMode = FMOD_SPEAKERMODE_STEREO;

#elif UNITY_XBOXONE

    // see fmod_output_wasapi.cpp OutputWASAPI::init ... only supports dspBufferLength of 512
    SupportDifferentDSPBufferSizes = false;

#elif UNITY_WIIU

    FMOD_WIIU_EXTRADRIVERDATA extraWiiU;
    cafe::AudioInitExtraDriverData(&extraWiiU);
    extradriverdataptr = &extraWiiU;

#elif UNITY_ANDROID
    // Java AudioTrack implementation in FMOD is currently stereo only
    // (OpenSL is likely too - 5.1 support to be added later)
    speakerMode = FMOD_SPEAKERMODE_STEREO;

    unsigned int dspBufferSize = m_DSPBufferSize;
    if (!dspBufferSize)
    {
        result = m_FMODSystem->getDSPBufferSize(&dspBufferSize, NULL);
        if (!ValidateFMODResult(result, "FMOD failed to get DSP Buffer size"))
            return false;
    }
    FMOD_OUTPUTTYPE androidAudioOutput = (AndroidAudio::GetAndroidAudioOutputType(dspBufferSize) == AndroidAudio::kOpenSL) ? FMOD_OUTPUTTYPE_OPENSL : FMOD_OUTPUTTYPE_AUDIOTRACK;
    printf_console("AudioManager: Selecting %s output...\n", (androidAudioOutput == FMOD_OUTPUTTYPE_OPENSL) ? "OpenSL" : "AudioTrack");
    result = m_FMODSystem->setOutput(androidAudioOutput);
    if (!ValidateFMODResult(result, "FMOD failed to set Android audio output"))
        return false;
#elif UNITY_PS4
    // see fmod_output_audioput.cpp OutputAudioOut::Init() ... now only supports dspBufferLength of 256
    SupportDifferentDSPBufferSizes = false;
    if ((speakerMode != FMOD_SPEAKERMODE_STEREO) && (speakerMode <= FMOD_SPEAKERMODE_MYEARS))
    {
        speakerMode = FMOD_SPEAKERMODE_7POINT1;
    }                                                                                                                                           // speaker mode has to be VIRTUAL or 7.1 or 2.0 (see OutputAudioOut::init() )

    FMOD_ORBIS_EXTRADRIVERDATA extradriverdata;
    memset(&extradriverdata, 0, sizeof(FMOD_ORBIS_EXTRADRIVERDATA));

    if (GetPs4InitializionFlags().RestrictedAudioUsageRights)
        extradriverdata.audioOutParam = SCE_AUDIO_OUT_PARAM_ATTR_RESTRICTED;
    extradriverdataptr = &extradriverdata;
#endif

    result = m_FMODSystem->setSpeakerMode((FMOD_SPEAKERMODE)speakerMode);
    if (result != FMOD_OK)
    {
        WarningStringMsg("FMOD could not set speaker mode to the one specified in the project settings. Falling back to stereo.");
        result = m_FMODSystem->setSpeakerMode(FMOD_SPEAKERMODE_STEREO);
    }
    if (!ValidateFMODResult(result, "FMOD failed to set speaker mode ... "))
        return false;

    if (m_DefaultDSPBufferSize == 0)
    {
        m_FMODSystem->getDSPBufferSize((unsigned int*)&m_DefaultDSPBufferSize, NULL);
    }

    if (SupportDifferentDSPBufferSizes)
    {
        int dspNumBuffers = 0;
        result = m_FMODSystem->getDSPBufferSize(NULL, &dspNumBuffers);
        if (!ValidateFMODResult(result, "FMOD failed to get number of DSP buffers"))
            return false;
        result = m_FMODSystem->setDSPBufferSize(m_DSPBufferSize == 0 ? m_DefaultDSPBufferSize : m_DSPBufferSize, dspNumBuffers);
        if (!ValidateFMODResult(result, "FMOD failed to set DSP Buffer size ... "))
            return false;
    }

    int currsamplerate;
    FMOD_SOUND_FORMAT format;
    FMOD_DSP_RESAMPLER resampler;

    result = m_FMODSystem->getSoftwareFormat(&currsamplerate, &format, NULL, NULL, &resampler, NULL);
    if (!ValidateFMODResult(result, "FMOD failed to get driver capabilities ... "))
        return false;

    result = m_FMODSystem->setSoftwareFormat(m_activeSampleRate != 0 ? m_activeSampleRate : currsamplerate, format, 0, 8, resampler);
    if (result == FMOD_ERR_INVALID_PARAM)
        result = m_FMODSystem->setSoftwareFormat(currsamplerate, format, 0, 8, resampler);
    if (!ValidateFMODResult(result, "FMOD failed to get driver capabilities ... "))
        return false;

    result = m_FMODSystem->setSoftwareChannels(m_RealVoiceCount);
    if (!ValidateFMODResult(result, "FMOD failed to set software channel count ... "))
        return false;

    result = FMOD_ERR_NET_SOCKET_ERROR;

#ifdef PLAYER_FMOD_PROFILE_PORT
    FMOD_ADVANCEDSETTINGS advSettings;
    memset(&advSettings, 0, sizeof(FMOD_ADVANCEDSETTINGS));
    advSettings.cbsize = sizeof(FMOD_ADVANCEDSETTINGS);
    unsigned short portOffset = 0;
    while (result == FMOD_ERR_NET_SOCKET_ERROR && portOffset < 50)
    {
        advSettings.profileport = PLAYER_FMOD_PROFILE_PORT + portOffset++;
        result = m_FMODSystem->setAdvancedSettings(&advSettings);
        if (result != FMOD_OK)
            break;

        result = m_FMODSystem->init(m_VirtualVoiceCount, initFlags, extradriverdataptr);
    }

    if (result == FMOD_ERR_NET_SOCKET_ERROR)
    {
        // handle this error silently because it should be possible to run multiple unity editors simultaneously (our test framework does that)
        initFlags &= ~FMOD_INIT_ENABLE_PROFILE;
        result = m_FMODSystem->init(m_VirtualVoiceCount, initFlags, extradriverdataptr);
        printf_console("Audio: Failed to init the FMOD with the Profiler enabled.\n");
    }
    else if (result == FMOD_OK && (initFlags & FMOD_INIT_ENABLE_PROFILE))
    {
        printf_console("Audio: FMOD Profiler initialized on port %hu\n", advSettings.profileport);
    }
#else
    // If we have no info about the profiler port to use, then init without profiler
    initFlags &= ~FMOD_INIT_ENABLE_PROFILE;
    result = m_FMODSystem->init(m_VirtualVoiceCount, initFlags, extradriverdataptr);
#endif

    // If we just fail to init the FMOD system all together then
    // initialise it NOOUTPUT, as the problem is likely driver specific.
    if (result != FMOD_OK)
    {
        ErrorString("FMOD failed to initialize the output device, attempting to initialize the null output.");
        result = m_FMODSystem->setOutput(FMOD_OUTPUTTYPE_NOSOUND);
        result = m_FMODSystem->init(m_VirtualVoiceCount, initFlags, extradriverdataptr);
    }

#if UNITY_WIN
    if (result == FMOD_ERR_OUTPUT_FORMAT)
        if (!ValidateFMODResult(result, "FMOD failed to initialize. This may be because your sound card is configured to give applications exclusive access, thus preventing Unity from using this device. You can change this in Control Panel > Audio Devices and Sound Themes > Playback Device > Properties > Options ... "))
            return false;
#endif
    if (!ValidateFMODResult(result, "FMOD failed to initialize ... "))
        return false;

    m_ProfilingEnabled = (initFlags & FMOD_INIT_ENABLE_PROFILE) != 0;

#if UNITY_LINUX
    LogDriverDetails(m_FMODSystem, driverID);
#endif

#if UNITY_EDITOR
    if (!EditorPrefs::HasKey(kAudioMixerUseRMSMetering))
        EditorPrefs::SetBool(kAudioMixerUseRMSMetering, m_IsUsingRMSMetering);
#endif
    return true;
}

#if UNITY_ANDROID || UNITY_TIZEN || UNITY_SWITCH
void AudioManager::OverrideVolume(float volume)
{
    m_ChannelGroup_FMODMaster->setVolume(volume);
}

bool AudioManager::StopOutput()
{
    return (m_FMODSystem->stopOutput() == FMOD_OK);
}

bool AudioManager::StartOutput()
{
    return (m_FMODSystem->startOutput() == FMOD_OK);
}

#endif // UNITY_ANDROID || UNITY_TIZEN || UNITY_SWITCH

void AudioManager::CloseFMOD()
{
    if (m_FMODSystem)
    {
        // Save bypass state of custom filters on Monobehaviours
        dynamic_array<MonoBehaviour*> monoBehaviours(kMemTempAlloc);
        Object::FindObjectsOfType(monoBehaviours);
        for (size_t i = 0; i < monoBehaviours.size(); ++i)
        {
            MonoBehaviour* behaviour = monoBehaviours[i];
            FMOD::DSP* dsp = behaviour->GetDSP();
            if (dsp)
            {
                AudioCustomFilter* customFilter = NULL;
                FMOD_RESULT result;
                CheckFMODError(result = dsp->getUserData((void**)&customFilter));
                if (result == FMOD_OK)
                    CheckFMODError(result = dsp->getBypass(&customFilter->m_SavedBypassState));
            }
        }

        // Cleanup sources
        {
            dynamic_array<AudioSource*> audioSources(kMemTempAlloc);
            Object::FindObjectsOfType(audioSources);
            for (size_t i = 0; i < audioSources.size(); ++i)
                audioSources[i]->Cleanup();
        }

        // Cleanup listener(s)
        {
            dynamic_array<AudioListener*> audioListeners(kMemTempAlloc);
            Object::FindObjectsOfType(audioListeners);
            for (size_t i = 0; i < audioListeners.size(); ++i)
                audioListeners[i]->Cleanup();
        }

        // Cleanup reverb zone(s)
        {
            dynamic_array<AudioReverbZone*> audioReverbZones(kMemTempAlloc);
            Object::FindObjectsOfType(audioReverbZones);
            for (size_t i = 0; i < audioReverbZones.size(); ++i)
                audioReverbZones[i]->Cleanup();
        }

        // Cleanup Audio Mixer(s)
        {
            dynamic_array<AudioMixer*> audioMixers(kMemTempAlloc);
            Object::FindObjectsOfType(audioMixers);
            for (size_t i = 0; i < audioMixers.size(); ++i)
                audioMixers[i]->CleanupMemory();
        }

        if (m_ChannelGroup_FX_IgnoreVolume)
        {
            m_ChannelGroup_FX_IgnoreVolume->release();
            m_ChannelGroup_FX_IgnoreVolume = NULL;
        }

        if (m_ChannelGroup_NoFX_IgnoreVolume)
        {
            m_ChannelGroup_NoFX_IgnoreVolume->release();
            m_ChannelGroup_NoFX_IgnoreVolume = NULL;
        }

        if (m_ChannelGroup_FX_UseVolume)
        {
            m_ChannelGroup_FX_UseVolume->release();
            m_ChannelGroup_FX_UseVolume = NULL;
        }

        if (m_ChannelGroup_NoFX_UseVolume)
        {
            m_ChannelGroup_NoFX_UseVolume->release();
            m_ChannelGroup_NoFX_UseVolume = NULL;
        }

#if PS4_PAD_SPEAKER
        for (int index = 0; index < SCE_USER_SERVICE_MAX_LOGIN_USERS; ++index)
        {
            DualShock4Speaker& speaker = m_DualShock4Speaker[index];
            if (speaker.m_ChannelGroup)
            {
                speaker.m_ChannelGroup->release();
                speaker.m_ChannelGroup = NULL;
            }
            if (speaker.m_DSP)
            {
                speaker.m_DSP->release();
                speaker.m_DSP = NULL;
            }
            speaker.m_UserId = SCE_USER_SERVICE_USER_ID_INVALID;
        }
#endif

        m_MasterDSP->release();
        m_MasterDSP = NULL;

        // m_ChannelGroup_FMODMaster  is the FMOD master group so we should not call release on it
        m_ChannelGroup_FMODMaster = NULL;

        // cleanup any loaded audio clips
        {
            dynamic_array<AudioClip*> audioClips(kMemTempAlloc);
            Object::FindObjectsOfType(audioClips);
            for (size_t i = 0; i < audioClips.size(); ++i)
                audioClips[i]->Cleanup();
        }

#if UNITY_EDITOR
        // Must release these before we delete SoundManager
        m_PreviewChannel.Clear();
        m_PreviewSound.Release();

        if (m_ChannelGroup_Preview)
        {
            m_ChannelGroup_Preview->release();
            m_ChannelGroup_Preview = NULL;
        }
#endif

        // Note: This must happen before closing the FMOD system
        if (m_SoundManager != NULL)
        {
            UNITY_DELETE(m_SoundManager, kMemAudio);
            m_SoundManager = NULL;
        }

        m_FMODSystem->close();
    }
}

#if PS4_PAD_SPEAKER
bool AudioManager::SetDualShock4PadSpeakerMixLevel(int padIndex, int mixLevel)
{
    if (padIndex >= 0 && padIndex < SCE_USER_SERVICE_MAX_LOGIN_USERS)
    {
        DualShock4Speaker& speaker = m_DualShock4Speaker[padIndex];
        return speaker.SetMixLevel(mixLevel);
    }
    return false;
}

bool AudioManager::SetDualShock4PadSpeakerRestrictedAudioPadIndex(int padIndex, bool restricted)
{
    if (padIndex >= 0 && padIndex < SCE_USER_SERVICE_MAX_LOGIN_USERS)
    {
        DualShock4Speaker& speaker = m_DualShock4Speaker[padIndex];
        return speaker.SetRestrictedAudio(restricted);
    }
    return false;
}

FMOD::ChannelGroup* AudioManager::CreateNewDualShock4DSP(SceUserServiceUserId userId, DualShock4Speaker& speaker)
{
    speaker.m_UserId = speaker.m_NewUserId = userId;    // NOTE: Assign this first - it will be read by the DualShock4_DSPFeeder thread which starts in the createDSP() call below ...

    //
    // Create a channel group for the DualShock4 speaker ...
    //
    Assert(speaker.m_ChannelGroup == NULL);
    FMOD_RESULT result = m_FMODSystem->createChannelGroup("PS4PadSpeaker[user]", &speaker.m_ChannelGroup);
    if (!ValidateFMODResult(result, "ERROR: CreateNewDualShock4DSP - failed to create channel group for new user's DualShock4 speaker..."))
        return nullptr;

    //
    // ... and a DSP ...
    //
    FMOD_DSP_DESCRIPTION  dspDesc;
    memset(&dspDesc, 0, sizeof(FMOD_DSP_DESCRIPTION));
    strcpy(dspDesc.name, "DualShock4 DSP Output");
    dspDesc.channels    = 0;
    dspDesc.read        = DualShock4_DSPRead;
    dspDesc.create      = DualShock4_DSPCreate;
    dspDesc.release     = DualShock4_DSPRelease;
    dspDesc.userdata    = (void*)&speaker;

    FMOD::DSP* dsp = nullptr;
    result = m_FMODSystem->createDSP(&dspDesc, &dsp);       // NOTE: DualShock4_DSPFeeder threads starts running here!
    if (!ValidateFMODResult(result, "ERROR: CreateNewDualShock4DSP - failed to create DSP for new user's DualShock4 speaker..."))
        return nullptr;

    speaker.m_DSP = dsp;

    //
    // ... add the DSP to the channel group
    //
    result = speaker.m_ChannelGroup->addDSP(dsp, nullptr);
    if (!ValidateFMODResult(result, "ERRO: CreateNewDualShock4DSP - failed to add DualShock4 speaker DSP to channel group ..."))
        return nullptr;

    return speaker.m_ChannelGroup;
}

FMOD::ChannelGroup* AudioManager::GetChannelGroup_DualShock4Speaker(SceUserServiceUserId userId)
{
    if (SCE_USER_SERVICE_USER_ID_INVALID == userId)
    {
        return nullptr;
    }

    //
    // Do we have a speaker assigned for this user?
    //
    for (int speakerIndex = 0; speakerIndex < SCE_USER_SERVICE_MAX_LOGIN_USERS; ++speakerIndex)
    {
        const DualShock4Speaker& speaker = m_DualShock4Speaker[speakerIndex];

        if (userId == speaker.m_UserId)
        {
            return speaker.m_ChannelGroup;
        }
    }

    //
    // Check whether a previous user has logged out - re-use the slot if so
    //
    SceUserServiceLoginUserIdList userIdList;
    if (SCE_OK == sceUserServiceGetLoginUserIdList(&userIdList))
    {
        for (int speakerIndex = 0; speakerIndex < SCE_USER_SERVICE_MAX_LOGIN_USERS; ++speakerIndex)
        {
            DualShock4Speaker& speaker = m_DualShock4Speaker[speakerIndex];
            SceUserServiceUserId existingUser = speaker.m_UserId;

            if (SCE_USER_SERVICE_USER_ID_INVALID != existingUser)
            {
                bool found = false;

                for (int loggedIn = 0; loggedIn < SCE_USER_SERVICE_MAX_LOGIN_USERS; ++loggedIn)
                {
                    SceUserServiceUserId loggedInUser = userIdList.userId[loggedIn];
                    if (existingUser == loggedInUser)
                    {
                        found = true;
                        break;
                    }
                }

                if (!found)
                {
                    // Re-use this slot - previous user has logged out
                    speaker.m_NewUserId = userId;
                    return speaker.m_ChannelGroup;
                }
            }
        }
    }


    //
    // ... none found, so try to create a new one for this user
    //
    for (int speakerIndex = 0; speakerIndex < SCE_USER_SERVICE_MAX_LOGIN_USERS; ++speakerIndex)
    {
        DualShock4Speaker& speaker = m_DualShock4Speaker[speakerIndex];

        if (SCE_USER_SERVICE_USER_ID_INVALID == speaker.m_UserId)
        {
            if (CreateNewDualShock4DSP(userId, speaker))
            {
                return speaker.m_ChannelGroup;
            }
        }
    }

    return nullptr;
}

#endif
int AudioManager::GetMemoryAllocated() const
{
    int a = 0;
    FMOD::Memory_GetStats(&a, NULL);
    return a;
}

float AudioManager::GetCPUUsage() const
{
    float c = 0.0f;
    if (m_FMODSystem)
        m_FMODSystem->getCPUUsage(NULL, NULL, NULL, NULL, &c);
    return c;
}

int AudioManager::GetPlayingSourceCount() const
{
    int count = 0;
    TAudioSources::const_iterator i = m_Sources.begin();
    while (i != m_Sources.end())
    {
        AudioSource& source = **(i++);
        if (source.IsPlaying())
            count++;
    }
    return count;
}

#if ENABLE_PROFILER
void AudioManager::GetProfilerData(AudioStats& audioStats)
{
    if (!m_FMODSystem)
        return;

    if (m_FMODSystem)
    {
        audioStats.totalAudioSourceCount = AudioSource::s_GlobalActiveCount;
        audioStats.playingSources = GetPlayingSourceCount();
        audioStats.pausedSources = audioStats.totalAudioSourceCount - audioStats.playingSources;

        audioStats.audioClipCount = AudioClip::s_GlobalCount;
        audioStats.numSoundChannelInstances = SoundChannelInstance::s_GlobalCount;
        audioStats.numSoundChannelHandles = SoundChannel::s_GlobalCount;
        audioStats.numVFSHandles = s_FMOD_FileAccessor_GlobalCount;

        m_FMODSystem->getChannelsPlaying(&audioStats.numFMODChannels);

        float dspCPU, streamCPU, cpuUsage;
        m_FMODSystem->getCPUUsage(&dspCPU, &streamCPU, NULL, NULL, &cpuUsage);
        audioStats.totalCPU = RoundfToInt(cpuUsage * 10.0F);
        audioStats.dspCPU = RoundfToInt(dspCPU * 10.0F);
        audioStats.streamCPU = RoundfToInt(streamCPU * 10.0F);
        audioStats.otherCPU = audioStats.totalCPU - (audioStats.dspCPU + audioStats.streamCPU);

        FMOD_MEMORY_USAGE_DETAILS details;
        m_FMODSystem->getMemoryInfo(FMOD_EVENT_MEMBITS_ALL, 0, 0, &details);

        int accum = 0;
        accum += audioStats.streamingMemory = GetMemoryManager().GetAllocatedMemory(kMemFMODStream);
        accum += audioStats.sampleMemory = GetMemoryManager().GetAllocatedMemory(kMemFMODSample);
        accum += audioStats.channelMemory = details.channel + details.channelgroup;
        accum += audioStats.dspMemory = details.dsp + details.dspconnection;
        accum += audioStats.extraDSPBufferMemory = GetMemoryManager().GetAllocatedMemory(kMemFMODExtraDSP);
        accum += audioStats.codecMemory = details.codec + details.dspcodec;
        accum += audioStats.recordMemory = details.recordbuffer;
        accum += audioStats.reverbMemory = details.reverb;
        accum += audioStats.otherAudioBuffers = GetMemoryManager().GetAllocatedMemory(kMemAudioData);

        audioStats.totalMemoryUsage = GetMemoryManager().GetAllocatedMemory(kMemAudio) + audioStats.otherAudioBuffers +
            GetMemoryManager().GetAllocatedMemory(kMemFMOD) + audioStats.extraDSPBufferMemory + audioStats.sampleMemory + audioStats.streamingMemory;

        audioStats.otherMemory = audioStats.totalMemoryUsage - accum;
    }
}

#endif

int AudioManager::GetSpeakerCount() const
{
    if (!m_FMODSystem)
        return 2;

    switch (m_activeSpeakerMode)
    {
        case FMOD_SPEAKERMODE_MONO:     return 1;
        case FMOD_SPEAKERMODE_STEREO:   return 2;
        case FMOD_SPEAKERMODE_QUAD:     return 4;
        case FMOD_SPEAKERMODE_SURROUND: return 5;
        case FMOD_SPEAKERMODE_5POINT1:  return 6;
        case FMOD_SPEAKERMODE_7POINT1:  return 8;
        default: return 2;
    }
}

FMOD_RESULT AudioManager::CreateAllocationBoundSound(const char* data, FMOD_MODE mode, FMOD_CREATESOUNDEXINFO* exInfo,
    SoundHandle::Instance** instance, SampleClip* sampleClip)
{
    SET_ALLOC_OWNER(sampleClip == 0 ? (void*)gAudioManager : (void*)sampleClip);
    return LoadFMODSound(instance, data, mode, sampleClip, 0, 0, exInfo);
}

#if ENABLE_WWW
SoundHandle::Instance* AudioManager::CreateFMODSoundFromWWW(IWWWStream* webStream,
    FMOD_SOUND_TYPE suggestedtype,
    FMOD_SOUND_FORMAT format,
    unsigned freq,
    unsigned channels,
    bool stream,
    bool compressed,
    SampleClip* sampleClip)
{
    if (!m_FMODSystem)
        return NULL;

    SoundHandle::Instance* instance = NULL;
    FMOD_CREATESOUNDEXINFO exInfo;
    memset(&exInfo, 0, sizeof(FMOD_CREATESOUNDEXINFO));
    exInfo.cbsize = sizeof(FMOD_CREATESOUNDEXINFO);
    exInfo.decodebuffersize = 16384;
    exInfo.suggestedsoundtype = suggestedtype;
    exInfo.format = format;
    exInfo.defaultfrequency = freq;
    exInfo.numchannels = channels;
    exInfo.useropen = AudioClip::WWWOpen;
    exInfo.userclose = AudioClip::WWWClose;
    exInfo.userread = AudioClip::WWWRead;
    exInfo.userseek = AudioClip::WWWSeek;
    exInfo.userdata = (void*)webStream;


    FMOD_MODE mode = FMOD_SOFTWARE | FMOD_3D |
        (suggestedtype == FMOD_SOUND_TYPE_MPEG ? FMOD_MPEGSEARCH : FMOD_IGNORETAGS) | FMOD_LOOP_OFF;

    if (stream)
        mode |= FMOD_CREATESTREAM;
    else
        mode |= compressed ? FMOD_CREATECOMPRESSEDSAMPLE : FMOD_CREATESAMPLE;

    if (suggestedtype == FMOD_SOUND_TYPE_RAW)
        mode |= FMOD_OPENRAW;

    FMOD_RESULT err = CreateAllocationBoundSound((const char*)webStream, mode, &exInfo, &instance, sampleClip);
    if (err != FMOD_OK)
    {
        m_LastErrorString = FMOD_ErrorString(err);
        m_LastFMODErrorResult = err;
        return NULL;
    }

    return instance;
}

#endif // ENABLE_WWW

SoundHandle::Instance* AudioManager::CreateFMODSoundFromMovie(AudioClip* clip)
{
    if (!m_FMODSystem)
        return NULL;

    MoviePlayback* movie = clip->GetMovie();
    Assert(movie);

    SoundHandle::Instance* instance = NULL;
    FMOD_CREATESOUNDEXINFO exInfo;
    memset(&exInfo, 0, sizeof(FMOD_CREATESOUNDEXINFO));
    exInfo.cbsize = sizeof(FMOD_CREATESOUNDEXINFO);
    exInfo.length = 0xffffffff;
    exInfo.decodebuffersize = 4096;
    exInfo.format = FMOD_SOUND_FORMAT_PCM16;
    exInfo.defaultfrequency = movie->GetMovieAudioRate();
    exInfo.numchannels = movie->GetMovieAudioChannelCount();
    exInfo.pcmreadcallback = AudioClip::moviepcmread;
    exInfo.userdata = (void*)clip;


    FMOD_MODE mode = FMOD_SOFTWARE | FMOD_3D | FMOD_CREATESTREAM | FMOD_OPENUSER | FMOD_IGNORETAGS | FMOD_LOOP_OFF;
    FMOD_RESULT err = CreateAllocationBoundSound(0, mode, &exInfo, &instance, clip);

    if (err != FMOD_OK)
    {
        m_LastErrorString = FMOD_ErrorString(err);
        m_LastFMODErrorResult = err;
        return NULL;
    }

    return instance;
}

void AudioManager::UpdateListener(
    const Vector3f& position,
    const Vector3f& velocity,
    const Vector3f& up,
    const Vector3f& forward)
{
    if (!m_FMODSystem)
        return;

    m_FMODSystem->set3DListenerAttributes(
        0,
        reinterpret_cast<const FMOD_VECTOR*>(&position),
        reinterpret_cast<const FMOD_VECTOR*>(&velocity),
        reinterpret_cast<const FMOD_VECTOR*>(&forward),
        reinterpret_cast<const FMOD_VECTOR*>(&up)
        );
}

bool IsZeroGUID(FMOD_GUID * guid)
{
    return guid == NULL ||
        (guid->Data1 == 0 && guid->Data2 == 0 && guid->Data3 == 0 && ((uint64_t*)(guid->Data4))[0] == 0);
}

bool AudioManager::SetActiveOutputDriver(FMOD_GUID* guid)
{
    if (IsZeroGUID(guid))
    {
        memset(&m_DefaultOutputDriver, 0, sizeof(FMOD_GUID));
        return (m_FMODSystem->setDriver(0) == FMOD_OK);
    }

    int numDrivers;
    FMOD_RESULT result = m_FMODSystem->getNumDrivers(&numDrivers);
    if (result != FMOD_OK)
        return false;

    int oldDriver = -1;
    result = m_FMODSystem->getDriver(&oldDriver);
    if (result != FMOD_OK)
        return false;

    const int driverNameLen = 64;
    char driverName[driverNameLen];
    FMOD_GUID audioGUID;

    result = m_FMODSystem->getDriverInfo(oldDriver, driverName, driverNameLen, &audioGUID);

    // If the old driver was already set, don't bother setting it again.
    if (result == FMOD_OK && CompareMemory<FMOD_GUID>(audioGUID, *guid))
    {
        return true;
    }

    for (int driverNum = 0; driverNum < numDrivers; ++driverNum)
    {
        result = m_FMODSystem->getDriverInfo(driverNum, driverName, driverNameLen, &audioGUID);

        if (result == FMOD_OK && CompareMemory<FMOD_GUID>(audioGUID, *guid))
        {
            result = m_FMODSystem->setDriver(driverNum);

            // Failed to set driver, we must restore the original.
            if (result == FMOD_ERR_OUTPUT_INIT)
            {
                m_FMODSystem->setDriver(oldDriver);
                return false;
            }

            if (result == FMOD_OK)
            {
                m_DeviceChanged = true;
                m_PendingAudioConfigurationCallback = true;

                // Don't copy if same ptr
                if (&m_DefaultOutputDriver != guid)
                {
                    memcpy(&m_DefaultOutputDriver, guid, sizeof(FMOD_GUID));
                }

                return true;
            }
        }
    }

    return false;
}

void AudioManager::SetDefaultMicrophoneDriver(FMOD_GUID* guid)
{
    if (guid == NULL)
    {
        memset(&m_DefaultRecordingDriver, 0, sizeof(FMOD_GUID));
    }
    else
    {
        memcpy(&m_DefaultRecordingDriver, guid, sizeof(FMOD_GUID));
    }
}

int AudioManager::GetAutomaticUpdateMode(GameObject *go)
{
    Rigidbody* body = go->QueryComponent<Rigidbody>();
    if (body)
        return kVelocityUpdateModeFixed;

    Transform* parent = go->GetComponent<Transform>().GetParent();
    while (parent)
    {
        go = parent->GetGameObjectPtr();
        if (go)
            body = go->QueryComponent<Rigidbody>();
        else
            body = NULL;
        if (body)
            return kVelocityUpdateModeFixed;

        parent = parent->GetParent();
    }
    return kVelocityUpdateModeDynamic;
}

bool AudioManager::ShouldSourcePause(bool ignoreListenerPause)
{
    if (m_IsApplicationPaused)
        return true;

    if (m_IsPaused && !ignoreListenerPause)
        return true;

    return false;
}

void AudioManager::UpdatePauseState()
{
    if (!m_FMODSystem)
        return;

    UInt64 dspTicks = GetRealDSPTime();

    if (m_IsPaused || m_IsApplicationPaused)
    {
        if (m_pauseStartTicks == 0)
            m_pauseStartTicks = dspTicks;
    }
    else
    {
        if (m_pauseStartTicks != 0)
        {
            UInt64 pauseDuration = dspTicks - m_pauseStartTicks;
            m_accPausedTicks += pauseDuration;
            m_pauseStartTicks = 0;
        }
    }

    // Update the pause state in all the individual AudioSources
    TAudioSourcesIterator i = m_Sources.begin();
    while (i != m_Sources.end())
    {
        AudioSource& source = **(i++);
        //This references back to the AudioManager which has set the pause state above
        source.UpdatePauseState();
    }
}

void AudioManager::SetApplicationPause(bool pause)
{
    if (m_IsApplicationPaused == pause)
        return;

    m_IsApplicationPaused = pause;
    UpdatePauseState();
}

void AudioManager::SetListenerPause(bool pause)
{
    if (m_IsPaused == pause)
        return;

    m_IsPaused = pause;
    UpdatePauseState();
}

bool AudioManager::GetListenerPause() const
{
    return m_IsPaused;
}

void AudioManager::SetVolume(float volume)
{
    if (!m_FMODSystem)
        return;

    m_ChannelGroup_FX_UseVolume->setVolume(volume);
    m_ChannelGroup_NoFX_UseVolume->setVolume(volume);

#if PS4_PAD_SPEAKER
    for (int index = 0; index < SCE_USER_SERVICE_MAX_LOGIN_USERS; ++index)
    {
        DualShock4Speaker& speaker = m_DualShock4Speaker[index];
        if (speaker.m_ChannelGroup)
        {
            speaker.m_ChannelGroup->setVolume(volume);
        }
    }
#endif

    m_Volume = volume;
}

float AudioManager::GetVolume() const
{
    return m_Volume;
}

template<class TransferFunction>
void AudioManager::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);

    transfer.Transfer(m_DefaultVolume, "m_Volume");
    transfer.Transfer(m_Rolloffscale, "Rolloff Scale");
    transfer.Transfer(m_DopplerFactor, "Doppler Factor");
    transfer.Transfer((SInt32&)m_speakerMode, "Default Speaker Mode");  // Remember to specify the TransferName in the doxygen comment in the .h file

    TRANSFER(m_SampleRate);
    TRANSFER(m_DSPBufferSize);

    TRANSFER(m_VirtualVoiceCount);
    TRANSFER(m_RealVoiceCount);

    TRANSFER(m_SpatializerPlugin);

    TRANSFER(m_DisableAudio);
    TRANSFER(m_VirtualizeEffects);
    transfer.Align();
}

void AudioManager::CheckConsistency()
{
    Super::CheckConsistency();
    m_DefaultVolume = clamp(m_DefaultVolume, 0.0f, 1.0f);
    m_Rolloffscale = clamp(m_Rolloffscale, 0.0f, 10.0f);
    m_DopplerFactor = clamp(m_DopplerFactor, 0.0f, 10.0f);
    m_speakerMode = clamp(m_speakerMode, FMOD_SPEAKERMODE_MONO, FMOD_SPEAKERMODE_SRS5_1_MATRIX);
    m_SampleRate = clamp(m_SampleRate, 0, 96000);
#if UNITY_PSP2
    // Case 78852: PSP2 only supports values up to 512 (64, 128, 256 or 512)
    m_DSPBufferSize = clamp(m_DSPBufferSize, 0, 512);
#else
    m_DSPBufferSize = clamp(m_DSPBufferSize, 0, 8192);
#endif
    m_VirtualVoiceCount = clamp(m_VirtualVoiceCount, 1, 4095);
    m_RealVoiceCount = clamp(m_RealVoiceCount, 1, 255);


    //FIXME: Check that the spatializer plugin is available. If not, then reset to ""
}

AudioConfigurationScripting AudioManager::GetConfiguration()
{
    AudioConfigurationScripting config;
    memset(&config, 0, sizeof(config));
    if (!m_FMODSystem)
        return config;

    config.sampleRate = m_activeSampleRate;
    CheckFMODError(m_FMODSystem->getDSPBufferSize((unsigned int*)&config.dspBufferSize, NULL));
    CheckFMODError(m_FMODSystem->getSoftwareFormat(&config.sampleRate, NULL, NULL, NULL, NULL, NULL)); // Necessary, as m_SampleRate can be 0
    config.speakerMode = m_activeSpeakerMode;
    config.numRealVoices = m_activeRealVoiceCount;
    config.numVirtualVoices = m_activeVirtualVoiceCount;
    return config;
}

bool AudioManager::SetConfiguration(const AudioConfigurationScripting& config)
{
    if (!m_FMODSystem)
        return false;

    // TODO: We can do some checks here for making sure that parameters are actually changed. This needs some extra work though as we first need to take the given config values, massage them
    // via CheckConsistency and then check whether they are different from the current settings while handling that m_SampleRate and m_DSPBufferSize can be 0 (so we effectively need to read the
    // current settings from FMOD instead).

    m_SampleRate = config.sampleRate;

#if UNITY_PSP2
    m_DSPBufferSize = (config.dspBufferSize + 63) & ~63;
#elif !UNITY_PS4
    m_DSPBufferSize = config.dspBufferSize;
#endif

#if !UNITY_PSP2
    m_speakerMode = config.speakerMode;
#endif

    m_VirtualVoiceCount = config.numVirtualVoices;
    m_RealVoiceCount = config.numRealVoices;

    CheckConsistency();

    ShutdownReinitializeAndReload();
    return m_FMODSystem != NULL && m_FMODSystem->update() != FMOD_ERR_UNINITIALIZED; // TODO: Perform better error handling here. Currently FMOD will fail on some audio settings.
}

void AudioManager::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);

    if (IsAudioDisabledInStandalone())
        return;

    if (!m_FMODSystem)
    {
        InitFMOD();
        m_IsPaused = false;
    }

    if (!m_FMODSystem)
        return;

    // has the speakermode changed?
    if (m_activeSampleRate != m_SampleRate ||
        m_activeDSPBufferSize != m_DSPBufferSize ||
        m_activeSpeakerMode != m_speakerMode ||
        m_activeVirtualVoiceCount != m_VirtualVoiceCount ||
        m_activeRealVoiceCount != m_RealVoiceCount)
    {
        // bootstrap FMOD
        ShutdownReinitializeAndReload();
        if (!m_FMODSystem)
            return;
    }
    else if (m_activeVirtualizeEffects != m_VirtualizeEffects)
    {
        for (TAudioSourcesIterator i = m_Sources.begin(); i != m_Sources.end();)
        {
            AudioSource& curSource = **i++;
            curSource.UpdateEffectVirtualizationState(true);
        }
        m_activeVirtualizeEffects = m_VirtualizeEffects;
    }

    m_Volume = m_DefaultVolume;
    m_ChannelGroup_FX_UseVolume->setVolume(m_Volume);
    m_ChannelGroup_NoFX_UseVolume->setVolume(m_Volume);

#if PS4_PAD_SPEAKER
    for (int index = 0; index < SCE_USER_SERVICE_MAX_LOGIN_USERS; ++index)
    {
        DualShock4Speaker& speaker = m_DualShock4Speaker[index];
        if (speaker.m_ChannelGroup)
        {
            speaker.m_ChannelGroup->setVolume(m_Volume);
        }
    }
#endif

    // We are handling Doppler in Unity code now (outside of FMOD), so instead of passing down m_DopplerFactor here,
    // we always pass zero to disable FMOD's Doppler.
    m_FMODSystem->set3DSettings(0, 1, m_Rolloffscale);
}

PROFILER_INFORMATION(gAudioUpdateProfile, "AudioManager.Update", kProfilerAudio);
PROFILER_INFORMATION(gAudioFixedUpdateProfile, "AudioManager.FixedUpdate", kProfilerAudio);

#if UNITY_EDITOR
void AudioManager::ListenerCheck()
{
    if (!IsWorldPlaying())
        return;

    int listenerCount = m_Listeners.size_slow();
    // @TODO enable multiple listeners
    if (listenerCount == 0 && !m_Sources.empty())
    {
        LogString("There are no audio listeners in the scene. Please ensure there is always one audio listener in the scene");
        m_ChannelGroup_FX_UseVolume->setVolume(0.0f);
        m_ChannelGroup_NoFX_UseVolume->setVolume(0.0f);
    }
    else
    {
        if (listenerCount > 1)
            LogString(Format("There are %d audio listeners in the scene. Please ensure there is always exactly one audio listener in the scene.", listenerCount));
        m_ChannelGroup_FX_UseVolume->setVolume(m_Volume);
        m_ChannelGroup_NoFX_UseVolume->setVolume(m_Volume);
    }
}

#endif

#define Unity_HiWord(x) ((UInt32)((UInt64)(x) >> 32))
#define Unity_LoWord(x) ((UInt32)(x))
void AudioManager::ProcessScheduledSources()
{
    // start scheduled sources
    // Get mixer clock
    unsigned hiclock, loclock;
    m_FMODSystem->getDSPClock(&hiclock, &loclock);

#if ENABLE_AUDIO_MANAGER_BASED_SCHEDULING
    // Calculate delta DSP clock so that we can count down the trigger time on pending
    // scheduled audio sources.

    UInt64 curDSPClock = ((UInt64)hiclock << 32) + loclock;

    // on first call m_lastDSPClock will be 0, we should bring it inline with the dsp clock
    m_lastDSPClock = m_lastDSPClock == 0 ? curDSPClock : m_lastDSPClock;
    UInt64 deltaDSPClock = curDSPClock - m_lastDSPClock;
    m_lastDSPClock = curDSPClock;

    int sampleRate;
    m_FMODSystem->getSoftwareFormat(&sampleRate, NULL, NULL, NULL, NULL, NULL);

    double deltaTime = (double)deltaDSPClock / (double)sampleRate;

    for (TScheduledSourcesIterator s = m_ScheduledSources.begin(), next; s != m_ScheduledSources.end(); s = next)
    {
        next = s;
        ++next;
#else
    for (TScheduledSourcesIterator s = m_ScheduledSources.begin(); s != m_ScheduledSources.end(); s++)
    {
#endif
        AudioScheduledSource& p = *s;
        AudioSource* curSource = p.source;

        Assert(curSource != NULL);
        Assert(curSource->m_Channel.IsValid());

#if ENABLE_AUDIO_MANAGER_BASED_SCHEDULING
        // For now we only allow the audio manager to manage VAG compressed formats, or GCADPCM
        AudioClip* audioClip = curSource->GetAudioClip();
        Assert(audioClip != NULL);

        SampleClip::CompressionFormat format = audioClip->GetCompressionFormat();
        if (format == SampleClip::kPSMVAG || format == SampleClip::kHEVAG || format == SampleClip::kGCADPCM)
        {
            if (p.time > 0.0f)
            {
                // convert absolute scheduled time to relative time.
                p.time = GetDSPTime() - (p.time + deltaTime);
            }

            curSource->m_HasScheduledStartDelay = true;
            p.time += deltaTime;

            if (p.time >= 0)
            {
                curSource->m_HasScheduledStartDelay = false;
                curSource->m_pause = false;
                curSource->m_Channel->SetPaused(false);
                curSource->UpdateParameters();

                AddAudioSource(curSource);

                UnScheduleSource(curSource);
            }
            continue;
        }
#endif

        if (p.time != 0.0)
        {
            int sampleRate;
            m_FMODSystem->getSoftwareFormat(&sampleRate, NULL, NULL, NULL, NULL, NULL);
            if (p.time > 0.0)
            {
                // exact scheduled
                UInt64 sample = (UInt64)(p.time * sampleRate) + m_accPausedTicks;
                curSource->m_Channel->setDelay(FMOD_DELAYTYPE_DSPCLOCK_START, Unity_HiWord(sample), Unity_LoWord(sample));
            }
            else
            {
                UInt64 sample = ((UInt64)hiclock << 32) + loclock + (UInt64)(-p.time * sampleRate);
                curSource->m_Channel->setDelay(FMOD_DELAYTYPE_DSPCLOCK_START, Unity_HiWord(sample), Unity_LoWord(sample));
            }
            curSource->m_HasScheduledStartDelay = true;
        }

        AddAudioSource(curSource);

        // Update parameters here, not directly on AudioSource::Play()
        // The reason is that in this later Update, the listener will have had its transform updated, so we avoid sending incorrect temporary values to FMOD.
        // One-shot sounds are different in that they are played directly and therefore not put in m_ScheduledSources.
        curSource->UpdateParameters();
        curSource->UpdatePauseState();

#if ENABLE_AUDIO_MANAGER_BASED_SCHEDULING
        m_ScheduledSources.erase(s);
#endif
    }

#if !ENABLE_AUDIO_MANAGER_BASED_SCHEDULING
    // clean queue
    m_ScheduledSources.clear();
#endif
}

void AudioManager::Update()
{
    PROFILER_AUTO(gAudioUpdateProfile, NULL);

    if (!m_FMODSystem)
        return;

    SET_ALLOC_OWNER(this);

    float deltaTime = GetTimeManager().GetDeltaTime();
    float unscaledDeltaTime = GetTimeManager().GetDynamicUnscaledDeltaTime();

    for (TAudioMixersIterator i = m_Mixers.begin(), end = m_Mixers.end(); i != end; ++i)
    {
        AudioMixer& mixer = **i;

        if (mixer.GetUpdateMode() == kNormalTime)
            mixer.Update(deltaTime);
        else
            mixer.Update(unscaledDeltaTime);
    }

    ProcessScheduledSources();

#if UNITY_EDITOR
    m_IsUsingRMSMetering = EditorPrefs::GetBool(kAudioMixerUseRMSMetering, true);

    //FIXME: This is super inefficient
    m_CanUseSpatializerEffect = GetCurrentSpatializerDefinition() != NULL;
    ListenerCheck();
#endif

    for (TAudioListenersIterator l = m_Listeners.begin(); l != m_Listeners.end();)
    {
        AudioListener& curListener = **l++;
        curListener.Update();
    }

    for (TAudioSourcesIterator i = m_Sources.begin(); i != m_Sources.end();)
    {
        AudioSource& curSource = **i++;
#if UNITY_EDITOR
        if (!IsWorldPlaying() && curSource.m_Channel.IsValid())
        {
            if (curSource.GetGameObject().IsMarkedVisible())
                curSource.m_Channel->setMute(curSource.GetMute());
            else
                curSource.m_Channel->setMute(true);
        }
#endif
        curSource.Update();
    }

    // update reverb zones position
    for (TAudioReverbZonesIterator r = m_ReverbZones.begin(); r != m_ReverbZones.end(); ++r)
    {
        AudioReverbZone& curReverbZone = **r;
        curReverbZone.Update();
    }

    int samplerate = 0;
    m_FMODSystem->getSoftwareFormat(&samplerate, NULL, NULL, NULL, NULL, NULL);
    g_AudioMasterDSPInternal.samplerate = samplerate;
    g_AudioMasterDSPInternal.flags =
        (g_AudioMasterDSPInternal.flags & ~(UnityAudioEffectStateFlags_IsPlaying | UnityAudioEffectStateFlags_IsPaused)) |
#if UNITY_EDITOR
        (IsWorldPlaying() ? UnityAudioEffectStateFlags_IsPlaying : 0) |
#else
        UnityAudioEffectStateFlags_IsPlaying |
#endif
        (GetPlayerPause() != kPlayerRunning ? UnityAudioEffectStateFlags_IsPaused : 0);
    // g_AudioMasterDSPInternal.currdsptick is updated by AudioMasterDSPProcessCallback

    m_FMODSystem->update();

    if (m_DeviceChangeNeedsReset)
    {
        m_DeviceChangeNeedsReset = false;
        ShutdownReinitializeAndReload();
    }

    HandlePendingAudioConfigurationCallback();
}

void AudioManager::FixedUpdate()
{
    if (!m_FMODSystem)
        return;

    PROFILER_AUTO(gAudioFixedUpdateProfile, NULL);

    SET_ALLOC_OWNER(this);

    #if UNITY_EDITOR
    ListenerCheck();
    #endif

    for (TAudioListenersIterator l = m_Listeners.begin(); l != m_Listeners.end();)
    {
        // Increment iterator before calling FixedUpdate, in case FixedUpdate modifies m_Listeners
        AudioListener& curListener = **l++;
        curListener.FixedUpdate();
    }

    TAudioSourcesIterator i;
    for (i = m_Sources.begin(); i != m_Sources.end();)
    {
        // Increment iterator before calling FixedUpdate, in case FixedUpdate modifies m_Sources (can happen for deferred playOnAwake)
        AudioSource& curSource = **i++;
        curSource.FixedUpdate();
    }
}

void AudioManager::AddAudioSource(AudioSource* s)
{
    Assert(s);
    m_Sources.push_back(s->m_Node);
}

void AudioManager::RemoveAudioSource(AudioSource* s)
{
    Assert(s);
    UnScheduleSource(s);
    s->m_Node.RemoveFromList();  // note: removes either from m_Sources or m_PausedSources
}

void AudioManager::AddAudioMixer(AudioMixer* mixer)
{
    Assert(mixer);
    m_Mixers.push_back(mixer->m_Node);
}

void AudioManager::RemoveAudioMixer(AudioMixer* mixer)
{
    Assert(mixer);
    mixer->m_Node.RemoveFromList();
}

void AudioManager::CleanupDependentMixers(AudioMixer* parent)
{
    for (TAudioMixersIterator i = m_Mixers.begin(), end = m_Mixers.end(); i != end; ++i)
    {
        AudioMixer& mixer = **i;
        AudioMixerGroup* group = mixer.GetOutputAudioMixerGroup();
        if (group && (PPtr<AudioMixer>(parent->GetInstanceID()) == group->GetAudioMixer()))
        {
            mixer.Cleanup();
        }
    }
}

bool AudioManager::GroupGUIDHasDependentMixers(const UnityGUID& guid)
{
    for (TAudioMixersIterator i = m_Mixers.begin(), end = m_Mixers.end(); i != end; ++i)
    {
        AudioMixer& mixer = **i;
        AudioMixerGroup* group = mixer.GetOutputAudioMixerGroup();
        if (group && guid == group->GetGroupID())
        {
            return true;
        }
    }

    return false;
}

void AudioManager::OnEnterPlayModePreStart()
{
    for (TAudioMixersIterator i = m_Mixers.begin(), end = m_Mixers.end(); i != end; ++i)
    {
        AudioMixer& mixer = **i;
        mixer.OnEnterPlayModePreStart();
    }
}

void AudioManager::OnExitPlayMode()
{
    for (TAudioMixersIterator i = m_Mixers.begin(), end = m_Mixers.end(); i != end; ++i)
    {
        AudioMixer& mixer = **i;
        mixer.OnExitPlayMode();
    }
}

void AudioManager::OnMixerChanged()
{
    for (TAudioMixersIterator i = m_Mixers.begin(), end = m_Mixers.end(); i != end; ++i)
    {
        AudioMixer& mixer = **i;
        mixer.SetupGroups();
    }

    // Audio source binding must happen after the mixer groups have been recreated, otherwise we'll connect to old/missing FMOD channel groups.
    RebindAudioSourcesToMixer(NULL);  // Apply to all mixers
}

void AudioManager::RebindAudioSourcesToMixer(AudioMixer* mixer)
{
    for (TAudioSourcesIterator i = m_Sources.begin(), end = m_Sources.end(); i != end; ++i)
    {
        AudioSource& curSource = **i;
        if (mixer == NULL)
            curSource.ConfigureFMODGroups();
        else
        {
            AudioMixerGroup* outputGroup = curSource.GetOutputAudioMixerGroup();
            if (outputGroup != NULL)
            {
                AudioMixer* outputMixer = outputGroup->GetAudioMixer();
                if (mixer == outputMixer)
                    curSource.ConfigureFMODGroups();
            }
        }
    }
}

void AudioManager::StopSources()
{
    TAudioSourcesIterator i = m_Sources.begin();
    while (!m_Sources.empty())
    {
        AudioSource& curSource = **i;
        ++i;
        curSource.Stop(true);
    }
}

void AudioManager::AddAudioListener(AudioListener* s)
{
    Assert(s);
    m_Listeners.push_back(s->GetNode());
}

void AudioManager::RemoveAudioListener(AudioListener* s)
{
    Assert(s);
    s->GetNode().RemoveFromList();
}

AudioListener* AudioManager::GetAudioListener() const
{
    if (!m_Listeners.empty())
        return m_Listeners.back().GetData();
    else
        return NULL;
}

/// Schedule source to be played in sync. In this frame if time==0, delayed by -time if time<0 or scheduled at time
void AudioManager::ScheduleSource(AudioSource* s, double time)
{
    s->m_ScheduledSource.RemoveFromList();
    s->m_ScheduledSource.time = time;
    m_ScheduledSources.push_back(s->m_ScheduledSource);
}

void AudioManager::UnScheduleSource(AudioSource* s)
{
    s->m_ScheduledSource.RemoveFromList();
}

void AudioManager::AddAudioReverbZone(AudioReverbZone* zone)
{
    Assert(zone);
    m_ReverbZones.push_back(zone->m_Node);
}

void AudioManager::RemoveAudioReverbZone(AudioReverbZone* zone)
{
    Assert(zone);
    zone->m_Node.RemoveFromList();
}

#if UNITY_EDITOR
void AudioManager::GetSpatializerNames(std::vector<core::string>& pluginNames)
{
    AudioEffectInternalDefinitionArray definitions(kMemTempAlloc);
    GetAudioSpatializerDefinitions(definitions);

    for (int i = 0; i < definitions.size(); i++)
    {
        pluginNames.push_back(definitions[i]->m_desc->m_unity.name);
    }
}

void AudioManager::SetSpatializerName(core::string pluginName)
{
    m_SpatializerPlugin = pluginName;
    //FIXME: This is super inefficient
    m_CanUseSpatializerEffect = GetCurrentSpatializerDefinition() != NULL;
}

#endif

bool AudioManager::RequiresCustomSpatializer() const
{
    return !m_SpatializerPlugin.empty();
}

AudioEffectInternalDefinition* AudioManager::GetCurrentSpatializerDefinition()
{
    if (!m_SpatializerPlugin.empty())
    {
        AudioEffectInternalDefinitionArray definitions(kMemTempAlloc);
        GetAudioSpatializerDefinitions(definitions);

        for (int i = 0; i < definitions.size(); i++)
        {
            if (m_SpatializerPlugin.compare(definitions[i]->m_desc->m_unity.name) == 0)
            {
                return definitions[i];
            }
        }
    }

    return NULL;
}

const char* AudioManager::GetCurrentSpatializerDefinitionName()
{
    AudioEffectInternalDefinition* audioEffectDef = GetCurrentSpatializerDefinition();
    if (audioEffectDef != NULL)
        return audioEffectDef->m_desc->m_unity.name;
    else
        return "";
}

#if ENABLE_MICROPHONE
// Microphone(s)
bool HasMicrophoneAuthorization()
{
    #if UNITY_WINRT
        #if UNITY_METRO
    namespace Capabilities = metro::Capabilities;
        #else
        #error Unknown WinRT flavour (did you implement capability detection for the OS?)
        #endif

    Capabilities::IsSupported(Capabilities::kMicrophone, "because you're using Microphone functionality");
    #endif // UNITY_WINRT

    return true;
}

const std::vector<core::string> AudioManager::GetRecordDevices() const
{
    std::vector<core::string> devices;
    m_MicrophoneNameToIDMap.clear();

    if (!m_FMODSystem)
        return devices;

    if (!HasMicrophoneAuthorization())
        return devices;

    int numDevices = 0; // fails to return number of drivers if this isn't zero
    FMOD_RESULT result = m_FMODSystem->getRecordNumDrivers(&numDevices);

    if (result != FMOD_OK)
        return devices;

    if (numDevices > 0)
    {
        for (int i = 0; i < numDevices; ++i)
        {
            char name[255];

            m_FMODSystem->getRecordDriverInfo(i, name, 255, NULL);

            core::string strName = (char*)name;
            // update map with a unique name
            core::string origName = strName;
            int no = 0;
            while (m_MicrophoneNameToIDMap.find(strName) != m_MicrophoneNameToIDMap.end())
            {
                char post[256];
                snprintf(post, sizeof(post), " %i", ++no);
                strName = origName + post;
            }
            devices.push_back(strName);
            m_MicrophoneNameToIDMap[strName] = i;
        }
    }

    return devices;
}

int AudioManager::GetMicrophoneDeviceIDFromName(const core::string& name) const
{
    if (m_MicrophoneNameToIDMap.empty())
        GetRecordDevices();

    if (m_MicrophoneNameToIDMap.empty())
        return -1;

    // Double lookup on return is totally unnecessary, because we can cache the iterator
    std::map<core::string, int>::const_iterator devit = m_MicrophoneNameToIDMap.find(name);
    if (devit != m_MicrophoneNameToIDMap.end())
        return devit->second;
    else
    {
        // If m_DefaultRecordingDriver matches one of the drivers that FMOD knows about, use that.
        int numDevices = 0;
        FMOD_RESULT result = m_FMODSystem->getRecordNumDrivers(&numDevices);

        if (result != FMOD_OK)
            return 0;

        for (int driverNum = 0; driverNum < numDevices; ++driverNum)
        {
            const int driverNameLen = 64;
            char driverName[driverNameLen];
            FMOD_GUID audioGUID;
            m_FMODSystem->getRecordDriverInfo(driverNum, driverName, driverNameLen, &audioGUID);

            if (CompareMemory<FMOD_GUID>(audioGUID, m_DefaultRecordingDriver))
            {
                return driverNum;
            }
        }

        return 0; // the default device is always 0.
    }
}

void ReportError(char const* msg, FMOD_RESULT result)
{
    ErrorString(Format("%s. result=%d (%s)", msg, result, FMOD_ErrorString(result)));
}

void CapsToSoundFormat(FMOD_CAPS caps, FMOD_SOUND_FORMAT *soundFormat, int *sampleSizeInBytes)
{
    *soundFormat = FMOD_SOUND_FORMAT_PCM16;
    *sampleSizeInBytes = 2;

    if ((caps & FMOD_CAPS_OUTPUT_FORMAT_PCM16) == FMOD_CAPS_OUTPUT_FORMAT_PCM16)
    {
        *soundFormat = FMOD_SOUND_FORMAT_PCM16;
        *sampleSizeInBytes = 2;
    }
    else if ((caps & FMOD_CAPS_OUTPUT_FORMAT_PCM8) == FMOD_CAPS_OUTPUT_FORMAT_PCM8)
    {
        *soundFormat = FMOD_SOUND_FORMAT_PCM8;
        *sampleSizeInBytes = 1;
    }
    else if ((caps & FMOD_CAPS_OUTPUT_FORMAT_PCM24) == FMOD_CAPS_OUTPUT_FORMAT_PCM24)
    {
        *soundFormat = FMOD_SOUND_FORMAT_PCM24;
        *sampleSizeInBytes = 3;
    }
    else if ((caps & FMOD_CAPS_OUTPUT_FORMAT_PCM32) == FMOD_CAPS_OUTPUT_FORMAT_PCM32)
    {
        *soundFormat = FMOD_SOUND_FORMAT_PCM32;
        *sampleSizeInBytes = 4;
    }
    else if ((caps & FMOD_CAPS_OUTPUT_FORMAT_PCMFLOAT) == FMOD_CAPS_OUTPUT_FORMAT_PCMFLOAT)
    {
        *soundFormat = FMOD_SOUND_FORMAT_PCMFLOAT;
        *sampleSizeInBytes = sizeof(float);
    }
}

void AudioManager::GetDeviceCaps(int deviceID, int *minFreq, int *maxFreq) const
{
    FMOD_CAPS caps = 0;
    FMOD_RESULT result = m_FMODSystem->getRecordDriverCaps(deviceID, &caps, minFreq, maxFreq);

    if (result != FMOD_OK)
    {
        ReportError("Failed to get record driver caps", result);
    }
}

SoundHandle::Instance* AudioManager::CreateSound(int deviceID, int lengthSec, int frequency, SampleClip* sampleClip)
{
    if (!m_FMODSystem)
        return NULL;

    SoundHandle::Instance* instance = NULL;
    FMOD_CAPS caps = 0;
    FMOD_RESULT result = m_FMODSystem->getRecordDriverCaps(deviceID, &caps, NULL, NULL);

    if (result != FMOD_OK)
    {
        ReportError("Failed to get record driver caps", result);
        return NULL;
    }

    FMOD_SOUND_FORMAT soundFormat = FMOD_SOUND_FORMAT_NONE;
    int sampleSizeInBytes = 1;
    CapsToSoundFormat(caps, &soundFormat, &sampleSizeInBytes);

    FMOD_CREATESOUNDEXINFO exinfo;
    memset(&exinfo, 0, sizeof(FMOD_CREATESOUNDEXINFO));

    exinfo.cbsize           = sizeof(FMOD_CREATESOUNDEXINFO);
    exinfo.numchannels      = 1;
    exinfo.format           = soundFormat;
    exinfo.defaultfrequency = frequency;
    exinfo.length = exinfo.defaultfrequency * sampleSizeInBytes * exinfo.numchannels * lengthSec;

    FMOD_MODE mode = FMOD_3D | FMOD_SOFTWARE | FMOD_OPENUSER;
    result = CreateAllocationBoundSound(0, mode, &exinfo, &instance, sampleClip);

    if (result != FMOD_OK)
    {
        ReportError("Failed to create sound clip for recording", result);
        return NULL;
    }

    return instance;
}

PPtr<AudioClip> AudioManager::GetMicAudioClip(int deviceID)
{
    PPtr<AudioClip> audioClip;

    // We may have a Null AudioClip if it has been cleaned up by GC
    // by changing scenes for example.
    TMicAudioClipsMapItr itr = m_MicAudioClips.find(deviceID);
    if (itr == m_MicAudioClips.end() || m_MicAudioClips[deviceID].IsNull())
    {
        audioClip = NEW_OBJECT(AudioClip);
        m_MicAudioClips[deviceID] = audioClip;
    }
    else
    {
        audioClip = m_MicAudioClips[deviceID];
    }

    return audioClip;
}

PPtr<AudioClip> AudioManager::StartRecord(int deviceID, bool loop, int lengthSec, int frequency)
{
    if (!m_FMODSystem)
        return NULL;

    if (!HasMicrophoneAuthorization())
        return NULL;

    if (lengthSec <= 0)
    {
        ErrorString("Length of the recording must be greater than zero (0)");
        return NULL;
    }

    if (frequency <= 0)
    {
        ErrorString("Frequency must be greater than zero (0)");
        return NULL;
    }

#if UNITY_PS4
    if (frequency != 16000) // ps4 AudioIn only supports 16000Hz, so we need to drop out here, before we create the sound at the wrong frequency
    {
        ErrorString("Recording frequency must be 16000Hz");
        return NULL;
    }
#endif

    AudioClip* audioClip = static_cast<AudioClip*>(Object::Produce(TypeOf<AudioClip>()));
    SoundHandle::Instance* instance = CreateSound(deviceID, lengthSec, frequency, audioClip);

    if (instance == NULL)
    {
        DestroySingleObject(audioClip);
        return NULL;
    }

    FMOD_RESULT result = StartFMODRecord(m_FMODSystem, deviceID, instance, loop);

    if (result == FMOD_OK)
    {
        audioClip->Reset();
        audioClip->SetAwakeCalledInternal();

        audioClip->InitWSound(instance);
        audioClip->SetName("Microphone");

        return audioClip;
    }
    else
    {
        DestroySoundHandleInstance(instance);
        DestroySingleObject(audioClip);
        ReportError("Starting Microphone failed", result);
        return NULL;
    }
}

bool AudioManager::EndRecord(int deviceID)
{
    if (!m_FMODSystem)
        return false;

    m_FMODSystem->recordStop(deviceID);

    return true;
}

bool AudioManager::IsRecording(int deviceID) const
{
    if (!m_FMODSystem)
        return false;

    bool isRecording;
    m_FMODSystem->isRecording(deviceID, &isRecording);
    return isRecording;
}

unsigned AudioManager::GetRecordPosition(int deviceID) const
{
    if (!m_FMODSystem)
        return 0;

    unsigned pos;
    m_FMODSystem->getRecordPosition(deviceID, &pos);
    return pos;
}

#endif // ENABLE_MICROPHONE

AudioScriptBufferManager& AudioManager::GetScriptBufferManager()
{
    return *GetScriptBufferManagerPtr();
}

AudioScriptBufferManager* AudioManager::GetScriptBufferManagerPtr()
{
    if (m_ScriptBufferManager == 0)
    {
        InitScriptBufferManager();
    }

    return m_ScriptBufferManager;
}

bool AudioManager::ScriptBufferManagerIsInitialized()
{
    return (NULL != m_ScriptBufferManager);
}

void AudioManager::DidReloadDomain()
{
    GetAudioManager().GetScriptBufferManager().DidReloadDomain();
}

void AudioManager::BeforeDomainUnload()
{
    if (GetAudioManagerPtr() && GetAudioManager().ScriptBufferManagerIsInitialized())
        GetAudioManager().GetScriptBufferManager().BeforeDomainReload();
}

#if UNITY_EDITOR
void AudioManager::ResetAllAudioClipPlayCounts()
{
    dynamic_array<AudioClip*> files(kMemTempAlloc);
    Object::FindObjectsOfType(files);
    for (size_t i = 0; i < files.size(); i++)
    {
        files[i]->ResetPlayCount();
    }
}

void AudioManager::PlayClip(AudioClip& clip, int startSample, bool loop, bool twoD)
{
    // The old code just used the clips as they are, assuming they were preloaded and either already decompressed or compressed in memory (and in the old code, when running
    // in the editor clips were never streamed). Since the loading is much more flexible in the new system, we cannot make any such assumptions here and therefore load the
    // sound specifically for previewing here. This way it does not interfere with the other instances of the sound.

    if (!m_FMODSystem)
        return;

    SET_ALLOC_OWNER(this);

    // update FMOD to get any device changes
    m_FMODSystem->update();

    m_PreviewChannel.Clear();
    m_PreviewSound = clip.AllocatePreviewSound();
    if (m_PreviewSound.IsNull())
        return;

    m_PreviewChannel = m_PreviewSound.CreateChannel(true);

    if (m_PreviewChannel.IsValid())
    {
        m_PreviewChannel->setChannelGroup(m_ChannelGroup_Preview);

        FMOD_REVERB_CHANNELPROPERTIES rev;
        memset(&rev, 0, sizeof(rev));
        rev.Room = -10000;
        m_PreviewChannel->setReverbProperties(&rev);

        m_PreviewChannel->SetLoop(loop);

        // movie audio
        if (clip.GetMovie())
            clip.GetMovie()->SetAudioChannel(m_PreviewChannel);

        m_PreviewChannel->SetPaused(false);
    }
}

void AudioManager::LoopClip(const AudioClip& clip, bool loop)
{
    if (m_PreviewChannel.IsValid())
        m_PreviewChannel->SetLoop(loop);
}

void AudioManager::StopClip(const AudioClip& clip)
{
    if (m_PreviewChannel.IsValid())
        m_PreviewChannel->Stop();

    if (clip.GetMovie())
        clip.GetMovie()->SetAudioChannel(SoundChannel());
}

void AudioManager::StopAllClips()
{
    if (m_PreviewChannel.IsValid())
        m_PreviewChannel->Stop();
}

void AudioManager::PauseClip(const AudioClip& clip)
{
    if (m_PreviewChannel.IsValid())
        m_PreviewChannel->SetPaused(true);

    if (clip.GetMovie())
        clip.GetMovie()->SetAudioChannel(SoundChannel());
}

void AudioManager::ResumeClip(const AudioClip& clip)
{
    if (m_PreviewChannel.IsValid())
        m_PreviewChannel->SetPaused(false);
}

bool AudioManager::IsClipPlaying(const AudioClip& clip)
{
    bool isPlaying = false;
    if (m_PreviewChannel.IsValid())
        m_PreviewChannel->isPlaying(&isPlaying);
    return isPlaying;
}

float AudioManager::GetClipPosition(const AudioClip& clip)
{
    unsigned int pos = 0;
    if (m_PreviewChannel.IsValid())
        m_PreviewChannel->GetPositionMS(&pos);
    return (float)pos / 1000.f;
}

unsigned int AudioManager::GetClipSamplePosition(const AudioClip& clip)
{
    unsigned int pos = 0;
    if (m_PreviewChannel.IsValid())
        m_PreviewChannel->GetPositionPCM(&pos);
    return pos;
}

void AudioManager::SetClipSamplePosition(const AudioClip& clip, unsigned int iSamplePosition)
{
    if (m_PreviewChannel.IsValid())
    {
        FMOD::Sound* sound = NULL;
        if (m_PreviewChannel->getCurrentSound(&sound) == FMOD_OK)
        {
            // Only seek if inside sample (case 595965)
            unsigned int length = 0;
            if (sound->getLength(&length, FMOD_TIMEUNIT_PCM) == FMOD_OK && iSamplePosition < length)
                m_PreviewChannel->SetPositionPCM(iSamplePosition);
        }
    }
}

void AudioManager::ClearPreviewChannel(SoundChannel channel)
{
    if (m_PreviewChannel.Equals(channel))
    {
        // Clear the channel and the preview sound.
        // This way we clean up resources immediately when they stop playing
        // as this is called from the Channel stop callback.
        m_PreviewChannel.Clear();
        m_PreviewSound = SoundHandle();
    }
}

float AudioManager::GetMasterGroupLevel() const
{
    return sqrtf(m_MasterGroupLevel);
}

float AudioManager::GetMasterGroupClippingAmount() const
{
    return m_MasterGroupClipping;
}

bool AudioManager::GetMasterGroupMute() const
{
    return m_MasterGroupMute;
}

void AudioManager::SetMasterGroupMute(bool value)
{
    m_MasterGroupMute = value;
}

float AudioManager::GetDSPLoad() const
{
    if (!m_FMODSystem)
        return 0.0f;

    float cpu;
    m_FMODSystem->getCPUUsage(&cpu, NULL, NULL, NULL, NULL);
    return cpu * 0.01f;
}

float AudioManager::GetStreamLoad() const
{
    if (!m_FMODSystem)
        return 0.0f;

    float cpu;
    m_FMODSystem->getCPUUsage(NULL, &cpu, NULL, NULL, NULL);
    return cpu * 0.01f;
}

void AudioManager::SetEditingInPlaymode(bool enable)
{
    if (m_EditingInPlaymode != enable)
    {
        m_EditingInPlaymode = enable;
        for (TAudioMixersIterator i = m_Mixers.begin(), end = m_Mixers.end(); i != end; ++i)
        {
            AudioMixer& mixer = **i;
            mixer.OnEditingInPlayModeChanged();
        }
    }
}

bool AudioManager::IsEditingInPlaymode() const
{
    return m_EditingInPlaymode;
}

#endif // UNITY_EDITOR

SoundManager* AudioManager::GetSoundManager()
{
    return m_SoundManager;
}

dynamic_array<AudioEffectInternalDefinition*>& AudioManager::GetAudioEffectInternalDefinitions()
{
    if (m_AudioEffectInternalDefs.capacity() == 0)
        m_AudioEffectInternalDefs.reserve(1024);
    return m_AudioEffectInternalDefs;
}

IMPLEMENT_REGISTER_CLASS(AudioManager, 11);
IMPLEMENT_OBJECT_SERIALIZE(AudioManager);

GET_MANAGER(AudioManager)
GET_MANAGER_PTR(AudioManager)

extern "C" bool UnityAudioSupportsPositiveGains()
{
#ifdef UNITY_CLIPPING_THRESHOLD
    return UNITY_CLIPPING_THRESHOLD > 0.0f;
#endif
    return false;
}

#endif //ENABLE_AUDIO
