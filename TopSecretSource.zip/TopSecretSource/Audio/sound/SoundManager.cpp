#include "UnityPrefix.h"
#include "Runtime/BaseClasses/ManagerContext.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Audio/AudioManager.h"
#include "Runtime/Audio/sound/SoundUserData.h"
#include "Runtime/Input/TimeManager.h"
#include "Runtime/Threads/Thread.h"
#include "Runtime/Audio/AudioClip.h"
#include "SoundManager.h"
#include "Runtime/Audio/Utilities/Conversion.h"
#include "Runtime/Core/Callbacks/GlobalCallbacks.h"

#include "Runtime/Utilities/File.h"
#include "Runtime/File/StreamedResource.h"

void __audio_mainthread_check_internal(const char* funcname)
{
#if SUPPORT_THREADS
    if (!Thread::CurrentThreadIsMainThread())
    {
        ErrorString(Format("Function %s may only be called from main thread!", funcname));
        DEBUG_BREAK;
    }
#endif
}

class SampleClip;

// SoundHandle::Instances are moved between the m_PendingSounds, m_LoadedSounds and m_DisposedSounds lists of the SoundManager
class SoundHandle::Instance : public SoundHandleAPI, public ListNode<SoundHandle::Instance>
{
public:
    Instance();
    ~Instance();

public:
    void ReleaseIfNotReferenced();
    void Dispose();

    SoundChannel CreateChannel(SoundHandle& requester, bool paused);
    unsigned int GetMemoryInfoInternal(bool includeClones) const;
    void UpdateLoadState();

    inline WeakPtr<SoundHandle::Instance>& GetWeakPtr() { return m_WeakPtr; }

public:
    SoundUserData<SoundHandle::Instance>   m_UserData;
    int                                    m_SubSoundIndex;     // Index of subsound if this instance is a child of an FSB
    List<ListNode<SoundChannelInstance> >  m_Channels;          // Channels spawned by this FMOD::Sound instance (only compressed/decompressed allow multiple channels to be spawned from a shared FMOD::Sound)
    FMOD::Sound*                           m_FSB;               // Sound bank
    FMOD::Sound*                           m_Sound;             // Sub-sound
    SoundHandle::LoadState                 m_LoadState;         // Loading is a sequence of createSound -> getOpenState -> getSubSound -> getOpenState
    FMOD_MODE                              m_Mode;              // Sound creation flags
    WeakPtr<SampleClip>                    m_ParentSampleClip;  // Pre-resolved SampleClip (if any). Note that DestroyImmediate may destroy an AudioClip that's still used by FMOD, hence to avoid crashes in the profiler we must access it indirectly.
    UInt32                                 m_Flags;             // Combination of various bit flags defined in the Flags enum
    StreamedResource                       m_Resource;          // Path to sound file -- needed for forceful unloading when assets are regenerated
    List<ListNode<SoundChannelInstance> >  m_PendingChannels;   // Channels requested to play before sound finished loading (non-blocking comp/decomp sounds)
    SoundHandle::Instance*                 m_PrevClone;         // Implicit list of clones without any sentinel node (needed when determining memory usage and performing forced unloads or disposal).
    SoundHandle::Instance*                 m_NextClone;         // Implicit list of clones without any sentinel node (needed when determining memory usage and performing forced unloads or disposal).
    int                                    m_Age;               // Age of this sound
    bool                                   m_Disposed;          // Marks when an instance is disposed so any further channel playback requests can be rejected.
    WeakPtr<SoundHandle::Instance>         m_WeakPtr;           // Weak pointer to instance, used by SoundHandles

#if ENABLE_PROFILER
    static int s_GlobalCount;
#endif

    friend class SoundHandleAPI;
};

#if ENABLE_PROFILER
int SoundHandle::s_GlobalCount = 0;
int SoundHandle::Instance::s_GlobalCount = 0;
template<> int WeakPtr<SoundHandle::Instance>::s_GlobalCount = 0;
template<> int WeakPtr<SoundHandle::Instance>::SharedData::s_GlobalCount = 0;
#endif

SoundHandle::Instance::Instance()
    : ListNode<SoundHandle::Instance>(this)
    , m_UserData(this)
    , m_SubSoundIndex(-1)
    , m_FSB(NULL)
    , m_Sound(NULL)
    , m_LoadState(kUnloaded)
    , m_Mode(0)
    , m_Flags(0)
    , m_PrevClone(this)
    , m_NextClone(this)
    , m_Age(0)
    , m_Disposed(false)
    , m_WeakPtr(this, kMemAudio)
{
#if ENABLE_PROFILER
    AtomicIncrement(&s_GlobalCount);
#endif
}

SoundHandle::Instance::~Instance()
{
    AUDIO_MAINTHREAD_CHECK();
    SOUNDMANAGERWATCHDOG();

    // Stop channels before we release the sounds, because FMOD::Sound::release doesn't do it!
    while (!m_Channels.empty())
    {
        SoundChannelInstance* c = &*m_Channels.front();
        SOUNDMANAGERWATCHDOG_UPDATE();
        if (!c->m_PendingStop)
            c->Stop();
        else
        {
            c->~SoundChannelInstance();
            UNITY_FREE(kMemAudio, c);
        }
    }

    m_WeakPtr.Clear(); // Stop anyone from accessing the instance

    // Unlink from clone list
    m_PrevClone->m_NextClone = m_NextClone;
    m_NextClone->m_PrevClone = m_PrevClone;

    if (m_FSB != NULL)
        CheckFMODError(m_FSB->release());
    else if (m_Sound != NULL)
        CheckFMODError(m_Sound->release());

    RemoveFromList();
    m_Channels.clear();
    m_PendingChannels.clear();

#if ENABLE_PROFILER
    AtomicDecrement(&s_GlobalCount);
#endif
}

// The instance has a weak pointer, so the ref-count can never drop below 1 when SoundHandles release them. Therefore we need to check it here.
// Note that the situation is different for SoundChannel where the SoundChannelInstance destroys itself.
void SoundHandle::Instance::ReleaseIfNotReferenced()
{
    AUDIO_MAINTHREAD_CHECK();
    if (m_WeakPtr.GetRefCount() == 1 && (m_LoadState == SoundHandle::kFailed || m_LoadState == SoundHandle::kLoaded))
    {
        Assert(m_Channels.empty());
        Assert(m_PendingChannels.empty());
        GetSoundManager()->DisposeSound(this);
    }
}

// Immediate unload (API function): Stops playing channels, disposes sound instance.
// The actual unloading however may happen later if sound is still loading in order to avoid main thread stalls.
void SoundHandle::Instance::Dispose()
{
    AUDIO_MAINTHREAD_CHECK();
    SOUNDMANAGERWATCHDOG();

    // Keep instance alive for the scope of this function so that channel->Stop() doesn't delete it too early.
    SoundHandle tmphandle(this);

    // Stop all channels playing this sound
    List<ListNode<SoundChannelInstance> >::iterator it = m_Channels.begin();
    while (it != m_Channels.end())
    {
        SOUNDMANAGERWATCHDOG_UPDATE();
        // channel->Stop may modify list, so increment iterator prior to that
        SoundChannelInstance* channel = &(**it++);
        channel->Stop();
    }

    // Unlink from handle list, as no one should be able to use this instance after this call has executed. (Weak pointer is released in destructor, but may stay alive until last SoundHandle releases it.)
    m_WeakPtr.Clear();

    // Unlink from clone list
    m_PrevClone->m_NextClone = m_NextClone;
    m_NextClone->m_PrevClone = m_PrevClone;
    m_PrevClone = this;
    m_NextClone = this;

    // Move sound to dispose list for later destruction
    GetSoundManager()->DisposeSound(this);
}

static FMOD::Sound* GetFMODSubSound(FMOD::Sound* sound, int subSoundIndex)
{
    Assert(sound != NULL);

    int numSubSounds = 0;
    CheckFMODError(sound->getNumSubSounds(&numSubSounds));
    if (numSubSounds > 0)
    {
        Assert(subSoundIndex >= 0);
        Assert(subSoundIndex < numSubSounds);
        FMOD::Sound* subSound = NULL;
        FMOD_RESULT result = sound->getSubSound(subSoundIndex, &subSound);
        if (result == FMOD_OK)
            return subSound;
    }

    return NULL;
}

void SoundHandle::Instance::UpdateLoadState()
{
    AUDIO_MAINTHREAD_CHECK();
    FMOD_RESULT result;
    FMOD_OPENSTATE openstate;
    unsigned int pctbuffered;
    bool starving, diskbusy;
    switch (m_LoadState)
    {
        case kLoadingBase:
            result = m_FSB->getOpenState(&openstate, &pctbuffered, &starving, &diskbusy);
            // TODO: Handle error correctly, e.g. FMOD_ERR_FORMAT
            if (result == FMOD_OK)
            {
                if (openstate == FMOD_OPENSTATE_ERROR)
                {
                    m_LoadState = kFailed;
                }
                else if (openstate == FMOD_OPENSTATE_READY)
                {
                    m_Sound = GetFMODSubSound(m_FSB, m_SubSoundIndex);

                    if (m_Sound != NULL)
                    {
                        m_LoadState = kLoadingSub;
                    }
                    else
                    {
                        // Not an FSB
                        m_LoadState = kLoaded;
                        m_Sound = m_FSB;
                        m_FSB = NULL;
                    }
                }
            }
            break;
        case kLoadingSub:
            result = m_Sound->getOpenState(&openstate, &pctbuffered, &starving, &diskbusy);
            if (result == FMOD_OK)
            {
                if (openstate == FMOD_OPENSTATE_ERROR)
                {
                    m_LoadState = kFailed;
                    break;
                }
                else if (openstate == FMOD_OPENSTATE_READY)
                {
                    CheckFMODError(m_Sound->setUserData(&m_UserData));
                    m_LoadState = kLoaded;
                    break;
                }
            }
            break;
        default:
            AssertMsg(m_LoadState == kLoaded || m_LoadState == kFailed, "Invalid load state - possible cause: sounds not removed from pending list");
    }
}

// The requester handle is passed because cloning may allocate a new instance that the requester should be replaced by
SoundChannel SoundHandle::Instance::CreateChannel(SoundHandle& requester, bool paused)
{
    AUDIO_MAINTHREAD_CHECK();
    if (GetLoadState() == kFailed)
        return SoundChannel();

    Assert(!m_Disposed);
    if (m_Disposed)
    {
        ErrorString("Error: Trying to play disposed sound!\n");
        return SoundChannel();
    }

    // Streams and compressed tracker files can only play one sound at a time, so both the FSB and the subsound must be instanced (as they contain a file handle each)
    if ((m_Flags & SoundHandle::kInstanceLimitation) != 0 && !m_Channels.empty())
    {
        // This instance is already playing a stream, so in order to play additional concurrent streams we need to clone this sound instance, as each stream requires its own filehandle (in m_FSB)
        SoundHandle clone = GetSoundManager()->GetHandle(m_Resource, m_SubSoundIndex, m_Mode, m_Flags, m_ParentSampleClip, true);
        SoundHandle::Instance* cloneInstance = clone.m_WeakPtr;
        if (clone.IsNull())
            return SoundChannel();
        cloneInstance->m_PrevClone = this;
        cloneInstance->m_NextClone = m_NextClone;
        m_NextClone->m_PrevClone = cloneInstance;
        m_NextClone = cloneInstance;
        if (clone->GetLoadState() == kFailed)
        {
            GetSoundManager()->DisposeSound(cloneInstance);
            return SoundChannel();
        }
        requester = clone;
        if (clone->GetLoadState() == kLoaded)
            return cloneInstance->CreateChannel(requester, paused);
        SoundChannel channel = SoundChannel::Create(clone, paused);
        cloneInstance->m_PendingChannels.push_back(channel->m_PendingNode);
        cloneInstance->m_Channels.push_back(channel->m_ChannelsNode);
        return channel;
    }

    if (GetLoadState() == kLoaded)
    {
        // No channels are playing, so we can use this sound instance to create a new channel
        SoundChannel channel = SoundChannel::Create(requester, paused);
        FMOD::Channel* fmodchannel = NULL;
        FMOD_RESULT result = GetAudioManager().GetFMODSystem()->playSound(FMOD_CHANNEL_FREE, m_Sound, true, &fmodchannel);
        if (result != FMOD_OK || fmodchannel == NULL)
        {
            if (result == FMOD_ERR_CHANNEL_ALLOC)
                WarningStringObject("Ran out of virtual channels. Sound will not be played.", m_ParentSampleClip);
            else if (result == FMOD_ERR_NOTREADY)
            {
                WarningStringObject(Format("Streaming system overload -- deferring playback. FMOD Error: %s", FMOD_ErrorString(result)), m_ParentSampleClip);
                m_PendingChannels.push_back(channel->m_PendingNode);
                m_Channels.push_back(channel->m_ChannelsNode);
                return channel;
            }
            else
                ErrorStringObject(Format("Sound could not be played. FMOD Error: %s", FMOD_ErrorString(result)), m_ParentSampleClip);
            return SoundChannel();
        }
        channel->SetFMODChannel(fmodchannel);
        m_Channels.push_back(channel->m_ChannelsNode);
        return channel;
    }

    // Still loading
    SoundChannel channel = SoundChannel::Create(requester, paused);
    m_PendingChannels.push_back(channel->m_PendingNode);
    m_Channels.push_back(channel->m_ChannelsNode);
    return channel;
}

unsigned int SoundHandle::Instance::GetMemoryInfoInternal(bool includeClones) const
{
    AUDIO_MAINTHREAD_CHECK();
    unsigned int size = 0;
    if (m_LoadState == kLoaded)
    {
        if (m_FSB != NULL)
            CheckFMODError(m_FSB->getMemoryInfo(FMOD_MEMORY_ALL, 0, &size, NULL));
        else
            CheckFMODError(m_Sound->getMemoryInfo(FMOD_MEMORY_ALL, 0, &size, NULL));
    }
    return size + sizeof(SoundHandle::Instance);
}

SoundHandle::LoadState SoundHandleAPI::GetLoadState() const
{
    AUDIO_MAINTHREAD_CHECK();

    SoundHandle::Instance* instance = (SoundHandle::Instance*)this;
    if (instance == NULL)
        return kUnloaded;

    return instance->m_LoadState;
}

int SoundHandleAPI::GetMusicChannelCount() const
{
    AUDIO_MAINTHREAD_CHECK();

    SoundHandle::Instance* instance = (SoundHandle::Instance*)this;
    if (instance == NULL)
        return 0;

    if (instance->m_Sound == NULL)
        return 0;
    int c = 0;
    if (instance->m_Sound->getMusicNumChannels(&c) == FMOD_OK)
        return c;
    return 0;
}

bool SoundHandleAPI::SetData(const float* data, unsigned lengthSamples, unsigned offsetSamples)
{
    AUDIO_MAINTHREAD_CHECK();

    SoundHandle::Instance* instance = (SoundHandle::Instance*)this;
    if (instance == NULL)
        return false;

    if (instance->m_Sound == NULL)
        return false;

    if ((instance->m_Mode & FMOD_CREATESTREAM) != 0)
    {
        ErrorStringObject("Cannot set data on streamed samples. If the AudioClip was created via AudioClip.Create and no PCM read callback was provided, the 'stream' argument must be false. For a disk-based AudioClip changing the load type to DecompressOnLoad on the AudioClip will allow modification of the data.", instance->m_ParentSampleClip);
        return false;
    }

    if (instance->m_Flags & kAllowSharing)
    {
        ErrorStringObject("Cannot set data on shared sample", instance->m_ParentSampleClip);
        return false;
    }

    FMOD_SOUND_FORMAT format;
    int numChannels = 0, bitsPerSample = 0;
    CheckFMODError(instance->m_Sound->getFormat(NULL, &format, &numChannels, &bitsPerSample));
    switch (format)
    {
        case FMOD_SOUND_FORMAT_PCM8:
        case FMOD_SOUND_FORMAT_PCM16:
        case FMOD_SOUND_FORMAT_PCM24:
        case FMOD_SOUND_FORMAT_PCMFLOAT:
            break;
        default:
            ErrorStringObject("Cannot set data on compressed samples. Changing the load type to DecompressOnLoad on the AudioClip will fix this.", instance->m_ParentSampleClip);
            return false;
    }

    //Address of a pointer that will point to the first part of the locked data.
    void *ptr1 = NULL;

    //Address of a pointer that will point to the second part of the locked data. This will be null if the data locked hasn't wrapped at the end of the buffer.
    void *ptr2 = NULL;

    //Length of data in bytes that was locked for ptr1
    unsigned len1 = 0;

    //  Length of data in bytes that was locked for ptr2. This will be 0 if the data locked hasn't wrapped at the end of the buffer.
    unsigned len2 = 0;

    unsigned int clipSampleCount = 0;
    CheckFMODError(instance->m_Sound->getLength(&clipSampleCount, FMOD_TIMEUNIT_PCM));

    unsigned samplesToCopy = lengthSamples;
    if (lengthSamples > clipSampleCount)
    {
        SampleClip* clip = instance->m_ParentSampleClip;
        WarningString(Format("Data too long to fit the audioclip: %s. %i sample(s) discarded", (clip == NULL) ? "[UNLOADED]" : clip->GetName(), lengthSamples - clipSampleCount));
        samplesToCopy = clipSampleCount;
    }

    //Offset in bytes to the position you want to lock in the sample buffer.
    int offsetBytes = offsetSamples * numChannels * (bitsPerSample / 8);

    //Number of bytes you want to lock in the sample buffer.
    int lengthBytes = samplesToCopy * numChannels * (bitsPerSample / 8);

    FMOD_RESULT result;
    CheckFMODError(result = instance->m_Sound->lock(offsetBytes, lengthBytes, &ptr1, &ptr2, &len1, &len2));
    if (result != FMOD_OK)
        return false;

    if (ptr2 == NULL)
    {
        ArrayFromNormFloat(format, data, data + samplesToCopy * numChannels, ptr1);
    }
    else // wrap
    {
        ArrayFromNormFloat(format, data, data + (len1 / sizeof(float)), ptr1);
        ArrayFromNormFloat(format, data + len1 / sizeof(float), data + (len1 + len2) / sizeof(float), ptr2);
    }

    CheckFMODError(instance->m_Sound->unlock(ptr1, ptr2, len1, len2));
    return true;
}

bool SoundHandleAPI::GetData(float* data, unsigned lengthSamples, unsigned offsetSamples) const
{
    AUDIO_MAINTHREAD_CHECK();

    SoundHandle::Instance* instance = (SoundHandle::Instance*)this;
    if (instance == NULL)
        return false;

    if (instance->m_Sound == NULL)
        return false;

    if ((instance->m_Mode & FMOD_CREATESTREAM) != 0)
    {
        ErrorStringObject("Cannot get data from streamed samples. If the AudioClip was created via AudioClip.Create and no PCM read callback was provided, the 'stream' argument must be false. For a disk-based AudioClip changing the load type to DecompressOnLoad on the AudioClip will allow modification of the data.", instance->m_ParentSampleClip);
        return false;
    }

    FMOD_SOUND_FORMAT format;
    int numChannels = 0, bitsPerSample = 0;
    CheckFMODError(instance->m_Sound->getFormat(NULL, &format, &numChannels, &bitsPerSample));
    switch (format)
    {
        case FMOD_SOUND_FORMAT_PCM8:
        case FMOD_SOUND_FORMAT_PCM16:
        case FMOD_SOUND_FORMAT_PCM24:
        case FMOD_SOUND_FORMAT_PCMFLOAT:
            break;
        default:
            ErrorStringObject("Cannot get data on compressed samples. Changing the load type to DecompressOnLoad on the AudioClip will fix this.", instance->m_ParentSampleClip);
            return false;
    }

    //Address of a pointer that will point to the first part of the locked data.
    void *ptr1 = NULL;

    //Address of a pointer that will point to the second part of the locked data. This will be null if the data locked hasn't wrapped at the end of the buffer.
    void *ptr2 = NULL;

    //Length of data in bytes that was locked for ptr1
    unsigned len1 = 0;

    //  Length of data in bytes that was locked for ptr2. This will be 0 if the data locked hasn't wrapped at the end of the buffer.
    unsigned len2 = 0;

    unsigned clipSampleCount;
    CheckFMODError(instance->m_Sound->getLength(&clipSampleCount, FMOD_TIMEUNIT_PCM));

    unsigned samplesToCopy = lengthSamples;
    if (lengthSamples > clipSampleCount)
    {
        SampleClip* clip = instance->m_ParentSampleClip;
        WarningString(Format("Data longer than the AudioClip: %s. %i sample(s) copied", (clip == NULL) ? "[UNLOADED]" : clip->GetName(), clipSampleCount));
        samplesToCopy = clipSampleCount;
    }

    //Offset in bytes to the position you want to lock in the sample buffer.
    int offsetBytes = offsetSamples * numChannels * (bitsPerSample / 8);

    //Number of bytes you want to lock in the sample buffer.
    int lengthBytes = samplesToCopy  * numChannels * (bitsPerSample / 8);

    unsigned totalLengthBytes;
    CheckFMODError(instance->m_Sound->getLength(&totalLengthBytes, FMOD_TIMEUNIT_PCMBYTES));
    Assert((int)totalLengthBytes >= lengthBytes);

    FMOD_RESULT result;
    CheckFMODError(result = instance->m_Sound->lock(offsetBytes, lengthBytes, &ptr1, &ptr2, &len1, &len2));
    if (result != FMOD_OK)
        return false;

    if (ptr2 == NULL)
    {
        ArrayToNormFloat(format, ptr1, ((char*)ptr1 + len1), data);
    }
    else // wrap
    {
        if (len1 + len2 > (unsigned)lengthBytes)
        {
            WarningString(Format("Array can not hold the number of samples (%d)", (len1 + len2) - lengthBytes));
        }
        else
        {
            ArrayToNormFloat(format, ptr1, ((char*)ptr1 + len1), data);
            ArrayToNormFloat(format, ptr2, ((char*)ptr2 + len2), data + (len1 / 4));
        }
    }

    CheckFMODError(instance->m_Sound->unlock(ptr1, ptr2, len1, len2));
    return true;
}

unsigned int SoundHandleAPI::GetLengthPCM() const
{
    AUDIO_MAINTHREAD_CHECK();

    SoundHandle::Instance* instance = (SoundHandle::Instance*)this;
    if (instance == NULL)
        return 0;

    if (instance->m_LoadState == kLoaded)
    {
        unsigned int length = 0;
        CheckFMODError(instance->m_Sound->getLength(&length, FMOD_TIMEUNIT_PCM));
        return length;
    }

    return 0;
}

float SoundHandleAPI::GetLengthMS() const
{
    AUDIO_MAINTHREAD_CHECK();

    SoundHandle::Instance* instance = (SoundHandle::Instance*)this;
    if (instance == NULL)
        return 0.0f;

    if (instance->m_LoadState == kLoaded)
    {
        unsigned int length = 0;
        CheckFMODError(instance->m_Sound->getLength(&length, FMOD_TIMEUNIT_MS));
        return length;
    }

    return 0;
}

int SoundHandleAPI::GetNumChannels() const
{
    AUDIO_MAINTHREAD_CHECK();

    SoundHandle::Instance* instance = (SoundHandle::Instance*)this;
    if (instance == NULL)
        return 0;

    if (instance->m_LoadState == kLoaded)
    {
        int channels = 0;
        CheckFMODError(instance->m_Sound->getFormat(NULL, NULL, &channels, NULL));
        return channels;
    }

    return 0;
}

int SoundHandleAPI::GetBitsPerSample() const
{
    AUDIO_MAINTHREAD_CHECK();

    SoundHandle::Instance* instance = (SoundHandle::Instance*)this;
    if (instance == NULL)
        return 0;

    if (instance->m_LoadState == kLoaded)
    {
        int bits = 0;
        CheckFMODError(instance->m_Sound->getFormat(NULL, NULL, NULL, &bits));
        return bits;
    }

    return 0;
}

float SoundHandleAPI::GetFrequency() const
{
    AUDIO_MAINTHREAD_CHECK();

    SoundHandle::Instance* instance = (SoundHandle::Instance*)this;
    if (instance == NULL)
        return 0;

    if (instance->m_LoadState == kLoaded)
    {
        float frequency = 0.0f;
        CheckFMODError(instance->m_Sound->getDefaults(&frequency, NULL, NULL, NULL));
        return frequency;
    }

    return 0;
}

unsigned int SoundHandleAPI::GetMemoryInfo(bool includeClones) const
{
    AUDIO_MAINTHREAD_CHECK();

    SoundHandle::Instance* instance = (SoundHandle::Instance*)this;
    if (instance == NULL)
        return 0;

    if (includeClones)
    {
        SOUNDMANAGERWATCHDOG();
        unsigned int size = 0;
        SoundHandle::Instance* e = instance;
        do
        {
            SOUNDMANAGERWATCHDOG_UPDATE();
            size += e->GetMemoryInfoInternal(includeClones);
            e = e->m_NextClone;
        }
        while (e != instance);
        return size;
    }

    return instance->GetMemoryInfoInternal(false);
}

SoundHandle::SoundHandle()
{
#if ENABLE_PROFILER
    AtomicIncrement(&s_GlobalCount);
#endif
}

SoundHandle::SoundHandle(const SoundHandle& handle)
{
#if ENABLE_PROFILER
    AtomicIncrement(&s_GlobalCount);
#endif

    m_WeakPtr = handle.m_WeakPtr;
}

SoundHandle::SoundHandle(SoundHandle::Instance* instance)
{
#if ENABLE_PROFILER
    AtomicIncrement(&s_GlobalCount);
#endif

    if (instance != NULL)
        m_WeakPtr = instance->GetWeakPtr();
}

SoundHandle::~SoundHandle()
{
#if ENABLE_PROFILER
    AtomicDecrement(&s_GlobalCount);
#endif

    // ForceRelease sets the pointer of m_WeakPtr to NULL, so we need to get it first.
    // It can be NULL if SoundManager forcefully unloaded the sound, but in the general case the unloading will be triggered by the last handle's release
    // causing the disposal of the sound (which might take several frames if it happens at a time when the sound is still pre-buffering).
    Instance* instance = m_WeakPtr;
    m_WeakPtr.ForceRelease();
    if (instance != NULL)
    {
        AUDIO_MAINTHREAD_CHECK();
        instance->ReleaseIfNotReferenced();
    }
}

void SoundHandle::operator=(const SoundHandle& handle)
{
    if (m_WeakPtr == handle.m_WeakPtr)
        return;

    // ForceRelease sets the pointer of m_WeakPtr to NULL, so we need to get it first.
    // It can be NULL if SoundManager forcefully unloaded the sound, but in the general case the unloading will be triggered by the last handle's release
    // causing the disposal of the sound (which might take several frames if it happens at a time when the sound is still pre-buffering).
    Instance* instance = m_WeakPtr;
    m_WeakPtr = handle.m_WeakPtr;
    if (instance != NULL)
    {
        AUDIO_MAINTHREAD_CHECK();
        instance->ReleaseIfNotReferenced();
    }
}

void SoundHandle::Release()
{
    AUDIO_MAINTHREAD_CHECK();

    *this = SoundHandle();
}

SoundChannel SoundHandle::CreateChannel(bool paused)
{
    AUDIO_MAINTHREAD_CHECK();

    if (m_WeakPtr == NULL)
        return SoundChannel();

    if (m_WeakPtr->GetLoadState() == SoundHandle::kFailed)
        return SoundChannel();

    return m_WeakPtr->CreateChannel(*this, paused);
}

void SoundHandle::UnbindFromSampleClip()
{
    SoundHandle::Instance* instance = m_WeakPtr;
    if (instance == NULL)
        return;

    SampleClip* clip = instance->m_ParentSampleClip;
    if (clip == NULL)
        return;

    clip->ReleaseIfEqual(*this);
}

bool SoundHandle::IsStreamingFromDisk() const
{
    SoundHandle::Instance* instance = m_WeakPtr;
    if (instance == NULL)
        return false;

    return (instance->m_Mode & FMOD_CREATESTREAM) != 0 && instance->m_Resource.m_Size > 0;
}

SoundManager::SoundManager()
    : m_NumPendingSoundInstances(0)
    , m_NumLoadedSoundInstances(0)
    , m_NumDisposedSoundInstances(0)
    , m_NumPendingUnloads(0)
{
    AUDIO_MAINTHREAD_CHECK();

    GlobalCallbacks::Get().exitPlayModeAfterOnEnableInEditMode.Register(&SoundManager::OnExitPlayModeStatic);
}

SoundManager::~SoundManager()
{
    AUDIO_MAINTHREAD_CHECK();

    SOUNDMANAGERWATCHDOG();

    GlobalCallbacks::Get().exitPlayModeAfterOnEnableInEditMode.Unregister(&SoundManager::OnExitPlayModeStatic);

    // Flush pending loads
    while (!m_PendingSounds.empty())
    {
        SOUNDMANAGERWATCHDOG_UPDATE();
        Update();
        GetAudioManager().GetFMODSystem()->update();
    }

    // Dispose loaded sounds
    List<ListNode<SoundHandle::Instance> >::iterator it = m_LoadedSounds.begin();
    while (it != m_LoadedSounds.end())
    {
        SOUNDMANAGERWATCHDOG_UPDATE();
        DisposeSound(&(**it++));
    }

    // Flush disposed sounds
    FlushDisposedSounds();

    m_AllChannels.clear();
    m_ModifiedClips.clear();
    Assert(m_PendingSounds.empty());
    Assert(m_LoadedSounds.empty());
    Assert(m_DisposedSounds.empty());
}

void SoundManager::SetLoopPointsForClip(SampleClip* clip, FMOD::Sound* sound)
{
    if (clip->GetCompressionFormat() == SampleClip::kAAC)
    {
        const int aacPrimingFrames = 2112;
        // By convention, AAC encoders leave 2112 silent frames of encoding priming data.
        // https://developer.apple.com/library/mac/technotes/tn2258/_index.html#//apple_ref/doc/uid/DTS40009396-CH1-SECTION4
        // In my testing, both our windows and OS X encoding solutions seem to follow this practice.
        sound->setLoopPoints(aacPrimingFrames, FMOD_TIMEUNIT_PCM, aacPrimingFrames + clip->m_Length * clip->m_Frequency, FMOD_TIMEUNIT_PCM);
    }
}

FMOD_RESULT LoadFMODSound(SoundHandle::Instance** instance, const char* path, FMOD_MODE mode, SampleClip* ownerClip,
    unsigned int size, unsigned int offset, FMOD_CREATESOUNDEXINFO* exinfoIn)
{
    if (!instance)
        return FMOD_ERR_INVALID_PARAM;

    // Use the local ex if one is not passed.
    FMOD_CREATESOUNDEXINFO* exinfo = NULL;
    FMOD_CREATESOUNDEXINFO exinfoLocal;
    if (exinfoIn)
    {
        exinfo = exinfoIn;
    }
    else
    {
        memset(&exinfoLocal, 0, sizeof(exinfoLocal));
        exinfoLocal.cbsize = sizeof(FMOD_CREATESOUNDEXINFO);

        // FMOD calls createSound on its AsyncThread in FMOD_NONBLOCKING mode and therefore we can't handle FMOD_ERR_FORMAT error there.
        // So we don't enforce FSB type optimization and let FMOD to try other codecs that can open audio resource.
        // E.g. that can happen when we switch to WebGL platform where output format is set to WAV (see case 625140).
        if (!(mode & FMOD_NONBLOCKING))
            exinfoLocal.suggestedsoundtype = FMOD_SOUND_TYPE_FSB;

        exinfoLocal.fileoffset = offset;
        exinfoLocal.length = size;

        exinfo = &exinfoLocal;
    }

    SET_ALLOC_OWNER(ownerClip == 0 ? (void*)GetAudioManagerPtr() : (void*)ownerClip);

    // We must ensure that we have the userdata set for the createsound call
    *instance = UNITY_NEW(SoundHandle::Instance, kMemAudio);

    // Bootstrap the instance
    (*instance)->m_LoadState = (mode & FMOD_NONBLOCKING) ? SoundHandle::kLoadingBase : SoundHandle::kLoadingSub;
    (*instance)->m_Mode = mode;
    (*instance)->m_ParentSampleClip = ownerClip->GetWeakPtr();
    exinfo->userdata = &(*instance)->m_UserData;

    FMOD::Sound* sound = NULL;

    FMOD_RESULT result = GetAudioManager().GetFMODSystem()->createSound(path, mode, exinfo, &sound);
    if (result == FMOD_ERR_FORMAT)
    {
        // Try to detect format as FMOD should will not fall back to trying other types when FMOD_SOUND_TYPE_FSB is specified as the suggested type
        exinfoLocal.suggestedsoundtype = FMOD_SOUND_TYPE_UNKNOWN;
        result = GetAudioManager().GetFMODSystem()->createSound(path, mode, exinfo, &sound);
    }

    if (result != FMOD_OK)
    {
        ErrorStringMsg("Error: Cannot create FMOD::Sound instance for resource %s, (%s)", path, FMOD_ErrorString(result));
        UNITY_DELETE(*instance, kMemAudio);
        return result;
    }

    (*instance)->m_FSB = sound;
    (*instance)->m_Sound = NULL;

    return FMOD_OK;
}

FMOD_RESULT StartFMODRecord(FMOD::System* system, int deviceID, SoundHandle::Instance* instance, bool loop)
{
    FMOD::Sound* sound = (instance->m_FSB != NULL) ? instance->m_FSB : instance->m_Sound;
    return system->recordStart(deviceID, sound, loop);
}

void DestroySoundHandleInstance(SoundHandle::Instance* instance)
{
    if (instance)
        UNITY_DELETE(instance, kMemAudio);
}

// This is where we integrate
SoundHandle SoundManager::IntegrateFMODSound(SoundHandle::Instance* instance, const StreamedResource& resource,
    UInt32 flags, int subsound, SoundHandle::LoadState loadState)
{
    AUDIO_MAINTHREAD_CHECK();

    Assert(instance != NULL);

#if !UNITY_WEBGL
    if ((instance->m_Mode & FMOD_NONBLOCKING) == 0 && loadState == SoundHandle::kLoadingBase)
    {
        instance->m_Sound = GetFMODSubSound(instance->m_FSB, subsound);

        // if there is no subsound, then we need to switch the sound to the subsound
        if (!instance->m_Sound)
        {
            instance->m_Sound = instance->m_FSB;
            instance->m_FSB = NULL;
        }

        loadState = SoundHandle::kLoaded;
    }
#endif

    instance->m_Flags = flags;
    instance->m_SubSoundIndex = subsound;
    instance->m_LoadState = loadState;
    instance->m_Resource = resource;

    if (instance->m_Sound != NULL)
    {
        CheckFMODError(instance->m_Sound->setUserData(&instance->m_UserData));
    }

#if !UNITY_WEBGL
    if (loadState == SoundHandle::kLoaded)
        m_LoadedSounds.push_back(*instance);
    else
#endif
    m_PendingSounds.push_back(*instance);

    if (instance->m_FSB)
        SetLoopPointsForClip(instance->m_ParentSampleClip, instance->m_FSB);
    else if (instance->m_Sound)
        SetLoopPointsForClip(instance->m_ParentSampleClip, instance->m_Sound);

    return SoundHandle(instance);
}

SoundHandle SoundManager::GetHandle(const StreamedResource& resource, int subSoundIndex, FMOD_MODE mode, UInt32 flags, SampleClip* ownerClip, bool forceInstantiate)
{
    AUDIO_MAINTHREAD_CHECK();

    if (!forceInstantiate)
    {
        SOUNDMANAGERWATCHDOG();
        for (List<ListNode<SoundHandle::Instance> >::iterator it = m_LoadedSounds.begin(); it != m_LoadedSounds.end(); ++it)
        {
            SOUNDMANAGERWATCHDOG_UPDATE();
            SoundHandle::Instance* s = &(**it);
            if (s->m_Resource == resource && s->m_SubSoundIndex == subSoundIndex && s->m_Mode == mode && (s->m_Flags & SoundHandle::kAllowSharing) != 0)
                return SoundHandle(s);
        }
    }

    const char* path = resource.m_Source.c_str();
    unsigned int size = (unsigned int)resource.m_Size;
    unsigned int offset = (unsigned int)resource.m_Offset;

    SoundHandle::Instance* instance = NULL;
    FMOD_RESULT result = LoadFMODSound(&instance, path, mode, ownerClip, size, offset);
    if (result != FMOD_OK)
        return SoundHandle();

    return IntegrateFMODSound(instance, resource, flags, subSoundIndex, SoundHandle::kLoadingBase);
}

SoundHandle SoundManager::GetHandleFromFMODSound(SoundHandle::Instance* instance, UInt32 flags, SampleClip* ownerClip)
{
    AUDIO_MAINTHREAD_CHECK();

    // One would think this is not necessary but we should check here
    // in case for example, a WWW open call failed.
    if (instance == NULL)
        return SoundHandle();

    FMOD::Sound* sound = (instance->m_FSB != NULL) ? instance->m_FSB : instance->m_Sound;

    if (sound == NULL)
        return SoundHandle();

    SOUNDMANAGERWATCHDOG();
    for (List<ListNode<SoundHandle::Instance> >::iterator it = m_LoadedSounds.begin(); it != m_LoadedSounds.end(); ++it)
    {
        SOUNDMANAGERWATCHDOG_UPDATE();
        SoundHandle::Instance* s = &(**it);
        if (s->m_LoadState == SoundHandle::kLoaded && s->m_Sound == sound)
            return SoundHandle(s);
    }

    // Reset the instance sounds
    instance->m_FSB = sound;
    instance->m_Sound = NULL;

    return IntegrateFMODSound(instance, StreamedResource(), flags, -1, SoundHandle::kLoadingBase);
}

FMOD_RESULT F_API SoundManager::CreateSoundInternal(const char *name_or_data, FMOD_MODE mode, FMOD_CREATESOUNDEXINFO *exinfo,
    SoundHandle& handle, UInt32 flags, SampleClip* ownerClip)
{
    AUDIO_MAINTHREAD_CHECK();

    SoundHandle::Instance* instance = NULL;
    FMOD_RESULT result = LoadFMODSound(&instance, name_or_data, mode, ownerClip, 0, 0, exinfo);
    if (result != FMOD_OK)
    {
        handle = SoundHandle();
        return result;
    }

    // We are not using an FSB, so just setup the final clip state.
    instance->m_Sound = instance->m_FSB;
    instance->m_FSB = NULL;

    handle = IntegrateFMODSound(instance, StreamedResource(), flags, -1, SoundHandle::kLoaded);

    return result;
}

void SoundManager::UpdateChannels()
{
    AUDIO_MAINTHREAD_CHECK();

    List<ListNode<SoundChannelInstance> >::iterator it = m_AllChannels.begin();
    while (it != m_AllChannels.end())
    {
        SoundChannelInstance* channel = &(**it++);
        channel->Update();
    }
}

void SoundManager::Update()
{
    AUDIO_MAINTHREAD_CHECK();

    // This function lets channels perform delayed calls such as setting position on streams.
    // It's OK to call this once per frame since the amount of channels is usually low (< 100).
    UpdateChannels();

    SOUNDMANAGERWATCHDOG();
    int numPendingSoundInstances = 0;
    SoundList::iterator it = m_PendingSounds.begin();
    while (it != m_PendingSounds.end())
    {
        SOUNDMANAGERWATCHDOG_UPDATE();
        ++numPendingSoundInstances;
        SoundHandle::Instance* instance = &(**it++);
        ++instance->m_Age;
        instance->UpdateLoadState();
        if (instance->GetLoadState() == SoundHandle::kLoaded)
        {
            bool allChannelsHavePendingStopRequests = !instance->m_PendingChannels.empty();
            List<ListNode<SoundChannelInstance> >::iterator it = instance->m_PendingChannels.begin();
            while (it != instance->m_PendingChannels.end())
            {
                SOUNDMANAGERWATCHDOG_UPDATE();
                ListNode<SoundChannelInstance>& channel = *it++;
                FMOD::Channel* fmodchannel = NULL;
                if (!channel->HasPendingStopRequest())
                {
                    allChannelsHavePendingStopRequests = false;
                    FMOD_RESULT result = GetAudioManager().GetFMODSystem()->playSound(FMOD_CHANNEL_FREE, instance->m_Sound, true, &fmodchannel);
                    if (result != FMOD_OK || fmodchannel == NULL)
                    {
                        if (result == FMOD_ERR_CHANNEL_ALLOC)
                        {
                            WarningStringObject("Ran out of virtual channels. Sound will not be played.", instance->m_ParentSampleClip);
                            continue;
                        }
                        else if (result == FMOD_ERR_NOTREADY)
                        {
                            WarningStringObject(Format("Streaming system overload -- deferring playback. FMOD Error: %s", FMOD_ErrorString(result)), instance->m_ParentSampleClip);
                            continue;
                        }
                        else
                        {
                            ErrorStringObject(Format("Sound could not be played. FMOD Error: %s", FMOD_ErrorString(result)), instance->m_ParentSampleClip);
                            continue;
                        }
                    }
                    else
                    {
                        // Assign FMOD channel and apply parameter changes that have happened in the meantime while we waited for FSB creation and acquiring the subsound.
                        channel->SetFMODChannel(fmodchannel);
                        channel->ApplyBufferedParameters();
                        channel->UpdateVolume();
                        channel->UpdatePauseState();
                    }
                }
                channel.RemoveFromList();
            }
            if (allChannelsHavePendingStopRequests)
                GetSoundManager()->DisposeSound(instance);
            else
                m_LoadedSounds.push_back(*instance);
        }
        else if (instance->GetLoadState() == SoundHandle::kFailed)
        {
            GetSoundManager()->DisposeSound(instance);
        }
    }

    int numDisposedSoundInstances = 0;
    int numPendingUnloads = 0;
    it = m_DisposedSounds.begin();
    while (it != m_DisposedSounds.end())
    {
        SOUNDMANAGERWATCHDOG_UPDATE();
        ++numDisposedSoundInstances;
        SoundHandle::Instance* instance = &(**it++);
        if (instance->GetLoadState() == SoundHandle::kLoaded || instance->GetLoadState() == SoundHandle::kFailed)
        {
            // We need to wait for sounds to either succeed or fail loading, otherwise we will be stalling the main thread
            UNITY_DELETE(instance, kMemAudio);
        }
        else
        {
            ++numPendingUnloads;
            instance->UpdateLoadState();
        }
    }

    m_NumLoadedSoundInstances = m_LoadedSounds.size_slow();
    m_NumPendingSoundInstances = numPendingSoundInstances;
    m_NumDisposedSoundInstances = numDisposedSoundInstances;
    m_NumPendingUnloads = numPendingUnloads;
}

// Disposing sounds is non-blocking. Sounds will be moved to the m_DisposeSounds list from where they are deleted once the loading has advanced far enough to not cause any stalling.
void SoundManager::DisposeSound(SoundHandle::Instance* instance)
{
    AUDIO_MAINTHREAD_CHECK();

    if (instance->m_Disposed)
        return;

    //Assert(instance->m_NumRefs == 0);
    m_DisposedSounds.push_back(*instance);
    instance->m_Disposed = true;
}

void SoundManager::FlushDisposedSounds()
{
    AUDIO_MAINTHREAD_CHECK();

    SOUNDMANAGERWATCHDOG();

#if UNITY_WEBGL
    // For WebGL we can't wait for sound open state updates, as WebGL is single-threaded and hence will only update load state between frame updates.
    SoundList::iterator it = m_DisposedSounds.begin();
    while (it != m_DisposedSounds.end())
    {
        SOUNDMANAGERWATCHDOG_UPDATE();
        SoundHandle::Instance* instance = &(**it++);
        UNITY_DELETE(instance, kMemAudio);
    }
#else
    bool canSleep = false;
    while (!m_DisposedSounds.empty())
    {
        if (canSleep)
            Thread::Sleep(0.01f);
        else
            canSleep = true;

        SOUNDMANAGERWATCHDOG_UPDATE();
        Update();
        GetAudioManager().GetFMODSystem()->update();
    }
#endif
}

bool SoundManager::AwaitLoading(SoundHandle::Instance* instance)
{
    AUDIO_MAINTHREAD_CHECK();

    // Run two updates in order to make sure the sound either loaded or failed
    if (instance->GetLoadState() != SoundHandle::kLoaded && instance->GetLoadState() != SoundHandle::kFailed)
    {
        instance->UpdateLoadState();
        if (instance->GetLoadState() != SoundHandle::kLoaded && instance->GetLoadState() != SoundHandle::kFailed)
            instance->UpdateLoadState();
    }
    if (instance->GetLoadState() == SoundHandle::kFailed)
        return false;
    Assert(instance->GetLoadState() == SoundHandle::kLoaded);
    Assert(instance->m_Sound != NULL);
    return true;
}

void SoundManager::RegisterModifiedClip(SampleClip* clip)
{
    AUDIO_MAINTHREAD_CHECK();

    m_ModifiedClips.push_back(clip->m_NodeInModifiedClipList);
}

void SoundManager::UnloadClip(SampleClip* clip)
{
    AUDIO_MAINTHREAD_CHECK();

    SOUNDMANAGERWATCHDOG();

    const StreamedResource& resource = clip->GetResource();

    // Fix for case 849564: Calling AudioClip.UnloadAudioData on an external audio clip unloads all external audio clips and throws no errors
    // First check against m_ParentSampleClip, but note that m_ParentSampleClip can become NULL too when the AudioClip is unloaded elsewhere. In this case check against m_Resource.
    // Also note that instance->m_Resource is NULL for script-generated AudioClips such as WWW.getAudioClip, so this alone is not a sufficient check.

    SoundList::iterator it = m_PendingSounds.begin();
    while (it != m_PendingSounds.end())
    {
        SOUNDMANAGERWATCHDOG_UPDATE();
        SoundHandle::Instance* instance = &(**it++);
        if (instance->m_ParentSampleClip == clip || (instance->m_ParentSampleClip == NULL && instance->m_Resource == resource))
            instance->Dispose();
    }

    it = m_LoadedSounds.begin();
    while (it != m_LoadedSounds.end())
    {
        SOUNDMANAGERWATCHDOG_UPDATE();
        // Don't break here: there may be multiple instances of the sound loaded
        SoundHandle::Instance* instance = &(**it++);
        if (instance->m_ParentSampleClip == clip || (instance->m_ParentSampleClip == NULL && instance->m_Resource == resource))
            instance->Dispose();
    }

    FlushDisposedSounds();

    clip->m_NodeInModifiedClipList.RemoveFromList();
}

void SoundManager::OnExitPlayModeStatic()
{
    AUDIO_MAINTHREAD_CHECK();

    GetSoundManager()->OnExitPlayMode();
}

void SoundManager::OnExitPlayMode()
{
    AUDIO_MAINTHREAD_CHECK();

    SOUNDMANAGERWATCHDOG();
    List<ListNode<SampleClip> >::iterator it = m_ModifiedClips.begin();
    while (it != m_ModifiedClips.end())
    {
        SOUNDMANAGERWATCHDOG_UPDATE();
        // The iterator must be incremented prior to the UnloadClip call, as it modifies the list.
        SampleClip* clip = &(**it++);
        if (!clip->m_PreloadAudioData)
            clip->UnloadAudioData();
        else
        {
            // AudioClips allow modification via GetData/SetData
            AudioClip* ac = (AudioClip*)clip;
            ac->Reload();
        }
    }

    Assert(m_ModifiedClips.empty());
}

#if ENABLE_PROFILER
void SoundManager::GetProfilerData(AudioStats& audioStats)
{
    AUDIO_MAINTHREAD_CHECK();

    audioStats.numSoundHandles = SoundHandle::s_GlobalCount;
    audioStats.numSoundHandleInstances = SoundHandle::Instance::s_GlobalCount;
    audioStats.numPendingSoundHandleInstances = m_NumPendingSoundInstances;
    audioStats.numLoadedSoundHandleInstance = m_NumLoadedSoundInstances;
    audioStats.numDisposedSoundHandleInstances = m_NumDisposedSoundInstances;
    audioStats.numPendingSoundInstanceUnloads = m_NumPendingUnloads;
    audioStats.numSoundChannelInstanceWeakPtrs = WeakPtr<SoundChannelInstance>::s_GlobalCount;
    audioStats.numSoundHandleInstanceWeakPtrs = WeakPtr<SoundHandle::Instance>::s_GlobalCount;
    audioStats.numSampleClipWeakPtrs = WeakPtr<SampleClip>::s_GlobalCount;
    audioStats.numWeakPtrSharedData = WeakPtrSharedData::s_GlobalCountBase;
    audioStats.numWeakPtrSharedDataSoundChannel = WeakPtr<SoundChannelInstance>::SharedData::s_GlobalCount;
    audioStats.numWeakPtrSharedDataSoundHandle = WeakPtr<SoundHandle::Instance>::SharedData::s_GlobalCount;
    audioStats.numWeakPtrSharedDataSampleClip = WeakPtr<SampleClip>::SharedData::s_GlobalCount;
}

#endif

FMOD_RESULT SoundManager::OnCreateSoundPushAllocation(void* _userdata)
{
#if ENABLE_MEM_PROFILER && ENABLE_AUTO_SCOPED_ROOT
    SoundUserData<SoundHandle::Instance>* userdata = (SoundUserData<SoundHandle::Instance>*)_userdata;
    SoundHandle::Instance* instance = userdata->TryGet();
    if (instance == NULL)
        return FMOD_ERR_INVALID_PARAM;
    return push_allocation_root(instance->m_ParentSampleClip, NULL, false) ? FMOD_OK : FMOD_ERR_INVALID_PARAM; // Returning anything else than FMOD_OK will prevent a call to OnCreateSoundPopAllocation
#else
    return FMOD_ERR_INVALID_PARAM;
#endif
}

FMOD_RESULT SoundManager::OnCreateSoundPopAllocation()
{
#if ENABLE_MEM_PROFILER && ENABLE_AUTO_SCOPED_ROOT
    pop_allocation_root();
#endif
    return FMOD_OK;
}

void SoundManager::CaptureProfilerInfo(dynamic_array<AudioProfilerClipInfo>& info, dynamic_array<char>& names)
{
    List<ListNode<SoundHandle::Instance> >::iterator it;

    it = m_PendingSounds.begin();
    while (it != m_PendingSounds.end())
    {
        SOUNDMANAGERWATCHDOG_UPDATE();
        SoundHandle::Instance* instance = &(**it++);
        SampleClip* clip = instance->m_ParentSampleClip;
        if (clip == NULL)
            continue;
        AudioProfilerClipInfo i;
        i.assetInstanceId = clip->GetInstanceID();
        i.assetNameOffset = names.size();
        const char* s = clip->GetName();
        while (*s)
            names.push_back(*s++);
        names.push_back(0);
        i.loadState = instance->m_LoadState;
        i.internalLoadState = 0;
        i.age = instance->m_Age;
        i.disposed = instance->m_Disposed ? 1 : 0;
        i.numChannelInstances = instance->m_Channels.size_slow();
        info.push_back(i);
    }

    it = m_LoadedSounds.begin();
    while (it != m_LoadedSounds.end())
    {
        SOUNDMANAGERWATCHDOG_UPDATE();
        SoundHandle::Instance* instance = &(**it++);
        SampleClip* clip = instance->m_ParentSampleClip;
        if (clip == NULL)
            continue;
        AudioProfilerClipInfo i;
        i.assetInstanceId = clip->GetInstanceID();
        i.assetNameOffset = names.size();
        const char* s = clip->GetName();
        while (*s)
            names.push_back(*s++);
        names.push_back(0);
        i.loadState = instance->m_LoadState;
        i.internalLoadState = 1;
        i.age = instance->m_Age;
        i.disposed = instance->m_Disposed ? 1 : 0;
        i.numChannelInstances = instance->m_Channels.size_slow();
        info.push_back(i);
    }

    it = m_DisposedSounds.begin();
    while (it != m_DisposedSounds.end())
    {
        SOUNDMANAGERWATCHDOG_UPDATE();
        SoundHandle::Instance* instance = &(**it++);
        SampleClip* clip = instance->m_ParentSampleClip;
        if (clip == NULL)
            continue;
        AudioProfilerClipInfo i;
        i.assetInstanceId = clip->GetInstanceID();
        i.assetNameOffset = names.size();
        i.age = instance->m_Age;
        i.disposed = instance->m_Disposed ? 1 : 0;
        i.numChannelInstances = instance->m_Channels.size_slow();
        const char* s = clip->GetName();
        while (*s)
            names.push_back(*s++);
        names.push_back(0);
        i.loadState = instance->m_LoadState;
        i.internalLoadState = 2;
        info.push_back(i);
    }
}

SampleClip* GetParentSampleClipFromInstance(SoundHandle::Instance* instance)
{
    // No thread check here because this can be called from PCM script callbacks
    return instance->m_ParentSampleClip;
}

SoundManager* GetSoundManager()
{
    AUDIO_MAINTHREAD_CHECK();

    return GetAudioManager().GetSoundManager();
}
