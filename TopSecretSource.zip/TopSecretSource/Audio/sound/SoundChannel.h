#ifndef _SOUNDCHANNEL_H_
#define _SOUNDCHANNEL_H_

#include "Runtime/Audio/sound/SoundUserData.h"
#include "Runtime/Audio/sound/SoundManager.h"
#include "Runtime/Audio/correct_fmod_includer.h"

struct SoundControllerMemory;
class AudioSource;

#if 1

inline FMOD_RESULT _CheckFMODError(FMOD_RESULT result, const char* filename, int line, const char* funcname)
{
    if (result != FMOD_OK)
        ErrorStringMsg("%s(%d) : Error executing %s (%s)", filename, line, funcname, FMOD_ErrorString(result));
    return result;
}

    #define CheckFMODError(...) _CheckFMODError(__VA_ARGS__, __FILE__, __LINE__, #__VA_ARGS__)

#else

    #define CheckFMODError(...) (__VA_ARGS__)

#endif

class SoundChannel;

class SoundChannelSharedDefs
{
public:
    enum Flag
    {
        ONESHOT = 1 << 0,
    };
};

// INTERNAL CHANNEL INSTANCE -- all access to this is happening through the SoundChannel handle
// Wrapping the FMOD::Channel into a class is also necessary, because we need a place to store state for channels that are temporarily deactivated by the SoundManager to free up CPU or streaming
// bandwidth, so by dealing with SoundChannel instances rather than FMOD::Channel handles everywhere in the Unity audio code base we are guaranteed to have an interface that returns meaningful
// information back to the higher-level logical control layers even though the low-level system is not doing any intensive work.
class SoundChannelInstance : public SoundChannelSharedDefs
{
private:
    // Hide destructor, as SoundChannels destroy themselves when Stop() is called.
    // Also, all SoundChannelInstances should be allocated via SoundChannel::Create in order to set the proper memory labels.
    // Make sure that derived classes like ProceduralSoundChannel, BufferedSoundChannel, VideoSoundChannel, ScriptedSoundChannel follow this pattern.
    SoundChannelInstance(SoundHandle sound, bool paused);
    virtual ~SoundChannelInstance();

    static FMOD_RESULT F_CALLBACK FMODChannelCallback(FMOD_CHANNEL *channel, FMOD_CHANNEL_CALLBACKTYPE type, void *commanddata1, void *commanddata2);

public:
    inline WeakPtr<SoundChannelInstance>& GetWeakPtr() { return m_WeakPtr; }

    // This is called for pending channels, i.e. channels that were requested to play before the FMOD::Sounds finished loading
    void SetFMODChannel(FMOD::Channel* fmodchannel);

    inline void SetAmbientVolume(float volume)       { m_AmbientVolume = volume; UpdateVolume(); }
    inline void SetBlendVolume(float volume)         { m_BlendVolume = volume; UpdateVolume(); }
    inline void SetVolume(float volume)              { m_ChannelVolume = volume; UpdateVolume(); }
    inline void SetOneshotVolume(float volume)       { m_OneShotVolume = volume; UpdateVolume(); }
    inline void SetPitch(float pitch)                { m_Pitch = pitch; UpdatePitch(); }
    inline void SetDopplerPitch(float pitch)         { m_DopplerPitch = pitch; UpdatePitch(); }

    inline bool GetPaused() const                    { return m_ChannelPaused; }
    inline void SetPaused(bool paused)               { m_ChannelPaused = paused; UpdatePauseState(); }
    inline void SetGamePaused(bool paused)           { m_GamePaused = paused; UpdatePauseState(); }
    inline void SetEditorPaused(bool paused)         { m_EditorPaused = paused; UpdatePauseState(); }

    inline void SetAudioSource(AudioSource* source)  { m_AudioSource = source; }
    inline AudioSource* GetAudioSource() const       { return m_AudioSource; }

    inline bool HasPendingPlayRequest() const        { return m_PendingNode.IsInList(); }
    inline bool HasPendingStopRequest() const        { return m_PendingStop; }

    inline FMOD::Channel* GetFMODChannel() const     { return m_FMODChannel; }

    inline void SetFlag(Flag flag)                   { m_Flags |= flag; }
    inline bool GetFlag(Flag flag)                   { return (m_Flags & flag) != 0; }

    void ApplyBufferedParameters();

    void Stop();

    void UpdateVolume();
    void UpdatePitch();
    void UpdatePauseState();

    // FMOD delegate functions
    // Notice that some of these are intentionally left out, as there is higher-level functionality that overrides them (i.e. SetPaused, GetPaused, etc.)
    // setMode/getMode delegates are not provided, because they modify state and mimicking this logic gets way too complex for the parameter buffer

    FMOD_RESULT F_API getCurrentSound(FMOD::Sound** sound);
    FMOD_RESULT F_API getDelay(FMOD_DELAYTYPE delaytype, unsigned int* delayhi, unsigned int* delaylo);

    FMOD_RESULT F_API isPlaying(bool* playing);

    FMOD_RESULT F_API set3DAttributes(const FMOD_VECTOR* pos, const FMOD_VECTOR* vel);
    FMOD_RESULT F_API set3DConeOrientation(FMOD_VECTOR* orientation);
    FMOD_RESULT F_API get3DConeOrientation(FMOD_VECTOR* orientation);
    FMOD_RESULT F_API set3DConeSettings(float insideconeangle, float outsideconeangle, float outsidevolume);
    FMOD_RESULT F_API set3DDopplerLevel(float dopplerlevel);
    FMOD_RESULT F_API set3DMinMaxDistance(float minDist, float maxDist);
    FMOD_RESULT F_API set3DPanLevel(float panlevel);
    FMOD_RESULT F_API set3DSpread(float spread);
    FMOD_RESULT F_API setCallback(FMOD_CHANNEL_CALLBACK callback);
    FMOD_RESULT F_API setChannelGroup(FMOD::ChannelGroup* group);
    FMOD_RESULT F_API setDelay(FMOD_DELAYTYPE delaytype, unsigned int delayhi, unsigned int delaylo);
    FMOD_RESULT F_API setMute(bool mute);
    FMOD_RESULT F_API setPan(float pan);
    FMOD_RESULT F_API setPriority(int priority);
    FMOD_RESULT F_API setReverbProperties(FMOD_REVERB_CHANNELPROPERTIES* reverbproperties);
    FMOD_RESULT F_API getReverbProperties(FMOD_REVERB_CHANNELPROPERTIES* reverbproperties);
    FMOD_RESULT F_API isVirtual(bool* isVirtual);

    // Replacements functions for getPosition which doesn't fit into the buffering scheme because of the FMOD_TIMEUNIT selector
    FMOD_RESULT F_API GetPositionPCM(unsigned int* position_pcm);
    FMOD_RESULT F_API GetPositionMS(unsigned int* position_ms);
    FMOD_RESULT F_API SetPositionPCM(unsigned int position_pcm);
    FMOD_RESULT F_API SetPositionMS(unsigned int position_ms);

    // Replacements functions for setMode-based calls that are too complex to handle for our buffering method
    FMOD_RESULT F_API SetLoop(bool loop);

    void              Update();

private:
    // When a sound is loaded in the background and immediately after initiating the load a channel instance is created, we need to buffer FMOD parameters that cannot be set,
    // because no corresponding FMOD::Channel object exists yet that can take them.
    struct ParameterBuffer
    {
        #define ParameterDeclarations\
            DefineParam(FMOD_VECTOR, pos);\
            DefineParam(FMOD_VECTOR, vel);\
            DefineParam(FMOD_VECTOR, orientation);\
            DefineParam(float, insideconeangle);\
            DefineParam(float, outsideconeangle);\
            DefineParam(float, outsidevolume);\
            DefineParam(float, dopplerlevel);\
            DefineParam(float, minDist);\
            DefineParam(float, maxDist);\
            DefineParam(float, panlevel);\
            DefineParam(float, spread);\
            DefineParam(FMOD_CHANNEL_CALLBACK, callback);\
            DefineParam(FMOD::ChannelGroup*, group);\
            DefineArray(unsigned int, delayhi, FMOD_DELAYTYPE_MAX);\
            DefineArray(unsigned int, delaylo, FMOD_DELAYTYPE_MAX);\
            DefineParam(float, pan);\
            DefineParam(unsigned int, position_pcm);\
            DefineParam(unsigned int, position_ms);\
            DefineParam(int, priority);\
            DefineParam(FMOD_REVERB_CHANNELPROPERTIES, reverbproperties);\
            DefineParam(bool, mute);\
            DefineParam(bool, loop);

        #define DefineParam(type, name)      type name
        #define DefineArray(type, name, size) type name[size]
        ParameterDeclarations
        #undef DefineParam
        #undef DefineArray

        #define DefineParam(type, name)      bool name##_dirty : 1
        #define DefineArray(type, name, size) unsigned int name##_dirty : size
        ParameterDeclarations
        #undef DefineParam
        #undef DefineArray

        ParameterBuffer();
        bool m_HasModifiedParams : 1;
        void Apply(FMOD::Channel* channel);
    } m_ParameterBuffer;

    SoundUserData<SoundChannelInstance>              m_UserData;
    FMOD::Channel*                                   m_FMODChannel;
    SoundHandle                                      m_Sound;         // Sound played by channel
    ListNode<SoundChannelInstance>                   m_ChannelsNode;  // SoundHandle::Instance keeps track of channels in order to handle instantiation of streams in its m_Channels list
    ListNode<SoundChannelInstance>                   m_PendingNode;   // SoundHandle::Instance keeps track of pending channels in order to handle deferred parameter changes in its m_PendingChannels list
    ListNode<SoundChannelInstance>                   m_UpdateNode;    // Certain operations such as seeking may not be performed immediately and therefore FrameUpdate() will try to apply such deferred parameters

    // Subsystems like the ambience manager may set the ambient volume at any point. All the volumes get combined to a final volume passed to FMOD::Channel::setVolume
    // This could also have been solved by letting the SoundChannel know the SoundAmbienceManager, but would introduce a two-way dependency between the systems, so it
    // is more elegant to buffer the values that the control systems write into the lowlevel channels.

    float                                            m_AmbientVolume; // for built-in room systems
    float                                            m_BlendVolume;   // set by blend node weights
    float                                            m_ChannelVolume; // the individual channel volume
    float                                            m_OneShotVolume; // only used for oneshots, so can be removed when we get rid of AudioSource
    float                                            m_Pitch;         // current pitch scale factor
    float                                            m_DopplerPitch;  // current pitch adjustment due to the Doppler effect
    float                                            m_BaseFrequency; // read from the assigned channel's current sound

    bool                                             m_ChannelPaused;
    bool                                             m_GamePaused;
    bool                                             m_EditorPaused;
    bool                                             m_PendingStop;   // Stop the channel right after it was created (for very fast Play() / Stop() call sequences)

    AudioSource*                                     m_AudioSource;
    UInt32                                           m_Flags;

    WeakPtr<SoundChannelInstance>                    m_WeakPtr;       // All SoundChannel handles point to this instance via the weak ptr

public:
#if ENABLE_PROFILER
    static int s_GlobalCount;
#endif

    friend class SoundChannel;
    friend class SoundHandle;
    friend class SoundHandle::Instance;
};

// This is the handle used throughout the code, basically a smarter replacement for the FMOD::Channel* handles.
// The difference here is that a SoundChannelInstance keeps track of all SoundChannel handles referencing it like a weak pointer, so whenever some code destroys SoundChannelInstance,
// the list of references is reset too. The difference from a normal weak pointer is that after destroying the referenced instance, the instance now dereferences to s_NullInstance
// instance, so any function calls via -> can still be passed to this, but doesn't do any work. It should be considered a last resort though (the old audio system was calling a lot
// of FMOD functions on invalid/expired handles which went by undetected), so during development however, we want it to throw assertions that we can find code that doesn't properly
// check for instances that become inactive. This all helps keep track of shared pointers such as channels that are simultaneously used by the video player and by the normal audio system.

class SoundChannel : public SoundChannelSharedDefs
{
public:
    SoundChannel()
    {
#if ENABLE_PROFILER
        AtomicIncrement(&s_GlobalCount);
#endif
    }

    explicit SoundChannel(SoundChannelInstance* instance)
    {
#if ENABLE_PROFILER
        AtomicIncrement(&s_GlobalCount);
#endif
        if (instance != NULL)
            m_WeakPtr = instance->GetWeakPtr();
    }

    SoundChannel(const SoundChannel& c)
    {
#if ENABLE_PROFILER
        AtomicIncrement(&s_GlobalCount);
#endif
        m_WeakPtr = c.m_WeakPtr;
    }

    ~SoundChannel()
    {
#if ENABLE_PROFILER
        AtomicDecrement(&s_GlobalCount);
#endif
    }

public:
    inline SoundChannelInstance* operator->() const
    {
        AUDIO_MAINTHREAD_CHECK();
        return m_WeakPtr;
    }

    inline SoundChannel& operator=(const SoundChannel& c)
    {
        m_WeakPtr = c.m_WeakPtr;
        return *this;
    }

    inline bool IsNull() const
    {
        return m_WeakPtr == NULL;
    }

    inline bool IsValid() const
    {
        return m_WeakPtr != NULL;
    }

    inline bool Equals(const SoundChannel& c) const
    {
        return m_WeakPtr == c.m_WeakPtr;
    }

    inline bool Equals(const WeakPtr<SoundChannelInstance>& weakptr) const
    {
        return m_WeakPtr == weakptr;
    }

    inline void Clear()
    {
        m_WeakPtr.Clear();
    }

    static inline SoundChannel Create(SoundHandle sound, bool paused)
    {
        AUDIO_MAINTHREAD_CHECK();
        return SoundChannel(UNITY_NEW(SoundChannelInstance, kMemAudio)(sound, paused));
    }

    WeakPtr<SoundChannelInstance> m_WeakPtr;

#if ENABLE_PROFILER
    static int s_GlobalCount;
#endif

    friend class SoundChannelInstance;
    friend class SoundHandle;
    friend class SoundManager;

    // SoundChannelInstance API wrappers

#define AUDIO_WRAP_INSTANCE_API(callWithArgs)   \
    do {                                                \
        SoundChannelInstance* ptr = m_WeakPtr;          \
        if (ptr == NULL)                                \
            return;                                     \
        ptr->callWithArgs;                              \
    } while (0)

#define AUDIO_WRAP_INSTANCE_API_RETURN(callWithArgs, defaultRetval) \
    do {                                                \
        SoundChannelInstance* ptr = m_WeakPtr;          \
        if (ptr == NULL)                                \
            return defaultRetval;                       \
        return ptr->callWithArgs;                       \
    } while (0)

    // This is called for pending channels, i.e. channels that were requested to play before the FMOD::Sounds finished loading
    void SetFMODChannel(FMOD::Channel* fmodchannel)  { AUDIO_WRAP_INSTANCE_API(SetFMODChannel(fmodchannel)); }

    void SetAmbientVolume(float volume)         { AUDIO_WRAP_INSTANCE_API(SetAmbientVolume(volume)); }
    void SetBlendVolume(float volume)           { AUDIO_WRAP_INSTANCE_API(SetBlendVolume(volume)); }
    void SetVolume(float volume)                { AUDIO_WRAP_INSTANCE_API(SetVolume(volume)); }
    void SetOneshotVolume(float volume)         { AUDIO_WRAP_INSTANCE_API(SetOneshotVolume(volume)); }
    void SetPitch(float pitch)                  { AUDIO_WRAP_INSTANCE_API(SetPitch(pitch)); }

    bool GetPaused() const                      { AUDIO_WRAP_INSTANCE_API_RETURN(GetPaused(), true); }
    void SetPaused(bool paused)                 { AUDIO_WRAP_INSTANCE_API(SetPaused(paused)); }
    void SetGamePaused(bool paused)             { AUDIO_WRAP_INSTANCE_API(SetGamePaused(paused)); }
    void SetEditorPaused(bool paused)           { AUDIO_WRAP_INSTANCE_API(SetEditorPaused(paused)); }

    void SetAudioSource(AudioSource* source)    { AUDIO_WRAP_INSTANCE_API(SetAudioSource(source)); }
    AudioSource* GetAudioSource() const         { AUDIO_WRAP_INSTANCE_API_RETURN(GetAudioSource(), NULL); }

    bool HasPendingStopRequest() const          { AUDIO_WRAP_INSTANCE_API_RETURN(HasPendingStopRequest(), false); }

    FMOD::Channel* GetFMODChannel() const       { AUDIO_WRAP_INSTANCE_API_RETURN(GetFMODChannel(), NULL); }

    void SetFlag(Flag flag)                     { AUDIO_WRAP_INSTANCE_API(SetFlag(flag)); }
    bool GetFlag(Flag flag)                     { AUDIO_WRAP_INSTANCE_API_RETURN(GetFlag(flag), false); }

    void ApplyBufferedParameters()  { AUDIO_WRAP_INSTANCE_API(ApplyBufferedParameters()); }

    void Stop()                     { AUDIO_WRAP_INSTANCE_API(Stop()); }

    void UpdateVolume()             { AUDIO_WRAP_INSTANCE_API(UpdateVolume()); }
    void UpdatePitch()              { AUDIO_WRAP_INSTANCE_API(UpdatePitch()); }
    void UpdatePauseState()         { AUDIO_WRAP_INSTANCE_API(UpdatePauseState()); }

    // FMOD delegate functions
    // Notice that some of these are intentionally left out, as there is higher-level functionality that overrides them (i.e. SetPaused, GetPaused, etc.)
    // setMode/getMode delegates are not provided, because they modify state and mimicking this logic gets way too complex for the parameter buffer

    FMOD_RESULT F_API getCurrentSound(FMOD::Sound** sound)
    { AUDIO_WRAP_INSTANCE_API_RETURN(getCurrentSound(sound), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API getDelay(FMOD_DELAYTYPE delaytype, unsigned int* delayhi, unsigned int* delaylo)
    { AUDIO_WRAP_INSTANCE_API_RETURN(getDelay(delaytype, delayhi, delaylo), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API isPlaying(bool* playing)
    { AUDIO_WRAP_INSTANCE_API_RETURN(isPlaying(playing), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API set3DAttributes(const FMOD_VECTOR* pos, const FMOD_VECTOR* vel)
    { AUDIO_WRAP_INSTANCE_API_RETURN(set3DAttributes(pos, vel), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API set3DConeOrientation(FMOD_VECTOR* orientation)
    { AUDIO_WRAP_INSTANCE_API_RETURN(set3DConeOrientation(orientation), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API get3DConeOrientation(FMOD_VECTOR* orientation)
    { AUDIO_WRAP_INSTANCE_API_RETURN(get3DConeOrientation(orientation), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API set3DConeSettings(float insideconeangle, float outsideconeangle, float outsidevolume)
    { AUDIO_WRAP_INSTANCE_API_RETURN(set3DConeSettings(insideconeangle, outsideconeangle, outsidevolume), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API set3DDopplerLevel(float dopplerlevel)
    { AUDIO_WRAP_INSTANCE_API_RETURN(set3DDopplerLevel(dopplerlevel), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API set3DMinMaxDistance(float minDist, float maxDist)
    { AUDIO_WRAP_INSTANCE_API_RETURN(set3DMinMaxDistance(minDist, maxDist), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API set3DPanLevel(float panlevel)
    { AUDIO_WRAP_INSTANCE_API_RETURN(set3DPanLevel(panlevel), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API set3DSpread(float spread)
    { AUDIO_WRAP_INSTANCE_API_RETURN(set3DSpread(spread), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API setCallback(FMOD_CHANNEL_CALLBACK callback)
    { AUDIO_WRAP_INSTANCE_API_RETURN(setCallback(callback), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API setChannelGroup(FMOD::ChannelGroup* group)
    { AUDIO_WRAP_INSTANCE_API_RETURN(setChannelGroup(group), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API setDelay(FMOD_DELAYTYPE delaytype, unsigned int delayhi, unsigned int delaylo)
    { AUDIO_WRAP_INSTANCE_API_RETURN(setDelay(delaytype, delayhi, delaylo), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API setMute(bool mute)
    { AUDIO_WRAP_INSTANCE_API_RETURN(setMute(mute), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API setPan(float pan)
    { AUDIO_WRAP_INSTANCE_API_RETURN(setPan(pan), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API setPriority(int priority)
    { AUDIO_WRAP_INSTANCE_API_RETURN(setPriority(priority), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API setReverbProperties(FMOD_REVERB_CHANNELPROPERTIES* reverbproperties)
    { AUDIO_WRAP_INSTANCE_API_RETURN(setReverbProperties(reverbproperties), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API getReverbProperties(FMOD_REVERB_CHANNELPROPERTIES* reverbproperties)
    { AUDIO_WRAP_INSTANCE_API_RETURN(getReverbProperties(reverbproperties), FMOD_ERR_INVALID_HANDLE); }


    // Replacements functions for getPosition which doesn't fit into the buffering scheme because of the FMOD_TIMEUNIT selector
    FMOD_RESULT F_API GetPositionPCM(unsigned int* position_pcm)
    { AUDIO_WRAP_INSTANCE_API_RETURN(GetPositionPCM(position_pcm), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API GetPositionMS(unsigned int* position_ms)
    { AUDIO_WRAP_INSTANCE_API_RETURN(GetPositionMS(position_ms), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API SetPositionPCM(unsigned int position_pcm)
    { AUDIO_WRAP_INSTANCE_API_RETURN(SetPositionPCM(position_pcm), FMOD_ERR_INVALID_HANDLE); }

    FMOD_RESULT F_API SetPositionMS(unsigned int position_ms)
    { AUDIO_WRAP_INSTANCE_API_RETURN(SetPositionMS(position_ms), FMOD_ERR_INVALID_HANDLE); }


    // Replacements functions for setMode-based calls that are too complex to handle for our buffering method
    FMOD_RESULT F_API SetLoop(bool loop)
    { AUDIO_WRAP_INSTANCE_API_RETURN(SetLoop(loop), FMOD_ERR_INVALID_HANDLE); }

    void              Update()
    { AUDIO_WRAP_INSTANCE_API(Update()); }

#undef AUDIO_WRAP_INSTANCE_API_RETURN
#undef AUDIO_WRAP_INSTANCE_API
};

// Helper class to make it easy and safe to destroy a list of channels.
// The problem here is that the end callback of an FMOD::Channel will cause destruction of the SoundChannel, which then performs all other kinds of cleanup operations, so in
// order to delete a list of channels, it is practical to first take a snapshot of the channels to be deleted that is not in any way affected by the deletion callbacks.
// Note that we don't want to invoke the constructor or destructor of SoundChannel (as it is a variant of a weak pointer), so we just keep pointers to it.
class SoundChannelStopList
{
public:
    inline SoundChannelStopList(int size)
    {
        m_Count = 0;
        m_NumDuplicates = 0;
        m_Size = size;
        if (m_Size <= 0)
        {
            m_Channels = NULL;
            return;
        }
        m_Channels = ALLOC_TEMP_MANUAL(SoundChannel*, m_Size);
    }

    inline ~SoundChannelStopList()
    {
        AUDIO_MAINTHREAD_CHECK();
        Assert(m_Count == m_Size - m_NumDuplicates);
        for (int n = 0; n < m_Count; n++)
            (*m_Channels[n])->Stop();
        FREE_TEMP_MANUAL(m_Channels);
    }

public:
    inline void Add(SoundChannel& channel)
    {
        Assert(m_Count < m_Size);
        for (int n = 0; n < m_Count; n++)
        {
            if (m_Channels[n] == &channel)
            {
                m_NumDuplicates++;
                return;
            }
        }
        m_Channels[m_Count++] = &channel;
    }

protected:
    int m_Count;
    int m_NumDuplicates;
    int m_Size;
    SoundChannel** m_Channels;
};

#endif
