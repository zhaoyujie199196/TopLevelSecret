#pragma once

#include "Runtime/mecanim/generic/crc32.h"

class AudioSource;
class OneShot;
class SoundChannel;

class SoundUserDataGeneric
{
public:
    typedef UInt32 SoundUserDataType;

    SoundUserDataGeneric(void* owner, SoundUserDataType type) : m_type(type), m_owner(owner), m_UserDataFunction(NULL) {}

    template<typename T>
    inline T* TryGet() const
    {
        return (m_type != GetUserDataType<T>()) ? NULL : (T*)m_owner;
    }

    template<typename T>
    inline T* Get() const
    {
        T* p = TryGet<T>();
        Assert(p != NULL);
        return p;
    }

protected:
    SoundUserDataType m_type;
    void* m_owner;
    const char *m_UserDataFunction;

    template<typename T>
    static inline const char* GetUserDataString()
    {
#if UNITY_WIN || UNITY_WINRT || UNITY_XBOXONE
        return __FUNCSIG__;
#else
        return __PRETTY_FUNCTION__;
#endif
    }

    template<typename T>
    static inline SoundUserDataType GetUserDataType()
    {
        static SoundUserDataType functionHash = mecanim::processCRC32(GetUserDataString<T>());
        return functionHash;
    }
};

template<typename T>
class SoundUserData : public SoundUserDataGeneric
{
public:
    SoundUserData(T* owner) : SoundUserDataGeneric(owner, GetUserDataType<T>()) { m_UserDataFunction = SoundUserDataGeneric::GetUserDataString<T>(); }

    inline T* TryGet() const { return SoundUserDataGeneric::TryGet<T>(); }
    inline T* Get() const { return SoundUserDataGeneric::Get<T>(); }
};
