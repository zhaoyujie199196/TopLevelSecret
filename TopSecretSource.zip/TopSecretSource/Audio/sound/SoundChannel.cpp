#include "UnityPrefix.h"
#include "SoundChannel.h"
#include "Runtime/Audio/AudioSource.h"

#if ENABLE_PROFILER
int SoundChannelInstance::s_GlobalCount = 0;
int SoundChannel::s_GlobalCount = 0;
#endif

FMOD_RESULT F_CALLBACK SoundChannelInstance::FMODChannelCallback(FMOD_CHANNEL *channel, FMOD_CHANNEL_CALLBACKTYPE type, void *commanddata1, void *commanddata2)
{
    AUDIO_MAINTHREAD_CHECK();

    FMOD::Channel* fmodchannel = (FMOD::Channel*)channel;
    Assert(fmodchannel);

    SoundUserData<SoundChannelInstance>* userData = 0;
    CheckFMODError(fmodchannel->getUserData((void**)&userData));
    Assert(userData);

    SoundChannelInstance* instance = userData->TryGet();
    if (instance != NULL)
    {
        if (type == FMOD_CHANNEL_CALLBACKTYPE_END)
        {
#if UNITY_EDITOR
            GetAudioManager().ClearPreviewChannel(SoundChannel(instance));
#endif

            if (instance->m_AudioSource != NULL)
            {
                instance->m_AudioSource->UpdateEffectVirtualizationState(false);
            }

            CheckFMODError(fmodchannel->setUserData(NULL));

            // This makes sure that the last stream instance gets unloaded too. If we don't do this, the SampleClip's reference will keep the file handle
            // open until the SampleClip is destroyed. This can be a problem on platforms where the number of file handles is limited.
            if (instance->m_Sound.IsStreamingFromDisk())
                instance->m_Sound.UnbindFromSampleClip();

            // Cannot call UNITY_DELETE(SoundChannelInstance, kMemAudio) because of private destructor, so we do this instead:
            instance->~SoundChannelInstance();
            UNITY_FREE(kMemAudio, instance);
        }
        else if (type == FMOD_CHANNEL_CALLBACKTYPE_VIRTUALVOICE)
        {
            if (instance->m_AudioSource != NULL)
            {
                instance->m_AudioSource->UpdateEffectVirtualizationState(false);
            }
        }
    }

    return FMOD_OK;
}

SoundChannelInstance::SoundChannelInstance(SoundHandle sound, bool paused)
    : m_UserData(this)
    , m_FMODChannel(NULL)
    , m_Sound(sound)
    , m_ChannelsNode(this)
    , m_PendingNode(this)
    , m_UpdateNode(this)
    , m_AmbientVolume(1.0f)
    , m_BlendVolume(1.0f)
    , m_ChannelVolume(1.0f)
    , m_OneShotVolume(1.0f)
    , m_Pitch(1.0f)
    , m_DopplerPitch(1.0f)
    , m_BaseFrequency(1.0f)
    , m_ChannelPaused(paused)
    , m_GamePaused(false)
    , m_EditorPaused(false)
    , m_PendingStop(false)
    , m_AudioSource(NULL)
    , m_Flags(0)
    , m_WeakPtr(this, kMemAudio)
{
    AUDIO_MAINTHREAD_CHECK();

#if ENABLE_PROFILER
    AtomicIncrement(&s_GlobalCount);
#endif
    GetSoundManager()->GetAllChannelsNode().push_back(m_UpdateNode);
}

SoundChannelInstance::~SoundChannelInstance()
{
    AUDIO_MAINTHREAD_CHECK();

#if ENABLE_PROFILER
    AtomicDecrement(&s_GlobalCount);
#endif

    if (m_AudioSource != NULL)
    {
        m_AudioSource->UnbindFromChannelInstance(m_WeakPtr);
        m_AudioSource = NULL;
    }

    m_ChannelsNode.RemoveFromList();
    m_PendingNode.RemoveFromList();
    m_UpdateNode.RemoveFromList();

    m_WeakPtr.Clear(); // Break connection to instance in all SoundChannel handles accessing it
}

void SoundChannelInstance::SetFMODChannel(FMOD::Channel* fmodchannel)
{
    AUDIO_MAINTHREAD_CHECK();

    m_FMODChannel = fmodchannel;

    if (fmodchannel != NULL)
    {
        CheckFMODError(fmodchannel->setUserData(&m_UserData));
        CheckFMODError(fmodchannel->setCallback(FMODChannelCallback));
        CheckFMODError(fmodchannel->getFrequency(&m_BaseFrequency));
        ApplyBufferedParameters();
    }
}

#define ConditionalBreak()                       //static bool do_break = true; if(do_break) __asm { int 3 } // Conditional break (can be deactivated by setting do_break to false in debug window)

#define SetBit(v, index, bit)                      { v = (bit) ? ((v) | (1 << (index))) : ((v) & ~(1 << (index))); }
#define FromBuffer(name)                         { *name = m_ParameterBuffer.name; }
#define FromBufferIndexed(name, index)            { *name = m_ParameterBuffer.name[index]; }
#define FromBufferPtr(name)                      { if(name != NULL) memcpy(name, &m_ParameterBuffer.name, sizeof(*name)); }
#define ToBuffer(name)                           { m_ParameterBuffer.m_HasModifiedParams |= (m_FMODChannel == NULL); m_ParameterBuffer.name = name; m_ParameterBuffer.name##_dirty = (m_FMODChannel == NULL); ConditionalBreak(); }
#define ToBufferIndexed(name, index)              { m_ParameterBuffer.m_HasModifiedParams |= (m_FMODChannel == NULL); m_ParameterBuffer.name[index] = name; SetBit(m_ParameterBuffer.name##_dirty, index, m_FMODChannel == NULL); ConditionalBreak(); }
#define ToBufferPtr(name)                        { if(name != NULL) { m_ParameterBuffer.m_HasModifiedParams |= (m_FMODChannel == NULL); memcpy(&m_ParameterBuffer.name, name, sizeof(*name)); m_ParameterBuffer.name##_dirty = (m_FMODChannel == NULL); ConditionalBreak(); } }
#define ClearBuffered(name)                      { m_ParameterBuffer.name##_dirty = false; }

// setMode/getMode delegates are not provided, because they modify state and mimicking this logic gets way too complex for the parameter buffer

FMOD_RESULT F_API SoundChannelInstance::getCurrentSound(FMOD::Sound** sound)
{
    AUDIO_MAINTHREAD_CHECK();
    Assert(m_FMODChannel != NULL);
    return CheckFMODError(m_FMODChannel->getCurrentSound(sound));
}

FMOD_RESULT F_API SoundChannelInstance::getDelay(FMOD_DELAYTYPE delaytype, unsigned int* delayhi, unsigned int* delaylo)
{
    AUDIO_MAINTHREAD_CHECK();
    FromBufferIndexed(delayhi, delaytype);
    FromBufferIndexed(delaylo, delaytype);
    return FMOD_OK;
}

FMOD_RESULT F_API SoundChannelInstance::isPlaying(bool* playing)
{
    AUDIO_MAINTHREAD_CHECK();
    if (m_FMODChannel == NULL)
    {
        *playing = false;
        return FMOD_OK;
    }
    return CheckFMODError(m_FMODChannel->isPlaying(playing));
}

FMOD_RESULT F_API SoundChannelInstance::set3DAttributes(const FMOD_VECTOR* pos, const FMOD_VECTOR* vel)
{
    AUDIO_MAINTHREAD_CHECK();
    ToBufferPtr(pos);
    ToBufferPtr(vel);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    return CheckFMODError(m_FMODChannel->set3DAttributes(pos, vel));
}

FMOD_RESULT F_API SoundChannelInstance::set3DConeOrientation(FMOD_VECTOR* orientation)
{
    AUDIO_MAINTHREAD_CHECK();
    ToBufferPtr(orientation);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    return CheckFMODError(m_FMODChannel->set3DConeOrientation(orientation));
}

FMOD_RESULT F_API SoundChannelInstance::get3DConeOrientation(FMOD_VECTOR* orientation)
{
    AUDIO_MAINTHREAD_CHECK();
    FromBufferPtr(orientation);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    return CheckFMODError(m_FMODChannel->get3DConeOrientation(orientation));
}

FMOD_RESULT F_API SoundChannelInstance::set3DConeSettings(float insideconeangle, float outsideconeangle, float outsidevolume)
{
    AUDIO_MAINTHREAD_CHECK();
    ToBuffer(insideconeangle);
    ToBuffer(outsideconeangle);
    ToBuffer(outsidevolume);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    return CheckFMODError(m_FMODChannel->set3DConeSettings(insideconeangle, outsideconeangle, outsidevolume));
}

FMOD_RESULT F_API SoundChannelInstance::set3DDopplerLevel(float dopplerlevel)
{
    AUDIO_MAINTHREAD_CHECK();
    ToBuffer(dopplerlevel);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    return CheckFMODError(m_FMODChannel->set3DDopplerLevel(dopplerlevel));
}

FMOD_RESULT F_API SoundChannelInstance::set3DMinMaxDistance(float minDist, float maxDist)
{
    AUDIO_MAINTHREAD_CHECK();
    ToBuffer(minDist);
    ToBuffer(maxDist);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    minDist = std::max(0.0f, minDist);
    maxDist = std::max(minDist, maxDist);
    return CheckFMODError(m_FMODChannel->set3DMinMaxDistance(minDist, maxDist));
}

FMOD_RESULT F_API SoundChannelInstance::set3DPanLevel(float panlevel)
{
    AUDIO_MAINTHREAD_CHECK();
    ToBuffer(panlevel);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    panlevel = clamp(panlevel, 0.0f, 1.0f);
    return CheckFMODError(m_FMODChannel->set3DPanLevel(panlevel));
}

FMOD_RESULT F_API SoundChannelInstance::set3DSpread(float spread)
{
    AUDIO_MAINTHREAD_CHECK();
    ToBuffer(spread);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    spread = clamp(spread, 0.0f, 360.0f);
    return CheckFMODError(m_FMODChannel->set3DSpread(spread));
}

FMOD_RESULT F_API SoundChannelInstance::setCallback(FMOD_CHANNEL_CALLBACK callback)
{
    AUDIO_MAINTHREAD_CHECK();
    ToBuffer(callback);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    return CheckFMODError(m_FMODChannel->setCallback(callback));
}

FMOD_RESULT F_API SoundChannelInstance::setChannelGroup(FMOD::ChannelGroup* group)
{
    AUDIO_MAINTHREAD_CHECK();
    ToBuffer(group);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    return CheckFMODError(m_FMODChannel->setChannelGroup(group));
}

FMOD_RESULT F_API SoundChannelInstance::setDelay(FMOD_DELAYTYPE delaytype, unsigned int delayhi, unsigned int delaylo)
{
    AUDIO_MAINTHREAD_CHECK();
    ToBufferIndexed(delayhi, delaytype);
    ToBufferIndexed(delaylo, delaytype);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    return CheckFMODError(m_FMODChannel->setDelay(delaytype, delayhi, delaylo));
}

FMOD_RESULT F_API SoundChannelInstance::setMute(bool mute)
{
    AUDIO_MAINTHREAD_CHECK();
    ToBuffer(mute);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    return CheckFMODError(m_FMODChannel->setMute(mute));
}

FMOD_RESULT F_API SoundChannelInstance::setPan(float pan)
{
    AUDIO_MAINTHREAD_CHECK();
    ToBuffer(pan);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    return CheckFMODError(m_FMODChannel->setPan(pan));
}

FMOD_RESULT F_API SoundChannelInstance::setPriority(int priority)
{
    AUDIO_MAINTHREAD_CHECK();
    ToBuffer(priority);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    return CheckFMODError(m_FMODChannel->setPriority(priority));
}

FMOD_RESULT F_API SoundChannelInstance::setReverbProperties(FMOD_REVERB_CHANNELPROPERTIES* reverbproperties)
{
    AUDIO_MAINTHREAD_CHECK();
    ToBufferPtr(reverbproperties);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    return CheckFMODError(m_FMODChannel->setReverbProperties(reverbproperties));
}

FMOD_RESULT F_API SoundChannelInstance::getReverbProperties(FMOD_REVERB_CHANNELPROPERTIES* reverbproperties)
{
    AUDIO_MAINTHREAD_CHECK();
    FromBufferPtr(reverbproperties);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    return CheckFMODError(m_FMODChannel->getReverbProperties(reverbproperties));
}

FMOD_RESULT F_API SoundChannelInstance::isVirtual(bool* isVirtual)
{
    AUDIO_MAINTHREAD_CHECK();
    if (m_FMODChannel == NULL)
    {
        *isVirtual = true;
        return FMOD_OK;
    }
    return CheckFMODError(m_FMODChannel->isVirtual(isVirtual));
}

// Replacements functions for getPosition which doesn't fit into the buffering scheme because of the FMOD_TIMEUNIT selector
FMOD_RESULT F_API SoundChannelInstance::GetPositionPCM(unsigned int* position_pcm)
{
    AUDIO_MAINTHREAD_CHECK();
    if (m_FMODChannel == NULL)
    {
        FromBuffer(position_pcm);
        return FMOD_OK;
    }
    return CheckFMODError(m_FMODChannel->getPosition(position_pcm, FMOD_TIMEUNIT_PCM));
}

// position changes as the channel plays, so don't return buffered value when a channel is available
FMOD_RESULT F_API SoundChannelInstance::GetPositionMS(unsigned int* position_ms)
{
    AUDIO_MAINTHREAD_CHECK();
    if (m_FMODChannel == NULL)
    {
        FromBuffer(position_ms);
        return FMOD_OK;
    }
    return CheckFMODError(m_FMODChannel->getPosition(position_ms, FMOD_TIMEUNIT_MS));
}

// position changes as the channel plays, so don't return buffered value when a channel is available
FMOD_RESULT F_API SoundChannelInstance::SetPositionPCM(unsigned int position_pcm)
{
    AUDIO_MAINTHREAD_CHECK();
    ClearBuffered(position_ms);
    ToBuffer(position_pcm);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    FMOD_RESULT result = m_FMODChannel->setPosition(position_pcm, FMOD_TIMEUNIT_PCM);
    if (result != FMOD_OK)
    {
        if (result == FMOD_ERR_NOTREADY)
        {
            m_ParameterBuffer.m_HasModifiedParams = true;
            m_ParameterBuffer.position_pcm_dirty = true;
        }
        else
            CheckFMODError(result);
    }
    return FMOD_OK;
}

FMOD_RESULT F_API SoundChannelInstance::SetPositionMS(unsigned int position_ms)
{
    AUDIO_MAINTHREAD_CHECK();
    ClearBuffered(position_pcm);
    ToBuffer(position_ms);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    FMOD_RESULT result = m_FMODChannel->setPosition(position_ms, FMOD_TIMEUNIT_MS);
    if (result != FMOD_OK)
    {
        if (result == FMOD_ERR_NOTREADY)
        {
            m_ParameterBuffer.m_HasModifiedParams = true;
            m_ParameterBuffer.position_ms_dirty = true;
        }
        else
            CheckFMODError(result);
    }
    return FMOD_OK;
}

// Replacements functions for setMode-based calls that are too complex to handle for our buffering method
FMOD_RESULT F_API SoundChannelInstance::SetLoop(bool loop)
{
    AUDIO_MAINTHREAD_CHECK();
    ToBuffer(loop);
    if (m_FMODChannel == NULL)
        return FMOD_OK;
    return CheckFMODError(m_FMODChannel->setMode(loop ? FMOD_LOOP_NORMAL : FMOD_LOOP_OFF));
}

#undef ConditionalBreak
#undef FromBuffer
#undef ToBuffer
#undef FromBufferIndexed
#undef ToBufferIndexed
#undef ClearBuffered
#undef FromBufferPtr
#undef ToBufferPtr

void SoundChannelInstance::ApplyBufferedParameters()
{
    AUDIO_MAINTHREAD_CHECK();
    if (m_FMODChannel != NULL)
    {
        m_ParameterBuffer.Apply(m_FMODChannel);
        UpdateVolume();
        UpdatePitch();
        UpdatePauseState();
        if (m_AudioSource != NULL)
            m_AudioSource->UpdateEffectVirtualizationState(false);
    }
}

void SoundChannelInstance::Stop()
{
    AUDIO_MAINTHREAD_CHECK();

    // Sound hasn't started playing yet.
    // This happens if a Stop() call happens very quickly after a Play() and the sound is set to load in the background.
    if (m_PendingNode.IsInList())
    {
        if (m_AudioSource != NULL)
        {
            m_AudioSource->UnbindFromChannelInstance(m_WeakPtr);
            m_AudioSource = NULL;
        }

        m_PendingStop = true;
    }

    if (m_FMODChannel == NULL)
        return;

    CheckFMODError(m_FMODChannel->stop());

    // DO NOT CALL ANYTHING HERE. THIS INSTANCE HAS BEEN DESTROYED.
}

void SoundChannelInstance::UpdateVolume()
{
    AUDIO_MAINTHREAD_CHECK();

    if (m_FMODChannel == NULL)
        return;

    float mixVolume = m_ChannelVolume * m_AmbientVolume * m_BlendVolume;
    if (m_Flags & ONESHOT)
        mixVolume *= m_OneShotVolume;
    CheckFMODError(m_FMODChannel->setVolume(mixVolume));
}

void SoundChannelInstance::UpdatePitch()
{
    AUDIO_MAINTHREAD_CHECK();

    if (m_FMODChannel == NULL)
        return;

    CheckFMODError(m_FMODChannel->setFrequency(m_Pitch * m_DopplerPitch * m_BaseFrequency));
}

void SoundChannelInstance::UpdatePauseState()
{
    AUDIO_MAINTHREAD_CHECK();

    if (m_FMODChannel == NULL)
        return;

    bool paused = m_ChannelPaused || m_GamePaused;
    CheckFMODError(m_FMODChannel->setPaused(paused));
}

SoundChannelInstance::ParameterBuffer::ParameterBuffer()
{
    // Initialize to FMOD defaults
    memset(this, 0, sizeof(*this));
}

void SoundChannelInstance::ParameterBuffer::Apply(FMOD::Channel* channel)
{
    AUDIO_MAINTHREAD_CHECK();
    if (!m_HasModifiedParams)
        return;
    m_HasModifiedParams = false;
    #define ApplyBuffered1(func, name)                     { if(name##_dirty)         { CheckFMODError(channel->func(name)); name##_dirty = false; } }
    #define ApplyBuffered2(func, name1, name2)              { if(name1##_dirty)        { CheckFMODError(channel->func(name1, name2)); name1##_dirty = false; name2##_dirty = false; } }
    #define ApplyBuffered3(func, name1, name2, name3)        { if(name1##_dirty)        { CheckFMODError(channel->func(name1, name2, name3)); name1##_dirty = false; name2##_dirty = false; name3##_dirty = false; } }
    #define ApplyBufferedPtr1(func, name)                  { if(name##_dirty)         { CheckFMODError(channel->func(&name)); name##_dirty = false; } }
    #define ApplyBufferedPtr2(func, name1, name2)           { if(name1##_dirty)        { CheckFMODError(channel->func(&name1, &name2)); name1##_dirty = false; name2##_dirty = false; } }
    #define ApplyBufferedIndexed1(func, index, name)        { if(name##_dirty[index])  { CheckFMODError(channel->func(index, name[index])); name##_dirty[index] = false; } }
    #define ApplyBufferedIndexed2(func, index, name1, name2) { if(name1##_dirty & (1 << (index))) { CheckFMODError(channel->func(index, name1[index], name2[index])); name1##_dirty &= ~(1 << (index)); name2##_dirty &= ~(1 << (index)); } }
    ApplyBuffered1(setMute, mute);
    ApplyBuffered1(setCallback, callback);
    if (loop_dirty)
    {
        channel->setMode(loop ? FMOD_LOOP_NORMAL : FMOD_LOOP_OFF); loop_dirty = false;
    }
    if (position_pcm_dirty)
    {
        CheckFMODError(channel->setPosition(position_pcm, FMOD_TIMEUNIT_PCM)); position_pcm_dirty = false;
    }
    if (position_ms_dirty)
    {
        CheckFMODError(channel->setPosition(position_ms, FMOD_TIMEUNIT_MS)); position_ms_dirty = false;
    }
    ApplyBuffered1(setChannelGroup, group);
    ApplyBuffered1(setPriority, priority);
    ApplyBufferedPtr1(setReverbProperties, reverbproperties);
    ApplyBufferedIndexed2(setDelay, FMOD_DELAYTYPE_DSPCLOCK_START, delayhi, delaylo);
    ApplyBufferedIndexed2(setDelay, FMOD_DELAYTYPE_DSPCLOCK_END, delayhi, delaylo);
    ApplyBufferedIndexed2(setDelay, FMOD_DELAYTYPE_DSPCLOCK_PAUSE, delayhi, delaylo);
    ApplyBuffered1(setPan, pan);

    ApplyBufferedPtr2(set3DAttributes, pos, vel);
    ApplyBufferedPtr1(set3DConeOrientation, orientation);
    ApplyBuffered3(set3DConeSettings, insideconeangle, outsideconeangle, outsidevolume);
    ApplyBuffered1(set3DDopplerLevel, dopplerlevel);
    ApplyBuffered2(set3DMinMaxDistance, minDist, maxDist);
    ApplyBuffered1(set3DPanLevel, panlevel);
    ApplyBuffered1(set3DSpread, spread);

    #undef ApplyBuffered1
    #undef ApplyBufferedPtr1
    #undef ApplyBufferedPtr2
    #undef ApplyBufferedIndexed1
    #undef ApplyBufferedIndexed2
}

void SoundChannelInstance::Update()
{
    AUDIO_MAINTHREAD_CHECK();

    if (m_FMODChannel != NULL)
    {
        if (m_ParameterBuffer.position_pcm_dirty)
        {
            FMOD_RESULT result = m_FMODChannel->setPosition(m_ParameterBuffer.position_pcm, FMOD_TIMEUNIT_PCM);
            if (result == FMOD_OK)
                m_ParameterBuffer.position_pcm_dirty = false;
        }

        if (m_ParameterBuffer.position_ms_dirty)
        {
            FMOD_RESULT result = m_FMODChannel->setPosition(m_ParameterBuffer.position_ms, FMOD_TIMEUNIT_MS);
            if (result == FMOD_OK)
                m_ParameterBuffer.position_ms_dirty = false;
        }
    }
}
