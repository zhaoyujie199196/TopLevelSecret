#pragma once

#include "Configuration/UnityConfigure.h"
#include "Runtime/BaseClasses/GameManager.h"
#include "Runtime/Utilities/LinkedList.h"
#include "Runtime/Utilities/WeakPtr.h"
#include "Runtime/Threads/AtomicOps.h"
#include "Runtime/Profiler/ProfilerStats.h"
#include "Runtime/Audio/correct_fmod_includer.h"
#include "Runtime/Audio/AudioProfiler.h"

#if 0

extern double GetTimeSinceStartup();

class SoundManagerWatchDog
{
public:
    SoundManagerWatchDog()
    {
        m_StartTime = GetTimeSinceStartup();
    }

public:
    void Update(const char* filename, int line)
    {
        double delta = GetTimeSinceStartup() - m_StartTime;
        if (delta > 15.0)    // make this value waaaay lower
        {
            printf_console("Stuck in loop at %s line %d", filename, line);
            ErrorStringMsg("Stuck in loop at %s line %d", filename, line);
            exit(1);
        }
    }

protected:
    double m_StartTime;
};

    #define SOUNDMANAGERWATCHDOG() \
        SoundManagerWatchDog watchdog

    #define SOUNDMANAGERWATCHDOG_UPDATE() \
        watchdog.Update(__FILE__, __LINE__)
#else

    #define SOUNDMANAGERWATCHDOG() do {} while(false)
    #define SOUNDMANAGERWATCHDOG_UPDATE() do {} while(false)

#endif

extern void __audio_mainthread_check_internal(const char* funcname);

#if UNITY_WIN || UNITY_WINRT || UNITY_XBOXONE
#   define AUDIO_MAINTHREAD_CHECK() __audio_mainthread_check_internal(__FUNCSIG__)
#else
#   define AUDIO_MAINTHREAD_CHECK() __audio_mainthread_check_internal(__PRETTY_FUNCTION__)
#endif

struct AudioStats;

class SampleClip;
class AudioClip;
class SoundChannel;

class SoundChannelInstance;

struct StreamedResource;

class SoundHandleShared
{
public:
    enum LoadState
    {
        kUnloaded,
        kLoadingBase,
        kLoadingSub,
        kLoaded,
        kFailed,
    };

    enum Flags
    {
        kAllowSharing       = 1 << 0, // Set if sound is shareable (i.e. not applicable to sounds that are modified via SetData)
        kInstanceLimitation = 1 << 1, // Handle FMOD limitation that requires
    };
};

class SoundHandleAPI : public SoundHandleShared
{
public:
    LoadState GetLoadState() const;
    int GetMusicChannelCount() const;
    bool SetData(const float* data, unsigned lengthSamples, unsigned offsetSamples);
    bool GetData(float* data, unsigned lengthSamples, unsigned offsetSamples) const;
    unsigned int GetLengthPCM() const;
    float GetLengthMS() const;
    int GetNumChannels() const;
    int GetBitsPerSample() const;
    float GetFrequency() const;
    unsigned int GetMemoryInfo(bool recurse) const;
};

class SoundHandle : public SoundHandleShared
{
public:
    class Instance;
    friend class SoundHandle::Instance;
    friend class SoundManager;

private:
    explicit SoundHandle(Instance* instance);

public:
    SoundHandle();
    SoundHandle(const SoundHandle& handle);
    ~SoundHandle();

public:
    void Dispose(); // Called by DynamicUnload. Stops playing channels and disposes sound instance immediately. The actual FMOD::Sound unload may happen later if sound is still loading in order to avoid blocking.
    void Release(); // Disposes sound instance when refcount == 0
    SoundChannel CreateChannel(bool paused);
    void UnbindFromSampleClip();
    bool IsStreamingFromDisk() const;

    inline bool IsNull() const
    {
        return m_WeakPtr == NULL;
    }

    inline SoundHandleAPI* operator->() const
    {
        AUDIO_MAINTHREAD_CHECK();
        SoundHandle::Instance* instance = m_WeakPtr;
        return (SoundHandleAPI*)instance;
    }

    inline bool operator==(const SoundHandle& handle) const
    {
        return m_WeakPtr == handle.m_WeakPtr;
    }

    void operator=(const SoundHandle& handle);

#if ENABLE_PROFILER
    static int s_GlobalCount;
#endif

protected:
    WeakPtr<Instance> m_WeakPtr;

    friend class SoundChannelInstance;
};

class SoundManager
{
public:
    SoundManager();
    ~SoundManager();

public:
    SoundHandle GetHandle(const StreamedResource& resource, int subsound, FMOD_MODE mode, UInt32 flags, SampleClip* ownerClip, bool forceInstantiate);
    SoundHandle GetHandleFromFMODSound(SoundHandle::Instance* instance, UInt32 flags, SampleClip* ownerClip);

    FMOD_RESULT F_API CreateSoundInternal(const char *name_or_data, FMOD_MODE mode, FMOD_CREATESOUNDEXINFO *exinfo, SoundHandle& handle,
        UInt32 flags, SampleClip* ownerClip);

    SoundHandle IntegrateFMODSound(SoundHandle::Instance* instance, const StreamedResource& resource,
        UInt32 flags, int subsound, SoundHandle::LoadState state);

    void UpdateChannels();
    void Update();

    void RegisterModifiedClip(SampleClip* clip);
    void UnloadClip(SampleClip* clip);

    static void OnExitPlayModeStatic();
    void OnExitPlayMode();

    void GetProfilerData(AudioStats& audioStats);

    List<ListNode<SoundChannelInstance> >& GetAllChannelsNode() { return m_AllChannels; }
    void FlushDisposedSounds();

    static FMOD_RESULT OnCreateSoundPushAllocation(void* userdata);
    static FMOD_RESULT OnCreateSoundPopAllocation();

    void CaptureProfilerInfo(dynamic_array<AudioProfilerClipInfo>& info, dynamic_array<char>& names);

private:
    // Called by SoundHandle::Instance only
    void DisposeSound(SoundHandle::Instance* instance); // When ref-count reaches zero
    bool AwaitLoading(SoundHandle::Instance* instance);
    void SetLoopPointsForClip(SampleClip* clip, FMOD::Sound* sound);

public:
    List<ListNode<SoundChannelInstance> > m_AllChannels;
    typedef List<ListNode<SoundHandle::Instance> > SoundList;
    SoundList m_PendingSounds;
    SoundList m_LoadedSounds;
    SoundList m_DisposedSounds;
    int m_NumPendingSoundInstances;
    int m_NumLoadedSoundInstances;
    int m_NumDisposedSoundInstances;
    int m_NumPendingUnloads;
    List<ListNode<SampleClip> > m_ModifiedClips;

    friend class SoundHandle::Instance;
};

FMOD_RESULT LoadFMODSound(SoundHandle::Instance** instance, const char* path, FMOD_MODE mode, SampleClip* ownerClip,
    unsigned int size = 0, unsigned int offset = 0, FMOD_CREATESOUNDEXINFO* exinfoIn = NULL);

FMOD_RESULT StartFMODRecord(FMOD::System* system, int deviceID, SoundHandle::Instance* instance, bool loop);

void DestroySoundHandleInstance(SoundHandle::Instance* instance);

SampleClip* GetParentSampleClipFromInstance(SoundHandle::Instance* instance);

SoundManager* GetSoundManager();
