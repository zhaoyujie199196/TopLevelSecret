#ifdef UNITY
#include "UnityPrefix.h"
#endif

#include "Runtime/Debug/Stacktrace.cpp"

#include "AudioFeatureDefines.h"

#if AUDIO_ENABLE_DEBUGGING

    #define AUDIODEBUG_LOG_PLAIN -1000

    #ifdef UNITY
        #include "Runtime/Threads/Thread.h"
    #endif

static int AudioDebug_TabCount = 0;
static AudioDebugTypeData* s_AudioDebugTypeDataList = NULL;

bool AudioDebugTypeData::InstanceCountChanged = false;

    #if AUDIO_DEBUG_ENABLE_COUNTERS == 1
int AudioCounters_NumChannels = 0;
int AudioCounters_NumLoopPlays = 0;
int AudioCounters_NumStopCallbacks = 0;
    #endif

const int AUDIO_DEBUG_PADDING = 100;

char aAudioDebugPrintBuf[8192];
char aAudioDebugPrintBuf2[8192];

class AudioDebugFileHandle
{
public:
    AudioDebugFileHandle()
    {
    #if UNITY_WIN
        char path[2048];
        GetModuleFileNameA(GetModuleHandle(NULL), path, sizeof(path));
        strcpy(strrchr(path, '\\') + 1, "unity_audiodebug.txt");
        m_pHandle = fopen(path, "w");
    #elif UNITY_OSX
        m_pHandle = fopen("~/unity_audiodebug.txt", "w");
    #else
        m_pHandle = NULL;
    #endif
    }

    ~AudioDebugFileHandle()
    {
        if (m_pHandle != NULL)
        {
            AUDIO_DUMPINSTANCEDATA("At debug system shutdown:", false);
            fclose(m_pHandle);
        }
    }

public:
    FILE* m_pHandle;
};

inline FILE* AudioDebug_GetLogFile()
{
    static AudioDebugFileHandle pHandle;
    return pHandle.m_pHandle;
}

AudioDebugTypeData::AudioDebugTypeData(const char* pInitMarker, const char* pClearMarker, const char* pName)
    : INITMARKER1(*(UInt32*)pInitMarker)
    , INITMARKER2(*(UInt32*)(pInitMarker + 4))
    , CLEARMARKER1(*(UInt32*)pClearMarker)
    , CLEARMARKER2(*(UInt32*)(pClearMarker + 4))
    , INSTANCECOUNTER(0)
    , INSTANCECOUNTERFRAMEPEAK(0)
    , INSTANCECOUNTERTOTALPEAK(0)
    , m_pName(pName)
{
    m_pNext = s_AudioDebugTypeDataList;
    s_AudioDebugTypeDataList = this;
}

void AudioDebug_Indent(signed int tabdelta)
{
    AudioDebug_TabCount += tabdelta;
}

void AudioDebug_Log(const void* thisptr, const char* filename, int line, int tabdelta, const char* pFmtStr = NULL, ...)
{
    va_list args;
    va_start(args, pFmtStr);
    if (tabdelta < 0 && tabdelta != AUDIODEBUG_LOG_PLAIN)
        AudioDebug_TabCount += tabdelta;
    FILE* f = AudioDebug_GetLogFile();
    if (f != NULL)
    {
        if (tabdelta == AUDIODEBUG_LOG_PLAIN)
            aAudioDebugPrintBuf2[0] = 0;
        else
            sprintf_s(aAudioDebugPrintBuf2, sizeof(aAudioDebugPrintBuf2) - 1, "%s(%d): ", filename, line);
        int nLen = strlen(aAudioDebugPrintBuf2);
        int nSpace = AUDIO_DEBUG_PADDING + AudioDebug_TabCount;
        while (nLen < nSpace)
            aAudioDebugPrintBuf2[nLen++] = ' ';
        aAudioDebugPrintBuf2[nLen] = 0;
        if (tabdelta != 0 && tabdelta != AUDIODEBUG_LOG_PLAIN)
            sprintf_s(&aAudioDebugPrintBuf2[nLen], sizeof(aAudioDebugPrintBuf2) - 1 - nLen, "%s%s", (tabdelta == 0) ? "" : (tabdelta > 0) ? "> " : "< ", pFmtStr);
        else
            vsprintf_s(&aAudioDebugPrintBuf2[nLen], sizeof(aAudioDebugPrintBuf2) - 1 - nLen, pFmtStr, args);
        while (aAudioDebugPrintBuf2[nLen] != 0)
            nLen++;
        if (tabdelta != AUDIODEBUG_LOG_PLAIN)
        {
            AudioDebugThreadID threadid = AudioDebugGetThreadID;
            if (thisptr != (void*)-1)
                sprintf_s(&aAudioDebugPrintBuf2[nLen], sizeof(aAudioDebugPrintBuf2) - 1 - nLen, " [this = %p, threadid = %p%s]", thisptr, (void*)threadid, (threadid == AudioDebugMainThreadID) ? " (main thread)" : "");
            else
                sprintf_s(&aAudioDebugPrintBuf2[nLen], sizeof(aAudioDebugPrintBuf2) - 1 - nLen, " [static function, threadid = %p%s]", (void*)threadid, (threadid == AudioDebugMainThreadID) ? " (main thread)" : "");
            while (aAudioDebugPrintBuf2[nLen] != 0)
                nLen++;
        }
        aAudioDebugPrintBuf2[nLen] = '\n';
        aAudioDebugPrintBuf2[nLen + 1] = 0;
        //printf_console(aAudioDebugPrintBuf2);
        FILE* f = AudioDebug_GetLogFile();
        fprintf(f, aAudioDebugPrintBuf2);
        fflush(f);
    }
    if (tabdelta > 0 && tabdelta != AUDIODEBUG_LOG_PLAIN)
        AudioDebug_TabCount += tabdelta;
    va_end(args);
}

void AudioDebugDumpInstanceDataIfChanged(const char* title, bool clearcounters)
{
    if (!AudioDebugTypeData::InstanceCountChanged)
        return;
    AudioDebugTypeData::InstanceCountChanged = false;
    AudioDebugDumpInstanceData(title, clearcounters);
}

void AudioDebugDumpInstanceData(const char* title, bool clearcounters)
{
    FILE* f = AudioDebug_GetLogFile();
    if (f != NULL)
    {
        AudioDebug_Log(NULL, __FILE__, __LINE__, AUDIODEBUG_LOG_PLAIN, "[INFO] --------------------------------------------------------------------------------");
        AudioDebug_Log(NULL, __FILE__, __LINE__, AUDIODEBUG_LOG_PLAIN, "[INFO] %s", title);
        AudioDebug_Log(NULL, __FILE__, __LINE__, AUDIODEBUG_LOG_PLAIN, "[INFO] --------------------------------------------------------------------------------");
        AudioDebugTypeData* p = s_AudioDebugTypeDataList;
        while (p != NULL)
        {
            AudioDebug_Log(NULL, __FILE__, __LINE__, AUDIODEBUG_LOG_PLAIN, "[INFO] %s.Count     = %d", p->m_pName, p->INSTANCECOUNTER);
            AudioDebug_Log(NULL, __FILE__, __LINE__, AUDIODEBUG_LOG_PLAIN, "[INFO] %s.PeakCount = %d", p->m_pName, p->INSTANCECOUNTERTOTALPEAK);
            AudioDebug_Log(NULL, __FILE__, __LINE__, AUDIODEBUG_LOG_PLAIN, "[INFO] %s.FramePeak = %d", p->m_pName, p->INSTANCECOUNTERFRAMEPEAK);
            if (clearcounters)
            {
                if (p->INSTANCECOUNTERTOTALPEAK > p->INSTANCECOUNTER)
                    p->INSTANCECOUNTERTOTALPEAK = p->INSTANCECOUNTER;
                if (p->INSTANCECOUNTERFRAMEPEAK > p->INSTANCECOUNTER)
                    p->INSTANCECOUNTERFRAMEPEAK = p->INSTANCECOUNTER;
            }
            p = p->m_pNext;
        }
    }
    #if AUDIO_DEBUG_ENABLE_COUNTERS == 1
    AudioDebug_Log(NULL, __FILE__, __LINE__, AUDIODEBUG_LOG_PLAIN, "[INFO] Num channel objects at shutdown: %d", AudioCounters_NumChannels);
    AudioDebug_Log(NULL, __FILE__, __LINE__, AUDIODEBUG_LOG_PLAIN, "[INFO] Num loop plays counted:          %d", AudioCounters_NumLoopPlays);
    AudioDebug_Log(NULL, __FILE__, __LINE__, AUDIODEBUG_LOG_PLAIN, "[INFO] Num stop callbacks executed:     %d", AudioCounters_NumStopCallbacks);
    #endif
}

void AudioDebug_Error(const void* thisptr, const char* msg, const char* filename, int line, const char* expr, bool bFatal)
{
    AudioDebugThreadID threadid = AudioDebugGetThreadID;
    AudioDebug_Log(thisptr, filename, line, 0, "%s %s [threadid = %p%s]", msg, expr, (void*)threadid, (threadid == AudioDebugMainThreadID) ? " (main thread)" : "");
    if (bFatal)
    {
    #if UNITY_WIN
        DebugBreak();
        //__asm int 3
    #elif UNITY_OSX
        Debugger();
    #endif
        AssertMsg(false, aAudioDebugPrintBuf2);
    }
}

bool AudioDebug_AssertOnMainThread(const void* thisptr, const char* msg, const char* filename, int line, const char* expr, bool bFatal)
{
    bool bRunningOnMainThread = AudioDebugEqualsCurrentThreadID(AudioDebugMainThreadID);
    if (!bRunningOnMainThread)
        AudioDebug_Error(thisptr, msg, filename, line, expr, bFatal);
    Assert(!bFatal || bRunningOnMainThread);
    return bRunningOnMainThread;
}

FMOD_RESULT AudioDebug_CheckFMODResult(const void* thisptr, bool bBreak, const char* filename, int line, const char* expr, bool bPreCheck, FMOD_RESULT result, bool bPostCheck)
{
    AudioDebugThreadID threadid = AudioDebugGetThreadID;
    if (0 && AudioDebug_GetLogFile())
    {
        // Enable for extensive logging
        AudioDebug_Log(thisptr, filename, line, 0, "Executing %s (result = %d) [threadid = %p%s]", expr, result, (void*)threadid, (threadid == AudioDebugMainThreadID) ? " (main thread)" : "");
    }
    if (result != FMOD_OK)
    {
        AudioDebug_Log(thisptr, filename, line, 0, "Failed %s with error code %d (%s) when calling %s [threadid = %p%s]", (bBreak) ? "check" : "test", result, AudioDebugFMODErrorString(result), expr, (void*)threadid, (threadid == AudioDebugMainThreadID) ? " (main thread)" : "");
        if (bBreak)
        {
            core::string s = GetStacktrace();
            AudioDebug_Log(thisptr, filename, line, 0, "Callstack:");
            AudioDebug_Log(thisptr, filename, line, 0, "%s", s.c_str());
            AUDIO_DUMPINSTANCEDATA("Counters at debug breakpoint:", false);
    #if UNITY_WIN
            __debugbreak();
            //__asm int 3
    #elif UNITY_OSX
            Debugger();
    #endif
            AssertMsg(false, aAudioDebugPrintBuf2);
        }
    }
    return result;
}

static inline char AudioDebug_MakePrintableChar(char c)
{
    if (c >= ' ')
        return c;
    return '.';
}

void AudioDebug_ValidateMarkersError(const void* thisptr, unsigned long m1, unsigned long m2, unsigned long i1, unsigned long i2, unsigned long c1, unsigned long c2, const char* filename, int line, const char* expr)
{
    sprintf_s(aAudioDebugPrintBuf, sizeof(aAudioDebugPrintBuf2) - 1, "Audio marker validation failed (looking for %c%c%c%c%c%c%c%c, found %c%c%c%c%c%c%c%c)%s",
        AudioDebug_MakePrintableChar((i1 >> 24) & 0xFF),
        AudioDebug_MakePrintableChar((i1 >> 16) & 0xFF),
        AudioDebug_MakePrintableChar((i1 >>  8) & 0xFF),
        AudioDebug_MakePrintableChar((i1 >>  0) & 0xFF),
        AudioDebug_MakePrintableChar((i2 >> 24) & 0xFF),
        AudioDebug_MakePrintableChar((i2 >> 16) & 0xFF),
        AudioDebug_MakePrintableChar((i2 >>  8) & 0xFF),
        AudioDebug_MakePrintableChar((i2 >>  0) & 0xFF),
        AudioDebug_MakePrintableChar((m1 >> 24) & 0xFF),
        AudioDebug_MakePrintableChar((m1 >> 16) & 0xFF),
        AudioDebug_MakePrintableChar((m1 >>  8) & 0xFF),
        AudioDebug_MakePrintableChar((m1 >>  0) & 0xFF),
        AudioDebug_MakePrintableChar((m2 >> 24) & 0xFF),
        AudioDebug_MakePrintableChar((m2 >> 16) & 0xFF),
        AudioDebug_MakePrintableChar((m2 >>  8) & 0xFF),
        AudioDebug_MakePrintableChar((m2 >>  0) & 0xFF),
        (m1 == c1 && m2 == c2) ? " [object appears to been have freed]: " : ": ");
    AudioDebug_Error(thisptr, aAudioDebugPrintBuf, filename, line, expr, true);
}

#endif
