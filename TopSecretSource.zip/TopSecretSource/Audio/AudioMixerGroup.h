#pragma once

#include "Runtime/BaseClasses/NamedObject.h"
#include "Runtime/Utilities/GUID.h"
#include "AudioMixer.h"

class AudioMixerGroup : public NamedObject
{
    REGISTER_CLASS(AudioMixerGroup);
    DECLARE_OBJECT_SERIALIZE();
public:
    typedef dynamic_array<PPtr<AudioMixerGroup> > Children;


    AudioMixerGroup(MemLabelId label, ObjectCreationMode mode);
    // virtual ~AudioMixerGroup (); - declared-by-macro

    virtual void AwakeFromLoad(AwakeFromLoadMode awakeMode);

    PPtr<AudioMixer> GetAudioMixer() const { return m_AudioMixer; }
    const UnityGUID& GetGroupID() const { return m_GroupID; }
    const Children& GetChildren() const { return m_Children; }

    void GetGroupInGUIDListRecursive(const std::vector<UnityGUID>& guids, AudioMixer::GroupList& groups);

protected:
    Children         m_Children;
    PPtr<AudioMixer> m_AudioMixer;

private:
    UnityGUID        m_GroupID;
};
