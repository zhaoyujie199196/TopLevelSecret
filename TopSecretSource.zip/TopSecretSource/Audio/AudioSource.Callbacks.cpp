/*
 *  AudioSource.Callbacks.cpp
 *  Xcode
 *
 *  Created by Søren Christiansen on 10/12/09.
 *  Copyright 2009 Unity Technologies. All rights reserved.
 *
 */
#include "UnityPrefix.h"
#include "Configuration/UnityConfigure.h"
#if ENABLE_AUDIO
#include "AudioSource.h"
#include "AudioManager.h"
#include "Runtime/Utilities/Utility.h"
#include "Runtime/Audio/sound/SoundChannel.h"
#include "Runtime/Audio/AudioPluginInterface.h"
#include "Runtime/Audio/AudioEffectInternal.h"

/**
 * Do log, linear and custom rolloff calculation to avoid interpolating the (animation)curve
 **/
float AudioSource::EvaluateAttenuationCurve(float distance) const
{
    float maxDistance, minDistance, rolloffScale;
    RolloffMode rolloffMode;

    rolloffScale = GetAudioManager().GetRolloffScale();

    maxDistance = GetMaxDistance();
    minDistance = GetMinDistance();
    rolloffMode = GetRolloffMode();

    float gain = 1.0f;

    switch (rolloffMode)
    {
        case kRolloffLinear:
        {
            float range = maxDistance - minDistance;
            if (range <= 0)
                gain = 1.0f;
            else
            {
                distance = maxDistance - distance;
                gain = distance / range;
            }
        }
        break;
        case kRolloffLogarithmic:
        {
            if ((distance > minDistance) && (rolloffScale != 1.0f))
            {
                distance -= minDistance;
                distance *= rolloffScale;
                distance += minDistance;
            }

            if (distance < .000001f)
            {
                distance = .000001f;
            }
            gain = minDistance / distance;
        }
        break;
        case kRolloffCustom:
        {
            //@TODO: maxDistance can be 0.0F in that case the audio will play back incorrectly because gain becomes nan
            if (maxDistance > 0.0F)
            {
                const AnimationCurve& curve = GetCustomRolloffCurve();

                float evalTime = (distance / maxDistance);
                gain = curve.Evaluate(evalTime);
            }
        }
        break;
        default:
            break;
    }

    Assert(IsFinite(gain));

    if (gain < 0.0f)
        gain = 0.0f;
    if (gain > 1.0f)
        gain = 1.0f;

    return gain;
}

// This function is a FMOD hack that allows us to get the rolloff calculation
// to be re-evaluated once we change the rolloff curve.
// This is better than moving the channels slightly.
void AudioSource::ForceRolloffCurveEvaluation()
{
    FMOD_VECTOR vec;

    for (TOneShots::iterator it = m_OneShots.begin(); it != m_OneShots.end(); ++it)
    {
        if ((*it)->channel.IsValid())
        {
            CheckFMODError((*it)->channel->get3DConeOrientation(&vec));
            CheckFMODError((*it)->channel->set3DConeOrientation(&vec));
        }
    }

    if (m_Channel.IsValid())
    {
        CheckFMODError(m_Channel->get3DConeOrientation(&vec));
        CheckFMODError(m_Channel->set3DConeOrientation(&vec));
    }
}

float F_CALLBACK AudioSource::rolloffCallback(
    FMOD_CHANNEL *  c_channel,
    float  distance)
{
    FMOD::Channel* fmodChannel = (FMOD::Channel*)c_channel;
    SoundUserData<SoundChannelInstance>* userData = NULL;
    fmodChannel->getUserData((void**)&userData);
    if (userData == NULL || userData->TryGet() == NULL) // call TryGet here because the callback is global and we might want to support channels not created through SoundChannelInstance (i.e. third party stuff)
        return 1.0f;
    AudioSource* audioSource = userData->Get()->GetAudioSource();
    if (audioSource == NULL || audioSource->m_SpatializerDSP != NULL) // See comment in AudioSource::Update3DPanParameters
        return 1.0f;
    return audioSource->CalculateDistanceAttenuation();
}

#endif
