#ifndef AUDIOCLIP_H
#define AUDIOCLIP_H

#include "Runtime/BaseClasses/NamedObject.h"
#include "Runtime/Threads/AtomicOps.h"
#include "Runtime/Threads/Mutex.h"
#include "Runtime/Audio/correct_fmod_includer.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Serialize/SerializationCaching/CachedReader.h"
#include "Runtime/Mono/MonoIncludes.h"
#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/Audio/sound/SoundChannel.h"
#include "Runtime/File/StreamedResource.h"

#if UNITY_WIN || UNITY_WINRT || UNITY_XBOXONE
    #define AUDIOCLIP_GETFUNCTIONSIG __FUNCSIG__
#else
    #define AUDIOCLIP_GETFUNCTIONSIG __PRETTY_FUNCTION__
#endif

#define CHECK_LEGACY_AUDIOCLIP_(audioclip) \
    {\
        if(!(audioclip)->IsLegacyFormat())\
        {\
            ErrorStringObject(Format("Trying to call %s on non-legacy AudioClip!", AUDIOCLIP_GETFUNCTIONSIG), audioclip);\
        }\
        Assert((audioclip)->IsLegacyFormat());\
    }

#define CHECK_LEGACY_AUDIOCLIP() \
    CHECK_LEGACY_AUDIOCLIP_(this)

#define MAKE_LEGACY_AUDIOCLIP() \
    EnableLegacyMode();

#if ENABLE_WWW
class IWWWStream
{
public:
    virtual ~IWWWStream() {}

    virtual bool IsDone() const = 0;

    virtual void LockPartialData() = 0;
    virtual void UnlockPartialData() = 0;

    virtual size_t GetCapacity() const = 0;

    virtual const UInt8* GetPartialData() const = 0;
    virtual size_t GetPartialSize() const = 0;
};
#endif

class AudioSource;
class MoviePlayback;
namespace FMOD
{ class Channel; class Sound; }

class SampleClip : public NamedObject
{
    REGISTER_CLASS(SampleClip);
    DECLARE_OBJECT_SERIALIZE();
public:
    enum LoadType
    {
        kDecompressOnLoad = 0,
        kCompressedInMemory = 1,
        kStreaming = 2,
    };

    enum CompressionFormat
    {
        kPCM = 0,
        kVorbis = 1,
        kADPCM = 2,
        kMP3 = 3,
        kPSMVAG = 4,
        kHEVAG = 5,
        kXMA = 6,
        kAAC = 7,
        kGCADPCM = 8,
        kATRAC9 = 9
    };

    enum ContainerFormat
    {
        kUnknown = 0,
        kFSB = 1,
        kWAV = 2,
        kAIFF = 3,
        kMPEG = 4,
        kOGG = 5,
        kXM = 6,
        kS3M = 7,
        kIT = 8,
        kMOD = 9,
        kM4A = 10
    };


    SampleClip(MemLabelId label, ObjectCreationMode mode);
    virtual void MainThreadCleanup();

    static void InitializeClass();
    static void CleanupClass();

    //Loading management interface.
    bool LoadAudioData();
    bool UnloadAudioData();
    bool GetPreloadAudioData() const;
    virtual SoundHandle::LoadState GetLoadState() const;

    SoundChannel AllocateChannel(bool paused, UInt64 startTime = 0);

#if UNITY_EDITOR
    virtual SoundHandle AllocatePreviewSound();
#endif

    void LoadBaseSound();

    inline bool IsTrackerFile() const { return m_IsTrackerFormat; }

    bool IsStreamReady() const;

    CompressionFormat GetCompressionFormat() const;
    CompressionFormat GetTargetPlatformCompressionFormat() const { return m_CompressionFormat;  }
    inline LoadType GetLoadType() const { return m_LoadType; }
    inline bool GetLoadInBackground() const { return m_LoadInBackground; }
    inline bool SupportsNegativePitch() const { return GetCompressionFormat() == kPCM || m_LoadType == kDecompressOnLoad; }

    inline int GetPlayCount() const { return m_PlayCount; }
    inline void IncrementPlayCount() { AtomicIncrement(&m_PlayCount); }
    inline void ResetPlayCount() { m_PlayCount = 0; }

    bool GetLegacy3D() const { return m_Legacy3D; }

    void ReleaseIfEqual(SoundHandle handle);

    inline const WeakPtr<SampleClip>& GetWeakPtr() const { return m_WeakPtr; }

protected:
    const StreamedResource& GetResource() const;

    FMOD_MODE CalculateFMODMode() const;
    UInt32 CalculateFlags() const;

    // Serialized data
    int m_Frequency;
    int m_Channels;
    int m_BitsPerSample;
    bool m_IsTrackerFormat;
    float m_Length; // in seconds
    LoadType m_LoadType;
    SoundHandle m_Sound;
    int m_SubsoundIndex;
    bool m_PreloadAudioData;
    bool m_LoadInBackground;
    bool m_Legacy3D;

    StreamedResource  m_Resource;
    CompressionFormat m_CompressionFormat;

#if UNITY_EDITOR
    StreamedResource  m_EditorResource;
    CompressionFormat m_EditorCompressionFormat;
#endif

    // Non-serialized data
    WeakPtr<SampleClip> m_WeakPtr;
    ListNode<SampleClip> m_NodeInModifiedClipList;
    volatile int m_PlayCount;

    friend class SoundManager;
};

// AudioClip contains a lot of legacy code, and that's why it inherits from the leaner SampleClip, so that when using it in a new context we don't have to look
// at a lot of legacy functions and members that are not available here. Still, AudioClip is the only class that ever gets instanciated, because it must serialize both
// data for the new and old system.
class AudioClip : public SampleClip
{
    REGISTER_CLASS(AudioClip);
    DECLARE_OBJECT_SERIALIZE();
public:
    enum { kAudioQueueSize = (4 * 16384) };

    AudioClip(MemLabelId label, ObjectCreationMode mode);
    // virtual ~AudioClip (); - declared-by-macro

    virtual void MainThreadCleanup();

#if ENABLE_WWW
    // WARNING: don't call AwakeFromLoad if you use InitStream
    bool InitStream(IWWWStream* streamData, const char* url, MoviePlayback* movie, bool realStream = false, bool compressed = false, FMOD_SOUND_TYPE fmodSoundType = FMOD_SOUND_TYPE_UNKNOWN);
#endif
    bool InitWSound(SoundHandle::Instance* instance);
    bool CreateUserSound(const core::string& name, unsigned lengthSamples, short channels, unsigned frequency, bool stream);

    void AwakeFromLoad(AwakeFromLoadMode awakeMode);
    void AwakeFromLoadThreaded();

public:

    SoundHandle CreateSound();

    unsigned int GetSampleCount() const;
    unsigned int GetChannelCount() const;
    unsigned int GetBitRate() const;
    unsigned int GetFrequency() const;
    unsigned int GetSoundSize() const;
    unsigned int GetLength() const;
    float GetLengthSec() const;
    unsigned int GetBitsPerSample() const;
    MoviePlayback* GetMovie() const;

    bool SetData(const float* data, unsigned lengthSamples, unsigned offsetSamples = 0);
    bool GetData(float* data, unsigned lengthSamples, unsigned offsetSamples = 0) const;

    bool IsMovieAudio() const { return IsLegacyFormat() ? m_legacy->m_MoviePlayback != NULL : false; }
    int GetMusicChannelCount() const;

    bool IsWWWStreamed() const
    {
        return IsLegacyFormat() ? m_legacy->m_WWWStreamed : false;
    }

    bool IsLegacyFormat() const { return m_legacy.get() != NULL; }

    bool ReadyToPlay();

    //@{ Importer only setters
    void Importer_SetLoadType(LoadType loadtype) { m_LoadType = loadtype; }
    void Importer_SetLoadInBackground(bool flag) { m_LoadInBackground = flag; }
    void Importer_SetPreloadAudioData(bool flag) { m_PreloadAudioData = flag; }
    //@}

    // Attached movie clip
    void SetMoviePlayback(MoviePlayback* movie);
    MoviePlayback* GetMoviePlayback() const;

    /**
     * Queue data in to clip
     * This is read by streamed sound
     * @param buffer Audio data to queue
     * @param size Size of Audio data
     **/
    bool QueueAudioData(const void* const buffer, unsigned size);

    /**
     * Top audio data from the quene
     * @note buf must allocate size bytes
     * @param size The size in bytes you want to top
     * @return The audio data
     **/
    bool GetQueuedAudioData(void** buf, unsigned size);

    void ClearQueue();

    static void InitializeClass();
    static void CleanupClass();

    void Cleanup();
    void Reload();

    void EnableLegacyMode();

#if UNITY_EDITOR
    SoundHandle AllocatePreviewSound();
#endif

    static FMOD_SOUND_TYPE GetFormatFromExtension(const core::string& ext);
    static bool IsFormatSupportedByPlatform(const core::string& ext);

private:
    struct LegacyData
    {
        // Serialized data
        FMOD_SOUND_TYPE m_Type;
        FMOD_SOUND_FORMAT m_Format;

        // buffer
        typedef UNITY_VECTOR (kMemAudioData, UInt8) TAudioQueue;
        TAudioQueue m_AudioBufferQueue;

        // The mutex needs to be static because the mutex allocates a TLS key and the number of AudioCLips created by scripts can be large,
        // while the number of available TLS keys aren't (< 1024?)
        static Mutex m_AudioQueueMutex;

        bool m_UserGenerated;
        unsigned m_UserLengthSamples;
        bool m_UserIsStream;

#if ENABLE_WWW
        IWWWStream *m_StreamData;
#endif

        bool m_ExternalStream;

        //this is used, if this clip is tied to a movie to control playback
        MoviePlayback *m_MoviePlayback;

        FMOD_OPENSTATE m_OpenState;

        // Script callbacks
#if SUPPORT_SCRIPTING_THREADS
        ScriptingDomainPtr scriptingDomain;
#endif
        ScriptingArrayPtr m_PCMArray;
        int m_PCMArrayGCHandle;
        ScriptingMethodPtr m_CachedPCMReaderCallbackMethod;
        ScriptingMethodPtr m_CachedSetPositionCallbackMethod;

        ScriptingArrayPtr GetScriptPCMArray(unsigned length);
        unsigned m_DecodeBufferSize;

        // Streaming
        bool m_WWWStreamed;
        bool m_WWWCompressed;
    };

    std::auto_ptr<LegacyData> m_legacy;

    bool LoadSound();
    FMOD_CREATESOUNDEXINFO GetExInfo() const;

    void CreateScriptCallback();

    SoundHandle::Instance* m_ThreadedLoadInstance;

private:
    struct movieUserData
    {
        MoviePlayback* movie;
        unsigned read;
    };

#if ENABLE_WWW
    struct wwwUserData
    {
        bool seek;
        IWWWStream* stream;
        unsigned pos;
        unsigned filesize;
    };

    // Callbacks for WWW streaming
    static FMOD_RESULT F_CALLBACK WWWOpen(
        const char *  www,                                   // WWW class pointer
        int  unicode,
        unsigned int *  filesize,
        void **  handle,
        void **  userdata
        );

    static FMOD_RESULT F_CALLBACK WWWClose(
        void *  handle,
        void *  userdata
        );
    static FMOD_RESULT F_CALLBACK WWWRead(
        void *  handle,
        void *  buffer,
        unsigned int  sizebytes,
        unsigned int *  bytesread,
        void *  userdata
        );
    static FMOD_RESULT F_CALLBACK WWWSeek(
        void *  handle,
        unsigned int  pos,
        void *  userdata
        );
#endif
    // Callbacks for movie streaming
    static FMOD_RESULT F_CALLBACK movieopen(
        const char *  buffer,
        int  unicode,
        unsigned int *  filesize,
        void **  handle,
        void **  userdata
        );

    static FMOD_RESULT F_CALLBACK movieclose(
        void *  handle,
        void *  userdata
        );
    static FMOD_RESULT F_CALLBACK movieread(
        void *  handle,
        void *  buffer,
        unsigned int  sizebytes,
        unsigned int *  bytesread,
        void *  userdata
        );
    static FMOD_RESULT F_CALLBACK movieseek(
        void *  handle,
        unsigned int  pos,
        void *  userdata
        );


    // Callbacks for PCM streaming
    static FMOD_RESULT F_CALLBACK moviepcmread(
        FMOD_SOUND *  sound,
        void *  data,
        unsigned int  datalen
        );

    // Callbacks for PCM streaming
    static FMOD_RESULT F_CALLBACK ScriptPCMReadCallback(
        FMOD_SOUND *  sound,
        void *  data,
        unsigned int  datalen
        );

    static FMOD_RESULT F_CALLBACK ScriptPCMSetPositionCallback(
        FMOD_SOUND *  sound,
        int  subsound,
        unsigned int  position,
        FMOD_TIMEUNIT  postype);


    friend class AudioManager;

#if ENABLE_PROFILER
    static int s_GlobalCount;
#endif

    friend class AudioImporter;
};

#endif
