#ifndef AUDIOFEATUREDEFINES_H
#define AUDIOFEATUREDEFINES_H

#ifdef UNITY
    #include "Runtime/Utilities/dynamic_array.h"
    #include "Runtime/Audio/correct_fmod_includer.h"
#else
    #if defined(WIN32) || defined(_WINDOWS)
        #include <windows.h>
        #define UNITY_WIN 1
    #elif defined(__apple__)
        #define UNITY_OSX 1
    #endif
    #define ENABLE_AUDIO_FMOD 1
    #define dynamic_array vector
    #include "Runtime/Audio/correct_fmod_includer.h"
#endif

#define AUDIO_ENABLE_DEBUGGING              0

#define AUDIO_ENABLE_BREAK_ON_FMOD_ERROR    (1 * AUDIO_ENABLE_DEBUGGING)
#define AUDIO_DEBUG_ENABLE_COUNTERS         (1 * AUDIO_ENABLE_DEBUGGING)

#include "AudioDebug.h"

#if AUDIO_DEBUG_ENABLE_COUNTERS == 1
extern int AudioCounters_NumChannels;
extern int AudioCounters_NumLoopPlays;
extern int AudioCounters_NumStopCallbacks;
#endif

#if 0

class AudioRefCountedTarget
{
    AUDIO_MARKER_DATA(AUDIO_DEBUG_FILTER_SMARTPTR)

public:
    AudioRefCountedTarget()
        : m_nRefCount(0)
    {
        AUDIO_MARKER_INIT();
        AUDIO_LOGSCOPE();
    }

    virtual ~AudioRefCountedTarget()
    {
        AUDIO_LOGSCOPE();
        AUDIO_ASSERT(m_nRefCount == 0);
        AUDIO_MARKER_CLEANUP();
    }

public:
    inline void AddRef()
    {
        AUDIO_LOGSCOPE();
        ++m_nRefCount;
    }

    inline void Release()
    {
        AUDIO_LOGSCOPE();
        if (--m_nRefCount == 0)
        {
            AudioRefCountedTarget* p = this;
            UNITY_DELETE(p, kMemAudio);
        }
    }

    inline int GetRefCount() const
    {
        AUDIO_LOGSCOPE();
        return m_nRefCount;
    }

protected:
    int m_nRefCount;
};

template<typename T>
class AudioRefCountedPtr
{
    AUDIO_MARKER_DATA(AUDIO_DEBUG_FILTER_SMARTPTR)

public:
    inline AudioRefCountedPtr()
        : m_pPtr(NULL)
    {
        AUDIO_MARKER_INIT();
        AUDIO_LOGSCOPE();
    }

    inline AudioRefCountedPtr(T* pPtr)
        : m_pPtr(pPtr)
    {
        AUDIO_MARKER_INIT();
        AUDIO_LOGSCOPE();
        if (m_pPtr != NULL)
            m_pPtr->AddRef();
    }

    inline AudioRefCountedPtr(const AudioRefCountedPtr<T>& p)
        : m_pPtr(p.m_pPtr)
    {
        AUDIO_MARKER_INIT();
        AUDIO_LOGSCOPE();
        if (m_pPtr != NULL)
            m_pPtr->AddRef();
    }

    inline ~AudioRefCountedPtr()
    {
        AUDIO_LOGSCOPE();
        if (m_pPtr)
        {
            m_pPtr->Release();
            m_pPtr = NULL;
        }
        AUDIO_MARKER_CLEANUP();
    }

public:
    inline T* operator->() const
    {
        AUDIO_LOGSCOPE();
        AUDIO_ASSERT(m_pPtr != NULL);
        return m_pPtr;
    }

    inline bool operator==(T* pPtr) const
    {
        AUDIO_LOGSCOPE();
        return m_pPtr == pPtr;
    }

    inline bool operator!=(T* pPtr) const
    {
        AUDIO_LOGSCOPE();
        return m_pPtr != pPtr;
    }

    inline bool operator==(const AudioRefCountedPtr<T>& p) const
    {
        AUDIO_LOGSCOPE();
        return m_pPtr == p.m_pPtr;
    }

    inline bool operator!=(const AudioRefCountedPtr<T>& p) const
    {
        AUDIO_LOGSCOPE();
        return m_pPtr != p.m_pPtr;
    }

    inline T* GetRawPtr() const
    {
        AUDIO_LOGSCOPE();
        return m_pPtr;
    }

    inline int GetRefCount() const
    {
        AUDIO_LOGSCOPE();
        return (m_pPtr == NULL) ? 0 : m_pPtr->GetRefCount();
    }

    inline void operator=(T* p)
    {
        AUDIO_LOGSCOPE();
        if (p != NULL)
            p->AddRef();
        if (m_pPtr != NULL)
            m_pPtr->Release();
        m_pPtr = p;
    }

    inline void operator=(const AudioRefCountedPtr<T>& p)
    {
        AUDIO_LOGSCOPE();
        if (p.m_pPtr != NULL)
            p.m_pPtr->AddRef();
        if (m_pPtr != NULL)
            m_pPtr->Release();
        m_pPtr = p.m_pPtr;
    }

protected:
    mutable T* m_pPtr;
};

template<typename T> class AudioWeakPtr;

class AudioWeakPtrTarget
{
    AUDIO_MARKER_DATA(AUDIO_DEBUG_FILTER_SMARTPTR)

public:
    class Data
    {
        AUDIO_MARKER_DATA(AUDIO_DEBUG_FILTER_SMARTPTR)
    public:
        inline Data(void* pTargetPtr)
            : m_nRefCount(0)
            , m_pTargetPtr(pTargetPtr)
        {
            AUDIO_MARKER_INIT();
            AUDIO_LOGSCOPE();
        }

        inline ~Data()
        {
            AUDIO_LOGSCOPE();
            AUDIO_MARKER_CLEANUP();
        }

    public:
        inline void AddRef()
        {
            AUDIO_LOGSCOPE();
            ++m_nRefCount;
        }

        inline void Release()
        {
            AUDIO_LOGSCOPE();
            if (--m_nRefCount == 0)
            {
                AUDIO_ASSERT(m_pTargetPtr == NULL);
                Data* p = this;
                UNITY_DELETE(p, kMemAudio);
            }
        }

        inline void Clear()
        {
            AUDIO_LOGSCOPE();
            m_pTargetPtr = NULL;
        }

    public:
        void* m_pTargetPtr;
        int m_nRefCount;
    };

public:
    inline AudioWeakPtrTarget(void* pTargetPtr)
    {
        AUDIO_MARKER_INIT();
        AUDIO_LOGSCOPE();
        m_pData = UNITY_NEW(Data, kMemAudio)(pTargetPtr);
        m_pData->AddRef();
    }

    inline ~AudioWeakPtrTarget()
    {
        AUDIO_LOGSCOPE();
        m_pData->Clear();
        m_pData->Release();
        AUDIO_MARKER_CLEANUP();
    }

    Data* GetWeakPtrData() const
    {
        return m_pData;
    }

    inline int GetRefCount() const
    {
        return m_pData->m_nRefCount;
    }

protected:
    Data* m_pData;
};

template<typename T>
class AudioWeakPtr
{
    AUDIO_MARKER_DATA(AUDIO_DEBUG_FILTER_SMARTPTR)

public:
    inline AudioWeakPtr(T* pTarget)
    {
        AUDIO_MARKER_INIT();
        AUDIO_LOGSCOPE();
        m_pData = (pTarget == NULL) ? NULL : pTarget->GetWeakPtrData();
        if (m_pData != NULL)
            m_pData->AddRef();
    }

    inline AudioWeakPtr(const AudioWeakPtr<T>& p)
    {
        AUDIO_MARKER_INIT();
        AUDIO_LOGSCOPE();
        m_pData = p->GetWeakPtrData();
        if (m_pData != NULL)
            m_pData->AddRef();
    }

    inline ~AudioWeakPtr()
    {
        AUDIO_LOGSCOPE();
        if (m_pData != NULL)
        {
            m_pData->Release();
            m_pData = NULL;
        }
        AUDIO_MARKER_CLEANUP();
    }

public:
    inline T* operator->() const
    {
        AUDIO_LOGSCOPE();
        return (m_pData == NULL) ? NULL : (T*)m_pData->m_pTargetPtr;
    }

    inline bool operator!=(T* pPtr) const
    {
        AUDIO_LOGSCOPE();
        return (pPtr == NULL && m_pData != NULL) || (m_pData != NULL && m_pData->m_pTargetPtr != pPtr);
    }

    inline bool operator==(T* pPtr) const
    {
        AUDIO_LOGSCOPE();
        return (pPtr == NULL && m_pData == NULL) || (m_pData != NULL && m_pData->m_pTargetPtr == pPtr);
    }

    inline bool operator==(const AudioWeakPtr<T>& p) const
    {
        AUDIO_LOGSCOPE();
        return m_pData == p.m_pData;
    }

    inline bool operator!=(const AudioWeakPtr<T>& p) const
    {
        AUDIO_LOGSCOPE();
        return m_pData != p.m_pData;
    }

    inline void operator=(AudioWeakPtr<T>& pPtr)
    {
        AUDIO_LOGSCOPE();
        if (pPtr->m_pTarget != NULL)
            pPtr->m_pTarget->AddRef();
        if (m_pData != NULL)
            m_pData->Release();
        m_pData = pPtr->m_pTarget;
    }

    inline void operator=(AudioWeakPtrTarget* pTarget)
    {
        AUDIO_LOGSCOPE();
        if (pTarget != NULL && pTarget->GetWeakPtrData() != NULL)
            pTarget->GetWeakPtrData()->AddRef();
        if (m_pData != NULL)
            m_pData->Release();
        m_pData = (pTarget == NULL) ? NULL : pTarget->GetWeakPtrData();
    }

    inline T* GetWeakPtrTarget() const
    {
        AUDIO_LOGSCOPE();
        return (m_pData != NULL) ? m_pData->m_pTargetPtr : NULL;
    }

    inline int GetRefCount() const
    {
        AUDIO_LOGSCOPE();
        return (m_pData != NULL) ? m_pData->m_nRefCount : 0;
    }

protected:
    mutable typename AudioWeakPtrTarget::Data* m_pData;
};

class AudioChannel;
class AudioSource;
class AudioSourceSharedData;
class AudioSoundHandle;
class AudioClip;

typedef dynamic_array<AudioChannel*> TAudioChannels;
typedef TAudioChannels::iterator TAudioChannelsIter;

typedef dynamic_array<AudioSource*> TAudioSources;
typedef TAudioSources::iterator TAudioSourcesIter;

typedef dynamic_array<FMOD::DSP*> TAudioDSPList;
typedef TAudioDSPList::iterator TAudioDSPListIter;

typedef AudioRefCountedPtr<AudioSoundHandle> AudioSoundHandlePtr;
typedef AudioRefCountedPtr<AudioSourceSharedData> AudioSourceSharedDataPtr;

typedef AudioWeakPtr<AudioSource> AudioSourcePtr;

#endif

#endif
