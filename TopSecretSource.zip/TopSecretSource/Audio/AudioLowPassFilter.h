#ifndef __AUDIOLOWPASS_FILTER_H__
#define __AUDIOLOWPASS_FILTER_H__
#include "AudioSourceFilter.h"
#include "Runtime/Audio/AudioSource.h"
#include "Runtime/Math/AnimationCurveUtility.h"
#include "Runtime/Math/AnimationCurve.h"

class AudioLowPassFilter : public AudioFilter
{
    REGISTER_CLASS(AudioLowPassFilter);
    DECLARE_OBJECT_SERIALIZE();
public:
    AudioLowPassFilter(MemLabelId label, ObjectCreationMode mode);

    virtual void AwakeFromLoad(AwakeFromLoadMode awakeMode);

    virtual void CheckConsistency();
    virtual void Update();
    virtual void AddToManager();

    float GetCutoffFrequency() const;
    void SetCutoffFrequency(float value);

    float GetLowpassResonanceQ() const { return m_LowpassResonanceQ; }
    void SetLowpassResonanceQ(float value) { m_LowpassResonanceQ = value; Update(); SetDirty(); }

    const AnimationCurve& GetCustomLowpassLevelCurve() const;
    AnimationCurve* GetCustomLowpassLevelCurveCopy() const;
    void SetCustomLowpassLevelCurve(const AnimationCurve& curve);

    virtual void Reset();

private:
    friend class AudioSource;
    friend class AudioListener;

    void SetCutoffFrequencyInternal(float cutoffFrequency);

    AnimationCurve m_LowpassLevelCustomCurve;
    float          m_LowpassResonanceQ;
    bool           m_NeedToNormalizeCurve;
};

#endif // __AUDIOLOWPASS_FILTER_H__
