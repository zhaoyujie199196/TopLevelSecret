#ifndef __AUDIOHIGHPASS_FILTER_H__
#define __AUDIOHIGHPASS_FILTER_H__

#include "AudioSourceFilter.h"

class AudioHighPassFilter : public AudioFilter
{
    REGISTER_CLASS(AudioHighPassFilter);
    DECLARE_OBJECT_SERIALIZE();
public:
    AudioHighPassFilter(MemLabelId label, ObjectCreationMode mode);

    virtual void CheckConsistency();
    virtual void AddToManager();
    virtual void Reset();

    void Update();

    float GetCutoffFrequency() const { return m_CutoffFrequency; }
    void SetCutoffFrequency(float value) { m_CutoffFrequency = value; Update(); SetDirty(); }

    float GetHighpassResonanceQ() const { return m_HighpassResonanceQ; }
    void SetHighpassResonanceQ(float value) { m_HighpassResonanceQ = value; Update(); SetDirty(); }

private:
    float m_CutoffFrequency;
    float m_HighpassResonanceQ;
};

#endif // __AUDIOHIGHPASS_FILTER_H__
