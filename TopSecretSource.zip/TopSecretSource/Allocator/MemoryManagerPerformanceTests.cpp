#include "UnityPrefix.h"

#if ENABLE_PERFORMANCE_TESTS

#include "Runtime/Testing/PerformanceTesting.h"
#include "Runtime/Testing/MultiThreadedTestFixture.h"
#include "Runtime/Allocator/DynamicHeapAllocator.h"
#include "Runtime/Allocator/MemoryManager.h"
#include "Runtime/Threads/Thread.h"

PERFORMANCE_TEST_SUITE(MemoryManagerPerformance)
{
    struct TempAllocWrapper
    {
        static void* Alloc(size_t size) { return UNITY_MALLOC(kMemTempAlloc, size); }
        static void  Free(void* ptr) { UNITY_FREE(kMemTempAlloc, ptr); }
    };
    struct TempJobAllocWrapper
    {
        static void* Alloc(size_t size) { return UNITY_MALLOC(kMemTempJobAlloc, size); }
        static void  Free(void* ptr) { UNITY_FREE(kMemTempJobAlloc, ptr); }
    };
    struct TempOverflowAllocWrapper
    {
        static void* Alloc(size_t size) { return UNITY_MALLOC(kMemTempOverflow, size); }
        static void  Free(void* ptr) { UNITY_FREE(kMemTempOverflow, ptr); }
    };
    struct DefaultAllocWrapper
    {
        static void* Alloc(size_t size) { return UNITY_MALLOC(kMemDefault, size); }
        static void  Free(void* ptr) { UNITY_FREE(kMemDefault, ptr); }
    };
    class DynamicHeapAllocWrapper
    {
    public:
        DynamicHeapAllocWrapper() { m_Alloc = new DynamicHeapAllocator<LowLevelAllocator>(4 * 1024 * 1024, 1024, true, NULL, "TestAlloc"); }
        ~DynamicHeapAllocWrapper() { delete m_Alloc; }
        void* Alloc(size_t size) { return m_Alloc->Allocate(size, kDefaultMemoryAlignment); }
        void  Free(void* ptr) { m_Alloc->Deallocate(ptr); }
    private:
        DynamicHeapAllocator<LowLevelAllocator>* m_Alloc;
    };
    struct MallocFreeAllocWrapper
    {
        static void* Alloc(size_t size) { return ::malloc(size); }
        static void  Free(void* ptr) { ::free(ptr); }
    };

    static const size_t allocSizes[] = { 134, 345, 763, 4768, 343, 245, 5643, 85335, 3453, 7843, 2346, 437, 3475, 289, 43743, 437 };
    static const size_t allocSizesCount = sizeof(allocSizes) / sizeof(allocSizes[0]);

    template<class TAlloc, size_t NOuterLoops, size_t NInnerLoops>
    void StackAllocPerformanceTest(TAlloc& alloc)
    {
        size_t* ptrs[NInnerLoops] = {};

        if (Thread::CurrentThreadIsMainThread())
            GetMemoryManager().FrameMaintenance();

        // Prewarm alloc
        void* fillptr01 = alloc.Alloc(128);
        void* fillptr02 = alloc.Alloc(504);
        void* fillptr03 = alloc.Alloc(1058);

        PERFORMANCE_TEST_LOOP(NOuterLoops)
        {
            for (size_t i = 0; i < NInnerLoops; ++i)
            {
                const size_t allocSize = allocSizes[i % allocSizesCount];
                ptrs[i] = (size_t*)alloc.Alloc(sizeof(size_t) + allocSize);
                *(ptrs[i]) = i;
            }

            for (size_t i = 0; i < NInnerLoops; ++i)
            {
                CHECK_EQUAL(i, *(ptrs[i]));
                alloc.Free(ptrs[i]);
            }
        }

        alloc.Free(fillptr03);
        alloc.Free(fillptr02);
        alloc.Free(fillptr01);

        if (Thread::CurrentThreadIsMainThread())
            GetMemoryManager().FrameMaintenance();
    }

    static const size_t kOuterLoops = 1000;
    static const size_t kInnerLoops = 50;

    TEST(StackAllocations_kMemTempAlloc)
    {
        TempAllocWrapper alloc;
        StackAllocPerformanceTest<TempAllocWrapper, kOuterLoops, kInnerLoops>(alloc);
    }

    TEST(StackAllocations_kMemTempJobAlloc)
    {
        TempJobAllocWrapper alloc;
        StackAllocPerformanceTest<TempJobAllocWrapper, kOuterLoops, kInnerLoops>(alloc);
    }

    TEST(StackAllocations_kMemTempOverflow)
    {
        TempOverflowAllocWrapper alloc;
        StackAllocPerformanceTest<TempOverflowAllocWrapper, kOuterLoops, kInnerLoops>(alloc);
    }

    TEST(StackAllocations_kMemDefault)
    {
        DefaultAllocWrapper alloc;
        StackAllocPerformanceTest<DefaultAllocWrapper, kOuterLoops, kInnerLoops>(alloc);
    }

    TEST(StackAllocations_DynamicHeapAllocator)
    {
        DynamicHeapAllocWrapper alloc;
        StackAllocPerformanceTest<DynamicHeapAllocWrapper, kOuterLoops, kInnerLoops>(alloc);
    }

    TEST(StackAllocations_MallocFree)
    {
        MallocFreeAllocWrapper alloc;
        StackAllocPerformanceTest<MallocFreeAllocWrapper, kOuterLoops, kInnerLoops>(alloc);
    }

    static const size_t kMTOuterLoops = 100;
    static const size_t kMTInnerLoops = 50;

    template<class TAlloc>
    class BaseAllocThreadedStackPerformanceTestFixture : public MultiThreadedPerformanceTestFixture
    {
    public:
        BaseAllocThreadedStackPerformanceTestFixture() : MultiThreadedPerformanceTestFixture(GetSuggestedThreadsCount(), 0) {}

        virtual void ThreadFunc(size_t threadIdx)
        {
            StackAllocPerformanceTest<TAlloc, kMTOuterLoops, kMTInnerLoops>(m_Alloc);
        }

    private:
        TAlloc m_Alloc;
    };

    class TempJobAllocThreadedStackPerformanceFixture : public BaseAllocThreadedStackPerformanceTestFixture<TempJobAllocWrapper> {};
    class TempOverflowAllocThreadedStackPerformanceFixture : public BaseAllocThreadedStackPerformanceTestFixture<TempOverflowAllocWrapper> {};
    class DynamicHeapAllocThreadedStackPerformanceFixture : public BaseAllocThreadedStackPerformanceTestFixture<DynamicHeapAllocWrapper> {};
    class DefaultAllocThreadedStackPerformanceFixture : public BaseAllocThreadedStackPerformanceTestFixture<DefaultAllocWrapper> {};
    class MallocFreeThreadedStackPerformanceFixture : public BaseAllocThreadedStackPerformanceTestFixture<MallocFreeAllocWrapper> {};

    TEST_FIXTURE(TempJobAllocThreadedStackPerformanceFixture, ThreadedStackAllocations_kMemTempJobAlloc)
    {
        Run();
    }

    TEST_FIXTURE(TempOverflowAllocThreadedStackPerformanceFixture, ThreadedStackAllocations_kMemTempOverflow)
    {
        Run();
    }

    TEST_FIXTURE(DefaultAllocThreadedStackPerformanceFixture, ThreadedStackAllocations_kMemDefault)
    {
        Run();
    }

    TEST_FIXTURE(DynamicHeapAllocThreadedStackPerformanceFixture, ThreadedStackAllocations_DynamicHeapAllocator)
    {
        Run();
    }

    TEST_FIXTURE(MallocFreeThreadedStackPerformanceFixture, ThreadedStackAllocations_MallocFree)
    {
        Run();
    }
}

#endif // ENABLE_PERFORMANCE_TESTS
