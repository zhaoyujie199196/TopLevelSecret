#ifndef DUALTHREAD_ALLOCATOR_H_
#define DUALTHREAD_ALLOCATOR_H_

#if ENABLE_MEMORY_MANAGER

#include "Runtime/Allocator/BaseAllocator.h"
#include "Runtime/Threads/ThreadSpecificValue.h"

class BucketAllocator;
class DelayedPointerDeletionManager;

// Dual Thread Allocator is an indirection to a real allocator

// Has pointer to the main allocator (nonlocking)
// Has pointer to the shared thread allocator (locking)

/************************************************************************/
/* This takes 2 allocators (one lockless and one lockprotected) and is  */
/* a higher level logic for directing the allocations to the right      */
/* allocator. Main thread uses the lockless one, and all threads        */
/* share the protected one. Allocations from the main thread, that      */
/* are deallocated on a thread, must be put on a queue and deallocated  */
/* from the main thread. on windows and mac, this is the allocator we   */
/* use for most things, with the DynamicHeapAllocator as base.          */
/************************************************************************/

template<class UnderlyingAllocator>
class DualThreadAllocator : public BaseAllocator
{
public:
    // when constructing it will be from the main thread
    DualThreadAllocator(const char* name, BucketAllocator* bucketAllocator, BaseAllocator* mainAllocator, BaseAllocator* threadAllocator);
    virtual ~DualThreadAllocator() {}

    virtual void*  Allocate(size_t size, int align);
    virtual void*  Reallocate(void* p, size_t size, int align);
    virtual void   Deallocate(void* p) { TryDeallocate(p); }
    virtual bool   TryDeallocate(void* p);
    virtual bool   Contains(const void* p) const;
    virtual size_t GetPtrSize(const void* ptr) const;
    virtual bool   CheckIntegrity();

    virtual size_t GetAllocatedMemorySize() const;
    virtual size_t GetBookKeepingMemorySize() const;
    virtual size_t GetReservedMemorySize() const;

#if USE_MEMORY_DEBUGGING || ENABLE_MEM_PROFILER
    virtual ProfilerAllocationHeader* GetProfilerHeader(const void* ptr) const;
    virtual size_t GetRequestedPtrSize(const void* ptr) const;
    virtual bool   ValidateIntegrity(const void* ptr) const;
#endif // USE_MEMORY_DEBUGGING || ENABLE_MEM_PROFILER

    virtual void ThreadCleanup();
    virtual void FrameMaintenance(bool cleanup);

private:
    UnderlyingAllocator* GetCurrentAllocator() const;
    void CreateDelayedDeletionManager();

    BucketAllocator*     m_BucketAllocator;
    UnderlyingAllocator* m_MainAllocator;
    UnderlyingAllocator* m_ThreadAllocator;

    DelayedPointerDeletionManager* m_DelayedDeletion;
};

#endif
#endif
