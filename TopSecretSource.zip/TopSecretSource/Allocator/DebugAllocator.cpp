#include "UnityPrefix.h"
#include "Runtime/Allocator/DebugAllocator.h"

#if ENABLE_MEMORY_MANAGER && PLATFORM_SUPPORTS_DEBUG_ALLOCATOR

#include "Runtime/Allocator/AllocationHeader.h"
#include "Runtime/Allocator/MemoryManager.h"
#include "Runtime/Profiler/MemoryProfiler.h"
#include "Runtime/Threads/AtomicOps.h"

#if UNITY_WIN
#include <Windows.h>
#elif UNITY_POSIX
#include <unistd.h>
#include <sys/mman.h>
#endif

#include <cstdlib>

static bool ShouldProtectAllocation(size_t size)
{
    if (DEBUG_ALLOCATOR_MINIMUM_MEMORY_SIZE_TO_PROTECT < 0)
        return true;
    return size >= DEBUG_ALLOCATOR_MINIMUM_MEMORY_SIZE_TO_PROTECT;
}

struct DebugAllocatorHeader
{
    static size_t CalculateNeededAllocationSize(size_t size, ptrdiff_t align,
        bool protectAllocation, ptrdiff_t pageSize)
    {
        size_t headerAndPaddingSize = MemoryProfiler::GetHeaderSize() + sizeof(DebugAllocatorHeader) + align - 1 + size;
        if (!protectAllocation)
            return headerAndPaddingSize;

        return (pageSize + (headerAndPaddingSize + pageSize)) & (-pageSize);
    }

    static DebugAllocatorHeader* SetupHeader(void* realPtr, size_t realSize, size_t size, ptrdiff_t align, bool shouldProtect, ptrdiff_t pageSize)
    {
        UInt8* realPtr8 = static_cast<UInt8*>(realPtr);
        UInt8* endPtr8 = realPtr8 + realSize;
        UInt8* userPtr;

        if (!shouldProtect)
        {
            userPtr = reinterpret_cast<UInt8*>(reinterpret_cast<size_t>(endPtr8 - size) & (-align));
        }
        else
        {
            UInt8* endPagePtr8 = reinterpret_cast<UInt8*>(reinterpret_cast<size_t>(endPtr8) & (-pageSize));
            UInt8* guardPagePtr = endPagePtr8 - pageSize;
            userPtr = reinterpret_cast<UInt8*>(reinterpret_cast<size_t>(guardPagePtr - size) & (-align));
        }

        DebugAllocatorHeader* header = GetHeader(userPtr);
        header->size = size;
        header->realPtrDiff = userPtr - realPtr8;
        header->overheadSize = realSize - size;
        header->magic = kMagic;
        return header;
    }

    static ProfilerAllocationHeader* GetProfilerHeader(void* ptr)
    {
#if ENABLE_MEM_PROFILER
        // ProfilerAllocationHeader is always just before profiler header
        return reinterpret_cast<ProfilerAllocationHeader*>(ptr) - 1;
#else
        return NULL;
#endif
    }

    static DebugAllocatorHeader* GetHeader(void* ptr)
    {
#if ENABLE_MEM_PROFILER
        // DebugAllocatorHeader is RO and always just before profiler header
        return reinterpret_cast<DebugAllocatorHeader*>(GetProfilerHeader(ptr)) - 1;
#else
        return reinterpret_cast<DebugAllocatorHeader*>(ptr) - 1;
#endif
    }

    void* GetUserPtr()
    {
#if ENABLE_MEM_PROFILER
        return reinterpret_cast<ProfilerAllocationHeader*>(this + 1) + 1;
#else
        return this + 1;
#endif
    }

    void* GetRealPtr() { return static_cast<UInt8*>(GetUserPtr()) - realPtrDiff; }
    void* GetPostGuardPtr(int pageSize)
    {
        return static_cast<UInt8*>(GetRealPtr()) + size + overheadSize - pageSize;
    }

    static const UInt32 kMagic = 0xD09F00D;

    size_t size;
    UInt16 realPtrDiff;
    UInt16 overheadSize;
    UInt32 magic;                                        // Magic value for the header check
};

DebugAllocator::DebugAllocator(const char* name)
    : BaseAllocator(name)
    , m_PageSize(0)
    , m_AllocationGranularity(0)
    , m_ProtectionMode(ProtectionMode::ReadWriteProtection)
    , m_BasePtr(NULL)
{
    // Obtain system's page size
#if UNITY_WIN
    SYSTEM_INFO sysInfo;
    GetSystemInfo(&sysInfo);
    m_PageSize = sysInfo.dwPageSize;
    m_AllocationGranularity = sysInfo.dwAllocationGranularity;
#elif UNITY_POSIX
    m_PageSize = m_AllocationGranularity = getpagesize();
#endif
    AssertMsg(m_PageSize > 0, "DebugAllocator: Unknown memory page size!");
    AssertMsg(IsPowerOfTwo(m_PageSize), "DebugAllocator: Memory page size MUST be ^2!");

    // Got intial memory address which will be always incremented further.
#if UNITY_WIN
    void* ptr = VirtualAlloc(NULL, m_PageSize, MEM_RESERVE, PAGE_NOACCESS);
    m_BasePtr = static_cast<UInt8*>(ptr) + m_PageSize;
    VirtualFree(ptr, 0, MEM_RELEASE);
#elif UNITY_POSIX
    void* ptr = mmap(NULL, m_PageSize, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (ptr != MAP_FAILED)
    {
        m_BasePtr = static_cast<UInt8*>(ptr) + m_PageSize;
        munmap(ptr, m_PageSize);
    }
#endif
}

void* DebugAllocator::Allocate(size_t size, int align)
{
    bool shouldProtect = ShouldProtectAllocation(size);

    size_t realSize = DebugAllocatorHeader::CalculateNeededAllocationSize(size, align, shouldProtect, m_PageSize);

    void* realPtr = shouldProtect ? VirtualPageAllocateAndProtect(realSize) : std::malloc(realSize);
    if (realPtr == NULL)
        return NULL;

    DebugAllocatorHeader* header = DebugAllocatorHeader::SetupHeader(realPtr, realSize, size, align, shouldProtect, m_PageSize);
    RegisterAllocation(header);

    return header->GetUserPtr();
}

void* DebugAllocator::Reallocate(void* p, size_t size, int align)
{
    if (p == NULL)
        return Allocate(size, align);

    void* newPtr = Allocate(size, align);
    if (newPtr == NULL)
        return NULL;

    DebugAllocatorHeader* oldHeader = DebugAllocatorHeader::GetHeader(p);
    UNITY_MEMCPY(newPtr, p, std::min<size_t>(size, oldHeader->size));

    Deallocate(p);

    return newPtr;
}

void DebugAllocator::Deallocate(void* p)
{
    if (p == NULL)
        return;

    DebugAllocatorHeader* header = DebugAllocatorHeader::GetHeader(p);
    AssertMsg(header->magic == DebugAllocatorHeader::kMagic, "Invalid memory pointer was detected!");
    RegisterDeallocation(header);

    void* realPtr = header->GetRealPtr();

    bool shouldProtect = ShouldProtectAllocation(header->size);
    size_t realSize = header->size + header->overheadSize;

    if (shouldProtect)
        VirtualPageDecommitAndProtect(realPtr, realSize);
    else
        std::free(realPtr);
}

bool DebugAllocator::Contains(const void* ptr) const
{
    if (ptr == NULL)
        return false;

    DebugAllocatorHeader* header = DebugAllocatorHeader::GetHeader(const_cast<void*>(ptr));
    return header->magic == DebugAllocatorHeader::kMagic;
}

size_t DebugAllocator::GetPtrSize(const void* ptr) const
{
    if (ptr == NULL)
        return 0;

    DebugAllocatorHeader* header = DebugAllocatorHeader::GetHeader(const_cast<void*>(ptr));
    return header->size;
}

#if USE_MEMORY_DEBUGGING || ENABLE_MEM_PROFILER

ProfilerAllocationHeader* DebugAllocator::GetProfilerHeader(const void* ptr) const
{
    if (ptr == NULL)
        return NULL;

    return DebugAllocatorHeader::GetProfilerHeader(const_cast<void*>(ptr));
}

size_t DebugAllocator::GetRequestedPtrSize(const void* ptr) const
{
    if (ptr == NULL)
        return 0;

    DebugAllocatorHeader* header = DebugAllocatorHeader::GetHeader(const_cast<void*>(ptr));
    return header->size;
}

bool DebugAllocator::ValidateIntegrity(const void* ptr) const
{
    DebugAllocatorHeader* header = DebugAllocatorHeader::GetHeader(const_cast<void*>(ptr));
    AssertMsg(header->magic == DebugAllocatorHeader::kMagic, "Invalid memory pointer was detected!");
    return header->magic == DebugAllocatorHeader::kMagic;
}

#endif // USE_MEMORY_DEBUGGING || ENABLE_MEM_PROFILER

void DebugAllocator::SetBufferOverrunProtectionMode(ProtectionMode mode)
{
    m_ProtectionMode = mode;
}

void DebugAllocator::RegisterAllocation(DebugAllocatorHeader* h)
{
    // Update stats
    Mutex::AutoLock lock(m_AllocStatsMutex);

    RegisterAllocationData(h->size, h->overheadSize);
    m_TotalReservedBytes += h->size + h->overheadSize;
}

void DebugAllocator::RegisterDeallocation(DebugAllocatorHeader* h)
{
    // Update stats
    Mutex::AutoLock lock(m_AllocStatsMutex);

    RegisterDeallocationData(h->size, h->overheadSize);
    m_TotalReservedBytes -= h->size + h->overheadSize;
}

void* DebugAllocator::VirtualPageAllocateAndProtect(size_t totalSizeWithGuardPage)
{
    // Using base address is important for performance reasons due to ASLR bug in 10.10.
    // (Calling mmap(NULL, ...) might be too expensive because of an algorithm system uses to find unused address.)
    void* ptr = NULL;
    // As we do munmap, it's we never allocate in previously deallocated pages.
    // We always suggest larger pointer to mmap to avoid virtual addresses reuse.
    const size_t increment = m_PageSize;
    int retries = 0;
    for (;;)
    {
        const size_t basePtrIncrement = (totalSizeWithGuardPage - m_PageSize + (increment << retries) + m_AllocationGranularity - 1)  & ~(m_AllocationGranularity - 1);
        void* nextBasePtr = reinterpret_cast<void*>(AtomicAdd((size_t volatile*)&m_BasePtr, (size_t)basePtrIncrement));
        void* suggestedPtr = static_cast<UInt8*>(nextBasePtr) - basePtrIncrement;

        // Try to allocate at suggested address.
#if UNITY_WIN
        ptr = VirtualAlloc(suggestedPtr, totalSizeWithGuardPage, MEM_RESERVE, PAGE_NOACCESS);
        if (ptr != NULL) // Chaining fail check
#elif UNITY_POSIX
        // We can do not fixed alloc on posix.
        ptr = mmap(suggestedPtr, totalSizeWithGuardPage, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (ptr != MAP_FAILED) // Chaining fail check
#endif

            // Check if we got a larger address.
            if (ptr >= static_cast<UInt8*>(suggestedPtr) - m_AllocationGranularity)
                break;

        // Allocation at the requested ptr failed or mmap returned ptr which is less than the base one.
        // To prevent reusage of addresses we suggest larger address next iteration.
#if UNITY_WIN
        VirtualFree(ptr, 0, MEM_RELEASE);
#elif UNITY_POSIX
        munmap(ptr, totalSizeWithGuardPage);
#endif

        // Retry with increasing suggested ptr up to by m_PageSize << 32.
        if (retries++ >= 32)
            return NULL;
    }

    // Protect guard page
#if UNITY_WIN
    switch (m_ProtectionMode)
    {
        case ProtectionMode::NoProtection:
            return VirtualAlloc(ptr, totalSizeWithGuardPage, MEM_COMMIT, PAGE_READWRITE);
        case ProtectionMode::WriteProtection:
        {
            void* returnPtr = VirtualAlloc(ptr, totalSizeWithGuardPage, MEM_COMMIT, PAGE_READWRITE);
            DWORD oldProtect;
            VirtualProtect(static_cast<UInt8*>(returnPtr) + totalSizeWithGuardPage - m_PageSize, m_PageSize, PAGE_READONLY, &oldProtect);
            return returnPtr;
        }
        case ProtectionMode::ReadWriteProtection:
            return VirtualAlloc(ptr, totalSizeWithGuardPage - m_PageSize, MEM_COMMIT, PAGE_READWRITE);
        default:
            return NULL;
    }
#elif UNITY_POSIX
    void* guardPtr = static_cast<UInt8*>(ptr) + totalSizeWithGuardPage - m_PageSize;
    switch (m_ProtectionMode)
    {
        case ProtectionMode::WriteProtection:
            mprotect(guardPtr, m_PageSize, PROT_READ);
            break;
        case ProtectionMode::ReadWriteProtection:
            mprotect(guardPtr, m_PageSize, PROT_NONE);
            madvise(guardPtr, m_PageSize, MADV_DONTNEED);
            break;
        default:
            break;
    }

    return ptr;
#endif

    return NULL;
}

void DebugAllocator::VirtualPageDecommitAndProtect(void* ptr, size_t size)
{
#if UNITY_WIN
    VirtualFree(ptr, 0, MEM_RELEASE);
#elif UNITY_POSIX
    munmap(ptr, size);
#endif
}

#endif // ENABLE_MEMORY_MANAGER && PLATFORM_SUPPORTS_DEBUG_ALLOCATOR
