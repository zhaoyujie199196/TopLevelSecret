#include "UnityPrefix.h"
#include "Runtime/Allocator/ThreadsafeLinearAllocator.h"

#if ENABLE_UNIT_TESTS
#if ENABLE_MEMORY_MANAGER && SUPPORT_THREADS

#include "Runtime/Testing/Testing.h"
#include "Runtime/Threads/Thread.h"

INTEGRATION_TEST_SUITE(ThreadsafeLinearAllocator)
{
    static const size_t kAllocSizes[] = { 1234, 345, 763, 34768, 343, 2345, 45643, 85335, 3453, 7843, 2346, 437, 3475, 23789, 423743, 4537 };
    static const size_t kAllocSizesCount = sizeof(kAllocSizes) / sizeof(kAllocSizes[0]);

    template<int Size>
    class LinearAllocationTest
    {
    public:
        static void* RunThread(void *data)
        {
            const int numRetries = 200;
            const int numAllocations = 50;
            int* pointers[numAllocations];
            for (int j = 0; j < numRetries; ++j)
            {
                for (int i = 0; i < numAllocations; ++i)
                {
                    pointers[i] = (int*)UNITY_MALLOC(kMemTempJobAlloc, sizeof(int) + kAllocSizes[i % kAllocSizesCount]);
                    *(pointers[i]) = i;
                }
                for (int i = 0; i < numAllocations; ++i)
                {
                    CHECK_EQUAL(i, *(pointers[i]));
                    UNITY_FREE(kMemTempJobAlloc, pointers[i]);
                }
            }
            return 0;
        }

        void RunTest()
        {
            for (int i = 0; i < Size; ++i)
                m_Threads[i].Run(RunThread, NULL);
            for (int i = 0; i < Size; ++i)
                m_Threads[i].WaitForExit();
        }

    private:
        Thread m_Threads[Size];
    };

    TEST(MallocFree_On10Threads_DoesNotCrash)
    {
        LinearAllocationTest<10> testRunner;
        testRunner.RunTest();
    }

    struct Fixture
    {
        Fixture()
        {
            allocator = UNITY_NEW(ThreadsafeLinearAllocator(64, 4, "Test"), kMemDefault);
        }

        ~Fixture()
        {
            UNITY_DELETE(allocator, kMemDefault);
        }

        ThreadsafeLinearAllocator* allocator;
    };

    TEST_FIXTURE(Fixture, Allocate_LargeBlock_Overflows)
    {
        CHECK_EQUAL(64, allocator->GetReservedMemorySize());
        void* ptr = allocator->Allocate(65, kDefaultMemoryAlignment);
        CHECK_EQUAL(64, allocator->GetReservedMemorySize());
        allocator->Deallocate(ptr);
    }

    TEST_FIXTURE(Fixture, Initialization_ReservesOneBlock)
    {
        CHECK_EQUAL(64, allocator->GetReservedMemorySize());
    }

    TEST_FIXTURE(Fixture, Allocate_ReservesBlock)
    {
        void* ptrs[4];
        for (int i = 0; i < 4; ++i)
        {
            ptrs[i] = allocator->Allocate(32, kDefaultMemoryAlignment);
            CHECK_EQUAL(64 * (i + 1), allocator->GetReservedMemorySize());
        }

        for (int i = 0; i < 4; ++i)
            allocator->Deallocate(ptrs[i]);
    }

    TEST_FIXTURE(Fixture, Allocate_WithFullBlocks_Overflows)
    {
        void* ptrs[5];
        for (int i = 0; i < 4; ++i)
            ptrs[i] = allocator->Allocate(32, kDefaultMemoryAlignment);

        ptrs[4] = allocator->Allocate(32, kDefaultMemoryAlignment);
        CHECK_EQUAL(64 * 4, allocator->GetReservedMemorySize());

        for (int i = 0; i < 5; ++i)
            allocator->Deallocate(ptrs[i]);
    }

    TEST_FIXTURE(Fixture, FrameMaintance_DetectsLeaks)
    {
        void* ptr = allocator->Allocate(16, kDefaultMemoryAlignment);
        for (int i = 0; i < ThreadsafeLinearAllocator::kMaxAllocationFramespan - 1; ++i)
            allocator->FrameMaintenance(false);
        EXPECT(Warning, "Internal: JobTempAlloc has allocations that are more than 4 frames old - this is not allowed and likely a leak");
        allocator->FrameMaintenance(false);
        allocator->Deallocate(ptr);
    }
}
#endif
#endif
