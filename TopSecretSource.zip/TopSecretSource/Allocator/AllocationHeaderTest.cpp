#include "UnityPrefix.h"
#include "Runtime/Allocator/AllocationHeader.h"

#if ENABLE_MEMORY_MANAGER
#if ENABLE_UNIT_TESTS

#include "Runtime/Testing/Testing.h"

UNIT_TEST_SUITE(AllocationHeaderTests)
{
    struct DerivedAllocationSizeHeader : AllocationSizeHeader
    {
    };

    TEST(AllocationHeaderStructsHaveCorrectSize)
    {
        CHECK_EQUAL(sizeof(size_t), sizeof(AllocationSizeHeader));
        CHECK(sizeof(NullAllocationSizeHeader) <= 1);
    }

    TEST(HasAllocationSizeWorks)
    {
        CHECK(HasAllocationSize<AllocationSizeHeader>::result);
        CHECK(HasAllocationSize<DerivedAllocationSizeHeader>::result);
        CHECK(!HasAllocationSize<NullAllocationSizeHeader>::result);
    }
}

#endif // ENABLE_UNIT_TESTS
#endif // ENABLE_MEMORY_MANAGER
