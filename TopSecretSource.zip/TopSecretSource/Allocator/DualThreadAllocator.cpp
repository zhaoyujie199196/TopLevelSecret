#include "UnityPrefix.h"
#include "DualThreadAllocator.h"
#include "Runtime/Threads/Thread.h"
#include "Runtime/Threads/Mutex.h"
#include "Runtime/Allocator/AllocationHeader.h"
#include "Runtime/Allocator/BucketAllocator.h"
#include "Runtime/Allocator/DynamicHeapAllocator.h"

#if ENABLE_MEMORY_MANAGER

class DelayedPointerDeletionManager
{
public:
    DelayedPointerDeletionManager(BaseAllocator* mainAlloc, BaseAllocator* threadAlloc) :
        m_MainThreadPendingPointers(NULL),
        m_MainThreadPendingCount(0),
        m_MainThreadPendingReserved(0),
        m_HasPendingDeletes(0),
        m_MainAlloctor(mainAlloc),
        m_ThreadAlloctor(threadAlloc)
    {}

    ~DelayedPointerDeletionManager() { CleanupPendingMainThreadPointers(); }

    bool HasPending() {return m_HasPendingDeletes != 0; }
    void AddPointerToMainThreadDealloc(void* ptr);
    void CleanupPendingMainThreadPointers();
    void DeallocateLocalMemory();
private:
    void GrowPendingBuffer();
    void** m_MainThreadPendingPointers;
    UInt32 m_MainThreadPendingCount;
    UInt32 m_MainThreadPendingReserved;

    volatile int m_HasPendingDeletes;
    BaseAllocator* m_MainAlloctor;
    BaseAllocator* m_ThreadAlloctor;
    Mutex m_MainThreadPendingPointersMutex;
};

void DelayedPointerDeletionManager::AddPointerToMainThreadDealloc(void* ptr)
{
    Mutex::AutoLock autolock(m_MainThreadPendingPointersMutex);
    if (++m_MainThreadPendingCount > m_MainThreadPendingReserved)
        GrowPendingBuffer();
    m_MainThreadPendingPointers[m_MainThreadPendingCount - 1] = ptr;
    m_HasPendingDeletes = 1;
}

void DelayedPointerDeletionManager::CleanupPendingMainThreadPointers()
{
    Mutex::AutoLock autolock(m_MainThreadPendingPointersMutex);
    Assert(Thread::CurrentThreadIsMainThread());
    m_HasPendingDeletes = 0;

    for (UInt32 i = 0; i < m_MainThreadPendingCount; ++i)
        m_MainAlloctor->Deallocate(m_MainThreadPendingPointers[i]);
    m_MainThreadPendingCount = 0;
}

void DelayedPointerDeletionManager::DeallocateLocalMemory()
{
    Assert(!m_HasPendingDeletes && m_MainThreadPendingCount == 0);
    m_ThreadAlloctor->Deallocate(m_MainThreadPendingPointers);
    m_MainThreadPendingPointers = NULL;
    m_MainThreadPendingReserved = 0;
}

void DelayedPointerDeletionManager::GrowPendingBuffer()
{
    const UInt32 kInitialBufferSize = 128;
    m_MainThreadPendingReserved = std::max(m_MainThreadPendingReserved * 2, kInitialBufferSize);
    m_MainThreadPendingPointers = (void**)m_ThreadAlloctor->Reallocate(m_MainThreadPendingPointers, m_MainThreadPendingReserved * sizeof(void*), kDefaultMemoryAlignment);
}

template<class UnderlyingAllocator>
DualThreadAllocator<UnderlyingAllocator>::DualThreadAllocator(const char* name, BucketAllocator* bucketAllocator, BaseAllocator* mainAllocator, BaseAllocator* threadAllocator)
    : BaseAllocator(name)
    , m_BucketAllocator(bucketAllocator)
    , m_MainAllocator((UnderlyingAllocator*)mainAllocator)
    , m_ThreadAllocator((UnderlyingAllocator*)threadAllocator)
    , m_DelayedDeletion(NULL)
{
}

template<class UnderlyingAllocator>
void DualThreadAllocator<UnderlyingAllocator>::ThreadCleanup()
{
    if (Thread::CurrentThreadIsMainThread())
        UNITY_DELETE(m_DelayedDeletion, kMemManager);
}

template<class UnderlyingAllocator>
void DualThreadAllocator<UnderlyingAllocator>::FrameMaintenance(bool cleanup)
{
    if (m_DelayedDeletion)
    {
        m_DelayedDeletion->CleanupPendingMainThreadPointers();
        if (cleanup)
        {
            m_DelayedDeletion->DeallocateLocalMemory();
            ThreadCleanup();
        }
    }
}

template<class UnderlyingAllocator>
UnderlyingAllocator* DualThreadAllocator<UnderlyingAllocator>::GetCurrentAllocator() const
{
    if (Thread::CurrentThreadIsMainThread())
        return m_MainAllocator;
    else
        return m_ThreadAllocator;
}

template<class UnderlyingAllocator>
void* DualThreadAllocator<UnderlyingAllocator>::Allocate(size_t size, int align)
{
    // Try lockless allocator first
    if (m_BucketAllocator != NULL && m_BucketAllocator->BucketAllocator::CanAllocate(size, align))
    {
        void* ptr = m_BucketAllocator->BucketAllocator::Allocate(size, align);
        if (ptr != NULL)
            return ptr;
    }

    // Use either main thread allocator or thread allocator
    UnderlyingAllocator* alloc = GetCurrentAllocator();
    bool isMainThread = alloc == m_MainAllocator;
    if (isMainThread && m_DelayedDeletion && m_DelayedDeletion->HasPending())
        m_DelayedDeletion->CleanupPendingMainThreadPointers();

    return alloc->UnderlyingAllocator::Allocate(size, align);
}

template<class UnderlyingAllocator>
void* DualThreadAllocator<UnderlyingAllocator>::Reallocate(void* p, size_t size, int align)
{
    size_t oldSize = m_BucketAllocator != NULL ? m_BucketAllocator->BucketAllocator::GetPtrSize(p) : 0;
    if (oldSize != 0)
    {
        // Check if we can stay in BucketAllocator
        if (m_BucketAllocator->BucketAllocator::CanAllocate(size, align))
        {
            void* realPtr = m_BucketAllocator->BucketAllocator::Reallocate(p, size, align);
            if (realPtr != NULL)
                return realPtr;
        }

        // Size is too large
        void* realNewPtr = Allocate(size, align);
        if (realNewPtr != NULL)
            UNITY_MEMCPY(realNewPtr, p, oldSize);

        m_BucketAllocator->BucketAllocator::Deallocate(p);

        return realNewPtr;
    }

    UnderlyingAllocator* alloc = GetCurrentAllocator();

    if (alloc->UnderlyingAllocator::Contains(p))
        return alloc->UnderlyingAllocator::Reallocate(p, size, align);

    UnderlyingAllocator* containingAlloc = NULL;
    if (alloc == m_MainAllocator)
    {
        Assert(m_ThreadAllocator->UnderlyingAllocator::Contains(p));
        containingAlloc = m_ThreadAllocator;
    }
    else
    {
        Assert(m_MainAllocator->UnderlyingAllocator::Contains(p));
        containingAlloc = m_MainAllocator;
    }

    oldSize = containingAlloc->UnderlyingAllocator::GetPtrSize(p);
    void* ptr = alloc->UnderlyingAllocator::Allocate(size, align);
    memcpy(ptr, p, std::min(size, oldSize));
    Deallocate(p);
    return ptr;
}

template<class UnderlyingAllocator>
bool DualThreadAllocator<UnderlyingAllocator>::TryDeallocate(void* p)
{
    // Try lockless allocator first
    if (m_BucketAllocator != NULL && m_BucketAllocator->BucketAllocator::TryDeallocate(p))
        return true;

    UnderlyingAllocator* alloc = GetCurrentAllocator();
    if (alloc->UnderlyingAllocator::TryDeallocate(p))
        return true;

    if (alloc == m_MainAllocator)
    {
        return m_ThreadAllocator->UnderlyingAllocator::TryDeallocate(p);
    }
    else
    {
        DebugAssert(m_MainAllocator->UnderlyingAllocator::Contains(p));
        if (!m_DelayedDeletion)
            CreateDelayedDeletionManager();

        m_DelayedDeletion->AddPointerToMainThreadDealloc(p);

        return true;
    }

    return false;
}

template<class UnderlyingAllocator>
bool DualThreadAllocator<UnderlyingAllocator>::Contains(const void* p) const
{
    if (m_BucketAllocator != NULL && m_BucketAllocator->BucketAllocator::Contains(p))
        return true;

    UnderlyingAllocator* alloc = GetCurrentAllocator();
    if (alloc->UnderlyingAllocator::Contains(p))
        return true;

    UnderlyingAllocator* altAlloc = (alloc == m_MainAllocator) ? m_ThreadAllocator : m_MainAllocator;
    return altAlloc->UnderlyingAllocator::Contains(p);
}

template<class UnderlyingAllocator>
size_t DualThreadAllocator<UnderlyingAllocator>::GetAllocatedMemorySize() const
{
    return m_MainAllocator->GetAllocatedMemorySize() + (m_ThreadAllocator ? m_ThreadAllocator->GetAllocatedMemorySize() : 0);
}

template<class UnderlyingAllocator>
size_t DualThreadAllocator<UnderlyingAllocator>::GetBookKeepingMemorySize() const
{
    return m_MainAllocator->GetBookKeepingMemorySize() + (m_ThreadAllocator ? m_ThreadAllocator->GetBookKeepingMemorySize() : 0);
}

template<class UnderlyingAllocator>
size_t DualThreadAllocator<UnderlyingAllocator>::GetReservedMemorySize() const
{
    return m_MainAllocator->GetReservedMemorySize() + (m_ThreadAllocator ? m_ThreadAllocator->GetReservedMemorySize() : 0);
}

template<class UnderlyingAllocator>
size_t DualThreadAllocator<UnderlyingAllocator>::GetPtrSize(const void* ptr) const
{
    size_t size = m_BucketAllocator != NULL ? m_BucketAllocator->BucketAllocator::GetPtrSize(ptr) : 0;
    if (size != 0)
        return size;

    // all allocators have the same allocation header
    return m_MainAllocator->UnderlyingAllocator::GetPtrSize(ptr);
}

template<class UnderlyingAllocator>
bool DualThreadAllocator<UnderlyingAllocator>::CheckIntegrity()
{
    // TODO: Check bucket allocator
    bool valid = m_ThreadAllocator->UnderlyingAllocator::CheckIntegrity();
    if (Thread::CurrentThreadIsMainThread())
        valid &= m_MainAllocator->UnderlyingAllocator::CheckIntegrity();
    Assert(valid);
    return valid;
}

#if USE_MEMORY_DEBUGGING || ENABLE_MEM_PROFILER

template<class UnderlyingAllocator>
ProfilerAllocationHeader* DualThreadAllocator<UnderlyingAllocator>::GetProfilerHeader(const void* ptr) const
{
#ifndef BUCKETALLOCATOR_USES_ALLOCATION_HEADER
    if (m_BucketAllocator != NULL && m_BucketAllocator->BucketAllocator::Contains(ptr))
        return NULL;
#endif // !BUCKETALLOCATOR_USES_ALLOCATION_HEADER

    // DualThreadAllocator uses BucketAllocator and DynamicHeapAllocator that have the same AllocationHeader
    const AllocationHeader* allocHeader = AllocationHeader::GetAllocationHeader(ptr);
    return allocHeader->GetProfilerHeader();
}

template<class UnderlyingAllocator>
size_t DualThreadAllocator<UnderlyingAllocator>::GetRequestedPtrSize(const void* ptr) const
{
#ifndef BUCKETALLOCATOR_USES_ALLOCATION_HEADER
    if (m_BucketAllocator != NULL)
    {
        size_t size = m_BucketAllocator->BucketAllocator::GetPtrSize(ptr);
        if (size != 0)
            return size;
    }
#endif // !BUCKETALLOCATOR_USES_ALLOCATION_HEADER

    // DualThreadAllocator uses BucketAllocator and DynamicHeapAllocator that have the same AllocationHeader
    const AllocationHeader* allocHeader = AllocationHeader::GetAllocationHeader(ptr);
    return allocHeader->GetAllocationSize();
}

template<class UnderlyingAllocator>
bool DualThreadAllocator<UnderlyingAllocator>::ValidateIntegrity(const void* ptr) const
{
#ifndef BUCKETALLOCATOR_USES_ALLOCATION_HEADER
    if (m_BucketAllocator != NULL && m_BucketAllocator->BucketAllocator::Contains(ptr))
        return true;
#endif // !BUCKETALLOCATOR_USES_ALLOCATION_HEADER

    // DualThreadAllocator uses BucketAllocator and DynamicHeapAllocator that have the same AllocationHeader
    const AllocationHeader* allocHeader = AllocationHeader::GetAllocationHeader(ptr);
#if USE_MEMORY_DEBUGGING
    UInt16 allocHeaderAllocatorIdentifier = allocHeader->GetAllocatorIdentifier();
    if ((allocHeaderAllocatorIdentifier != m_MainAllocator->GetAllocatorIdentifier()) &&
        (allocHeaderAllocatorIdentifier != m_ThreadAllocator->GetAllocatorIdentifier()) &&
        (m_BucketAllocator != NULL && allocHeaderAllocatorIdentifier != m_BucketAllocator->GetAllocatorIdentifier()))
        return false;
#endif
    return AllocationHeader::ValidateIntegrity(allocHeader->GetAllocationPtr(), -1);
}

#endif // USE_MEMORY_DEBUGGING || ENABLE_MEM_PROFILER

Mutex g_CreateDelayedDeletionManagerLock;
template<class UnderlyingAllocator>
void DualThreadAllocator<UnderlyingAllocator>::CreateDelayedDeletionManager()
{
    Mutex::AutoLock lock(g_CreateDelayedDeletionManagerLock);
    if (!m_DelayedDeletion)
    {
        SET_ALLOC_OWNER(NULL);
        m_DelayedDeletion = UNITY_NEW(DelayedPointerDeletionManager(m_MainAllocator, m_ThreadAllocator), kMemManager);
    }
}

template class DualThreadAllocator<DynamicHeapAllocator<LowLevelAllocator> >;

#endif // #if ENABLE_MEMORY_MANAGER
