#pragma once

#include "Runtime/Allocator/BaseAllocator.h"
#include "Runtime/Threads/Mutex.h"
#include "Runtime/Utilities/ReflectableEnum.h"

#define PLATFORM_SUPPORTS_DEBUG_ALLOCATOR (((UNITY_WIN && !UNITY_WINRT_8_1) || UNITY_POSIX) && UNITY_64)

/*  Protection results each allocation being placed on a separate memory page and
    the succeeding memory page being protected. As a result, the effective size of
    each allocation is one page. This results in excessive memory usage on mobiles.
    By protecting only large allocations this can be worked around.

    Negative value means all allocations are protected.
*/
#define DEBUG_ALLOCATOR_MINIMUM_MEMORY_SIZE_TO_PROTECT -1

#if ENABLE_MEMORY_MANAGER && PLATFORM_SUPPORTS_DEBUG_ALLOCATOR

struct DebugAllocatorHeader;

// Debug allocator for finding memory overwrites and deallocated memory access.
// All allocations are rounded up to a page size and 1 extra guard page is added.
// Allocation is aligned to the next guard page and the guard page is set protected.
// This allows us to detect buffer overruns.
//
// On deallocation it decommits memory and marks it as full protected.
// This allows us to detect access to deallocated memory.
//
// Very greedy allocator, but useful in x64 Editor where we have enough address space.
//
// Implemented for Windows and OSX for now. Could be used on x64 archs only as it needs huge address space available.
class DebugAllocator : public BaseAllocator
{
public:
    DebugAllocator(const char* name);

    virtual void*  Allocate(size_t size, int align);
    virtual void*  Reallocate(void* p, size_t size, int align);
    virtual void   Deallocate(void* p);
    virtual bool   Contains(const void* p) const;
    virtual size_t GetPtrSize(const void* ptr) const;

#if USE_MEMORY_DEBUGGING || ENABLE_MEM_PROFILER
    virtual ProfilerAllocationHeader* GetProfilerHeader(const void* ptr) const;
    virtual size_t GetRequestedPtrSize(const void* ptr) const;
    virtual bool   ValidateIntegrity(const void* ptr) const;
#endif // USE_MEMORY_DEBUGGING || ENABLE_MEM_PROFILER

    REFLECTABLE_ENUM(ProtectionMode,
        (NoProtection, 0)
            (WriteProtection, 1)
            (ReadWriteProtection, 2)
        );
    void SetBufferOverrunProtectionMode(ProtectionMode mode);

private:
    void RegisterAllocation(DebugAllocatorHeader* h);
    void RegisterDeallocation(DebugAllocatorHeader* h);

    void* VirtualPageAllocateAndProtect(size_t totalSizeWithGuardPage);
    static void VirtualPageDecommitAndProtect(void* ptr, size_t size);

    size_t m_PageSize;
    size_t m_AllocationGranularity;
    ProtectionMode m_ProtectionMode;
    Mutex m_AllocStatsMutex;
    volatile void* m_BasePtr;
};

#endif // ENABLE_MEMORY_MANAGER && PLATFORM_SUPPORTS_DEBUG_ALLOCATOR
