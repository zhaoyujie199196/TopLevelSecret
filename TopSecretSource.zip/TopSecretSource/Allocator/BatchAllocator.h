#pragma once
/*

Used to allocate multiple smaller allocations in batch.
Resulting in a single Allocation to the memory manager.
* AllocateRoot, Allocate and AllocateField only records allocate instructions.
* Allocations are performed only in commit.
(Thus you can't touch the allocated memory until Commit is called)

EXAMPLE:

BatchAllocator batch;

// Allocate a root (must always be the first allocation)
TransformHierarchy* hierarchy = NULL;
batch.AllocateRoot(hierarchy);

// Allocate fields.
// The ptr will be written into the allocated hierarchy, when Commit is called.
batch.AllocateField(hierarchy->localTransforms, transformCount);
batch.AllocateField(hierarchy->parentIndices, transformCount);

// Actually perform allocate the memory, and assign all recorded fields / roots etc
batch.Commit(kMemDefault);

// Deallocate the memory
BatchAllocator::DeallocateRoot(kMemDefault, hierarchy);

*/
#include "Runtime/Utilities/remove_const.h"

class BatchAllocator
{
public:
    BatchAllocator();

    void Commit(MemLabelRef label);

    // Allocates the root object
    template<class T>
    void AllocateRoot(T*& dstPtr, size_t count = 1, size_t alignment = 0);

    // Allocates a field (the ptr passed into this function must be relative to the root)
    template<class T>
    void AllocateField(T*& dstPtr, size_t count, size_t alignment = 0);
    void AllocateField(void*& dstPtr, size_t count, size_t alignment, size_t sizeOf);

    // Allocates an o
    template<class T>
    void Allocate(T*& dstPtr, size_t count, size_t alignment = 0);

    // Aligns the next allocation to the platform's cache line size.
    // Use to avoid false sharing between jobs.
    void PadToCacheLine();

    static void DeallocateRoot(MemLabelRef label, void* dstPtr) { UNITY_FREE(label, dstPtr); }

private:

    void AllocateInternal(void** dstPtr, SInt32 rootIndex, size_t elementSize, size_t count, size_t alignment);

    struct Allocation
    {
        SInt32  rootIndex;
        size_t  offset;
        size_t  size;
        void**  dstPtr;
    };

    enum { kMaxAllocationCount = 32 };

    size_t          m_BufferSize;
    size_t          m_AllocationCount;
    size_t          m_MaxAlignment;
    Allocation      m_Allocations[kMaxAllocationCount];
};

template<class T>
void BatchAllocator::AllocateRoot(T*& dstPtr, size_t count, size_t alignment)
{
    // NOTE: For now we assume that first allocation is root allocation
    // If we have use cases for multiple root allocations, then we need to genaralize this code a bit more...
    typedef typename core::remove_const<T>::type MutableT;
    MutableT *&dstPtrMutable = const_cast<MutableT *&>(dstPtr);
    Assert((void*)&dstPtr == (void*)&dstPtrMutable);

    Assert(m_AllocationCount == 0);
    alignment = (alignment != 0) ? alignment : ALIGN_OF(MutableT);

    AllocateInternal(reinterpret_cast<void**>(&dstPtrMutable), -1, sizeof(MutableT), count, alignment);

    dstPtrMutable = NULL;
}

template<class T>
void BatchAllocator::Allocate(T*& dstPtr, size_t count, size_t alignment)
{
    // NOTE: For now we assume that first allocation is root allocation
    // If we have use cases for multiple root allocations, then we need to genaralize this code a bit more...
    typedef typename core::remove_const<T>::type MutableT;
    MutableT *&dstPtrMutable = const_cast<MutableT *&>(dstPtr);
    Assert((void*)&dstPtr == (void*)&dstPtrMutable);

    Assert(m_AllocationCount >= 1);
    alignment = (alignment != 0) ? alignment : ALIGN_OF(MutableT);

    AllocateInternal(reinterpret_cast<void**>(&dstPtrMutable), -1, sizeof(MutableT), count, alignment);
}

template<class T>
void BatchAllocator::AllocateField(T*& dstPtr, size_t count, size_t alignment)
{
    // NOTE: For now we assume that first allocation is root allocation
    // If we have use cases for multiple root allocations, then we need to genaralize this code a bit more...
    Assert(m_AllocationCount >= 1);

    typedef typename core::remove_const<T>::type MutableT;
    MutableT *&dstPtrMutable = const_cast<MutableT *&>(dstPtr);
    Assert((void*)&dstPtr == (void*)&dstPtrMutable);

    alignment = (alignment != 0) ? alignment : ALIGN_OF(MutableT);

    AllocateInternal(reinterpret_cast<void**>(&dstPtrMutable), 0, sizeof(MutableT), count, alignment);
}

inline void BatchAllocator::AllocateField(void*& dstPtr, size_t count, size_t alignment, size_t sizeOf)
{
    // NOTE: For now we assume that first allocation is root allocation
    // If we have use cases for multiple root allocations, then we need to genaralize this code a bit more...
    Assert(m_AllocationCount >= 1);

    alignment = (alignment != 0) ? alignment : sizeOf;

    AllocateInternal(&dstPtr, 0, sizeOf, count, alignment);
}
