#include "UnityPrefix.h"
#include "Runtime/Allocator/BucketAllocator.h"

#if ENABLE_UNIT_TESTS && ENABLE_MEMORY_MANAGER && USE_BUCKET_ALLOCATOR

#include "Runtime/Testing/Testing.h"
#include "Runtime/Allocator/MemoryManager.h"
#include "Runtime/Threads/AtomicOps.h"
#include "Runtime/Threads/Thread.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Misc/SystemInfo.h"

// When doing any changes you have to run the stress test over night and it has to succeed.
// Do not commit BUCKET_ENABLE_STRESS_TEST 1 because it will take several hours to run.
#define BUCKET_ENABLE_STRESS_TEST 0

#if BUCKET_ENABLE_STRESS_TEST
#define ITER (1 << 4)
#else
#define ITER (1 << 0)
#endif

UNIT_TEST_SUITE(BucketAllocatorTests)
{
    TEST(Test_AllocateDeallocate)
    {
        BucketAllocator* testAlloc = UNITY_NEW(BucketAllocator, kMemDefault)("TestAlloc", 16, 4, 32 * 1024 * 1024, 1);

        void* ptr;
        ptr = testAlloc->Allocate(1, kDefaultMemoryAlignment);
        CHECK(ptr != NULL);
        CHECK(testAlloc->GetAllocatedMemorySize() == 16);
        CHECK(testAlloc->TryDeallocate(ptr));
        CHECK(testAlloc->GetAllocatedMemorySize() == 0);

        ptr = testAlloc->Allocate(17, kDefaultMemoryAlignment);
        CHECK(ptr != NULL);
        CHECK(testAlloc->GetAllocatedMemorySize() == 32);
        CHECK(testAlloc->TryDeallocate(ptr));
        CHECK(testAlloc->GetAllocatedMemorySize() == 0);

        ptr = testAlloc->Allocate(40, kDefaultMemoryAlignment);
        CHECK(ptr != NULL);
        CHECK(testAlloc->GetAllocatedMemorySize() == 48);
        CHECK(testAlloc->TryDeallocate(ptr));
        CHECK(testAlloc->GetAllocatedMemorySize() == 0);

        ptr = testAlloc->Allocate(64, kDefaultMemoryAlignment);
        CHECK(ptr != NULL);
        CHECK(testAlloc->GetAllocatedMemorySize() == 64);
        CHECK(testAlloc->TryDeallocate(ptr));
        CHECK(testAlloc->GetAllocatedMemorySize() == 0);

        ptr = testAlloc->Allocate(80, kDefaultMemoryAlignment);
        CHECK(ptr == NULL);
        CHECK(!testAlloc->TryDeallocate(ptr));

        UNITY_DELETE(testAlloc, kMemDefault);
    }

    TEST(Test_Alignment)
    {
        BucketAllocator* testAlloc = UNITY_NEW(BucketAllocator, kMemDefault)("TestAlloc", 16, 4, 32 * 1024 * 1024, 1);

        void* ptr;
        ptr = testAlloc->Allocate(1, 2);
        CHECK_EQUAL(ptr, AlignPtr(ptr, 2));

        ptr = testAlloc->Allocate(1, 4);
        CHECK_EQUAL(ptr, AlignPtr(ptr, 4));

        ptr = testAlloc->Allocate(1, 8);
        CHECK_EQUAL(ptr, AlignPtr(ptr, 8));

        ptr = testAlloc->Allocate(1, 16);
        CHECK_EQUAL(ptr, AlignPtr(ptr, 16));

        UNITY_DELETE(testAlloc, kMemDefault);
    }
}

STRESS_TEST_SUITE(BucketAllocatorStressTests)
{
    struct BucketAllocatorFixture
    {
        BucketAllocatorFixture()
        {
        }

        ~BucketAllocatorFixture()
        {
        }

        static void* AllocTestFunc(void *p)
        {
            BaseAllocator* testAlloc = static_cast<BaseAllocator*>(p);

            // We use up to 32 blocks of 1MB size for each allocation size.
            // So on 8 threads we can safely do the following number of allocations:
#if BUCKET_ENABLE_STRESS_TEST
            const int kProbeAllocationsCount[] = { 256 * 1024, 128 * 1024, 87380, 64 * 1024 };
#else
            const int kProbeAllocationsCount[] = { 8 * 1024, 8 * 1024, 8 * 1024, 8 * 1024 };
#endif
            const int kProbeSizes[] = { 16, 32, 48, 64 };
            const int kProbeSizesCount = sizeof(kProbeSizes) / sizeof(kProbeSizes[0]);

            dynamic_array<void*> allocations[kProbeSizesCount];
            for (int i = 0; i < kProbeSizesCount; ++i)
                allocations[i].resize_uninitialized(kProbeAllocationsCount[i]);

            for (int retries = 0; retries < ITER; ++retries)
            {
                // Allocate memory
                for (int i = 0; i < kProbeSizesCount; ++i)
                {
                    for (int j = 0; j < kProbeAllocationsCount[i]; ++j)
                    {
                        allocations[i][j] = testAlloc->Allocate(kProbeSizes[i], kDefaultMemoryAlignment);
                        *((int*)allocations[i][j]) = i * j;
                    }
                }

                // Deallocate it
                for (int i = 0; i < kProbeSizesCount; ++i)
                {
                    for (int j = 0; j < kProbeAllocationsCount[i]; ++j)
                    {
                        CHECK(*((int*)allocations[i][j]) == i * j);
                        testAlloc->Deallocate(allocations[i][j]);
                    }
                }
            }

            return NULL;
        }

        void RunAllocatorTest(BaseAllocator* allocator)
        {
            size_t oldAllocatedBytes = allocator->GetAllocatedMemorySize();

            int startProcessor = -1;
            int workerThreads = systeminfo::GetPhysicalProcessorCount();

            Thread* threads = new Thread[workerThreads];

            for (int i = 0; i < workerThreads; ++i)
            {
                threads[i].Run(&AllocTestFunc, (void*)allocator, DEFAULT_UNITY_THREAD_STACK_SIZE, startProcessor);
                if (startProcessor >= 0)
                {
                    ++startProcessor;
                }
            }

            for (int i = 0; i < workerThreads; ++i)
            {
                threads[i].WaitForExit(false);
            }
            delete[] threads;

            CHECK_EQUAL(oldAllocatedBytes, allocator->GetAllocatedMemorySize());
        }
    };

    TEST_FIXTURE(BucketAllocatorFixture, Test_AllocateDeallocateSequential)
    {
        BucketAllocator* testAlloc = UNITY_NEW(BucketAllocator, kMemDefault)("TestAlloc", 16, 4, 64 * 1024 * 1024, 8);

        int workerThreads = systeminfo::GetProcessorCount();
        for (int i = 0; i < workerThreads; ++i)
        {
            AllocTestFunc(testAlloc);
        }

        UNITY_DELETE(testAlloc, kMemDefault);
    }

    TEST_FIXTURE(BucketAllocatorFixture, Test_DefaultAllocateDeallocateSequential)
    {
        int workerThreads = systeminfo::GetProcessorCount();
        for (int i = 0; i < workerThreads; ++i)
        {
            AllocTestFunc(GetMemoryManager().GetAllocator(kMemDefault));
        }
    }

    TEST_FIXTURE(BucketAllocatorFixture, Test_AllocateDeallocateConcurrent)
    {
        BucketAllocator* testAlloc = UNITY_NEW(BucketAllocator, kMemDefault)("TestAlloc", 16, 4, 64 * 1024 * 1024, 8);

        RunAllocatorTest(testAlloc);

        UNITY_DELETE(testAlloc, kMemDefault);
    }

    TEST_FIXTURE(BucketAllocatorFixture, Test_DefaultAllocateDeallocateConcurrent)
    {
        RunAllocatorTest(GetMemoryManager().GetAllocator(kMemDefault));
    }
}

#undef BUCKET_ENABLE_STRESS_TEST

#endif // ENABLE_UNIT_TESTS && ENABLE_MEMORY_MANAGER && USE_BUCKET_ALLOCATOR
