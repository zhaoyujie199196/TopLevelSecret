#include "UnityPrefix.h"
#include "Runtime/Allocator/StackAllocator.h"

#if ENABLE_UNIT_TESTS

#include "Runtime/Testing/Testing.h"
#include "Runtime/Allocator/MemoryManager.h"

UNIT_TEST_SUITE(StackAllocatorTests)
{
    struct StackAllocatorFixture
    {
        StackAllocatorFixture()
        {
            m_Allocator = UNITY_NEW(StackAllocator, kMemDefault)(512, kMemTempOverflow, "m_Allocator");
        }

        ~StackAllocatorFixture()
        {
            UNITY_DELETE(m_Allocator, kMemDefault);
        }

        StackAllocator* m_Allocator;
    };

    TEST_FIXTURE(StackAllocatorFixture, AllocateDeallocate_AllocationsSucceed)
    {
        void* ptr;
        ptr = m_Allocator->Allocate(1, kDefaultMemoryAlignment);
        CHECK(ptr != NULL);
        CHECK_EQUAL(1, m_Allocator->GetAllocatedMemorySize());
        CHECK(m_Allocator->TryDeallocate(ptr));
        CHECK_EQUAL(0, m_Allocator->GetAllocatedMemorySize());

        ptr = m_Allocator->Allocate(17, kDefaultMemoryAlignment);
        CHECK(ptr != NULL);
        CHECK_EQUAL(17, m_Allocator->GetAllocatedMemorySize());
        CHECK(m_Allocator->TryDeallocate(ptr));
        CHECK_EQUAL(0, m_Allocator->GetAllocatedMemorySize());

        ptr = m_Allocator->Allocate(40, kDefaultMemoryAlignment);
        CHECK(ptr != NULL);
        CHECK_EQUAL(40, m_Allocator->GetAllocatedMemorySize());
        CHECK(m_Allocator->TryDeallocate(ptr));
        CHECK_EQUAL(0, m_Allocator->GetAllocatedMemorySize());

        ptr = m_Allocator->Allocate(64, kDefaultMemoryAlignment);
        CHECK(ptr != NULL);
        CHECK_EQUAL(64, m_Allocator->GetAllocatedMemorySize());
        CHECK(m_Allocator->TryDeallocate(ptr));
        CHECK_EQUAL(0, m_Allocator->GetAllocatedMemorySize());
    }

    TEST_FIXTURE(StackAllocatorFixture, AlignedAllocate_IsAligned)
    {
        void* ptr;
        ptr = m_Allocator->Allocate(1, 2);
        CHECK_EQUAL(ptr, AlignPtr(ptr, 2));
        CHECK(m_Allocator->TryDeallocate(ptr));

        ptr = m_Allocator->Allocate(1, 4);
        CHECK_EQUAL(ptr, AlignPtr(ptr, 4));
        CHECK(m_Allocator->TryDeallocate(ptr));

        ptr = m_Allocator->Allocate(1, 8);
        CHECK_EQUAL(ptr, AlignPtr(ptr, 8));
        CHECK(m_Allocator->TryDeallocate(ptr));

        ptr = m_Allocator->Allocate(1, 16);
        CHECK_EQUAL(ptr, AlignPtr(ptr, 16));
        CHECK(m_Allocator->TryDeallocate(ptr));
    }

    TEST_FIXTURE(StackAllocatorFixture, OverflowAllocation_GoesToHeap)
    {
        void* ptr;
        ptr = m_Allocator->Allocate(200, kDefaultMemoryAlignment);
        CHECK(ptr != NULL);
        CHECK(m_Allocator->Contains(ptr));
        CHECK_EQUAL(m_Allocator->GetAllocatedMemorySize(), 200);

        ptr = m_Allocator->Allocate(200, kDefaultMemoryAlignment);
        CHECK(ptr != NULL);
        CHECK(m_Allocator->Contains(ptr));
        CHECK_EQUAL(m_Allocator->GetAllocatedMemorySize(), 400);

        // this will fail to allocate within the stack, and will overflow to the heap
        // invisibly, still be reported contained and the overall size as expected
        ptr = m_Allocator->Allocate(200, kDefaultMemoryAlignment);
        CHECK(ptr != NULL);
        CHECK(m_Allocator->Contains(ptr));
        CHECK_EQUAL(m_Allocator->GetAllocatedMemorySize(), 400);

        m_Allocator->Deallocate(ptr);

        CHECK_EQUAL(m_Allocator->GetAllocatedMemorySize(), 400);

        m_Allocator->FreeAllAllocations();
    }

    // The following tests fail on 32-bit due to the allocator not accounting for padding in the
    // reported book-keeping size. This would be fixable in the allocator but would come at a performance
    // cost of looking at prevPtr to calculate the padding on allocate/deallocate.
    // Instead, since these tests are not testing anything specific to 32-bit or 64-bit and since 64-bit
    // is run more commonly so it will find failures quickly, we disable these tests on 32-bit runs.
#if UNITY_64
    TEST_FIXTURE(StackAllocatorFixture, FreeAllAllocations_ClearsAllActiveStackAllocations)
    {
        void* ptr;
        ptr = m_Allocator->Allocate(16, kDefaultMemoryAlignment);
        CHECK_EQUAL(32, m_Allocator->GetAllocatedMemorySize() + m_Allocator->GetBookKeepingMemorySize());
        CHECK_EQUAL(32, m_Allocator->GetUsedStackSize());

        void* middle = m_Allocator->Allocate(16, kDefaultMemoryAlignment);
        CHECK_EQUAL(64, m_Allocator->GetAllocatedMemorySize() + m_Allocator->GetBookKeepingMemorySize());
        CHECK_EQUAL(64, m_Allocator->GetUsedStackSize());

        ptr = m_Allocator->Allocate(16, kDefaultMemoryAlignment);
        CHECK_EQUAL(96, m_Allocator->GetAllocatedMemorySize() + m_Allocator->GetBookKeepingMemorySize());
        CHECK_EQUAL(96, m_Allocator->GetUsedStackSize());

        CHECK(m_Allocator->TryDeallocate(middle));

        // memory has been 'freed' but still in use on the stack.
        CHECK_EQUAL(64, m_Allocator->GetAllocatedMemorySize() + m_Allocator->GetBookKeepingMemorySize());
        CHECK_EQUAL(96, m_Allocator->GetUsedStackSize());

        m_Allocator->FreeAllAllocations();

        // everything has now been wiped out to a clean slate
        CHECK_EQUAL(0, m_Allocator->GetAllocatedMemorySize());
        CHECK_EQUAL(0, m_Allocator->GetUsedStackSize());

        ptr = m_Allocator->Allocate(16, kDefaultMemoryAlignment);
        CHECK_EQUAL(32, m_Allocator->GetAllocatedMemorySize() + m_Allocator->GetBookKeepingMemorySize());
        CHECK_EQUAL(32, m_Allocator->GetUsedStackSize());

        CHECK(m_Allocator->TryDeallocate(ptr));
        CHECK_EQUAL(0, m_Allocator->GetAllocatedMemorySize());
        CHECK_EQUAL(0, m_Allocator->GetUsedStackSize());
    }

    TEST_FIXTURE(StackAllocatorFixture, FreeAllAllocations_LeakHeapAllocation_PrintsError)
    {
        void* ptr;
        ptr = m_Allocator->Allocate(16, kDefaultMemoryAlignment);
        CHECK_EQUAL(32, m_Allocator->GetAllocatedMemorySize() + m_Allocator->GetBookKeepingMemorySize());
        CHECK_EQUAL(32, m_Allocator->GetUsedStackSize());

        ptr = m_Allocator->Allocate(16, kDefaultMemoryAlignment);
        CHECK_EQUAL(64, m_Allocator->GetAllocatedMemorySize() + m_Allocator->GetBookKeepingMemorySize());
        CHECK_EQUAL(64, m_Allocator->GetUsedStackSize());

        ptr = m_Allocator->Allocate(16, kDefaultMemoryAlignment);
        CHECK_EQUAL(96, m_Allocator->GetAllocatedMemorySize() + m_Allocator->GetBookKeepingMemorySize());
        CHECK_EQUAL(96, m_Allocator->GetUsedStackSize());

        // this allocation will fall outside of the stack
        void* heapAlloc;
        heapAlloc = m_Allocator->Allocate(512, kDefaultMemoryAlignment);
        CHECK_EQUAL(96, m_Allocator->GetAllocatedMemorySize() + m_Allocator->GetBookKeepingMemorySize());
        CHECK_EQUAL(96, m_Allocator->GetUsedStackSize());

        m_Allocator->FreeAllAllocations();

        CHECK(m_Allocator->TryDeallocate(heapAlloc));
    }

    TEST_FIXTURE(StackAllocatorFixture, DeallocationMidStack_StackUsageIsUnchanged)
    {
        void* a = m_Allocator->Allocate(16, kDefaultMemoryAlignment);
        void* b = m_Allocator->Allocate(16, kDefaultMemoryAlignment);
        void* c = m_Allocator->Allocate(16, kDefaultMemoryAlignment);
        void* d = m_Allocator->Allocate(16, kDefaultMemoryAlignment);

        CHECK(a != NULL && b != NULL && c != NULL && d != NULL);
        CHECK_EQUAL(128, m_Allocator->GetAllocatedMemorySize() + m_Allocator->GetBookKeepingMemorySize());
        CHECK_EQUAL(128, m_Allocator->GetUsedStackSize());

        CHECK(m_Allocator->TryDeallocate(b));
        CHECK_EQUAL(96, m_Allocator->GetAllocatedMemorySize() + m_Allocator->GetBookKeepingMemorySize());
        CHECK_EQUAL(128, m_Allocator->GetUsedStackSize());

        CHECK(m_Allocator->TryDeallocate(c));
        CHECK_EQUAL(64, m_Allocator->GetAllocatedMemorySize() + m_Allocator->GetBookKeepingMemorySize());
        CHECK_EQUAL(128, m_Allocator->GetUsedStackSize());

        CHECK(m_Allocator->TryDeallocate(d));
        CHECK_EQUAL(32, m_Allocator->GetAllocatedMemorySize() + m_Allocator->GetBookKeepingMemorySize());
        CHECK_EQUAL(32, m_Allocator->GetUsedStackSize());

        CHECK(m_Allocator->TryDeallocate(a));
        CHECK_EQUAL(0, m_Allocator->GetAllocatedMemorySize());
        CHECK_EQUAL(0, m_Allocator->GetUsedStackSize());
    }
#endif // UNITY_64
}

#endif // ENABLE_UNIT_TESTS
