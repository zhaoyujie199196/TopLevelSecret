#pragma once

#include "Runtime/AssetBundles/AssetBundleLoadFromStreamAsyncOperation.h"

#if ENABLE_CACHING

/// AssetBundleCreateOperation which fetches data from a cache and supports feeding.
/// Used for WWW backward compatibility.
class AssetBundleLoadFromCacheAsyncOperation : public AssetBundleLoadFromStreamAsyncOperation
{
public:
    AssetBundleLoadFromCacheAsyncOperation(const core::string& assetBundleName);
    virtual ~AssetBundleLoadFromCacheAsyncOperation();

    void SetCacheHash(const Hash128& hash) { m_CacheHash = hash; }
    void SetCacheUrl(const core::string& url) { m_Url = url; }

    void Execute();
    void ExecuteSynchronously();

private:
    static void LoadCachedArchiveJob(AssetBundleLoadFromCacheAsyncOperation* this_);

    Hash128 m_CacheHash;
    core::string m_Url;
};

#endif // ENABLE_CACHING
