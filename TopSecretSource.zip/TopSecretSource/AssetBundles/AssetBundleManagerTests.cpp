#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS && SUPPORT_THREADS

#include "Runtime/AssetBundles/AssetBundleManager.h"
#include "Runtime/BaseClasses/GameObject.h"
#include "Runtime/Threads/Semaphore.h"
#include "Runtime/Testing/Testing.h"
#include "Runtime/Testing/TestFixtures.h"
#include "Runtime/Mono/MonoScript.h"
#include "Runtime/Testing/Faking.h"
#include "Runtime/Testing/FakingScripts.h"
#include "Runtime/Serialize/PersistentManager.h"
#include "Runtime/BaseClasses/TypeInfo.h"
#include <map>

#if !UNITY_XBOXONE

STRESS_TEST_SUITE(AssetBundleManagerTests)
{
    TEST(RegisterAndUnloadAssetBundle_FromMultipleThreads_DoesNotCrash, TestAttributes::KnownFailure(853595, "Disabled because it triggers assert in debug builds."))
    {
        const int kNumAssetBundles = 100;
        const int kNumTestRuns = 10;

        struct ThreadFuncWrapper
        {
            struct Input
            {
                Semaphore* semaphore;
                volatile bool requestStop;
            };

            static void* ThreadFunc(void* userData)
            {
                std::vector<ConstantString> dependencies;
                dependencies.push_back(ConstantString("Blahblah", kMemString));

                dynamic_array<InstanceID> preloadObjs; preloadObjs.push_back(InstanceID_Make(100));

                Input* inp = reinterpret_cast<Input*>(userData);
                inp->semaphore->Signal();

                do
                {
                    ////FIXME: this has to be called on the main thread; will trigger assert
                    GetAssetBundleManager().CollectPreloadDataDependencies(NULL, dependencies, preloadObjs, false);
                }
                while (!inp->requestStop);
                return NULL;
            }
        };

        Thread collectDataThread;

        for (int i = 0; i < kNumTestRuns; ++i)
        {
            Semaphore evt;

            ThreadFuncWrapper::Input inputData;
            inputData.semaphore = &evt;
            inputData.requestStop = false;

            collectDataThread.Run(ThreadFuncWrapper::ThreadFunc, &inputData);
            evt.WaitForSignal();

            dynamic_array<AssetBundle*> assetBundles;

            for (int i = 0; i < kNumAssetBundles; ++i)
            {
                AssetBundle* assetBundle = CreateObjectFromCode<AssetBundle>();
                assetBundle->m_AssetBundleName = ("TestAssetBundle" + IntToString(i)).c_str();
                assetBundles.push_back(assetBundle);

                GetAssetBundleManager().RegisterAssetBundle(assetBundles[i]);
            }

            for (int i = 0; i < kNumAssetBundles; ++i)
            {
                GetAssetBundleManager().UnloadAssetBundle(assetBundles[i]);
                DestroySingleObject(assetBundles[i]);
            }

            inputData.requestStop = true;

            collectDataThread.WaitForExit();
        }
    }
}
#endif

#if ENABLE_UNIT_TESTS_WITH_FAKES

static void HideObject(Object* obj)
{
    Object::GetIDToPointerMapInternal()[obj->GetInstanceID()] = NULL;
}

static void ShowObject(Object* obj)
{
    Object::GetIDToPointerMapInternal()[obj->GetInstanceID()] = obj;
}

class FakeBundle
{
public:
    FakeBundle(core::string name)
    {
        bundle = CreateObjectFromCode<AssetBundle>();
        bundle->m_AssetBundleName = name.c_str();
        GetAssetBundleManager().RegisterAssetBundle(bundle);
    }

    ~FakeBundle()
    {
        GetAssetBundleManager().UnloadAssetBundle(bundle);
        DestroySingleObject(bundle);
        for (int i = 0; i < mInfos.size(); i++)
            delete mInfos[i];
        mInfos.clear();
        for (int i = 0; i < mObjects.size(); i++)
            DestroySingleObject(mObjects[i]);
        mObjects.clear();
    }

    AssetBundle *bundle;
    dynamic_array<AssetBundle::AssetInfo*> mInfos;
    dynamic_array<Object*> mObjects;
    void AddDependency(FakeBundle *depBundle)
    {
        bundle->m_Dependencies.push_back(depBundle->bundle->m_AssetBundleName);
    }

    void AddPreloads(InstanceID objectId, dynamic_array<InstanceID> preloads)
    {
        AssetBundle::AssetInfo *info = new AssetBundle::AssetInfo();
        mInfos.push_back(info);
        info->preloadIndex = bundle->m_PreloadTable.size();
        info->preloadSize = preloads.size();
        for (int i = 0; i < preloads.size(); i++)
            bundle->m_PreloadTable.push_back(PPtr<Object>(preloads[i]));
        bundle->m_AssetLookupContainer.insert(std::make_pair(objectId, info));
    }

    void AddPreloads(InstanceID objectId, InstanceID id1, InstanceID id2 = InstanceID_None, InstanceID id3 = InstanceID_None, InstanceID id4 = InstanceID_None)
    {
        InstanceID ids[] = { id1, id2, id3, id4 };
        dynamic_array<InstanceID> list;
        for (int i = 0; i < 4; i++)
            if (ids[i] != InstanceID_None)
                list.push_back(ids[i]);
        AddPreloads(objectId, list);
    }

    template<typename T> T* CreateObject()
    {
        T *obj = CreateObjectFromCode<T>(kDidLoadThreaded);
        mObjects.push_back(obj);
        GetPersistentManager().MakeObjectPersistent(obj->GetInstanceID(), bundle->m_AssetBundleName.c_str());
        return obj;
    }

    void HideObjects()
    {
        for (int i = 0; i < mObjects.size(); i++)
            HideObject(mObjects[i]);
    }

    void ShowObjects()
    {
        for (int i = 0; i < mObjects.size(); i++)
            ShowObject(mObjects[i]);
    }
};

struct BaseFixture
{
    FAKE_METHOD(PersistentManager, GetSerializedTypeAndIdentifierInternal, void(InstanceID, const Unity::Type * &, SerializedObjectIdentifier&));

    BaseFixture()
    {
        PersistentManager_GetSerializedTypeAndIdentifierInternal.Calls(this, &BaseFixture::GetSerializedTypeAndIdentifierInternalImpl);
    }

    ~BaseFixture()
    {
        for (int i = 0; i < mBundles.size(); i++)
            delete mBundles[i];
        mBundles.clear();
    }

    void GetSerializedTypeAndIdentifierInternalImpl(PersistentManager *pm, InstanceID instanceID, const Unity::Type*& type, SerializedObjectIdentifier& identifier)
    {
        pm->InstanceIDToSerializedObjectIdentifier(instanceID, identifier);
        if (mTypeMap.find(instanceID) != mTypeMap.end())
            type = mTypeMap[instanceID];
    }

    template<typename T> T* CreateObject(FakeBundle *bundle)
    {
        T *obj = bundle->CreateObject<T>();
        mTypeMap[obj->GetInstanceID()] = obj->GetType();
        return obj;
    }

    FakeBundle *CreateFakeBundle(core::string bundleName)
    {
        FakeBundle *bundle = new FakeBundle(bundleName);
        mBundles.push_back(bundle);
        return bundle;
    }

    void HideAllObjects()
    {
        for (int i = 0; i < mBundles.size(); i++)
            mBundles[i]->HideObjects();
    }

    void ShowAllObjects()
    {
        for (int i = 0; i < mBundles.size(); i++)
            mBundles[i]->ShowObjects();
    }

    void CollectPreloadDataDependencies(PPtr<AssetBundle> bundlePPtr, dynamic_array<InstanceID>& preloadObjects, bool scriptsOnly)
    {
        HideAllObjects();
        GetAssetBundleManager().CollectPreloadDataDependencies(bundlePPtr, preloadObjects, scriptsOnly);
        ShowAllObjects();
    }

    std::map<InstanceID, const Unity::Type *> mTypeMap;
    dynamic_array<FakeBundle*> mBundles;
};

static const int kObjectPairCreationCount = 10;
struct TwoBundleWithScriptsFixture : BaseFixture
{
    dynamic_array<InstanceID> mPreloadObjects;
    TwoBundleWithScriptsFixture()
    {
        FakeBundle *bundle1 = CreateFakeBundle("Bundle1");
        FakeBundle *bundle2 = CreateFakeBundle("Bundle2");
        bundle1->AddDependency(bundle2);

        for (int i = 0; i < kObjectPairCreationCount; i++)
        {
            GameObject *gameObject = CreateObject<GameObject>(bundle1);
            MonoScript *script = CreateObject<MonoScript>((i % 2) ? bundle1 : bundle2); // put some in bundle 1 and some in bundle 2
            mPreloadObjects.push_back(gameObject->GetInstanceID());
            bundle1->AddPreloads(gameObject->GetInstanceID(), script->GetInstanceID());
        }
    }
};

// Should be sorted in the order of: MonoScript, SerializedFileIndex, LocalIdentifierInFile
static void CheckSorted(dynamic_array<InstanceID> &list)
{
    if (list.empty())
        return;

    SerializedObjectIdentifier lastId, curId;
    Object *obj = PPtr<Object>(list[0]);
    bool lastMonoScript = obj->GetType() == WeakTypeOf<MonoScript>();
    GetPersistentManager().InstanceIDToSerializedObjectIdentifier(list[0], lastId);

    for (int i = 1; i < list.size(); i++)
    {
        obj = PPtr<Object>(list[i]);
        bool monoScript = obj->GetType() == WeakTypeOf<MonoScript>();
        GetPersistentManager().InstanceIDToSerializedObjectIdentifier(list[i], curId);

        if (monoScript != lastMonoScript)
            CHECK(!monoScript && lastMonoScript);
        else if (curId.serializedFileIndex != lastId.serializedFileIndex)
            CHECK(curId.serializedFileIndex > lastId.serializedFileIndex);
        else
            CHECK(curId.localIdentifierInFile > lastId.localIdentifierInFile);

        lastId = curId;
        lastMonoScript = monoScript;
    }
}

UNIT_TEST_SUITE(AssetBundleManagerCollectPreloadDependencies)
{
    TEST_FIXTURE(BaseFixture, PrefabWithReferencesInMultipleBundles_CollectsAllPreloadIds)
    {
        FakeBundle *bundle1 = CreateFakeBundle("Bundle1");
        FakeBundle *bundle2 = CreateFakeBundle("Bundle2");
        FakeBundle *bundle3 = CreateFakeBundle("Bundle3");

        bundle1->AddDependency(bundle2);
        bundle1->AddDependency(bundle3);

        GameObject *prefab1 = CreateObject<GameObject>(bundle1);
        GameObject *prefab2 = CreateObject<GameObject>(bundle2);
        GameObject *prefab2Obj1 = CreateObject<GameObject>(bundle2);
        GameObject *prefab3 = CreateObject<GameObject>(bundle3);
        GameObject *prefab3Obj1 = CreateObject<GameObject>(bundle3);

        bundle1->AddPreloads(prefab1->GetInstanceID(), prefab2->GetInstanceID(), prefab3->GetInstanceID());
        bundle1->AddPreloads(prefab2->GetInstanceID(), prefab2Obj1->GetInstanceID());
        bundle1->AddPreloads(prefab3->GetInstanceID(), prefab3Obj1->GetInstanceID());

        dynamic_array<InstanceID> preloadObjects;
        preloadObjects.push_back(prefab1->GetInstanceID());

        CollectPreloadDataDependencies(PPtr<AssetBundle>(bundle1->bundle->GetInstanceID()), preloadObjects, false);

        CheckSorted(preloadObjects);
        CHECK_CONTAINS(preloadObjects.begin(), preloadObjects.end(), prefab1->GetInstanceID());
        CHECK_CONTAINS(preloadObjects.begin(), preloadObjects.end(), prefab2->GetInstanceID());
        CHECK_CONTAINS(preloadObjects.begin(), preloadObjects.end(), prefab3->GetInstanceID());
        CHECK_CONTAINS(preloadObjects.begin(), preloadObjects.end(), prefab2Obj1->GetInstanceID());
        CHECK_CONTAINS(preloadObjects.begin(), preloadObjects.end(), prefab3Obj1->GetInstanceID());
    }

    TEST_FIXTURE(TwoBundleWithScriptsFixture, MultiplePreloadResults_ReturnsSortsIDs)
    {
        CollectPreloadDataDependencies(PPtr<AssetBundle>(mBundles[0]->bundle->GetInstanceID()), mPreloadObjects, false);

        CheckSorted(mPreloadObjects);
        CHECK_EQUAL(kObjectPairCreationCount * 2, mPreloadObjects.size());
    }

    TEST_FIXTURE(TwoBundleWithScriptsFixture, WhenScriptOnlyFlagSet_ReturnsOnlyScripts)
    {
        CollectPreloadDataDependencies(PPtr<AssetBundle>(mBundles[0]->bundle->GetInstanceID()), mPreloadObjects, true);

        CheckSorted(mPreloadObjects);
        CHECK_EQUAL(kObjectPairCreationCount, mPreloadObjects.size());
    }

    TEST_FIXTURE(BaseFixture, PreloadObjectDependencyIsAlreadyLoaded_IncludeItButNotChildDependencies)
    {
        // preload refernece chain prefab1(unloaded) -> prefab2(loaded) -> prefab3(unloaded)
        FakeBundle *bundle1 = CreateFakeBundle("Bundle1");
        GameObject *prefab1 = CreateObject<GameObject>(bundle1);
        GameObject *prefab2 = CreateObject<GameObject>(bundle1);
        GameObject *prefab3 = CreateObject<GameObject>(bundle1);
        bundle1->AddPreloads(prefab1->GetInstanceID(), prefab2->GetInstanceID());
        bundle1->AddPreloads(prefab2->GetInstanceID(), prefab3->GetInstanceID());

        dynamic_array<InstanceID> preloadObjects;
        preloadObjects.push_back(prefab1->GetInstanceID());

        HideObject(prefab1);
        HideObject(prefab3);

        PPtr<AssetBundle> bundlePPtr = PPtr<AssetBundle>(bundle1->bundle);
        GetAssetBundleManager().CollectPreloadDataDependencies(bundlePPtr, preloadObjects, false);

        ShowObject(prefab1);
        ShowObject(prefab3);

        bool containsObject3 = false;
        for (int i = 0; i < preloadObjects.size(); i++)
            containsObject3 |= (preloadObjects[i] == prefab3->GetInstanceID());

        CheckSorted(preloadObjects);
        CHECK_CONTAINS(preloadObjects.begin(), preloadObjects.end(), prefab1->GetInstanceID());
        CHECK_CONTAINS(preloadObjects.begin(), preloadObjects.end(), prefab2->GetInstanceID());
        CHECK_EQUAL(false, containsObject3);
    }
}

REGRESSION_TEST_SUITE(AssetBundleManagerCollectPreloadDependenciesRegression)
{
    // Case 879105: Stack overflow on long chains
    TEST_FIXTURE(BaseFixture, WhenLongChainOfBundleDependencies_DoesNotStackOverflow)
    {
        const int kBundleRecurisiveDepth = 5 * 1024;
        FakeBundle *prevBundle = NULL;
        GameObject *prevObj = NULL;
        dynamic_array<InstanceID> preloadObjects;

        for (int i = 0; i < kBundleRecurisiveDepth; i++)
        {
            FakeBundle *bundle = CreateFakeBundle(FormatString("bundle%d", i));
            GameObject *obj = CreateObject<GameObject>(bundle);

            if (i == 0)
                preloadObjects.push_back(obj->GetInstanceID());

            if (prevObj != NULL)
            {
                prevBundle->AddPreloads(prevObj->GetInstanceID(), obj->GetInstanceID());
                prevBundle->AddDependency(bundle);
            }
            prevObj = obj;
            prevBundle = bundle;
        }

        CollectPreloadDataDependencies(PPtr<AssetBundle>(mBundles[0]->bundle->GetInstanceID()), preloadObjects, false);
        CheckSorted(preloadObjects);
        CHECK_EQUAL(kBundleRecurisiveDepth, preloadObjects.size());
    }
}

#endif // #if ENABLE_UNIT_TESTS_WITH_FAKES
#endif // #if ENABLE_UNIT_TESTS
