#ifndef ASSETBUNDLEUTILITY_H
#define ASSETBUNDLEUTILITY_H

#include "Runtime/PreloadManager/PreloadManager.h"
#include "Runtime/AssetBundles/AssetBundle.h"
#include "Runtime/Utilities/PathNameUtility.h"

#if ENABLE_WWW
class WWW;
AssetBundle* ExtractAssetBundle(WWW &www);
#endif

void UnloadAssetBundleFileStreams(const std::vector<core::string>& fileStreams);

/// Return true if the given asset bundle can be used with the current player.
/// If not, "error" will be set to a description of why the bundle cannot be used.
/// The given "bundleName" is only used for printing more informative error
/// messages.
bool TestAssetBundleCompatibility(AssetBundle& bundle, const core::string& bundleName, core::string& error);
bool TestAssetBundleCompatibility(const core::string& bundlePath, const core::string& bundleName, core::string& error);

/// Prefix to all files inside an asset bundle taking into account its main file.
/// As a result we can have prefix like "archive:/CAB-<name-or-id>/" for assetbundle or
/// "archive:/" for webplayer.
core::string GetAbsoluteAssetBundlePrefix(const core::string& mainAssetFileName);
/// Prefix without "archive:/" part
core::string GetAssetBundlePrefix(const core::string& mainAssetFileName);

/// Return true if filename is an assetbundle filename
bool IsAssetBundleFilename(const core::string& filename);

Object* LoadNamedObjectFromAssetBundle(AssetBundle& bundle, const core::string& name, ScriptingSystemTypeObjectPtr type);
void LoadAssetWithSubAssetFromAssetBundle(AssetBundle& bundle, const core::string& name, ScriptingSystemTypeObjectPtr type, dynamic_array<Object*>& output);
Object* LoadMainObjectFromAssetBundle(AssetBundle& bundle);

void GetAllAssetNamesFromAssetBundle(AssetBundle& assetBundle, std::vector<core::string>& assetNames);
void GetAllScenePathsFromAssetBundle(AssetBundle& assetBundle, std::vector<core::string>& scenePaths);

/// Return true if filePath is a path to the asset in SerializedFile
/// TODO: Move to ArchiveReaderHeader once Ulf's file.serializedFile branch is in trunk
inline bool IsSerializedFileAssetFilePath(const core::string& filePath)
{
    core::string ext = GetPathNameExtension(filePath);
    if (ext.empty() || ext == "assets" || ext == "sharedAssets")
        return true;

    return false;
}

#endif  // ASSETBUNDLEUTILITY_H
