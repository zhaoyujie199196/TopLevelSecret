#pragma once

#include "Runtime/AssetBundles/AssetBundle.h"
#include "Runtime/Serialize/PersistentManager.h"
#include "Runtime/Threads/ReadWriteLock.h"
#include "Runtime/Utilities/HashStringFunctions.h"

class AssetBundleLoadAssetOperation;

class AssetBundleManager
{
private:
    // Map for the hash to the assetBundle.
    typedef vector_map<ConstantString, AssetBundle*> AssetBundleDependenciesMap;
    AssetBundleDependenciesMap m_HashToAssetBundle;

    // TODO.
    // The bool value is unnecessary. Use something like dense_hash_set when it's available.
    typedef dense_hash_map<AssetBundleLoadAssetOperation*, bool, PointerHashFunction<AssetBundleLoadAssetOperation*> > AssetBundleLoadAssetOperationMap;
    AssetBundleLoadAssetOperationMap m_AssetBundleLoadAssetOperations;

    struct PreloadData
    {
        InstanceID m_InstanceID;
        SerializedObjectIdentifier m_Identifier;
        SInt32 m_Group;

        PreloadData(InstanceID instanceID, int group)
            : m_InstanceID(instanceID)
            , m_Group(group)
        {
        }
    };

    struct SortPreloadDataByIdentifier
    {
        bool operator()(const PreloadData& lhs, const PreloadData& rhs) const
        {
            if (lhs.m_Group != rhs.m_Group)
                return lhs.m_Group < rhs.m_Group;
            else
                return lhs.m_Identifier < rhs.m_Identifier;
        }
    };

    // Scenes available in all assetbundles.
    // All assetbundles that have BuildPlayer-* files are streamed scene assetbundles and user can load level from them.
    // As a streamed scene AssetBundle might have multiple scenes, we should know internal path
    // to that scene to be able to load additional data (e.g. Enlighten data).
    typedef StringHash32Function<UNITY_STRING(kMemFile)> StringHashFunctor;
    typedef dense_hash_map<UNITY_STRING(kMemFile), AssetBundle*, StringHashFunctor> SceneToAssetBundleMap;
    SceneToAssetBundleMap m_ScenePathToAssetBundleMap;
    SceneToAssetBundleMap m_SceneNameToAssetBundleMap;

    mutable ReadWriteLock m_RWLock;

public:
    AssetBundleManager();
    ~AssetBundleManager();

    void RegisterAssetBundle(AssetBundle* assetBundle);
    void UnloadAssetBundle(AssetBundle* assetBundle);

    void AddAssetBundleLoadAssetOperation(AssetBundleLoadAssetOperation* operation);
    void RemoveAssetBundleLoadAssetOperation(AssetBundleLoadAssetOperation* operation);
    void CollectPreloadObjectsFromAssetBundleLoadAssetOperations(dynamic_array<InstanceID>& objects);

    void SortPreloadObjects(dynamic_array<InstanceID>& preloadObjects, bool scriptsOnly);

    // Add dependencies to the preload list
    void CollectPreloadDataDependencies(const AssetBundle* bundle, const std::vector<ConstantString>& dependencies, dynamic_array<InstanceID>& preloadObjects, bool scriptsOnly, bool hasLock = false);
    void CollectPreloadDataDependencies(PPtr<AssetBundle>& bundlePPtr, dynamic_array<InstanceID>& preloadObjects, bool scriptsOnly);

    // Returns scene path and loading path to the scene SerializedFile for a registered scene AssetBundles
    bool GetAssetBundleScenePaths(const core::string& sceneName, core::string& scenePath, core::string& sceneLoadingPath) const;

private:
    void PopulatePreloadData(const dynamic_array<InstanceID>& instanceIDs, dynamic_array<PreloadData>& preloadDataArray, bool scriptsOnly);

    const AssetBundle* CollectPreloadData(InstanceID instanceID, const AssetBundle* bundle, const std::vector<ConstantString>& dependencies, dynamic_array<InstanceID>& preloadObjects, bool hasReadLock);
    void CollectPreloadDataRecursively(const AssetBundle* bundle, const std::vector<ConstantString>& initialDependencies, dynamic_array<InstanceID>& preloadObjects, bool hasReadLock);

    void GetAssetBundleAndScenePathBySceneName(const core::string& sceneName, AssetBundle*& assetBundle, core::string& scenePath) const;
};

AssetBundleManager& GetAssetBundleManager();
