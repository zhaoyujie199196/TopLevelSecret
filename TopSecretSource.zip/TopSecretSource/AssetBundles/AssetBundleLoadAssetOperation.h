#pragma once

#include "Runtime/PreloadManager/LoadOperation.h"
#include "Runtime/AssetBundles/AssetBundle.h"
#include "Runtime/Threads/Mutex.h"

class AssetBundleLoadAssetOperation : public LoadOperation
{
public:
    // Create a new operation which will load the specified asset
    // @param bundle AssetBundle we are loading from. Must be alive during load operation!
    // @param name Name of the object (or set of objects with the same name) to load
    // @param type Requested object type. We'll return only objects of the specified type.
    // @param includeSubAssets If true, we'll load all assets which have the specified name and not only the first one.
    static AssetBundleLoadAssetOperation* LoadAsset(AssetBundle& bundle, const core::string& name, ScriptingSystemTypeObjectPtr type, bool includeSubAssets);

    virtual void Perform();

    // Return object loaded by this operation
    Object* GetLoadedAsset();
    // Return all assets loaded by this operation (requested asset + dependencies)
    void GetAllLoadedAssets(dynamic_array<Object*>& objects);

    // Used in AssetBundleUtility.
    static InstanceID PrepareMainAssetPreloadList(AssetBundle& bundle, dynamic_array<InstanceID>& preloadAssets);
    //  Used in AssetBundleUtility.
    static void PreparePreloadAssets(const AssetBundle& bundle, const AssetBundle::range& assets, const ScriptingSystemTypeObjectPtr& typeToLoad, bool loadFirstOnly,
        dynamic_array<InstanceID>& outAssetsToLoad, dynamic_array<InstanceID>& outAssetsLoaded, dynamic_array<PPtr<Object> >& outAssets);

    virtual ~AssetBundleLoadAssetOperation();

    const dynamic_array<InstanceID>& GetAssetsToLoadDependencies() const { return m_AssetsToLoadDependencies; }
    const dynamic_array<InstanceID>& GetAssetsLoadedDependencies() const { return m_AssetsLoadedDependencies; }

protected:
    AssetBundleLoadAssetOperation(AssetBundle& bundle, const core::string& name, ScriptingSystemTypeObjectPtr type, bool includeSubAssets);

    // Collect dependencies
    void CollectFullPreloadDataDependencies(dynamic_array<InstanceID>& assetsToLoadDependencies);
    // Return assets which match requested type from all that match the specified name
    void GetLoadedAssets(dynamic_array<Object*>& objects, bool onlyFirst);

    // AssetBundle we are loading from.
    PPtr<AssetBundle> m_AssetBundle;
    // AssetBundle name, so we don't lose the information if the bundle is unloaded
    ConstantString m_AssetBundleName;
    // The name of the assets we want to load.
    core::string m_AssetName;
    // The type of the assets we want to load.
    ScriptingSystemTypeObjectPtr m_AssetType;
    // Fully calculated list of assets we requested for load.
    dynamic_array<PPtr<Object> > m_AssetsToLoad;
    // Assets dependencies to be loaded.
    dynamic_array<InstanceID> m_AssetsToLoadDependencies;
    // Assets dependencies already loaded.
    dynamic_array<InstanceID> m_AssetsLoadedDependencies;
};
