#include "UnityPrefix.h"
#include "Runtime/AssetBundles/AssetBundleLoadFromMemoryAsyncOperation.h"
#include "Runtime/Jobs/BackgroundJobQueue.h"

AssetBundleLoadFromMemoryAsyncOperation::AssetBundleLoadFromMemoryAsyncOperation()
    : AssetBundleLoadFromStreamAsyncOperation("Memory")
{
    SetAllowThreadedConversion(true);
}

void AssetBundleLoadFromMemoryAsyncOperation::Execute(const UInt8* dataPtr, size_t dataSize)
{
    // This copies data to internal buffer we decompress from
    if (FeedStream(dataPtr, dataSize))
        GetBackgroundJobQueue().ScheduleJob(FinalizeJob, this);
    else
        IntegrateWithPreloadManager();
}

void AssetBundleLoadFromMemoryAsyncOperation::ExecuteSynchronously(const UInt8* dataPtr, size_t dataSize)
{
    if (FeedStream(dataPtr, dataSize))
        FinalizeStream();
    IntegrateImmediately();
}

void AssetBundleLoadFromMemoryAsyncOperation::FinalizeJob(AssetBundleLoadFromMemoryAsyncOperation* this_)
{
    if (!this_->IsCancelled())
        this_->FinalizeStream();
    this_->IntegrateWithPreloadManager();
}
