#include "UnityPrefix.h"
#include "Runtime/AssetBundles/AssetBundleLoadFromCacheAsyncOperation.h"

#if ENABLE_CACHING

#include "Runtime/AssetBundles/AssetBundleUtility.h"
#include "Runtime/Jobs/BackgroundJobQueue.h"
#include "Runtime/Misc/CachingManager.h"

AssetBundleLoadFromCacheAsyncOperation::AssetBundleLoadFromCacheAsyncOperation(const core::string& assetBundleName)
    : AssetBundleLoadFromStreamAsyncOperation(assetBundleName)
{
    SetAllowThreadedConversion(true);
}

AssetBundleLoadFromCacheAsyncOperation::~AssetBundleLoadFromCacheAsyncOperation()
{
}

void AssetBundleLoadFromCacheAsyncOperation::Execute()
{
    core::string subpath = GetCachingManager().GetCurrentCache().URLToPath(m_Url, m_CacheHash);
    SetCacheId(subpath);

    GetBackgroundJobQueue().ScheduleJob(LoadCachedArchiveJob, this);
}

void AssetBundleLoadFromCacheAsyncOperation::ExecuteSynchronously()
{
    core::string subpath = GetCachingManager().GetCurrentCache().URLToPath(m_Url, m_CacheHash);
    SetCacheId(subpath);

    LoadCachedArchive();
    IntegrateImmediately();
}

void AssetBundleLoadFromCacheAsyncOperation::LoadCachedArchiveJob(AssetBundleLoadFromCacheAsyncOperation* this_)
{
    if (!this_->IsCancelled())
        this_->LoadCachedArchive();
    this_->IntegrateWithPreloadManager();
}

#endif // ENABLE_CACHING
