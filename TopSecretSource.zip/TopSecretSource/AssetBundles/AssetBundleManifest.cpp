#include "UnityPrefix.h"
#include "AssetBundleManifest.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Utilities/PathNameUtility.h"


IMPLEMENT_REGISTER_CLASS(AssetBundleManifest, 290);
IMPLEMENT_OBJECT_SERIALIZE(AssetBundleManifest);

void AssetBundleManifest::ThreadedCleanup()
{
}

void AssetBundleManifest::GetAllAssetBundles(std::vector<core::string>& assetBundleNames)
{
    assetBundleNames.clear();

    for (vector_map<SInt32, ConstantString>::const_iterator it = m_AssetBundleNames.begin(); it != m_AssetBundleNames.end(); ++it)
    {
        assetBundleNames.push_back(it->second.c_str());
    }

    std::sort(assetBundleNames.begin(), assetBundleNames.end());
}

void AssetBundleManifest::GetAllAssetBundlesWithVariant(std::vector<core::string>& assetBundleNames)
{
    assetBundleNames.clear();

    for (vector_set<SInt32>::const_iterator it = m_AssetBundlesWithVariant.begin(); it != m_AssetBundlesWithVariant.end(); ++it)
    {
        assetBundleNames.push_back(m_AssetBundleNames[*it].c_str());
    }

    std::sort(assetBundleNames.begin(), assetBundleNames.end());
}

Hash128 AssetBundleManifest::GetAssetBundleHash(const core::string& assetBundleName)
{
    SInt32 assetBundleIndex = GetAssetBundleIndex(assetBundleName);
    if (assetBundleIndex == -1)
    {
        WarningString(Format("AssetBundle with name \"%s\" doesn't exist in the AssetBundleManifest.", assetBundleName.c_str()));
        return Hash128();
    }

    return m_AssetBundleInfos[assetBundleIndex].m_AssetBundleHash;
}

void AssetBundleManifest::CollectDirectDependencies(const core::string& assetBundleName, std::vector<core::string>& dependencies)
{
    dependencies.clear();

    SInt32 assetBundleIndex = GetAssetBundleIndex(assetBundleName);
    if (assetBundleIndex == -1)
        return;

    vector_set<SInt32>& assetBundleDependencies = m_AssetBundleInfos[assetBundleIndex].m_AssetBundleDependencies;
    for (vector_set<SInt32>::const_iterator it = assetBundleDependencies.begin(); it != assetBundleDependencies.end(); ++it)
    {
        dependencies.push_back(m_AssetBundleNames[*it].c_str());
    }

    std::sort(dependencies.begin(), dependencies.end());
}

void AssetBundleManifest::CollectAllDependencies(const core::string& assetBundleName, std::vector<core::string>& dependencies)
{
    dependencies.clear();

    SInt32 assetBundleIndex = GetAssetBundleIndex(assetBundleName);
    if (assetBundleIndex == -1)
        return;

    std::set<SInt32> assetBundleDependencies;
    CollectAllDependenciesRecursively(assetBundleIndex, assetBundleDependencies);

    // Remove itself from the dependencies if necessary. Please check case 780252.
    assetBundleDependencies.erase(assetBundleIndex);

    for (std::set<SInt32>::const_iterator it = assetBundleDependencies.begin(); it != assetBundleDependencies.end(); ++it)
    {
        dependencies.push_back(m_AssetBundleNames[*it].c_str());
    }

    std::sort(dependencies.begin(), dependencies.end());
}

void AssetBundleManifest::CollectAllDependenciesRecursively(SInt32 assetBundleIndex, std::set<SInt32>& dependencies)
{
    if (m_AssetBundleInfos.find(assetBundleIndex) == m_AssetBundleInfos.end())
        return;

    vector_set<SInt32>& assetBundleDependencies = m_AssetBundleInfos[assetBundleIndex].m_AssetBundleDependencies;
    for (vector_set<SInt32>::const_iterator it = assetBundleDependencies.begin(); it != assetBundleDependencies.end(); ++it)
    {
        if (!dependencies.insert(*it).second)
            continue;

        CollectAllDependenciesRecursively(*it, dependencies);
    }
}

SInt32 AssetBundleManifest::GetAssetBundleIndex(const core::string& assetBundleName)
{
    core::string goodAssetBundleName = ToLower(assetBundleName);
    ConvertSeparatorsToUnity(goodAssetBundleName);

    for (vector_map<SInt32, ConstantString>::const_iterator it = m_AssetBundleNames.begin(); it != m_AssetBundleNames.end(); ++it)
    {
        if (it->second == goodAssetBundleName.c_str())
            return it->first;
    }

    return -1;
}

#if UNITY_EDITOR

#include "Runtime/Serialize/TransferFunctions/YAMLWrite.h"

template<>
void AssetBundleManifest::Transfer(YAMLWrite& transfer)
{
    // Make the text manifest file more readable, also don't write the assetBundleIndices.
    transfer.BeginMetaGroup("AssetBundleInfos");
    int count = 0;
    for (AssetBundleInfoContainer::const_iterator it = m_AssetBundleInfos.begin(); it != m_AssetBundleInfos.end(); ++it, ++count)
    {
        transfer.BeginMetaGroup(Format("Info_%d", count).c_str());

        transfer.Transfer(m_AssetBundleNames[it->first], "Name");

        transfer.BeginMetaGroup("Dependencies");
        vector_set<SInt32>& dependencies = m_AssetBundleInfos[it->first].m_AssetBundleDependencies;
        int dependencyCount = 0;
        for (vector_set<SInt32>::const_iterator innerIt = dependencies.begin(); innerIt != dependencies.end(); ++innerIt, ++dependencyCount)
        {
            transfer.Transfer(m_AssetBundleNames[*innerIt], Format("Dependency_%d", dependencyCount).c_str());
        }
        transfer.EndMetaGroup();

        transfer.EndMetaGroup();
    }
    transfer.EndMetaGroup();
}

#endif
