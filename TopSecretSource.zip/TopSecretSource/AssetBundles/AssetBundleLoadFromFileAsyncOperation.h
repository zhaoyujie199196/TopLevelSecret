#pragma once

#include "Runtime/AssetBundles/AssetBundleLoadFromStreamAsyncOperation.h"

/// AssetBundleCreateOperation implementation which can load assetbundle from file.
/// If archive supports realtime decompression (chunk-based compression), we load it directly form a file,
/// overwise we decompress it into memory.
class AssetBundleLoadFromFileAsyncOperation : public AssetBundleLoadFromStreamAsyncOperation
{
public:
    AssetBundleLoadFromFileAsyncOperation(const core::string& assetBundleName);
    virtual ~AssetBundleLoadFromFileAsyncOperation();

    void SetPath(const core::string& path) { m_Path = path; }
    void SetOffset(const UInt64 offset) {m_Offset = offset; }
    void Execute();
    void ExecuteSynchronously();

private:
    static void LoadArchiveJob(AssetBundleLoadFromFileAsyncOperation* context);
    static void ConvertArchiveJob(AssetBundleLoadFromFileAsyncOperation* context);

    InitializeResult LoadArchive();
    bool ConvertArchive();

    core::string m_Path;
    UInt64 m_Offset;
};
