#pragma once
#include "Runtime/Threads/ThreadSharedObject.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Threads/ThreadSharedObject.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/2D/Common/SpriteTypes.h"

class SharedSpriteRenderData : private ThreadSharedObject
{
public:
    void AddRef() const { ThreadSharedObject::AddRef(); }
    void Release() const { ThreadSharedObject::Release(kMemSprites); }
    int  GetRefCount() const { return ThreadSharedObject::GetRefCount(); }

    const dynamic_array<SpriteVertex>& GetVertices() const { return m_Vertices; }
    dynamic_array<SpriteVertex>&       GetVertices() { return m_Vertices; }

    const dynamic_array<UInt16>& GetIndices() const { return m_Indices; }
    dynamic_array<UInt16>&       GetIndices() { return m_Indices; }

private:
    dynamic_array<SpriteVertex> m_Vertices;
    dynamic_array<UInt16>       m_Indices;
};
