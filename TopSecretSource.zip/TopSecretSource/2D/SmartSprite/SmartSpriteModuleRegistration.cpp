#include "UnityPrefix.h"
#include "Runtime/Modules/ModuleRegistration.h"
#include "Runtime/BaseClasses/ClassRegistration.h"

#define UNITY_MODULE_NAME     SmartSprite
#define UNITY_MODULE_STRIPPABLE
#define UNITY_MODULE_INCLUDE "Runtime/2D/SmartSprite/SmartSpriteModule.inc.h"
    #include "Runtime/Modules/ModuleTemplate.inc.h"
#undef UNITY_MODULE_NAME
#undef UNITY_MODULE_INCLUDE

UNITY_MODULE_INITIALIZE(SmartSprite)
{
}

UNITY_MODULE_CLEANUP(SmartSprite)
{
}
