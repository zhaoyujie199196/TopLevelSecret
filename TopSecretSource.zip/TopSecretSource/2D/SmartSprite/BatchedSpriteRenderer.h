#pragma once

#include "Configuration/UnityConfigure.h"

#include "Runtime/BaseClasses/BaseObject.h"
#include "Runtime/Camera/Camera.h"
#include "Runtime/Graphics/Renderer.h"

class SpriteDataProvider;
class Sprite;
struct SpriteVertex;

class EXPORT_COREMODULE BatchedSpriteRenderer : public Renderer
{
    REGISTER_CLASS(BatchedSpriteRenderer);
    DECLARE_OBJECT_SERIALIZE();
public:
    static void InitializeClass();
    static void CleanupClass();

    BatchedSpriteRenderer(MemLabelId label, ObjectCreationMode mode);

    virtual void AwakeFromLoad(AwakeFromLoadMode awakeMode);
    virtual void SmartReset();

    virtual void UpdateLocalAABB();
    virtual void Render(int materialIndex, const ChannelAssigns& channels);
    virtual UInt32 AddAsRenderNode(RenderNodeQueue& queue, const RenderNode::SourceData& sourceData);

private:
    void RenderSprites(size_t idxStart, int idxEnd, size_t totalIndices, size_t totalVertices, const ChannelAssigns& channels);
    void OnDidAddComponent(Component* com);

    PPtr<SpriteDataProvider> m_SpriteRenderProvider;
};
