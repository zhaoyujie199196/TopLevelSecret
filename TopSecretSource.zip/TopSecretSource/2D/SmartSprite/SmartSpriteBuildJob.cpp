#include "UnityPrefix.h"
#include "SmartSpriteBuildJob.h"
#include "External/libtess2/libtess2/tesselator.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Math/Simd/vec-math.h"

using namespace math;

PROFILER_INFORMATION(gBuildSmartSprite, "SmartSprite", kProfilerAI)

// Const Stuff. Could be a Member
namespace SmartSpriteUtils
{
    static const UInt32 kMinimumSplineDetail = 1;
    static const UInt32 kColumnTriangleIndices[18] = { 0, 3, 1, 0, 2, 3, 2, 5, 3, 2, 4, 5, 4, 7, 5, 4, 6, 7 };

    static Vector2f BezierPoint(const Vector2f& startTangent, const Vector2f& startPosition, const Vector2f& endPosition, const Vector2f& endTangent, float t)
    {
        float s = 1.0f - t;
        const float4 xt = float4(t);
        const float4 nt = float4(s);
        const float4 x3 = float4(3.0f);

        const float4 knot01 = float4(startPosition.x, startPosition.y, 0, 0);
        const float4 knot02 = float4(startTangent.x, startTangent.y, 0, 0);
        const float4 knot10 = float4(endTangent.x, endTangent.y, 0, 0);
        const float4 knot11 = float4(endPosition.x, endPosition.y, 0, 0);

        const float4 value = knot01 * nt * nt * nt + knot02 * nt * nt * xt * x3 + knot10 * nt * xt * xt * x3 + knot11 * xt * xt * xt;
        return Vector2f(value.x, value.y);
    }

    static bool GenerateColumnVertices(const Vector2f& a, const Vector2f& b, const Vector4f& border, const Vector2f& whsize, bool flip, Vector2f& rt, Vector2f& rtm, Vector2f& rbm, Vector2f& rb)
    {
        const float4 _a = float4(a.x, a.y, 0, 0);
        const float4 _b = float4(b.x, b.y, 0, 0);
        const float4 v1 = flip ? (_a - _b) : (_b - _a);
        const float4 v2 = float4(-v1.y, v1.x, 0, 0);
        if (length(v2) < Vector2f::epsilon)
            return false;

        const float4 whsizey = float4(whsize.y * 0.5f);
        const float4 borderw = float4(border.y);
        const float4 bordery = float4(border.w);
        const float4 nv2 = normalize(v2);
        const float4 v3 = nv2 * whsizey;

        const float4 _rt = _a - v3;
        const float4 _rb = _a + v3;
        const float4 _rtm = _rt + (nv2 * bordery);
        const float4 _rbm = _rb - (nv2 * borderw);

        rt.x = _rt.x;   rt.y = _rt.y;
        rb.x = _rb.x;   rb.y = _rb.y;
        rtm.x = _rtm.x; rtm.y = _rtm.y;
        rbm.x = _rbm.x; rbm.y = _rbm.y;
        return true;
    }
}

struct SortBySpritePosition
{
    inline bool operator()(const SmartSpriteData* r1, const SmartSpriteData* r2)
    {
        return r1->m_Order < r2->m_Order;
    }
};

/**
 *  PPtr are only accessed on the MainThread 1) Constructor and Main Thread Init.
 *  Major parts of CPU intensive code Including Tessellation resides on Worker through Job.
 **/
SmartSpriteBuildJob::SmartSpriteBuildJob()
    : m_RenderDataArray(kMemTempJobAlloc)
    , m_Angles(kMemTempJobAlloc)
    , m_Edges(kMemTempJobAlloc)
    , m_Vertices(kMemTempJobAlloc)
    , m_CurveVertices(kMemTempJobAlloc)
    , m_ColliderPoints(kMemTempJobAlloc)
    , m_ControlPoints(kMemTempJobAlloc)
    , m_BuildBottom(false)
    , m_ContinousStrip(false)
{
}

void SmartSpriteBuildJob::Terminate()
{
    for (SmartSpriteAngleArray::iterator it = m_Angles.begin(); it != m_Angles.end(); ++it)
    {
        UNITY_DELETE((*it).m_Sprites, kMemTempJobAlloc);
    }
}

void SmartSpriteBuildJob::MainThreadInit(SmartSprite* sprite, const SmartSprite::ControlPoints& points, SmartSprite::AngleRanges& angles, PPtr<Texture2D> f, bool buildBottom, bool continousStrip)
{
    m_ControlPoints = points;
    m_BuildBottom = buildBottom;
    m_ContinousStrip = continousStrip;
    m_Tess = NULL;
    m_Vertices.clear();
    m_CurveVertices.clear();
    m_ColliderPoints.clear();
    m_RenderDataArray.clear();
    m_Angles.clear();
    m_Edges.clear();

    // Reserve
    size_t cpSize = points.size();
    m_Angles.reserve(angles.size());
    m_Vertices.reserve(cpSize);
    m_CurveVertices.reserve(cpSize * 64);
    m_ColliderPoints.reserve(cpSize * 64);
    m_RenderDataArray.reserve(cpSize + 1);
    m_Edges.reserve(cpSize);

    if (f.IsValid())
    {
        m_FillInfo.m_Texture = f;
        m_FillInfo.m_TextureDataSize = Vector2f(m_FillInfo.m_Texture->GetDataWidth(), m_FillInfo.m_Texture->GetDataHeight());
        m_FillInfo.m_TextureScaledSize = m_FillInfo.m_TextureDataSize * (1.0f / sprite->GetFillSpriteScale());
        Assert(m_FillInfo.m_Texture->GetWrapMode() == kTexWrapRepeat);
    }


    m_FillInfo.m_SplineDetail = std::max(SmartSpriteUtils::kMinimumSplineDetail, sprite->GetSplineDetail());
    m_FillInfo.m_ColliderDetail = std::min(sprite->GetColliderDetail(), sprite->GetSplineDetail());

    for (SmartSprite::AngleRanges::iterator it = angles.begin(); it != angles.end(); ++it)
    {
        SmartSpriteAngle angle;
        angle.m_Start = it->m_Start;
        angle.m_End = it->m_End;
        size_t spriteCount = it->m_Sprites.size();
        for (SpriteArray::iterator itr = it->m_Sprites.begin(); itr != it->m_Sprites.end(); ++itr)
        {
            PPtr<Sprite> spr = (*itr);
            if (spr.IsValid())
            {
                SmartSpriteInfo info;
                info.m_Texture = spr->GetRenderData().texture;
                info.m_TextureRect = spr->GetRenderData(true).textureRect;
                info.m_TextureDataSize = Vector2f(info.m_Texture->GetGPUWidth(), info.m_Texture->GetGPUHeight());
                info.m_TextureScaledSize = info.m_TextureDataSize * (1.0f / sprite->GetFillSpriteScale());
                info.m_Border = spr->GetBorder();
                info.m_Size = spr->GetSize();
                info.m_SizeInUnits = spr->GetSizeInUnits();
                info.m_PixelsToUnit = spr->GetPixelsToUnits();
                if (NULL == angle.m_Sprites)
                {
                    angle.m_Sprites = UNITY_NEW(dynamic_array<SmartSpriteInfo>, kMemTempJobAlloc) ();
                    angle.m_Sprites->reserve(spriteCount);
                }
                angle.m_Sprites->push_back(info);
            }
        }
        if (NULL != angle.m_Sprites)
        {
            m_Angles.push_back(angle);
        }
    }

    SetupData();
}

int SmartSpriteBuildJob::SetupData()
{
    size_t cpSize = m_ControlPoints.size();
    for (SmartSprite::ControlPoints::const_iterator it = m_ControlPoints.begin(); it != m_ControlPoints.end(); ++it)
        m_Vertices.push_back(Vector2f(it->m_Position.x, it->m_Position.y));

    for (size_t i = 0; i < cpSize; i++)
    {
        size_t j = (i + 1) % cpSize;
        if (j == 0 && !DoesBuildBottom())
            continue;

        static const math::float4 up = math::float4(0, 1.0f, 0, 0);
        static const math::float4 right = math::float4(1.0f, 0, 0, 0);

        const math::float4 p1 = math::float4(m_ControlPoints[i].m_Position.x, m_ControlPoints[i].m_Position.y, 0, 0);
        const math::float4 p2 = math::float4(m_ControlPoints[j].m_Position.x, m_ControlPoints[j].m_Position.y, 0, 0);
        const math::float4 _dir = p2 - p1;

        if (math::dot(_dir, _dir) < Vector2f::epsilon)
        {
            // they are the same point, just move on
            continue;
        }

        int selectedIndex = -1, renderOrder = 0;
        const math::float4 dir = math::normalize(_dir);

        // now we determine the which sprite to use from the angle ranges
        for (int k = 0; k < m_Angles.size(); ++k)
        {
            // first we dot with right to find out if we are on the left or right of up
            float dotRight = math::dot(dir, right);
            float dotUp = math::acos(math::dot(dir, up));
            float sign = dotRight >= 0 ? 1.0f : -1.0f;
            float angle = dotUp * kRad2Deg * sign;
            const SmartSpriteAngle& info = m_Angles[k];

            if (angle > info.m_Start && angle < info.m_End)
            {
                selectedIndex = k;
                break;
            }

            // special case
            if (info.m_Start > 0 && info.m_End < 0)
            {
                if (angle > info.m_Start || angle < info.m_End)
                {
                    selectedIndex = k;
                    break;
                }
            }
            renderOrder++;
        }

        if (-1 == selectedIndex)
            continue;

        int min = (int)std::min(i, j);
        int max = (int)std::max(i, j);
        bool edgeUpdated = false;
        for (SmartSpriteEdgeArray::iterator itr = m_Edges.begin(); itr != m_Edges.end(); ++itr)
        {
            if (itr->m_ArrayIndex == selectedIndex && m_ControlPoints[i].m_Mode != kControlPointModeBreak && i != (cpSize - 1))
            {
                if (itr->m_StartPoint - min == 1)
                {
                    edgeUpdated = true;
                    itr->m_StartPoint = min;
                    break;
                }
                if (max - itr->m_EndPoint == 1)
                {
                    edgeUpdated = true;
                    itr->m_EndPoint = max;
                    break;
                }
            }
        }
        if (!edgeUpdated)
        {
            SmartSpriteEdge ei(selectedIndex);
            ei.m_StartPoint = min;
            ei.m_EndPoint = max;
            ei.m_Bottom = (j == 0) ? 1 : 0;
            ei.m_RenderOrder = renderOrder;
            ei.m_SpriteIndex = m_ControlPoints[i].m_AngleSpriteIndex;
            m_Edges.push_back(ei);
        }
    }

    // Reinitialize Sub Sprites.
    if (IsContinousStrip())
    {
        SmartSpriteData* data = UNITY_NEW(SmartSpriteData, kMemTempJobAlloc) ();
        m_RenderDataArray.push_back(data);
    }
    for (size_t index = 0; index < m_Edges.size(); ++index)
    {
        SmartSpriteData* edgeData = UNITY_NEW(SmartSpriteData, kMemTempJobAlloc) ();
        m_RenderDataArray.push_back(edgeData);
    }

    // Set Base Data.
    size_t fillSpriteOn = 0;
    if (IsContinousStrip())
    {
        SmartSpriteData* FillRenderData = m_RenderDataArray[0];
        FillRenderData->m_Order = -255; // always first
        FillRenderData->m_Texture = m_FillInfo.m_Texture;
        fillSpriteOn = 1;
    }
    for (size_t index = 0; index < m_Edges.size(); ++index)
    {
        SmartSpriteEdge& ei = m_Edges[index];
        SmartSpriteData* renderData = m_RenderDataArray[index + fillSpriteOn];
        dynamic_array<SmartSpriteInfo>& spriteInfos = *m_Angles[ei.m_ArrayIndex].m_Sprites;
        // If Sprite Index set through Control-Point is valid, set it. Otherwise Reset.
        ei.m_SpriteIndex = (ei.m_SpriteIndex < spriteInfos.size()) ? ei.m_SpriteIndex : (ei.m_SpriteIndex % spriteInfos.size());
        renderData->m_Texture = spriteInfos[ei.m_SpriteIndex].m_Texture;
    }

    return 0;
}

unsigned int SmartSpriteBuildJob::Execute()
{
    PROFILER_AUTO(gBuildSmartSprite, NULL);
    {
        // Generate for Collider
        FillContour(m_ColliderPoints, m_FillInfo.m_ColliderDetail);
        FillContour(m_CurveVertices);
        FillEdges();

        // sort it by render order
        std::sort(m_RenderDataArray.begin(), m_RenderDataArray.end(), SortBySpritePosition());
    }

    return 0;
}

bool SmartSpriteBuildJob::Integrate(SmartSprite* sprite)
{
    sprite->UpdateMesh(m_RenderDataArray);
    sprite->UpdateCollider(m_ColliderPoints);

    for (size_t index = 0; index < m_RenderDataArray.size(); ++index)
        UNITY_DELETE(m_RenderDataArray[index], kMemTempJobAlloc);
    m_RenderDataArray.clear();

    return true;
}

bool SmartSpriteBuildJob::GenerateTiles(SmartSpriteEdge* ei, SmartSpriteData* renderData, const Vector4f& border, const float refDistance, dynamic_array<Vector2f>& segment)
{
    size_t columns = segment.size() - 1;
    dynamic_array<SpriteVertex>& vertices = renderData->m_Vertices;
    dynamic_array<UInt16>& indices = renderData->m_Indices;

    dynamic_array<SmartSpriteInfo>& spriteInfos = *m_Angles[ei->m_ArrayIndex].m_Sprites;
    const SmartSpriteInfo& esi = spriteInfos[ei->m_SpriteIndex];

    Vector2f whsize = Vector2f(esi.m_TextureRect.width, esi.m_TextureRect.height);
    vertices.reserve(columns * 8);
    indices.reserve(columns * 18);
    size_t activeColumn = 0;
    float uvDist = 0;

    Vector4f borderP = esi.m_Border * (1.0f / esi.m_PixelsToUnit);
    Vector2f whsizeP = whsize * (1.0f / esi.m_PixelsToUnit);
    float uvStart = borderP.x;
    float uvEnd = whsizeP.x - borderP.z;
    float uvInter = uvEnd - uvStart;
    float uvTotal = whsizeP.x;
    float distanceMultipler = uvInter / refDistance;
    float uvNow = uvStart / uvTotal;
    float debugTest = 0, uvOld = 0;
    // Find control points
    // 0───1
    // │   │
    // 2───3
    // │   │
    // │   │
    // 4───5
    // │   │
    // 6───7
    for (size_t i = 0; i < columns; ++i)
    {
        SpriteVertex column[8];
        size_t vertCount = vertices.size();
        bool segA, segB, lastColumn = (columns - 1 == i);
        Vector2f lt, ltm, lbm, lb, rt, rtm, rbm, rb;
        Vector2f endSegment = lastColumn ? segment[i] : segment[i + 2];

        // GenerateColumnVertices SIMDfied. Below mostly scalar and assigment stuff.
        segA = SmartSpriteUtils::GenerateColumnVertices(segment[i], segment[i + 1], borderP, whsizeP, false, lt, ltm, lbm, lb);
        segB = SmartSpriteUtils::GenerateColumnVertices(segment[i + 1], endSegment, borderP, whsizeP, lastColumn, rt, rtm, rbm, rb);

        // Not 9 Splice, try flip
        if (segA && !segB)
            segB = SmartSpriteUtils::GenerateColumnVertices(segment[i + 1], segment[i], borderP, whsizeP, true, rt, rtm, rbm, rb);
        if (!(segA && segB))
            continue;

        column[0].pos.x = lt.x;                 column[0].pos.y = lt.y;                 column[0].pos.z = 0;
        column[1].pos.x = rt.x;                 column[1].pos.y = rt.y;                 column[1].pos.z = 0;
        column[2].pos.x = ltm.x;                column[2].pos.y = ltm.y;                column[2].pos.z = 0;
        column[3].pos.x = rtm.x;                column[3].pos.y = rtm.y;                column[3].pos.z = 0;
        column[4].pos.x = lbm.x;                column[4].pos.y = lbm.y;                column[4].pos.z = 0;
        column[5].pos.x = rbm.x;                column[5].pos.y = rbm.y;                column[5].pos.z = 0;
        column[6].pos.x = lb.x;                 column[6].pos.y = lb.y;                 column[6].pos.z = 0;
        column[7].pos.x = rb.x;                 column[7].pos.y = rb.y;                 column[7].pos.z = 0;

        if (i == 0)
        {
            column[0].uv.x = column[0].uv.y = column[2].uv.x = column[1].uv.y = 0;
            column[1].uv.x = column[3].uv.x = border.x / whsize.x;
            column[2].uv.y = column[3].uv.y = border.y / whsize.y;

            column[4].uv.x = column[6].uv.x = 0;
            column[6].uv.y = column[7].uv.y = 1.0f;
            column[5].uv.x = column[7].uv.x = border.x / whsize.x;
            column[4].uv.y = column[5].uv.y = (whsize.y - border.w) / whsize.y;
        }
        else if (i == (columns - 1))
        {
            column[0].uv.y = column[1].uv.y = 0;
            column[0].uv.x = column[2].uv.x = (whsize.x - border.z) / whsize.x;
            column[1].uv.x = column[3].uv.x = 1.0f;
            column[2].uv.y = column[3].uv.y = border.y / whsize.y;

            column[4].uv.x = column[6].uv.x = (whsize.x - border.z) / whsize.x;
            column[6].uv.y = column[7].uv.y = 1.0f;
            column[5].uv.x = column[7].uv.x = 1.0f;
            column[4].uv.y = column[5].uv.y = (whsize.y - border.w) / whsize.y;
        }
        else
        {
            if ((uvInter - uvDist) < 0.01f)
            {
                uvNow = uvStart / uvTotal;
                uvDist = 0;
            }

            column[0].uv.y = 0;
            column[2].uv.y = border.y / whsize.y;
            column[4].uv.x = column[6].uv.x = column[0].uv.x = column[2].uv.x = uvNow;
            column[4].uv.y = (whsize.y - border.w) / whsize.y;
            column[6].uv.y = 1.0f;

            Vector2f diff = segment[i + 1] - segment[i];
            float distance = Magnitude(diff) * distanceMultipler;
            uvDist = uvDist + distance;
            uvOld = uvNow;
            uvNow = ((uvDist + uvStart) / uvTotal);

            if ((uvDist - uvInter) > 0.01f)
            {
                uvNow = uvEnd / uvTotal;
                uvDist = uvEnd;
            }

            debugTest = debugTest + distance;
            //  printf_console("_uv %f-%f %f\n", uvOld, uvNow, debugTest / uvInter);

            column[1].uv.y = 0;
            column[1].uv.x = column[3].uv.x = column[5].uv.x = column[7].uv.x = uvNow;
            column[3].uv.y = border.y / whsize.y;
            column[7].uv.y = 1.0f;
            column[5].uv.y = (whsize.y - border.w) / whsize.y;
        }

        // Fix UV for Sheets/Atlas
        float xStart = esi.m_TextureRect.x / esi.m_TextureDataSize.x;
        float yStart = esi.m_TextureRect.y / esi.m_TextureDataSize.y;
        float xSize = esi.m_TextureRect.width / esi.m_TextureDataSize.x;
        float ySize = esi.m_TextureRect.height / esi.m_TextureDataSize.y;
        for (size_t j = 0; j < 8; ++j)
        {
            column[j].uv.x = (column[j].uv.x * xSize) + xStart;
            column[j].uv.y = (column[j].uv.y * ySize) + yStart;
            vertices.push_back(column[j]);
        }
        for (size_t j = 0; j < 18; ++j)
        {
            UInt16 index = (UInt16)(vertCount + SmartSpriteUtils::kColumnTriangleIndices[j]);
            indices.push_back(index);
        }
    }
    return true;
}

void SmartSpriteBuildJob::GenerateLinear(const SmartSprite::ControlPoints& inputs, const size_t startPoint, const size_t endPoint, dynamic_array<Vector2f>& outputs, const UInt32 forcedDetail)
{
    const Vector2f& v1 = inputs[startPoint].m_Position;
    const Vector2f& v2 = inputs[endPoint].m_Position;
    UInt32 detail = SmartSprite::GetControlPointDetail(m_ControlPoints, m_FillInfo.m_SplineDetail, startPoint);
    detail = (forcedDetail == 0) ? detail : ((forcedDetail > detail) ? detail : forcedDetail);
    float fDiv = 0, fMax = (float)detail;
    for (size_t sub = 0; sub < detail; ++sub)
    {
        Vector2f v = Lerp(v1, v2, fDiv / fMax);
        outputs.push_back(v);
        fDiv++;
    }
}

void SmartSpriteBuildJob::GenerateBezier(const Vector2f* v, const size_t pt, dynamic_array<Vector2f>& outputs, const UInt32 forcedDetail)
{
    UInt32 detail = SmartSprite::GetControlPointDetail(m_ControlPoints, m_FillInfo.m_SplineDetail, pt);
    detail = (forcedDetail == 0) ? detail : ((forcedDetail > detail) ? detail : forcedDetail);
    float fDiv = 0, fMax = (float)detail;
    for (size_t sub = 0; sub < detail; ++sub)
    {
        Vector2f res = SmartSpriteUtils::BezierPoint(v[0], v[1], v[2], v[3], fDiv / fMax);
        outputs.push_back(res);
        fDiv++;
    }
}

size_t SmartSpriteBuildJob::GetControlStartIndex(size_t position)
{
    size_t index = 0;
    for (size_t i = 0; i < position; ++i)
        index = index + SmartSprite::GetControlPointDetail(m_ControlPoints, m_FillInfo.m_SplineDetail, i);
    return index;
}

void SmartSpriteBuildJob::FillEdges()
{
    size_t fillSpriteOn = IsContinousStrip() ? 1 : 0;

    for (size_t index = 0; index < m_Edges.size(); ++index)
    {
        SmartSpriteEdge& ei = m_Edges[index];
        SmartSpriteData* renderData = m_RenderDataArray[index + fillSpriteOn];
        dynamic_array<SmartSpriteInfo>& spriteInfos = *m_Angles[ei.m_ArrayIndex].m_Sprites;
        const SmartSpriteInfo& esi = spriteInfos[ei.m_SpriteIndex];

        size_t vSize = m_Vertices.size();
        size_t cvSize = m_CurveVertices.size();

        dynamic_array<Vector2f> vertices(kMemTempJobAlloc);
        Vector4f border = esi.m_Border * (1.0f / esi.m_PixelsToUnit);
        Vector2f whsize = Vector2f(esi.m_TextureRect.width, esi.m_TextureRect.height);
        whsize = whsize * (1.0f / esi.m_PixelsToUnit);

        size_t startPoint = GetControlStartIndex(ei.m_StartPoint);
        size_t endPoint = GetControlStartIndex(ei.m_EndPoint);
        if (ei.m_Bottom)
        {
            startPoint = endPoint;
            endPoint = cvSize - 1;
        }
        size_t firstOffset = 0, lastOffset = 0;
        size_t pointsCount = vSize * m_FillInfo.m_SplineDetail;

        // Generate Intermediate Vertices for the 9-Splice.
        Vector2f v1 = m_CurveVertices[startPoint];
        Vector2f v2 = m_CurveVertices[startPoint + 1];
        Vector2f insertLeft = (v1 - v2);
        insertLeft = v1 + (Normalize(insertLeft) * border.x);

        Vector2f v3 = m_CurveVertices[endPoint];
        Vector2f v4 = m_CurveVertices[endPoint - 1];
        Vector2f insertRight = (v3 - v4);
        insertRight = v3 + (Normalize(insertRight) * border.z);

        float total = 0, extend = 0;
        float uvStart = border.x;
        float uvEnd = whsize.x - border.z;
        float uvInter = uvEnd - uvStart;

        vertices.reserve(vSize * m_FillInfo.m_SplineDetail);
        vertices.push_back(insertLeft);

        float totalSegmentSize = 0;
        for (size_t i = startPoint, j = 0; i < endPoint; ++i)
        {
            j = (i + 1);
            const float4 start = float4(m_CurveVertices[i].x, m_CurveVertices[i].y, 0, 0);
            const float4 end = float4(m_CurveVertices[j].x, m_CurveVertices[j].y, 0, 0);
            const float4 diff = end - start;
            totalSegmentSize = totalSegmentSize + length(diff);
        }

        float fUv = totalSegmentSize / uvInter;
        float floored = math::floor(fUv);
        size_t totalSegments = (fUv > floored) ? size_t(floored) + 1 : size_t(floored);
        uvInter = totalSegmentSize / (float)totalSegments;

        for (size_t i = startPoint, j = 0; i < endPoint; ++i)
        {
            j = (i + 1);
            float4 start = float4(m_CurveVertices[i].x, m_CurveVertices[i].y, 0, 0);
            const float4 end = float4(m_CurveVertices[j].x, m_CurveVertices[j].y, 0, 0);
            const float4 diff = end - start;
            const float4 step = normalize(diff);
            float4 inter = start;

            total = total + length(diff);
            vertices.push_back(Vector2f(start.x, start.y));

            while (total > uvInter)
            {
                float _uv = uvInter - extend;
                const float4 uv = float4(_uv);
                inter = start + (step * uv);
                vertices.push_back(Vector2f(inter.x, inter.y));
                total = total - uvInter;
                start = inter;
                extend = 0;
            }
            extend = total;
        }
        vertices.push_back(m_CurveVertices[endPoint]);
        vertices.push_back(insertRight);

        GenerateTiles(&ei, renderData, esi.m_Border, uvInter, vertices);
        renderData->m_Order = ei.m_RenderOrder;
    }
}

void SmartSpriteBuildJob::FillContour(dynamic_array<Vector2f>& resultVertices, const UInt32 detailForCollider)
{
    AssertMsg(m_Tess == NULL, "m_Tess cannot be NULL");
    size_t cpSize = m_ControlPoints.size();
    resultVertices.reserve(cpSize * m_FillInfo.m_SplineDetail);

    for (size_t j = 0; j < cpSize; ++j)
    {
        size_t k = (j == cpSize - 1) ? 0 : (j + 1);
        const Vector2f& p0 = m_ControlPoints[j].m_Position;
        const Vector2f& p1 = m_ControlPoints[k].m_Position;

        if (m_ControlPoints[j].m_Mode == kControlPointModeContinuous || m_ControlPoints[k].m_Mode == kControlPointModeContinuous || m_ControlPoints[j].m_RightMode == kTangentModeFree || m_ControlPoints[k].m_LeftMode == kTangentModeFree)
        {
            Vector2f rPos, lPos;
            SmartSprite::GetControlPointTangents(m_ControlPoints, j, k, p0, p1, lPos, rPos);
            Vector2f v[4] = { rPos, p0, p1, lPos };
            GenerateBezier(v, j, resultVertices, detailForCollider);
        }
        else
        {
            GenerateLinear(m_ControlPoints, j, k, resultVertices, detailForCollider);
        }
    }

    if (detailForCollider || DoesBuildBottom())
    {
        resultVertices.push_back(m_ControlPoints[0].m_Position);
    }
    if (IsContinousStrip() && 0 == detailForCollider)
    {
        m_Tess = tessNewTess(NULL);
        tessAddContour(m_Tess, kVertexSize, resultVertices.data(), sizeof(Vector2f), resultVertices.size());
        Tessellate(m_FillInfo.m_TextureScaledSize, m_RenderDataArray[0]);
    }
}

void SmartSpriteBuildJob::Tessellate(const Vector2f& qs, SmartSpriteData* renderData)
{
    int tessError = tessTesselate(m_Tess, TESS_WINDING_NONZERO, TESS_POLYGONS, kPolygonVertices, kVertexSize, NULL);
    Assert(tessError == 1);

    const int elemCount = tessGetElementCount(m_Tess);
    const TESSindex* elements = tessGetElements(m_Tess);
    const TESSreal* real = tessGetVertices(m_Tess);

    int index = 0;
    for (int e = 0; e < elemCount; ++e)
    {
        const int* idx = &elements[e * kPolygonVertices];

        // Extract vertices
        for (int i = 0; i < kPolygonVertices; ++i)
        {
            AssertMsg(idx[i] != TESS_UNDEF, "Invalid Tessellation Formed");
            float x = real[idx[i] * kVertexSize];
            float y = real[idx[i] * kVertexSize + 1];

            SpriteVertex vert;
            vert.pos.x = x;
            vert.pos.y = y;
            vert.pos.z = 0.0f;

            // calculate UV
            vert.uv.x = x / qs.x;
            vert.uv.y = y / qs.y;

            renderData->m_Indices.push_back(index++);
            renderData->m_Vertices.push_back(vert);
        }
    }

    AssertMsg(index == renderData->m_Vertices.size(), "Invalid indices after Tessellation");
    tessDeleteTess(m_Tess);
    m_Tess = NULL;
}
