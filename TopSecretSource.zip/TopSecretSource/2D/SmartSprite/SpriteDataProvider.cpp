#include "UnityPrefix.h"
#include "SpriteDataProvider.h"

#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Serialize/TransferFunctions/TransferNameConversions.h"

IMPLEMENT_REGISTER_CLASS(SpriteDataProvider, 325);

SpriteDataProvider::SpriteDataProvider(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
{
}

void SpriteDataProvider::ThreadedCleanup()
{
}
