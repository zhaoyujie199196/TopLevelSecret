#include "UnityPrefix.h"
#include "SmartSprite.h"
#include "SmartSpriteBuildJob.h"
#include "Runtime/Math/Simd/vec-math.h"
#include "Runtime/Math/Simd/vec-quat.h"
#include "Runtime/BaseClasses/MessageHandlerRegistration.h"
#include "Runtime/BaseClasses/SupportedMessageFlags.h"

using namespace math;

IMPLEMENT_REGISTER_CLASS(SmartSprite, 326);
IMPLEMENT_OBJECT_SERIALIZE(SmartSprite)

void SmartSprite::InitializeClass()
{
    REGISTER_MESSAGE_VOID(kOnWillRenderObject, OnWillRenderObject);
}

void SmartSprite::CleanupClass()
{
}

SmartSprite::SmartSprite(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
    , m_Angles(kMemSprites)
    , m_ControlPoints(kMemSprites)
    , m_Job(NULL)
    , m_FillScale(100.0f)
    , m_SplineDetail(16)
    , m_ColliderDetail(16)
    , m_BuildBottom(false)
    , m_RenderDataDirtyFlag(false)
    , m_ContinousStrip(true)
{
}

void SmartSprite::ThreadedCleanup()
{
    SyncFence(m_JobFence);
}

SupportedMessageFlags SmartSprite::CalculateSupportedMessages()
{
    return kHasOnWillRenderObject;
}

void SmartSprite::ResetData()
{
    // Defaults to Square.
    SmartSpriteControlPoint p;
    m_ControlPoints.clear();
    m_Angles.clear();
    p.m_Position = Vector2f(0.0f, 0.0f); m_ControlPoints.push_back(p);
    p.m_Position = Vector2f(0.0f, 1.0f); m_ControlPoints.push_back(p);
    p.m_Position = Vector2f(1.0f, 1.0f); m_ControlPoints.push_back(p);
    p.m_Position = Vector2f(1.0f, 0.0f); m_ControlPoints.push_back(p);
    m_BuildBottom = true;
    m_FillScale = 100.0f;
    m_SplineDetail = 16;
    m_ColliderDetail = 16;
    m_ContinousStrip = true;
    m_RenderDataDirtyFlag = true;
}

void SmartSprite::Reset()
{
    Super::Reset();
    ResetData();
}

void SmartSprite::SmartReset()
{
    Super::SmartReset();
    ResetData();
}

void SmartSprite::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);

    if (awakeMode & kInstantiateOrCreateFromCodeAwakeFromLoad && m_ControlPoints.empty())
        ResetData();

    SetRenderDataDirty();
}

void SmartSprite::GetTangents(size_t index1, size_t index2, TangentResults* res)
{
    Assert(index1 < m_ControlPoints.size() && index2 < m_ControlPoints.size());
    res->m_StartPos = m_ControlPoints[index1].m_Position;
    res->m_EndPos = m_ControlPoints[index2].m_Position;
    return SmartSprite::GetControlPointTangents(m_ControlPoints, index1, index2, res->m_StartPos, res->m_EndPos, res->m_LeftTangent, res->m_RightTangent);
}

Vector3f SmartSprite::GetCenter()
{
    Vector2f min, max;
    SmartSprite::FindBounds(m_ControlPoints, min, max);
    return Vector3f((max.x - min.x) * 0.5f, (max.y - min.y) * 0.5f, 0.0f);
}

Vector3f SmartSprite::GetExtent()
{
    Vector2f min, max;
    SmartSprite::FindBounds(m_ControlPoints, min, max);
    return Vector3f((max.x - min.x) * 0.5f, (max.y - min.y) * 0.5f, 1.0f);
}

size_t SmartSprite::GetRenderCount()
{
    return m_RenderDataArray.size();
}

const SpriteRenderData* SmartSprite::GetSpriteRenderData(size_t idx)
{
    Assert(idx < m_RenderDataArray.size());
    return &m_RenderDataArray[idx];
}

const UInt32 SmartSprite::GetDetail(size_t position) const
{
    Assert(position < m_ControlPoints.size());
    return m_ControlPoints[position].m_Detail;
}

const UInt32 SmartSprite::GetMode(size_t position) const
{
    Assert(position < m_ControlPoints.size());
    return m_ControlPoints[position].m_Mode;
}

void SmartSprite::InsertPointAt(size_t position, Vector2f value)
{
    SmartSpriteControlPoint p1;
    p1.m_Position = value;
    m_ControlPoints.insert(m_ControlPoints.begin() + position, p1);
    SetRenderDataDirty();
}

void SmartSprite::SetRotationAt(size_t position, float value, bool left)
{
    Assert(position < m_ControlPoints.size());
    if (left)
        m_ControlPoints[position].m_RotationLeft = value;
    else
        m_ControlPoints[position].m_RotationRight = value;
    SetRenderDataDirty();
}

void SmartSprite::SetDistanceAt(size_t position, float value, bool left)
{
    Assert(position < m_ControlPoints.size());
    if (left)
        m_ControlPoints[position].m_DistanceLeft = value;
    else
        m_ControlPoints[position].m_DistanceRight = value;
    SetRenderDataDirty();
}

void SmartSprite::SetPointAt(size_t position, Vector2f value)
{
    Assert(position < m_ControlPoints.size());
    m_ControlPoints[position].m_Position = value;
    SetRenderDataDirty();
}

void SmartSprite::SetContinousStrip(const bool val)
{
    if (val != m_ContinousStrip)
    {
        m_ContinousStrip = val;
        SetRenderDataDirty();
    }
}

void SmartSprite::SetDetail(size_t position, UInt32 detail)
{
    Assert(position < m_ControlPoints.size());
    if (detail != m_ControlPoints[position].m_Detail)
    {
        m_ControlPoints[position].m_Detail = detail;
        SetRenderDataDirty();
    }
}

void SmartSprite::SetMode(size_t position, UInt32 mode)
{
    Assert(mode < kControlPointModeTotal);
    if ((ControlPointMode)mode != m_ControlPoints[position].m_Mode)
    {
        m_ControlPoints[position].m_Mode = (ControlPointMode)mode;
        SetRenderDataDirty();
    }
}

void SmartSprite::RemovePointAt(size_t position)
{
    if (m_ControlPoints.size() > position)
    {
        m_ControlPoints.erase(m_ControlPoints.begin() + position);
        SetRenderDataDirty();
    }
}

void SmartSprite::SetColliderDetail(const UInt32 detail)
{
    UInt32 resultDetail = (detail < m_SplineDetail) ? detail : m_SplineDetail;
    if (resultDetail != m_ColliderDetail)
    {
        m_ColliderDetail = resultDetail;
        SetRenderDataDirty();
    }
}

void SmartSprite::SetBuildBottom(const bool buildBottom)
{
    if (buildBottom != m_BuildBottom)
    {
        m_BuildBottom = buildBottom;
        SetRenderDataDirty();
    }
}

void SmartSprite::SetFillSpriteScale(const float fillSpriteScale)
{
    if (fillSpriteScale != m_FillScale)
    {
        m_FillScale = fillSpriteScale;
        SetRenderDataDirty();
    }
}

void SmartSprite::SetSplineDetail(const UInt32 splineDetail)
{
    if (splineDetail != m_SplineDetail)
    {
        m_SplineDetail = splineDetail;
        if (m_ColliderDetail > m_SplineDetail)
            SetColliderDetail(m_SplineDetail);
        SetRenderDataDirty();
    }
}

static void SmartSpriteJob(SmartSpriteBuildJob* job)
{
    job->Execute();
}

void SmartSprite::OnWillRenderObject()
{
    if (m_RenderDataDirtyFlag)
    {
        if (NULL == m_Job)
        {
            m_Job = UNITY_NEW(SmartSpriteBuildJob, kMemTempJobAlloc) ();
            m_Job->MainThreadInit(this, m_ControlPoints, m_Angles, m_FillTex, m_BuildBottom, m_ContinousStrip);
            ScheduleJob(m_JobFence, &SmartSpriteJob, m_Job);
            m_RenderDataDirtyFlag = false;
        }
    }
}

void SmartSprite::SetRenderDataDirty()
{
    m_RenderDataDirtyFlag = true;
    SetDirty();
}

void SmartSprite::Sync()
{
    if (m_Job)
    {
        SyncFence(m_JobFence);
        m_Job->Integrate(this);
        UNITY_DELETE(m_Job, kMemTempJobAlloc);
    }
}

void SmartSprite::UpdateMesh(dynamic_array<SmartSpriteData*>& renderDataArray)
{
    size_t inputSize = renderDataArray.size();
    for (size_t i = 0; i < m_RenderDataArray.size(); ++i)
    {
        SpriteRenderData& rd = m_RenderDataArray[i];
        rd.ReleaseData();
    }
    m_RenderDataArray.clear();

    m_RenderDataArray.resize(inputSize);
    for (size_t i = 0; i < inputSize; ++i)
    {
        SmartSpriteData* data = renderDataArray[i];
        m_RenderDataArray.push_back(SpriteRenderData());
        SpriteRenderData& rd = m_RenderDataArray.back();
        rd.SetVertices(data->m_Vertices.begin(), data->m_Vertices.size());
        rd.SetIndices(data->m_Indices.begin(), data->m_Indices.size());
        rd.ClearUvCalculationPendingFlag();
        rd.texture = data->m_Texture;
    }
}

template<class TransferFunction>
void SmartSprite::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);

    TRANSFER(m_FillTex);
    TRANSFER(m_Angles);
    TRANSFER(m_ControlPoints);
    TRANSFER(m_FillScale);
    TRANSFER(m_SplineDetail);
    TRANSFER(m_ColliderDetail);
    TRANSFER(m_BuildBottom);
    TRANSFER(m_ContinousStrip);
    transfer.Align();
}

void SmartSprite::UpdateCollider(dynamic_array<Vector2f>& path)
{
    Polygon2D data;

    if (m_BuildBottom)
        data.SetPoints(path.begin(), path.size());
    else
        data.SetPoints(path.begin(), path.size() - m_ColliderDetail);

    SendMessage(kSetPolygon2D, &data, ClassID(Polygon2D));
}

#if UNITY_EDITOR
void SmartSprite::CycleMode(size_t position)
{
    Assert(position < m_ControlPoints.size());
    int mode = (int)m_ControlPoints[position].m_Mode;
    mode = ++mode % kControlPointModeTotal;
    m_ControlPoints[position].m_Mode = (ControlPointMode)mode;
    SetRenderDataDirty();
}

void SmartSprite::CycleSprite(size_t position)
{
    Assert(position < m_ControlPoints.size());
    m_ControlPoints[position].m_AngleSpriteIndex = ++m_ControlPoints[position].m_AngleSpriteIndex % MAX_SPRITES_PER_EDGE;
    SetRenderDataDirty();
}

#endif

/////
// Common Functions.

void SmartSprite::FindBounds(const SmartSprite::ControlPoints& controlPoints, Vector2f& min, Vector2f& max)
{
    min.x = min.y = (std::numeric_limits<float>::max)();
    max.x = max.y = -(std::numeric_limits<float>::max)();

    for (SmartSprite::ControlPoints::const_iterator it = controlPoints.begin(); it != controlPoints.end(); ++it)
    {
        min.x = std::min(it->m_Position.x, min.x);
        min.y = std::min(it->m_Position.y, min.y);
        max.x = std::max(it->m_Position.x, max.x);
        max.y = std::max(it->m_Position.y, max.y);
    }
}

UInt32 SmartSprite::GetControlPointDetail(const SmartSprite::ControlPoints& controlPoints, UInt32 defaultIndex, size_t position)
{
    Assert(position < controlPoints.size());
    UInt32 min = 1, detail = 1;
#if CONTROLPOINT_HASDETAIL
    detail = (0 == controlPoints[position].m_Detail) ? std::max(min, defaultIndex) : std::max(min, controlPoints[position].m_Detail);
#else
    detail = defaultIndex;
#endif
    return detail;
}

void SmartSprite::GetControlPointTangents(const SmartSprite::ControlPoints& controlPoints, size_t index1, size_t index2, Vector2f p0, Vector2f p1, Vector2f& leftTangent, Vector2f& rightTangent)
{
    UInt32 cpSize = controlPoints.size();
    static Quaternionf qp = AxisAngleToQuaternion(Vector3f::zAxis, Deg2Rad(90.0f));
    static Quaternionf qn = AxisAngleToQuaternion(Vector3f::zAxis, Deg2Rad(-90.0f));
    static const float4 _qp = float4(qp.x, qp.y, qp.z, qp.w);
    static const float4 _qn = float4(qn.x, qn.y, qn.z, qn.w);
    static const float4 _up = float4(0, 1.0f, 0, 0);
    static const float4 _left = float4(-1.0f, 0, 0, 0);
    static const float4 _right = float4(1.0f, 0, 0, 0);
    static const float4 _half = float4(0.5f, 0.5f, 0.5f, 0.5f);

    const float4 _p0 = float4(p0.x, p0.y, 0, 0);
    const float4 _p1 = float4(p1.x, p1.y, 0, 0);
    float4 res(ZERO);

    if (controlPoints[index1].m_Mode == kControlPointModeContinuous)
    {
        const Vector2f& prev = controlPoints[GetPrevCP(index1, cpSize)].m_Position;
        const Vector2f& next = controlPoints[GetNextCP(index1, cpSize)].m_Position;
        const Vector2f diff1 = next - prev;
        const Vector2f diff2 = next - p0;
        const float val = (diff1.x * diff2.y) - (diff2.x * diff1.y);

        const float4 _prev = float4(prev.x, prev.y, 0, 0);
        const float4 pp_p0 = _prev - _p0;
        const float4 p1_p0 = _p1 - _p0;

        float4 mid = normalize(pp_p0) + normalize(p1_p0);
        const float4 q = (val < 0) ? _qp : _qn;
        mid = quatMulVec(q, mid);
        res = _p0 + mid;
    }
    else if (controlPoints[index1].m_RightMode == kTangentModeFree || controlPoints[index1].m_Mode == kControlPointModeFree)
    {
        float rotR = Deg2Rad(controlPoints[index1].m_RotationRight);
        Quaternionf qr = AxisAngleToQuaternion(Vector3f::zAxis, rotR);
        const float4 q = float4(qr.x, qr.y, qr.z, qr.w);
        const float4 dist = float4(controlPoints[index1].m_DistanceRight);
        float4 mid = quatMulVec(q, _up);
        mid = normalize(mid) * dist;
        res = _p0 + mid;
    }
    else
    {
        const float4 p1_p0 = _p1 - _p0;
        res = normalize(p1_p0) + _p0;
    }
    rightTangent.x = res.x; rightTangent.y = res.y;

    if (controlPoints[index2].m_Mode == kControlPointModeContinuous)
    {
        const Vector2f& prev = controlPoints[GetPrevCP(index2, cpSize)].m_Position;
        const Vector2f& next = controlPoints[GetNextCP(index2, cpSize)].m_Position;
        const Vector2f diff1 = next - prev;
        const Vector2f diff2 = next - p1;
        const float val = (diff1.x * diff2.y) - (diff2.x * diff1.y);

        const float4 _next = float4(next.x, next.y, 0, 0);
        const float4 pp_p1 = _next - _p1;
        const float4 p0_p1 = _p0 - _p1;

        float4 mid = normalize(pp_p1) + normalize(p0_p1);
        const float4 q = (val > 0) ? _qp : _qn;
        mid = quatMulVec(q, mid);
        res = _p1 + mid;
    }
    else if (controlPoints[index2].m_LeftMode == kTangentModeFree || controlPoints[index2].m_Mode == kControlPointModeFree)
    {
        float rotL = Deg2Rad(controlPoints[index2].m_RotationLeft);
        Quaternionf qr = AxisAngleToQuaternion(Vector3f::zAxis, rotL);
        const float4 q = float4(qr.x, qr.y, qr.z, qr.w);
        const float4 dist = float4(controlPoints[index2].m_DistanceLeft);
        float4 mid = quatMulVec(q, _up);
        mid = normalize(mid) * dist;
        res = _p1 + mid;
    }
    else
    {
        const float4 p0_p1 = _p0 - _p1;
        res = normalize(p0_p1) + _p1;
    }
    leftTangent.x = res.x; leftTangent.y = res.y;
}

size_t SmartSprite::GetNextCP(size_t current, size_t size)
{
    return (current + 1) % size;
}

size_t SmartSprite::GetPrevCP(size_t current, size_t size)
{
    return (current == 0) ? (size - 1) : (current - 1);
}
