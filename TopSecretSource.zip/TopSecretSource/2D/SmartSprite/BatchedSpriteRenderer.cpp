#include "UnityPrefix.h"
#include "BatchedSpriteRenderer.h"

#include "Runtime/BaseClasses/MessageIdentifiers.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Serialize/TransferFunctions/TransferNameConversions.h"

#include "Runtime/BaseClasses/GameObject.h"
#include "Runtime/BaseClasses/SupportedMessageOptimization.h"
#include "Runtime/Camera/RenderManager.h"
#include "Runtime/GfxDevice/BatchRendering.h"
#include "Runtime/GfxDevice/ChannelAssigns.h"
#include "Runtime/GfxDevice/GfxDevice.h"
#include "Runtime/Graphics/SpriteFrame.h"
#include "Runtime/Graphics/Mesh/DynamicVBO.h"
#include "Runtime/Graphics/Mesh/MeshVertexFormat.h"
#include "Runtime/Graphics/Mesh/SpriteRenderer.h"
#include "Runtime/Graphics/Mesh/TransformVertex.h"
#include "Runtime/Math/Color.h"

#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Profiler/ExternalGraphicsProfiler.h"
#include "Runtime/2D/Common/SpriteDataProvider.h"

IMPLEMENT_REGISTER_CLASS(BatchedSpriteRenderer, 324);
IMPLEMENT_OBJECT_SERIALIZE()

static SHADERPROP(MainTex);

struct BatchedSpriteRenderingData
{
    Texture2D* texture;
    int batchCount;
    int batchDataIndex;
};
struct BatchData
{
    const SharedSpriteRenderData* sharedSpriteData;
    Texture2D* texture;
    Matrix4x4f transform;
    ColorRGBAf color;
};


BatchedSpriteRenderer::BatchedSpriteRenderer(MemLabelId label, ObjectCreationMode mode)
    : Super(kRendererSprite, label, mode)
{
    m_CastShadows = kShadowCastingOff;
    m_ReceiveShadows = false;
}

void BatchedSpriteRenderer::ThreadedCleanup()
{
}

void BatchedSpriteRenderer::InitializeClass()
{
    REGISTER_MESSAGE_PTR(BatchedSpriteRenderer, kDidAddComponent, OnDidAddComponent, Component);
}

void BatchedSpriteRenderer::CleanupClass()
{
}

template<class TransferFunction>
void BatchedSpriteRenderer::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);
    transfer.SetVersion(1);
    TRANSFER(m_SpriteRenderProvider);
}

void BatchedSpriteRenderer::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);
}

void BatchedSpriteRenderer::SmartReset()
{
    SetMaterialCount(1);
    SetMaterial(SpriteRenderer::GetDefaultSpriteMaterial(), 0);
}

void BatchedSpriteRenderer::UpdateLocalAABB()
{
    if (m_SpriteRenderProvider)
        m_TransformInfo.localAABB.SetCenterAndExtent(m_SpriteRenderProvider->GetCenter(), m_SpriteRenderProvider->GetExtent());
    else
        m_TransformInfo.localAABB.SetCenterAndExtent(Vector3f::zero, Vector3f::zero);
}

inline ColorRGBA32 BatchedSpriteRendererGetDeviceColor(const ColorRGBAf& color, GfxDevice& device)
{
    if (GetActiveColorSpace() == kLinearColorSpace)
        return device.ConvertToDeviceVertexColor(GammaToActiveColorSpace(color));
    else
        return device.ConvertToDeviceVertexColor(color);
}

void BatchedSpriteRenderer_RenderSprites(const BatchData* batchDatas, ShaderPropertySheet& props, size_t idxStart, int idxEnd, size_t totalIndices, size_t totalVertices, const ChannelAssigns& channels)
{
    if (totalVertices == 0 || totalIndices == 0)
        return;

    GfxDevice& device = GetGfxDevice();
    UInt32 expectedFence = device.GetNextCPUFence();

    // Generate VBO for tiles
    DynamicVBO& vbo = device.GetDynamicVBO();
    DynamicVBOChunkHandle handle;
    const UInt32 channelMask = CalculateSpriteChannelMask(channels);
    size_t vertStride = CalculateVertexSize(channelMask);
    if (!vbo.GetChunk(vertStride, totalVertices, totalIndices, kPrimitiveTriangles, &handle))
        return;

    UInt8*  vbPtr = (UInt8*)handle.vbPtr;
    UInt16* ibPtr = (UInt16*)handle.ibPtr;

    PPtr<Texture2D> spriteTexture(0);
    size_t vertIdx = 0;
    for (size_t idx = idxStart; idx != idxEnd; ++idx)
    {
        Assert(batchDatas[idx].texture && batchDatas[idx].sharedSpriteData);
        const SharedSpriteRenderData& sharedSpriteRenderData = *batchDatas[idx].sharedSpriteData;
        UInt32 numIndices = sharedSpriteRenderData.GetIndices().size();
        UInt32 numVertices = sharedSpriteRenderData.GetVertices().size();
        if (!numIndices || !numVertices)
            continue;

        spriteTexture = batchDatas[idx].texture;
        sharedSpriteRenderData.AddRef();

        const Matrix4x4f& xform = batchDatas[idx].transform;

        const SpriteVertex* srcVertices = sharedSpriteRenderData.GetVertices().data();
        const UInt16* srcIndices = sharedSpriteRenderData.GetIndices().data();
        TransformSprite(vbPtr, ibPtr, channelMask, &xform, srcVertices, numVertices, srcIndices, numIndices, BatchedSpriteRendererGetDeviceColor(batchDatas[idx].color, device), vertIdx);
        vertIdx += numVertices;

        sharedSpriteRenderData.Release();
    }
    vbo.ReleaseChunk(handle, totalVertices, totalIndices);

    // Set up properties for shader
    if (spriteTexture.IsValid()) //TODO@2D - code below mutates property sheet during rendering. Fix!
    {
        // BUGFIX 582080: Use padded representation in case of NPOT->POT runtime conversion.
        props.SetTextureWithExplicitSize(kSLPropMainTex, spriteTexture->GetUnscaledTextureID(),
            spriteTexture->GetDataWidth(), spriteTexture->GetDataHeight(),
            spriteTexture->GetTexelSizeX(), spriteTexture->GetTexelSizeY());
    }
    else
    {
        props.SetTextureWithExplicitSize(kSLPropMainTex, TextureID(), 0, 0, 0, 0);
    }
    props.ComputeHash();
    device.SetShaderPropertiesShared(props);

    vbo.DrawChunk(handle, channels, channelMask, DefaultMeshVertexFormat(channelMask).GetVertexDecl(channels.GetSourceMap()));

    // Insert fence after batching is complete
    UInt32 fence = device.InsertCPUFence();
    Assert(fence == expectedFence);
    //GPU_TIMESTAMP();
}

void BatchedSpriteRenderer_Render(const RenderNodeQueue& queue, UInt32 nodeID, const ChannelAssigns& channels, int materialIndex)
{
    const RenderNode& node = queue.GetNode(nodeID);
    const BatchedSpriteRenderingData& renderingData = *(BatchedSpriteRenderingData*)queue.GetAdditionalData(node.rendererSpecificDataIndex);
    const BatchData* batchData = (BatchData*)queue.GetAdditionalData(renderingData.batchDataIndex);

    Texture2D* firstTexture = batchData[0].texture;
    const SharedSpriteRenderData& firstSharedSpriteData = *batchData[0].sharedSpriteData;

    size_t numIndicesBatch = firstTexture ? firstSharedSpriteData.GetIndices().size() : 0;
    size_t numVerticesBatch = firstTexture ? firstSharedSpriteData.GetVertices().size() : 0;
    int idxStart = 0;
    int idxEnd = renderingData.batchCount;
    for (size_t idx = 1; idx < idxEnd; ++idx)
    {
        Texture2D* texture = batchData[idx].texture;
        const SharedSpriteRenderData& sharedSpriteRenderData = *batchData[idx].sharedSpriteData;
        UInt32 numIndices = sharedSpriteRenderData.GetIndices().size();
        UInt32 numVertices = sharedSpriteRenderData.GetVertices().size();
        Assert(numIndices && numVertices);

        // Check if texture has changed
        if (texture != firstTexture)
        {
            if (numIndicesBatch)
                BatchedSpriteRenderer_RenderSprites(batchData, *node.customProperties, idxStart, idx, numIndicesBatch, numVerticesBatch, channels);

            numIndicesBatch = 0;
            numVerticesBatch = 0;
            idxStart = idx;
            firstTexture = texture;
        }

        // Check for number of indices
        if ((numIndicesBatch + numIndices) <= 2048)
        {
            numIndicesBatch += numIndices;
            numVerticesBatch += numVertices;
        }
        else
        {
            if (numIndicesBatch)
            {
                BatchedSpriteRenderer_RenderSprites(batchData, *node.customProperties, idxStart, idx, numIndicesBatch, numVerticesBatch, channels);
                numIndicesBatch = numIndices;
                numVerticesBatch = numVertices;
                idxStart = idx;
            }
            else // Can't fit in one draw call
            {
                idxStart = idx;
                BatchedSpriteRenderer_RenderSprites(batchData, *node.customProperties, idxStart, idx + 1, numIndices, numVertices, channels);
                idxStart++;
            }
        }
    }

    if (idxStart != idxEnd)
        BatchedSpriteRenderer_RenderSprites(batchData, *node.customProperties, idxStart, idxEnd, numIndicesBatch, numVerticesBatch, channels);
}

inline bool IsSpriteRenderDataValid(const SpriteRenderData* rd)
{
    return (rd && rd->texture.IsValid());
}

UInt32 BatchedSpriteRenderer::AddAsRenderNode(RenderNodeQueue& queue, const RenderNode::SourceData& sourceData)
{
    if (m_SpriteRenderProvider.IsNull())
        return RenderNode::kInvalid;

    // Sync for any Internal Jobs.
    m_SpriteRenderProvider->Sync();

    size_t spriteIndex = 0;
    size_t spriteCount = m_SpriteRenderProvider->GetRenderCount();
    if (spriteCount == 0)
        return RenderNode::kInvalid;

    // Set initial texture
    const SpriteRenderData* firstSpriteRenderData = NULL;
    for (; spriteIndex < spriteCount; ++spriteIndex)
    {
        const SpriteRenderData* rd = m_SpriteRenderProvider->GetSpriteRenderData(spriteIndex);
        if (!IsSpriteRenderDataValid(rd))
            continue;

        firstSpriteRenderData = rd;
        break;
    }
    if (!firstSpriteRenderData)
        return RenderNode::kInvalid;

    UInt32 nodeID = BaseRenderer::FlattenToRenderQueue(queue, sourceData);
    RenderNode& node = queue.GetNode(nodeID);
    node.type = kRendererSprite;
    node.executeCallback = BatchedSpriteRenderer_Render;

    // release the previous AddRef (done in BaseRenderer::FlattenToRenderQueue)
    if (node.customProperties)
        node.customProperties->Release();

    // use GetCustomPropertiesRememberToUpdateHash
    node.customProperties = &GetCustomPropertiesRememberToUpdateHash(); //TODO@2D - code below mutates property sheet during rendering. Fix!
    node.customPropertiesHash = node.customProperties->GetLastComputedHash();
    node.customProperties->AddRef();

    dynamic_array<BatchData> spriteBatchDataIn;
    spriteBatchDataIn.reserve(spriteCount - spriteIndex);

    // Acquire the shared data
    BatchData firstBatch =
    {
        firstSpriteRenderData->AcquireSharedData(),
        firstSpriteRenderData->texture,
        m_SpriteRenderProvider->GetTransformMatrix(0),
        m_SpriteRenderProvider->GetColor(0)
    };
    spriteBatchDataIn.push_back(firstBatch);

    // add the rest if they're valid
    for (; spriteIndex < spriteCount; ++spriteIndex)
    {
        const SpriteRenderData* spriteRenderData = m_SpriteRenderProvider->GetSpriteRenderData(spriteIndex);
        if (!IsSpriteRenderDataValid(spriteRenderData))
            continue;

        const SharedSpriteRenderData& sharedSpriteRenderData = spriteRenderData->GetSharedData();
        UInt32 numIndices = sharedSpriteRenderData.GetIndices().size();
        UInt32 numVertices = sharedSpriteRenderData.GetVertices().size();
        if (!numIndices || !numVertices)
            continue;

        // Acquire the shared data
        BatchData addBatch =
        {
            spriteRenderData->AcquireSharedData(),
            spriteRenderData->texture,
            m_SpriteRenderProvider->GetTransformMatrix(spriteIndex),
            m_SpriteRenderProvider->GetColor(spriteIndex)
        };
        spriteBatchDataIn.push_back(addBatch);
    }

    int batchDataIndex = queue.ReserveAdditionalData(spriteBatchDataIn.size() * sizeof(BatchData));
    node.rendererSpecificDataIndex = queue.ReserveAdditionalData(sizeof(BatchedSpriteRenderingData));

    BatchedSpriteRenderingData& renderingData = *(BatchedSpriteRenderingData*)queue.GetAdditionalData(node.rendererSpecificDataIndex);
    BatchData* spriteBatchDataOut = (BatchData*)queue.GetAdditionalData(batchDataIndex);
    memcpy(spriteBatchDataOut, &spriteBatchDataIn[0], spriteBatchDataIn.size() * sizeof(BatchData));
    renderingData.batchDataIndex = batchDataIndex;
    renderingData.batchCount = spriteBatchDataIn.size();

    return nodeID;
}

// This assumes Materials are the same. Might need revisiting in the near future.
void BatchedSpriteRenderer::Render(int materialIndex, const ChannelAssigns& channels)
{
    if (m_SpriteRenderProvider.IsNull())
        return;

    // Sync for any Internal Jobs.
    m_SpriteRenderProvider->Sync();

    size_t idxStart = 0;
    size_t idxEnd = m_SpriteRenderProvider->GetRenderCount();
    if (idxEnd == 0)
        return;

    // Set initial texture
    const SpriteRenderData* spriteRenderData = m_SpriteRenderProvider->GetSpriteRenderData(0);
    if (!spriteRenderData)
        return;

    PPtr<Texture2D> texture = spriteRenderData->texture;
    const SharedSpriteRenderData& sharedSpriteRenderDataStart = spriteRenderData->GetSharedData();

    if (sharedSpriteRenderDataStart.GetVertices().size() > 0 && sharedSpriteRenderDataStart.GetIndices().size() > 0)
        sharedSpriteRenderDataStart.AddRef();

    size_t numIndicesBatch = texture.IsValid() ? sharedSpriteRenderDataStart.GetIndices().size() : 0;
    size_t numVerticesBatch = texture.IsValid() ? sharedSpriteRenderDataStart.GetVertices().size() : 0;

    for (size_t idx = 1; idx < idxEnd; ++idx)
    {
        const SpriteRenderData* spriteRenderData = m_SpriteRenderProvider->GetSpriteRenderData(idx);
        if (!spriteRenderData || !spriteRenderData->texture.IsValid())
            continue;

        const SharedSpriteRenderData& sharedSpriteRenderData = spriteRenderData->GetSharedData();
        UInt32 numIndices = sharedSpriteRenderData.GetIndices().size();
        UInt32 numVertices = sharedSpriteRenderData.GetVertices().size();
        if (!numIndices || !numVertices)
            continue;

        {
            sharedSpriteRenderData.AddRef();

            // Check if texture has changed
            if (spriteRenderData->texture != texture)
            {
                if (numIndicesBatch)
                {
                    RenderSprites(idxStart, idx, numIndicesBatch, numVerticesBatch, channels);
                }
                numIndicesBatch = 0;
                numVerticesBatch = 0;
                idxStart = idx;
                texture = spriteRenderData->texture;
            }

            // Check for number of indices
            if ((numIndicesBatch + numIndices) <= 2048)
            {
                numIndicesBatch += numIndices;
                numVerticesBatch += numVertices;
            }
            else
            {
                if (numIndicesBatch)
                {
                    RenderSprites(idxStart, idx, numIndicesBatch, numVerticesBatch, channels);
                    numIndicesBatch = numIndices;
                    numVerticesBatch = numVertices;
                    idxStart = idx;
                }
                else // Can't fit in one draw call
                {
                    idxStart = idx;
                    RenderSprites(idxStart, idx + 1, numIndices, numVertices, channels);
                    idxStart++;
                }
            }

            sharedSpriteRenderData.Release();
        }
    }

    if (sharedSpriteRenderDataStart.GetVertices().size() > 0 && sharedSpriteRenderDataStart.GetIndices().size() > 0)
        sharedSpriteRenderDataStart.Release();

    if (idxStart != idxEnd)
    {
        RenderSprites(idxStart, idxEnd, numIndicesBatch, numVerticesBatch, channels);
    }
}

void BatchedSpriteRenderer::RenderSprites(size_t idxStart, int idxEnd, size_t totalIndices, size_t totalVertices, const ChannelAssigns& channels)
{
    if (m_SpriteRenderProvider.IsNull())
        return;

    if (totalVertices == 0 || totalIndices == 0)
        return;

    GfxDevice& device = GetGfxDevice();
    UInt32 expectedFence = device.GetNextCPUFence();

    // Generate VBO for tiles
    DynamicVBO& vbo = device.GetDynamicVBO();
    DynamicVBOChunkHandle handle;
    const UInt32 channelMask = CalculateSpriteChannelMask(channels);
    size_t vertStride = CalculateVertexSize(channelMask);
    if (!vbo.GetChunk(vertStride, totalVertices, totalIndices, kPrimitiveTriangles, &handle))
        return;

    UInt8*  vbPtr = (UInt8*)handle.vbPtr;
    UInt16* ibPtr = (UInt16*)handle.ibPtr;

    PPtr<Texture2D> spriteTexture(0);
    size_t vertIdx = 0;
    for (size_t idx = idxStart; idx != idxEnd; ++idx)
    {
        const SpriteRenderData* spriteRenderData = m_SpriteRenderProvider->GetSpriteRenderData(idx);
        if (!spriteRenderData || !spriteRenderData->texture.IsValid())
            continue;

        const SharedSpriteRenderData& sharedSpriteRenderData = spriteRenderData->GetSharedData();
        UInt32 numIndices = sharedSpriteRenderData.GetIndices().size();
        UInt32 numVertices = sharedSpriteRenderData.GetVertices().size();
        if (!numIndices || !numVertices)
            continue;

        spriteTexture = spriteRenderData->texture;
        sharedSpriteRenderData.AddRef();

        Matrix4x4f xform = m_SpriteRenderProvider->GetTransformMatrix(idx);

        const SpriteVertex* srcVertices = sharedSpriteRenderData.GetVertices().data();
        const UInt16* srcIndices = sharedSpriteRenderData.GetIndices().data();
        TransformSprite(vbPtr, ibPtr, channelMask, &xform, srcVertices, numVertices, srcIndices, numIndices, BatchedSpriteRendererGetDeviceColor(m_SpriteRenderProvider->GetColor(idx), device), vertIdx);
        vertIdx += numVertices;

        sharedSpriteRenderData.Release();
    }
    vbo.ReleaseChunk(handle, totalVertices, totalIndices);

    // Set up properties for shader
    ShaderPropertySheet& props = GetCustomPropertiesRememberToUpdateHash(); //TODO@2D - code below mutates property sheet during rendering. Fix!
    if (spriteTexture.IsValid())
    {
        // BUGFIX 582080: Use padded representation in case of NPOT->POT runtime conversion.
        props.SetTextureWithExplicitSize(kSLPropMainTex, spriteTexture->GetUnscaledTextureID(),
            spriteTexture->GetDataWidth(), spriteTexture->GetDataHeight(),
            spriteTexture->GetTexelSizeX(), spriteTexture->GetTexelSizeY());
    }
    else
    {
        props.SetTextureWithExplicitSize(kSLPropMainTex, TextureID(), 0, 0, 0, 0);
    }
    props.ComputeHash();
    device.SetShaderPropertiesShared(props);

    vbo.DrawChunk(handle, channels, channelMask, DefaultMeshVertexFormat(channelMask).GetVertexDecl(channels.GetSourceMap()));

    // Insert fence after batching is complete
    UInt32 fence = device.InsertCPUFence();
    Assert(fence == expectedFence);
    GPU_TIMESTAMP();
}

void BatchedSpriteRenderer::OnDidAddComponent(Component* com)
{
    if (com)
    {
        SpriteDataProvider* spriteRenderProvider = dynamic_pptr_cast<SpriteDataProvider*>(com);
        if (spriteRenderProvider)
            m_SpriteRenderProvider = PPtr<SpriteDataProvider>(spriteRenderProvider->GetInstanceID());
    }
}
