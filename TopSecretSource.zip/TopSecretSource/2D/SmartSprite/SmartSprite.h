#pragma once
#include "Configuration/UnityConfigure.h"
#include "Runtime/GameCode/Behaviour.h"
#include "Runtime/Graphics/Renderer.h"
#include "Runtime/Math/Vector2.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Graphics/SpriteFrame.h"
#include "Runtime/2D/Common/SpriteDataProvider.h"
#include "Runtime/Jobs/Jobs.h"

#define DEG2RAD_(x) x * (3.14159265358979323846f/180.0f)
#define RAD2DEG_(x) x * (180.0f/3.14159265358979323846f)
#define MAX_SPRITES_PER_EDGE    16

typedef dynamic_array<PPtr<Sprite> > SpriteArray;
class SmartSpriteBuildJob;

struct TESStesselator;

/**

   Points can be in these states
   - Continuous mode: The rotation is determined by the neighbour points
   - Broken: This is the end and the start of the next segment

   Left/Right Modes:
   - Linear: This makes a straight line
   - Free:   Custom rotation for this side only

 */
enum ControlPointMode
{
    kControlPointModeBreak,            // Breaks to form a new Segment.
    kControlPointModeContinuous,       // Auto
    kControlPointModeFree,                     // Free
    kControlPointModeTotal
};

enum ControlPointTangentMode
{
    kTangentModeLinear,
    kTangentModeFree,
    kTangentModeTotal
};

struct AngleRange
{
    DECLARE_SERIALIZE(AngleRange)
    float m_Start;
    float m_End;
    SpriteArray m_Sprites;
};

template<class TransferFunction>
void AngleRange::Transfer(TransferFunction& transfer)
{
    TRANSFER(m_Start);
    TRANSFER(m_End);
    TRANSFER(m_Sprites);
}

struct SmartSpriteControlPoint
{
    DECLARE_SERIALIZE(SmartSpriteControlPoint)
    Vector2f m_Position;
    float m_RotationLeft;
    float m_RotationRight;
    float m_DistanceLeft;
    float m_DistanceRight;
    UInt32 m_Detail;
    UInt32 m_Mode;                  ///< enum { Break = 0, Continuous, Free }
    UInt32 m_LeftMode;              ///< enum { Linear = 0, Free }
    UInt32 m_RightMode;             ///< enum { Linear = 0, Free }
    UInt32 m_AngleSpriteIndex;

    SmartSpriteControlPoint()
        : m_Position(0, 0)
        , m_RotationLeft(0)
        , m_RotationRight(180)
        , m_DistanceLeft(1.0f)
        , m_DistanceRight(1.0f)
        , m_Detail(16)
        , m_Mode(kControlPointModeBreak)
        , m_LeftMode(kTangentModeLinear)
        , m_RightMode(kTangentModeLinear)
        , m_AngleSpriteIndex(0)
    {
    }
};

template<class TransferFunction>
void SmartSpriteControlPoint::Transfer(TransferFunction& transfer)
{
    TRANSFER(m_Position);
    TRANSFER(m_RotationLeft);
    TRANSFER(m_RotationRight);
    TRANSFER(m_DistanceLeft);
    TRANSFER(m_DistanceRight);
    TRANSFER(m_Detail);
    TRANSFER(m_Mode);
    TRANSFER(m_LeftMode);
    TRANSFER(m_RightMode);
    TRANSFER(m_AngleSpriteIndex);
}

struct SmartSpriteData
{
    PPtr<Texture2D> m_Texture;
    dynamic_array<SpriteVertex> m_Vertices;
    dynamic_array<UInt16> m_Indices;
    int m_Order;

    // SpriteData
    SmartSpriteData()
        : m_Vertices(kMemTempJobAlloc)
        , m_Indices(kMemTempJobAlloc)
        , m_Order(0)
    {
    }
};

// Keep this struct in sync with the one defined in "SmartSprite.bindings"
struct TangentResults
{
    Vector2f m_StartPos;
    Vector2f m_EndPos;
    Vector2f m_LeftTangent;
    Vector2f m_RightTangent;
};

class SmartSprite : public SpriteDataProvider
{
    REGISTER_CLASS(SmartSprite);
    DECLARE_OBJECT_SERIALIZE();
public:

    typedef std::vector<SpriteRenderData>           RenderDatas;
    typedef dynamic_array<SmartSpriteControlPoint>  ControlPoints;
    typedef dynamic_array<AngleRange>               AngleRanges;
    typedef dynamic_array<Vector2f>                 ColliderPath;

    SmartSprite(MemLabelId label, ObjectCreationMode mode);
    // ~SmartSprite ();  declared-by-macro

    static void InitializeClass();
    static void CleanupClass();

    static void GetControlPointTangents(const SmartSprite::ControlPoints& controlPoints, size_t index1, size_t index2, Vector2f p0, Vector2f p1, Vector2f& leftTangent, Vector2f& rightTangent);
    static void FindBounds(const SmartSprite::ControlPoints& controlPoints, Vector2f& min, Vector2f& max);
    static UInt32 GetControlPointDetail(const SmartSprite::ControlPoints& controlPoints, UInt32 defaultIndex, size_t position);

    GET_SET_DIRTY(PPtr<Texture2D>, FillSprite, m_FillTex)

    const bool GetContinousStrip() const
    {
        return m_ContinousStrip;
    }

    const UInt32 GetSplineDetail() const
    {
        return m_SplineDetail;
    }

    const UInt32 GetColliderDetail() const
    {
        return m_ColliderDetail;
    }

    const bool GetBuildBottom() const
    {
        return m_BuildBottom;
    }

    const float GetFillSpriteScale() const
    {
        return m_FillScale;
    }

    const ControlPoints& GetControlPoints()
    {
        return m_ControlPoints;
    }

    virtual Matrix4x4f GetTransformMatrix(size_t idx)
    {
        return Matrix4x4f::identity;
    }

    virtual ColorRGBAf GetColor(size_t idx)
    {
        return ColorRGBAf(1.0f, 1.0f, 1.0f, 1.0f);
    }

    void AwakeFromLoad(AwakeFromLoadMode awakeMode);
    void GetTangents(size_t index1, size_t index2, TangentResults* res);
    void MessageIdentifier::OptimizedMessageMask CalculateSupportedMessages();
    size_t GetRenderCount();
    Vector3f GetCenter();
    Vector3f GetExtent();
    const UInt32 GetMode(size_t position) const;
    const UInt32 GetDetail(size_t position) const;
    const SpriteRenderData* GetSpriteRenderData(size_t idx);

    void Reset();
    void SmartReset();
    void SetRenderDataDirty();
    void UpdateMesh(dynamic_array<SmartSpriteData*>& renderDataArray);
    void UpdateCollider(dynamic_array<Vector2f>& path);

    // Job Sync.
    void Sync();

    // NOTE: These are the only three calls that should be used to manipulate Control Points.
    void SetPointAt(size_t position, Vector2f value);
    void SetRotationAt(size_t position, float value, bool left);
    void SetDistanceAt(size_t position, float value, bool left);
    void InsertPointAt(size_t position, Vector2f value);
    void RemovePointAt(size_t position);

    // Control Point Property Set.
    void SetMode(size_t position, UInt32 mode);
    void SetColliderDetail(const UInt32 detail);
    void SetDetail(size_t position, UInt32 detail);
    void SetBuildBottom(const bool dontBuildBottom);
    void SetFillSpriteScale(const float fillSpriteScale);
    void SetSplineDetail(const UInt32 splineDetail);
    void SetContinousStrip(const bool val);

#if UNITY_EDITOR
    void CycleMode(size_t position);
    void CycleSprite(size_t position);
#endif

private:
    PPtr<Texture2D> m_FillTex;
    RenderDatas m_RenderDataArray;
    AngleRanges m_Angles;
    ControlPoints m_ControlPoints;

    JobFence m_JobFence;
    SmartSpriteBuildJob* m_Job;
    float m_FillScale;
    UInt32 m_SplineDetail;             ///< enum { Linear = 1, MediumAccuracy = 4, HighAccuracy = 16 }
    UInt32 m_ColliderDetail;            ///< enum { Linear = 1, MediumAccuracy = 4, HighAccuracy = 16 }
    bool m_BuildBottom;
    bool m_RenderDataDirtyFlag;
    bool m_ContinousStrip;

    static size_t GetNextCP(size_t current, size_t size);
    static size_t GetPrevCP(size_t current, size_t size);

    void ResetData();
};
