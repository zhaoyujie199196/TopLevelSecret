#pragma once

#include "Configuration/UnityConfigure.h"

#include "Runtime/BaseClasses/BaseObject.h"
#include "Runtime/BaseClasses/GameObject.h"
#include "Runtime/Math/Color.h"
#include "Runtime/Math/Matrix4x4.h"
#include "Runtime/Math/Vector3.h"

class Sprite;
struct SpriteRenderData;
struct SpriteVertex;
class Texture2D;

class EXPORT_COREMODULE SpriteDataProvider : public Unity::Component
{
    REGISTER_CLASS_TRAITS(kTypeIsAbstract);
    REGISTER_CLASS(SpriteDataProvider);
public:
    SpriteDataProvider(MemLabelId label, ObjectCreationMode mode);

    static void InitializeClass();
    static void CleanupClass();

    virtual void Sync() {}
    virtual size_t GetRenderCount() { return 0; }
    virtual const SpriteRenderData* GetSpriteRenderData(size_t idx) { return NULL; }

    virtual Matrix4x4f GetTransformMatrix(size_t idx) { return Matrix4x4f::identity;  }
    virtual ColorRGBAf GetColor(size_t idx) { return ColorRGBAf(1.0f, 1.0f, 1.0f, 1.0f); }

    virtual Vector3f GetCenter() { return Vector3f::zero; }
    virtual Vector3f GetExtent() { return Vector3f::zero; }
};
