#pragma once
#include "SmartSprite.h"

struct SmartSpriteInfo
{
    Vector4f m_Border;
    Vector2f m_Size;
    Vector2f m_SizeInUnits;
    Vector2f m_TextureDataSize;
    Vector2f m_TextureScaledSize;
    Rectf m_TextureRect;
    float m_PixelsToUnit;
    UInt32 m_SplineDetail;
    UInt32 m_ColliderDetail;
    PPtr<Texture2D> m_Texture;

    // Sensible defaults
    SmartSpriteInfo()
        : m_Size(32.0f, 32.0f)
        , m_SizeInUnits(1.0f, 1.0f)
        , m_TextureDataSize(32.0f, 32.0f)
        , m_TextureScaledSize(32.0f, 32.0f)
        , m_PixelsToUnit(32.0f)
        , m_SplineDetail(1)
        , m_ColliderDetail(1)
    {
    }
};

struct SmartSpriteAngle
{
    float m_Start;
    float m_End;
    dynamic_array<SmartSpriteInfo>* m_Sprites;

    SmartSpriteAngle()
        : m_Start(0)
        , m_End(0)
        , m_Sprites(NULL)
    {
    }
};

struct SmartSpriteEdge
{
    int m_StartPoint;
    int m_EndPoint;
    int m_RenderOrder;
    int m_ArrayIndex;
    int m_SpriteIndex;
    int m_Bottom;

    // Defaults.
    SmartSpriteEdge(const int arrayIndex)
        : m_StartPoint(0)
        , m_EndPoint(0)
        , m_RenderOrder(0)
        , m_ArrayIndex(arrayIndex)
        , m_SpriteIndex(0)
        , m_Bottom(0)
    {
    }
};

class SmartSpriteBuildJob
{
private:

    typedef dynamic_array<SmartSpriteEdge>  SmartSpriteEdgeArray;
    typedef dynamic_array<SmartSpriteAngle> SmartSpriteAngleArray;
    typedef dynamic_array<SmartSpriteData*> SmartSpriteDataArray;

public:

    static const int kVertexSize = 2;
    static const int kPolygonVertices = 3;

    SmartSpriteBuildJob();
    void MainThreadInit(SmartSprite* sprite, const SmartSprite::ControlPoints& points, SmartSprite::AngleRanges& angles, PPtr<Texture2D> f, bool buildBottom, bool continousStrip);
    unsigned int Execute();
    bool Integrate(SmartSprite* sprite);

private:

    bool IsContinousStrip()     { return m_ContinousStrip; }
    bool DoesBuildBottom()      { return m_BuildBottom; }

    int SetupData();
    size_t GetControlStartIndex(size_t position);
    void FillContour(dynamic_array<Vector2f>& resultVertices, const UInt32 detailForCollider = 0);
    void FillEdges();
    void Tessellate(const Vector2f& qs, SmartSpriteData* renderData);

    void GenerateLinear(const SmartSprite::ControlPoints& inputs, const size_t startPoint, const size_t endPoint, dynamic_array<Vector2f>& outputs, const UInt32 forcedDetail);
    void GenerateBezier(const Vector2f* v, const size_t pt, dynamic_array<Vector2f>& outputs, const UInt32 forcedDetail);
    bool GenerateTiles(SmartSpriteEdge* edgeInfo, SmartSpriteData* renderData, const Vector4f& border, const float refDistance, dynamic_array<Vector2f>& segment);

    void Terminate();

    TESStesselator* m_Tess;
    SmartSpriteInfo m_FillInfo;

    SmartSpriteDataArray m_RenderDataArray;
    SmartSpriteAngleArray m_Angles;
    SmartSpriteEdgeArray m_Edges;
    dynamic_array<Vector2f> m_Vertices;
    dynamic_array<Vector2f> m_CurveVertices;
    dynamic_array<Vector2f> m_ColliderPoints;
    SmartSprite::ControlPoints m_ControlPoints;

    bool m_BuildBottom;
    bool m_ContinousStrip;
};
