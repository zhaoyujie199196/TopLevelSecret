#pragma once
#include "Runtime/Math/Vector2.h"
#include "Runtime/Math/Vector3.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"

enum SpritePackingMode
{
    kSPMTight = 0,
    kSPMRectangle
};

enum SpriteMeshType
{
    kSpriteMeshTypeFullRect = 0,
    kSpriteMeshTypeTight = 1
};

enum SpritePackingRotation
{
    kSPRNone = 0,
    kSPRFlipHorizontal,
    kSPRFlipVertical,
    kSPRRotate180,
    kSPRRotate90,
    kSPRAny = 5
};

enum SpriteRenderDataMode
{
    kSpriteRenderDataModeAutoDetect,
    kSpriteRenderDataModeAtlas,
    kSpriteRenderDataModeNotAtlas
};

struct SpriteSettings
{
#if UNITY_BIG_ENDIAN
    UInt32 reserved        : 25;
    UInt32 meshType        :  1; // SpriteMeshType
    UInt32 packingRotation :  4; // SpritePackingRotation
    UInt32 packingMode     :  1; // SpritePackingMode
    UInt32 packed          :  1; // bool
#else
    UInt32 packed          :  1; // bool
    UInt32 packingMode     :  1; // SpritePackingMode
    UInt32 packingRotation :  4; // SpritePackingRotation
    UInt32 meshType        :  1; // SpriteMeshType
    UInt32 reserved        : 25;
#endif
};
