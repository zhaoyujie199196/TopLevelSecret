#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "Runtime/Testing/TestFixtures.h"
#include "Runtime/Testing/Testing.h"
#include "Runtime/2D/SpriteTiling/TilingShapeGenerator.h"
#include "Runtime/Geometry/Polygon2D.h"
#include "Runtime/Jobs/JobTypes.h"
#include "Runtime/Jobs/Jobs.h"
#include "Runtime/Testing/ParametricTest.h"

#include "Runtime/2D/SpriteTiling/TilingShapeGeneratorTests_ExpectedData.inc.h"

struct GenerateTilingAreaInfo;
void PrepareTilingSegment(const SpriteTilingProperty&property, const Polygon2D&originalPath, Polygon2D(&tileSegment)[9]);
void GenerateTilingAreaJob(GenerateTilingAreaInfo *data, unsigned index);

UNIT_TEST_SUITE(TilingShapeGenerator)
{
    struct PrepareTilingSegmentTestData
    {
        SpriteTilingProperty tilingProperty;
        int expectedCount[9];
        Polygon2D path;
    };

    std::ostream& operator<<(std::ostream& stream, const PrepareTilingSegmentTestData& data)
    {
        return stream << "PrepareTilingSegmentTestData";
    }

    PARAMETRIC_TEST_SOURCE(PrepareTilingSegmentGroupDataCases, (const PrepareTilingSegmentTestData))
    {
        SpriteTilingProperty tilingProperty(
            Vector4f(1, 1, 1, 1), Vector2f::zero, Vector2f::one * 3, Vector2f::one * 3, kSpriteDrawModeSimple, false, 0
            );
        {
            PrepareTilingSegmentTestData testData =
            {
                tilingProperty,
                {4, 0, 0, 0, 0, 0, 0, 0, 0},
                Polygon2D().Default()
            };
            Vector2f path[4] = {Vector2f(0.1f, 0.1f), Vector2f(0.1f, 0.9f), Vector2f(0.9f, 0.9f), Vector2f(0.9f, 0.1f)};
            testData.path.GetPath(0).assign(&path[0], &path[4]);
            PARAMETRIC_TEST_CASE_WITH_NAME("VerifyPathInSegment0_GroupedCorrectly", testData);
        }

        {
            PrepareTilingSegmentTestData testData =
            {
                tilingProperty,
                {0, 0, 0, 0, 4, 0, 0, 0, 0},
                Polygon2D().Default()
            };
            Vector2f path[4] = {Vector2f(1.1f, 1.1f), Vector2f(1.1f, 1.9f), Vector2f(1.9f, 1.9f), Vector2f(1.9f, 1.1f)};
            testData.path.GetPath(0).assign(&path[0], &path[4]);
            PARAMETRIC_TEST_CASE_WITH_NAME("VerifyPathInSegment5_GroupedCorrectly", testData);
        }

        {
            PrepareTilingSegmentTestData testData =
            {
                tilingProperty,
                {4, 4, 4, 4, 4, 4, 4, 4, 4},
                Polygon2D().Default()
            };
            Vector2f path[4] = {Vector2f(0, 0), Vector2f(0, 3), Vector2f(3, 3), Vector2f(3, 0)};
            testData.path.GetPath(0).assign(&path[0], &path[4]);
            PARAMETRIC_TEST_CASE_WITH_NAME("VerifyPathInMultipleSegments_GroupedCorrectly", testData);
        }
    }

    PARAMETRIC_TEST(PrepareTilingSegmentVerifyPathGroupedCorrectly, (const PrepareTilingSegmentTestData testData), PrepareTilingSegmentGroupDataCases)
    {
        Polygon2D results[9];
        for (int i = 0; i < 9; ++i)
            results[i].Clear();
        PrepareTilingSegment(testData.tilingProperty, testData.path, results);
        for (int i = 0; i < 9; ++i)
        {
            CHECK_EQUAL(testData.expectedCount[i], results[i].GetTotalPointCount());
        }
    }

    struct GenerateTilingShapeTestData
    {
        SpriteTilingProperty tilingProperty;
        const Vector2f* path;
        size_t pathPointCount;
        const float* expectedData;
        size_t expectedPointCount;
    };

    std::ostream& operator<<(std::ostream& stream, const GenerateTilingShapeTestData& data)
    {
        return stream << "GenerateTilingShapeTestData";
    }

    PARAMETRIC_TEST_SOURCE(GenerateTilingShapeGenerationDataCases, (const GenerateTilingShapeTestData))
    {
        {
            GenerateTilingShapeTestData testData =
            {
                SpriteTilingProperty(Vector4f(0.0f, 0.0f, 0.0f, 0.0f), Vector2f::zero, Vector2f::one, Vector2f::one * 5, kSpriteDrawModeTiled, false, 0.5f),
                kGenerateTilingShape_WithNoBorderTileModeSize5_PathInsideSprite_PathData,
                sizeof(kGenerateTilingShape_WithNoBorderTileModeSize5_PathInsideSprite_PathData) / sizeof(*kGenerateTilingShape_WithNoBorderTileModeSize5_PathInsideSprite_PathData),
                kGenerateTilingShape_WithNoBorderTileModeSize5_PathInsideSprite_ExpectedData,
                sizeof(kGenerateTilingShape_WithNoBorderTileModeSize5_PathInsideSprite_ExpectedData) / sizeof(*kGenerateTilingShape_WithNoBorderTileModeSize5_PathInsideSprite_ExpectedData)
            };
            PARAMETRIC_TEST_CASE_WITH_NAME("VerifyNoBorderTileModeSize5_PathInsideSprite", testData);
        }

        {
            GenerateTilingShapeTestData testData =
            {
                SpriteTilingProperty(Vector4f(0.0f, 0.0f, 0.0f, 0.0f), Vector2f::zero, Vector2f::one, Vector2f::one, kSpriteDrawModeTiled, false, 0.5f),
                kGenerateTilingShape_WithNoBorderTileMode_PathOutSideSprite_PathData,
                sizeof(kGenerateTilingShape_WithNoBorderTileMode_PathOutSideSprite_PathData) / sizeof(*kGenerateTilingShape_WithNoBorderTileMode_PathOutSideSprite_PathData),
                kGenerateTilingShape_WithNoBorderTileMode_PathOutSideSprite_ExpectedData,
                sizeof(kGenerateTilingShape_WithNoBorderTileMode_PathOutSideSprite_ExpectedData) / sizeof(*kGenerateTilingShape_WithNoBorderTileMode_PathOutSideSprite_ExpectedData)
            };
            PARAMETRIC_TEST_CASE_WITH_NAME("VerifyNoBorderTileMode_PathOutsideSprite", testData);
        }

        {
            GenerateTilingShapeTestData testData =
            {
                SpriteTilingProperty(Vector4f(0.0f, 0.0f, 0.0f, 0.0f), Vector2f::zero, Vector2f::one, Vector2f::one, kSpriteDrawModeTiled, false, 0.5f),
                kGenerateTilingShape_WithNoBorderTileMode_PathData,
                sizeof(kGenerateTilingShape_WithNoBorderTileMode_PathData) / sizeof(*kGenerateTilingShape_WithNoBorderTileMode_PathData),
                kGenerateTilingShape_WithNoBorderTileMode_ExpectedData,
                sizeof(kGenerateTilingShape_WithNoBorderTileMode_ExpectedData) / sizeof(*kGenerateTilingShape_WithNoBorderTileMode_ExpectedData)
            };
            PARAMETRIC_TEST_CASE_WITH_NAME("VerifyNoBorderTileMode", testData);
        }

        {
            GenerateTilingShapeTestData testData =
            {
                SpriteTilingProperty(Vector4f(0.97f, 1.0f, 1.0f, 1.0f), Vector2f::one * 0.5f, Vector2f::one * 3, Vector2f::one * 5, kSpriteDrawModeTiled, false, 0.5f),
                kGenerateTilingShape_WithBorderTileModeSize5_PathInMultipleTileSegment_PathData,
                sizeof(kGenerateTilingShape_WithBorderTileModeSize5_PathInMultipleTileSegment_PathData) / sizeof(*kGenerateTilingShape_WithBorderTileModeSize5_PathInMultipleTileSegment_PathData),
                kGenerateTilingShape_WithBorderTileModeSize5_PathInMultipleTileSegment_ExpectedData,
                sizeof(kGenerateTilingShape_WithBorderTileModeSize5_PathInMultipleTileSegment_ExpectedData) / sizeof(*kGenerateTilingShape_WithBorderTileModeSize5_PathInMultipleTileSegment_ExpectedData)
            };
            PARAMETRIC_TEST_CASE_WITH_NAME("VerifyBorderTileModeSize5_PathInMultipleTileSegment", testData);
        }

        {
            GenerateTilingShapeTestData testData =
            {
                SpriteTilingProperty(Vector4f(0.97f, 1.0f, 1.0f, 1.0f), Vector2f::one * 0.5f, Vector2f::one * 3, Vector2f::one * 5, kSpriteDrawModeSliced, false, 0.5f),
                kGenerateTilingShape_WithBorderSliceModeSize5_PathInMultipleTileSegment_PathData,
                sizeof(kGenerateTilingShape_WithBorderSliceModeSize5_PathInMultipleTileSegment_PathData) / sizeof(*kGenerateTilingShape_WithBorderSliceModeSize5_PathInMultipleTileSegment_PathData),
                kGenerateTilingShape_WithBorderSliceModeSize5_PathInMultipleTileSegment_ExpectedData,
                sizeof(kGenerateTilingShape_WithBorderSliceModeSize5_PathInMultipleTileSegment_ExpectedData) / sizeof(*kGenerateTilingShape_WithBorderSliceModeSize5_PathInMultipleTileSegment_ExpectedData)
            };
            PARAMETRIC_TEST_CASE_WITH_NAME("VerifyBorderSliceModeSize5_PathInMultipleTileSegment", testData);
        }

        {
            GenerateTilingShapeTestData testData =
            {
                SpriteTilingProperty(Vector4f(0.156250f, 0.181641f, 0.0f, 0.0f), Vector2f::zero, Vector2f::one, Vector2f::one * 5, kSpriteDrawModeTiled, false, 0.5f),
                kGenerateTilingShape_WithLeftBottomBorderOnlyTileModeSize5_PathData,
                sizeof(kGenerateTilingShape_WithLeftBottomBorderOnlyTileModeSize5_PathData) / sizeof(*kGenerateTilingShape_WithLeftBottomBorderOnlyTileModeSize5_PathData),
                kGenerateTilingShape_WithLeftBottomBorderOnlyTileModeSize5_ExpectedData,
                sizeof(kGenerateTilingShape_WithLeftBottomBorderOnlyTileModeSize5_ExpectedData) / sizeof(*kGenerateTilingShape_WithLeftBottomBorderOnlyTileModeSize5_ExpectedData)
            };
            PARAMETRIC_TEST_CASE_WITH_NAME("VerifyLeftBottomBorderOnlyTileModeSize5", testData);
        }

        {
            GenerateTilingShapeTestData testData =
            {
                SpriteTilingProperty(Vector4f(0.156250f, 0.181641f, 0.0f, 0.0f), Vector2f::zero, Vector2f::one, Vector2f::one * 5, kSpriteDrawModeSliced, false, 0.5f),
                kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathData,
                sizeof(kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathData) / sizeof(*kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathData),
                kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_ExpectedData,
                sizeof(kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_ExpectedData) / sizeof(*kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_ExpectedData)
            };
            PARAMETRIC_TEST_CASE_WITH_NAME("VerifyLeftBottomBorderOnlySliceModeSize5", testData);
        }

        {
            GenerateTilingShapeTestData testData =
            {
                SpriteTilingProperty(Vector4f(0.156250f, 0.181641f, 0.0, 0.0), Vector2f::zero, Vector2f::one, Vector2f::one * 5, kSpriteDrawModeTiled, false, 0.5f),
                kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathOutsideSprite_PathData,
                sizeof(kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathOutsideSprite_PathData) / sizeof(*kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathOutsideSprite_PathData),
                kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathOutsideSprite_ExpectedData,
                sizeof(kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathOutsideSprite_ExpectedData) / sizeof(*kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathOutsideSprite_ExpectedData)
            };
            PARAMETRIC_TEST_CASE_WITH_NAME("VerifyLeftBottomBorderOnlySliceModeSize5_PathOutsideSprite", testData);
        }
    }

    PARAMETRIC_TEST(GenerateTilingShapeVerifyGeneration, (const GenerateTilingShapeTestData testData), GenerateTilingShapeGenerationDataCases)
    {
        Polygon2D polygon2D;
        polygon2D.SetPoints(testData.path, testData.pathPointCount);
        Polygon2D result;
        JobFence fence;
        ScheduleGenerateTilingShape(fence, testData.tilingProperty, 0.0025f, 3, polygon2D, result);
        SyncFence(fence);

        int matched = 0;
        int totalPoints = 0;
        for (int i = 0; i < result.GetPathCount(); ++i)
        {
            const Polygon2D::TPath& t = result.GetPath(i);
            for (int j = 0; j < t.size(); ++j)
            {
                Vector2f v(testData.expectedData[totalPoints * 2], testData.expectedData[totalPoints * 2 + 1]);
                if (CompareApproximately(v, t[j]))
                    ++matched;

                ++totalPoints;
            }
        }
        CHECK_EQUAL(testData.expectedPointCount / 2, totalPoints);
        CHECK_EQUAL(testData.expectedPointCount / 2, matched);
    }
}


#endif // ENABLE_UNIT_TESTS
