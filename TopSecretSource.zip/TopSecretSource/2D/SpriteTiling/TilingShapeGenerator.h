#pragma once

#include "Runtime/Math/Vector2.h"
#include "Runtime/Graphics/Mesh/SpriteRenderer.h"

class Polygon2D;
struct JobFence;

struct SpriteTilingProperty
{
    DECLARE_SERIALIZE_NO_PPTR(SpriteTilingProperty)
    SpriteTilingProperty() :
        border(Vector4f::zero),
        pivot(Vector2f::zero),
        oldSize(Vector2f::zero),
        newSize(Vector2f::zero),
        drawMode(kSpriteDrawModeSimple),
        adaptiveTiling(false),
        adaptiveTilingThreshold(0.0f)
    {}
    SpriteTilingProperty(const Vector4f& b, const Vector2f& p, const Vector2f& o, const Vector2f& n, const SpriteDrawMode d, const bool at, const float att) :
        border(b),
        pivot(p),
        oldSize(o),
        newSize(n),
        drawMode(d),
        adaptiveTiling(at),
        adaptiveTilingThreshold(att)
    {}
    Vector4f border;
    Vector2f pivot;
    Vector2f oldSize;
    Vector2f newSize;
    SpriteDrawMode drawMode;
    bool adaptiveTiling;
    float adaptiveTilingThreshold;
};

template<class TransferFunction>
void SpriteTilingProperty::Transfer(TransferFunction& transfer)
{
    TRANSFER(border);
    TRANSFER(pivot);
    TRANSFER(oldSize);
    TRANSFER(newSize);
    TRANSFER(adaptiveTilingThreshold);
    TRANSFER_ENUM(drawMode);
    TRANSFER(adaptiveTiling);
    transfer.Align();
}

bool operator!=(const SpriteTilingProperty& stp1, const SpriteTilingProperty& stp2);
bool operator==(const SpriteTilingProperty& stp1, const SpriteTilingProperty& stp2);
void ScheduleGenerateTilingShape(JobFence& fence, const SpriteTilingProperty& property, const float minPointDistance, int minPointsPerPath, const Polygon2D& path, Polygon2D& result);
void ScheduleGenerateBoxTilingShape(JobFence& jobFence, const SpriteTilingProperty& property, const float minPointDistance, const Vector2f(&boxPoint)[2], Polygon2D& result);
