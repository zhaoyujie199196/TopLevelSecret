#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "Runtime/Testing/TestFixtures.h"
#include "Runtime/Testing/Testing.h"
#include "Runtime/2D/SpriteTiling/TilingShapeGenerator.h"
#include "Runtime/Geometry/Polygon2D.h"
#include "Runtime/Jobs/JobTypes.h"
#include "Runtime/Jobs/Jobs.h"
#include "Runtime/Testing/ParametricTest.h"

#include "Runtime/2D/SpriteTiling/BoxTilingShapeGeneratorTests_ExpectedData.inc.h"

struct GenerateTilingAreaInfo;
void PrepareTilingSegment(const SpriteTilingProperty&property, const Polygon2D&originalPath, Polygon2D(&tileSegment)[9]);
void GenerateTilingAreaJob(GenerateTilingAreaInfo *data, unsigned index);

UNIT_TEST_SUITE(BoxTilingShapeGenerator)
{
    struct GenerateTilingShapeTestData
    {
        SpriteTilingProperty tilingProperty;
        const Vector2f path[2];
        const float* expectedData;
        size_t expectedPointCount;

        GenerateTilingShapeTestData() : expectedData(NULL), expectedPointCount(0)
        {}

        GenerateTilingShapeTestData(const SpriteTilingProperty& tp, const Vector2f(&testPath)[2], const float* testExpectedData, const size_t testExpectedDataCount)
        {
            tilingProperty = tp,
            expectedPointCount = testExpectedDataCount;
            UNITY_MEMCPY((void*)path, testPath, 2 * sizeof(Vector2f));
            expectedData = (float*)UNITY_MALLOC(kMemDefault, testExpectedDataCount * sizeof(float));
            UNITY_MEMCPY((void*)expectedData, testExpectedData, testExpectedDataCount * sizeof(float));
        }

        GenerateTilingShapeTestData(const GenerateTilingShapeTestData& other)
        {
            *this = other;
        }

        GenerateTilingShapeTestData& operator=(const GenerateTilingShapeTestData& other)
        {
            tilingProperty = other.tilingProperty;
            expectedPointCount = other.expectedPointCount;
            UNITY_MEMCPY((void*)path, other.path, 2 * sizeof(Vector2f));
            expectedData = (float*)UNITY_MALLOC(kMemDefault, expectedPointCount * sizeof(float));
            UNITY_MEMCPY((void*)expectedData, other.expectedData, expectedPointCount * sizeof(float));
            return *this;
        }

        ~GenerateTilingShapeTestData()
        {
            UNITY_FREE(kMemDefault, expectedData);
        }
    };

    std::ostream& operator<<(std::ostream& stream, const GenerateTilingShapeTestData& data)
    {
        return stream << "GenerateTilingShapeTestData";
    }

    PARAMETRIC_TEST_SOURCE(BoxTilingShapeGenerationDataCases, (const GenerateTilingShapeTestData))
    {
        const Vector2f bottomLeftStart(0, 0.05f), bottomLeftEnd(0.15f, 0.15f);
        const Vector2f expectedBottomLeftStart(0, 0.05f), expectedBottomLeftEnd(0.15f, 0.15f);
        const Vector2f topLeftStart(0, 0.85f), topLeftEnd(0.15f, 0.95f);
        const Vector2f expectedTopLeftStart(0, 4.85f), expectedTopLeftEnd(0.15f, 4.95f);
        const Vector2f bottomRightStart(0.85f, 0.05f), bottomRightEnd(0.95f, 0.15f);
        const Vector2f expectedBottomRightStart(4.85f, .05f), expectedBottomRightEnd(4.95f, .15f);
        const Vector2f topRightStart(0.85f, 0.85f), topRightEnd(0.95f, 0.95f);
        const Vector2f expectedTopRightStart(4.85f, 4.85f), expectedTopRightEnd(4.95f, 4.95f);

        const SpriteDrawMode drawModeTestParam[] =
        {
            kSpriteDrawModeTiled, kSpriteDrawModeTiled, kSpriteDrawModeSliced
        };

        const bool adaptiveTilingTestParam[] =
        {
            true, false, false
        };

        for (int i = 0; i < 3; ++i)
        {
            {
                const Vector2f pathData[] = {Vector2f(-0.5f, -0.5f), Vector2f(0.5, 0.5)};
                const float p[] = {-2.5f, -2.5f, 2.5f, 2.5f};
                const float expectedData[] = {p[0], p[1], p[0], p[3], p[2], p[3], p[2], p[1]};
                GenerateTilingShapeTestData testData(
                    SpriteTilingProperty(Vector4f(0.2f, 0.2f, 0.2f, 0.2f), Vector2f::one * 0.5f, Vector2f::one, Vector2f::one * 5, drawModeTestParam[i], adaptiveTilingTestParam[i], 0.5f),
                    pathData, expectedData, 8);
                core::string testName = Format("PathCoversFullSprite_DrawMode%d_AdaptileTiling%d", drawModeTestParam[i], adaptiveTilingTestParam[i]);
                PARAMETRIC_TEST_CASE_WITH_NAME(testName, testData);
            }

            {
                const Vector2f pathData[] = {Vector2f(-0.5f, -0.5f), Vector2f(0.5, 0.5)};
                const float p[] = {-1.75f, -1.75f, 1.75f, 1.75f};
                const float expectedData[] = {p[0], p[1], p[0], p[3], p[2], p[3], p[2], p[1]};
                GenerateTilingShapeTestData testData(
                    SpriteTilingProperty(Vector4f::zero, Vector2f::one * 0.5f, Vector2f::one, Vector2f::one * 3.5, drawModeTestParam[i], adaptiveTilingTestParam[i], 0.5f),
                    pathData,
                    expectedData, 8);
                core::string testName = Format("PathCoversFullSprite_TileSizeIsPartial_DrawMode%d_AdaptileTiling%d", drawModeTestParam[i], adaptiveTilingTestParam[i]);
                PARAMETRIC_TEST_CASE_WITH_NAME(testName, testData);
            }

            SpriteTilingProperty stp(Vector4f(0.2f, 0.2f, 0.2f, 0.2f), Vector2f::zero, Vector2f::one, Vector2f::one * 5, drawModeTestParam[i], adaptiveTilingTestParam[i], 0.5f);
            {
                const Vector2f pathData[] = {topLeftStart, topLeftEnd};
                const float p[] = {expectedTopLeftStart.x, expectedTopLeftStart.y, expectedTopLeftEnd.x, expectedTopLeftEnd.y};
                const float expectedData[] = {p[0], p[1], p[0], p[3], p[2], p[3], p[2], p[1]};
                GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
                core::string testName = Format("PathCoversTopLeft_DrawMode%d_AdaptileTiling%d", drawModeTestParam[i], adaptiveTilingTestParam[i]);
                PARAMETRIC_TEST_CASE_WITH_NAME(testName, testData);
            }

            {
                const Vector2f pathData[] = {topRightStart, topRightEnd};
                const float p[] = {expectedTopRightStart.x, expectedTopRightStart.y, expectedTopRightEnd.x, expectedTopRightEnd.y};
                const float expectedData[] = {p[0], p[1], p[0], p[3], p[2], p[3], p[2], p[1]};
                GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
                core::string testName = Format("PathCoversTopRight_DrawMode%d_AdaptileTiling%d", drawModeTestParam[i], adaptiveTilingTestParam[i]);
                PARAMETRIC_TEST_CASE_WITH_NAME(testName, testData);
            }

            {
                const Vector2f pathData[] = {bottomLeftStart, bottomLeftEnd};
                const float p[] = {expectedBottomLeftStart.x, expectedBottomLeftStart.y, expectedBottomLeftEnd.x, expectedBottomLeftEnd.y};
                const float expectedData[] = {p[0], p[1], p[0], p[3], p[2], p[3], p[2], p[1]};
                GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
                core::string testName = Format("PathCoversBottomLeft_DrawMode%d_AdaptileTiling%d", drawModeTestParam[i], adaptiveTilingTestParam[i]);
                PARAMETRIC_TEST_CASE_WITH_NAME(testName, testData);
            }

            {
                const Vector2f pathData[] = {bottomRightStart, bottomRightEnd};
                const float p[] = {expectedBottomRightStart.x, expectedBottomRightStart.y, expectedBottomRightEnd.x, expectedBottomRightEnd.y};
                const float expectedData[] = {p[0], p[1], p[0], p[3], p[2], p[3], p[2], p[1]};
                GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
                core::string testName = Format("PathCoversBottomRight_DrawMode%d_AdaptileTiling%d", drawModeTestParam[i], adaptiveTilingTestParam[i]);
                PARAMETRIC_TEST_CASE_WITH_NAME(testName, testData);
            }

            {
                const Vector2f pathData[] = {bottomLeftStart, topLeftEnd};
                const float p[] = {expectedBottomLeftStart.x, expectedBottomLeftStart.y, expectedTopLeftEnd.x, expectedTopLeftEnd.y};
                const float expectedData[] = {p[0], p[1], p[0], p[3], p[2], p[3], p[2], p[1]};
                GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
                core::string testName = Format("PathCoversBottomLeftTopLeft_DrawMode%d_AdaptileTiling%d", drawModeTestParam[i], adaptiveTilingTestParam[i]);
                PARAMETRIC_TEST_CASE_WITH_NAME(testName, testData);
            }

            {
                const Vector2f pathData[] = {bottomLeftStart, bottomRightEnd};
                const float p[] = {expectedBottomLeftStart.x, expectedBottomLeftStart.y, expectedBottomRightEnd.x, expectedBottomRightEnd.y};
                const float expectedData[] = {p[0], p[1], p[0], p[3], p[2], p[3], p[2], p[1]};
                GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
                core::string testName = Format("PathCoversBottomLeftBottomRight_DrawMode%d_AdaptileTiling%d", drawModeTestParam[i], adaptiveTilingTestParam[i]);
                PARAMETRIC_TEST_CASE_WITH_NAME(testName, testData);
            }

            {
                const Vector2f pathData[] = {bottomLeftStart, topRightEnd};
                const float p[] = {expectedBottomLeftStart.x, expectedBottomLeftStart.y, expectedTopRightEnd.x, expectedTopRightEnd.y};
                const float expectedData[] = {p[0], p[1], p[0], p[3], p[2], p[3], p[2], p[1]};
                GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
                core::string testName = Format("PathCoversBottomLeftTopRight_DrawMode%d_AdaptileTiling%d", drawModeTestParam[i], adaptiveTilingTestParam[i]);
                PARAMETRIC_TEST_CASE_WITH_NAME(testName, testData);
            }

            {
                const Vector2f pathData[] = {bottomRightStart, topRightEnd};
                const float p[] = {expectedBottomRightStart.x, expectedBottomRightStart.y, expectedTopRightEnd.x, expectedTopRightEnd.y};
                const float expectedData[] = {p[0], p[1], p[0], p[3], p[2], p[3], p[2], p[1]};
                GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
                core::string testName = Format("PathCoversBottomRightTopRight_DrawMode%d_AdaptileTiling%d", drawModeTestParam[i], adaptiveTilingTestParam[i]);
                PARAMETRIC_TEST_CASE_WITH_NAME(testName, testData);
            }

            {
                const Vector2f pathData[] = {topLeftStart, topRightEnd};
                const float p[] = {expectedTopLeftStart.x, expectedTopLeftStart.y, expectedTopRightEnd.x, expectedTopRightEnd.y};
                const float expectedData[] = {p[0], p[1], p[0], p[3], p[2], p[3], p[2], p[1]};
                GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
                core::string testName = Format("PathCoversTopLeftTopRight_DrawMode%d_AdaptileTiling%d", drawModeTestParam[i], adaptiveTilingTestParam[i]);
                PARAMETRIC_TEST_CASE_WITH_NAME(testName, testData);
            }

            {
                const Vector2f pathData[] = {Vector2f::zero, Vector2f::one};
                const float p[] = {0, 0, 5.0f, 5.0f};
                const float expectedData[] = {p[0], p[1], p[0], p[3], p[2], p[3], p[2], p[1]};
                stp.border = Vector4f::zero;
                GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
                core::string testName = Format("PathCoversFullSpriteWithNoBorders_DrawMode%d_AdaptileTiling%d", drawModeTestParam[i], adaptiveTilingTestParam[i]);
                PARAMETRIC_TEST_CASE_WITH_NAME(testName, testData);
            }

            {
                const Vector2f pathData[] = {Vector2f::zero, Vector2f::one};
                const float p[] = {4.0f, 0, 5.0f, 5.0f};
                const float expectedData[] = {p[0], p[1], p[0], p[3], p[2], p[3], p[2], p[1]};
                stp.border = Vector4f(0, 0, 1, 0);
                GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
                core::string testName = Format("PathCoversFullSpriteWithRightBorderOnly_DrawMode%d_AdaptileTiling%d", drawModeTestParam[i], adaptiveTilingTestParam[i]);
                PARAMETRIC_TEST_CASE_WITH_NAME(testName, testData);
            }

            {
                const Vector2f pathData[] = {Vector2f::zero, Vector2f::one};
                const float p[] = {0, 0, 1.0f, 5.0f};
                const float expectedData[] = {p[0], p[1], p[0], p[3], p[2], p[3], p[2], p[1]};
                stp.border = Vector4f(1, 0, 0, 0);
                GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
                core::string testName = Format("PathCoversFullSpriteWithLeftBorderOnly_DrawMode%d_AdaptileTiling%d", drawModeTestParam[i], adaptiveTilingTestParam[i]);
                PARAMETRIC_TEST_CASE_WITH_NAME(testName, testData);
            }

            {
                const Vector2f pathData[] = {Vector2f::zero, Vector2f::one};
                const float p[] = {0, 0.0f, 5.0f, 1.0f};
                const float expectedData[] = {p[0], p[1], p[0], p[3], p[2], p[3], p[2], p[1]};
                stp.border = Vector4f(0, 1, 0, 0);
                GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
                core::string testName = Format("PathCoversFullSpriteWithBottomBorderOnly_DrawMode%d_AdaptileTiling%d", drawModeTestParam[i], adaptiveTilingTestParam[i]);
                PARAMETRIC_TEST_CASE_WITH_NAME(testName, testData);
            }

            {
                const Vector2f pathData[] = {Vector2f::zero, Vector2f::one};
                const float p[] = {0, 4, 5.0f, 5.0f};
                const float expectedData[] = {p[0], p[1], p[0], p[3], p[2], p[3], p[2], p[1]};
                stp.border = Vector4f(0, 0, 0, 1);
                GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
                core::string testName = Format("PathCoversFullSpriteWithTopBorderOnly_DrawMode%d_AdaptileTiling%d", drawModeTestParam[i], adaptiveTilingTestParam[i]);
                PARAMETRIC_TEST_CASE_WITH_NAME(testName, testData);
            }
        }

        {
            SpriteTilingProperty stp(Vector4f(0.2f, 0.2f, 0.2f, 0.2f), Vector2f::zero, Vector2f::one, Vector2f::one * 3, kSpriteDrawModeTiled, true, 0.5f);
            const Vector2f pathData[] = {Vector2f(0.3f, 0.3f), Vector2f(0.5f, 0.5f)};
            GenerateTilingShapeTestData testData(stp, pathData,
                                                 kPathCoversPartialMidSegment_WithDrawModeTiled_ExpectedData,
                                                 sizeof(kPathCoversPartialMidSegment_WithDrawModeTiled_ExpectedData) / sizeof(*kPathCoversPartialMidSegment_WithDrawModeTiled_ExpectedData));
            PARAMETRIC_TEST_CASE_WITH_NAME("PathCoversPartialMidSegment_WithDrawModeTiled", testData);
        }

        {
            SpriteTilingProperty stp(Vector4f(0.2f, 0.2f, 0.2f, 0.2f), Vector2f::zero, Vector2f::one, Vector2f::one * 3, kSpriteDrawModeTiled, true, 0.5f);
            const Vector2f pathData[] = {Vector2f(0.05f, 0.05f), Vector2f(0.5f, 0.5f)};
            GenerateTilingShapeTestData testData(stp, pathData,
                                                 kPathCoversPartialBottomLeftMidSegment_WithDrawModeTiled_ExpectedData,
                                                 sizeof(kPathCoversPartialBottomLeftMidSegment_WithDrawModeTiled_ExpectedData) / sizeof(*kPathCoversPartialBottomLeftMidSegment_WithDrawModeTiled_ExpectedData));
            PARAMETRIC_TEST_CASE_WITH_NAME("PathCoversPartialBottomLeftMidSegment_WithDrawModeTiled", testData);
        }

        {
            SpriteTilingProperty stp(Vector4f(0.2f, 0.2f, 0.2f, 0.2f), Vector2f::zero, Vector2f::one, Vector2f::one * 3, kSpriteDrawModeTiled, true, 0.5f);
            const Vector2f pathData[] = {Vector2f(0.7f, 0.7f), Vector2f(0.9f, 0.9f)};
            GenerateTilingShapeTestData testData(stp, pathData,
                                                 kPathCoversPartialMidSegmentTopRight_WithDrawModeTiled_ExpectedData,
                                                 sizeof(kPathCoversPartialMidSegmentTopRight_WithDrawModeTiled_ExpectedData) / sizeof(*kPathCoversPartialMidSegmentTopRight_WithDrawModeTiled_ExpectedData));
            PARAMETRIC_TEST_CASE_WITH_NAME("PathCoversPartialMidSegmentTopRight_WithDrawModeTiled", testData);
        }

        {
            SpriteTilingProperty stp(Vector4f(0.2f, 0.2f, 0.2f, 0.2f), Vector2f::zero, Vector2f::one, Vector2f::one * 3, kSpriteDrawModeSliced, true, 0.5f);
            const Vector2f pathData[] = {Vector2f(0.3f, 0.3f), Vector2f(0.5f, 0.5f)};
            const float expectedData[] = {0.633333f, 0.633333f, 0.633333f, 1.500000f, 1.500000f, 1.500000f, 1.500000f, 0.633333f};
            GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
            PARAMETRIC_TEST_CASE_WITH_NAME("PathCoversPartialMidSegment_WithDrawModeSliced", testData);
        }

        {
            SpriteTilingProperty stp(Vector4f(0.2f, 0.2f, 0.2f, 0.2f), Vector2f::zero, Vector2f::one, Vector2f::one * 3, kSpriteDrawModeSliced, true, 0.5f);
            const Vector2f pathData[] = {Vector2f(0.05f, 0.05f), Vector2f(0.5f, 0.5f)};
            const float expectedData[] = {0.050000f, 0.050000f, 0.050000f, 1.500000f, 1.500000f, 1.500000f, 1.500000f, 0.050000f};
            GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
            PARAMETRIC_TEST_CASE_WITH_NAME("PathCoversPartialBottomLeftMidSegment_WithDrawModeSliced", testData);
        }

        {
            SpriteTilingProperty stp(Vector4f(0.2f, 0.2f, 0.2f, 0.2f), Vector2f::zero, Vector2f::one, Vector2f::one * 3, kSpriteDrawModeSliced, true, 0.5f);
            const Vector2f pathData[] = {Vector2f(0.7f, 0.7f), Vector2f(0.9f, 0.9f)};
            const float expectedData[] = {2.366667f, 2.366667f, 2.366667f, 2.900000f, 2.900000f, 2.900000f, 2.900000f, 2.366667f};
            GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
            PARAMETRIC_TEST_CASE_WITH_NAME("PathCoversPartialMidSegmentTopRight_WithDrawModeSliced", testData);
        }

        {
            SpriteTilingProperty stp(Vector4f(0.2f, 0.2f, 0.2f, 0.2f), Vector2f::zero, Vector2f::one, Vector2f(0.35f, 0.6f), kSpriteDrawModeTiled, true, 0.5f);
            const Vector2f pathData[] = {Vector2f(0.05f, 0.05f), Vector2f(0.3f, 0.3f)};
            const float expectedData[] = {0.043750f, 0.050000f, 0.043750f, 0.233333f, 0.275000f, 0.233333f, 0.275000f, 0.050000f};
            GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
            PARAMETRIC_TEST_CASE_WITH_NAME("PathCoversPartialBottomLeftMidSegment_WithDrawModeTiled_SizeXSmallerThanBorder", testData);
        }

        {
            SpriteTilingProperty stp(Vector4f(0.2f, 0.0f, 0.2f, 0.0f), Vector2f::zero, Vector2f::one, Vector2f::one, kSpriteDrawModeTiled, true, 0.5f);
            const Vector2f pathData[] = {Vector2f(0.25f, 0.0f), Vector2f(0.75f, 1.0f)};
            const float expectedData[] = {0.25f, 0.0f, 0.25f, 1.0f, 0.75f, 1.0f, 0.75f, 0.0f};
            GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
            PARAMETRIC_TEST_CASE_WITH_NAME("PathCoversMidSegment_WithDrawModeTile_AndLeftRightBorder", testData);
        }

        {
            SpriteTilingProperty stp(Vector4f(0.0f, 0.2f, 0.0f, 0.2f), Vector2f::zero, Vector2f::one, Vector2f::one, kSpriteDrawModeTiled, true, 0.5f);
            const Vector2f pathData[] = {Vector2f(0.0f, 0.25f), Vector2f(1.0f, 0.75f)};
            const float expectedData[] = {0.0f, 0.25f, 0.0f, 0.75f, 1.0f, 0.75f, 1.0f, 0.25f};
            GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
            PARAMETRIC_TEST_CASE_WITH_NAME("PathCoversMidSegment_WithDrawModeTile_AndTopBottomBorder", testData);
        }

        {
            SpriteTilingProperty stp(Vector4f(0.2f, 0.0f, 0.2f, 0.0f), Vector2f::zero, Vector2f::one, Vector2f(2, 1), kSpriteDrawModeTiled, true, 0.5f);
            const Vector2f pathData[] = {Vector2f(0.1f, 0.0f), Vector2f(0.9f, 1.0f)};
            const float expectedData[] = {0.1f, 0.0f, 0.1f, 1.0f, 1.9f, 1.0f, 1.9f, 0.0f};
            GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
            PARAMETRIC_TEST_CASE_WITH_NAME("PathCoversLeftAndRightSegment_WithDrawModeTile_AndLeftRightBorder", testData);
        }


        {
            SpriteTilingProperty stp(Vector4f(0.2f, 0.0f, 0.2f, 0.0f), Vector2f::zero, Vector2f::one, Vector2f(2, 1), kSpriteDrawModeTiled, true, 0.5f);
            const Vector2f pathData[] = {Vector2f(0.0f, 0.0f), Vector2f(1.0f, 1.0f)};
            const float expectedData[] = {0.0f, 0.0f, 0.0f, 1.0f, 2.0f, 1.0f, 2.0f, 0.0f};
            GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
            PARAMETRIC_TEST_CASE_WITH_NAME("PathCoversFullSpriteWithLeftRightBorderOnly_DrawModeTile_SizeXLargerThanOriginal", testData);
        }

        {
            SpriteTilingProperty stp(Vector4f(0.2f, 0.0f, 0.2f, 0.0f), Vector2f::zero, Vector2f::one, Vector2f(0.8f, 1), kSpriteDrawModeTiled, true, 0.5f);
            const Vector2f pathData[] = {Vector2f(-0.1f, -0.2f), Vector2f(0.75f, 1.2f)};
            const float expectedData[] = {-0.1f, 0.0f, -0.1f, 1.0f, 0.56666f, 1.0f, 0.56666f, 0.0f};
            GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
            PARAMETRIC_TEST_CASE_WITH_NAME("PathCoversBottomLeftAndMidSegmentWithLeftRightBorderOnly_DrawModeTile_SizeXSmallerThanOriginal", testData);
        }

        {
            SpriteTilingProperty stp(Vector4f(0.2f, 0.2f, 0.2f, 0.2f), Vector2f::zero, Vector2f::one, Vector2f(0.3f, 0.3f), kSpriteDrawModeTiled, true, 0.5f);
            const Vector2f pathData[] = {Vector2f(-0.1f, -0.2f), Vector2f(0.3f, 0.3f)};
            const float expectedData[] = {-0.1f, -0.2f, -0.1f, 0.25f, 0.25f, 0.25f, 0.25, -0.2f};
            GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
            PARAMETRIC_TEST_CASE_WITH_NAME("PathCoversBottomLeftAndMidSegment_WithDrawModeTile_SizeSmallerThanMid", testData);
        }

        {
            SpriteTilingProperty stp(Vector4f(0.2f, 0.2f, 0.2f, 0.2f), Vector2f::zero, Vector2f::one, Vector2f(0.3f, 0.3f), kSpriteDrawModeTiled, true, 0.5f);
            const Vector2f pathData[] = {Vector2f(0.6f, 0.6f), Vector2f(1.1f, 1.1f)};
            const float expectedData[] = {0.0f, 0.0f, 0.0f, 0.4f, 0.4f, 0.4f, 0.4f, 0.0f};
            GenerateTilingShapeTestData testData(stp, pathData, expectedData, 8);
            PARAMETRIC_TEST_CASE_WITH_NAME("PathCoversMidAndTopRightSegment_WithDrawModeTile_SizeSmallerThanMid", testData);
        }
    }

    PARAMETRIC_TEST(GenerateBoxTilingShapeVerifyGeneration, (const GenerateTilingShapeTestData testData), BoxTilingShapeGenerationDataCases)
    {
        Polygon2D result;
        Vector2f points[] = {testData.path[0], testData.path[1]};
        JobFence fence;
        ScheduleGenerateBoxTilingShape(fence, testData.tilingProperty, 0, points, result);
        SyncFence(fence);


        int expectedPointIndex = 0;
        int matched = 0;
        int totalPoints = 0;
        for (int i = 0; i < result.GetPathCount(); ++i)
        {
            const Polygon2D::TPath& t = result.GetPath(i);
            for (int j = 0; j < t.size(); ++j)
            {
                Vector2f expectedData = Vector2f(testData.expectedData[expectedPointIndex], testData.expectedData[expectedPointIndex + 1]);
                if (CompareApproximately(expectedData, t[j]))
                    ++matched;
                expectedPointIndex += 2;
                ++totalPoints;
            }
        }

        CHECK_EQUAL(testData.expectedPointCount / 2, totalPoints);
        CHECK_EQUAL(testData.expectedPointCount / 2, matched);
    }
}


#endif // ENABLE_UNIT_TESTS
