#include "UnityPrefix.h"

#include "Runtime/2D/SpriteTiling/TilingShapeGenerator.h"
#include "Runtime/2D/SpriteTiling/SpriteTiling.h"
#include "Runtime/Geometry/Intersection.h"
#include "Runtime/Geometry/Polygon2D.h"
#include "Runtime/Jobs/JobTypes.h"
#include "Runtime/Jobs/Jobs.h"
#include "Runtime/Utilities/sorting.h"

PROFILER_INFORMATION(gPrepareTilingSegment, "Physics2D.PrepareTilingSegment", kProfilerPhysics);
PROFILER_INFORMATION(gGenerateTilingArea, "Physics2D.GenerateTilingArea", kProfilerPhysics);
PROFILER_INFORMATION(gGenerateBoxTilingShape, "Physics2D.GenerateBoxTilingShape", kProfilerPhysics);

struct GenerateTilingAreaInfo
{
    NineSliceRectData outRectData[9];
    Polygon2D tileSegment[9];
    SpriteTilingProperty tileProperty;
    Polygon2D* finalResult;
    float minPointDistance;
    int minPointPerPath;
    int jobCount;
    Polygon2D segmentResult[9];
    bool insertEdgePoint;

    GenerateTilingAreaInfo(MemLabelRef tileSegmentMemLabel, MemLabelRef segmentResultMemLabel)
    {
        for (int i = 0; i < 9; ++i)
        {
            tileSegment[i].set_memory_label(tileSegmentMemLabel);
            segmentResult[i].set_memory_label(segmentResultMemLabel);
        }
    }
};

struct PointSqrDistanceFindPredicate
{
    PointSqrDistanceFindPredicate(const Vector2f& p, const float d) : point(p), sqrDistance(d)
    {}

    bool operator()(const Vector2f& i) const
    {
        return SqrMagnitude(i - point) <= sqrDistance;
    }

    Vector2f point;
    float sqrDistance;
};

struct PointDistanceSortPredicate
{
    PointDistanceSortPredicate() {}
    bool operator()(const Vector2f& i, const Vector2f& j) const
    {
        return SqrMagnitude(startPoint - i) < SqrMagnitude(startPoint - j);
    }

    Vector2f startPoint;
};

void GenerateTilingAreaJob(GenerateTilingAreaInfo* data, unsigned index);
void PrepareTilingSegment(const SpriteTilingProperty&property, const Polygon2D&originalPath, Polygon2D(&tileSegment)[9]);
static void GenerateTilingJobCombine(GenerateTilingAreaInfo* data);
static void GenerateTilingArea(Polygon2D& result, const NineSliceRectData& rectData, const Polygon2D& oriPath, const SpriteTilingProperty& property, const float minPointDistance, const int minPointPerPath);
FORCE_INLINE static void AddPointToSegment(Polygon2D(&tileSegment)[9], int segment, int pathIndex, const Vector2f&point);
FORCE_INLINE static int GetPointSegment(Vector2f point, Vector2f cp1, Vector2f cp2);
FORCE_INLINE static void InsertLineBorderIntersectPoints(const Vector2f& partialTile, const Vector4f& segmentBoundary, const Vector2f& p1, const Vector2f& p2, const Vector2f& offset, const float sqrMinPointDistance, const Polygon2D::TPath& existingPoints, Polygon2D::TPath& newPointPath);
FORCE_INLINE static void InsertNewPoint(const Vector2f& newPoint, const float sqrMinPointDistance, const Polygon2D::TPath& existingPoints, Polygon2D::TPath& newPointPath);
void GenerateBoxTilingShapeJob(GenerateTilingAreaInfo* data);
void GenerateBoxTilingShape(GenerateTilingAreaInfo* jobData);
static void CalculateStartEndSegment(const float cp1, const float cp2, const float min, const float max, float &outStart, float &outEnd);
static int FindTileSegmentIndex(const NineSliceRectData::TileSegment tileSegment, const NineSliceRectData(&rectData)[9], const int rectDataCount);

void ScheduleGenerateTilingShape(JobFence& fence, const SpriteTilingProperty& property, const float minPointDistance, int minPointsPerPath, const Polygon2D& path, Polygon2D& result)
{
    using namespace math;

    Assert(property.drawMode != kSpriteDrawModeSimple);

    GenerateTilingAreaInfo* jobInfo = UNITY_NEW(GenerateTilingAreaInfo, kMemTempJobAlloc)(kMemDefault, kMemTempJobAlloc);
    {
        PROFILER_AUTO(gPrepareTilingSegment, NULL);
        // Split up the path into each 9 slice segment.
        PrepareTilingSegment(property, path, jobInfo->tileSegment);
    }

    float4 spriteBordersInUnit = vload4f(property.border.GetPtr());
    float2 startPoint = vload2f(property.pivot.GetPtr());
    float2 tileSize = vload2f(property.newSize.GetPtr());
    float2 oldSize = vload2f(property.oldSize.GetPtr());
    startPoint = tileSize * startPoint * float1(-1);
    int outRectDataCount;
    GetSourceAndDestinationRect(spriteBordersInUnit, startPoint, tileSize, oldSize, jobInfo->outRectData, outRectDataCount);

    {
        memcpy(&jobInfo->tileProperty, &property, sizeof(SpriteTilingProperty));
        jobInfo->finalResult = &result;
        jobInfo->jobCount = outRectDataCount;
        jobInfo->minPointDistance = minPointDistance;
        jobInfo->minPointPerPath = minPointsPerPath;
        jobInfo->insertEdgePoint = false;
        ScheduleJobForEach(fence, GenerateTilingAreaJob, jobInfo, outRectDataCount, GenerateTilingJobCombine);
    }
}

void GenerateTilingAreaJob(GenerateTilingAreaInfo *data, unsigned index)
{
    using namespace math;
    Polygon2D& result = data->segmentResult[data->outRectData[index].tileSegment];
    const Polygon2D& oriPath = data->tileSegment[data->outRectData[index].tileSegment];

    if (oriPath.GetPathCount() <= 0)
        return;

    PROFILER_AUTO(gGenerateTilingArea, NULL);

    int tileSegmentIndex = data->outRectData[index].tileSegment;
    // left,bottom,right,top. 0 indicates there is boundary, infinity indicates no boundary
    const Vector4f segmentBoundary[9] =
    {
        Vector4f(Vector2f::infinity, Vector2f::infinity, 0, 0),
        Vector4f(0, Vector2f::infinity, 0, 0),
        Vector4f(0, Vector2f::infinity, Vector2f::infinity, 0),
        Vector4f(Vector2f::infinity, 0, 0, 0),
        Vector4f(0, 0, 0, 0),
        Vector4f(0, 0, Vector2f::infinity, 0),
        Vector4f(Vector2f::infinity, 0, 0, Vector2f::infinity),
        Vector4f(0, 0, 0, Vector2f::infinity),
        Vector4f(0, 0, Vector2f::infinity, Vector2f::infinity),
    };

    const NineSliceRectData& rectData = data->outRectData[index];
    const SpriteTilingProperty& property = data->tileProperty;
    const float minPointDistance = data->minPointDistance;
    const int minPointPerPath = data->minPointPerPath;

    const float2& sourceRectSize = rectData.sourceRectSize;
    const float2& destRectPos = rectData.destRectPos;
    const float2& destRectSize = rectData.destRectSize;
    const float sqrMinPointDistance = minPointDistance * minPointDistance;

    float xyTileCount[2];
    Vector2f scale;
    Vector2f size;

    {
        float2 sizeFloat2;
        GetTilingIterationData(rectData, property.drawMode, property.adaptiveTiling, property.adaptiveTilingThreshold, sizeFloat2, xyTileCount);
        vstore2f(size.GetPtr(), sizeFloat2);
        vstore2f(scale.GetPtr(), sizeFloat2 / sourceRectSize);
    }

    Vector2f offset = Vector2f::zero;
    Vector2f pivot; vstore2f(pivot.GetPtr(), destRectPos);
    Vector2f sizeDiff; vstore2f(sizeDiff.GetPtr(), select(float2(ZERO), destRectSize - sourceRectSize, destRectSize < sourceRectSize));
    Vector2f centerPoint; vstore2f(centerPoint.GetPtr(), sourceRectSize * float2(0.5f, 0.5f));
    Vector2f newCenterPoint = size * 0.5f;

    while (xyTileCount[1] > 0)
    {
        float addY = (xyTileCount[1] > 1.0f || property.adaptiveTiling) ? 1.0f : xyTileCount[1];
        xyTileCount[1] -= 1.0f;
        float xTileCount = xyTileCount[0];
        offset.x = 0;
        while (xTileCount > 0)
        {
            float addX = (xTileCount > 1.0f || property.adaptiveTiling) ? 1.0f : xTileCount;
            xTileCount -= 1.0f;
            for (int i = 0; i < oriPath.GetPathCount(); ++i)
            {
                const Polygon2D::TPath& path = oriPath.GetPath(i);
                if (path.empty())
                    continue;
                Polygon2D::TPath newPath(kMemTempJobAlloc);

                Vector2f it2 = path.back();
                Vector2f newPointOffset = newCenterPoint - centerPoint + pivot + offset;
                for (Polygon2D::TPath::const_iterator it1 = path.begin(); it1 != path.end(); it2 = *it1, ++it1)
                {
                    if (addX < 1 || addY < 1) // handle continuous mode when revealing partial
                    {
                        Polygon2D::TPath intersectPoints(kMemTempJobAlloc);
                        // we are dealing with partial tiling rect
                        Vector2f partialTile = Vector2f(size.x * addX, size.y * addY);
                        Vector2f cp = *it1;

                        if (cp.x <= partialTile.x && cp.y <= partialTile.y)
                        {
                            if (segmentBoundary[tileSegmentIndex].x != Vector2f::infinity)
                                cp.x = math::max(cp.x, 0.0f);
                            if (segmentBoundary[tileSegmentIndex].y != Vector2f::infinity)
                                cp.y = math::max(cp.y, 0.0f);
                            InsertNewPoint(cp + newPointOffset, sqrMinPointDistance, newPath, intersectPoints);
                        }
                        else if (segmentBoundary[tileSegmentIndex].z == Vector2f::infinity || segmentBoundary[tileSegmentIndex].w == Vector2f::infinity)
                        {
                            if (cp.x > sourceRectSize.x)
                                cp.x += sizeDiff.x;
                            else if (cp.x > partialTile.x)
                                cp.x = partialTile.x;

                            if (cp.y > sourceRectSize.y)
                                cp.y += sizeDiff.y;
                            else if (cp.y > partialTile.y)
                                cp.y = partialTile.y;

                            InsertNewPoint(cp + newPointOffset, sqrMinPointDistance, newPath, intersectPoints);

                            // if the next point is outside of the sprite, we need to move the point
                            // if it is beyond current partial tile for intersection to be correctly calculated
                            if (it2.y > sourceRectSize.y)
                            {
                                if (it2.y > partialTile.y)
                                    it2.y += sizeDiff.y;
                            }
                            else if (it2.y > partialTile.y)
                                it2.y = partialTile.y;

                            if (it2.x > sourceRectSize.x)
                            {
                                if (it2.x > partialTile.x)
                                    it2.x += sizeDiff.x;
                            }
                            else if (it2.x > partialTile.x)
                                it2.x = partialTile.x;
                        }

                        if (data->insertEdgePoint)
                        {
                            if (segmentBoundary[tileSegmentIndex].x != Vector2f::infinity)
                                cp.x = math::max(cp.x, 0.0f);
                            if (segmentBoundary[tileSegmentIndex].y != Vector2f::infinity)
                                cp.y = math::max(cp.y, 0.0f);
                            if (segmentBoundary[tileSegmentIndex].z != Vector2f::infinity)
                                cp.x = math::min(cp.x, partialTile.x);
                            if (segmentBoundary[tileSegmentIndex].w != Vector2f::infinity)
                                cp.y = math::min(cp.y, partialTile.y);

                            InsertNewPoint(cp + newPointOffset, sqrMinPointDistance, newPath, intersectPoints);
                        }
                        else
                            InsertLineBorderIntersectPoints(partialTile, segmentBoundary[tileSegmentIndex], cp, it2, newPointOffset, sqrMinPointDistance, newPath, intersectPoints);

                        PointDistanceSortPredicate pds; pds.startPoint = it2 + pivot + offset;
                        QSort(intersectPoints.begin(), intersectPoints.end(), pds);
                        newPath.insert(newPath.end(), intersectPoints.begin(), intersectPoints.end());
                    }
                    else
                    {
                        Vector2f p = *it1 - centerPoint;

                        // If the point is within the sprite, we scale the point distance.
                        // if not, we want to maintain the point distance from the edge of the sprite
                        if (it1->x <= sourceRectSize.x && (it1->x >= 0 || segmentBoundary[tileSegmentIndex].x != Vector2f::infinity))
                            p.x *= scale.x;
                        else
                        {
                            float b = math::abs(p.x) - centerPoint.x;
                            p.x = centerPoint.x * scale.x + b;
                            p.x *= it1->x > 0 ? 1 : -1;
                        }

                        if (it1->y <= sourceRectSize.y && (it1->y >= 0 || segmentBoundary[tileSegmentIndex].y != Vector2f::infinity))
                            p.y *= scale.y;
                        else
                        {
                            float b = math::abs(p.y) - centerPoint.y;
                            p.y = centerPoint.y * scale.y + b;
                            p.y *= it1->y > 0 ? 1 : -1;
                        }

                        p = p + pivot + newCenterPoint + offset;
                        if (std::find_if(newPath.begin(), newPath.end(), PointSqrDistanceFindPredicate(p, sqrMinPointDistance)) == newPath.end())
                            newPath.push_back(p);
                    }
                }
                if (newPath.size() >= minPointPerPath)
                {
                    result.SetPathCount(result.GetPathCount() + 1);
                    result.SetPath(result.GetPathCount() - 1, newPath);
                }
            }
            offset.x += size.x;
        }
        offset.y += size.y;
    }
}

static void GenerateTilingJobCombine(GenerateTilingAreaInfo *data)
{
    for (int i = 0; i < data->jobCount; ++i)
    {
        Polygon2D& newPoints = data->segmentResult[data->outRectData[i].tileSegment];
        int pathCount = newPoints.GetPathCount();
        for (int j = 0; j < pathCount; ++j)
        {
            Polygon2D::TPath& path = newPoints.GetPath(j);
            if (path.size() > 0)
            {
                data->finalResult->SetPathCount(data->finalResult->GetPathCount() + 1);
                data->finalResult->SetPath(data->finalResult->GetPathCount() - 1, path);
            }
        }
    }
    UNITY_DELETE(data, kMemTempJobAlloc);
}

void PrepareTilingSegment(const SpriteTilingProperty& property, const Polygon2D& originalPath, Polygon2D(&tileSegment)[9])
{
    const Vector2f oldSize = property.oldSize;

    const Vector2f pivot = Vector2f(property.pivot.x * oldSize.x, property.pivot.y * oldSize.y);
    const Vector4f border = property.border;

    // Points for nine slice
    const Vector2f Pp = Vector2f(-pivot.x, -pivot.y);
    const Vector2f Ap = Vector2f(border.x + Pp.x, border.y + Pp.y);
    const Vector2f Bp = Vector2f(oldSize.x - border.z + Pp.x, border.y + Pp.y);
    const Vector2f Cp = Vector2f(border.x + Pp.x, oldSize.y - border.w + Pp.y);
    const Vector2f Dp = Vector2f(oldSize.x - border.z + Pp.x, oldSize.y - border.w + Pp.y);

    // Define the min max for each segment
    const Vector2f segmentMinMax[9][2] =
    {
        {-Vector2f::infinityVec, Ap},
        {Vector2f(Ap.x, -Vector2f::infinity), Bp},
        {Vector2f(Bp.x, -Vector2f::infinity), Vector2f(Vector2f::infinity, Bp.y)},
        {Vector2f(-Vector2f::infinity, Ap.y), Cp},
        {Ap, Dp},
        {Bp, Vector2f(Vector2f::infinity, Dp.y)},
        {Vector2f(-Vector2f::infinity, Cp.y), Vector2f(Cp.x, Vector2f::infinity)},
        {Cp, Vector2f(Dp.x, Vector2f::infinity)},
        {Dp, Vector2f::infinityVec}
    };

    // Pivot of each segment
    const Vector2f segmentPivot[9] =
    {
        Pp,
        Vector2f(Ap.x, Pp.y),
        Vector2f(Bp.x, Pp.y),
        Vector2f(Pp.x, Ap.y),
        Ap,
        Bp,
        Vector2f(Pp.x, Cp.y),
        Cp,
        Dp
    };

    // Border lines
    const Vector2f* segmentYlines[] = {&Ap, &Bp, &Cp, &Dp};
    const Vector2f* segmentXlines[] = {&Cp, &Ap, &Dp, &Bp};
    for (int j = 0; j < originalPath.GetPathCount(); ++j)
    {
        const Polygon2D::TPath& path = originalPath.GetPath(j);
        Vector2f it2 = path.back();

        for (Polygon2D::TPath::const_iterator it1 = path.begin(); it1 != path.end(); it2 = *it1, ++it1)
        {
            int segment2 = GetPointSegment(it2, Ap, Dp);
            AddPointToSegment(tileSegment, segment2, j, it2 - segmentPivot[segment2]);

            int segment1 = GetPointSegment(*it1, Ap, Dp);

            if (segment1 != segment2) // not on the same segment. There is an intersection
            {
                int start = std::min(segment1, segment2);
                int end = std::max(segment1, segment2);
                Vector2f result;
                dynamic_array<Vector2f> newPoints[9];
                for (int startY = start / 3; startY < end / 3; ++startY)
                {
                    int scStartIndex = 3 * startY;
                    if (IntersectLineSegmentWithLine(*it1, it2, *segmentYlines[startY * 2], *segmentYlines[startY * 2 + 1], result))
                    {
                        for (int sc = 0; sc < 6; ++sc)
                        {
                            Vector2f cappedResult = result;
                            cappedResult.x = std::max(cappedResult.x, segmentMinMax[scStartIndex + sc][0].x);
                            cappedResult.y = std::max(cappedResult.y, segmentMinMax[scStartIndex + sc][0].y);
                            cappedResult.x = std::min(cappedResult.x, segmentMinMax[scStartIndex + sc][1].x);
                            cappedResult.y = std::min(cappedResult.y, segmentMinMax[scStartIndex + sc][1].y);
                            newPoints[scStartIndex + sc].push_back(cappedResult);
                        }
                    }
                }

                for (int startX = start % 3; startX < end % 3; ++startX)
                {
                    if (IntersectLineSegmentWithLine(*it1, it2, *segmentXlines[startX * 2], *segmentXlines[startX * 2 + 1], result))
                    {
                        const int segmentInterested[] = {0, 1, 3, 4, 6, 7};
                        for (int sc = 0; sc < 6; ++sc)
                        {
                            int scStartIndex = segmentInterested[sc] + startX;
                            Vector2f cappedResult = result;
                            cappedResult.x = std::max(cappedResult.x, segmentMinMax[scStartIndex][0].x);
                            cappedResult.y = std::max(cappedResult.y, segmentMinMax[scStartIndex][0].y);
                            cappedResult.x = std::min(cappedResult.x, segmentMinMax[scStartIndex][1].x);
                            cappedResult.y = std::min(cappedResult.y, segmentMinMax[scStartIndex][1].y);
                            newPoints[scStartIndex].push_back(cappedResult);
                        }
                    }
                }
                PointDistanceSortPredicate pds; pds.startPoint = it2;
                for (int k = 0; k < 9; ++k)
                {
                    QSort(newPoints[k].begin(), newPoints[k].end(), pds);
                    for (dynamic_array<Vector2f>::iterator kkit = newPoints[k].begin(); kkit != newPoints[k].end(); ++kkit)
                        AddPointToSegment(tileSegment, k, j, *kkit - segmentPivot[k]);
                }
            }
        }
    }

    for (int i = 0; i < 9; ++i)
    {
        bool clear = true;
        for (int j = 0; j < tileSegment[i].GetPathCount(); ++j)
        {
            if (tileSegment[i].GetPath(j).size() > 1)
            {
                clear = false;
                break;
            }
        }
        if (clear)
            tileSegment[i].Clear();
    }
}

static int GetPointSegment(Vector2f point, Vector2f cp1, Vector2f cp2)
{
    //      ┌───┬───┬───┐
    //      │ 6 │ 7 │ 8 │
    //      ├──*C───*D──┤
    //      │ 3 │ 4 │ 5 │
    //      ├──*A──*B───┤
    //      │ 0 │ 1 │ 2 │
    //      *P──┴───┴───┘

    int segment = 0;
    if (cp2.y <= point.y)
        segment = 6;
    else if (cp1.y <= point.y)
        segment = 3;

    if (cp2.x <= point.x)
        segment += 2;
    else if (cp1.x <= point.x)
        segment += 1;

    return segment;
}

static int GetPointSegmentCapSize(Vector2f point, Vector2f cp1, Vector2f cp2, Vector2f min, Vector2f max)
{
    int segment = 0;

    if (cp2.y <= point.y && !CompareApproximately(cp2.y, max.y))
        segment = 6;
    else if ((cp1.y <= point.y && !CompareApproximately(cp1.y, max.y)) ||
             (cp1.y < min.y || CompareApproximately(cp1.y, min.y)))
        segment = 3;

    if (cp2.x <= point.x && !CompareApproximately(cp2.x, max.x))
        segment += 2;
    else if ((cp1.x <= point.x && !CompareApproximately(cp1.x, max.x)) ||
             (cp1.x < min.x || CompareApproximately(cp1.x, min.x)))
        segment += 1;

    return segment;
}

static void AddPointToSegment(Polygon2D(&tileSegment)[9], int segment, int pathIndex, const Vector2f& point)
{
    if (tileSegment[segment].GetPathCount() < pathIndex + 1)
    {
        tileSegment[segment].SetPathCount(pathIndex + 1);
    }

    Polygon2D::TPath& path = tileSegment[segment].GetPath(pathIndex);
    if (path.size() == 0 ||
        (!CompareApproximately(path.back(), point) &&
         !CompareApproximately(path.front(), point)))
    {
        path.push_back(point);
    }
}

static void InsertLineBorderIntersectPoints(const Vector2f& partialTile,
    const Vector4f& segmentBoundary,
    const Vector2f& p1,
    const Vector2f& p2,
    const Vector2f& offset,
    const float sqrMinPointDistance,
    const Polygon2D::TPath& existingPoints,
    Polygon2D::TPath& newPointPath)
{
    Vector2f intersectPoint;

    // don't have to test for top/right intersect if there is no boundary
    if (segmentBoundary.z != Vector2f::infinity)
    {
        if (IntersectLineSegmentWithLine(p1, p2, Vector2f(partialTile.x, 0), partialTile, intersectPoint))
        {
            Vector2f cappedResult = intersectPoint;
            float c = std::max(segmentBoundary.z, partialTile.x);
            cappedResult.x = std::min(cappedResult.x, c);
            c = std::max(segmentBoundary.w, partialTile.y);
            cappedResult.y = std::min(cappedResult.y, c);
            InsertNewPoint(cappedResult + offset, sqrMinPointDistance, existingPoints, newPointPath);
        }
    }

    if (segmentBoundary.w != Vector2f::infinity)
    {
        if (IntersectLineSegmentWithLine(p1, p2, Vector2f(0, partialTile.y), partialTile, intersectPoint))
        {
            Vector2f cappedResult = intersectPoint;
            float c = std::max(segmentBoundary.z, partialTile.x);
            cappedResult.x = std::min(cappedResult.x, c);
            c = std::max(segmentBoundary.w, partialTile.y);
            cappedResult.y = std::min(cappedResult.y, c);
            InsertNewPoint(cappedResult + offset, sqrMinPointDistance, existingPoints, newPointPath);
        }
    }
}

static void InsertNewPoint(const Vector2f& newPoint, const float sqrMinPointDistance, const Polygon2D::TPath& existingPoints, Polygon2D::TPath& newPointPath)
{
    if (std::find_if(existingPoints.begin(), existingPoints.end(), PointSqrDistanceFindPredicate(newPoint, sqrMinPointDistance)) == existingPoints.end() &&
        std::find_if(newPointPath.begin(), newPointPath.end(), PointSqrDistanceFindPredicate(newPoint, sqrMinPointDistance)) == newPointPath.end())
        newPointPath.push_back(newPoint);
}

bool operator!=(const SpriteTilingProperty& stp1, const SpriteTilingProperty& stp2)
{
    return !(stp1 == stp2);
}

bool operator==(const SpriteTilingProperty& stp1, const SpriteTilingProperty& stp2)
{
    return stp1.border == stp2.border &&
        stp1.pivot == stp2.pivot &&
        stp1.oldSize == stp2.oldSize &&
        stp1.newSize == stp2.newSize &&
        stp1.drawMode == stp2.drawMode &&
        stp1.adaptiveTiling == stp2.adaptiveTiling &&
        CompareApproximately(stp1.adaptiveTilingThreshold, stp2.adaptiveTilingThreshold);
}

void ScheduleGenerateBoxTilingShape(JobFence& jobFence, const SpriteTilingProperty& property, const float minPointDistance, const Vector2f(&boxPoint)[2], Polygon2D& result)
{
    GenerateTilingAreaInfo* jobData = UNITY_NEW(GenerateTilingAreaInfo, kMemTempJobAlloc)(kMemTempJobAlloc, kMemTempJobAlloc);
    jobData->minPointDistance = minPointDistance;
    // This is 1 because we are reusing GenerateTilingAreaJob on the min/max point of the box to determine their position during tiling
    jobData->minPointPerPath = 1;
    jobData->tileProperty = property;
    jobData->insertEdgePoint = true;
    jobData->finalResult = &result;
    jobData->tileSegment[0].SetPathCount(1);
    Polygon2D::TPath& path = jobData->tileSegment[0].GetPath(0);
    path.assign(boxPoint, &boxPoint[2]);
    ScheduleJob(jobFence, GenerateBoxTilingShapeJob, jobData);
}

void GenerateBoxTilingShapeJob(GenerateTilingAreaInfo* data)
{
    GenerateBoxTilingShape(data);
    UNITY_DELETE(data, kMemTempJobAlloc);
}

void GenerateBoxTilingShape(GenerateTilingAreaInfo* jobData)
{
    PROFILER_AUTO(gGenerateBoxTilingShape, NULL);

    using namespace math;

    Polygon2D& result = *jobData->finalResult;
    const SpriteTilingProperty& property = jobData->tileProperty;

    Assert(property.drawMode != kSpriteDrawModeSimple);

    float pStartX = 0, pEndX = 0, pStartY = 0, pEndY = 0; // start end points for points in sprite border

    const Vector2f& oldSize = property.oldSize;
    const Vector4f& border = property.border;

    const Vector2f pivot(property.pivot.x * oldSize.x, property.pivot.y * oldSize.y);

    // Points for nine slice
    const Vector2f Pp(-pivot.x, -pivot.y);
    const Vector2f Ap(border.x + Pp.x, border.y + Pp.y);
    const Vector2f Bp(oldSize.x - border.z + Pp.x, border.y + Pp.y);
    const Vector2f Cp(border.x + Pp.x, oldSize.y - border.w + Pp.y);
    const Vector2f Dp(oldSize.x - border.z + Pp.x, oldSize.y - border.w + Pp.y);

    int outRectDataCount;
    int outRectDataIndex[2] = {-1 , -1};
    NineSliceRectData::TileSegment tileSegment[2];
    float tileCount[2][2];
    Vector2f tileSizes[2];
    Polygon2D::TPath startPoints(kMemTempJobAlloc), endPoints(kMemTempJobAlloc);

    const Vector2f segmentPivot[9] =
    {
        Pp,
        Vector2f(Ap.x, Pp.y),
        Vector2f(Bp.x, Pp.y),
        Vector2f(Pp.x, Ap.y),
        Ap,
        Bp,
        Vector2f(Pp.x, Cp.y),
        Cp,
        Dp
    };

    Polygon2D::TPath& inputPath = jobData->tileSegment[0].GetPath(0);
    Vector2f boxPoint[] = {inputPath[0], inputPath[1]};
    jobData->tileSegment[0].Clear();

    CalculateStartEndSegment(Ap.x, Dp.x, boxPoint[0].x, boxPoint[1].x, pStartX, pEndX);
    CalculateStartEndSegment(Ap.y, Dp.y, boxPoint[0].y, boxPoint[1].y, pStartY, pEndY);

    {
        float4 spriteBordersInUnit = vload4f(property.border.GetPtr());
        float2 startPoint = vload2f(property.pivot.GetPtr());
        float2 tileSize = vload2f(property.newSize.GetPtr());
        float2 oldSize = vload2f(property.oldSize.GetPtr());
        startPoint = tileSize * startPoint * float1(-1);

        GetSourceAndDestinationRect(spriteBordersInUnit, startPoint, tileSize, oldSize, jobData->outRectData, outRectDataCount);
    }

    tileSegment[0] = (NineSliceRectData::TileSegment)GetPointSegmentCapSize(boxPoint[0], Ap, Dp, -pivot, oldSize - pivot);
    tileSegment[1] = (NineSliceRectData::TileSegment)GetPointSegmentCapSize(boxPoint[1], Ap, Dp, -pivot, oldSize - pivot);

    for (int i = 0; i < outRectDataCount; ++i)
    {
        if (jobData->outRectData[i].tileSegment == tileSegment[0])
            outRectDataIndex[0] = i;

        if (jobData->outRectData[i].tileSegment == tileSegment[1])
            outRectDataIndex[1] = i;

        if (outRectDataIndex[0] != -1 && outRectDataIndex[1] != -1)
            break;
    }

    if (outRectDataIndex[0] < 0 && outRectDataIndex[1] < 0) // nothing to generate
        return;

    for (int i = 0; i < 2; ++i)
    {
        if (outRectDataIndex[i] >= 0)
            continue;

        // Is in a segment that doesn't exist. Need to find another segment to place the point
        switch (tileSegment[i])
        {
            case NineSliceRectData::kTileSegmentBottomMid:
            {
                for (int j = 0; j < outRectDataCount; ++j)
                {
                    NineSliceRectData::TileSegment ts = jobData->outRectData[j].tileSegment;
                    if (ts == NineSliceRectData::kTileSegmentBottomLeft || ts == NineSliceRectData::kTileSegmentBottomRight)
                    {
                        outRectDataIndex[i] = j;
                        break;
                    }
                }
            }
            break;
            case NineSliceRectData::kTileSegmentLeft:
            {
                for (int j = 0; j < outRectDataCount; ++j)
                {
                    NineSliceRectData::TileSegment ts = jobData->outRectData[j].tileSegment;
                    if (ts == NineSliceRectData::kTileSegmentBottomLeft || ts == NineSliceRectData::kTileSegmentTopLeft)
                    {
                        outRectDataIndex[i] = j;
                        break;
                    }
                }
            }
            break;
            case NineSliceRectData::kTileSegmentMid:
            {
                for (int j = 0; j < outRectDataCount; ++j)
                {
                    NineSliceRectData::TileSegment ts = jobData->outRectData[j].tileSegment;
                    if (ts == NineSliceRectData::kTileSegmentBottomMid || ts == NineSliceRectData::kTileSegmentTopMid ||
                        ts == NineSliceRectData::kTileSegmentLeft || ts == NineSliceRectData::kTileSegmentRight)
                    {
                        outRectDataIndex[i] = j;
                        break;
                    }
                }
            }
            break;
            case NineSliceRectData::kTileSegmentRight:
            {
                for (int j = 0; j < outRectDataCount; ++j)
                {
                    NineSliceRectData::TileSegment ts = jobData->outRectData[j].tileSegment;
                    if (ts == NineSliceRectData::kTileSegmentBottomRight || ts == NineSliceRectData::kTileSegmentTopRight)
                    {
                        outRectDataIndex[i] = j;
                        break;
                    }
                }
                break;
            }
            case NineSliceRectData::kTileSegmentTopMid:
            {
                for (int j = 0; j < outRectDataCount; ++j)
                {
                    NineSliceRectData::TileSegment ts = jobData->outRectData[j].tileSegment;
                    if (ts == NineSliceRectData::kTileSegmentTopLeft || ts == NineSliceRectData::kTileSegmentTopRight)
                    {
                        outRectDataIndex[i] = j;
                        break;
                    }
                }
            }
            break;
            default:
                // Default, take the segment of the other point
                outRectDataIndex[i] = outRectDataIndex[(i + 1) % 2];
        }
        if (outRectDataIndex[i] != -1)
            tileSegment[i] = jobData->outRectData[outRectDataIndex[i]].tileSegment;
    }

    if (outRectDataIndex[0] < 0 && outRectDataIndex[1] < 0) // still nothing to generate
        return;

    if (tileSegment[0] >= NineSliceRectData::kTileSegmentLeft && tileSegment[0] <= NineSliceRectData::kTileSegmentRight &&
        tileSegment[1] >= NineSliceRectData::kTileSegmentLeft && tileSegment[1] <= NineSliceRectData::kTileSegmentRight)
    {
        if ((boxPoint[0].y < Ap.y && boxPoint[1].y < Ap.y) ||
            (boxPoint[0].y > Dp.y && boxPoint[1].y > Dp.y))
            return;
    }

    // Check if segment is bottom mid, mid or top mid i.e. value 1, 4, 7
    if (((tileSegment[0] - 1) % 3) == 0 && (((tileSegment[1] - 1) % 3) == 0))
    {
        if ((boxPoint[0].x < Ap.x && boxPoint[1].x < Ap.x) ||
            (boxPoint[0].x > Dp.x && boxPoint[1].x > Dp.x))
            return;
    }

    for (int i = 0; i < 2; ++i)
    {
        if (outRectDataIndex[i] < 0)
        {
            outRectDataIndex[i] = outRectDataIndex[(i + 1) % 2];
            tileSegment[i] = tileSegment[(i + 1) % 2];
            jobData->segmentResult[tileSegment[i]].Clear();
        }

        if (tileSegment[i] >= NineSliceRectData::kTileSegmentLeft && tileSegment[i] <= NineSliceRectData::kTileSegmentRight)
        {
            boxPoint[i].y = math::max(boxPoint[i].y, Ap.y);
            boxPoint[i].y = math::min(boxPoint[i].y, Dp.y);
        }

        // Check if segment is bottom mid, mid or top mid i.e. value 1, 4, 7
        if (((tileSegment[i] - 1) % 3) == 0)
        {
            boxPoint[i].x = math::max(boxPoint[i].x, Ap.x);
            boxPoint[i].x = math::min(boxPoint[i].x, Dp.x);
        }

        float2 tileSizesFloat2;
        GetTilingIterationData(jobData->outRectData[outRectDataIndex[i]], property.drawMode, property.adaptiveTiling, property.adaptiveTilingThreshold, tileSizesFloat2, tileCount[i]);
        vstore2f(tileSizes[i].GetPtr(), tileSizesFloat2);

        jobData->tileSegment[tileSegment[i]].SetPathCount(1);
        Polygon2D::TPath& path = jobData->tileSegment[tileSegment[i]].GetPath(0);
        path.resize_uninitialized(1);
        path[0] = boxPoint[i] - segmentPivot[tileSegment[i]];
        GenerateTilingAreaJob(jobData, outRectDataIndex[i]);
        Polygon2D& segmentResult = jobData->segmentResult[tileSegment[i]];
        if (i == 0)
        {
            if (jobData->tileProperty.drawMode == kSpriteDrawModeSliced || (pStartX <= 0 && pStartY <= 0))
            {
                if (segmentResult.GetPointCount() > 0)
                {
                    startPoints.push_back() = segmentResult.GetPoints()[0];
                    tileCount[0][1] = tileCount[0][0] = 1;
                }
            }
            else
            {
                for (int i = 0; i < segmentResult.GetPathCount(); ++i)
                {
                    const Polygon2D::TPath& p = segmentResult.GetPath(i);
                    startPoints.insert(startPoints.end(), p.begin(), p.end());
                }
            }
            if (tileSegment[0] == tileSegment[1])
                segmentResult.Clear(); // need to clear since end point is sharing the same segment
        }
        else
        {
            if (jobData->tileProperty.drawMode == kSpriteDrawModeSliced || (pEndX <= 0 && pEndY <= 0))
            {
                if (segmentResult.GetPathCount() > 0)
                {
                    Polygon2D::TPath& path = segmentResult.GetPath(segmentResult.GetPathCount() - 1);
                    if (path.size() > 0)
                    {
                        endPoints.push_back() = path[path.size() - 1];
                        tileCount[1][1] = tileCount[1][0] = 1;
                    }
                }
            }
            else
            {
                for (int i = 0; i < segmentResult.GetPathCount(); ++i)
                {
                    const Polygon2D::TPath& p = segmentResult.GetPath(i);
                    endPoints.insert(endPoints.end() , p.begin(), p.end());
                }
            }
        }
    }

    if (startPoints.size() <= 0 || endPoints.size() <= 0)
        return;

    // Fast path when start end points are at the edge where no tiling is required.
    if (jobData->tileProperty.drawMode == kSpriteDrawModeSliced || (pStartX <= 0 && pStartY <= 0 && pEndX <= 0 && pEndY <= 0))
    {
        if (startPoints.size() > 0 && endPoints.size() > 0)
        {
            Vector2f start = startPoints[0];
            Vector2f end = endPoints[0];
            result.SetPathCount(1);
            Polygon2D::TPath& newPath = result.GetPath(0);
            newPath.resize_uninitialized(4);
            newPath[0].Set(start.x, start.y);
            newPath[1].Set(start.x, end.y);
            newPath[2].Set(end.x, end.y);
            newPath[3].Set(end.x, start.y);
        }

        return;
    }

    tileCount[0][0] = Ceilf(tileCount[0][0]);
    tileCount[0][1] = Ceilf(tileCount[0][1]);
    tileCount[1][0] = Ceilf(tileCount[1][0]);
    tileCount[1][1] = Ceilf(tileCount[1][1]);

    Vector2f startPointDestRectPos, endPointDestRectPos;
    vstore2f(startPointDestRectPos.GetPtr(), jobData->outRectData[outRectDataIndex[0]].destRectPos);
    vstore2f(endPointDestRectPos.GetPtr(), jobData->outRectData[outRectDataIndex[1]].destRectPos);
    int resultPathCount = 0;
    result.SetPathCount(std::max(tileCount[0][1], tileCount[1][1]) * std::max(tileCount[0][0], tileCount[1][0]));

    for (int i = 0; i < tileCount[0][1] || i < tileCount[1][1]; ++i)
    {
        int startYIndex = i < tileCount[0][1] ? i : tileCount[0][1] - 1;
        int endYIndex = i < tileCount[1][1] ? i : tileCount[1][1] - 1;
        startYIndex *= tileCount[0][0];
        endYIndex *= tileCount[1][0];

        for (int j = 0; j < tileCount[0][0] || j < tileCount[1][0]; ++j)
        {
            int startXIndex = j < tileCount[0][0] ? j : tileCount[0][0] - 1;
            int endXIndex = j < tileCount[1][0] ? j : tileCount[1][0] - 1;

            Vector2f startP = startPoints[startYIndex + startXIndex], endP;

            // ran out of start points, need to generate startpoints
            if (tileCount[0][0] <= j)
                startP.x = tileSizes[1].x * j + endPointDestRectPos.x;
            if (tileCount[0][1] <= i)
                startP.y = tileSizes[1].y * i + endPointDestRectPos.y;


            if (endYIndex + endXIndex < endPoints.size())
                endP = endPoints[endYIndex + endXIndex];
            else
            {
                endP.x = tileSizes[0].x * j + tileSizes[0].x + startPointDestRectPos.x;
                endP.y = tileSizes[0].y * i + tileSizes[0].y + startPointDestRectPos.y;
            }

            //need to generate own end point for start point
            if (pEndX <= 0 && j < tileCount[0][0] - 1)
                endP.x = tileSizes[0].x * j + tileSizes[0].x + startPointDestRectPos.x;
            if (pEndY <= 0 && i < tileCount[0][1] - 1)
                endP.y = tileSizes[0].y * i + tileSizes[0].y + startPointDestRectPos.y;

            Polygon2D::TPath& newPath = result.GetPath(resultPathCount);
            newPath.resize_uninitialized(4);
            newPath[0].Set(startP.x, startP.y);
            newPath[1].Set(startP.x, endP.y);
            newPath[2].Set(endP.x, endP.y);
            newPath[3].Set(endP.x, startP.y);
            ++resultPathCount;
        }
    }
}

static void CalculateStartEndSegment(const float cp1, const float cp2, const float min, const float max, float &outStart, float &outEnd)
{
    outStart = outEnd = 0;
    if (!CompareApproximately(cp1, cp2))
    {
        if (min >= cp1 && min <= cp2)
            outStart = (min - cp1) / (cp2 - cp1);

        if (max >= cp1 && max <= cp2)
            outEnd = (cp2 - max) / (cp2 - cp1);
    }
}

static int FindTileSegmentIndex(const NineSliceRectData::TileSegment tileSegment, const NineSliceRectData(&rectData)[9], const int rectDataCount)
{
    for (int i = 0; i < rectDataCount; ++i)
    {
        if (rectData[i].tileSegment == tileSegment)
            return i;
    }
    return -1;
}
