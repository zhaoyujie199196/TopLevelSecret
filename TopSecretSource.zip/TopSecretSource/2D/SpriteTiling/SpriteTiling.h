#pragma once

#include "Runtime/Jobs/JobTypes.h"
#include "Runtime/Graphics/Mesh/SpriteRenderer.h"
#include "Runtime/Math/Simd/vec-types.h"
#include "Runtime/Utilities/dynamic_array.h"

class SharedSpriteRenderData;

struct NineSliceRectData
{
    enum TileSegment
    {
        kTileSegmentBottomLeft,
        kTileSegmentBottomMid,
        kTileSegmentBottomRight,
        kTileSegmentLeft,
        kTileSegmentMid,
        kTileSegmentRight,
        kTileSegmentTopLeft,
        kTileSegmentTopMid,
        kTileSegmentTopRight,
    };

    TileSegment tileSegment;
    math::float2 sourceRectPos;
    math::float2 sourceRectSize;
    math::float2 destRectPos;
    math::float2 destRectSize;
    NineSliceRectData() {}
};

struct SpriteTilingJobData
{
    math::float4 spriteUV;
    math::float1 adaptiveTilingThreshold;
    math::float2 spriteSizeInUnit;
    SharedMeshData* spriteRenderData;

    SpriteDrawMode drawMode;
    int rectDataCount;
    bool adaptiveTiling;

    NineSliceRectData rectData[9];

    SpriteTilingJobData() :
        spriteRenderData(NULL)
    {}
};


bool ScheduleSpriteTilingJob(JobFence& jobFence,
    SharedMeshData* spriteRenderData,
    const Vector2f spriteRendererSize,
    const SpriteDrawMode spriteRendererDrawMode,
    const bool adaptiveTiling,
    const float adaptiveTilingThreshold,
    const Sprite* sprite);

void GetSourceAndDestinationRect(const math::float4& spriteBordersInUnit,
    const math::float2& startPoint,
    const math::float2& tileSize,
    const math::float2& spriteSizeInUnit,
    NineSliceRectData outRectData[9],
    int& outRectDataCount);

void GetTilingIterationData(const NineSliceRectData& rectData,
    const SpriteDrawMode drawMode,
    const bool adaptiveTiling,
    const float adaptiveTilingThreshold,
    math::float2& size,
    float xyTileCount[2]);
