#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "Runtime/2D/SpriteTiling/SpriteTiling.h"
#include "Runtime/Testing/TestFixtures.h"
#include "Runtime/Testing/Testing.h"
#include "Runtime/Graphics/Mesh/SharedMeshData.h"
#include "Runtime/Graphics/SpriteUtility.h"

void GetSpriteTileVertexAndIndexCount(const math::float1& adaptiveTilingThreshold, const SpriteDrawMode drawMode, const bool adaptiveTiling, const NineSliceRectData rectData[9], const int rectDataCount, int& outIndexCount, int& outVertexCount);
void GenerateSpriteTileMesh(SpriteTilingJobData& jobData);

UNIT_TEST_SUITE(Generate9Slice)
{
    struct Fixture
    {
        SharedMeshData m_SpriteRenderData;
        SpriteTilingJobData m_JobData;
        float m_WorldUnit;
        math::float4 m_SpriteBordersInUnit;

        Fixture() : m_SpriteRenderData(kMemSprites)
        {
            const float textureSize = 128;
            const float pixelsToUnit = 100;
            m_JobData.spriteRenderData = &m_SpriteRenderData;
            m_JobData.spriteUV = math::float4(0, 0, 1, 1);
            m_JobData.spriteSizeInUnit = math::float2(textureSize, textureSize) / pixelsToUnit;
            m_WorldUnit = textureSize / pixelsToUnit;
        }

        void SetDrawMode(SpriteDrawMode drawMode)
        {
            m_JobData.drawMode = drawMode;
        }

        void SetTilingOption(bool adaptiveTiling, float threshold)
        {
            m_JobData.adaptiveTiling = adaptiveTiling;
            m_JobData.adaptiveTilingThreshold = threshold;
        }

        void CheckCorrectNumberOfQuadsGenerated(const math::float4& area, int quadCount)
        {
            const int kVertexPerQuad = 4;
            const int kIndicesPerQuad = 6;
            int indexCount, vertexCount;
            GetRequiredIndexAndVertexCount(area, indexCount, vertexCount);
            CHECK_EQUAL(quadCount * kVertexPerQuad, vertexCount);
            CHECK_EQUAL(quadCount * kIndicesPerQuad, indexCount);
        }

        void CheckVerticesAreWithinBounds(const SharedMeshData* sharedMeshData, const Vector2f& bottomLeft, const Vector2f& topRight)
        {
            const StrideIterator<Vector3f>& vertexBuffer = sharedMeshData->GetVertexData().MakeStrideIterator<Vector3f>(kShaderChannelVertex);
            const StrideIterator<Vector2f>& uvBuffer = sharedMeshData->GetVertexData().MakeStrideIterator<Vector2f>(kShaderChannelTexCoord0);
            for (int i = 0; i < sharedMeshData->GetVertexCount(); ++i)
            {
                CHECK(vertexBuffer[i].x >= bottomLeft.x);
                CHECK(vertexBuffer[i].y >= bottomLeft.y);
                CHECK(vertexBuffer[i].x <= topRight.x);
                CHECK(vertexBuffer[i].y <= topRight.y);
                CHECK(uvBuffer[i].x >= 0);
                CHECK(uvBuffer[i].y >= 0);
                CHECK(uvBuffer[i].x <= 1);
                CHECK(uvBuffer[i].y <= 1);
            }
        }

        void GetRequiredIndexAndVertexCount(const math::float4& area, int& outIndexCount, int& outVertexCount)
        {
            m_JobData.rectDataCount = 0;
            GetSourceAndDestinationRect(m_SpriteBordersInUnit, area.xy, area.zw, m_JobData.spriteSizeInUnit, m_JobData.rectData, m_JobData.rectDataCount);
            int totalIndexCount = 0, totalVertexCount = 0;
            GetSpriteTileVertexAndIndexCount(m_JobData.adaptiveTilingThreshold, m_JobData.drawMode, m_JobData.adaptiveTiling, m_JobData.rectData, m_JobData.rectDataCount, totalIndexCount, totalVertexCount);
            outVertexCount = totalVertexCount;
            outIndexCount = totalIndexCount;
        }

        void GenerateMesh(const math::float4& area)
        {
            int indexCount, vertexCount;
            GetRequiredIndexAndVertexCount(area, indexCount, vertexCount);
            SetSpriteMeshVertexCount(m_JobData.spriteRenderData, vertexCount);
            SetSpriteMeshIndexCount(m_JobData.spriteRenderData, indexCount);
            GenerateSpriteTileMesh(m_JobData);
        }
    };

    TEST_FIXTURE(Fixture, GetRequiredIndexAndVertexCount_FromSpriteWithBorders_WithSlicedModeAndAdaptiveTilingOff_ProducesCorrectNumberOfQuads)
    {
        m_SpriteBordersInUnit = math::float4(0.1f, 0.1f, 0.1f, 0.1f);
        SetDrawMode(kSpriteDrawModeSliced);
        SetTilingOption(false, 1);

        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit, m_WorldUnit), 9);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 2, m_WorldUnit), 9);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 2, m_WorldUnit * 2), 9);
    }

    // In kSpriteDrawModeSliced smartTiling have no effect
    TEST_FIXTURE(Fixture, GetRequiredIndexAndVertexCount_FromSpriteWithBorders_WithSlicedModeAndAdaptiveTilingOn_ProducesCorrectNumberOfQuads)
    {
        m_SpriteBordersInUnit = math::float4(0.1f, 0.1f, 0.1f, 0.1f);
        SetDrawMode(kSpriteDrawModeSliced);
        SetTilingOption(true, 1);

        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit, m_WorldUnit), 9);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 2, m_WorldUnit), 9);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 2, m_WorldUnit * 2), 9);
    }

    TEST_FIXTURE(Fixture, GenerateSpriteTileMesh_FromSpriteWithBorders_WithSlicedModeAndAdaptiveTilingOff_ProducesVerticesWithinBound)
    {
        m_SpriteBordersInUnit = math::float4(0.1f, 0.1f, 0.1f, 0.1f);
        SetDrawMode(kSpriteDrawModeSliced);
        SetTilingOption(false, 1);

        GenerateMesh(math::float4(0, 0, m_WorldUnit, m_WorldUnit));
        Vector2f bottomLeft(0, 0);
        Vector2f topRight(m_WorldUnit, m_WorldUnit);
        CheckVerticesAreWithinBounds(m_JobData.spriteRenderData, bottomLeft, topRight);
    }

    TEST_FIXTURE(Fixture, GetRequiredIndexAndVertexCount_FromSpriteWithBorders_WithTiledModeAndAdaptiveTilingOff_ProducesCorrectNumberOfQuads)
    {
        m_SpriteBordersInUnit = math::float4(0.1f, 0.1f, 0.1f, 0.1f);
        SetDrawMode(kSpriteDrawModeTiled);
        SetTilingOption(false, 0.5f);

        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit, m_WorldUnit), 9);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 1.1f, m_WorldUnit), 12);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 1.8f, m_WorldUnit), 12);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 2.1f, m_WorldUnit), 15);
    }

    TEST_FIXTURE(Fixture, GetRequiredIndexAndVertexCount_FromSpriteWithBorders_WithTiledModeAndAdaptiveTilingOn_ProducesCorrectNumberOfQuads)
    {
        m_SpriteBordersInUnit = math::float4(0.1f, 0.1f, 0.1f, 0.1f);
        SetDrawMode(kSpriteDrawModeTiled);
        SetTilingOption(true, 0.5f);

        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit, m_WorldUnit), 9);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 1.1f, m_WorldUnit), 9);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 1.8f, m_WorldUnit), 12);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 2.1f, m_WorldUnit), 12);
    }

    TEST_FIXTURE(Fixture, GenerateSpriteTileMesh_FromSpriteWithBorders_WithTiledModeAndAdaptiveTilingOff_ProducesVerticesWithinBound)
    {
        m_SpriteBordersInUnit = math::float4(0.1f, 0.1f, 0.1f, 0.1f);
        SetDrawMode(kSpriteDrawModeTiled);
        SetTilingOption(false, 1);

        GenerateMesh(math::float4(0, 0, m_WorldUnit, m_WorldUnit));
        Vector2f bottomLeft(0, 0);
        Vector2f topRight(m_WorldUnit, m_WorldUnit);
        CheckVerticesAreWithinBounds(m_JobData.spriteRenderData, bottomLeft, topRight);
    }

    /////////////////////////////////////////////////


    TEST_FIXTURE(Fixture, GetRequiredIndexAndVertexCount_FromSpriteWithoutBorders_WithSlicedModeAndAdaptiveTilingOff_ProducesCorrectNumberOfQuads)
    {
        m_SpriteBordersInUnit = math::float4(math::ZERO);
        SetDrawMode(kSpriteDrawModeSliced);
        SetTilingOption(false, 1);

        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit, m_WorldUnit), 1);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 2, m_WorldUnit), 1);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 2, m_WorldUnit * 2), 1);
    }

    // In kSpriteDrawModeSliced adaptiveTiling have no effect
    TEST_FIXTURE(Fixture, GetRequiredIndexAndVertexCount_FromSpriteWithoutBorders_WithSlicedModeAndAdaptiveTilingOn_ProducesCorrectNumberOfQuads)
    {
        m_SpriteBordersInUnit = math::float4(math::ZERO);
        SetDrawMode(kSpriteDrawModeSliced);
        SetTilingOption(true, 1);

        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit, m_WorldUnit), 1);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 2, m_WorldUnit), 1);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 2, m_WorldUnit * 2), 1);
    }

    TEST_FIXTURE(Fixture, GenerateSpriteTileMesh_FromSpriteWithoutBorders_WithSlicedModeAndAdaptiveTilingOff_ProducesVerticesWithinBound)
    {
        m_SpriteBordersInUnit = math::float4(math::ZERO);
        SetDrawMode(kSpriteDrawModeSliced);
        SetTilingOption(false, 1);

        GenerateMesh(math::float4(0, 0, m_WorldUnit, m_WorldUnit));
        Vector2f bottomLeft(0, 0);
        Vector2f topRight(m_WorldUnit, m_WorldUnit);
        CheckVerticesAreWithinBounds(m_JobData.spriteRenderData, bottomLeft, topRight);
    }

    TEST_FIXTURE(Fixture, GetRequiredIndexAndVertexCount_FromSpriteWithoutBorders_WithTiledModeAndAdaptiveTilingOff_ProducesCorrectNumberOfQuads)
    {
        m_SpriteBordersInUnit = math::float4(math::ZERO);
        SetDrawMode(kSpriteDrawModeTiled);
        SetTilingOption(false, 0.5f);

        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit, m_WorldUnit), 1);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 1.1f, m_WorldUnit), 2);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 1.8f, m_WorldUnit), 2);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 2.1f, m_WorldUnit), 3);
    }

    TEST_FIXTURE(Fixture, GetRequiredIndexAndVertexCount_FromSpriteWithoutBorders_WithTiledModeAndAdaptiveTilingOn_ProducesCorrectNumberOfQuads)
    {
        m_SpriteBordersInUnit = math::float4(math::ZERO);
        SetDrawMode(kSpriteDrawModeTiled);
        SetTilingOption(true, 0.5f);

        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit, m_WorldUnit), 1);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 1.1f, m_WorldUnit), 1);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 1.8f, m_WorldUnit), 2);
        CheckCorrectNumberOfQuadsGenerated(math::float4(0, 0, m_WorldUnit * 2.1f, m_WorldUnit), 2);
    }

    TEST_FIXTURE(Fixture, GenerateSpriteTileMesh_FromSpriteWithoutBorders_WithTiledModeAndAdaptiveTilingOff_ProducesVerticesWithinBound)
    {
        m_SpriteBordersInUnit = math::float4(math::ZERO);
        SetDrawMode(kSpriteDrawModeTiled);
        SetTilingOption(false, 1);

        GenerateMesh(math::float4(0, 0, m_WorldUnit, m_WorldUnit));
        Vector2f bottomLeft(0, 0);
        Vector2f topRight(m_WorldUnit, m_WorldUnit);
        CheckVerticesAreWithinBounds(m_JobData.spriteRenderData, bottomLeft, topRight);
    }
}

#endif // ENABLE_UNIT_TESTS
