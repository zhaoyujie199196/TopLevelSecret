#pragma once
#include "Runtime/BaseClasses/BaseObject.h"
#include "Runtime/BaseClasses/GameObject.h"
#include "Runtime/GameCode/Behaviour.h"
#include "Runtime/Graphics/Renderer.h"
#include "Runtime/Utilities/LinkedList.h"

class SortingGroup : public Behaviour
{
    REGISTER_CLASS_TRAITS(kTypeIsSealed);
    REGISTER_CLASS(SortingGroup);
    DECLARE_OBJECT_SERIALIZE();
public:

    SortingGroup(MemLabelId label, ObjectCreationMode mode);

    static void InitializeClass();

    virtual void MainThreadCleanup();
    virtual void SmartReset();

    virtual void AwakeFromLoad(AwakeFromLoadMode awakeMode);
    virtual void WillDestroyComponent();
    virtual void AddToManager();
    virtual void RemoveFromManager();

    inline bool GetNeedsSorting() const { return m_NeedsSorting; }
    void SetNeedsSorting(bool needsSorting);

    UInt32 GetLayerAndOrder() const;

    void SetSortingLayerID(int uniqueId);
    int GetSortingLayerID() const;
    core::string GetSortingLayerName() const;
    void SetSortingLayerName(const core::string& name);
    SInt16 GetSortingOrder() const { return m_SortingOrder; }
    void SetSortingOrder(SInt16 newValue);
    void SetupSortingOverride();

    GET_SET(UInt32, SortingGroupID, m_SortingGroupID);
    GET_SET(UInt32, SortingGroupOrder, m_SortingGroupOrder);
    GET_SET(UInt32, Index, m_ManagerIdx);

    inline bool IsActiveSortingGroup() { return GetEnabled() && IsAddedToManager() && GetIndex() != GlobalLayeringData::kInvalidSortingGroupID; }

    void FindRootSortingGroupAndSort();
    void Update();

private:
    void TransformChanged(int changeMask);

    static int SortChildren(int startIndex, UInt32 rootSortingGroupID, UInt32 parentSortingGroupID, dynamic_array<Renderer*>& renderers, dynamic_array<SortingGroup*>& sortingGroups);

    // From Renderer.h
    SInt32 m_SortingLayerID;
    SInt16 m_SortingLayer;
    SInt16 m_SortingOrder;

    bool m_NeedsSorting;

    UInt32 m_SortingGroupID : 20;
    UInt32 m_SortingGroupOrder : 12;

    UInt32 m_ManagerIdx;
    ListNode<SortingGroup> m_SortingGroupListNode;
};
