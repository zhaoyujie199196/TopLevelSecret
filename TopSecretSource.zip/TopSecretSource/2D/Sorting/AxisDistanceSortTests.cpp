#include "UnityPrefix.h"
#include "Configuration/UnityConfigure.h"

#if ENABLE_UNIT_TESTS

#include "Runtime/Testing/Testing.h"
#include "Runtime/Testing/Faking.h"
#include "Runtime/Testing/ParametricTest.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/Camera/RenderLoops/RenderLoopPrivate.h"
#include "Runtime/Camera/RenderLoops/RenderLoop.h"

void EvaluateObjectDepth(const RenderLoopContext& ctx, const AABB& worldAABB, float sortingBias, float& outDistanceForSort, float& outDistanceAlongView);

static std::ostream& operator<<(std::ostream& stream, const Vector3f& vec)
{
    stream << "{x: " << vec.x << ", y: " << vec.y << ", z: " << vec.z << "}";
    return stream;
}

UNIT_TEST_SUITE(AxisDistanceSortTests)
{
    struct CustomAxisSortTestFixture
    {
        RenderLoopContext ctx;
        AABB worldAABB;

        CustomAxisSortTestFixture()
            : ctx(kMemTempAlloc)
        {
            ctx.m_CurCameraMatrix = Matrix4x4f::identity;
            ctx.m_TransparencySortMode = Camera::kTransparencySortCustomAxis;
        }

        void Setup(Vector3f axisRotationInEulerDeg, Vector3f pos)
        {
            worldAABB.m_Center  = pos;
            worldAABB.m_Extent = Vector3f::one;

            Quaternionf rotation = EulerToQuaternion(axisRotationInEulerDeg  * kDeg2Rad);
            Vector3f axis = Normalize(RotateVectorByQuat(rotation, Vector3f(0, 0, 1.0f)));
            ctx.m_CurCameraTransparencySortAxis = axis;
        }
    };

    PARAMETRIC_TEST_SOURCE(AllTestAxii, (Vector3f, Vector3f, float, float))
    {
        PARAMETRIC_TEST_CASE_WITH_NAME("AlongPositiveZAxis", Vector3f(0, 0, 0), Vector3f(0, 0, 1.0f), 0.0f, -1.0f);
        PARAMETRIC_TEST_CASE_WITH_NAME("RotatedDown45", Vector3f(60.0f, 0, 0), Vector3f(0, 0, 1.0f), 0.0f, -0.5f);
        PARAMETRIC_TEST_CASE_WITH_NAME("RotatedDown45InNonUnitPosition", Vector3f(60.0f, 0, 0), Vector3f(0, 0, 10.0f), 0.0f, -0.5f);
        PARAMETRIC_TEST_CASE_WITH_NAME("RotatedUp45InNonUnitPosition", Vector3f(-60.0f, 0, 0), Vector3f(0, 0, 10.0f), 0.0f, -0.5f);
        PARAMETRIC_TEST_CASE_WITH_NAME("RotatedLeft45InNonUnitPosition", Vector3f(0, -60.0f, 0), Vector3f(0, 0, 10.0f), 0.0f, -0.5f);
        PARAMETRIC_TEST_CASE_WITH_NAME("RotatedRight45InNonUnitPosition", Vector3f(0, 60.0f, 0), Vector3f(0, 0, 10.0f), 0.0f, -0.5f);
        PARAMETRIC_TEST_CASE_WITH_NAME("AlongPositiveZAxisPositiveBias", Vector3f(0, 0, 0), Vector3f(0, 0, 1.0f), 3.0f, -4.0f);
        PARAMETRIC_TEST_CASE_WITH_NAME("AlongPositiveZAxisNegativeBias", Vector3f(0, 0, 0), Vector3f(0, 0, 1.0f), -3.0f, 2.0f);
    }

    PARAMETRIC_TEST_FIXTURE(CustomAxisSortTestFixture, EvaluateObjectDepth_WithCustomAxis_ReturnsSortDepthInCustomAxis, (Vector3f axisRotation, Vector3f pos, float bias, float result), AllTestAxii)
    {
        float epsilon = 0.000001f;

        Setup(axisRotation, pos);

        float outDistanceForSort;
        float outDistanceAlongView;

        EvaluateObjectDepth(ctx, worldAABB, bias, outDistanceForSort, outDistanceAlongView);

        // numbers are negated, because the smaller the number the earlier you get rendered,
        // but visually it means you are rendered at the bottom. Therefore, the farther back you are
        // the earlier you should render, so take a smaller number
        CHECK_CLOSE(result * Magnitude(pos), outDistanceForSort, epsilon);
    }
}

#endif
