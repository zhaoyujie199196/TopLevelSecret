#include "UnityPrefix.h"
#include "SortingGroupUtils.h"
#include "Runtime/2D/Sorting/SortingGroup.h"
#include "Runtime/Graphics/Renderer.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Transform/TransformAccess.h"
#include "Runtime/Transform/TransformHierarchyTypes.h"

#include "Runtime/Profiler/Profiler.h"

PROFILER_INFORMATION(gSortingGroup_UpdateRenderer, "SortingGroup.UpdateRenderer", kProfilerPlayerLoop)
PROFILER_INFORMATION(gSortingGroup_UpdateSortingGroup, "SortingGroup.UpdateSortingGroup", kProfilerPlayerLoop)

void SetSortingGroupIDIntoChildren(Transform* parent, UInt32 rootID)
{
    for (int i = 0; i < parent->GetChildrenCount(); i++)
    {
        Transform& child = parent->GetChild(i);

        SortingGroup* childGroup = child.QueryComponent<SortingGroup>();
        if (childGroup != NULL && childGroup->IsActiveSortingGroup())
        {
            childGroup->SetSortingGroupID(rootID);
            continue; // no need to descend into this one
        }

        GameObject& go = child.GetGameObject();
        int count = go.GetComponentCount();
        for (int j = 0; j < count; j++)
        {
            Renderer* renderer = go.QueryComponentAtIndex<Renderer>(j);
            if (renderer != NULL)
            {
                renderer->SetSortingGroupID(rootID);
            }
        }

        // Descend
        SetSortingGroupIDIntoChildren(&child, rootID);
    }
}

void SetSiblingRenderersParentGroupID(GameObject* go, UInt32 parentGroupID)
{
    int count = go->GetComponentCount();
    for (int j = 0; j < count; j++)
    {
        Renderer* sibling = go->QueryComponentAtIndex<Renderer>(j);
        if (sibling != NULL)
        {
            sibling->SetSortingGroupID(parentGroupID);
        }
    }
}

SortingGroup* FindEnabledAncestorSortingGroup(Unity::Component* component)
{
    GameObject* go = component->GetGameObjectPtr();
    if (go == NULL)
        return NULL;

    SortingGroup* ancestorSortingGroup = FindAncestorComponent<SortingGroup>(*go);
    if (ancestorSortingGroup)
    {
        if (ancestorSortingGroup->IsActiveSortingGroup())
            return ancestorSortingGroup;
        else
        {
            Transform* transform = ancestorSortingGroup->QueryComponent<Transform>();
            if (transform && transform->GetParent())
                return FindEnabledAncestorSortingGroup(transform->GetParent());
        }
    }
    return NULL;
}

void UpdateSortingGroupStatus(SortingGroup* sortingGroup)
{
    PROFILER_AUTO(gSortingGroup_UpdateSortingGroup, NULL);

    sortingGroup->SetSortingGroupID(GlobalLayeringData::kInvalidSortingGroupID);

    if (sortingGroup->IsActiveSortingGroup())
        sortingGroup->SetNeedsSorting(true);
    else
    {
        // Check if there is a parent sorting group to handle the sorting
        SortingGroup* ancestorSortingGroup = FindEnabledAncestorSortingGroup(sortingGroup);
        if (ancestorSortingGroup)
            ancestorSortingGroup->SetNeedsSorting(true);
        else
        {
            // Trigger sorting for any child sorting groups
            dynamic_array<SortingGroup*> allSortingGroups(kMemTempAlloc);
            GetComponentsInChildren<SortingGroup>(sortingGroup->GetGameObject(), allSortingGroups);
            for (dynamic_array<SortingGroup*>::iterator iter = allSortingGroups.begin(); iter != allSortingGroups.end(); ++iter)
            {
                SortingGroup* childSortingGroup = *iter;
                if (childSortingGroup->GetSortingGroupID() == sortingGroup->GetIndex())
                {
                    childSortingGroup->SetSortingGroupID(GlobalLayeringData::kInvalidSortingGroupID);
                    childSortingGroup->SetNeedsSorting(true);
                }
            }

            // Cleanup all renderers attached to this
            UpdateParentSortingGroupRecursive(sortingGroup);
        }
    }
}

void UpdateSortingGroupStatusForRenderer(Renderer* renderer)
{
    PROFILER_AUTO(gSortingGroup_UpdateRenderer, NULL);

    SortingGroup* sortingGroup = FindEnabledAncestorSortingGroup(renderer);
    if (sortingGroup)
    {
        sortingGroup->SetNeedsSorting(true);
    }
    else
    {
        renderer->SetSortingGroupID(GlobalLayeringData::kInvalidSortingGroupID);
    }
}

void UpdateParentSortingGroupRecursive(SortingGroup* sortingGroup)
{
    GameObject* go = sortingGroup->GetGameObjectPtr();
    if (go == NULL)
        return;

    Transform* tr = sortingGroup->QueryComponent<Transform>();
    if (tr == NULL)
        return;

    // Update parent sorting group IDs for all children
    UInt32 sortingGroupIdx = sortingGroup->IsActiveSortingGroup() ? sortingGroup->GetIndex() : GlobalLayeringData::kInvalidSortingGroupID;
    SetSiblingRenderersParentGroupID(go, sortingGroupIdx);
    SetSortingGroupIDIntoChildren(tr, sortingGroupIdx);
}
