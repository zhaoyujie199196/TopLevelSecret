#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS
#include "SortingGroup.h"
#include "SortingGroupManager.h"

#include "Runtime/Testing/TestFixtures.h"
#include "Runtime/Testing/Testing.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Shaders/ShaderImpl/ShaderPass.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/Graphics/Mesh/SpriteRenderer.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/BaseClasses/TagManager.h"
#include "Runtime/Camera/RenderLoops/RenderLoopPrivate.h"

UNIT_TEST_SUITE(SortingGroupTests)
{
    class SortingGroupTestFixture
    {
    protected:
        typedef std::vector<PPtr<GameObject> > GameObjectsVector;
        GameObjectsVector gameObjects;

        GameObject& CreateGameObject(const std::string& name, const char* componentName, ...)
        {
            va_list ap;
            va_start(ap, componentName);
            GameObject& result = ::CreateGameObjectWithVAList(name, componentName, ap);
            va_end(ap);

            gameObjects.push_back(PPtr<GameObject>(result.GetInstanceID()));
            return result;
        }

        Transform* AttachToParent(GameObject& child, Transform* parent)
        {
            Transform* transform = child.QueryComponentTransform();
            CHECK(transform);
            transform->SetParent(parent);
            return transform;
        }

        Transform* CreateGameObjectWithSpriteRenderer(const core::string& name, SpriteRenderer*& spriteRenderer, Transform* parent = NULL)
        {
            GameObject& result = ::CreateGameObject(name, "SpriteRenderer", NULL);
            gameObjects.push_back(PPtr<GameObject>(result.GetInstanceID()));
            spriteRenderer = result.QueryComponent<SpriteRenderer>();
            return AttachToParent(result, parent);
        }

        Transform* CreateGameObjectWithSortingGroup(const core::string& name, SortingGroup*& sortingGroup, Transform* parent = NULL)
        {
            GameObject& result = ::CreateGameObject(name, "SortingGroup", NULL);
            gameObjects.push_back(PPtr<GameObject>(result.GetInstanceID()));
            sortingGroup = result.QueryComponent<SortingGroup>();
            return AttachToParent(result, parent);
        }

        Transform* CreateGameObjectWithSpriteRendererAndSortingGroup(const core::string& name, SpriteRenderer*& spriteRenderer, SortingGroup*& sortingGroup, Transform* parent = NULL)
        {
            GameObject& result = ::CreateGameObject(name, "SpriteRenderer", "SortingGroup", NULL);
            gameObjects.push_back(PPtr<GameObject>(result.GetInstanceID()));
            spriteRenderer = result.QueryComponent<SpriteRenderer>();
            sortingGroup = result.QueryComponent<SortingGroup>();
            return AttachToParent(result, parent);
        }

        ~SortingGroupTestFixture()
        {
            for (GameObjectsVector::iterator it = gameObjects.begin(); it != gameObjects.end(); ++it)
            {
                if (!it->IsValid()) continue;

                if (!(*it)->IsDestroying())
                    DestroyObjectHighLevel(*it);
            }
        }
    };

    TEST_FIXTURE(SortingGroupTestFixture, ParentedToAnotherSortingGroup_ChildSortingGroupIDMatchesParentIndex)
    {
        SpriteRenderer* sr1;
        SpriteRenderer* sr2;
        SortingGroup* sg1;
        SortingGroup* sg2;

        Transform* tr1 = CreateGameObjectWithSpriteRendererAndSortingGroup("A", sr1, sg1);
        CreateGameObjectWithSpriteRendererAndSortingGroup("B", sr2, sg2, tr1);

        GetSortingGroupManager().Update();

        CHECK_EQUAL(sg1->GetIndex(), sg2->GetSortingGroupID());
    }

    TEST_FIXTURE(SortingGroupTestFixture, HasEmptyGoBetweenSortingGroup_ChildSortingGroupIDMatchesParentIndex)
    {
        SpriteRenderer* sr1;
        SpriteRenderer* sr2;
        SortingGroup* sg1;
        SortingGroup* sg2;

        Transform* tr1 = CreateGameObjectWithSpriteRendererAndSortingGroup("A", sr1, sg1);
        GameObject& go = CreateGameObject("Test", "Transform", NULL);
        Transform* tr2 = go.QueryComponentTransform();
        tr2->SetParent(tr1);
        CreateGameObjectWithSpriteRendererAndSortingGroup("B", sr2, sg2, tr2);

        GetSortingGroupManager().Update();

        CHECK_EQUAL(sg1->GetIndex(), sg2->GetSortingGroupID());
    }

    TEST_FIXTURE(SortingGroupTestFixture, MultiChildrenMultiLevel_ChildSortingGroupIDMatchesParentIndex)
    {
        SpriteRenderer* sr1;
        SpriteRenderer* sr2;
        SpriteRenderer* sr3;
        SpriteRenderer* sr4;
        SpriteRenderer* sr5;
        SpriteRenderer* sr6;
        SortingGroup* sg1;
        SortingGroup* sg2;

        Transform* sgtr1 = CreateGameObjectWithSpriteRendererAndSortingGroup("A", sr1, sg1);
        Transform* sgtr2 = CreateGameObjectWithSpriteRendererAndSortingGroup("B", sr2, sg2, sgtr1);
        CreateGameObjectWithSpriteRenderer("3", sr3, sgtr1);
        CreateGameObjectWithSpriteRenderer("4", sr4, sgtr1);
        CreateGameObjectWithSpriteRenderer("5", sr5, sgtr2);
        CreateGameObjectWithSpriteRenderer("6", sr6, sgtr2);

        GetSortingGroupManager().Update();

        CHECK_EQUAL(sg1->GetIndex(), sr1->GetSortingGroupID());
        CHECK_EQUAL(sg1->GetIndex(), sr2->GetSortingGroupID());
        CHECK_EQUAL(sg1->GetIndex(), sr3->GetSortingGroupID());
        CHECK_EQUAL(sg1->GetIndex(), sr4->GetSortingGroupID());
        CHECK_EQUAL(sg1->GetIndex(), sr5->GetSortingGroupID());
        CHECK_EQUAL(sg1->GetIndex(), sr6->GetSortingGroupID());
    }

    TEST_FIXTURE(SortingGroupTestFixture, MultiChildrenMultiLevel_SortingOrderIsCorrect)
    {
        SpriteRenderer* sr1;
        SpriteRenderer* sr2;
        SpriteRenderer* sr3;
        SpriteRenderer* sr4;
        SpriteRenderer* sr5;
        SpriteRenderer* sr6;
        SortingGroup* sg1;
        SortingGroup* sg2;

        Transform* sgtr1 = CreateGameObjectWithSpriteRendererAndSortingGroup("A", sr1, sg1);
        Transform* sgtr2 = CreateGameObjectWithSpriteRendererAndSortingGroup("B", sr2, sg2, sgtr1);
        CreateGameObjectWithSpriteRenderer("3", sr3, sgtr1);
        CreateGameObjectWithSpriteRenderer("4", sr4, sgtr1);
        CreateGameObjectWithSpriteRenderer("5", sr5, sgtr2);
        CreateGameObjectWithSpriteRenderer("6", sr6, sgtr2);

        sg1->SetSortingOrder(0);
        sg2->SetSortingOrder(2);

        sr1->SetSortingOrder(1);
        sr2->SetSortingOrder(3);
        sr3->SetSortingOrder(5);
        sr4->SetSortingOrder(-1);
        sr5->SetSortingOrder(1);
        sr6->SetSortingOrder(0);

        GetSortingGroupManager().Update();

        CHECK_EQUAL(0, sg1->GetSortingGroupOrder());
        CHECK_EQUAL(3, sg2->GetSortingGroupOrder());

        CHECK_EQUAL(2, sr1->GetSortingGroupOrder());
        CHECK_EQUAL(6, sr2->GetSortingGroupOrder());
        CHECK_EQUAL(7, sr3->GetSortingGroupOrder());
        CHECK_EQUAL(1, sr4->GetSortingGroupOrder());
        CHECK_EQUAL(5, sr5->GetSortingGroupOrder());
        CHECK_EQUAL(4, sr6->GetSortingGroupOrder());
    }

    TEST_FIXTURE(SortingGroupTestFixture, DisableSortingGroup_ResetsSortingGroupID)
    {
        SpriteRenderer* sr1;
        SpriteRenderer* sr2;
        SortingGroup* sg1;
        Transform* tr1 = CreateGameObjectWithSpriteRendererAndSortingGroup("A", sr1, sg1);
        CreateGameObjectWithSpriteRenderer("2", sr2, tr1);

        GetSortingGroupManager().Update();

        CHECK_EQUAL(sg1->GetIndex(), sr1->GetSortingGroupID());

        sg1->SetEnabled(false);
        GetSortingGroupManager().Update();

        CHECK_EQUAL(GlobalLayeringData::kInvalidSortingGroupID, sr1->GetSortingGroupID());

        sg1->SetEnabled(true);
        GetSortingGroupManager().Update();

        CHECK_EQUAL(sg1->GetIndex(), sr1->GetSortingGroupID());
    }

    TEST_FIXTURE(SortingGroupTestFixture, DestroySortingGroup_ResetsSortingGroupID)
    {
        SpriteRenderer* sr1;
        SpriteRenderer* sr2;
        SortingGroup* sg1;
        Transform* tr1 = CreateGameObjectWithSpriteRendererAndSortingGroup("A", sr1, sg1);
        CreateGameObjectWithSpriteRenderer("2", sr2, tr1);

        GetSortingGroupManager().Update();

        CHECK_EQUAL(sg1->GetIndex(), sr1->GetSortingGroupID());

        DestroyObjectHighLevel(sg1, true);
        CHECK_EQUAL(GlobalLayeringData::kInvalidSortingGroupID, sr1->GetSortingGroupID());
    }

    // Case 878518: "Invalid sorting group ID" assert when removing a sorting group
    TEST_FIXTURE(SortingGroupTestFixture, DestroyParentSortingGroup_ResetsSortingGroupIDForChildSortingGroup)
    {
        SpriteRenderer* sr1;
        SpriteRenderer* sr2;
        SpriteRenderer* sr3;
        SortingGroup* sg1;
        SortingGroup* sg2;
        Transform* tr1 = CreateGameObjectWithSpriteRendererAndSortingGroup("A", sr1, sg1);
        Transform* tr2 = CreateGameObjectWithSpriteRendererAndSortingGroup("B", sr2, sg2, tr1);
        CreateGameObjectWithSpriteRenderer("3", sr3, tr2);

        GetSortingGroupManager().Update();

        CHECK_EQUAL(sg1->GetIndex(), sr1->GetSortingGroupID());
        CHECK_EQUAL(sg1->GetIndex(), sg2->GetSortingGroupID());
        CHECK_EQUAL(sg1->GetIndex(), sr3->GetSortingGroupID());

        DestroyObjectHighLevel(sg1, true);
        CHECK_EQUAL(GlobalLayeringData::kInvalidSortingGroupID, sg2->GetSortingGroupID());
        CHECK_EQUAL(GlobalLayeringData::kInvalidSortingGroupID, sr1->GetSortingGroupID());

        GetSortingGroupManager().Update();
        CHECK_EQUAL(sg2->GetIndex(), sr3->GetSortingGroupID());
    }

    TEST_FIXTURE(SortingGroupTestFixture, ParentedToNonSortingGroup_ChildSortingGroupIDMatchesParentIndex)
    {
        SpriteRenderer* sr1;
        SpriteRenderer* sr2;
        SpriteRenderer* sr3;
        SortingGroup* sg1;
        SortingGroup* sg2;

        Transform* sgtr1 = CreateGameObjectWithSpriteRendererAndSortingGroup("A", sr1, sg1);
        Transform* gotr1 = CreateGameObjectWithSpriteRenderer("2", sr3, sgtr1);
        CreateGameObjectWithSpriteRendererAndSortingGroup("C", sr2, sg2, gotr1);

        GetSortingGroupManager().Update();

        CHECK_EQUAL(sg1->GetIndex(), sr3->GetSortingGroupID());
        CHECK_EQUAL(sg1->GetIndex(), sr2->GetSortingGroupID());
    }

    TEST_FIXTURE(SortingGroupTestFixture, UnParentedFromAnotherSortingGroup_ChildSortingGroupBecomesParent)
    {
        SpriteRenderer* sr1;
        SpriteRenderer* sr2;
        SortingGroup* sg1;
        SortingGroup* sg2;

        Transform* sgtr1 = CreateGameObjectWithSpriteRendererAndSortingGroup("A", sr1, sg1);
        Transform* sgtr2 = CreateGameObjectWithSpriteRendererAndSortingGroup("B", sr2, sg2, sgtr1);

        GetSortingGroupManager().Update();

        CHECK_EQUAL(sg1->GetIndex(), sr2->GetSortingGroupID());

        sgtr2->SetParent(NULL);
        GetSortingGroupManager().Update();

        CHECK_EQUAL(sg2->GetIndex(), sr2->GetSortingGroupID());
    }

    TEST_FIXTURE(SortingGroupTestFixture, UnParentedFromNonSortingGroup_SortingGroupIDMatchesParent)
    {
        SpriteRenderer* sr1;
        SpriteRenderer* sr2;
        SpriteRenderer* sr3;
        SortingGroup* sg1;
        SortingGroup* sg2;

        Transform* sgtr1 = CreateGameObjectWithSpriteRendererAndSortingGroup("A", sr1, sg1);
        Transform* gotr1 = CreateGameObjectWithSpriteRenderer("2", sr3, sgtr1);
        CreateGameObjectWithSpriteRendererAndSortingGroup("C", sr2, sg2, gotr1);

        GetSortingGroupManager().Update();

        // Unparent normal sprite
        gotr1->SetParent(NULL);
        GetSortingGroupManager().Update();

        CHECK_EQUAL(GlobalLayeringData::kInvalidSortingGroupID, sr3->GetSortingGroupID());
        CHECK_EQUAL(sg2->GetIndex(), sr2->GetSortingGroupID());
    }

    TEST_FIXTURE(SortingGroupTestFixture, NewlyAddedRenderer_SortingGroupIDMatchesParent)
    {
        GameObject& go = CreateGameObject("A", "Transform", "SortingGroup", NULL);
        SpriteRenderer* sr1 = (SpriteRenderer*)AddComponent(go, "SpriteRenderer");
        SortingGroup* sg1 = go.QueryComponent<SortingGroup>();

        GetSortingGroupManager().Update();

        // newly added renderer follows the group
        CHECK_EQUAL(sg1->GetIndex(), sr1->GetSortingGroupID());
    }

    TEST_FIXTURE(SortingGroupTestFixture, NewlyAddedSortingGroup_ChildSortingGroupIDMatchesNewParent)
    {
        GameObject& go = CreateGameObject("A", "Transform", "SpriteRenderer", NULL);
        SortingGroup* sg1 = (SortingGroup*)AddComponent(go, "SortingGroup");
        SpriteRenderer* sr1 = go.QueryComponent<SpriteRenderer>();

        GetSortingGroupManager().Update();

        // renderer follows the newly added group
        CHECK_EQUAL(sg1->GetIndex(), sr1->GetSortingGroupID());
    }

    TEST_FIXTURE(SortingGroupTestFixture, ReenableSortingGroup_ChildSortingGroupIDMatchesCurrentlyActiveParent)
    {
        SpriteRenderer* sr1;
        SpriteRenderer* sr2;
        SortingGroup* sg1;
        SortingGroup* sg2;
        Transform* sgtr1 = CreateGameObjectWithSpriteRendererAndSortingGroup("A", sr1, sg1);
        Transform* sgtr2 = CreateGameObjectWithSpriteRendererAndSortingGroup("B", sr2, sg2);

        GetSortingGroupManager().Update();

        CHECK_EQUAL(sg1->GetIndex(), sr1->GetSortingGroupID());
        CHECK_EQUAL(sg2->GetIndex(), sr2->GetSortingGroupID());

        sgtr2->SetParent(sgtr1);
        GetSortingGroupManager().Update();

        CHECK_EQUAL(sg1->GetIndex(), sr1->GetSortingGroupID());
        CHECK_EQUAL(sg1->GetIndex(), sr2->GetSortingGroupID()); // sr2 will follow sg1's group

        sg1->SetEnabled(false);
        GetSortingGroupManager().Update();

        CHECK_EQUAL(GlobalLayeringData::kInvalidSortingGroupID, sr1->GetSortingGroupID());
        CHECK_EQUAL(sg2->GetIndex(), sr2->GetSortingGroupID());

        sg1->SetEnabled(true);
        GetSortingGroupManager().Update();

        CHECK_EQUAL(sg1->GetIndex(), sr1->GetSortingGroupID());
        CHECK_EQUAL(sg1->GetIndex(), sr2->GetSortingGroupID());
    }

    TEST_FIXTURE(SortingGroupTestFixture, DeactivateSortingGroupGameObject_ChildSortingGroupIDMatchesCurrentlyActiveParent)
    {
        SpriteRenderer* sr1;
        SpriteRenderer* sr2;
        SpriteRenderer* sr3;
        SortingGroup* sg1;
        SortingGroup* sg2;
        SortingGroup* sg3;
        Transform* sgtr1 = CreateGameObjectWithSpriteRendererAndSortingGroup("A", sr1, sg1);
        Transform* sgtr2 = CreateGameObjectWithSpriteRendererAndSortingGroup("B", sr2, sg2);
        Transform* sgtr3 = CreateGameObjectWithSpriteRendererAndSortingGroup("C", sr3, sg3);

        GetSortingGroupManager().Update();

        CHECK_EQUAL(sg1->GetIndex(), sr1->GetSortingGroupID());
        CHECK_EQUAL(sg2->GetIndex(), sr2->GetSortingGroupID());
        CHECK_EQUAL(sg3->GetIndex(), sr3->GetSortingGroupID());

        sgtr2->SetParent(sgtr1);
        sgtr3->SetParent(sgtr2);
        GetSortingGroupManager().Update();

        CHECK_NOT_EQUAL(GlobalLayeringData::kInvalidSortingGroupID, sg2->GetIndex());
        CHECK_EQUAL(sg1->GetIndex(), sr1->GetSortingGroupID());
        CHECK_EQUAL(sg1->GetIndex(), sr2->GetSortingGroupID());
        CHECK_EQUAL(sg1->GetIndex(), sr3->GetSortingGroupID());

        sgtr2->GetGameObject().Deactivate();
        GetSortingGroupManager().Update();

        CHECK_EQUAL(GlobalLayeringData::kInvalidSortingGroupID, sg2->GetIndex());
        CHECK_EQUAL(sg1->GetIndex(), sr1->GetSortingGroupID());
        CHECK_EQUAL(sg1->GetIndex(), sr2->GetSortingGroupID());
        CHECK_EQUAL(sg1->GetIndex(), sr3->GetSortingGroupID());
    }

#if UNITY_EDITOR
    TEST_FIXTURE(SortingGroupTestFixture, UpdatingLayer_ChildSortingGroupIDMatchesParentIndex)
    {
        SpriteRenderer* sr1;
        SortingGroup* sg1;
        Transform* sgtr1 = CreateGameObjectWithSortingGroup("A", sg1);
        CreateGameObjectWithSpriteRenderer("2", sr1, sgtr1);

        GetSortingGroupManager().Update();

        int pgID = sr1->GetSortingGroupID();

        TagManager& tagMan = GetTagManager();
        tagMan.AddSortingLayer();
        core::string newLayerName = tagMan.GetSortingLayerName(1);

        sr1->SetSortingLayerName(newLayerName);
        GetSortingGroupManager().Update();

        int pgID2 = sr1->GetSortingGroupID();

        CHECK_EQUAL(sg1->GetIndex(), pgID);
        CHECK_EQUAL(pgID, pgID2);
    }

    TEST_FIXTURE(SortingGroupTestFixture, AddingLayer_SortingOrderIsCorrect)
    {
        SpriteRenderer* sr1;
        SpriteRenderer* sr2;
        SpriteRenderer* sr3;
        SpriteRenderer* sr4;
        SpriteRenderer* sr5;
        SpriteRenderer* sr6;
        SortingGroup* sg1;
        SortingGroup* sg2;

        Transform* sgtr1 = CreateGameObjectWithSpriteRendererAndSortingGroup("A", sr1, sg1);
        Transform* sgtr2 = CreateGameObjectWithSpriteRendererAndSortingGroup("B", sr2, sg2, sgtr1);

        CreateGameObjectWithSpriteRenderer("3", sr3, sgtr1);
        CreateGameObjectWithSpriteRenderer("4", sr4, sgtr1);
        CreateGameObjectWithSpriteRenderer("5", sr5, sgtr2);
        CreateGameObjectWithSpriteRenderer("6", sr6, sgtr2);

        TagManager& tagMan = GetTagManager();
        tagMan.AddSortingLayer();
        tagMan.AddSortingLayer();
        int newLayerId1 = tagMan.GetSortingLayerUniqueID(1);
        int newLayerId2 = tagMan.GetSortingLayerUniqueID(2);

        sg1->SetSortingLayerID(newLayerId2);
        sg1->SetSortingOrder(0);

        sg2->SetSortingLayerID(newLayerId1);
        sg2->SetSortingOrder(2);

        sr1->SetSortingLayerID(newLayerId2);
        sr1->SetSortingOrder(1);

        sr2->SetSortingOrder(3);

        sr3->SetSortingOrder(5);

        sr4->SetSortingLayerID(newLayerId1);
        sr4->SetSortingOrder(-1);

        sr5->SetSortingOrder(1);

        sr6->SetSortingLayerID(newLayerId2);
        sr6->SetSortingOrder(0);

        GetSortingGroupManager().Update();

        CHECK_EQUAL(0, sg1->GetSortingGroupOrder());
        CHECK_EQUAL(3, sg2->GetSortingGroupOrder());

        CHECK_EQUAL(7, sr1->GetSortingGroupOrder());
        CHECK_EQUAL(5, sr2->GetSortingGroupOrder());
        CHECK_EQUAL(1, sr3->GetSortingGroupOrder());
        CHECK_EQUAL(2, sr4->GetSortingGroupOrder());
        CHECK_EQUAL(4, sr5->GetSortingGroupOrder());
        CHECK_EQUAL(6, sr6->GetSortingGroupOrder());
    }
#endif
}

#endif
