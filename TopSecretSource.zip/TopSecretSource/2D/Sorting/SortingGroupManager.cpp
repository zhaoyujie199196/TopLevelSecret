#include "UnityPrefix.h"
#include "SortingGroupManager.h"

#include "Runtime/2D/Sorting/SortingGroup.h"

#include "Runtime/Core/Callbacks/PlayerLoopCallbacks.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Utilities/sort_indices.h"
#include "Runtime/Utilities/RegisterRuntimeInitializeAndCleanup.h"

#include "Runtime/Profiler/Profiler.h"

PROFILER_INFORMATION(gSortingGroupManagerUpdate, "SortingGroupManager.Update", kProfilerPlayerLoop)

SortingGroupManager::SortingGroupManager()
{
}

SortingGroupManager::~SortingGroupManager()
{
}

void SortingGroupManager::Update()
{
    PROFILER_AUTO(gSortingGroupManagerUpdate, NULL);

    if (!m_SortingGroups.size())
        return;

    SortingGroupList::iterator next, listEnd = m_SortingGroupList.end();
    for (SortingGroupList::iterator i = m_SortingGroupList.begin(); i != listEnd; i = next)
    {
        next = i;
        next++;
        SortingGroup& sortingGroup = **i;
        sortingGroup.Update();
    }

    m_DataArray.resize_uninitialized(m_SortingGroups.size());
    for (size_t idx = 0; idx < m_SortingGroups.size(); idx++)
    {
        SortingGroup* sortingGroup = m_SortingGroups[idx];
        // Sorting Group is root
        if (sortingGroup->GetSortingGroupID() == GlobalLayeringData::kInvalidSortingGroupID)
        {
            SortingGroupData& sortingData = m_DataArray[idx];
            Transform& transform = sortingGroup->GetComponent<Transform>();
            sortingData.aabb = AABB(transform.GetPosition(), Vector3f::one);
            sortingData.layerAndOrder = sortingGroup->GetLayerAndOrder();
        }
    }
}

void SortingGroupManager::AddSortingGroup(SortingGroup* sortingGroup)
{
    sortingGroup->SetIndex(m_SortingGroups.size());
    m_SortingGroups.push_back(sortingGroup);
}

void SortingGroupManager::RemoveSortingGroup(SortingGroup* sortingGroup)
{
    UInt32 idx = sortingGroup->GetIndex();
    if (idx >= m_SortingGroups.size() || idx == GlobalLayeringData::kInvalidSortingGroupID)
    {
        AssertMsg(false, "Invalid SortingGroup index set in SortingGroup");
        return;
    }

    bool needSwapUpdate = idx + 1 < m_SortingGroups.size();
    CachedSortingGroupArray::iterator iter = m_SortingGroups.begin() + idx;
    m_SortingGroups.erase_swap_back(iter);
    if (needSwapUpdate)
    {
        SortingGroup* swapbackSortingGroup = m_SortingGroups[idx];
        swapbackSortingGroup->SetIndex(idx);
        if (swapbackSortingGroup->IsActiveSortingGroup())
            swapbackSortingGroup->SetNeedsSorting(true);
    }

    sortingGroup->SetIndex(GlobalLayeringData::kInvalidSortingGroupID);
}

void SortingGroupManager::NeedsSorting(ListNode<SortingGroup>& sortingGroupNode)
{
    if (sortingGroupNode->GetIndex() != GlobalLayeringData::kInvalidSortingGroupID)
        m_SortingGroupList.push_front(sortingGroupNode);
}

void SortingGroupManager::CopyTo(SortingGroupDataArray& dest)
{
    dest.assign(m_DataArray.begin(), m_DataArray.end());
}

// Globals
static SortingGroupManager* gSortingGroupManager = NULL;

void SortingGroupManagerPlayerLoopUpdate()
{
    if (gSortingGroupManager)
        gSortingGroupManager->Update();
}

void InitializeSortingGroupManager(void* data)
{
    UNUSED(data);
    gSortingGroupManager = UNITY_NEW_AS_ROOT_NO_LABEL(SortingGroupManager, kMemManager, "Managers", "Sorting Group Manager");
    REGISTER_PLAYERLOOP_CALL(PostLateUpdate, SortingGroupsUpdate, SortingGroupManagerPlayerLoopUpdate());
}

void CleanupSortingGroupManager(void* data)
{
    UNUSED(data);
    UNREGISTER_PLAYERLOOP_CALL(PostLateUpdate, SortingGroupsUpdate);
    if (gSortingGroupManager)
    {
        UNITY_DELETE(gSortingGroupManager, kMemManager);
        gSortingGroupManager = NULL;
    }
}

SortingGroupManager& GetSortingGroupManager()
{
    AssertMsg(gSortingGroupManager, "Sorting Group Manager has not been initialized before use.");
    return *gSortingGroupManager;
}

static RegisterRuntimeInitializeAndCleanup s_RegisterSortingGroupManager(InitializeSortingGroupManager, CleanupSortingGroupManager);
