#include "UnityPrefix.h"
#include "SortingGroup.h"

#include "Runtime/2D/Sorting/SortingGroupManager.h"
#include "Runtime/2D/Sorting/SortingGroupUtils.h"

#include "Runtime/BaseClasses/MessageHandlerRegistration.h"
#include "Runtime/Camera/RenderNodeQueuePrepareContext.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Transform/TransformHierarchyTypes.h"
#include "Runtime/Utilities/sorting.h"

PROFILER_INFORMATION(gSortingGroup_SortChildren, "SortingGroup.SortChildren", kProfilerPlayerLoop)


IMPLEMENT_REGISTER_CLASS(SortingGroup, 210);
IMPLEMENT_OBJECT_SERIALIZE(SortingGroup);

void SortingGroup::InitializeClass()
{
    REGISTER_MESSAGE(kTransformChanged, TransformChanged, int);
}

SortingGroup::SortingGroup(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
    , m_SortingLayerID(0)
    , m_SortingLayer(0)
    , m_SortingOrder(0)
    , m_SortingGroupOrder(0)
    , m_NeedsSorting(false)
    , m_ManagerIdx(GlobalLayeringData::kInvalidSortingGroupID)
    , m_SortingGroupListNode(this)
{
}

void SortingGroup::MainThreadCleanup()
{
    Super::MainThreadCleanup();
    if (GlobalLayeringData::kInvalidSortingGroupID != m_ManagerIdx)
        GetSortingGroupManager().RemoveSortingGroup(this);
    m_SortingGroupListNode.RemoveFromList();
}

void SortingGroup::ThreadedCleanup()
{
}

void SortingGroup::SmartReset()
{
    Super::SmartReset();

    m_SortingLayerID = 0;
    m_SortingLayer = 0;
    m_SortingOrder = 0;
    SetupSortingOverride();
}

void SortingGroup::TransformChanged(int changeMask)
{
    if (changeMask & Transform::kParentingChanged)
    {
        UpdateSortingGroupStatus(this);
    }
}

void SortingGroup::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);
    if (awakeMode == kDefaultAwakeFromLoad || (awakeMode & (kInstantiateOrCreateFromCodeAwakeFromLoad | kAnimationAwakeFromLoad)))
        SetupSortingOverride();
}

void SortingGroup::WillDestroyComponent()
{
    if (GetEnabled() && GetGameObjectPtr())
    {
        SetEnabled(false);
        UpdateSortingGroupStatus(this);
    }
}

void SortingGroup::AddToManager()
{
    GetSortingGroupManager().AddSortingGroup(this);
    UpdateSortingGroupStatus(this);
}

void SortingGroup::RemoveFromManager()
{
    UpdateSortingGroupStatus(this);
    GetSortingGroupManager().RemoveSortingGroup(this);
    m_SortingGroupListNode.RemoveFromList();
}

template<class TransferFunction>
void SortingGroup::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);
    transfer.Transfer(m_SortingLayerID, "m_SortingLayerID", kHideInEditorMask);
    transfer.Transfer(m_SortingLayer, "m_SortingLayer", kHideInEditorMask);
    transfer.Transfer(m_SortingOrder, "m_SortingOrder", kHideInEditorMask);
    transfer.Align();
}

void SortingGroup::SetNeedsSorting(bool needsSorting)
{
    m_NeedsSorting = needsSorting;
    if (m_NeedsSorting)
        GetSortingGroupManager().NeedsSorting(m_SortingGroupListNode);
}

UInt32 SortingGroup::GetLayerAndOrder() const
{
    return GlobalLayeringData::CalculateLayerAndOrder(m_SortingLayer, m_SortingOrder);
}

void SortingGroup::SetSortingLayerID(int uniqueId)
{
    if (!GetTagManager().IsSortingLayerUniqueIDValid(uniqueId))
    {
        ErrorString("Invalid layer id. Please use the unique id of the layer (which is not the same as its index in the list).");
        return;
    }

#if UNITY_EDITOR
    if (uniqueId == m_SortingLayerID)
        return;
    m_SortingLayerID = uniqueId;
#endif

    m_SortingLayer = GetTagManager().GetSortingLayerValueFromUniqueID(uniqueId);
    SetupSortingOverride();
    SetDirty();
}

int SortingGroup::GetSortingLayerID() const
{
    return GetTagManager().GetSortingLayerUniqueIDFromValue(m_SortingLayer);
}

core::string SortingGroup::GetSortingLayerName() const
{
    return GetTagManager().GetSortingLayerNameFromValue(m_SortingLayer);
}

void SortingGroup::SetSortingLayerName(const core::string& name)
{
    int uniqueId = GetTagManager().GetSortingLayerUniqueIDFromName(name);
    SetSortingLayerID(uniqueId);
}

void SortingGroup::SetSortingOrder(SInt16 newValue)
{
    if (m_SortingOrder == newValue)
        return;

    m_SortingOrder = newValue;
    SetupSortingOverride();
}

void SortingGroup::SetupSortingOverride()
{
#if UNITY_EDITOR
    // In editor, make sure our final layer sorting value is up to date
    // (might have changed behind our backs by global layer reordering).
    m_SortingLayer = GetTagManager().GetSortingLayerValueFromUniqueID(m_SortingLayerID);
#endif // if UNITY_EDITOR
    UpdateSortingGroupStatus(this);
}

struct SortingGroupElement
{
    Object* object;
    UInt32 layerAndOrder;
};
typedef dynamic_array<SortingGroupElement> SortingGroupElementArray;

struct SortingGroupElementSorter
{
    inline bool operator()(const SortingGroupElement& lhs, const SortingGroupElement& rhs)
    {
        return lhs.layerAndOrder < rhs.layerAndOrder;
    }
};

struct SortingGroupElementEquals
{
    inline bool operator()(const SortingGroupElement& lhs, const SortingGroupElement& rhs)
    {
        return lhs.layerAndOrder == rhs.layerAndOrder;
    }
};

int SortingGroup::SortChildren(int startIndex, UInt32 rootSortingGroupID, UInt32 parentSortingGroupID, dynamic_array<Renderer*>& renderers, dynamic_array<SortingGroup*>& sortingGroups)
{
    SortingGroupElementArray elements(kMemTempAlloc);
    for (dynamic_array<Renderer*>::iterator iter = renderers.begin(); iter != renderers.end(); ++iter)
    {
        Renderer* renderer = *iter;
        if (renderer->GetSortingGroupID() == parentSortingGroupID)
        {
            SortingGroupElement& element = elements.push_back();
            element.object = renderer;
            element.layerAndOrder = renderer->GetGlobalLayeringData().layerAndOrder;
        }
    }
    for (dynamic_array<SortingGroup*>::iterator iter = sortingGroups.begin(); iter != sortingGroups.end(); ++iter)
    {
        SortingGroup* sortingGroup = *iter;
        if (sortingGroup->GetSortingGroupID() == parentSortingGroupID)
        {
            SortingGroupElement& element = elements.push_back();
            element.object = sortingGroup;
            element.layerAndOrder = sortingGroup->GetLayerAndOrder();
        }
    }

    QSortFast(elements.begin(), elements.end(), SortingGroupElementSorter(), SortingGroupElementEquals());

    int idx = startIndex;
    for (SortingGroupElementArray::iterator iter = elements.begin(); iter != elements.end(); ++iter)
    {
        Object* element = iter->object;
        if (element->Is<SortingGroup>())
        {
            SortingGroup* childGroup = reinterpret_cast<SortingGroup*>(element);
            childGroup->SetSortingGroupOrder(idx++);
            if (childGroup->IsActiveSortingGroup())
            {
                idx = SortChildren(idx, rootSortingGroupID != GlobalLayeringData::kInvalidSortingGroupID ? rootSortingGroupID : childGroup->GetIndex(), childGroup->GetIndex(), renderers, sortingGroups);
            }
            childGroup->SetNeedsSorting(false);
        }
        else
        {
            AssertMsg(element->Is<Renderer>(), "Element sorted by sorting group is not a renderer or a sorting group");
            Renderer* renderer = reinterpret_cast<Renderer*>(element);
            renderer->SetSortingGroupID(rootSortingGroupID);
            renderer->SetSortingGroupOrder(idx++);
        }
    }
    return idx;
}

void SortingGroup::FindRootSortingGroupAndSort()
{
    Transform& transform = GetComponent<Transform>();
    Transform* parent = transform.GetParent();

    // Check if there is a parent sorting group for this sorting group
    if (parent)
    {
        SortingGroup* sortingGroup = FindEnabledAncestorSortingGroup(parent);
        if (sortingGroup)
        {
            sortingGroup->FindRootSortingGroupAndSort();
            return;
        }
    }

    // Update parent sorting group for all renderers in tree
    dynamic_array<SortingGroup*> allSortingGroups(kMemTempAlloc);
    GetComponentsInChildren<SortingGroup>(GetGameObject(), allSortingGroups);
    for (dynamic_array<SortingGroup*>::iterator iter = allSortingGroups.begin(); iter != allSortingGroups.end(); ++iter)
    {
        SortingGroup* sortingGroup = *iter;
        if (sortingGroup->IsActiveSortingGroup())
        {
            UpdateParentSortingGroupRecursive(sortingGroup);
            sortingGroup->SetNeedsSorting(false);
        }
    }

    // Gather all renderers
    dynamic_array<Renderer*> allRenderers(kMemTempAlloc);
    GetComponentsInChildren<Renderer>(GetGameObject(), allRenderers);

    // Check if number of child renderers/sorting groups is within the order limit
    UInt32 num = allRenderers.size() + allSortingGroups.size();
    if (num > GlobalLayeringData::kMaxSortingGroupOrder)
    {
        ErrorStringMsg("Number of renderers and sorting groups handled (%d) is greater than the limit (%d), Sorting Group is disabled.", num, GlobalLayeringData::kMaxSortingGroupOrder);
        return;
    }

    // Sort all renderers if still needed
    SortChildren(1, IsActiveSortingGroup() ? GetIndex() : GlobalLayeringData::kInvalidSortingGroupID, GetIndex(), allRenderers, allSortingGroups);
}

void SortingGroup::Update()
{
    if (m_NeedsSorting)
    {
        PROFILER_AUTO(gSortingGroup_SortChildren, NULL);
        FindRootSortingGroupAndSort();
    }
    m_SortingGroupListNode.RemoveFromList();
}
