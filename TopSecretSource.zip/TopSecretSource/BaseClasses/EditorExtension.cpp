#include "UnityPrefix.h"
#include "EditorExtension.h"

#if UNITY_EDITOR

#include "Editor/Src/EditorExtensionImpl.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Editor/Src/Prefabs/PrefabBackwardsCompatibility.h"
#include "Runtime/Misc/GarbageCollectSharedAssetsMarking.h"

EditorExtension::EditorExtension(MemLabelId label, ObjectCreationMode mode)
    :   Super(label, mode)
{
}

void EditorExtension::ThreadedCleanup()
{
    Assert(m_DeprecatedExtensionPtr.GetInstanceID() == InstanceID_None);
}

bool EditorExtension::IsPrefabParent() const
{
    Prefab* prefab = m_Prefab;
    return prefab != NULL && prefab->IsPrefabParent();
}

template<class TransferFunction>
void EditorExtension::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);
    if (!transfer.IsSerializingForGameRelease())
    {
        if (SerializePrefabIgnoreProperties(transfer))
        {
            transfer.Transfer(m_PrefabParentObject, "m_PrefabParentObject", kHideInEditorMask);
            transfer.Transfer(m_Prefab, "m_PrefabInternal", kHideInEditorMask);
        }

        if (transfer.IsReadingBackwardsCompatible())
            transfer.Transfer(m_DeprecatedExtensionPtr, "m_ExtensionPtr", kHideInEditorMask);
    }
}

void EditorExtension::MarkDependencies(GarbageCollectorThreadState& gc) const
{
    MarkInstanceIDAsRoot(GetPrefab().GetInstanceID(), gc);
}

PPtr<EditorExtensionImpl> GetDeprecatedExtensionPtrIfExists(const Object& o)
{
    EditorExtension* extension = dynamic_pptr_cast<EditorExtension*>(&o);
    if (extension)
        return extension->m_DeprecatedExtensionPtr;
    else
        return NULL;
}

void EditorExtension::VirtualStrippedRedirectTransfer(YAMLRead& transfer)
{
    transfer.Transfer(*this, GetClassName());
}

void EditorExtension::VirtualStrippedRedirectTransfer(YAMLWrite& transfer)
{
    /////@TODO: Reader doesn't handle arbitrary base names correctly... Fix proper
    transfer.BeginMetaGroup(GetClassName());

    Transfer(transfer);

    transfer.EndMetaGroup();
}

void EditorExtension::VirtualStrippedRedirectTransfer(JSONRead& transfer)
{
    transfer.TransferBase(*this);
}

void EditorExtension::VirtualStrippedRedirectTransfer(JSONWrite& transfer)
{
    transfer.TransferBase(*this);
}

void EditorExtension::VirtualStrippedRedirectTransfer(SafeBinaryRead& transfer)
{
    transfer.Transfer(*this, "Base");
}

void EditorExtension::VirtualStrippedRedirectTransfer(StreamedBinaryRead<false>& transfer)
{
    transfer.Transfer(*this, "Base");
}

void EditorExtension::VirtualStrippedRedirectTransfer(StreamedBinaryRead<true>& transfer)
{
    transfer.Transfer(*this, "Base");
}

void EditorExtension::VirtualStrippedRedirectTransfer(StreamedBinaryWrite<false>& transfer)
{
    transfer.TransferBase(*this);
}

void EditorExtension::VirtualStrippedRedirectTransfer(StreamedBinaryWrite<true>& transfer)
{
    transfer.TransferBase(*this);
}

void EditorExtension::VirtualStrippedRedirectTransfer(GenerateTypeTreeTransfer& transfer)
{
    transfer.TransferBase(*this);
}

void EditorExtension::AwakeFromLoad(AwakeFromLoadMode mode)
{
    Super::AwakeFromLoad(mode);
    PatchPrefabBackwardsCompatibility(*this, NULL);
}

IMPLEMENT_OBJECT_SERIALIZE(EditorExtension);

IMPLEMENT_REGISTER_CLASS(EditorExtension, 18);
INSTANTIATE_TEMPLATE_TRANSFER(EditorExtension);

#else

IMPLEMENT_REGISTER_CLASS(EditorExtension, 18);

void EditorExtension::ThreadedCleanup()
{
}

#endif
