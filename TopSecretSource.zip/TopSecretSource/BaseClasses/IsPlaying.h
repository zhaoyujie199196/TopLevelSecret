#ifndef ISPLAYING_H
#define ISPLAYING_H

/// Is the world playmode? (Otherwise we are in editor mode)
bool EXPORT_COREMODULE IsWorldPlaying();

void SetIsWorldPlaying(bool isPlaying);

#endif
