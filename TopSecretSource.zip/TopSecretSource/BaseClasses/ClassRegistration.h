#pragma once
#include "TypeInfo.h"

// TODO (ulfj) : This header should be removed
