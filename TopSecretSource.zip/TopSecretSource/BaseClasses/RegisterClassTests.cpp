//
// These tests are here to ensure that legacy class-ids are never modified and to
// ensure that no copy-paste errors occurred during the process of moving the legacy
// class registration to the new class registration code.
//

#include "UnityPrefix.h"

#if UNITY_EDITOR
#if ENABLE_UNIT_TESTS

#include "Runtime/Testing/Testing.h"
#include "TypeInfoManager.h"
#include "Runtime/Serialize/SerializeUtility.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Serialize/TransferFunctions/YAMLWrite.h"
#include "Runtime/Serialize/TransferFunctions/YAMLRead.h"
#include "Editor/Src/AssetPipeline/AssetImporter.h"
#include "Runtime/Serialize/TransferFunctions/GenerateTypeTreeTransfer.h"

namespace Unity
{
    class Component;
    class Cloth;
    class Joint;
    class HingeJoint;
    class FixedJoint;
    class CharacterJoint;
    class SpringJoint;
    class ConfigurableJoint;
}

namespace BuildReporting
{
    class BuildReport;
    class PackedAssets;
}

namespace UI
{
    class CanvasRenderer;
    class Canvas;
    class RectTransform;
    class CanvasGroup;
}

namespace TextRenderingPrivate
{
    class TextMesh;
    class GUIText;
}

namespace TextRendering
{
    class Font;
}

#if UNITY_PS4
class TextureRawPS4;
#endif

#if !UNITY_LINUX
//  class GISRaster;            // verified nonexistent outside of ClassID enum
//  class GISRasterImporter;    // verified nonexistent outside of ClassID enum
//  class CadImporter;          // not part of standard unity, and code isn't included in unity test
#endif


//class ReflectionProbes;       // legacy constant, verified nonexistent outside of ClassID enum

class Object;
class GameObject;
class LevelGameManager;
class Transform;
class TimeManager;
class GlobalGameManager;
class Behaviour;
class GameManager;
class AudioManager;
class ParticleAnimator;
class InputManager;
class EllipsoidParticleEmitter;
class EditorExtension;
class Physics2DSettings;
class Camera;
class Material;
class MeshRenderer;
class Renderer;
class ParticleRenderer;
class Texture;
class Texture2D;
class OcclusionCullingSettings;
class GraphicsSettings;
class MeshFilter;
class OcclusionPortal;
class Mesh;
class Skybox;
class QualitySettings;
class Shader;
class TextAsset;
class Rigidbody2D;
class Collider2D;
class Rigidbody;
class PhysicsManager;
class Collider;
class CircleCollider2D;
class HingeJoint;
class PolygonCollider2D;
class BoxCollider2D;
class PhysicsMaterial2D;
class MeshCollider;
class BoxCollider;
class CompositeCollider2D;
class EdgeCollider2D;
class CapsuleCollider2D;
class ComputeShader;
class AnimationClip;
class ConstantForce;
class WorldParticleCollider;
class TagManager;
class AudioListener;
class AudioSource;
class AudioClip;
class RenderTexture;
class CustomRenderTexture;
class MeshParticleEmitter;
class ParticleEmitter;
class Cubemap;
class Avatar;
class AnimatorController;
class GUILayer;
class RuntimeAnimatorController;
class ScriptMapper;
class Animator;
class TrailRenderer;
class DelayedCallManager;
class RenderSettings;
class Light;
class CGProgram;
class BaseAnimationTrack;
class Animation;
class MonoBehaviour;
class MonoScript;
class MonoManager;
class Texture3D;
class NewAnimationTrack;
class Projector;
class LineRenderer;
class Flare;
class Halo;
class LensFlare;
class FlareLayer;
class HaloLayer;
class NavMeshProjectSettings;
class PlayerSettings;
class NamedObject;
class GUITexture;
namespace TextRenderingPrivate
{ class GUIText; }
class GUIElement;
class PhysicMaterial;
class SphereCollider;
class CapsuleCollider;
class SkinnedMeshRenderer;
class BuildSettings;
class AssetBundle;
class CharacterController;
class WheelCollider;
class ResourceManager;
class NetworkView;
class NetworkManager;
class PreloadData;
class MovieTexture;
class TerrainCollider;
class MasterServerInterface;
class TerrainData;
class LightmapSettings;
class WebCamTexture;
class EditorSettings;
class EditorUserSettings;
class AudioReverbFilter;
class AudioHighPassFilter;
class AudioChorusFilter;
class AudioReverbZone;
class AudioEchoFilter;
class AudioLowPassFilter;
class AudioDistortionFilter;
class SparseTexture;
class AudioBehaviour;
class AudioFilter;
class WindZone;
class SubstanceArchive;
class ProceduralMaterial;
class ProceduralTexture;
class Texture2DArray;
class CubemapArray;
class OffMeshLink;
class OcclusionArea;
class Tree;
class NavMeshAgent;
class NavMeshSettings;
class ParticleSystem;
class ParticleSystemRenderer;
class ShaderVariantCollection;
class LODGroup;
class BlendTree;
class Motion;
class NavMeshObstacle;
class Terrain;
class SortingGroup;
class SpriteRenderer;
class Sprite;
class CachedSpriteAtlas;
class ReflectionProbe;
class LightProbeGroup;
class AnimatorOverrideController;
class BillboardAsset;
class BillboardRenderer;
class SpeedTreeWindAsset;
class AnchoredJoint2D;
class Joint2D;
class SpringJoint2D;
class DistanceJoint2D;
class HingeJoint2D;
class SliderJoint2D;
class WheelJoint2D;
class ClusterInputManager;
class BaseVideoTexture;
class NavMeshData;
class AudioMixer;
class AudioMixerController;
class AudioMixerGroupController;
class AudioMixerEffectController;
class AudioMixerSnapshotController;
class PhysicsUpdateBehaviour2D;
class ConstantForce2D;
class Effector2D;
class AreaEffector2D;
class PointEffector2D;
class PlatformEffector2D;
class SurfaceEffector2D;
class BuoyancyEffector2D;
class RelativeJoint2D;
class FixedJoint2D;
class FrictionJoint2D;
class TargetJoint2D;
class LightProbes;
class LightProbeProxyVolume;
class SampleClip;
class AudioMixerSnapshot;
class AudioMixerGroup;
class NScreenBridge;
class AssetBundleManifest;
class UnityAdsManager;
class RuntimeInitializeOnLoadManager;
class CloudWebServicesManager;
class UnityAnalyticsManager;
class CrashReportManager;
class PerformanceReportingManager;
#if (ENABLE_CLOUD_SERVICES)
class UnityConnectSettings;
#endif
#if ENABLE_DIRECTOR_AUDIO
class AudioPlayer;
#endif
//class BatchedSpriteRenderer;  // currently disabled and not included in builds
//class SpriteDataProvider;     // currently disabled and not included in builds
//class SmartSprite;            // currently disabled and not included in builds
#if ENABLE_HOLOLENS_MODULE_API
class WorldAnchor;
#endif
class OcclusionCullingData;
#if ENABLE_MARSHALLING_TESTS
class MarshallingTestObject;
#endif
class Prefab;
class EditorExtensionImpl;
class AssetImporter;
class AssetDatabase;
class Mesh3DSImporter;
class TextureImporter;
class ShaderImporter;
class ComputeShaderImporter;
class AvatarMask;
class AudioImporter;
class HierarchyState;
class AssetMetaData;
class DefaultAsset;
class DefaultImporter;
class TextScriptImporter;
class SceneAsset;
class NativeFormatImporter;
class MonoImporter;
class AssetServerCache;
class LibraryAssetImporter;
class ModelImporter;
class FBXImporter;
class TrueTypeFontImporter;
class MovieImporter;
class EditorBuildSettings;
class DDSImporter;
class InspectorExpandedState;
class AnnotationManager;
class PluginImporter;
class EditorUserBuildSettings;
class PVRImporter;
class ASTCImporter;
class KTXImporter;
class IHVImageFormatImporter;
class AnimatorStateTransition;
class AnimatorState;
class HumanTemplate;
class AnimatorStateMachine;
class PreviewAnimationClip;
class AnimatorTransition;
class SpeedTreeImporter;
class AnimatorTransitionBase;
class SubstanceImporter;
class LightmapParameters;
class LightingDataAsset;
#if !UNITY_LINUX
class SketchUpImporter;
#endif

#if ENABLE_VIDEO
class VideoClipImporter;
#endif
#if ENABLE_UNIT_TESTS
class ActivationLogComponent;
#endif

REGRESSION_TEST_SUITE(RegisterClassTests)
{
    TEST(EnsureIsEditorOnlyIsUnmodified)
    {
        // using macro for readability, not using a for-loop since that won't tell you *which* type has failed
        #define ENSURE_EDITOR_ONLY_CONSISTENCY(x) CHECK_EQUAL(x->IsEditorOnly(), IsEditorOnlyClassInternal(static_cast<ClassIDType>(x->GetPersistentTypeID())));

        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Object>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<GameObject>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Unity::Component>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<LevelGameManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Transform>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<TimeManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<GlobalGameManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Behaviour>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<GameManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ParticleAnimator>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<InputManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<EllipsoidParticleEmitter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<EditorExtension>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Physics2DSettings>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Camera>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Material>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<MeshRenderer>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Renderer>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ParticleRenderer>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Texture>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Texture2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<OcclusionCullingSettings>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<GraphicsSettings>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<MeshFilter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<OcclusionPortal>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Mesh>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Skybox>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<QualitySettings>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Shader>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<TextAsset>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Rigidbody2D>());
        //      ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Physics2DManager>());     // legacy constant, verified nonexistent outside of ClassID enum
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Collider2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Rigidbody>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<PhysicsManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Collider>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Unity::Joint>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<CircleCollider2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Unity::HingeJoint>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<PolygonCollider2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<BoxCollider2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<PhysicsMaterial2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<MeshCollider>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<BoxCollider>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<CompositeCollider2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<EdgeCollider2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<CapsuleCollider2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ComputeShader>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AnimationClip>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ConstantForce>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<WorldParticleCollider>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<TagManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioListener>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioSource>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioClip>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<RenderTexture>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<CustomRenderTexture>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<MeshParticleEmitter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ParticleEmitter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Cubemap>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Avatar>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AnimatorController>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<GUILayer>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<RuntimeAnimatorController>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ScriptMapper>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Animator>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<TrailRenderer>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<DelayedCallManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<TextRenderingPrivate::TextMesh>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<RenderSettings>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Light>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<CGProgram>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<BaseAnimationTrack>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Animation>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<MonoBehaviour>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<MonoScript>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<MonoManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Texture3D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<NewAnimationTrack>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Projector>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<LineRenderer>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Flare>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Halo>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<LensFlare>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<FlareLayer>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<HaloLayer>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<NavMeshProjectSettings>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<TextRendering::Font>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<PlayerSettings>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<NamedObject>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<GUITexture>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<TextRenderingPrivate::GUIText>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<GUIElement>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<PhysicMaterial>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SphereCollider>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<CapsuleCollider>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SkinnedMeshRenderer>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Unity::FixedJoint>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<BuildSettings>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AssetBundle>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<CharacterController>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Unity::CharacterJoint>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Unity::SpringJoint>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<WheelCollider>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ResourceManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<NetworkView>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<NetworkManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<PreloadData>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<MovieTexture>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Unity::ConfigurableJoint>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<TerrainCollider>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<MasterServerInterface>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<TerrainData>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<LightmapSettings>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<WebCamTexture>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<EditorSettings>());
        //      ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<InteractiveCloth>());     // legacy constant, verified nonexistent outside of ClassID enum
        //      ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ClothRenderer>());        // legacy constant, verified nonexistent outside of ClassID enum
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<EditorUserSettings>());
        //      ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SkinnedCloth>());         // legacy constant, verified nonexistent outside of ClassID enum
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioReverbFilter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioHighPassFilter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioChorusFilter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioReverbZone>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioEchoFilter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioLowPassFilter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioDistortionFilter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SparseTexture>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioBehaviour>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioFilter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<WindZone>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Unity::Cloth>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SubstanceArchive>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ProceduralMaterial>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ProceduralTexture>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Texture2DArray>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<CubemapArray>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<OffMeshLink>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<OcclusionArea>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Tree>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<NavMeshAgent>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<NavMeshSettings>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ParticleSystem>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ParticleSystemRenderer>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ShaderVariantCollection>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<LODGroup>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<BlendTree>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Motion>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<NavMeshObstacle>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Terrain>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SortingGroup>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SpriteRenderer>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Sprite>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<CachedSpriteAtlas>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ReflectionProbe>());
        //      ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ReflectionProbes>());     // legacy constant, verified nonexistent outside of ClassID enum
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<LightProbeGroup>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AnimatorOverrideController>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<UI::CanvasRenderer>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<UI::Canvas>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<UI::RectTransform>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<UI::CanvasGroup>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<BillboardAsset>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<BillboardRenderer>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SpeedTreeWindAsset>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AnchoredJoint2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Joint2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SpringJoint2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<DistanceJoint2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<HingeJoint2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SliderJoint2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<WheelJoint2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ClusterInputManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<BaseVideoTexture>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<NavMeshData>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioMixer>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioMixerController>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioMixerGroupController>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioMixerEffectController>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioMixerSnapshotController>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<PhysicsUpdateBehaviour2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ConstantForce2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Effector2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AreaEffector2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<PointEffector2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<PlatformEffector2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SurfaceEffector2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<BuoyancyEffector2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<RelativeJoint2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<FixedJoint2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<FrictionJoint2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<TargetJoint2D>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<LightProbes>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<LightProbeProxyVolume>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SampleClip>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioMixerSnapshot>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioMixerGroup>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<NScreenBridge>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AssetBundleManifest>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<UnityAdsManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<RuntimeInitializeOnLoadManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<CloudWebServicesManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<UnityAnalyticsManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<CrashReportManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<PerformanceReportingManager>());
#if (ENABLE_CLOUD_SERVICES)
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<UnityConnectSettings>());
#endif
#if ENABLE_DIRECTOR_AUDIO
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioPlayer>());
#endif

        //      ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<BatchedSpriteRenderer>());    // currently disabled and not included in builds
        //      ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SpriteDataProvider>());       // currently disabled and not included in builds
        //      ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SmartSprite>());              // currently disabled and not included in builds

#if UNITY_PS4
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<TextureRawPS4>());
#endif

#if ENABLE_HOLOLENS_MODULE_API
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<WorldAnchor>());
#endif
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<OcclusionCullingData>());

#if ENABLE_MARSHALLING_TESTS
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<MarshallingTestObject>());
#endif
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Prefab>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<EditorExtensionImpl>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AssetImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AssetDatabase>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<Mesh3DSImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<TextureImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ShaderImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ComputeShaderImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AvatarMask>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AudioImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<HierarchyState>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AssetMetaData>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<DefaultAsset>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<DefaultImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<TextScriptImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SceneAsset>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<NativeFormatImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<MonoImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AssetServerCache>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<LibraryAssetImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ModelImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<FBXImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<TrueTypeFontImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<MovieImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<EditorBuildSettings>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<DDSImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<InspectorExpandedState>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AnnotationManager>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<PluginImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<EditorUserBuildSettings>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<PVRImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ASTCImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<KTXImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<IHVImageFormatImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AnimatorStateTransition>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AnimatorState>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<HumanTemplate>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AnimatorStateMachine>());
        //      ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<PreviewAssetType>());         // not registered as a class
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AnimatorTransition>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SpeedTreeImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<AnimatorTransitionBase>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SubstanceImporter>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<LightmapParameters>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<LightingDataAsset>());
#if !UNITY_LINUX
        //      ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<GISRaster>());                // verified nonexistent outside of ClassID enum
        //      ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<GISRasterImporter>());        // verified nonexistent outside of ClassID enum
        //      ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<CadImporter>());              // not part of standard unity, and code isn't included in unity test
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<SketchUpImporter>());
#endif
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<BuildReporting::BuildReport>());
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<BuildReporting::PackedAssets>());
#if ENABLE_VIDEO
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<VideoClipImporter>());
#endif
#if ENABLE_UNIT_TESTS
        ENSURE_EDITOR_ONLY_CONSISTENCY(WeakTypeOf<ActivationLogComponent>());
#endif
        #undef ENSURE_EDITOR_ONLY_CONSISTENCY
    }

    TEST(EnsureClassIDsAreUnmodified)
    {
        CHECK_EQUAL(0, WeakTypeOf<Object>()->GetPersistentTypeID());
        CHECK_EQUAL(1, WeakTypeOf<GameObject>()->GetPersistentTypeID());
        CHECK_EQUAL(2, WeakTypeOf<Unity::Component>()->GetPersistentTypeID());
        CHECK_EQUAL(3, WeakTypeOf<LevelGameManager>()->GetPersistentTypeID());
        CHECK_EQUAL(4, WeakTypeOf<Transform>()->GetPersistentTypeID());
        CHECK_EQUAL(5, WeakTypeOf<TimeManager>()->GetPersistentTypeID());
        CHECK_EQUAL(6, WeakTypeOf<GlobalGameManager>()->GetPersistentTypeID());
        CHECK_EQUAL(8, WeakTypeOf<Behaviour>()->GetPersistentTypeID());
        CHECK_EQUAL(9, WeakTypeOf<GameManager>()->GetPersistentTypeID());
        CHECK_EQUAL(11, WeakTypeOf<AudioManager>()->GetPersistentTypeID());
        CHECK_EQUAL(12, WeakTypeOf<ParticleAnimator>()->GetPersistentTypeID());
        CHECK_EQUAL(13, WeakTypeOf<InputManager>()->GetPersistentTypeID());
        CHECK_EQUAL(15, WeakTypeOf<EllipsoidParticleEmitter>()->GetPersistentTypeID());
        CHECK_EQUAL(18, WeakTypeOf<EditorExtension>()->GetPersistentTypeID());
        CHECK_EQUAL(19, WeakTypeOf<Physics2DSettings>()->GetPersistentTypeID());
        CHECK_EQUAL(20, WeakTypeOf<Camera>()->GetPersistentTypeID());
        CHECK_EQUAL(21, WeakTypeOf<Material>()->GetPersistentTypeID());
        CHECK_EQUAL(23, WeakTypeOf<MeshRenderer>()->GetPersistentTypeID());
        CHECK_EQUAL(25, WeakTypeOf<Renderer>()->GetPersistentTypeID());
        CHECK_EQUAL(26, WeakTypeOf<ParticleRenderer>()->GetPersistentTypeID());
        CHECK_EQUAL(27, WeakTypeOf<Texture>()->GetPersistentTypeID());
        CHECK_EQUAL(28, WeakTypeOf<Texture2D>()->GetPersistentTypeID());
        CHECK_EQUAL(29, WeakTypeOf<OcclusionCullingSettings>()->GetPersistentTypeID());
        CHECK_EQUAL(30, WeakTypeOf<GraphicsSettings>()->GetPersistentTypeID());
        CHECK_EQUAL(33, WeakTypeOf<MeshFilter>()->GetPersistentTypeID());
        CHECK_EQUAL(41, WeakTypeOf<OcclusionPortal>()->GetPersistentTypeID());
        CHECK_EQUAL(43, WeakTypeOf<Mesh>()->GetPersistentTypeID());
        CHECK_EQUAL(45, WeakTypeOf<Skybox>()->GetPersistentTypeID());
        CHECK_EQUAL(47, WeakTypeOf<QualitySettings>()->GetPersistentTypeID());
        CHECK_EQUAL(48, WeakTypeOf<Shader>()->GetPersistentTypeID());
        CHECK_EQUAL(49, WeakTypeOf<TextAsset>()->GetPersistentTypeID());
        CHECK_EQUAL(50, WeakTypeOf<Rigidbody2D>()->GetPersistentTypeID());
        //      CHECK_EQUAL(51, WeakTypeOf<Physics2DManager>()->GetPersistentTypeID());     // legacy constant, verified nonexistent outside of ClassID enum
        CHECK_EQUAL(53, WeakTypeOf<Collider2D>()->GetPersistentTypeID());
        CHECK_EQUAL(54, WeakTypeOf<Rigidbody>()->GetPersistentTypeID());
        CHECK_EQUAL(55, WeakTypeOf<PhysicsManager>()->GetPersistentTypeID());
        CHECK_EQUAL(56, WeakTypeOf<Collider>()->GetPersistentTypeID());
        CHECK_EQUAL(57, WeakTypeOf<Unity::Joint>()->GetPersistentTypeID());
        CHECK_EQUAL(58, WeakTypeOf<CircleCollider2D>()->GetPersistentTypeID());
        CHECK_EQUAL(59, WeakTypeOf<Unity::HingeJoint>()->GetPersistentTypeID());
        CHECK_EQUAL(60, WeakTypeOf<PolygonCollider2D>()->GetPersistentTypeID());
        CHECK_EQUAL(61, WeakTypeOf<BoxCollider2D>()->GetPersistentTypeID());
        CHECK_EQUAL(62, WeakTypeOf<PhysicsMaterial2D>()->GetPersistentTypeID());
        CHECK_EQUAL(64, WeakTypeOf<MeshCollider>()->GetPersistentTypeID());
        CHECK_EQUAL(65, WeakTypeOf<BoxCollider>()->GetPersistentTypeID());
        CHECK_EQUAL(66, WeakTypeOf<CompositeCollider2D>()->GetPersistentTypeID());
        CHECK_EQUAL(68, WeakTypeOf<EdgeCollider2D>()->GetPersistentTypeID());
        CHECK_EQUAL(70, WeakTypeOf<CapsuleCollider2D>()->GetPersistentTypeID());
        CHECK_EQUAL(72, WeakTypeOf<ComputeShader>()->GetPersistentTypeID());
        CHECK_EQUAL(74, WeakTypeOf<AnimationClip>()->GetPersistentTypeID());
        CHECK_EQUAL(75, WeakTypeOf<ConstantForce>()->GetPersistentTypeID());
        CHECK_EQUAL(76, WeakTypeOf<WorldParticleCollider>()->GetPersistentTypeID());
        CHECK_EQUAL(78, WeakTypeOf<TagManager>()->GetPersistentTypeID());
        CHECK_EQUAL(81, WeakTypeOf<AudioListener>()->GetPersistentTypeID());
        CHECK_EQUAL(82, WeakTypeOf<AudioSource>()->GetPersistentTypeID());
        CHECK_EQUAL(83, WeakTypeOf<AudioClip>()->GetPersistentTypeID());
        CHECK_EQUAL(84, WeakTypeOf<RenderTexture>()->GetPersistentTypeID());
        CHECK_EQUAL(86, WeakTypeOf<CustomRenderTexture>()->GetPersistentTypeID());
        CHECK_EQUAL(87, WeakTypeOf<MeshParticleEmitter>()->GetPersistentTypeID());
        CHECK_EQUAL(88, WeakTypeOf<ParticleEmitter>()->GetPersistentTypeID());
        CHECK_EQUAL(89, WeakTypeOf<Cubemap>()->GetPersistentTypeID());
        CHECK_EQUAL(90, WeakTypeOf<Avatar>()->GetPersistentTypeID());
        CHECK_EQUAL(91, WeakTypeOf<AnimatorController>()->GetPersistentTypeID());
        CHECK_EQUAL(92, WeakTypeOf<GUILayer>()->GetPersistentTypeID());
        CHECK_EQUAL(93, WeakTypeOf<RuntimeAnimatorController>()->GetPersistentTypeID());
        CHECK_EQUAL(94, WeakTypeOf<ScriptMapper>()->GetPersistentTypeID());
        CHECK_EQUAL(95, WeakTypeOf<Animator>()->GetPersistentTypeID());
        CHECK_EQUAL(96, WeakTypeOf<TrailRenderer>()->GetPersistentTypeID());
        CHECK_EQUAL(98, WeakTypeOf<DelayedCallManager>()->GetPersistentTypeID());
        CHECK_EQUAL(102, WeakTypeOf<TextRenderingPrivate::TextMesh>()->GetPersistentTypeID());
        CHECK_EQUAL(104, WeakTypeOf<RenderSettings>()->GetPersistentTypeID());
        CHECK_EQUAL(108, WeakTypeOf<Light>()->GetPersistentTypeID());
        CHECK_EQUAL(109, WeakTypeOf<CGProgram>()->GetPersistentTypeID());
        CHECK_EQUAL(110, WeakTypeOf<BaseAnimationTrack>()->GetPersistentTypeID());
        CHECK_EQUAL(111, WeakTypeOf<Animation>()->GetPersistentTypeID());
        CHECK_EQUAL(114, WeakTypeOf<MonoBehaviour>()->GetPersistentTypeID());
        CHECK_EQUAL(115, WeakTypeOf<MonoScript>()->GetPersistentTypeID());
        CHECK_EQUAL(116, WeakTypeOf<MonoManager>()->GetPersistentTypeID());
        CHECK_EQUAL(117, WeakTypeOf<Texture3D>()->GetPersistentTypeID());
        CHECK_EQUAL(118, WeakTypeOf<NewAnimationTrack>()->GetPersistentTypeID());
        CHECK_EQUAL(119, WeakTypeOf<Projector>()->GetPersistentTypeID());
        CHECK_EQUAL(120, WeakTypeOf<LineRenderer>()->GetPersistentTypeID());
        CHECK_EQUAL(121, WeakTypeOf<Flare>()->GetPersistentTypeID());
        CHECK_EQUAL(122, WeakTypeOf<Halo>()->GetPersistentTypeID());
        CHECK_EQUAL(123, WeakTypeOf<LensFlare>()->GetPersistentTypeID());
        CHECK_EQUAL(124, WeakTypeOf<FlareLayer>()->GetPersistentTypeID());
        CHECK_EQUAL(125, WeakTypeOf<HaloLayer>()->GetPersistentTypeID());
        CHECK_EQUAL(126, WeakTypeOf<NavMeshProjectSettings>()->GetPersistentTypeID());
        CHECK_EQUAL(128, WeakTypeOf<TextRendering::Font>()->GetPersistentTypeID());
        CHECK_EQUAL(129, WeakTypeOf<PlayerSettings>()->GetPersistentTypeID());
        CHECK_EQUAL(130, WeakTypeOf<NamedObject>()->GetPersistentTypeID());
        CHECK_EQUAL(131, WeakTypeOf<GUITexture>()->GetPersistentTypeID());
        CHECK_EQUAL(132, WeakTypeOf<TextRenderingPrivate::GUIText>()->GetPersistentTypeID());
        CHECK_EQUAL(133, WeakTypeOf<GUIElement>()->GetPersistentTypeID());
        CHECK_EQUAL(134, WeakTypeOf<PhysicMaterial>()->GetPersistentTypeID());
        CHECK_EQUAL(135, WeakTypeOf<SphereCollider>()->GetPersistentTypeID());
        CHECK_EQUAL(136, WeakTypeOf<CapsuleCollider>()->GetPersistentTypeID());
        CHECK_EQUAL(137, WeakTypeOf<SkinnedMeshRenderer>()->GetPersistentTypeID());
        CHECK_EQUAL(138, WeakTypeOf<Unity::FixedJoint>()->GetPersistentTypeID());
        CHECK_EQUAL(141, WeakTypeOf<BuildSettings>()->GetPersistentTypeID());
        CHECK_EQUAL(142, WeakTypeOf<AssetBundle>()->GetPersistentTypeID());
        CHECK_EQUAL(143, WeakTypeOf<CharacterController>()->GetPersistentTypeID());
        CHECK_EQUAL(144, WeakTypeOf<Unity::CharacterJoint>()->GetPersistentTypeID());
        CHECK_EQUAL(145, WeakTypeOf<Unity::SpringJoint>()->GetPersistentTypeID());
        CHECK_EQUAL(146, WeakTypeOf<WheelCollider>()->GetPersistentTypeID());
        CHECK_EQUAL(147, WeakTypeOf<ResourceManager>()->GetPersistentTypeID());
        CHECK_EQUAL(148, WeakTypeOf<NetworkView>()->GetPersistentTypeID());
        CHECK_EQUAL(149, WeakTypeOf<NetworkManager>()->GetPersistentTypeID());
        CHECK_EQUAL(150, WeakTypeOf<PreloadData>()->GetPersistentTypeID());
        CHECK_EQUAL(152, WeakTypeOf<MovieTexture>()->GetPersistentTypeID());
        CHECK_EQUAL(153, WeakTypeOf<Unity::ConfigurableJoint>()->GetPersistentTypeID());
        CHECK_EQUAL(154, WeakTypeOf<TerrainCollider>()->GetPersistentTypeID());
        CHECK_EQUAL(155, WeakTypeOf<MasterServerInterface>()->GetPersistentTypeID());
        CHECK_EQUAL(156, WeakTypeOf<TerrainData>()->GetPersistentTypeID());
        CHECK_EQUAL(157, WeakTypeOf<LightmapSettings>()->GetPersistentTypeID());
        CHECK_EQUAL(158, WeakTypeOf<WebCamTexture>()->GetPersistentTypeID());
        CHECK_EQUAL(159, WeakTypeOf<EditorSettings>()->GetPersistentTypeID());
        //      CHECK_EQUAL(160, WeakTypeOf<InteractiveCloth>()->GetPersistentTypeID());    // legacy constant, verified nonexistent outside of ClassID enum
        //      CHECK_EQUAL(161, WeakTypeOf<ClothRenderer>()->GetPersistentTypeID());       // legacy constant, verified nonexistent outside of ClassID enum
        CHECK_EQUAL(162, WeakTypeOf<EditorUserSettings>()->GetPersistentTypeID());
        //      CHECK_EQUAL(163, WeakTypeOf<SkinnedCloth>()->GetPersistentTypeID());        // legacy constant, verified nonexistent outside of ClassID enum
        CHECK_EQUAL(164, WeakTypeOf<AudioReverbFilter>()->GetPersistentTypeID());
        CHECK_EQUAL(165, WeakTypeOf<AudioHighPassFilter>()->GetPersistentTypeID());
        CHECK_EQUAL(166, WeakTypeOf<AudioChorusFilter>()->GetPersistentTypeID());
        CHECK_EQUAL(167, WeakTypeOf<AudioReverbZone>()->GetPersistentTypeID());
        CHECK_EQUAL(168, WeakTypeOf<AudioEchoFilter>()->GetPersistentTypeID());
        CHECK_EQUAL(169, WeakTypeOf<AudioLowPassFilter>()->GetPersistentTypeID());
        CHECK_EQUAL(170, WeakTypeOf<AudioDistortionFilter>()->GetPersistentTypeID());
        CHECK_EQUAL(171, WeakTypeOf<SparseTexture>()->GetPersistentTypeID());
        CHECK_EQUAL(180, WeakTypeOf<AudioBehaviour>()->GetPersistentTypeID());
        CHECK_EQUAL(181, WeakTypeOf<AudioFilter>()->GetPersistentTypeID());
        CHECK_EQUAL(182, WeakTypeOf<WindZone>()->GetPersistentTypeID());
        CHECK_EQUAL(183, WeakTypeOf<Unity::Cloth>()->GetPersistentTypeID());
        CHECK_EQUAL(184, WeakTypeOf<SubstanceArchive>()->GetPersistentTypeID());
        CHECK_EQUAL(185, WeakTypeOf<ProceduralMaterial>()->GetPersistentTypeID());
        CHECK_EQUAL(186, WeakTypeOf<ProceduralTexture>()->GetPersistentTypeID());
        CHECK_EQUAL(187, WeakTypeOf<Texture2DArray>()->GetPersistentTypeID());
        CHECK_EQUAL(188, WeakTypeOf<CubemapArray>()->GetPersistentTypeID());
        CHECK_EQUAL(191, WeakTypeOf<OffMeshLink>()->GetPersistentTypeID());
        CHECK_EQUAL(192, WeakTypeOf<OcclusionArea>()->GetPersistentTypeID());
        CHECK_EQUAL(193, WeakTypeOf<Tree>()->GetPersistentTypeID());
        CHECK_EQUAL(195, WeakTypeOf<NavMeshAgent>()->GetPersistentTypeID());
        CHECK_EQUAL(196, WeakTypeOf<NavMeshSettings>()->GetPersistentTypeID());
        CHECK_EQUAL(198, WeakTypeOf<ParticleSystem>()->GetPersistentTypeID());
        CHECK_EQUAL(199, WeakTypeOf<ParticleSystemRenderer>()->GetPersistentTypeID());
        CHECK_EQUAL(200, WeakTypeOf<ShaderVariantCollection>()->GetPersistentTypeID());
        CHECK_EQUAL(205, WeakTypeOf<LODGroup>()->GetPersistentTypeID());
        CHECK_EQUAL(206, WeakTypeOf<BlendTree>()->GetPersistentTypeID());
        CHECK_EQUAL(207, WeakTypeOf<Motion>()->GetPersistentTypeID());
        CHECK_EQUAL(208, WeakTypeOf<NavMeshObstacle>()->GetPersistentTypeID());
        CHECK_EQUAL(218, WeakTypeOf<Terrain>()->GetPersistentTypeID());
        CHECK_EQUAL(210, WeakTypeOf<SortingGroup>()->GetPersistentTypeID());
        CHECK_EQUAL(212, WeakTypeOf<SpriteRenderer>()->GetPersistentTypeID());
        CHECK_EQUAL(213, WeakTypeOf<Sprite>()->GetPersistentTypeID());
        CHECK_EQUAL(214, WeakTypeOf<CachedSpriteAtlas>()->GetPersistentTypeID());
        CHECK_EQUAL(215, WeakTypeOf<ReflectionProbe>()->GetPersistentTypeID());
        //      CHECK_EQUAL(216, WeakTypeOf<ReflectionProbes>()->GetPersistentTypeID());        // legacy constant, verified nonexistent outside of ClassID enum
        CHECK_EQUAL(220, WeakTypeOf<LightProbeGroup>()->GetPersistentTypeID());
        CHECK_EQUAL(221, WeakTypeOf<AnimatorOverrideController>()->GetPersistentTypeID());
        CHECK_EQUAL(222, WeakTypeOf<UI::CanvasRenderer>()->GetPersistentTypeID());
        CHECK_EQUAL(223, WeakTypeOf<UI::Canvas>()->GetPersistentTypeID());
        CHECK_EQUAL(224, WeakTypeOf<UI::RectTransform>()->GetPersistentTypeID());
        CHECK_EQUAL(225, WeakTypeOf<UI::CanvasGroup>()->GetPersistentTypeID());
        CHECK_EQUAL(226, WeakTypeOf<BillboardAsset>()->GetPersistentTypeID());
        CHECK_EQUAL(227, WeakTypeOf<BillboardRenderer>()->GetPersistentTypeID());
        CHECK_EQUAL(228, WeakTypeOf<SpeedTreeWindAsset>()->GetPersistentTypeID());
        CHECK_EQUAL(229, WeakTypeOf<AnchoredJoint2D>()->GetPersistentTypeID());
        CHECK_EQUAL(230, WeakTypeOf<Joint2D>()->GetPersistentTypeID());
        CHECK_EQUAL(231, WeakTypeOf<SpringJoint2D>()->GetPersistentTypeID());
        CHECK_EQUAL(232, WeakTypeOf<DistanceJoint2D>()->GetPersistentTypeID());
        CHECK_EQUAL(233, WeakTypeOf<HingeJoint2D>()->GetPersistentTypeID());
        CHECK_EQUAL(234, WeakTypeOf<SliderJoint2D>()->GetPersistentTypeID());
        CHECK_EQUAL(235, WeakTypeOf<WheelJoint2D>()->GetPersistentTypeID());
        CHECK_EQUAL(236, WeakTypeOf<ClusterInputManager>()->GetPersistentTypeID());
        CHECK_EQUAL(237, WeakTypeOf<BaseVideoTexture>()->GetPersistentTypeID());
        CHECK_EQUAL(238, WeakTypeOf<NavMeshData>()->GetPersistentTypeID());
        CHECK_EQUAL(240, WeakTypeOf<AudioMixer>()->GetPersistentTypeID());
        CHECK_EQUAL(241, WeakTypeOf<AudioMixerController>()->GetPersistentTypeID());
        CHECK_EQUAL(243, WeakTypeOf<AudioMixerGroupController>()->GetPersistentTypeID());
        CHECK_EQUAL(244, WeakTypeOf<AudioMixerEffectController>()->GetPersistentTypeID());
        CHECK_EQUAL(245, WeakTypeOf<AudioMixerSnapshotController>()->GetPersistentTypeID());
        CHECK_EQUAL(246, WeakTypeOf<PhysicsUpdateBehaviour2D>()->GetPersistentTypeID());
        CHECK_EQUAL(247, WeakTypeOf<ConstantForce2D>()->GetPersistentTypeID());
        CHECK_EQUAL(248, WeakTypeOf<Effector2D>()->GetPersistentTypeID());
        CHECK_EQUAL(249, WeakTypeOf<AreaEffector2D>()->GetPersistentTypeID());
        CHECK_EQUAL(250, WeakTypeOf<PointEffector2D>()->GetPersistentTypeID());
        CHECK_EQUAL(251, WeakTypeOf<PlatformEffector2D>()->GetPersistentTypeID());
        CHECK_EQUAL(252, WeakTypeOf<SurfaceEffector2D>()->GetPersistentTypeID());
        CHECK_EQUAL(253, WeakTypeOf<BuoyancyEffector2D>()->GetPersistentTypeID());
        CHECK_EQUAL(254, WeakTypeOf<RelativeJoint2D>()->GetPersistentTypeID());
        CHECK_EQUAL(255, WeakTypeOf<FixedJoint2D>()->GetPersistentTypeID());
        CHECK_EQUAL(256, WeakTypeOf<FrictionJoint2D>()->GetPersistentTypeID());
        CHECK_EQUAL(257, WeakTypeOf<TargetJoint2D>()->GetPersistentTypeID());
        CHECK_EQUAL(258, WeakTypeOf<LightProbes>()->GetPersistentTypeID());
        CHECK_EQUAL(259, WeakTypeOf<LightProbeProxyVolume>()->GetPersistentTypeID());
        CHECK_EQUAL(271, WeakTypeOf<SampleClip>()->GetPersistentTypeID());
        CHECK_EQUAL(272, WeakTypeOf<AudioMixerSnapshot>()->GetPersistentTypeID());
        CHECK_EQUAL(273, WeakTypeOf<AudioMixerGroup>()->GetPersistentTypeID());
        CHECK_EQUAL(280, WeakTypeOf<NScreenBridge>()->GetPersistentTypeID());
        CHECK_EQUAL(290, WeakTypeOf<AssetBundleManifest>()->GetPersistentTypeID());
        CHECK_EQUAL(292, WeakTypeOf<UnityAdsManager>()->GetPersistentTypeID());
        CHECK_EQUAL(300, WeakTypeOf<RuntimeInitializeOnLoadManager>()->GetPersistentTypeID());
        CHECK_EQUAL(301, WeakTypeOf<CloudWebServicesManager>()->GetPersistentTypeID());
        CHECK_EQUAL(303, WeakTypeOf<UnityAnalyticsManager>()->GetPersistentTypeID());
        CHECK_EQUAL(304, WeakTypeOf<CrashReportManager>()->GetPersistentTypeID());
        CHECK_EQUAL(305, WeakTypeOf<PerformanceReportingManager>()->GetPersistentTypeID());
#if (ENABLE_CLOUD_SERVICES)
        CHECK_EQUAL(310, WeakTypeOf<UnityConnectSettings>()->GetPersistentTypeID());
#endif
        CHECK_EQUAL(319, WeakTypeOf<AvatarMask>()->GetPersistentTypeID());
#if ENABLE_DIRECTOR_AUDIO
        CHECK_EQUAL(323, WeakTypeOf<AudioPlayer>()->GetPersistentTypeID());
#endif

        //      CHECK_EQUAL(324, WeakTypeOf<BatchedSpriteRenderer>()->GetPersistentTypeID());   // currently disabled and not included in builds
        //      CHECK_EQUAL(325, WeakTypeOf<SpriteDataProvider>()->GetPersistentTypeID());      // currently disabled and not included in builds
        //      CHECK_EQUAL(326, WeakTypeOf<SmartSprite>()->GetPersistentTypeID());             // currently disabled and not included in builds

#if UNITY_PS4
        CHECK_EQUAL(327, WeakTypeOf<TextureRawPS4>()->GetPersistentTypeID());
#endif

#if ENABLE_HOLOLENS_MODULE_API
        CHECK_EQUAL(362, WeakTypeOf<WorldAnchor>()->GetPersistentTypeID());
#endif
        CHECK_EQUAL(363, WeakTypeOf<OcclusionCullingData>()->GetPersistentTypeID());
#if ENABLE_MARSHALLING_TESTS
        CHECK_EQUAL(900, WeakTypeOf<MarshallingTestObject>()->GetPersistentTypeID());
#endif
        CHECK_EQUAL(1001, WeakTypeOf<Prefab>()->GetPersistentTypeID());
        CHECK_EQUAL(1002, WeakTypeOf<EditorExtensionImpl>()->GetPersistentTypeID());
        CHECK_EQUAL(1003, WeakTypeOf<AssetImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1004, WeakTypeOf<AssetDatabase>()->GetPersistentTypeID());
        CHECK_EQUAL(1005, WeakTypeOf<Mesh3DSImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1006, WeakTypeOf<TextureImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1007, WeakTypeOf<ShaderImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1008, WeakTypeOf<ComputeShaderImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1020, WeakTypeOf<AudioImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1026, WeakTypeOf<HierarchyState>()->GetPersistentTypeID());
        CHECK_EQUAL(1028, WeakTypeOf<AssetMetaData>()->GetPersistentTypeID());
        CHECK_EQUAL(1029, WeakTypeOf<DefaultAsset>()->GetPersistentTypeID());
        CHECK_EQUAL(1030, WeakTypeOf<DefaultImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1031, WeakTypeOf<TextScriptImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1032, WeakTypeOf<SceneAsset>()->GetPersistentTypeID());
        CHECK_EQUAL(1034, WeakTypeOf<NativeFormatImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1035, WeakTypeOf<MonoImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1037, WeakTypeOf<AssetServerCache>()->GetPersistentTypeID());
        CHECK_EQUAL(1038, WeakTypeOf<LibraryAssetImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1040, WeakTypeOf<ModelImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1041, WeakTypeOf<FBXImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1042, WeakTypeOf<TrueTypeFontImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1044, WeakTypeOf<MovieImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1045, WeakTypeOf<EditorBuildSettings>()->GetPersistentTypeID());
        //      CHECK_EQUAL(1046, WeakTypeOf<DDSImporter>()->GetPersistentTypeID());            // deprecated
        CHECK_EQUAL(1048, WeakTypeOf<InspectorExpandedState>()->GetPersistentTypeID());
        CHECK_EQUAL(1049, WeakTypeOf<AnnotationManager>()->GetPersistentTypeID());
        CHECK_EQUAL(1050, WeakTypeOf<PluginImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1051, WeakTypeOf<EditorUserBuildSettings>()->GetPersistentTypeID());
        //      CHECK_EQUAL(1052, WeakTypeOf<PVRImporter>()->GetPersistentTypeID());            // deprecated
        //      CHECK_EQUAL(1053, WeakTypeOf<ASTCImporter>()->GetPersistentTypeID());           // deprecated
        //      CHECK_EQUAL(1054, WeakTypeOf<KTXImporter>()->GetPersistentTypeID());            // deprecated
        CHECK_EQUAL(1055, WeakTypeOf<IHVImageFormatImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1101, WeakTypeOf<AnimatorStateTransition>()->GetPersistentTypeID());
        CHECK_EQUAL(1102, WeakTypeOf<AnimatorState>()->GetPersistentTypeID());
        CHECK_EQUAL(1105, WeakTypeOf<HumanTemplate>()->GetPersistentTypeID());
        CHECK_EQUAL(1107, WeakTypeOf<AnimatorStateMachine>()->GetPersistentTypeID());
        CHECK_EQUAL(1108, WeakTypeOf<PreviewAnimationClip>()->GetPersistentTypeID());
        CHECK_EQUAL(1109, WeakTypeOf<AnimatorTransition>()->GetPersistentTypeID());
        CHECK_EQUAL(1110, WeakTypeOf<SpeedTreeImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1111, WeakTypeOf<AnimatorTransitionBase>()->GetPersistentTypeID());
        CHECK_EQUAL(1112, WeakTypeOf<SubstanceImporter>()->GetPersistentTypeID());
        CHECK_EQUAL(1113, WeakTypeOf<LightmapParameters>()->GetPersistentTypeID());
        CHECK_EQUAL(1120, WeakTypeOf<LightingDataAsset>()->GetPersistentTypeID());
#if !UNITY_LINUX
        //      CHECK_EQUAL(1121, WeakTypeOf<GISRaster>()->GetPersistentTypeID());              // verified nonexistent outside of ClassID enum
        //      CHECK_EQUAL(1122, WeakTypeOf<GISRasterImporter>()->GetPersistentTypeID());      // verified nonexistent outside of ClassID enum
        //      CHECK_EQUAL(1123, WeakTypeOf<CadImporter>()->GetPersistentTypeID());            // not part of standard unity, and code isn't included in unity test
        CHECK_EQUAL(1124, WeakTypeOf<SketchUpImporter>()->GetPersistentTypeID());
#endif
        CHECK_EQUAL(1125, WeakTypeOf<BuildReporting::BuildReport>()->GetPersistentTypeID());
        CHECK_EQUAL(1126, WeakTypeOf<BuildReporting::PackedAssets>()->GetPersistentTypeID());
#if ENABLE_VIDEO
        CHECK_EQUAL(1127, WeakTypeOf<VideoClipImporter>()->GetPersistentTypeID());
#endif
#if ENABLE_UNIT_TESTS
        CHECK_EQUAL(2000, WeakTypeOf<ActivationLogComponent>()->GetPersistentTypeID());
#endif
    }
}

#endif
#endif
