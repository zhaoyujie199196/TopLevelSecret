#include "UnityPrefix.h"
#include "AttributeContainer.h"
#include "TypeInfoManager.h"


RTTI::RuntimeTypeArray RTTI::ms_runtimeTypes;


namespace Unity
{
    const Type* Type::FindTypeByName(const char* name, CaseSensitivityOptions options)
    {
        return reinterpret_cast<const Type*>(TypeManager::Get().ClassNameToTypeInfo(name, options == kCaseInSensitive));
    }

    const Type* Type::FindTypeByPersistentTypeID(PersistentTypeID id)
    {
        return reinterpret_cast<const Type*>(TypeManager::Get().ClassIDToTypeInfo(id));
    }

    const Type* Type::GetDeserializationStubForPersistentTypeID(PersistentTypeID id)
    {
        return reinterpret_cast<const Type*>(TypeManager::Get().GetDeserializationStubForPersistentTypeID(id));
    }

    void Type::FindAllDerivedClasses(dynamic_array<const Type*>& result, TypeFilterOptions options) const
    {
        TypeManager::Get().FindAllDerivedClasses(&m_internal, reinterpret_cast<dynamic_array<TypeInfo>&>(result), options == kOnlyNonAbstract);
    }

    void Type::GetAttributes(TypeAttributes& result) const
    {
        result = TypeAttributes(this, GetAttributeCount());
    }
} // end namespace Unity

#if ENABLE_UNIT_TESTS

#include <iostream>

std::ostream& operator<<(std::ostream& stream, const Unity::Type* type)
{
    if (type == NULL)
        return (stream << "<null type>");

    if (type->GetNamespace() != NULL && type->GetNamespace()[0] != 0)
        stream << type->GetNamespace() << "::";

    return (stream << type->GetName());
}

#endif
