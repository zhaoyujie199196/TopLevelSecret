#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS
#if ENABLE_UNIT_TESTS_WITH_FAKES

#include "Runtime/Testing/Faking.h"
#include "Runtime/Testing/Testing.h"
#include "EventManager.h"

struct LoggingCounter
{
    LoggingCounter() : counter(0) {}
    int counter;
};

static void LoggingCallback(void* userData, void* sender, int type)
{
    LoggingCounter* logging = reinterpret_cast<LoggingCounter*>(userData);

    logging->counter++;
}

static void AlternativeCallback(void* userData, void* sender, int type)
{
}

struct EventManagerCallbackUserData
{
    EventManager *pEventManagerInstance;
    EventManager::EventIndex indexForEvent02;
    EventManager::EventIndex indexForTheEventInvokingThisCallback;
};

static void EventManagerCallback(void* userData, void* sender, int type)
{
    struct EventManagerCallbackUserData* eventManagerCallbackUserData = reinterpret_cast<struct EventManagerCallbackUserData*>(userData);

    // Are we running the callback from the first event in the chain (i.e., Event02)? If yes, let's remove ourselves
    // from the EventManager, which will leave Event01 dangling. The test EventRemovesItselfWithinInvocation_DoesNotCrash
    // checks that the EventManager can cope with this scenario without crashing.
    if (eventManagerCallbackUserData->indexForTheEventInvokingThisCallback == eventManagerCallbackUserData->indexForEvent02)
    {
        eventManagerCallbackUserData->pEventManagerInstance->RemoveEvent(eventManagerCallbackUserData->indexForEvent02);
    }
}

UNIT_TEST_SUITE(EventManagerTests)
{
    struct Fixture
    {
        Fixture()
            : instanceUnderTest(kMemTempAlloc)
        {}

        EventManager instanceUnderTest;
        EventManager::EventIndex index;
    };

    TEST_FIXTURE(Fixture, AddEvent_DoesReturnEventIndex_WithExpectedData)
    {
        LoggingCounter counter1;

        index = instanceUnderTest.AddEvent(LoggingCallback, &counter1, NULL);
        CHECK_EQUAL(LoggingCallback, index->callback);
        CHECK_EQUAL(&counter1, index->userData);
    }

    TEST_FIXTURE(Fixture, HasEvent_CanFind_SameEvent)
    {
        index = instanceUnderTest.AddEvent(LoggingCallback, NULL, NULL);
        CHECK(instanceUnderTest.HasEvent(index, LoggingCallback, NULL));
    }

    TEST_FIXTURE(Fixture, HasEvent_DoesNotMatch_SameCallbackWithDifferentData)
    {
        index = instanceUnderTest.AddEvent(LoggingCallback, NULL, NULL);

        int dummy;
        CHECK(!instanceUnderTest.HasEvent(index, LoggingCallback, &dummy));
    }

    TEST_FIXTURE(Fixture, HasEvent_DoesNotMatch_DifferentCallbackWithSameData)
    {
        index = instanceUnderTest.AddEvent(LoggingCallback, NULL, NULL);
        CHECK(!instanceUnderTest.HasEvent(index, AlternativeCallback, NULL));
    }

    TEST_FIXTURE(Fixture, InvokeEvent_WithASingleEvent_DoesCallCallback)
    {
        LoggingCounter counter1;
        index = instanceUnderTest.AddEvent(LoggingCallback, &counter1, NULL);

        instanceUnderTest.InvokeEvent(index, NULL, 0);

        CHECK_EQUAL(1, counter1.counter);
    }

    TEST_FIXTURE(Fixture, InvokeEvent_WithASingleEvent_CanBeCalledMultipleTimes)
    {
        LoggingCounter counter1;
        index = instanceUnderTest.AddEvent(LoggingCallback, &counter1, NULL);

        instanceUnderTest.InvokeEvent(index, NULL, 0);
        instanceUnderTest.InvokeEvent(index, NULL, 0);
        instanceUnderTest.InvokeEvent(index, NULL, 0);

        CHECK_EQUAL(3, counter1.counter);
    }

    TEST_FIXTURE(Fixture, HasEvent_CanFollowEventChain)
    {
        LoggingCounter counter1;
        LoggingCounter counter2;
        LoggingCounter counter3;

        index = instanceUnderTest.AddEvent(LoggingCallback, &counter1, NULL);
        index = instanceUnderTest.AddEvent(LoggingCallback, &counter2, index);
        index = instanceUnderTest.AddEvent(LoggingCallback, &counter3, index);

        CHECK(instanceUnderTest.HasEvent(index, LoggingCallback, &counter1));
        CHECK(instanceUnderTest.HasEvent(index, LoggingCallback, &counter2));
        CHECK(instanceUnderTest.HasEvent(index, LoggingCallback, &counter3));
    }

    TEST_FIXTURE(Fixture, InvokeEvent_WithChainedCallbacks_DoesCallAllOfThem)
    {
        LoggingCounter counter1;
        LoggingCounter counter2;
        LoggingCounter counter3;

        index = instanceUnderTest.AddEvent(LoggingCallback, &counter1, NULL);
        index = instanceUnderTest.AddEvent(LoggingCallback, &counter2, index);
        index = instanceUnderTest.AddEvent(LoggingCallback, &counter3, index);

        instanceUnderTest.InvokeEvent(index, NULL, 0);

        CHECK_EQUAL(1, counter1.counter);
        CHECK_EQUAL(1, counter2.counter);
        CHECK_EQUAL(1, counter3.counter);
    }

    TEST_FIXTURE(Fixture, AddEvent_WithDuplicateEvent_DoesProduceMultipleEvents)
    {
        LoggingCounter counter1;

        index = instanceUnderTest.AddEvent(LoggingCallback, &counter1, NULL);
        index = instanceUnderTest.AddEvent(LoggingCallback, &counter1, index);

        instanceUnderTest.InvokeEvent(index, NULL, 0);

        CHECK_EQUAL(2, counter1.counter);
    }

    TEST_FIXTURE(Fixture, RemoveEvent_WithNoEvents_SucceedsAndReturnsNull)
    {
        CHECK_EQUAL((EventManager::EventIndex)NULL, instanceUnderTest.RemoveEvent(NULL, NULL, NULL));
    }

    TEST_FIXTURE(Fixture, RemoveEvent_WithSingleEvent_ReturnsNull)
    {
        index = instanceUnderTest.AddEvent(LoggingCallback, NULL, NULL);

        index = instanceUnderTest.RemoveEvent(index, LoggingCallback, NULL);

        CHECK_EQUAL((EventManager::EventIndex)NULL, index);
    }

    TEST_FIXTURE(Fixture, RemoveEvent_FromMiddleOfEventChain_LeavesRemainingEvents)
    {
        LoggingCounter counter1;
        LoggingCounter counter2;
        LoggingCounter counter3;

        index = instanceUnderTest.AddEvent(LoggingCallback, &counter1, NULL);
        index = instanceUnderTest.AddEvent(LoggingCallback, &counter2, index);
        index = instanceUnderTest.AddEvent(LoggingCallback, &counter3, index);

        index = instanceUnderTest.RemoveEvent(index, LoggingCallback, &counter2);

        CHECK(instanceUnderTest.HasEvent(index, LoggingCallback, &counter1));
        CHECK(!instanceUnderTest.HasEvent(index, LoggingCallback, &counter2));
        CHECK(instanceUnderTest.HasEvent(index, LoggingCallback, &counter3));

        instanceUnderTest.InvokeEvent(index, NULL, 0);

        CHECK_EQUAL(1, counter1.counter);
        CHECK_EQUAL(0, counter2.counter);
        CHECK_EQUAL(1, counter3.counter);
    }

    TEST_FIXTURE(Fixture, InvokeEventThatRemovesItselfDuringInvoke_CorrectlyCleansUpEventAndOtherChainedEvents)
    {
        FAKE_METHOD(EventManager, DeallocateEntry, void(EventEntry * eventEntry));

        // Create a chain of events composed by Event02 -> Event01.
        // Store the EventManager instance, the indices for the first event (Event02) and the index of the event
        // invoking the callback itself in an EventManagerCallbackUserData structure.
        // We need all this information in order to be able to properly call the RemoveEvent method.
        EventManagerCallbackUserData eventManagerCallbackUserData01;
        eventManagerCallbackUserData01.pEventManagerInstance = &instanceUnderTest;

        EventManagerCallbackUserData eventManagerCallbackUserData02;
        eventManagerCallbackUserData02.pEventManagerInstance = &instanceUnderTest;
        index = instanceUnderTest.AddEvent(EventManagerCallback, &eventManagerCallbackUserData01, NULL);
        eventManagerCallbackUserData01.indexForTheEventInvokingThisCallback = index;
        index = instanceUnderTest.AddEvent(EventManagerCallback, &eventManagerCallbackUserData02, index);
        eventManagerCallbackUserData01.indexForEvent02 = index;
        eventManagerCallbackUserData02.indexForEvent02 = index;
        eventManagerCallbackUserData02.indexForTheEventInvokingThisCallback = index;

        // This will invoke Event02 -> Event01. Event02 will actually remove itself within the callback, which
        // will leave Event01 dangling.
        // This test verifies that the system can cope with this scenario without crashing.
        instanceUnderTest.InvokeEventNonStatic(index, NULL, 0);

        // Check that EventManager::DeallocateEntry has been called twice, once for each event.
        CHECK_EQUAL(2, EventManager_DeallocateEntry.CallCount());
    }
}
#endif
#endif
