#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "Runtime/Testing/Testing.h"
#include "Attribute.h"
#include "TypeInfoManager.h"
#include "Runtime/Serialize/SerializeUtility.h"
#include "Runtime/Serialize/TransferFunctions/GenerateTypeTreeTransfer.h"
#include "Runtime/Serialize/SerializationCaching/MemoryCacheReader.h"
#include "Runtime/Serialize/SerializationCaching/MemoryCacheWriter.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/BaseClasses/TypeInfoManager.h"
#if UNITY_EDITOR
#include "Runtime/Serialize/TransferFunctions/YAMLWrite.h"
#include "Runtime/Serialize/TransferFunctions/YAMLRead.h"
#include "Editor/Src/AssetPipeline/AssetImporter.h"
#include "Runtime/Serialize/TransferFunctions/StreamedBinaryWrite.h"
#include "Runtime/Serialize/TransferFunctions/SafeBinaryRead.h"
#include "Runtime/Serialize/SerializationCaching/CachedWriter.h"
#endif


UNIT_TEST_SUITE(TypeInfoManagerTests)
{
    typedef PersistentTypeID TestClassID;

    TypeRegistrationDesc InitTypeRegistrationDesc(PersistentTypeID id, RTTI* type, RTTI* base, const char* name)
    {
        TypeRegistrationDesc desc;
        memset(&desc, 0, sizeof(TypeRegistrationDesc));
        desc.init.base = base;
        desc.init.className = name;
        desc.init.classNamespace = "";
        desc.init.classID = id;
        desc.init.size = 10;
        desc.init.derivedFromInfo.typeIndex = RTTI::DefaultTypeIndex;
        desc.init.derivedFromInfo.descendantCount = RTTI::DefaultDescendentCount;
        desc.init.attributes = NULL;
        desc.init.attributeCount = 0;
        desc.type = type;
        return desc;
    }

    void RegisterTypeHelper(TypeInfoManager& manager, PersistentTypeID id, RTTI* type, RTTI* base, const char* name, const char* nameSpace, int size, RTTI::FactoryFunction* factory, TypeFlags flags)
    {
        TypeRegistrationDesc desc = InitTypeRegistrationDesc(id, type, base, name);
        desc.init.factory = factory;
        desc.init.classNamespace = nameSpace;
        desc.init.size = size;

        desc.init.isAbstract = HasFlag(flags, kTypeIsAbstract);
        desc.init.isSealed = HasFlag(flags, kTypeIsSealed);
        desc.init.isDeprecated = HasFlag(flags, kTypeIsDeprecated);
        desc.init.isEditorOnly = HasFlag(flags, kTypeIsEditorOnly);
        desc.init.isStripped = HasFlag(flags, kTypeIsStripped);
        desc.init.attributes = NULL;
        desc.init.attributeCount = 0;

        manager.RegisterType(desc);
    }

    struct FixtureManagedNotInitialized
    {
        TestClassID classID_Base;

        RTTI rtti_Base;

        RTTI::RuntimeTypeArray storage;
        TypeInfoManager m_Manager;

        FixtureManagedNotInitialized() :
            m_Manager(storage),
            classID_Base(0)
        {
            RegisterTypeHelper(m_Manager, classID_Base, &rtti_Base, NULL, "TestBaseClass", "", 42, NULL, kTypeIsAbstract);
        }

        ~FixtureManagedNotInitialized()
        {
            m_Manager.CleanupAllTypes();
        }
    };

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterNonClassType_SetsClassNameInRTTI)
    {
        RTTI rtti;
        m_Manager.RegisterNonClassType(static_cast<PersistentTypeID>(121), &rtti, "MyNonClassName", "");
        CHECK(strcmp(rtti.className, "MyNonClassName") == 0);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterNonClassType_SetsNamespaceInRTTI)
    {
        RTTI rtti;
        m_Manager.RegisterNonClassType(static_cast<PersistentTypeID>(121), &rtti, "MyClassName", "MyNamespace");
        CHECK(strcmp(rtti.classNamespace, "MyNamespace") == 0);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterClass_SetsClassIDInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        RegisterTypeHelper(m_Manager, classID_Test, &rtti, &rtti_Base, "MyClass", "", 10, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK_EQUAL(classID_Test, rtti.classID);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterStrippedClass_SetsClassIDInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        m_Manager.RegisterStrippedTypeInfo(classID_Test, &rtti, "MyClass", "");
        m_Manager.InitializeAllTypes();

        CHECK_EQUAL(classID_Test, rtti.classID);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterClass_SetsClassNameInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        RegisterTypeHelper(m_Manager, classID_Test, &rtti, &rtti_Base, "MyClass", "", 10, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK(strcmp(rtti.className, "MyClass") == 0);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterStrippedClass_SetsClassNameInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        m_Manager.RegisterStrippedTypeInfo(classID_Test, &rtti, "MyClass", "");
        m_Manager.InitializeAllTypes();

        CHECK(strcmp(rtti.className, "MyClass") == 0);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterClass_SetsNamespaceInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        RegisterTypeHelper(m_Manager, classID_Test, &rtti, &rtti_Base, "MyClass", "MyNamespace", 10, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK(strcmp(rtti.classNamespace, "MyNamespace") == 0);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterStrippedClass_SetsNamespaceInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        m_Manager.RegisterStrippedTypeInfo(classID_Test, &rtti, "MyClass", "MyNamespace");
        m_Manager.InitializeAllTypes();

        CHECK(strcmp(rtti.classNamespace, "MyNamespace") == 0);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterClass_SetsFactoryInRTTI)
    {
        struct Helper
        {
            static Object* Factory(MemLabelId label, ObjectCreationMode mode) { return NULL; }
        };

        TestClassID classID_Test(21);
        RTTI rtti;

        RegisterTypeHelper(m_Manager, classID_Test, &rtti, &rtti_Base, "MyClass", "", 10, &Helper::Factory, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK(rtti.factory == &Helper::Factory);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterClass_SetsIsAbstractInRTTI)
    {
        TestClassID classID_Abstract(21);
        TestClassID classID_NonAbstract(22);
        RTTI rtti_abstract;
        RTTI rtti_not_abstract;

        RegisterTypeHelper(m_Manager, classID_Abstract, &rtti_abstract, &rtti_Base, "MyAbstractClass", "", 10, NULL, kTypeIsAbstract);
        RegisterTypeHelper(m_Manager, classID_NonAbstract, &rtti_not_abstract, &rtti_Base, "MyNonAbstractClass", "", 10, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK(rtti_abstract.isAbstract);
        CHECK(!rtti_not_abstract.isAbstract);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterClass_SetsSealedInRTTI)
    {
        TestClassID classID_Sealed(21);
        TestClassID classID_NotSealed(22);
        RTTI rtti_sealed;
        RTTI rtti_not_sealed;

        RegisterTypeHelper(m_Manager, classID_Sealed, &rtti_sealed, &rtti_Base, "MySealedClass", "", 10, NULL, kTypeIsSealed);
        RegisterTypeHelper(m_Manager, classID_NotSealed, &rtti_not_sealed, &rtti_Base, "MyNonSealedClass", "", 10, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK(rtti_sealed.isSealed);
        CHECK(!rtti_not_sealed.isSealed);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterClass_SetsEditorOnlyInRTTI)
    {
        TestClassID classID_EditorOnly(21);
        TestClassID classID_NotEditorOnly(22);
        RTTI rtti_true;
        RTTI rtti_false;

        RegisterTypeHelper(m_Manager, classID_EditorOnly, &rtti_true, &rtti_Base, "MyEditorOnlyClass", "", 10, NULL, kTypeIsEditorOnly);
        RegisterTypeHelper(m_Manager, classID_NotEditorOnly, &rtti_false, &rtti_Base, "MyNotEditorOnlyClass", "", 10, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK(rtti_true.isEditorOnly);
        CHECK(!rtti_false.isEditorOnly);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterClass_DoesntSetIsStrippedInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        RegisterTypeHelper(m_Manager, classID_Test, &rtti, &rtti_Base, "MyNotStrippedClass", "", 10, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();
        CHECK(!rtti.isStripped);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterStrippedClass_SetIsStrippedInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        m_Manager.RegisterStrippedTypeInfo(classID_Test, &rtti, "MyStrippedClass", "");
        m_Manager.InitializeAllTypes();
        CHECK(rtti.isStripped);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, MarkDeprecated_SetsIsDeprecatedInRTTI)
    {
        TestClassID classID_Deprecated(21);
        TestClassID classID_NotDeprecated(22);
        RTTI rtti_true;
        RTTI rtti_false;

        RegisterTypeHelper(m_Manager, classID_Deprecated, &rtti_true, &rtti_Base, "MyDeprecatedClass", "", 10, NULL, kTypeNoFlags);
        RegisterTypeHelper(m_Manager, classID_NotDeprecated, &rtti_false, &rtti_Base, "MyNonDeprecatedClass", "", 10, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();
        m_Manager.MarkDeprecated(classID_Deprecated);

        CHECK(rtti_true.isDeprecated);
        CHECK(!rtti_false.isDeprecated);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterStrippedClass_SetsDefaultsInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        m_Manager.RegisterStrippedTypeInfo(classID_Test, &rtti, "MyClass", "");
        m_Manager.InitializeAllTypes();

        CHECK_EQUAL(static_cast<void*>(NULL), rtti.base);
        CHECK_EQUAL(static_cast<void*>(NULL), rtti.factory);
        CHECK_EQUAL(-1, rtti.size);
        CHECK(!rtti.isAbstract);
        CHECK(!rtti.isSealed);
        CHECK(!rtti.isEditorOnly);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, TypeIndexToTypeInfo_ReturnsValidTypeInfoForValidTypeIndex)
    {
        TestClassID classID_Test1(21);
        TestClassID classID_Test2(22);
        RTTI rtti_test1;
        RTTI rtti_test2;

        RegisterTypeHelper(m_Manager, classID_Test1, &rtti_test1, &rtti_Base, "Class1", "", 42, NULL, kTypeNoFlags);
        RegisterTypeHelper(m_Manager, classID_Test2, &rtti_test2, &rtti_Base, "Class2", "", 42, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK_EQUAL(&rtti_Base, m_Manager.TypeIndexToTypeInfo(rtti_Base.derivedFromInfo.typeIndex));
        CHECK_EQUAL(&rtti_test1, m_Manager.TypeIndexToTypeInfo(rtti_test1.derivedFromInfo.typeIndex));
        CHECK_EQUAL(&rtti_test2, m_Manager.TypeIndexToTypeInfo(rtti_test2.derivedFromInfo.typeIndex));
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, ClassNameToTypeInfo_ReturnsValidTypeInfoForRegisteredName)
    {
        TestClassID classID_Test1(21);
        TestClassID classID_Test2(22);
        RTTI rtti_test1;
        RTTI rtti_test2;

        RegisterTypeHelper(m_Manager, classID_Test1, &rtti_test1, &rtti_Base, "Class1", "", 42, NULL, kTypeNoFlags);
        RegisterTypeHelper(m_Manager, classID_Test2, &rtti_test2, &rtti_Base, "Class2", "", 42, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK_EQUAL(&rtti_test1, m_Manager.ClassNameToTypeInfo("Class1"));
        CHECK_EQUAL(&rtti_test2, m_Manager.ClassNameToTypeInfo("Class2"));
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, ClassNameToTypeInfo_ReturnsNullForUnregisteredName)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        RegisterTypeHelper(m_Manager, classID_Test, &rtti, &rtti_Base, "Class1", "", 42, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK_EQUAL(static_cast<TypeInfo>(NULL), m_Manager.ClassNameToTypeInfo("NoClassWithThisName"));
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, ClassNameToTypeInfo_ReturnsNullForStrippedClass)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        m_Manager.RegisterStrippedTypeInfo(classID_Test, &rtti, "Class1", "");
        m_Manager.InitializeAllTypes();

        CHECK_EQUAL(static_cast<TypeInfo>(NULL), m_Manager.ClassNameToTypeInfo("Class1"));
    }

    struct FixtureWithSimpleHierarchy
    {
        TestClassID classID_Base;
        TestClassID classID_Abstract;
        TestClassID classID_Abstract_AbstractChild;
        TestClassID classID_Abstract_ConcreteChild;
        TestClassID classID_Stripped_1;
        TestClassID classID_Concrete;
        TestClassID classID_Concrete_AbstractChild;
        TestClassID classID_Concrete_ConcreteChild;
        TestClassID classID_Stripped_2;

        RTTI rtti_Base;
        RTTI rtti_Abstract;
        RTTI rtti_Abstract_AbstractChild;
        RTTI rtti_Abstract_ConcreteChild;
        RTTI rtti_Stripped_1;
        RTTI rtti_Concrete;
        RTTI rtti_Concrete_AbstractChild;
        RTTI rtti_Concrete_ConcreteChild;
        RTTI rtti_Stripped_2;

        RTTI::RuntimeTypeArray storage;
        TypeInfoManager m_Manager;

        FixtureWithSimpleHierarchy() :
            m_Manager(storage),
            classID_Base(0),
            classID_Abstract(50),
            classID_Abstract_AbstractChild(51),
            classID_Abstract_ConcreteChild(52),
            classID_Stripped_1(90),
            classID_Concrete(60),
            classID_Concrete_AbstractChild(61),
            classID_Concrete_ConcreteChild(62),
            classID_Stripped_2(92)
        {
            RegisterTypeHelper(m_Manager, classID_Base, &rtti_Base, NULL, "TestBaseClass", "", 42, NULL, kTypeIsAbstract);
            RegisterTypeHelper(m_Manager, classID_Abstract, &rtti_Abstract, &rtti_Base, "Abstract", "", 42, NULL, kTypeIsAbstract);
            RegisterTypeHelper(m_Manager, classID_Abstract_AbstractChild, &rtti_Abstract_AbstractChild, &rtti_Abstract, "Abstract_AbstractChild", "", 42, NULL, kTypeIsAbstract);

            m_Manager.RegisterStrippedTypeInfo(classID_Stripped_1, &rtti_Stripped_1, "Stripped_1", "");

            RegisterTypeHelper(m_Manager, classID_Concrete, &rtti_Concrete, &rtti_Base, "Concrete", "", 42, NULL, kTypeNoFlags);
            RegisterTypeHelper(m_Manager, classID_Concrete_ConcreteChild, &rtti_Concrete_ConcreteChild, &rtti_Concrete, "Concrete_ConcreteChild", "", 42, NULL, kTypeNoFlags);

            RegisterTypeHelper(m_Manager, classID_Abstract_ConcreteChild, &rtti_Abstract_ConcreteChild, &rtti_Abstract, "Abstract_ConcreteChild", "", 42, NULL, kTypeNoFlags);
            RegisterTypeHelper(m_Manager, classID_Concrete_AbstractChild, &rtti_Concrete_AbstractChild, &rtti_Concrete, "Concrete_AbstractChild", "", 42, NULL, kTypeIsAbstract);

            m_Manager.RegisterStrippedTypeInfo(classID_Stripped_2, &rtti_Stripped_2, "Stripped_2", "");

            m_Manager.InitializeAllTypes();
        }

        ~FixtureWithSimpleHierarchy()
        {
            m_Manager.CleanupAllTypes();
        }
    };

    TEST_FIXTURE(FixtureWithSimpleHierarchy, IsDerivedFrom_SelfReturnTrue)
    {
        CHECK(IsDerivedFrom(&rtti_Base, &rtti_Base));

        CHECK(IsDerivedFrom(&rtti_Abstract, &rtti_Abstract));
        CHECK(IsDerivedFrom(&rtti_Abstract_AbstractChild, &rtti_Abstract_AbstractChild));
        CHECK(IsDerivedFrom(&rtti_Abstract_ConcreteChild, &rtti_Abstract_ConcreteChild));

        CHECK(IsDerivedFrom(&rtti_Concrete, &rtti_Concrete));
        CHECK(IsDerivedFrom(&rtti_Concrete_AbstractChild, &rtti_Concrete_AbstractChild));
        CHECK(IsDerivedFrom(&rtti_Concrete_ConcreteChild, &rtti_Concrete_ConcreteChild));
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, IsDerivedFrom_DirectBaseReturnsTrue)
    {
        CHECK(IsDerivedFrom(&rtti_Abstract, &rtti_Base));
        CHECK(IsDerivedFrom(&rtti_Concrete, &rtti_Base));

        CHECK(IsDerivedFrom(&rtti_Abstract_AbstractChild, &rtti_Abstract));
        CHECK(IsDerivedFrom(&rtti_Abstract_ConcreteChild, &rtti_Abstract));

        CHECK(IsDerivedFrom(&rtti_Concrete_AbstractChild, &rtti_Concrete));
        CHECK(IsDerivedFrom(&rtti_Concrete_ConcreteChild, &rtti_Concrete));
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, IsDerivedFrom_IndirectBaseReturnsTrue)
    {
        CHECK(IsDerivedFrom(&rtti_Abstract_AbstractChild, &rtti_Base));
        CHECK(IsDerivedFrom(&rtti_Abstract_ConcreteChild, &rtti_Base));
        CHECK(IsDerivedFrom(&rtti_Concrete_AbstractChild, &rtti_Base));
        CHECK(IsDerivedFrom(&rtti_Concrete_ConcreteChild, &rtti_Base));
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, IsDerivedFrom_NonBaseReturnsFalse)
    {
        CHECK(!IsDerivedFrom(&rtti_Abstract, &rtti_Concrete));
        CHECK(!IsDerivedFrom(&rtti_Concrete, &rtti_Abstract));

        CHECK(!IsDerivedFrom(&rtti_Abstract_AbstractChild, &rtti_Concrete));
        CHECK(!IsDerivedFrom(&rtti_Abstract_ConcreteChild, &rtti_Concrete));
        CHECK(!IsDerivedFrom(&rtti_Concrete_AbstractChild, &rtti_Abstract));
        CHECK(!IsDerivedFrom(&rtti_Concrete_ConcreteChild, &rtti_Abstract));
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, IsDerivedFrom_StrippedReturnsFalse)
    {
        CHECK(!IsDerivedFrom(&rtti_Stripped_1, &rtti_Base));
        CHECK(!IsDerivedFrom(&rtti_Stripped_2, &rtti_Base));

        CHECK(!IsDerivedFrom(&rtti_Stripped_1, &rtti_Concrete));
        CHECK(!IsDerivedFrom(&rtti_Stripped_1, &rtti_Abstract));
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, FindAllDerivedClasses_TypeInfo_BothAbstractAndNonAbstract)
    {
        dynamic_array<TypeInfo> typeInfoResult;
        m_Manager.FindAllDerivedClasses(&rtti_Abstract, typeInfoResult, false);
        CHECK_EQUAL(3, typeInfoResult.size());
        CHECK(std::find(typeInfoResult.begin(), typeInfoResult.end(), &rtti_Abstract) != typeInfoResult.end());
        CHECK(std::find(typeInfoResult.begin(), typeInfoResult.end(), &rtti_Abstract_ConcreteChild) != typeInfoResult.end());
        CHECK(std::find(typeInfoResult.begin(), typeInfoResult.end(), &rtti_Abstract_AbstractChild) != typeInfoResult.end());

        typeInfoResult.clear();
        m_Manager.FindAllDerivedClasses(&rtti_Concrete, typeInfoResult, false);
        CHECK_EQUAL(3, typeInfoResult.size());
        CHECK(std::find(typeInfoResult.begin(), typeInfoResult.end(), &rtti_Concrete) != typeInfoResult.end());
        CHECK(std::find(typeInfoResult.begin(), typeInfoResult.end(), &rtti_Concrete_ConcreteChild) != typeInfoResult.end());
        CHECK(std::find(typeInfoResult.begin(), typeInfoResult.end(), &rtti_Concrete_AbstractChild) != typeInfoResult.end());
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, FindAllDerivedClasses_TypeInfo_OnlyNonAbstract)
    {
        dynamic_array<TypeInfo> typeInfoResult;
        m_Manager.FindAllDerivedClasses(&rtti_Abstract, typeInfoResult, true);
        CHECK_EQUAL(1, typeInfoResult.size());
        CHECK(std::find(typeInfoResult.begin(), typeInfoResult.end(), &rtti_Abstract_ConcreteChild) != typeInfoResult.end());

        typeInfoResult.clear();
        m_Manager.FindAllDerivedClasses(&rtti_Concrete, typeInfoResult, true);
        CHECK_EQUAL(2, typeInfoResult.size());
        CHECK(std::find(typeInfoResult.begin(), typeInfoResult.end(), &rtti_Concrete) != typeInfoResult.end());
        CHECK(std::find(typeInfoResult.begin(), typeInfoResult.end(), &rtti_Concrete_ConcreteChild) != typeInfoResult.end());
    }

    static bool Contains(const dynamic_array<ClassIDType>& ids, TestClassID& testID)
    {
        for (dynamic_array<ClassIDType>::const_iterator it = ids.begin(); it != ids.end(); ++it)
        {
            if (*it == testID)
                return true;
        }
        return false;
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, FindAllDerivedClasses_ClassID_BothAbstractAndNonAbstract)
    {
        dynamic_array<ClassIDType> classIDResult;
        m_Manager.FindAllDerivedClasses(static_cast<ClassIDType>(classID_Abstract), classIDResult, false);
        CHECK_EQUAL(3, classIDResult.size());
        CHECK(Contains(classIDResult, classID_Abstract));
        CHECK(Contains(classIDResult, classID_Abstract_AbstractChild));
        CHECK(Contains(classIDResult, classID_Abstract_ConcreteChild));

        classIDResult.clear();
        m_Manager.FindAllDerivedClasses(static_cast<ClassIDType>(classID_Concrete), classIDResult, false);
        CHECK_EQUAL(3, classIDResult.size());
        CHECK(Contains(classIDResult, classID_Concrete));
        CHECK(Contains(classIDResult, classID_Concrete_AbstractChild));
        CHECK(Contains(classIDResult, classID_Concrete_ConcreteChild));
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, FindAllDerivedClasses_ClassID_OnlyNonAbstract)
    {
        dynamic_array<ClassIDType> classIDResult;
        m_Manager.FindAllDerivedClasses(static_cast<ClassIDType>(classID_Abstract), classIDResult, true);
        CHECK_EQUAL(1, classIDResult.size());
        CHECK(Contains(classIDResult, classID_Abstract_ConcreteChild));

        classIDResult.clear();
        m_Manager.FindAllDerivedClasses(static_cast<ClassIDType>(classID_Concrete), classIDResult, true);
        CHECK_EQUAL(2, classIDResult.size());
        CHECK(Contains(classIDResult, classID_Concrete));
        CHECK(Contains(classIDResult, classID_Concrete_ConcreteChild));
    }

    struct FixtureWithMultipleHierarchies
    {
        TestClassID classID_Base1;
        TestClassID classID_Derived1_a;
        TestClassID classID_Derived1_b;
        TestClassID classID_Base2;
        TestClassID classID_Derived2_a;
        TestClassID classID_Base3;

        RTTI rtti_Base1;
        RTTI rtti_Derived1_a;
        RTTI rtti_Derived1_b;
        RTTI rtti_Base2;
        RTTI rtti_Derived2_a;
        RTTI rtti_Base3;

        RTTI::RuntimeTypeArray storage;
        TypeInfoManager m_Manager;

        FixtureWithMultipleHierarchies() :
            m_Manager(storage),
            classID_Base1(50),
            classID_Derived1_a(51),
            classID_Derived1_b(52),
            classID_Base2(60),
            classID_Derived2_a(61),
            classID_Base3(70)
        {
            RegisterTypeHelper(m_Manager, classID_Base1, &rtti_Base1, NULL, "Base1", "", 42, NULL, kTypeIsAbstract);
            RegisterTypeHelper(m_Manager, classID_Derived1_a, &rtti_Derived1_a, &rtti_Base1, "Derived1_a", "", 42, NULL, kTypeIsAbstract);
            RegisterTypeHelper(m_Manager, classID_Derived1_b, &rtti_Derived1_b, &rtti_Base1, "Derived1_b", "", 42, NULL, kTypeIsAbstract);

            RegisterTypeHelper(m_Manager, classID_Base2, &rtti_Base2, NULL, "Base2", "", 42, NULL, kTypeIsAbstract);
            RegisterTypeHelper(m_Manager, classID_Derived2_a, &rtti_Derived2_a, &rtti_Base2, "Derived2_a", "", 42, NULL, kTypeIsAbstract);

            RegisterTypeHelper(m_Manager, classID_Base3, &rtti_Base3, NULL, "Base3", "", 42, NULL, kTypeIsAbstract);

            m_Manager.InitializeAllTypes();
        }

        ~FixtureWithMultipleHierarchies()
        {
            m_Manager.CleanupAllTypes();
        }
    };

    TEST_FIXTURE(FixtureWithMultipleHierarchies, MultipleHierarchies_TypeIndicesAreValid)
    {
        CHECK(rtti_Base1.derivedFromInfo.typeIndex != RTTI::DefaultTypeIndex);
        CHECK(rtti_Derived1_a.derivedFromInfo.typeIndex != RTTI::DefaultTypeIndex);
        CHECK(rtti_Derived1_b.derivedFromInfo.typeIndex != RTTI::DefaultTypeIndex);
        CHECK(rtti_Base2.derivedFromInfo.typeIndex != RTTI::DefaultTypeIndex);
        CHECK(rtti_Derived2_a.derivedFromInfo.typeIndex != RTTI::DefaultTypeIndex);
        CHECK(rtti_Base3.derivedFromInfo.typeIndex != RTTI::DefaultTypeIndex);
    }

    TEST_FIXTURE(FixtureWithMultipleHierarchies, MultipleHierarchies_DescendantCountIsCorrect)
    {
        // NOTE : descendant count is 1 + #descendants
        CHECK_EQUAL(3, rtti_Base1.derivedFromInfo.descendantCount);
        CHECK_EQUAL(2, rtti_Base2.derivedFromInfo.descendantCount);
        CHECK_EQUAL(1, rtti_Base3.derivedFromInfo.descendantCount);
    }

    TEST_FIXTURE(FixtureWithMultipleHierarchies, MultipleHierarchies_DerivedFromIsTrueWithinHierarchies)
    {
        CHECK(RTTI::IsDerivedFrom(rtti_Derived1_a, rtti_Base1));
        CHECK(RTTI::IsDerivedFrom(rtti_Derived2_a, rtti_Base2));
    }

    TEST_FIXTURE(FixtureWithMultipleHierarchies, MultipleHierarchies_DerivedFromIsFalseAcrossHierarchies)
    {
        CHECK(!RTTI::IsDerivedFrom(rtti_Base1, rtti_Base2));
        CHECK(!RTTI::IsDerivedFrom(rtti_Base1, rtti_Base3));

        CHECK(!RTTI::IsDerivedFrom(rtti_Derived1_a, rtti_Base2));
        CHECK(!RTTI::IsDerivedFrom(rtti_Derived1_b, rtti_Base3));
        CHECK(!RTTI::IsDerivedFrom(rtti_Derived2_a, rtti_Base1));
    }

    TEST(CallbacksAreCalledWhenExpected)
    {
        TestClassID classID_base(0);
        TestClassID classID_init(10);
        TestClassID classID_postInit(11);
        TestClassID classID_cleanup(12);

        RTTI rtti_base;
        RTTI rtti_init;
        RTTI rtti_postInit;
        RTTI rtti_cleanup;

        RTTI::RuntimeTypeArray storage;
        TypeInfoManager manager(storage);
        RegisterTypeHelper(manager, classID_base, &rtti_base, NULL, "TestBaseClass", "", 42, NULL, kTypeIsAbstract);

        static UInt32 init_called = 0;
        static UInt32 postinit_called = 0;
        static UInt32 cleanup_called = 0;

        struct CallbackHelper
        {
            static void InitCallback() { ++init_called; }
            static void PostInitCallback() { ++postinit_called; }
            static void CleanupCallback() { ++cleanup_called; }
        };

        TypeRegistrationDesc initDesc = InitTypeRegistrationDesc(classID_init, &rtti_init, &rtti_base, "ClassWithStaticInit");
        initDesc.initCallback = &CallbackHelper::InitCallback;
        manager.RegisterType(initDesc);

        TypeRegistrationDesc postInitDesc = InitTypeRegistrationDesc(classID_postInit, &rtti_postInit, &rtti_base, "ClassWithStaticPostInit");
        postInitDesc.postInitCallback = &CallbackHelper::PostInitCallback;
        manager.RegisterType(postInitDesc);

        TypeRegistrationDesc cleanupDesc = InitTypeRegistrationDesc(classID_cleanup, &rtti_cleanup, &rtti_base, "ClassWithStaticCleanup");
        cleanupDesc.cleanupCallback = &CallbackHelper::CleanupCallback;
        manager.RegisterType(cleanupDesc);

        manager.InitializeAllTypes();

        CHECK_EQUAL(0, init_called);
        CHECK_EQUAL(0, postinit_called);
        CHECK_EQUAL(0, cleanup_called);

        manager.CallInitializeTypes();

        CHECK_EQUAL(1, init_called);
        CHECK_EQUAL(0, postinit_called);
        CHECK_EQUAL(0, cleanup_called);

        manager.CallPostInitializeTypes();

        CHECK_EQUAL(1, init_called);
        CHECK_EQUAL(1, postinit_called);
        CHECK_EQUAL(0, cleanup_called);

        manager.CleanupAllTypes();

        CHECK_EQUAL(1, init_called);
        CHECK_EQUAL(1, postinit_called);
        CHECK_EQUAL(1, cleanup_called);
    }
}

INTEGRATION_TEST_SUITE(TypeInfoManagerIntegrationTests)
{
    TEST(TypeIndicesAreConsecutive)
    {
        for (UInt32 i = 0; i < TypeInfoManager::Get().TypeCount(); ++i)
            CHECK(TypeInfoManager::Get().TypeIndexToTypeInfo(i) != NULL);
    }

    TEST(IsDerivedFrom_ForAllRegisteredClasses_MatchesDataInTypeInfo)
    {
        struct local
        {
            static bool IsDerivedFromByWalkingBase(const Unity::Type* derivedType, const Unity::Type* baseType)
            {
                const Unity::Type* i = derivedType;
                while (i)
                {
                    if (baseType == i)
                        return true;

                    i = i->GetBaseClass();
                }
                return false;
            }
        };

        for (UInt32 i = 0; i < Unity::Type::GetTypeCount(); ++i)
        {
            const Unity::Type* t1 = Unity::Type::GetTypeByRuntimeTypeIndex(i);
            for (UInt32 j = 0; j < Unity::Type::GetTypeCount(); ++j)
            {
                const Unity::Type* t2 = Unity::Type::GetTypeByRuntimeTypeIndex(j);
                CHECK_EQUAL(local::IsDerivedFromByWalkingBase(t1, t2), t1->IsDerivedFrom(t2));
            }
        }
    }

    TEST(TypeIndex_ForAllRegisteredClasses_IsUnique)
    {
        for (UInt32 i = 0; i < TypeInfoManager::Get().TypeCount(); ++i)
        {
            TypeInfo t1 = TypeInfoManager::Get().TypeIndexToTypeInfo(i);
            for (UInt32 j = 0; j < TypeInfoManager::Get().TypeCount(); ++j)
            {
                TypeInfo t2 = TypeInfoManager::Get().TypeIndexToTypeInfo(j);
                if (i != j)
                    CHECK(t1->derivedFromInfo.typeIndex != t2->derivedFromInfo.typeIndex);
            }
        }
    }

#if UNITY_EDITOR
    TEST(IsEditorOnly_AssetImporterIsEditorOnly)
    {
        const Unity::Type* type = TypeOf<AssetImporter>();
        CHECK(type->IsEditorOnly());
    }

    struct SerializeType
    {
        DECLARE_SERIALIZE_NO_PPTR(SerializeTypeInfo);
        const Unity::Type* type;
    };

    template<class TransferFunction>
    void SerializeType::Transfer(TransferFunction& transfer)
    {
        transfer.Transfer(type, "type");
    }

    const PersistentTypeID NonExistingTypeID = static_cast<PersistentTypeID>(42);

    const char* serializedTransformTypeData = "type: 4\n";  // PersistentTypeID of Transform
    const char* serializedUnknownTypeData   = "type: 42\n"; // Non existing PersistentTypeID
    const char* serializedUndefinedTypeData = "type: -1\n"; // Undefined PersistentTypeID

    TEST(TypeInfo_SerializeTransformType_SerializedYaml)
    {
        SerializeType input;
        core::string str;
        input.type = TypeOf<Transform>();
        YAMLWrite write(kNoTransferInstructionFlags);

        input.Transfer(write);
        write.OutputToString(str);

        CHECK_EQUAL(serializedTransformTypeData, str);
    }

    TEST(TypeInfo_SerializeUndefinedType_SerializedYaml)
    {
        SerializeType input;
        core::string str;
        input.type = NULL;
        YAMLWrite write(kNoTransferInstructionFlags);

        input.Transfer(write);

        write.OutputToString(str);
        CHECK_EQUAL(serializedUndefinedTypeData, str);
    }

    TEST(TypeInfo_DeserializeYaml_TransformType)
    {
        SerializeType output;
        output.type = NULL;
        YAMLRead read(serializedTransformTypeData,
                      strlen(serializedTransformTypeData),
                      kNoTransferInstructionFlags, kMemTempAlloc);

        output.Transfer(read);

        CHECK_MSG(TypeOf<Transform>() == output.type, "Deserializing Transform type gave back unexpected type");
    }

    TEST(TypeInfo_YamlDeserialization_UndefinedType)
    {
        SerializeType output;
        output.type = NULL;
        YAMLRead read(serializedUndefinedTypeData,
                      strlen(serializedUndefinedTypeData),
                      kNoTransferInstructionFlags, kMemTempAlloc);

        output.Transfer(read);

        CHECK_MSG(output.type == NULL, "Deserializing undefined type didn't give back NULL type");
    }

    TEST(TypeInfo_YamlDeserialization_UnknownType)
    {
        SerializeType output;
        output.type = NULL;
        YAMLRead read(serializedUnknownTypeData,
                      strlen(serializedUnknownTypeData),
                      kNoTransferInstructionFlags, kMemTempAlloc);

        output.Transfer(read);

        CHECK_MSG(output.type != NULL, "Deserializing unknown type gave back unexpected NULL type");
        CHECK_MSG(output.type->GetPersistentTypeID() == NonExistingTypeID, "Deserializing unknown type gave back type with unexpected classID");
    }


    template<class T>
    struct BinarySerializeType
    {
        DECLARE_SERIALIZE_NO_PPTR(BinarySerializeType_ClassID);
        T a;
        T b;
    };

    template<class T>
    template<class TransferFunction>
    void BinarySerializeType<T>::Transfer(TransferFunction& transfer)
    {
        TRANSFER(a);
        TRANSFER(b);
    }

    template<class T>
    void ReadInstanceFromVector(T& instance, const dynamic_array<UInt8>& data, const TypeTreeIterator& type)
    {
        MemoryCacheReader memoryCache(const_cast<dynamic_array<UInt8>&>(data));
        SafeBinaryRead readStream;
        CachedReader& readCache = readStream.Init(type, 0, data.size(), kNoTransferInstructionFlags, kMemTempAlloc);
        readCache.InitRead(memoryCache, 0, data.size());

        readStream.Transfer(instance, "Base");
        readCache.End();
    }

    template<class T>
    static inline void WriteInstanceToVector(const T& instance, dynamic_array<UInt8>& data)
    {
        data.clear();

        MemoryCacheWriter memoryCache(data);
        StreamedBinaryWrite<false> writeStream;
        CachedWriter& writeCache = writeStream.Init(kNoTransferInstructionFlags, BuildTargetSelection::NoTarget());

        writeCache.InitWrite(memoryCache);
        writeStream.Transfer(const_cast<T&>(instance), "Base");

        if (!writeCache.CompleteWriting() || writeCache.GetPosition() != data.size())
            ErrorString("Error while writing serialized data.");
    }

    template<typename IntegerType>
    void CheckIntegerTypeConvertsToTypePtr()
    {
        BinarySerializeType<IntegerType> integerVersion;
        integerVersion.a = 4;
        integerVersion.b = (IntegerType) - 1;

        TypeTree integerVersionTypeTree;
        GenerateTypeTreeTransfer transfer(integerVersionTypeTree, kNoTransferInstructionFlags, &integerVersion, sizeof(integerVersion));
        transfer.TransferBase(integerVersion);

        dynamic_array<UInt8> integerVersionData(kMemTempAlloc);
        WriteInstanceToVector(integerVersion, integerVersionData);

        BinarySerializeType<const Unity::Type*> typePtrVersion;
        typePtrVersion.a = TypeOf<Object>();
        typePtrVersion.b = TypeOf<Object>();

        ReadInstanceFromVector(typePtrVersion, integerVersionData, integerVersionTypeTree.Root());

        CHECK(TypeOf<Transform>() == typePtrVersion.a);
        CHECK(NULL == typePtrVersion.b);
    }

    TEST(CanDeserialize_TypePtr_From16BitIntegerTypes)
    {
        CheckIntegerTypeConvertsToTypePtr<SInt16>();
        CheckIntegerTypeConvertsToTypePtr<UInt16>();
    }

    TEST(CanDeserialize_TypePtr_From32BitIntegerTypes)
    {
        CheckIntegerTypeConvertsToTypePtr<SInt32>();
        CheckIntegerTypeConvertsToTypePtr<UInt32>();
    }

    TEST(TypeInfo_CanGenerateTypeTreeContaining_Type)
    {
        TypeTree type;
        SerializeType output;
        output.type = NULL;
        GenerateTypeTreeTransfer generator(type, kNoTransferInstructionFlags, NULL, sizeof(SerializeType));

        output.Transfer(generator);

        TypeTreeIterator typeInfoMember = type.Root();
        CHECK_EQUAL("type", typeInfoMember.Name().c_str());
        CHECK_EQUAL("Type*", typeInfoMember.Type().c_str());
        CHECK(typeInfoMember.IsBasicDataType());
    }

    TEST(TypeInfo_PrimitiveTypesAreNotObjectDerived)
    {
        const Unity::Type* floatType = Unity::Type::FindTypeByName("float");
        CHECK(floatType != NULL);

        const Unity::Type* intType = Unity::Type::FindTypeByName("int");
        CHECK(intType != NULL);

        const Unity::Type* boolType = Unity::Type::FindTypeByName("bool");
        CHECK(boolType != NULL);

        CHECK(!floatType->IsDerivedFrom<Object>());
        CHECK(!intType->IsDerivedFrom<Object>());
        CHECK(!boolType->IsDerivedFrom<Object>());
    }

    TEST(GetDeserializationStubForPersistentTypeID_DoesNotReturnNULL)
    {
        RTTI::RuntimeTypeArray storage;
        TypeManager typeManager(storage);
        const RTTI* stub = typeManager.GetDeserializationStubForPersistentTypeID(42);

        CHECK(stub != NULL);
    }

    TEST(GetDeserializationStubForPersistentTypeID_WithPersistentTypeID_ReturnsStubThatHasSamePersistentTypeID)
    {
        RTTI::RuntimeTypeArray storage;
        TypeManager typeManager(storage);
        const PersistentTypeID expectedPersistentTypeID = 42;
        const RTTI* stub = typeManager.GetDeserializationStubForPersistentTypeID(expectedPersistentTypeID);

        PersistentTypeID actualPersistentTypeID = stub->classID;

        CHECK_EQUAL(expectedPersistentTypeID, actualPersistentTypeID);
    }

    TEST(GetDeserializationStubForPersistentTypeID_CalledMultipleTimesWithSameID_ReturnsSameStub)
    {
        RTTI::RuntimeTypeArray storage;
        TypeManager typeManager(storage);
        const RTTI* expectedStub = typeManager.GetDeserializationStubForPersistentTypeID(42);
        const RTTI* secondStub   = typeManager.GetDeserializationStubForPersistentTypeID(42);

        CHECK_EQUAL(expectedStub, secondStub);
    }

#endif // UNITY_EDITOR
}


#endif
