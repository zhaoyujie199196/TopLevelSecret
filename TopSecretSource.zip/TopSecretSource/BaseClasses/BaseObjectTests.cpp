#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "BaseObject.h"
#include "Runtime/Testing/Testing.h"
#include "Runtime/Testing/ParametricTest.h"
#include "Runtime/Allocator/BaseAllocator.h"
#include "Runtime/Allocator/MemoryManager.h"
#include "Runtime/Serialize/TransferUtility.h"

class GameObject;
class Transform;
class MonoManager;
class AudioMixer;
class GameManager;
class MonoScript;
class ProceduralTexture;
class ProceduralMaterial;
class AnimationClip;
class AnimatorOverrideController;
class Texture3D;
class MovieTexture;
class Font;
class NetworkView;
class GUITexture;
class TerrainData;
class WorldAnchor;
class MonoBehaviour;

INTEGRATION_TEST_SUITE(BaseObjectTests)
{
    PARAMETRIC_TEST_SOURCE(AllNonAbstractTypes, (const Unity::Type*))
    {
        dynamic_array<const Unity::Type*> classes(kMemTempAlloc);
        TypeOf<Object>()->FindAllDerivedClasses(classes, Unity::Type::kOnlyNonAbstract);

        for (int i = 0; i < classes.size(); ++i)
        {
            const Unity::Type* type = classes[i];

            // MonoManager requires the Mono library to be loaded.
            if (type == WeakTypeOf<MonoManager>())
            {
                PARAMETRIC_TEST_CASE_DISABLED(type);
                continue;
            }

            // Cleaning up AudioMixer requires AudioManager to be installed.
            if (type->IsDerivedFrom(WeakTypeOf<AudioMixer>()))
            {
                PARAMETRIC_TEST_CASE_DISABLED(type);
                continue;
            }

            PARAMETRIC_TEST_CASE(type);
        }
    }

    // Every object should destruct properly even when not having its AwakeFromLoad()
    // method called.
    PARAMETRIC_TEST(ClassAllowsDestructionWithoutAwakening, (const Unity::Type * type), AllNonAbstractTypes)
    {
        Object* instance = Object::Produce(type);
        instance->Reset();
        DestroySingleObject(instance);
    }

    class StompingAllocator : public BaseAllocator
    {
    private:
        BaseAllocator* m_UnderlyingAllocator;
    public:
        StompingAllocator(BaseAllocator* underlying) : BaseAllocator("Stomping allocator"), m_UnderlyingAllocator(underlying) {}

        UInt8 pattern;

        virtual void*  Allocate(size_t size, int align)
        {
            void* result = m_UnderlyingAllocator->Allocate(size, align);
            memset(result, pattern, size);
            return result;
        }

        virtual void*  Reallocate(void* p, size_t size, int align)
        {
            // Not supported
            return NULL;
        }

        virtual void   Deallocate(void* p) { m_UnderlyingAllocator->Deallocate(p); }
        virtual bool   Contains(const void* p) const { return m_UnderlyingAllocator->Contains(p); }
        virtual size_t GetPtrSize(const void* ptr) const { return m_UnderlyingAllocator->GetPtrSize(ptr); }

            #if USE_MEMORY_DEBUGGING || ENABLE_MEM_PROFILER
        virtual ProfilerAllocationHeader* GetProfilerHeader(const void* ptr) const { return m_UnderlyingAllocator->GetProfilerHeader(ptr); }
        virtual size_t GetRequestedPtrSize(const void* ptr) const { return m_UnderlyingAllocator->GetRequestedPtrSize(ptr); }
            #endif // USE_MEMORY_DEBUGGING || ENABLE_MEM_PROFILER

        virtual bool CanStompMemoryOnAlloc() const { return false; }
    };


    PARAMETRIC_TEST(Class_AfterCreateAndReset_HasConsistentSerializedData, (const Unity::Type * type), AllNonAbstractTypes)
    {
        StompingAllocator stomper(GetMemoryManager().GetAllocator(kMemDefault));
        MemLabelId stomperId = GetMemoryManager().AddCustomAllocator(&stomper);

        dynamic_array<UInt8> obj1(kMemTempAlloc);
        dynamic_array<UInt8> obj2(kMemTempAlloc);

        // Create and reset the object once, initially filling the memory with 0x00,
        // and serialize it to a vector.

        stomper.pattern = 0;

        Object* obj = Object::Produce(type, InstanceID_None, stomperId, kCreateObjectDefault);
        obj->Reset();
        obj1.clear();
        WriteObjectToVector(*obj, obj1);
        DestroySingleObject(obj);

        // Create and reset the object again, now filling memory with 0xff, and serialize.
        // Any value the object does not set in constructor/reset will thus be different.

        stomper.pattern = 0xff;

        obj = Object::Produce(type, InstanceID_None, stomperId, kCreateObjectDefault);
        obj->Reset();
        obj2.clear();
        WriteObjectToVector(*obj, obj2);
        DestroySingleObject(obj);

        // Compare the serialized representations
        CHECK_EQUAL(obj1.size(), obj2.size());
        CHECK_MSG(obj1 == obj2, Format("Expected two created+reset instances to match when serialized, but they differed at position %u (of %u). This means you forgot to initialize a field that is serialized.",
                std::distance(obj1.begin(), std::mismatch(obj1.begin(), obj1.end(), obj2.begin()).first),
                obj1.size()).c_str());

        GetMemoryManager().RemoveCustomAllocator(stomperId);
    }

#if SUPPORT_THREADS

    const static int kBaseVeryHighInstanceID = (std::numeric_limits<SInt32>::max() - 1) - 5000 * 4;

    struct CreateObjectsOnNonMainThreadFixture
    {
        const Unity::Type* objectType;
        Object* createdObject;

        static void* CreateObjectThread(void* userData)
        {
            CreateObjectsOnNonMainThreadFixture* fixture = (CreateObjectsOnNonMainThreadFixture*)userData;

            Object* obj = Object::Produce(fixture->objectType, kBaseVeryHighInstanceID, kMemBaseObject, kCreateObjectFromNonMainThread);
            obj->Reset();
            obj->AwakeFromLoadThreaded();

            fixture->createdObject = obj;

            return NULL;
        }

        ~CreateObjectsOnNonMainThreadFixture()
        {
            DestroySingleObject(createdObject);
        }
    };

    PARAMETRIC_TEST_SOURCE(AllTypesThatCanBeAwakedInTests, (const Unity::Type*))
    {
        dynamic_array<const Unity::Type*> classes(kMemTempAlloc);
        TypeOf<Object>()->FindAllDerivedClasses(classes, Unity::Type::kOnlyNonAbstract);

        for (int i = 0; i < classes.size(); ++i)
        {
            const Unity::Type* type = classes[i];

            // Ignore game manager derived
            if (type->IsDerivedFrom(WeakTypeOf<GameManager>()))
                continue;

            // AudioMixer requires AudioManager to be installed.
            if (type->IsDerivedFrom(WeakTypeOf<AudioMixer>()))
                continue;

            // MonoManager and MonoScript require the Mono library to be loaded.
            if (type == WeakTypeOf<MonoManager>() || type == WeakTypeOf<MonoScript>())
                continue;

            // Substance requires an active build target
            if (type == WeakTypeOf<ProceduralTexture>() || type == WeakTypeOf<ProceduralMaterial>())
                continue;

            // AnimationClip and AnimatorOverrideController have scripting-side awake code
            if (type->IsDerivedFrom(WeakTypeOf<AnimationClip>()) || type == WeakTypeOf<AnimatorOverrideController>())
                continue;

            // Can't awake Texture3D or MovieTexture without putting actual content into them
            if (type == WeakTypeOf<Texture3D>() || type == WeakTypeOf<MovieTexture>())
                continue;

            // Awaking Font requires the default font be available from built-in resources
            if (type == WeakTypeOf<Font>())
                continue;

            // NetworkView requires that the NetworkManager is ready
            if (type == WeakTypeOf<NetworkView>())
                continue;

            // GUITexture creates extra materials that fail the leak test
            if (type == WeakTypeOf<GUITexture>())
                continue;

#if UNITY_METRO
            // Windows Store apps use debug PhysX library
            // Gu::HeightField::loadFromDesc: desc.isValid() failed!
            // (Filename: C:/buildslave/physx/build/Source/GeomUtils/src/hf/GuHeightField.cpp Line: 353)
            if (type == WeakTypeOf<TerrainData>())
                continue;
#endif

#if ENABLE_HOLOLENS_MODULE
            // WorldAnchor::LockAtCurrentPosition_Internal() is accessing GameObject which is not created in this case
            if (type == WeakTypeOf<WorldAnchor>())
                continue;
#endif

            PARAMETRIC_TEST_CASE(type);
        }
    }

    PARAMETRIC_TEST_FIXTURE(CreateObjectsOnNonMainThreadFixture, Class_CanBeCreatedOnNonMainThread_ThenAwakedOnMainThread, (const Unity::Type * type), AllTypesThatCanBeAwakedInTests)
    {
        objectType = type;

        Thread creatorThread;
        creatorThread.Run(&CreateObjectsOnNonMainThreadFixture::CreateObjectThread, (CreateObjectsOnNonMainThreadFixture*)this);
        creatorThread.WaitForExit();

        Object::RegisterInstanceID(createdObject);
        createdObject->AwakeFromLoad(kDidLoadThreaded);
    }

#endif

    PARAMETRIC_TEST_SOURCE(AllTypesThatCanBeSerializedAfterReset, (const Unity::Type*))
    {
        dynamic_array<const Unity::Type*> classes(kMemTempAlloc);
        TypeOf<Object>()->FindAllDerivedClasses(classes, Unity::Type::kOnlyNonAbstract);

        for (int i = 0; i < classes.size(); ++i)
        {
            const Unity::Type* type = classes[i];

            // Ignore game manager derived
            if (type->IsDerivedFrom(WeakTypeOf<GameManager>()))
                continue;

            // AudioMixer requires AudioManager to be installed.
            if (type->IsDerivedFrom(WeakTypeOf<AudioMixer>()))
                continue;

#if !UNITY_EDITOR
            // Cannot serialize MonoBehaviour with no script set outside of the editor
            if (type == WeakTypeOf<MonoBehaviour>())
                continue;
#endif

            PARAMETRIC_TEST_CASE(type);
        }
    }

    PARAMETRIC_TEST(Class_AfterCreateAndReset_RoundTripsWithConsistentData, (const Unity::Type * type), AllTypesThatCanBeSerializedAfterReset)
    {
        dynamic_array<UInt8> before(kMemTempAlloc);
        dynamic_array<UInt8> after(kMemTempAlloc);

        Object* obj = Object::Produce(type, InstanceID_None, kMemBaseObject, kCreateObjectDefault);
        obj->Reset();

        // Serialize it once
        WriteObjectToVector(*obj, before);

        // Read it back
        ReadObjectFromVector(*obj, before);

        // Serialize it again for comparison
        WriteObjectToVector(*obj, after);

        CHECK_EQUAL(before.size(), after.size());
        CHECK(before == after);

        DestroySingleObject(obj);
    }


    struct CreateGameObjectAndTransformFixture
    {
        CreateGameObjectAndTransformFixture()
        {
            gameObject = Object::Produce(WeakTypeOf<GameObject>());
            gameObject->Reset();
            transform = Object::Produce(WeakTypeOf<Transform>());
            transform->Reset();
        }

        ~CreateGameObjectAndTransformFixture()
        {
            DestroySingleObject(transform);
            DestroySingleObject(gameObject);
        }

        static bool ContainsInstance(const dynamic_array<InstanceID>& instancesToSearch, const InstanceID& instanceToFind)
        {
            return std::find(instancesToSearch.begin(), instancesToSearch.end(), instanceToFind) != instancesToSearch.end();
        }

        PPtr<Object> transform;
        PPtr<Object> gameObject;
    };

    TEST_FIXTURE(CreateGameObjectAndTransformFixture, FindInstanceIDsOfTypes_va_arg_Type_ptr_FindsAllInstances)
    {
        dynamic_array<InstanceID> foundInstances;
        Object::FindInstanceIDsOfTypes(foundInstances,
            WeakTypeOf<Transform>(),
            WeakTypeOf<GameObject>(),
            NULL
            );

        CHECK(ContainsInstance(foundInstances, transform->GetInstanceID()));
        CHECK(ContainsInstance(foundInstances, gameObject->GetInstanceID()));
    }
}

#endif // ENABLE_UNIT_TESTS
