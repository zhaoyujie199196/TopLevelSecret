#include "UnityPrefix.h"
#include "Configuration/UnityConfigure.h"

#if ENABLE_UNIT_TESTS

#include "Runtime/Testing/Testing.h"
#include "BaseObject.h"
#include "EditorExtension.h"
#include "Editor/Src/Prefabs/Prefab.h"

UNIT_TEST_SUITE(PPtrTests)
{
    //-------------------------------------------------------------------------
    // These test verify that PPtrs are not dereferenced when assigned to an other PPtr
    // this is simply by using dummy instance ids which would result in NULL if they
    // were dereferenced

    TEST(Constructor_FromMatchingType_PreservesInstanceID)
    {
        PPtr<Object> o1(InstanceID_Make(1));
        PPtr<Object> o2(o1);
        CHECK_EQUAL(InstanceID_Make(1), o2.GetInstanceID());
    }

    TEST(Constructor_FromDerivedType_PreservesInstanceID)
    {
        PPtr<EditorExtension> o1(InstanceID_Make(1));
        PPtr<Object> o2(o1);
        CHECK_EQUAL(InstanceID_Make(1), o2.GetInstanceID());
    }

    TEST(Assignment_FromMatchingType_PreservesInstanceID)
    {
        PPtr<Object> o1(InstanceID_Make(1));
        PPtr<Object> o2;
        o2 = o1;
        CHECK_EQUAL(InstanceID_Make(1), o2.GetInstanceID());
    }

    TEST(Assignment_FromDerivedType_PreservesInstanceID)
    {
        PPtr<EditorExtension> o1(InstanceID_Make(1));
        PPtr<Object> o2;
        o2 = o1;
        CHECK_EQUAL(InstanceID_Make(1), o2.GetInstanceID());
    }

    // While these would be nice tests to have, they are not needed because they cause compile errors, so the tests won't even compile
    // These should fail anyway because down casting is not safe. Down casting should only be done using dynamic casting

    /*  TEST (ConstructByDownCastingPPtr)
        {
            PPtr<Object> o1(1);
            PPtr<EditorExtension> o2(o1);
            // the instance ID should be 0, because this casting should not be allowed
            CHECK_EQUAL(0, o2.GetInstanceID());
        }

        TEST (ConstructFromUnrelatedPPtr)
        {
            PPtr<Prefab> o1(1);
            PPtr<EditorExtension> o2(o1);
            // the instance ID should be 0, because this casting should not be allowed
            CHECK_EQUAL(0, o2.GetInstanceID());
        }


        TEST (AssignByDownCastingShouldFail)
        {
            PPtr<Object> o1(1);
            PPtr<EditorExtension> o2;
            o2 = o1;
            // the instance ID should be 0, because this casting should not be allowed
            CHECK_EQUAL(0, o2.GetInstanceID());
        }

        TEST (AssignFromUnrelatedTypeShouldFail)
        {
            PPtr<Prefab> o1(1);
            PPtr<EditorExtension> o2;
            o2 = o1;
            // the instance ID should be 0, because this casting should not be allowed
            CHECK_EQUAL(0, o2.GetInstanceID());
        }
    */
    TEST(Equality_MatchingTypesMatchingInstanceID_Matches)
    {
        PPtr<Object> o1(InstanceID_Make(1));
        PPtr<Object> o2(InstanceID_Make(1));
        CHECK(o1 == o2);
    }

    TEST(Equality_DerivedTypesSameInstanceID_Matches)
    {
        PPtr<Object> o1(InstanceID_Make(1));
        PPtr<EditorExtension> o2(InstanceID_Make(1));
        CHECK(o1 == o2);
    }
}
#endif
