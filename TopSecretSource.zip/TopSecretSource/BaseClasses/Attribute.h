#pragma once

#include "Variant.h"
#include "Runtime/Core/CoreMacros.h"

// Support registering attributes on classes that can be queried later on the Type.
// An example on how to define an attribute class that can later be put on a type:
//
// class IconAttribute
// {
// public:
//    IconAttribute(const char* color) : color(color) {}
//    const char* color;
// }
//
// Now as an example we put this Attribute on the Collider component but adding the
// following to the top of the Collider.cpp file:
//
// // Add Icon attribute to Collider
// REGISTER_TYPE_ATTRIBUTES(Collider, (Icon, ("yellow")));
//
// // Multiple attributes are supported!
// REGISTER_TYPE_ATTRIBUTES(Collider,
//      (Icon, ("yellow")),
//      (Bounds, (Rect(1, 2, 3, 4)))
// );
//
// Now this attribute will be associated with the Collider type on startup and
// you can query it on the Type:
//
// IconAttribute* a = TypeOf<Collider>()->FindAttribute<IconAttribute>();
// if (a != NULL)
//     myColor = a.color;
//
#define REGISTER_TYPE_ATTRIBUTES(TYPE_, ATTRIBUTES_) \
    DETAIL__ATTRIBUTES_BEGIN(TYPE_, ATTRIBUTES_) \
    DETAIL__ATTRIBUTES_SELECTS(ATTRIBUTES_) \
    DETAIL__ATTRIBUTES_END \
    class MISSING_SEMICOLON_AFTER_REGISTER_TYPE_ATTRIBUTES_MACRO

// Implementation details below:

#define DETAIL__ATTRIBUTES_COUNT_ADD(...)                   PP_VARG_SELECT_OVERLOAD(DETAIL__ATTRIBUTES_COUNT_ADD_, (__VA_ARGS__))
#define DETAIL__ATTRIBUTES_COUNT_ADD_2(TYPE_, ARGS_)        1 + PP_RECURSE(DETAIL__ATTRIBUTES_COUNT_ADD)
#define DETAIL__ATTRIBUTES_COUNT_ADD_3(TYPE_, ARGS_, _)     0
#define DETAIL__ATTRIBUTES_COUNT_ADD_RECURSE()              DETAIL__ATTRIBUTES_COUNT_ADD
#define DETAIL__ATTRIBUTES_COUNT(ATTRIBUTES_)               PP_EVAL(DETAIL__ATTRIBUTES_COUNT_ADD ATTRIBUTES_ (_,_,_))

#define DETAIL__ATTRIBUTES_TOTALSIZE_ADD(...)                   PP_VARG_SELECT_OVERLOAD(DETAIL__ATTRIBUTES_TOTALSIZE_ADD_, (__VA_ARGS__))
#define DETAIL__ATTRIBUTES_TOTALSIZE_ADD_2(TYPE_, ARGS_)        sizeof(TYPE_##Attribute) + PP_RECURSE(DETAIL__ATTRIBUTES_TOTALSIZE_ADD)
#define DETAIL__ATTRIBUTES_TOTALSIZE_ADD_3(TYPE_, ARGS_, _)     0
#define DETAIL__ATTRIBUTES_TOTALSIZE_ADD_RECURSE()              DETAIL__ATTRIBUTES_TOTALSIZE_ADD
#define DETAIL__ATTRIBUTES_TOTALSIZE(ATTRIBUTES_)               PP_EVAL(DETAIL__ATTRIBUTES_TOTALSIZE_ADD ATTRIBUTES_ (_,_,_))

#define DETAIL__ATTRIBUTES_SELECT(...)                  PP_VARG_SELECT_OVERLOAD(DETAIL__ATTRIBUTES_SELECT_, (__VA_ARGS__))
#define DETAIL__ATTRIBUTES_SELECT_2(TYPE_, ARGS_)       DETAIL__ATTRIBUTE(TYPE_, ARGS_) PP_RECURSE(DETAIL__ATTRIBUTES_SELECT)
#define DETAIL__ATTRIBUTES_SELECT_3(TYPE_, ARGS_, _)
#define DETAIL__ATTRIBUTES_SELECT_RECURSE()             DETAIL__ATTRIBUTES_SELECT
#define DETAIL__ATTRIBUTES_SELECTS(ATTRIBUTES_)         PP_EVAL(DETAIL__ATTRIBUTES_SELECT ATTRIBUTES_ (_,_,_))

#define DETAIL__ATTRIBUTES_BEGIN(TYPE_, ATTRIBUTES_) \
    template<> \
    /* This is a specialization on TYPE_ of the RegisterAttributes<T> template in ObjectDefines. */ \
    /* It is called by the RegisterClass initialization function */ \
    const ConstVariantRef* RegisterAttributes<TYPE_>(size_t& attributeCountOut) \
    { \
        const size_t totalsize = DETAIL__ATTRIBUTES_TOTALSIZE(ATTRIBUTES_); \
        const size_t count = DETAIL__ATTRIBUTES_COUNT(ATTRIBUTES_); \
        attributeCountOut = count; \
        static UInt8 data[totalsize]; \
        static ConstVariantRef attributes[count]; \
        UInt8* dataDst = data; \
        ConstVariantRef* attributeDst = attributes;

#define DETAIL__ATTRIBUTE(TYPE_, ARGS_) \
        *attributeDst++ = ConstVariantRef(*new (dataDst)TYPE_##Attribute ARGS_); \
        dataDst += sizeof(TYPE_##Attribute);

#define DETAIL__ATTRIBUTES_END \
        return attributes; \
    }
