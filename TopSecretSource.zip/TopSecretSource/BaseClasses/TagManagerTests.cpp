#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "TagManager.h"
#include "Runtime/Testing/Testing.h"

UNIT_TEST_SUITE(TagManagerTests)
{
    class TagsFixture
    {
    public:
        TagsFixture()
        {
            GetTagManager().RegisterDefaultTagsAndLayerMasks();
        }
    };

    TEST(StringToTag_TagToString_WithEmptyString_IsIdentityOperation)
    {
        CHECK_EQUAL("", GetTagManager().TagToString(GetTagManager().StringToTag("")));
    }

    TEST_FIXTURE(TagsFixture, StringToTag_TagToString_WithDefaultTag_IsIdentityOperation)
    {
        CHECK_EQUAL("Untagged", GetTagManager().TagToString(GetTagManager().StringToTag("Untagged")));
    }

    TEST(LayerToString_WithOutOfBoundsLayer_ReturnsEmptyString)
    {
        EXPECT(Error, "Layer index out of bounds");
        CHECK_EQUAL("", GetTagManager().LayerToString(64));
    }

    TEST_FIXTURE(TagsFixture, GetTags_DefaultCall_ReturnsDefaultTagList)
    {
        UnsignedToString tags = GetTagManager().GetTags();
        CHECK_EQUAL(7, tags.size());
        CHECK_EQUAL("Untagged", tags[0]);
        CHECK_EQUAL("Respawn", tags[1]);
        CHECK_EQUAL("Finish", tags[2]);
        CHECK_EQUAL("EditorOnly", tags[3]);
        CHECK_EQUAL("MainCamera", tags[5]);
        CHECK_EQUAL("Player", tags[6]);
        CHECK_EQUAL("GameController", tags[7]);
    }

#if UNITY_EDITOR

    TEST_FIXTURE(TagsFixture, GetTags_WithUserCreatedTag_ReturnsDefaultAndUserCreatedTag)
    {
        int tagsCount = GetTagManager().GetTags().size();
        GetTagManager().StringToTagAddIfUnavailable("myTag");
        UnsignedToString tags = GetTagManager().GetTags();
        CHECK_EQUAL(tagsCount + 1, tags.size());
    }

    TEST_FIXTURE(TagsFixture, StringToTagAddIfUnavailable_WithDefaultTag_DoesNotChangeAnything)
    {
        int tagsCount = GetTagManager().GetTags().size();
        GetTagManager().StringToTagAddIfUnavailable("Player");
        UnsignedToString tags = GetTagManager().GetTags();
        CHECK_EQUAL(tagsCount, tags.size());
    }

    TEST_FIXTURE(TagsFixture, StringToTagAddIfUnavailable_WithDuplicatedTag_RegistersTagOnlyOnce)
    {
        int tagsCount = GetTagManager().GetTags().size();
        GetTagManager().StringToTagAddIfUnavailable("myTag");
        GetTagManager().StringToTagAddIfUnavailable("myTag");
        UnsignedToString tags = GetTagManager().GetTags();
        CHECK_EQUAL(tagsCount + 1, tags.size());
    }

    TEST_FIXTURE(TagsFixture, RegisterLayer_WithExistingLayer_GeneratesError)
    {
        EXPECT(Log, "Default GameObject BitMask: Default already registered");
        GetTagManager().RegisterLayer(10, "Default");
    }

    TEST_FIXTURE(TagsFixture, RegisterLayer_WithExistingTag_GeneratesError)
    {
        EXPECT(Log, "Default GameObject BitMask for name: MyLayer already registered");
        GetTagManager().RegisterLayer(1, "MyLayer");
    }

    TEST_FIXTURE(TagsFixture, IsSortingLayerDefault_WithInexistentLayer_ReturnsFalse)
    {
        CHECK_EQUAL(1, GetTagManager().GetSortingLayerCount());    // only default layer exists
        CHECK(GetTagManager().IsSortingLayerDefault(0));
        CHECK(!GetTagManager().IsSortingLayerDefault(1));
    }

    TEST_FIXTURE(TagsFixture, IsSortingLayerDefault_WithUserCreatedLayer_ReturnsFalse)
    {
        GetTagManager().AddSortingLayer();
        CHECK_EQUAL(2, GetTagManager().GetSortingLayerCount());
        CHECK(GetTagManager().IsSortingLayerDefault(0));
        CHECK(!GetTagManager().IsSortingLayerDefault(1));
    }

    TEST(GetSortingLayerLocked_ByDefault_ReturnsFalse)
    {
        CHECK(!GetTagManager().GetSortingLayerLocked(0));
    }

    TEST(GetSortingLayerLocked_ForLockedLayer_ReturnsTrue)
    {
        GetTagManager().SetSortingLayerLocked(0, true);
        CHECK(GetTagManager().GetSortingLayerLocked(0));
    }

    TEST_FIXTURE(TagsFixture, GetSortingLayerLocked_ForUnlockedLayer_ReturnsFalse)
    {
        GetTagManager().AddSortingLayer();
        GetTagManager().SetSortingLayerLocked(1, false);
        CHECK(!GetTagManager().GetSortingLayerLocked(1));
    }

    TEST_FIXTURE(TagsFixture, GetSortingLayerLocked_ForInexistentLayers_ReturnsFalse)
    {
        CHECK(!GetTagManager().GetSortingLayerLocked(-1));
        CHECK(!GetTagManager().GetSortingLayerLocked(10));
    }

    TEST_FIXTURE(TagsFixture, SortingLayer_UserID_Works)
    {
        CHECK_EQUAL(1, GetTagManager().GetSortingLayerCount());    // only default layer initially

        // add 3 layers
        GetTagManager().AddSortingLayer();
        GetTagManager().AddSortingLayer();
        GetTagManager().AddSortingLayer();
        GetTagManager().SetSortingLayerName(1, "A");
        GetTagManager().SetSortingLayerName(2, "B");
        GetTagManager().SetSortingLayerName(3, "C");

        // now the order is: Default, A, B, C
        int idDefault = GetTagManager().GetSortingLayerUniqueID(0);
        int idA = GetTagManager().GetSortingLayerUniqueID(1);
        int idB = GetTagManager().GetSortingLayerUniqueID(2);
        int idC = GetTagManager().GetSortingLayerUniqueID(3);

        // find their values by user IDs
        CHECK_EQUAL(1, GetTagManager().GetSortingLayerValueFromUniqueID(idA));
        CHECK_EQUAL(2, GetTagManager().GetSortingLayerValueFromUniqueID(idB));
        CHECK_EQUAL(3, GetTagManager().GetSortingLayerValueFromUniqueID(idC));

        // find their values by names
        CHECK_EQUAL(1, GetTagManager().GetSortingLayerValueFromName("A"));
        CHECK_EQUAL(2, GetTagManager().GetSortingLayerValueFromName("B"));
        CHECK_EQUAL(3, GetTagManager().GetSortingLayerValueFromName("C"));

        // check all the above for default layer
        CHECK_EQUAL(0, GetTagManager().GetSortingLayerValueFromName(""));
        CHECK_EQUAL(0, GetTagManager().GetSortingLayerValueFromName("Default"));
        CHECK_EQUAL(0, GetTagManager().GetSortingLayerValueFromUniqueID(0));

        // reorder layers into: B, A, Default, C
        GetTagManager().SwapSortingLayers(0, 2);

        // check user IDs
        CHECK_EQUAL(-1, GetTagManager().GetSortingLayerValueFromUniqueID(idA));
        CHECK_EQUAL(-2, GetTagManager().GetSortingLayerValueFromUniqueID(idB));
        CHECK_EQUAL(0, GetTagManager().GetSortingLayerValueFromUniqueID(idDefault));
        CHECK_EQUAL(1, GetTagManager().GetSortingLayerValueFromUniqueID(idC));

        // find values by names
        CHECK_EQUAL(-2, GetTagManager().GetSortingLayerValueFromName("B"));
        CHECK_EQUAL(-1, GetTagManager().GetSortingLayerValueFromName("A"));
        CHECK_EQUAL(1, GetTagManager().GetSortingLayerValueFromName("C"));

        // check all the above for default layer
        CHECK_EQUAL(0, GetTagManager().GetSortingLayerValueFromName(""));
        CHECK_EQUAL(0, GetTagManager().GetSortingLayerValueFromName("Default"));
        CHECK_EQUAL(0, GetTagManager().GetSortingLayerValueFromUniqueID(0));
    }

    TEST_FIXTURE(TagsFixture, StringToTagAddIfUnavailable_WithNewTag_SetsUpMappings)
    {
        UInt32 tag = GetTagManager().StringToTagAddIfUnavailable("foobar");

        CHECK_EQUAL(tag, GetTagManager().StringToTag("foobar"));
        CHECK_EQUAL("foobar", GetTagManager().TagToString(tag));
    }

#endif // UNITY_EDITOR
}

#endif // ENABLE_UNIT_TESTS
