#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "AttributeContainer.h"
#include "Attribute.h"
#include "Runtime/Testing/Testing.h"


UNIT_TEST_SUITE(Attribute)
{
    // Need to define this here even though it is in ObjectDefines.h since the suite
    // is in its own namespace an the attribute registration below does a partial
    // specialization that wouldn't work without this.
    template<typename T>
    const ConstVariantRef* RegisterAttributes(size_t& attributeCountOut)
    {
        attributeCountOut = 0;
        return NULL;
    }

    struct NonExistingAttribute {};
    class TestDummyAttribute {};

    class TestIntArgumentAttribute
    {
    public:
        TestIntArgumentAttribute(int value) : value(value)
        {
        }

        int value;
    };

    class AClassWithTestIntArgumentAttribute {};

    const int kTestIntArgument1 = 99;

    REGISTER_TYPE_ATTRIBUTES(AClassWithTestIntArgumentAttribute,
        (TestIntArgument, (kTestIntArgument1))
        );

    class TestTypeArgumentAttribute
    {
    public:
        TestTypeArgumentAttribute(const Unity::Type* value) : value(value)
        {
        }

        const Unity::Type* value;
    };

    class AClassWithTestTypeArgumentAttributeAndTestIntArgumentAttribute {};

    REGISTER_TYPE_ATTRIBUTES(AClassWithTestTypeArgumentAttributeAndTestIntArgumentAttribute,
        (TestIntArgument, (kTestIntArgument1))
            (TestTypeArgument, (TypeOf<int>()))
        );

    TEST(AClass_WithATestIntArgumentAttribute_WillRegisterTheAttribute)
    {
        size_t attributeCount = 0;
        const ConstVariantRef* attributes = RegisterAttributes<AClassWithTestIntArgumentAttribute>(attributeCount);
        CHECK_EQUAL(1, attributeCount);

        const ConstVariantRef& v = attributes[0];
        CHECK_EQUAL(TypeOf<TestIntArgumentAttribute>(), v.GetType());
        CHECK_EQUAL(kTestIntArgument1, v.Get<TestIntArgumentAttribute>().value);
    }

    TEST(IntType_FindAttributeUsingTestDummyAttribute_ReturnsNoAttribute)
    {
        // CHECK_NULL doesn't support null check on const * so we need to const_cast
        SuiteAttributekUnitTestCategory::TestDummyAttribute* a = const_cast<SuiteAttributekUnitTestCategory::TestDummyAttribute*>(TypeOf<int>()->FindAttribute<SuiteAttributekUnitTestCategory::TestDummyAttribute>());
        CHECK_NULL(a);
    }

    TEST(AClassWithTestIntArgumentAttribute_FindAttributeUsingTestIntArgumentAttribute_ReturnsExpectedAttribute)
    {
        Unity::Type testType;
        RTTI& rtti = reinterpret_cast<RTTI&>(testType);
        rtti.attributes = RegisterAttributes<AClassWithTestIntArgumentAttribute>(rtti.attributeCount);

        const TestIntArgumentAttribute * a = testType.FindAttribute<TestIntArgumentAttribute>();
        // CHECK_NOT_NULL doesn't support null check on const * so we need to const_cast
        CHECK_NOT_NULL(const_cast<TestIntArgumentAttribute*>(a));
        CHECK_EQUAL(kTestIntArgument1, a->value);
    }

    TEST(AClassWithTestIntArgumentAttribute_GetAttributesOnType_ReturnsExpectedAttribute)
    {
        Unity::Type testType;
        RTTI& rtti = reinterpret_cast<RTTI&>(testType);
        rtti.attributes = RegisterAttributes<AClassWithTestIntArgumentAttribute>(rtti.attributeCount);

        Unity::TypeAttributes attributes;
        testType.GetAttributes(attributes);
        CHECK(attributes.begin() != attributes.end());
        CHECK(++(attributes.begin()) == attributes.end());
        const TestIntArgumentAttribute * a = testType.FindAttribute<TestIntArgumentAttribute>();
        ConstVariantRef avar(*a);
        Unity::TypeAttributes::const_iterator i = std::find(attributes.begin(), attributes.end(), avar);
        CHECK(i != attributes.end());
    }

    TEST(AClassWithTestTypeArgumentAttributeAndTestIntArgumentAttribute_GetAttributesOnType_ReturnsExpectedAttribute)
    {
        Unity::Type testType;
        RTTI& rtti = reinterpret_cast<RTTI&>(testType);
        rtti.attributes = RegisterAttributes<AClassWithTestTypeArgumentAttributeAndTestIntArgumentAttribute>(rtti.attributeCount);

        Unity::TypeAttributes attributes;
        testType.GetAttributes(attributes);
        CHECK(attributes.begin() != attributes.end());
        CHECK(++(attributes.begin()) != attributes.end());
        CHECK(++(++(attributes.begin())) == attributes.end());

        const TestIntArgumentAttribute * a1 = testType.FindAttribute<TestIntArgumentAttribute>();
        ConstVariantRef a1var(*a1);
        Unity::TypeAttributes::const_iterator i = std::find(attributes.begin(), attributes.end(), a1var);
        CHECK(i != attributes.end());

        const TestTypeArgumentAttribute * a2 = testType.FindAttribute<TestTypeArgumentAttribute>();
        ConstVariantRef a2var(*a2);
        i = std::find(attributes.begin(), attributes.end(), a2var);
        CHECK(i != attributes.end());
    }

    TEST(AClass_WithAnIntArgumentAttributeAndTestTypeArgumentAttribute_WillRegisterBothAttributes)
    {
        size_t attributeCount = 0;
        const ConstVariantRef* attributes = RegisterAttributes<AClassWithTestTypeArgumentAttributeAndTestIntArgumentAttribute>(attributeCount);
        CHECK_EQUAL(2, attributeCount);

        const ConstVariantRef& v1 = attributes[0];
        CHECK_EQUAL(TypeOf<TestIntArgumentAttribute>(), v1.GetType());
        CHECK_EQUAL(kTestIntArgument1, v1.Get<TestIntArgumentAttribute>().value);

        const ConstVariantRef& v2 = attributes[1];
        CHECK_EQUAL(TypeOf<TestTypeArgumentAttribute>(), v2.GetType());
        CHECK_EQUAL(TypeOf<int>(), v2.Get<TestTypeArgumentAttribute>().value);
    }
}

INTEGRATION_TEST_SUITE(Attribute)
{
    TEST(AClassWithNoAttributes_GetAttributesOnType_ReturnsNoAttributes)
    {
        Unity::TypeAttributes attributes;
        TypeOf<int>()->GetAttributes(attributes);
        CHECK(attributes.begin() == attributes.end());
    }

    TEST(AnAttributeNoAssociatedWithAnyType_GetAllAttributes_ReturnsEmtyContainer)
    {
        Unity::AllAttributes<SuiteAttributekUnitTestCategory::NonExistingAttribute> attributes = Unity::Type::GetAllAttributes<SuiteAttributekUnitTestCategory::NonExistingAttribute>();
        CHECK(attributes.begin() == attributes.end());
    }

    TEST(AttributesRegistered_GetAttributeCount_CanBeUsedToIndexAllAttributes)
    {
        UInt32 typeCount = Unity::Type::GetTypeCount();
        for (UInt32 i = 0; i < typeCount; ++i)
        {
            const Unity::Type* t1 = Unity::Type::GetTypeByRuntimeTypeIndex(i);
            size_t count = t1->GetAttributeCount();
            for (size_t j = 0; j < count; ++j)
            {
                CHECK(t1->GetAttribute(j).HasValue());
            }
        }
    }

    TEST(AttributesRegistered_GetAttributes_CanBeIterated)
    {
        UInt32 typeCount = Unity::Type::GetTypeCount();
        for (UInt32 i = 0; i < typeCount; ++i)
        {
            const Unity::Type* t1 = Unity::Type::GetTypeByRuntimeTypeIndex(i);
            Unity::TypeAttributes attributes;
            t1->GetAttributes(attributes);
            for (Unity::TypeAttributes::const_iterator j = attributes.begin(); j != attributes.end(); ++j)
            {
                CHECK_NOT_NULL(const_cast<Unity::Type*>(j.GetType()));
                CHECK(j->HasValue());
            }
        }
    }
}

#endif // ENABLE_UNIT_TESTS
