#ifndef EDITOREXTENSION_H
#define EDITOREXTENSION_H

#include "BaseObject.h"
class TypeTree;
class Prefab;
class EditorExtensionImpl;
struct GarbageCollectorThreadState;

#if UNITY_EDITOR

class EXPORT_COREMODULE EditorExtension : public Object
{
    REGISTER_CLASS_TRAITS(kTypeIsAbstract);
    REGISTER_CLASS(EditorExtension);
    DECLARE_OBJECT_SERIALIZE();
    DECLARE_STRIPPED_OBJECT_SERIALIZE();
public:

    PPtr<EditorExtension> m_PrefabParentObject;
    PPtr<Prefab> m_Prefab;

    PPtr<EditorExtensionImpl>   m_DeprecatedExtensionPtr;


    EditorExtension(MemLabelId label, ObjectCreationMode mode);
    // ~EditorExtension (); declared-by-macro

    friend PPtr<EditorExtensionImpl> GetDeprecatedExtensionPtrIfExists(const Object& o);

    virtual bool IsPrefabParent() const;

    PPtr<Prefab> GetPrefab() const { return m_Prefab; }
    PPtr<EditorExtension> GetPrefabParentObject() const { return m_PrefabParentObject; }

    virtual void AwakeFromLoad(AwakeFromLoadMode mode);

    void MarkDependencies(GarbageCollectorThreadState& gc) const;

    //core::string ExtractDeprecatedNameString ();
};

#else

class EXPORT_COREMODULE EditorExtension : public Object
{
    REGISTER_CLASS_TRAITS(kTypeIsAbstract);
    REGISTER_CLASS(EditorExtension);
public:

    EditorExtension(MemLabelId label, ObjectCreationMode mode) : Super(label, mode) {}
    // virtual ~EditorExtension (); declared-by-macro


    bool IsPrefabParent() const { return false; }

    inline void MarkDependencies(GarbageCollectorThreadState& gc) const {}
};


#endif

#endif
