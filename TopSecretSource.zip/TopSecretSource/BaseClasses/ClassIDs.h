#ifndef CLASSIDS_H_
#define CLASSIDS_H_

#define DefineClassID(x, classID) CLASS_##x = classID,


// Runtime classIDs are kept intentionally small.
enum ClassIDType
{
    DefineClassID(Undefined, -1)
    DefineClassID(Object, 0)
    DefineClassID(GameObject, 1)
    DefineClassID(Component, 2)
    DefineClassID(LevelGameManager, 3)
    DefineClassID(Transform, 4)
    DefineClassID(TimeManager, 5)
    DefineClassID(GlobalGameManager, 6)
    DefineClassID(Behaviour, 8)
    DefineClassID(GameManager, 9)
    DefineClassID(AudioManager, 11)
    DefineClassID(ParticleAnimator, 12)
    DefineClassID(InputManager, 13)
    DefineClassID(EllipsoidParticleEmitter, 15)
    DefineClassID(Pipeline, 17)
    DefineClassID(EditorExtension, 18)
    DefineClassID(Physics2DSettings, 19)
    DefineClassID(Camera, 20)
    DefineClassID(Material, 21)
    DefineClassID(MeshRenderer, 23)
    DefineClassID(Renderer, 25)
    DefineClassID(ParticleRenderer, 26)
    DefineClassID(Texture, 27)
    DefineClassID(Texture2D, 28)
    DefineClassID(OcclusionCullingSettings, 29)
    DefineClassID(GraphicsSettings, 30)
    DefineClassID(MeshFilter, 33)
    DefineClassID(OcclusionPortal, 41)
    DefineClassID(Mesh, 43)
    DefineClassID(Skybox, 45)
    DefineClassID(QualitySettings, 47)
    DefineClassID(Shader, 48)
    DefineClassID(TextAsset, 49)
    DefineClassID(Rigidbody2D, 50)
    DefineClassID(Physics2DManager, 51)
    DefineClassID(Collider2D, 53)
    DefineClassID(Rigidbody, 54)
    DefineClassID(PhysicsManager, 55)
    DefineClassID(Collider, 56)
    DefineClassID(Joint, 57)
    DefineClassID(CircleCollider2D, 58)
    DefineClassID(HingeJoint, 59)
    DefineClassID(PolygonCollider2D, 60)
    DefineClassID(BoxCollider2D, 61)
    DefineClassID(PhysicsMaterial2D, 62)
    DefineClassID(MeshCollider, 64)
    DefineClassID(BoxCollider, 65)
    DefineClassID(CompositeCollider2D, 66)
    DefineClassID(EdgeCollider2D, 68)
    //DefineClassID (PolygonColliderBase2D, 69) - Obsolete
    DefineClassID(CapsuleCollider2D, 70)
    DefineClassID(ComputeShader, 72)
    DefineClassID(AnimationClip, 74)
    DefineClassID(ConstantForce, 75)
    DefineClassID(WorldParticleCollider, 76)
    DefineClassID(TagManager, 78)
    DefineClassID(AudioListener, 81)
    DefineClassID(AudioSource, 82)
    DefineClassID(AudioClip, 83)
    DefineClassID(RenderTexture, 84)
    DefineClassID(CustomRenderTexture, 86)
    DefineClassID(MeshParticleEmitter, 87)
    DefineClassID(ParticleEmitter, 88)
    DefineClassID(Cubemap, 89)
    DefineClassID(Avatar, 90)
    DefineClassID(AnimatorController, 91)
    DefineClassID(GUILayer, 92)
    DefineClassID(RuntimeAnimatorController, 93)
    DefineClassID(ScriptMapper, 94)
    DefineClassID(Animator, 95)
    DefineClassID(TrailRenderer, 96)
    DefineClassID(DelayedCallManager, 98)
    DefineClassID(TextMesh, 102)
    DefineClassID(RenderSettings, 104)
    DefineClassID(Light, 108)
    DefineClassID(CGProgram, 109)
    DefineClassID(BaseAnimationTrack, 110)
    DefineClassID(Animation, 111)
    DefineClassID(MonoBehaviour, 114)
    DefineClassID(MonoScript, 115)
    DefineClassID(MonoManager, 116)
    DefineClassID(Texture3D, 117)
    DefineClassID(NewAnimationTrack, 118)
    DefineClassID(Projector, 119)
    DefineClassID(LineRenderer, 120)
    DefineClassID(Flare, 121)
    DefineClassID(Halo, 122)
    DefineClassID(LensFlare, 123)
    DefineClassID(FlareLayer, 124)
    DefineClassID(HaloLayer, 125)
    DefineClassID(NavMeshProjectSettings, 126)
    //DefineClassID (HaloManager, 127) - Obsolete
    DefineClassID(Font, 128)
    DefineClassID(PlayerSettings, 129)
    DefineClassID(NamedObject, 130)
    DefineClassID(GUITexture, 131)
    DefineClassID(GUIText, 132)
    DefineClassID(GUIElement, 133)
    DefineClassID(PhysicMaterial, 134)
    DefineClassID(SphereCollider, 135)
    DefineClassID(CapsuleCollider, 136)
    DefineClassID(SkinnedMeshRenderer, 137)
    DefineClassID(FixedJoint, 138)
    DefineClassID(RaycastCollider, 140)
    DefineClassID(BuildSettings, 141)
    DefineClassID(AssetBundle, 142)
    DefineClassID(CharacterController, 143)
    DefineClassID(CharacterJoint, 144)
    DefineClassID(SpringJoint, 145)
    DefineClassID(WheelCollider, 146)
    DefineClassID(ResourceManager, 147)
    DefineClassID(NetworkView, 148)
    DefineClassID(NetworkManager, 149)
    DefineClassID(PreloadData, 150)
    DefineClassID(MovieTexture, 152)
    DefineClassID(ConfigurableJoint, 153)
    DefineClassID(TerrainCollider, 154)
    DefineClassID(MasterServerInterface, 155)
    DefineClassID(TerrainData, 156)
    DefineClassID(LightmapSettings, 157)
    DefineClassID(WebCamTexture, 158)
    DefineClassID(EditorSettings, 159)
    DefineClassID(InteractiveCloth, 160)
    DefineClassID(ClothRenderer, 161)
    DefineClassID(EditorUserSettings, 162)
    DefineClassID(SkinnedCloth, 163)
    DefineClassID(AudioReverbFilter, 164)
    DefineClassID(AudioHighPassFilter, 165)
    DefineClassID(AudioChorusFilter, 166)
    DefineClassID(AudioReverbZone, 167)
    DefineClassID(AudioEchoFilter, 168)
    DefineClassID(AudioLowPassFilter, 169)
    DefineClassID(AudioDistortionFilter, 170)
    DefineClassID(SparseTexture, 171)
    DefineClassID(AudioBehaviour, 180)
    DefineClassID(AudioFilter, 181)
    DefineClassID(WindZone, 182)
    DefineClassID(Cloth, 183)
    DefineClassID(SubstanceArchive, 184)
    DefineClassID(ProceduralMaterial, 185)
    DefineClassID(ProceduralTexture, 186)
    DefineClassID(Texture2DArray, 187)
    DefineClassID(CubemapArray, 188)
    DefineClassID(OffMeshLink, 191)
    DefineClassID(OcclusionArea, 192)
    DefineClassID(Tree, 193)
    //DefineClassID (NavMeshObsolete, 194) // Obsolete
    DefineClassID(NavMeshAgent, 195)
    DefineClassID(NavMeshSettings, 196)
    DefineClassID(ParticleSystem, 198)
    DefineClassID(ParticleSystemRenderer, 199)
    DefineClassID(ShaderVariantCollection, 200)

    DefineClassID(LODGroup, 205)
    DefineClassID(BlendTree, 206)
    DefineClassID(Motion, 207)
    DefineClassID(NavMeshObstacle, 208)
    DefineClassID(Terrain, 218)

    DefineClassID(SortingGroup, 210)
    DefineClassID(SpriteRenderer, 212)
    DefineClassID(Sprite, 213)
    DefineClassID(CachedSpriteAtlas, 214)

    DefineClassID(ReflectionProbe, 215)
    DefineClassID(ReflectionProbes, 216)

    DefineClassID(LightProbeGroup, 220)
    DefineClassID(AnimatorOverrideController, 221)

    DefineClassID(CanvasRenderer, 222)
    DefineClassID(Canvas, 223)
    DefineClassID(RectTransform, 224)

    DefineClassID(CanvasGroup, 225)

    DefineClassID(BillboardAsset, 226)
    DefineClassID(BillboardRenderer, 227)
    DefineClassID(SpeedTreeWindAsset, 228)


    DefineClassID(AnchoredJoint2D, 229)
    DefineClassID(Joint2D, 230)
    DefineClassID(SpringJoint2D, 231)
    DefineClassID(DistanceJoint2D, 232)
    DefineClassID(HingeJoint2D, 233)
    DefineClassID(SliderJoint2D, 234)
    DefineClassID(WheelJoint2D, 235)

    DefineClassID(ClusterInputManager, 236)

    DefineClassID(BaseVideoTexture, 237)

    DefineClassID(NavMeshData, 238)
    DefineClassID(AudioMixer, 240)

    DefineClassID(AudioMixerController, 241)
    DefineClassID(AudioMixerGroupController, 243)
    DefineClassID(AudioMixerEffectController, 244)
    DefineClassID(AudioMixerSnapshotController, 245)

    DefineClassID(PhysicsUpdateBehaviour2D, 246)
    DefineClassID(ConstantForce2D, 247)
    DefineClassID(Effector2D, 248)
    DefineClassID(AreaEffector2D, 249)
    DefineClassID(PointEffector2D, 250)
    DefineClassID(PlatformEffector2D, 251)
    DefineClassID(SurfaceEffector2D, 252)
    DefineClassID(BuoyancyEffector2D, 253)
    DefineClassID(RelativeJoint2D, 254)
    DefineClassID(FixedJoint2D, 255)
    DefineClassID(FrictionJoint2D, 256)
    DefineClassID(TargetJoint2D, 257)

    DefineClassID(LightProbes, 258)
    DefineClassID(LightProbeProxyVolume, 259)

    DefineClassID(SampleClip, 271)

    DefineClassID(AudioMixerSnapshot, 272)
    DefineClassID(AudioMixerGroup, 273)

    DefineClassID(NScreenBridge, 280)

    DefineClassID(AssetBundleManifest, 290)
    DefineClassID(UnityAdsManager, 292)

    DefineClassID(RuntimeInitializeOnLoadManager, 300)

    DefineClassID(CloudWebServicesManager, 301)
    DefineClassID(UnityAnalyticsManager, 303)
    DefineClassID(CrashReportManager, 304)
    DefineClassID(PerformanceReportingManager, 305)

#if (ENABLE_CLOUD_SERVICES)
    DefineClassID(UnityConnectSettings, 310)
#endif

    DefineClassID(AvatarMask, 319)

    DefineClassID(AudioPlayer, 323)
    //DefineClassID (AudioClipInstance, 320)

    DefineClassID(BatchedSpriteRenderer, 324)
    DefineClassID(SpriteDataProvider, 325)
    DefineClassID(SmartSprite, 326)
    DefineClassID(TextureRawPS4, 327)

#if ENABLE_VIDEO
    DefineClassID(VideoPlayer, 328)
    DefineClassID(VideoClip, 329)
#endif

#if ENABLE_HOLOLENS_MODULE_API
    DefineClassID(WorldAnchor, 362)
#endif

    DefineClassID(OcclusionCullingData, 363)


#if ENABLE_MARSHALLING_TESTS
    DefineClassID(MarshallingTestObject, 900) // This is an object only used for testing the bindings generator marshalling
#endif

    kLargestRuntimeClassID,

    DefineClassID(SmallestEditorClassID, 1000)
    DefineClassID(Prefab, 1001)
    DefineClassID(EditorExtensionImpl, 1002)
    DefineClassID(AssetImporter, 1003)
    DefineClassID(AssetDatabase, 1004)
    DefineClassID(Mesh3DSImporter, 1005)
    DefineClassID(TextureImporter, 1006)
    DefineClassID(ShaderImporter, 1007)
    DefineClassID(ComputeShaderImporter, 1008)
    // DefineClassID (AvatarMask, 1011)         // Class is now a runtime class
    DefineClassID(AudioImporter, 1020)
    DefineClassID(HierarchyState, 1026)
    //  DefineClassID (GUIDSerializer, 1027)    //  - Deprecated.
    DefineClassID(AssetMetaData, 1028)
    DefineClassID(DefaultAsset, 1029)
    DefineClassID(DefaultImporter, 1030)
    DefineClassID(TextScriptImporter, 1031)
    DefineClassID(SceneAsset, 1032)
    // DefineClassID (SceneSet, 1033) // - Deprecated
    DefineClassID(NativeFormatImporter, 1034)
    DefineClassID(MonoImporter, 1035)
    DefineClassID(AssetServerCache, 1037)
    DefineClassID(LibraryAssetImporter, 1038)
    DefineClassID(ModelImporter, 1040)
    DefineClassID(FBXImporter, 1041)
    DefineClassID(TrueTypeFontImporter, 1042)
    DefineClassID(MovieImporter, 1044)
    DefineClassID(EditorBuildSettings, 1045)
    DefineClassID(DDSImporter, 1046) // preserved only to allow loading old data with new IHVImageFormatImporter without reimport
    DefineClassID(InspectorExpandedState, 1048)
    DefineClassID(AnnotationManager, 1049)
    DefineClassID(PluginImporter, 1050)
    DefineClassID(EditorUserBuildSettings, 1051)
    DefineClassID(PVRImporter, 1052) // preserved only to allow loading old data with new IHVImageFormatImporter without reimport
    DefineClassID(ASTCImporter, 1053) // preserved only to allow loading old data with new IHVImageFormatImporter without reimport
    DefineClassID(KTXImporter, 1054) // preserved only to allow loading old data with new IHVImageFormatImporter without reimport
    DefineClassID(IHVImageFormatImporter, 1055)
    DefineClassID(AnimatorStateTransition, 1101)
    DefineClassID(AnimatorState, 1102)
    DefineClassID(HumanTemplate, 1105)
    DefineClassID(AnimatorStateMachine, 1107)
    DefineClassID(PreviewAnimationClip, 1108)
    DefineClassID(AnimatorTransition, 1109)
    DefineClassID(SpeedTreeImporter, 1110)
    DefineClassID(AnimatorTransitionBase, 1111)
    DefineClassID(SubstanceImporter, 1112)
    DefineClassID(LightmapParameters, 1113)
    DefineClassID(LightingDataAsset, 1120)

#if !UNITY_LINUX
    // These aren't supported on Linux
    DefineClassID(GISRaster, 1121)
    DefineClassID(GISRasterImporter, 1122)

    DefineClassID(CadImporter, 1123)

    DefineClassID(SketchUpImporter, 1124)
#endif

    DefineClassID(BuildReport, 1125)
    DefineClassID(PackedAssets, 1126)

#if ENABLE_VIDEO
    DefineClassID(VideoClipImporter, 1127)
#endif

#if ENABLE_UNIT_TESTS
    DefineClassID(ActivationLogComponent, 2000)
#endif

#if ENABLE_UNIT_TESTS_WITH_FAKES
    DefineClassID(TestObjectWithSerializedArray, 2001)
#endif

    kLargestEditorClassID,

    kClassIdOutOfHierarchy = 100000,

    DefineClassID(int, kClassIdOutOfHierarchy)
    DefineClassID(bool, kClassIdOutOfHierarchy + 1)
    DefineClassID(float, kClassIdOutOfHierarchy + 2)
    DefineClassID(MonoObject, kClassIdOutOfHierarchy + 3)
    DefineClassID(Collision, kClassIdOutOfHierarchy + 4)
    DefineClassID(Vector3f, kClassIdOutOfHierarchy + 5)
    DefineClassID(RootMotionData, kClassIdOutOfHierarchy + 6)
    DefineClassID(Collision2D, kClassIdOutOfHierarchy + 7)
    DefineClassID(AudioMixerLiveUpdateFloat, kClassIdOutOfHierarchy + 8)
    DefineClassID(AudioMixerLiveUpdateBool, kClassIdOutOfHierarchy + 9)
    DefineClassID(Polygon2D, kClassIdOutOfHierarchy + 10)
    DefineClassID(SpriteTilingProperty, kClassIdOutOfHierarchy + 11)

#if UNITY_EDITOR
    kLargestAllowedClassID = kLargestEditorClassID
#else
    kLargestAllowedClassID = kLargestRuntimeClassID
#endif
};

//make sure people dont accidentally define classids in other files:
#undef DefineClassID


// in preparation to the new ClassID system being made by simonm ClassID() is made non-compile time constant
inline ClassIDType GetClassIDEnum(ClassIDType x) { return x; }
#define ClassID(x) GetClassIDEnum(CLASS_##x)


#endif
