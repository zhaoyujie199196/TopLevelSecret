#include "UnityPrefix.h"
#include "TypeInfoManager.h"
#include "Runtime/BaseClasses/BaseObject.h"

TypeManager* TypeManager::ms_Instance = NULL;

TypeManager::TypeManager(RTTI::RuntimeTypeArray& runtimeTypeArray)
    : m_MaxClassID(0)
    , m_RuntimeTypes(runtimeTypeArray)
{
    m_StringToTypeInfo.set_empty_key(NULL);
    m_RTTI.set_empty_key(-1);
    m_ReservedTypeIDs.set_empty_key(-1);
    m_DeserializationStubMap.set_empty_key(-1);
    m_RuntimeTypes.Count = 0;
}

TypeManager::~TypeManager()
{
    m_RuntimeTypes.Count = 0;
}

TypeInfo TypeManager::ClassIDToTypeInfo(int classID)
{
    RTTIMap::iterator i = m_RTTI.find(classID);
    if (i == m_RTTI.end())
        return NULL;
    else
        return i->second;
}

TypeInfo TypeManager::ClassNameToTypeInfo(const char* name, bool caseInsensitive)
{
    if (!caseInsensitive)
    {
        StringToTypeInfoMap::const_iterator i = m_StringToTypeInfo.find(name);
        return i != m_StringToTypeInfo.end() ? i->second : NULL;
    }
    else
    {
        for (StringToTypeInfoMap::const_iterator i = m_StringToTypeInfo.begin(); i != m_StringToTypeInfo.end(); i++)
        {
            if (StrIEquals(name, i->first))
                return i->second;
        }
        return NULL;
    }
}

void TypeManager::FindAllDerivedClasses(TypeInfo baseType, dynamic_array<TypeInfo>& derivedTypes, bool onlyNonAbstract)
{
    const UInt32 typeIndexBegin = baseType->derivedFromInfo.typeIndex;
    const UInt32 typeIndexEnd = baseType->derivedFromInfo.typeIndex + baseType->derivedFromInfo.descendantCount;

    derivedTypes.reserve(baseType->derivedFromInfo.descendantCount);
    if (onlyNonAbstract)
    {
        for (UInt32 typeIndex = typeIndexBegin; typeIndex < typeIndexEnd; ++typeIndex)
        {
            TypeInfo typeInfo = m_RuntimeTypes.Types[typeIndex];
            if (!typeInfo->isAbstract)
                derivedTypes.push_back(m_RuntimeTypes.Types[typeIndex]);
        }
    }
    else
    {
        for (UInt32 typeIndex = typeIndexBegin; typeIndex < typeIndexEnd; ++typeIndex)
            derivedTypes.push_back(m_RuntimeTypes.Types[typeIndex]);
    }
}

void TypeManager::FindAllDerivedClasses(ClassIDType classID, dynamic_array<ClassIDType>& derivedClasses, bool onlyNonAbstract)
{
    TypeInfo baseType = ClassIDToTypeInfo(classID);
    if (baseType == NULL)
        return;

    const UInt32 typeIndexBegin = baseType->derivedFromInfo.typeIndex;
    const UInt32 typeIndexEnd = baseType->derivedFromInfo.typeIndex + baseType->derivedFromInfo.descendantCount;

    derivedClasses.reserve(baseType->derivedFromInfo.descendantCount);
    if (onlyNonAbstract)
    {
        for (UInt32 typeIndex = typeIndexBegin; typeIndex < typeIndexEnd; ++typeIndex)
        {
            TypeInfo typeInfo = m_RuntimeTypes.Types[typeIndex];
            if (!typeInfo->isAbstract)
                derivedClasses.push_back(static_cast<ClassIDType>(m_RuntimeTypes.Types[typeIndex]->classID));
        }
    }
    else
    {
        for (UInt32 typeIndex = typeIndexBegin; typeIndex < typeIndexEnd; ++typeIndex)
            derivedClasses.push_back(static_cast<ClassIDType>(m_RuntimeTypes.Types[typeIndex]->classID));
    }
}

void TypeManager::InitializeGlobalInstance()
{
    AssertMsg(ms_Instance == NULL, "Global TypeManager instance is already initialized");
    ms_Instance = UNITY_NEW_AS_ROOT_NO_LABEL(TypeManager(RTTI::ms_runtimeTypes), kMemBaseObject, "Managers", "RTTI");
}

void TypeManager::CleanupGlobalInstance()
{
    AssertMsg(ms_Instance != NULL, "Global TypeManager instance is not initialized");
    UNITY_DELETE(ms_Instance, kMemBaseObject);
}

void TypeManager::InitializeAllTypes()
{
    SET_ALLOC_OWNER(ms_Instance);

    Assert(!m_RTTI.empty());

    InitializeDerivedFromInfo();
}

void TypeManager::CallInitializeTypes()
{
    // Call the IntializeClass function for classes that have it
    // This is done after all classes are registered and the rtti setup
    // so that the rtti system can be used insie InitializeClass()
    for (TypeCallbacks::iterator i = m_TypeCallbacks.begin(); i != m_TypeCallbacks.end(); ++i)
    {
        if (i->second.initType)
            i->second.initType();
    }
}

void TypeManager::CallPostInitializeTypes()
{
    // Call the PostIntializeClass function for classes that have it
    // This is done after all classes are registered and the rtti setup
    // so that the rtti system can be used inside PostInitializeClass()
    for (TypeCallbacks::iterator i = m_TypeCallbacks.begin(); i != m_TypeCallbacks.end(); ++i)
    {
        if (i->second.postInitType)
            i->second.postInitType();
    }
}

void TypeManager::CleanupAllTypes()
{
    for (TypeCallbacks::iterator i = m_TypeCallbacks.begin(); i != m_TypeCallbacks.end(); ++i)
    {
        if (i->second.cleanupType)
            i->second.cleanupType();
    }
}

void TypeManager::RegisterReservedPersistentTypeID(PersistentTypeID id, const char* name)
{
    FatalErrorOnClassIDConflict(id, name);
    m_ReservedTypeIDs[id] = name;
}

static TypeRegistrationDesc InitializeTypeRegistrationDesc(PersistentTypeID typeID, RTTI* type, const char* name, const char* nameSpace, int size, bool isStripped)
{
    TypeRegistrationDesc desc = { RTTI_DEFAULT_INITIALIZER_LIST, type, NULL, NULL, NULL };
    desc.init.classID = typeID;
    desc.init.className = name;
    desc.init.classNamespace = nameSpace;
    desc.init.isStripped = isStripped;
    desc.init.size = size;
    return desc;
}

void TypeManager::RegisterStrippedTypeInfo(PersistentTypeID typeID, RTTI* type, const char* name, const char* nameSpace)
{
    RegisterType(InitializeTypeRegistrationDesc(typeID, type, name, nameSpace, -1, true));
}

void TypeManager::RegisterNonClassType(PersistentTypeID typeID, RTTI* type, const char* name, const char* nameSpace)
{
    RegisterType(InitializeTypeRegistrationDesc(typeID, type, name, nameSpace, 0, false));
}

void TypeManager::RegisterType(const TypeRegistrationDesc& desc)
{
    Assert(desc.init.classID != ClassID(Undefined));
    FatalErrorOnClassIDConflict(desc.init.classID, desc.init.className);

    // Copy info from desc to rtti
    RTTI& destinationRTTI = *desc.type;
    destinationRTTI = desc.init;

    m_RTTI[destinationRTTI.classID] = &destinationRTTI;

    m_MaxClassID = std::max(m_MaxClassID, static_cast<UInt32>(destinationRTTI.classID));

    // Store callbacks
    if (desc.initCallback || desc.postInitCallback || desc.cleanupCallback)
    {
        TypeCallbackStruct& callback = m_TypeCallbacks[destinationRTTI.classID];
        callback.initType = desc.initCallback;
        callback.postInitType = desc.postInitCallback;
        callback.cleanupType = desc.cleanupCallback;
    }

    // Store String -> ClassID
    if (!destinationRTTI.isStripped)
    {
        Assert(m_StringToTypeInfo.find(destinationRTTI.className) == m_StringToTypeInfo.end());
        m_StringToTypeInfo[destinationRTTI.className] = &destinationRTTI;
    }
}

void TypeManager::MarkDeprecated(int classID)
{
    RTTIMap::iterator i = m_RTTI.find(classID);
    Assert(i != m_RTTI.end());
    i->second->isDeprecated = true;
}

TypeInfo TypeManager::GetDeserializationStubForPersistentTypeID(PersistentTypeID typeID)
{
    {
        ReadWriteLock::AutoReadLock readLock(m_DeserializationStubMapLock);
        const DeserializationStubMap& map = m_DeserializationStubMap;
        DeserializationStubMap::const_iterator it = map.find(typeID);
        if (it != map.end())
            return it->second;
    }
    {
        ReadWriteLock::AutoWriteLock writeLock(m_DeserializationStubMapLock);
        RTTI* newStub = UNITY_NEW(RTTI, kMemBaseObject);
        RTTI defaultRTTI = RTTI_DEFAULT_INITIALIZER_LIST;
        *newStub = defaultRTTI;
        newStub->classID = typeID;
        std::pair<DeserializationStubMap::iterator, bool> inserted = m_DeserializationStubMap.insert(PersistentTypeIDRTTIPair(typeID, newStub));
        if (!inserted.second)
            UNITY_DELETE(newStub, kMemBaseObject);

        return inserted.first->second;
    }
}

void TypeManager::FatalErrorOnClassIDConflict(PersistentTypeID typeID, const char* name)
{
    RTTIMap::const_iterator iRTTI = m_RTTI.find(typeID);
    if (iRTTI != m_RTTI.end())
        FatalErrorString(Format("ClassID %d (%s) conflicts with that of another class (%s). Please resolve the conflict.", typeID, name, iRTTI->second->className));

    ReservedTypeIDMap::const_iterator iReserved = m_ReservedTypeIDs.find(typeID);
    if (iReserved != m_ReservedTypeIDs.end())
        FatalErrorString(Format("ClassID %d (%s) conflicts with that of another class (%s). Please resolve the conflict.", typeID, name, iReserved->second));
}

class TypeManager::Builder
{
    struct Node
    {
        RTTI* pRTTI;
        SInt32 firstChild;
        SInt32 nextSibling;
    };

public:
    Builder()
        : nodes(kMemTempAlloc)
    {
    }

    UInt32 Build(const RTTIMap& rttiMap)
    {
        LookupOrAdd(&TypeInfoContainer<Object>::rtti); // Adding Object first ensures it gets type index 0
        for (RTTIMap::const_iterator iRTTI = rttiMap.begin(); iRTTI != rttiMap.end(); ++iRTTI)
        {
            if (!iRTTI->second->isStripped)
                LookupOrAdd(iRTTI->second);
        }

        for (RTTIMap::const_iterator iRTTI = rttiMap.begin(); iRTTI != rttiMap.end(); ++iRTTI)
        {
            DebugAssertMsg(iRTTI->second->isStripped || iRTTI->second->derivedFromInfo.typeIndex != RTTI::DefaultTypeIndex, "(Internal type system error) Type was not added");
            iRTTI->second->derivedFromInfo.typeIndex = RTTI::DefaultTypeIndex;
        }

        const UInt32 nodeCount = nodes.size();
        UInt32 nextTypeIndex = 0;
        for (UInt32 iNode = 0; iNode < nodeCount; ++iNode)
        {
            const Node& node = nodes[iNode];
            if (node.pRTTI->isStripped)
                continue;

            if (node.pRTTI->derivedFromInfo.typeIndex == RTTI::DefaultTypeIndex)
                nextTypeIndex += TraverseDepthFirst(node, nextTypeIndex);
        }

        return nextTypeIndex;
    }

    UInt32 TraverseDepthFirst(const Node& node, UInt32 typeIndex)
    {
        UInt32 descendantCount = 1;
        for (SInt32 child = node.firstChild; child != -1; child = nodes[child].nextSibling)
            descendantCount += TraverseDepthFirst(nodes[child], typeIndex + descendantCount);

        RTTI::DerivedFromInfo& derivedFromInfo = node.pRTTI->derivedFromInfo;
        DebugAssertMsg((derivedFromInfo.typeIndex == RTTI::DefaultTypeIndex) &&
            (derivedFromInfo.descendantCount == RTTI::DefaultDescendentCount), "Type is already initialized?");
        derivedFromInfo.typeIndex = typeIndex;
        derivedFromInfo.descendantCount = descendantCount;
        return descendantCount;
    }

private:

    SInt32 Add(RTTI* pRTTI)
    {
        Assert(pRTTI->derivedFromInfo.typeIndex == RTTI::DefaultTypeIndex);

        RTTI* pBaseRTTI = const_cast<RTTI*>(pRTTI->base);
        SInt32 baseID = pBaseRTTI ? LookupOrAdd(pBaseRTTI) : -1;

        SInt32 newNodeID = nodes.size();
        Node& newNode = nodes.push_back();
        newNode.pRTTI = pRTTI;
        newNode.firstChild = -1;

        pRTTI->derivedFromInfo.typeIndex = newNodeID;

        if (pBaseRTTI == NULL)
        {
            newNode.nextSibling = -1;
        }
        else
        {
            SInt32* prevNodeNext = &nodes[baseID].firstChild;
            while ((*prevNodeNext != -1) && (strcmp(nodes[*prevNodeNext].pRTTI->className, pRTTI->className) < 0))
            {
                prevNodeNext = &nodes[*prevNodeNext].nextSibling;
            }
            newNode.nextSibling = *prevNodeNext;
            *prevNodeNext = newNodeID;
        }

        return newNodeID;
    }

    SInt32 LookupOrAdd(RTTI* pRTTI)
    {
        SInt32 newNodeId = pRTTI->derivedFromInfo.typeIndex;
        if (newNodeId == RTTI::DefaultTypeIndex)
            newNodeId = Add(pRTTI);
        return newNodeId;
    }

    dynamic_array<Node> nodes;
};


void TypeManager::InitializeDerivedFromInfo()
{
    Builder builder;
    m_RuntimeTypes.Count = builder.Build(m_RTTI);
    AssertMsg(m_RuntimeTypes.Count < m_RuntimeTypes.MAX_RUNTIME_TYPES, "Too many runtime types! Need to bump the MAX_RUNTIME_TYPES");

    RTTI::DerivedFromInfo dummy;
    dummy.typeIndex = RTTI::DefaultTypeIndex;
    dummy.descendantCount = RTTI::DefaultDescendentCount;

    for (RTTIMap::iterator i1 = m_RTTI.begin(); i1 != m_RTTI.end(); ++i1)
    {
        if (i1->second->isStripped)
            continue;

        RTTI::DerivedFromInfo& rtti_info = i1->second->derivedFromInfo;
        m_RuntimeTypes.Types[rtti_info.typeIndex] = i1->second;
    }
}
