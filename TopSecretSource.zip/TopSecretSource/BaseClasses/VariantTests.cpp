#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "TypeInfo.h"
#include "Runtime/Testing/Testing.h"

UNIT_TEST_SUITE(VariantRefTests)
{
    TEST(VariantRef_WithDefaultConstruction_HasNoValue)
    {
        VariantRef v;
        CHECK(!v.HasValue());
    }

    TEST(VariantRef_WithIntConstruction_HasCorrectType)
    {
        int i = 99;
        VariantRef v(i);
        CHECK_EQUAL(TypeOf<int>(), v.GetType());
    }

    TEST(VariantRef_WithIntConstruction_HasValue)
    {
        int i = 99;
        VariantRef v(i);
        CHECK(v.HasValue());
    }

#if ENABLE_ASSERTIONS
    TEST(VariantRef_WithIntConstruction_AssertIfGettingWrongType)
    {
        int i = 99;
        VariantRef v(i);
        EXPECT(Assert, "Assertion failed on expression: 'm_Type == TypeOf<T>()'");
        v.Get<float>();
    }
#endif

#if ENABLE_ASSERTIONS
    TEST(VariantRef_WithDefaultConstruction_AssertIfGettingWithNoValue)
    {
        VariantRef v;
        EXPECT(Assert, "Assertion failed on expression: 'm_Type == TypeOf<T>()'");
        EXPECT(Assert, "Assertion failed on expression: 'm_Data != NULL'");
        v.Get<int>();
    }
#endif

    TEST(VariantRef_WithIntConstruction_HasCorrectValue)
    {
        int i = 99;
        VariantRef v(i);
        int& intRef = v.Get<int>();
        CHECK_EQUAL(99, intRef);
    }
}

UNIT_TEST_SUITE(ConstVariantRefTests)
{
    TEST(ConstVariantRef_WithDefaultConstruction_HasNoValue)
    {
        ConstVariantRef v;
        CHECK(!v.HasValue());
    }

    TEST(ConstVariantRef_WithIntConstruction_HasCorrectType)
    {
        int i = 99;
        ConstVariantRef v(i);
        CHECK_EQUAL(TypeOf<int>(), v.GetType());
    }

    TEST(ConstVariantRef_WithIntConstruction_HasValue)
    {
        int i = 99;
        ConstVariantRef v(i);
        CHECK(v.HasValue());
    }

#if ENABLE_ASSERTIONS
    TEST(ConstVariantRef_WithIntConstruction_AssertIfGettingWrongType)
    {
        int i = 99;
        ConstVariantRef v(i);
        EXPECT(Assert, "Assertion failed on expression: 'm_Type == TypeOf<T>()'");
        v.Get<float>();
    }
#endif

#if ENABLE_ASSERTIONS
    TEST(ConstVariantRef_WithDefaultConstruction_AssertIfGettingWithNoValue)
    {
        ConstVariantRef v;
        EXPECT(Assert, "Assertion failed on expression: 'm_Type == TypeOf<T>()'");
        EXPECT(Assert, "Assertion failed on expression: 'm_Data != NULL'");
        v.Get<int>();
    }
#endif

    TEST(ConstVariantRef_WithIntConstruction_HasCorrectValue)
    {
        int i = 99;
        ConstVariantRef v(i);
        const int& constIntRef = v.Get<int>();
        CHECK_EQUAL(99, constIntRef);
    }
}

#endif // ENABLE_UNIT_TESTS
