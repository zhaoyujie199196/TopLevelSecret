#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "Runtime/Testing/Testing.h"
#include "Runtime/BaseClasses/GameObject.h"
#include "Runtime/BaseClasses/MessageData.h"
#include "Runtime/BaseClasses/MessageHandler.h"
#include "Runtime/BaseClasses/TypeInfoManager.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Interfaces/IPhysics.h"
#include "Runtime/PreloadManager/LoadSceneOperation.h"

UNIT_TEST_SUITE(MessageHandlerTests)
{
    struct Fixture
    {
        Fixture() : m_Manager(m_Storage)
        {
            m_Manager.RegisterType(InitTypeRegistrationDesc(static_cast<PersistentTypeID>(0), &m_BaseObjectRTTI, NULL, "Class0"));
            m_Manager.RegisterType(InitTypeRegistrationDesc(static_cast<PersistentTypeID>(42), &m_Class1RTTI, &m_BaseObjectRTTI, "Class1"));
            m_Manager.RegisterType(InitTypeRegistrationDesc(static_cast<PersistentTypeID>(47), &m_Class2RTTI, &m_BaseObjectRTTI, "Class2"));
            m_Manager.InitializeAllTypes();
            m_BaseObjectType = reinterpret_cast<const Unity::Type*>(&m_BaseObjectRTTI);
            m_Class1Type = reinterpret_cast<const Unity::Type*>(&m_Class1RTTI);
            m_Class1TypeIndex = m_Class1Type->GetRuntimeTypeIndex();
            m_Class2TypeIndex = reinterpret_cast<const Unity::Type*>(&m_Class2RTTI)->GetRuntimeTypeIndex();
            m_Handler.Initialize(&m_Manager, m_BaseObjectType);
        }

        ~Fixture()
        {
            m_Manager.CleanupAllTypes();
        }

        RTTI::RuntimeTypeArray m_Storage;
        TypeManager m_Manager;
        MessageHandler m_Handler;

        // These Unity::Type fields are simply warpping to the associated private fields
        // in the bottom of the struct.
        const Unity::Type* m_BaseObjectType;
        const Unity::Type* m_Class1Type;
        RuntimeTypeIndex m_Class1TypeIndex;
        RuntimeTypeIndex m_Class2TypeIndex;

    private:
        TypeRegistrationDesc InitTypeRegistrationDesc(PersistentTypeID id, RTTI* type, RTTI* base, const char* name)
        {
            TypeRegistrationDesc desc;
            memset(&desc, 0, sizeof(TypeRegistrationDesc));
            desc.init.base = base;
            desc.init.className = name;
            desc.init.classNamespace = "";
            desc.init.classID = id;
            desc.init.size = 10;
            desc.init.derivedFromInfo.typeIndex = RTTI::DefaultTypeIndex;
            desc.init.derivedFromInfo.descendantCount = RTTI::DefaultDescendentCount;

            desc.type = type;
            return desc;
        }

        ::RTTI m_BaseObjectRTTI;
        ::RTTI m_Class1RTTI;
        ::RTTI m_Class2RTTI;
    };

    class TestReceiverClass
    {
    public:
        virtual void Handle(int messageID, MessageData& data) { Assert(0); }
        virtual bool CanHandle(int messageID, MessageData& data) { Assert(0); return false; }
    };

    static void ForwardToClassCallback(void* receiver, int messageID, MessageData& data)
    {
        TestReceiverClass* c = reinterpret_cast<TestReceiverClass*>(receiver);
        c->Handle(messageID, data);
    }

    static bool ForwardToClassCanCallback(void* receiver, int messageID, MessageData& data)
    {
        TestReceiverClass* c = reinterpret_cast<TestReceiverClass*>(receiver);
        return c->CanHandle(messageID, data);
    }

    TEST_FIXTURE(Fixture, HasMessageCallback_WhenRegisterMessagesCallbackCalled_ReturnsTrue)
    {
        m_Handler.RegisterMessageCallback(m_Class1Type, kTransformChanged, ForwardToClassCallback, NULL);
        m_Handler.ResolveCallbacks();

        CHECK(m_Handler.HasMessageCallback(m_Class1TypeIndex, kTransformChanged));
        CHECK(!m_Handler.HasMessageCallback(m_Class1TypeIndex, kStayTrigger));
    }

    TEST_FIXTURE(Fixture, HasMessageCallback_WhenRegisterMessagesCallbackCalled_ReturnsFalseIfTypeIsNotReceiver)
    {
        m_Handler.RegisterMessageCallback(m_Class1Type, kTransformChanged, ForwardToClassCallback, NULL);
        m_Handler.ResolveCallbacks();

        CHECK(!m_Handler.HasMessageCallback(m_Class2TypeIndex, kTransformChanged));
        CHECK(!m_Handler.HasMessageCallback(m_Class2TypeIndex, kStayTrigger));
    }

    TEST_FIXTURE(Fixture, HasMessageCallback_WhenRegisterAllMessagesCallbackCalled_ReturnsTrueForSendToScriptMessages)
    {
        m_Handler.RegisterAllMessagesCallback(m_Class1Type, ForwardToClassCallback, ForwardToClassCanCallback);
        m_Handler.ResolveCallbacks();

        CHECK(m_Handler.HasMessageCallback(m_Class1TypeIndex, kStayTrigger));   // Has kSendToScript
    }

    TEST_FIXTURE(Fixture, HasMessageCallback_WhenRegisterAllMessagesCallbackCalled_ReturnsFalseForDontSendToScriptMessages)
    {
        m_Handler.RegisterAllMessagesCallback(m_Class1Type, ForwardToClassCallback, ForwardToClassCanCallback);
        m_Handler.ResolveCallbacks();

        CHECK(!m_Handler.HasMessageCallback(m_Class1TypeIndex, kLayerChanged)); // Has kDontSendToScript
    }

    TEST_FIXTURE(Fixture, HasMessageCallback_WhenRegisterAllMessagesOnOtherTypeCallbackCalled_ReturnsFalseForSendToScriptMessagesForType)
    {
        m_Handler.RegisterAllMessagesCallback(m_Class1Type, ForwardToClassCallback, ForwardToClassCanCallback);
        m_Handler.ResolveCallbacks();

        CHECK(!m_Handler.HasMessageCallback(m_Class2TypeIndex, kStayTrigger));   // Has kSendToScript
        CHECK(!m_Handler.HasMessageCallback(m_Class2TypeIndex, kLayerChanged));  // Has kDontSendToScript
    }

    TEST_FIXTURE(Fixture, WillHandleMessage_WhenMessageRegisteredForClass_ReturnsTrue)
    {
        m_Handler.RegisterMessageCallback(m_Class1Type, kTransformChanged, ForwardToClassCallback, NULL);
        m_Handler.ResolveCallbacks();

        // Ok to pass NULL since first param is only used for messages registered with RegisterAllMessagesCallback
        CHECK(m_Handler.WillHandleMessage(NULL, m_Class1TypeIndex, kTransformChanged));
    }

    // Unity players doesn't assert so the EXPECT will fail in that case
#if ENABLE_ASSERTIONS
    TEST_FIXTURE(Fixture, WillHandleMessage_WhenMessageNotRegisteredForClass_FailsAssertion)
    {
        m_Handler.RegisterMessageCallback(m_Class1Type, kTransformChanged, ForwardToClassCallback, NULL);
        m_Handler.ResolveCallbacks();

        EXPECT(Assert, "Assertion failed on expression: 'HasMessageCallback(typeIndex, messageIdentifier)'");
        m_Handler.WillHandleMessage(NULL, m_Class1TypeIndex, kStayTrigger);
    }
#endif

    // Unity players doesn't assert so the EXPECT will fail in that case
#if ENABLE_ASSERTIONS
    TEST_FIXTURE(Fixture, RegisteredAllCallback_WillHandleMessage_ReturnsTrue)
    {
        class X : public TestReceiverClass
        {
        public:
            virtual bool CanHandle(int messageID, MessageData& data)
            {
                return messageID == kExitTrigger.messageID;
            }
        };

        m_Handler.RegisterAllMessagesCallback(m_Class1Type, ForwardToClassCallback, ForwardToClassCanCallback);
        m_Handler.ResolveCallbacks();

        X x;

        CHECK(m_Handler.WillHandleMessage(&x, m_Class1TypeIndex, kExitTrigger));   // Has kSendToScript
        CHECK(!m_Handler.WillHandleMessage(&x, m_Class1TypeIndex, kStayTrigger));  // Has kSendToScript

        EXPECT(Assert, "Assertion failed on expression: 'HasMessageCallback(typeIndex, messageIdentifier)'");
        m_Handler.WillHandleMessage(&x, m_Class1TypeIndex, kLayerChanged); // Has kDontSendToScript
    }
#endif

    TEST_FIXTURE(Fixture, RegisteredCallback_HandleMessage_PerformsACallback)
    {
        class X : public TestReceiverClass
        {
        public:
            X() : value(0) {}
            virtual void Handle(int messageID, MessageData& data)
            {
                value = data.GetData<int>();
            }

            int value;
        };

        m_Handler.RegisterMessageCallback(m_Class1Type, kLevelWasLoaded, ForwardToClassCallback, TypeOf<int>());
        m_Handler.ResolveCallbacks();

        X x;

        CHECK_EQUAL(0, x.value);
        int data = 99;
        MessageData msg(data);
        m_Handler.HandleMessage(&x, m_Class1TypeIndex, kLevelWasLoaded, msg);
        CHECK_EQUAL(99, x.value);
    }

    TEST_FIXTURE(Fixture, RegisteredAllCallback_HandleAllMessage_PerformsACallback)
    {
        class X : public TestReceiverClass
        {
        public:
            X() : value(0) {}
            virtual void Handle(int messageID, MessageData& data)
            {
                value = data.GetData<int>();
            }

            virtual bool CanHandle(int messageID, MessageData& data)
            {
                return messageID == kLevelWasLoaded.messageID;
            }

            int value;
        };

        m_Handler.RegisterAllMessagesCallback(m_Class1Type, ForwardToClassCallback, ForwardToClassCanCallback);
        m_Handler.ResolveCallbacks();

        X x;

        CHECK_EQUAL(0, x.value);
        int data = 98;
        MessageData msg(data);
        m_Handler.HandleMessage(&x, m_Class1TypeIndex, kLevelWasLoaded, msg);
        CHECK_EQUAL(98, x.value);
    }
}

#endif
