#pragma once

#include "TypeInfo.h"
#include "ClassIDs.h"
#include "Runtime/BaseClasses/Variant.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Utilities/HashStringFunctions.h"
#include "Runtime/Threads/ReadWriteLock.h"
#include "External/google/sparsehash/dense_hash_map.h"

class dynamic_bitset;

class TypeManager
{
public:
    TypeManager(RTTI::RuntimeTypeArray& runtimeTypes);
    ~TypeManager();

    // ---------------------------------------------------------------------------
    // PUBLIC API

    static inline TypeManager& Get()
    {
        Assert(ms_Instance != NULL);
        return *ms_Instance;
    }

    static void InitializeGlobalInstance();
    static void CleanupGlobalInstance();

    void InitializeAllTypes();
    void CallInitializeTypes();
    void CallPostInitializeTypes();
    void CleanupAllTypes();

    void RegisterReservedPersistentTypeID(PersistentTypeID id, const char* name);
    void RegisterType(const TypeRegistrationDesc& desc);

    // Convenience methods that wraps RegisterType(...)
    void RegisterStrippedTypeInfo(PersistentTypeID typeID, RTTI* type, const char* name, const char* nameSpace);
    void RegisterNonClassType(PersistentTypeID typeID, RTTI* destinationRTTI, const char* name, const char* nameSpace);

    // ------------------------------------------------------------------------
    // DEPRECATED API

    // NOTE : Some of these functions will still exist after the cleanup but they are only used internally
    // and for testing and we will get rid of the TypeInfo define

    TYPEINFO_DEPRECATED("Use Unity::Type::TypeCount() instead")
    UInt32 TypeCount() const { return m_RuntimeTypes.Count; }

    TYPEINFO_DEPRECATED("Use Unity::Type::GetTypeByRuntimeTypeIndex instead")
    inline TypeInfo TypeIndexToTypeInfo(UInt32 typeIndex)
    {
        DebugAssert(typeIndex < m_RuntimeTypes.Count);
        return m_RuntimeTypes.Types[typeIndex];
    }

    TYPEINFO_DEPRECATED("Use Unity::Type::GetTypeByPersistentTypeID instead")
    TypeInfo ClassIDToTypeInfo(int classID);

    TYPEINFO_DEPRECATED("Use Unity::Type::GetTypeByName instead")
    TypeInfo ClassNameToTypeInfo(const char* name, bool caseInsensitive = false);

    TYPEINFO_DEPRECATED("Use Unity::Type::FindAllDerivedClasses instead")
    void FindAllDerivedClasses(TypeInfo baseType, dynamic_array<TypeInfo>& derivedTypes, bool onlyNonAbstract);

    TYPEINFO_DEPRECATED("Use Unity::Type::FindAllDerivedClasses instead")
    void FindAllDerivedClasses(ClassIDType classID, dynamic_array<ClassIDType>& derivedClasses, bool onlyNonAbstract);

    TYPEINFO_DEPRECATED("Replaced by type flags on REGISTER_CLASS")
    void MarkDeprecated(int classID);

    TYPEINFO_DEPRECATED("Internal API")
    TypeInfo GetDeserializationStubForPersistentTypeID(PersistentTypeID typeID);

private:
    class Builder;

    struct TypeCallbackStruct
    {
        TypeCallback* initType;
        TypeCallback* postInitType;
        TypeCallback* cleanupType;

        TypeCallbackStruct()
        {
            initType = postInitType = cleanupType = NULL;
        }
    };

    struct HashFunctorPersistentTypeID
    {
        size_t operator()(PersistentTypeID data) const
        {
            return ComputeIntHash(data);
        }
    };

    struct ConstCharPtrHashFunctor
    {
        size_t operator()(const char* str) const
        {
            return ComputeShortStringHash32(str);
        }
    };

    struct ConstCharPtrEqualTo
    {
        bool operator()(const char* a, const char* b) const
        {
            return a == b || (a != NULL && b != NULL && strcmp(a, b) == 0);
        }
    };

    typedef std::map<PersistentTypeID, TypeCallbackStruct> TypeCallbacks;

    typedef std::pair<const char* const, TypeInfo> ConstCharPtrTypeInfoPair;
    typedef dense_hash_map<const char*, TypeInfo, ConstCharPtrHashFunctor, ConstCharPtrEqualTo, STL_ALLOCATOR(kMemPermanent, ConstCharPtrTypeInfoPair)> StringToTypeInfoMap;

    typedef std::pair<const PersistentTypeID, RTTI*> PersistentTypeIDRTTIPair;
    typedef dense_hash_map<PersistentTypeID, RTTI*, HashFunctorPersistentTypeID, std::equal_to<PersistentTypeID>, STL_ALLOCATOR(kMemPermanent, PersistentTypeIDRTTIPair)> RTTIMap;

    typedef std::pair<const PersistentTypeID, const char*> PersistentTypeIDConstCharPtrPair;
    typedef dense_hash_map<PersistentTypeID, const char*, HashFunctorPersistentTypeID, std::equal_to<PersistentTypeID>, STL_ALLOCATOR(kMemPermanent, PersistentTypeIDConstCharPtrPair)> ReservedTypeIDMap;

    typedef dense_hash_map<PersistentTypeID, RTTI*, HashFunctorPersistentTypeID, std::equal_to<PersistentTypeID>, STL_ALLOCATOR(kMemPermanent, PersistentTypeIDRTTIPair)> DeserializationStubMap;


    void FatalErrorOnClassIDConflict(PersistentTypeID typeID, const char* name);
    void InitializeDerivedFromInfo();

    static TypeManager* ms_Instance;

    UInt32 m_MaxClassID;
    RTTI::RuntimeTypeArray& m_RuntimeTypes;
    TypeCallbacks m_TypeCallbacks;
    StringToTypeInfoMap m_StringToTypeInfo;
    RTTIMap m_RTTI;
    ReservedTypeIDMap m_ReservedTypeIDs;

    mutable ReadWriteLock m_DeserializationStubMapLock;
    DeserializationStubMap m_DeserializationStubMap;
};

typedef TypeManager TypeInfoManager;
