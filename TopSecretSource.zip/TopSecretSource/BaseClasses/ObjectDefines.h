#ifndef OBJECTDEFINES_H
#define OBJECTDEFINES_H

#include "Runtime/Allocator/BaseAllocator.h"
#include "Configuration/UnityConfigure.h"
#include "Runtime/Allocator/MemoryMacros.h"
#include "Runtime/BaseClasses/ClassIDs.h"
#include "Runtime/BaseClasses/TypeInfo.h"
#include "Runtime/Core/CoreMacros.h"
#include "Runtime/Modules/ExportModules.h"
#include "Runtime/Utilities/RegisterRuntimeInitializeAndCleanup.h"
#include "Runtime/Utilities/TypeUtilities.h"

namespace BaseObjectInternal
{
    template<typename type>
    inline Object* NewObject(MemLabelId label, ObjectCreationMode mode)
    {
        void* p = UNITY_MALLOC(label, sizeof(type));
        AllocationRootWithSalt root = SET_PTR_AS_ROOT(p, sizeof(type), label, "Objects", NULL);
        SET_ALLOC_OWNER(HAS_ROOT_REFERENCE(root) ? p : NULL);
        return new(p)type(CreateMemLabel(label, root), mode);
    }
}
// ----------------------------------------------------------------------------

#define NEW_OBJECT(CLASS_) reinterpret_cast<CLASS_*>(::Object::AllocateAndAssignInstanceID(BaseObjectInternal::NewObject<CLASS_>(kMemBaseObject, kCreateObjectDefault)))
#define NEW_OBJECT_USING_MEMLABEL(CLASS_, MEMLABEL_) reinterpret_cast<CLASS_*>(::Object::AllocateAndAssignInstanceID(BaseObjectInternal::NewObject<CLASS_>(MEMLABEL_, kCreateObjectDefault)))
#define NEW_OBJECT_FROM_THREAD(CLASS_) reinterpret_cast<CLASS_*>(::Object::CalculateCachedTypeIndex(BaseObjectInternal::NewObject<CLASS_>(kMemBaseObject, kCreateObjectFromNonMainThread)))

#define NEW_OBJECT_RESET_AND_AWAKE(CLASS_) ResetAndAwake (NEW_OBJECT (CLASS_))


// ----------------------------------------------------------------------------


#if BUILDING_DYNAMICLIB
// Exporting transfer functions is not needed for WinRT players today
#if UNITY_WIN && !UNITY_WINRT
#define EXPORTDLL __declspec(dllexport)
#elif UNITY_OSX
#define EXPORTDLL __attribute__((visibility("default")))
#else
#define EXPORTDLL
#endif
#else // BUILDING_DYNAMICLIB
#define EXPORTDLL
#endif // BUILDING_DYNAMICLIB


// ----------------------------------------------------------------------------
// DEPRECATED API
#define SUPPORT_DEPRECATED_API
#ifdef SUPPORT_DEPRECATED_API

#if DEBUGMODE && SUPPORT_CPP0X_DECLTYPE
#define REGISTER_CLASS_VALIDATE_TYPE(ns, x) CompileTimeAssert((IsSameType<const ns::x*,decltype(this)>::result), "REGISTER_CLASS: " #ns "::" #x " typename mismatch")
#else
#define REGISTER_CLASS_VALIDATE_TYPE(ns, x)
#endif

// NOTE (ulfj) : Temporary solution until we can properly mark types as editor only (do not call this function)
inline bool IsEditorOnlyClassInternal(ClassIDType classID)
{
    return classID > ClassID(SmallestEditorClassID) ||
        //      classID == ClassID (AudioMixerController) ||
        //      classID == ClassID (AudioMixerGroupController) ||
        classID == ClassID(AudioMixerEffectController) ||
        //      classID == ClassID (AudioMixerSnapshotController) ||
        classID == ClassID(NewAnimationTrack) ||
        classID == ClassID(BaseAnimationTrack) ||
        classID == ClassID(CachedSpriteAtlas) ||
        classID == ClassID(BlendTree) ||
        classID == ClassID(EditorSettings) ||
        classID == ClassID(EditorUserSettings);
}

#define REGISTER_CLASS_SHARED(ns, x, d) \
public: \
    enum { kThisClassID = CLASS_##x, kTempUsingLegacyRegistration = 1 }; \
    static ClassIDType GetClassIDStatic () { return ClassID (x); } \
    static const char* GetClassStringStatic () { return #x; } \
    static const char* GetClassNamespaceStatic() { return #ns; } \
    static bool GetClassEditorOnlyStatic ()     { return IsEditorOnlyClassInternal(ClassID (x)); }\
    static const char* GetPPtrTypeString () { return "PPtr<"#x">"; } \
    typedef ns::x ThisType; \
    typedef d Super; \
protected: \
    ~x () { ThreadedCleanup(); } \
    void ThreadedCleanup(); \
private: \
    virtual TypeInfo GetTypeInfoVirtualInternal() const { REGISTER_CLASS_VALIDATE_TYPE(ns, x); return GetTypeInfo<ns::x>(); } \
public:

#define REGISTER_CLASS_SHARED_NON_ABSTRACT(x)                               \
    static bool IsAbstract ()                   { return false; }\
    static Object* PRODUCE (MemLabelId label, ObjectCreationMode mode)  {   \
        return BaseObjectInternal::NewObject<x>(label, mode);               \
    }

#define REGISTER_CLASS_SHARED_ABSTRACT(x)                                   \
    static bool IsAbstract ()                   { return true; }\
    static Object* PRODUCE(MemLabelId, ObjectCreationMode)      {   \
        AssertString("Can't produce abstract class"); return NULL;      \
    }

#define REGISTER_DERIVED_CLASS_2(x, d) \
    REGISTER_CLASS_SHARED(, x, d) \
    REGISTER_CLASS_SHARED_NON_ABSTRACT(x) \

#define REGISTER_DERIVED_CLASS_3(ns, x, d) \
    REGISTER_CLASS_SHARED(ns, x, d) \
    REGISTER_CLASS_SHARED_NON_ABSTRACT(x) \

// Every non-abstract class that is derived from object has to place this inside the class Declaration
// (REGISTER_DERIVED_CLASS (Foo, Object) or REGISTER_DERIVED_CLASS (Namespace, Foo, Object))
#define REGISTER_DERIVED_CLASS(...) PP_VARG_SELECT_OVERLOAD(REGISTER_DERIVED_CLASS_,(__VA_ARGS__))

#define REGISTER_PUBLIC_BASE_CLASS(x) \
public: \
    static ClassIDType GetClassIDStatic ()      { return ClassID (x); }\
    static const char* GetClassStringStatic ()  { return #x; } \
    static bool GetClassEditorOnlyStatic ()     { return IsEditorOnlyClassInternal(ClassID (x)); }\
    static const char* GetPPtrTypeString ()     { return "PPtr<"#x">"; }\
    static bool IsAbstract ()                   { return false; }

#define REGISTER_DERIVED_ABSTRACT_CLASS_2(x, d) \
    REGISTER_CLASS_SHARED(, x, d) \
    REGISTER_CLASS_SHARED_ABSTRACT(x) \

#define REGISTER_DERIVED_ABSTRACT_CLASS_3(ns, x, d) \
    REGISTER_CLASS_SHARED(ns, x, d) \
    REGISTER_CLASS_SHARED_ABSTRACT(x) \

// Every abstract class that is derived from object has to place this inside the class Declaration
// (REGISTER_DERIVED_ABSTRACT_CLASS (Foo, Object) or REGISTER_DERIVED_ABSTRACT_CLASS (Namespace, Foo, Object))
#define REGISTER_DERIVED_ABSTRACT_CLASS(...) PP_VARG_SELECT_OVERLOAD(REGISTER_DERIVED_ABSTRACT_CLASS_,(__VA_ARGS__))


#if DEBUGMODE

void EXPORT_COREMODULE AddVerifyClassRegistration(int classID);
void EXPORT_COREMODULE CleanupVerifyClassRegistration();

template<class T>
struct VerifyObjectIsRegisteredHelperOld
{
    static void VerifyClassRegistration(void*)
    {
        AddVerifyClassRegistration(T::GetClassIDStatic());
    }

    static RegisterRuntimeInitializeAndCleanup s_Init;
};

#define IMPLEMENT_CLASS_VERIFY_OBJECT_IS_REGISTERED_OLD(TYPE)  \
template<> RegisterRuntimeInitializeAndCleanup VerifyObjectIsRegisteredHelperOld<TYPE>::s_Init(&VerifyObjectIsRegisteredHelperOld<TYPE>::VerifyClassRegistration, NULL, 1); \
class MISSING_SEMICOLON_AFTER_IMPLEMENT_CLASS_VERIFY_OBJECT_IS_REGISTERED

#else

#define IMPLEMENT_CLASS_VERIFY_OBJECT_IS_REGISTERED_OLD(TYPE) \
class MISSING_SEMICOLON_AFTER_IMPLEMENT_CLASS_VERIFY_OBJECT_IS_REGISTERED

#endif

template<typename registeredClass, int classID>
inline void PerformLegacyRegisterClassCompileTimeChecks()
{
    CompileTimeAssert((classID < (int)kLargestAllowedClassID), "IMPLEMENT_CLASS: class id is larger than kLargestAllowedClassID.");
    CompileTimeAssert((registeredClass::kTempUsingLegacyRegistration == 1), "IMPLEMENT_CLASS: class has been registered using new registration macro, but uses legacy implementation macro.");
}

#define IMPLEMENT_CLASS_FULL(x, INIT, POSTINIT, CLEANUP)  \
IMPLEMENT_CLASS_VERIFY_OBJECT_IS_REGISTERED_OLD(x); \
template<> void RegisterClass<x>() \
{ \
    Assert(!x::Super::IsSealedClass ()); \
    PerformLegacyRegisterClassCompileTimeChecks<x, x::kThisClassID>(); \
\
    /* TODO : Get rid of the helper functions defined in REGISTER_CLASS and construct the desc there (and add the final pieces here) */ \
    TypeRegistrationDesc desc; \
\
    desc.init.base = &TypeInfoContainer<x::Super>::rtti; \
    desc.init.factory = x::PRODUCE; \
    desc.init.className = x::GetClassStringStatic(); \
    desc.init.classNamespace = x::GetClassNamespaceStatic(); \
    desc.init.classID = x::GetClassIDStatic(); \
    desc.init.size = sizeof (x); \
    desc.init.derivedFromInfo.typeIndex = RTTI::DefaultTypeIndex; \
    desc.init.derivedFromInfo.descendantCount = RTTI::DefaultDescendentCount; \
    desc.init.isAbstract = x::IsAbstract (); \
    desc.init.isSealed = x::IsSealedClass (); \
    desc.init.isDeprecated = false; \
    desc.init.isEditorOnly = x::GetClassEditorOnlyStatic(); \
    desc.init.isStripped = false; \
    desc.init.attributes = RegisterAttributes<x>(desc.init.attributeCount); \
\
    desc.type = &TypeInfoContainer<x>::rtti; \
\
    desc.initCallback = INIT; \
    desc.postInitCallback = POSTINIT; \
    desc.cleanupCallback = CLEANUP; \
\
    TypeInfoManager::Get().RegisterType(desc); \
}

#define IMPLEMENT_CLASS(x)  IMPLEMENT_CLASS_FULL(x, NULL, NULL, NULL)
#define IMPLEMENT_CLASS_HAS_INIT(x)  IMPLEMENT_CLASS_FULL(x, x::InitializeClass, NULL, x::CleanupClass)
#define IMPLEMENT_CLASS_HAS_POSTINIT(x)  IMPLEMENT_CLASS_FULL(x, x::InitializeClass, x::PostInitializeClass, x::CleanupClass)
#define IMPLEMENT_CLASS_INIT_ONLY(x)  IMPLEMENT_CLASS_FULL(x, x::InitializeClass, NULL, NULL)

#endif

// ----------------------------------------------------------------------------
// NEW API


#if DEBUGMODE && SUPPORT_CPP0X_DECLTYPE

#define REGISTER_VALIDATE_TYPE(TYPE_NAME_) CompileTimeAssert((IsSameType<const TYPE_NAME_*,decltype(this)>::result), "REGISTER_CLASS: " #TYPE_NAME_ " typename mismatch"); \
class MISSING_SEMICOLON_AFTER_REGISTER_VALIDATE_TYPE

#else

#define REGISTER_VALIDATE_TYPE(TYPE_NAME_) \
class MISSING_SEMICOLON_AFTER_REGISTER_VALIDATE_TYPE

#endif


// ----------------------------------------------------------------------------


#if DEBUGMODE

void EXPORT_COREMODULE AddVerifyClassRegistration(int classID);
void EXPORT_COREMODULE CleanupVerifyClassRegistration();

template<int PersistentTypeID>
struct VerifyObjectIsRegisteredHelper
{
    static void VerifyClassRegistration(void*)
    {
        AddVerifyClassRegistration(PersistentTypeID);
    }

    static RegisterRuntimeInitializeAndCleanup s_Init;
};

#define IMPLEMENT_CLASS_VERIFY_OBJECT_IS_REGISTERED(PERSISTENT_TYPE_ID)  \
template<> RegisterRuntimeInitializeAndCleanup VerifyObjectIsRegisteredHelper<PERSISTENT_TYPE_ID>::s_Init(&VerifyObjectIsRegisteredHelper<PERSISTENT_TYPE_ID>::VerifyClassRegistration, NULL, 1); \
class MISSING_SEMICOLON_AFTER_IMPLEMENT_CLASS_VERIFY_OBJECT_IS_REGISTERED

#else

#define IMPLEMENT_CLASS_VERIFY_OBJECT_IS_REGISTERED(PERSISTENT_TYPE_ID) \
class MISSING_SEMICOLON_AFTER_IMPLEMENT_CLASS_VERIFY_OBJECT_IS_REGISTERED

#endif


// ----------------------------------------------------------------------------


// This macro creates a compile-time test with which you can retrieve
// a static method from a class while ignoring any instances in it's parent class.
// It will return NULL when the static method does not exist.
#define CREATE_GET_STATIC_METHOD_FROM_TYPE_HELPER(HELPER_NAME_, METHOD_DECLARATION_, METHOD_NAME_) \
template<class T> struct HELPER_NAME_ \
{ \
private: \
    template<ToPointerType<METHOD_DECLARATION_>::ResultType> struct TestInstance; \
    template<typename Q> static FalseType Test(...); \
    template<typename Q> static TrueType  Test(TestInstance<&Q::METHOD_NAME_>*, ...); \
    template<typename Q> static FalseType Test(typename EnableIf<IsSameType<TestInstance<&Q::METHOD_NAME_>, TestInstance<&Q::Super::METHOD_NAME_> >::result>::type*, void*); \
    enum { value = sizeof(Test<T>(0, 0)) == sizeof(TrueType) }; \
    struct TypeNoCallback { enum MyEnum { METHOD_NAME_ = 0 }; }; \
public: \
    static ToPointerType<METHOD_DECLARATION_>::ResultType GetMethod() { return (ToPointerType<METHOD_DECLARATION_>::ResultType)Conditional<value, T, TypeNoCallback>::type::METHOD_NAME_; } \
}; \
class MISSING_SEMICOLON_AFTER_CREATE_UNIQUE_METHOD_IN_CLASS_TEST


CREATE_GET_STATIC_METHOD_FROM_TYPE_HELPER(GetInitializeClassMethodFromType, void(), InitializeClass);
CREATE_GET_STATIC_METHOD_FROM_TYPE_HELPER(GetPostInitializeClassMethodFromType, void(), PostInitializeClass);
CREATE_GET_STATIC_METHOD_FROM_TYPE_HELPER(GetCleanupClassMethodFromType, void(), CleanupClass);


// ----------------------------------------------------------------------------

// Register (possibly multiple) traits for a class that is registered after this Macro using REGISTER_CLASS.
// Valid values are kTypeNoFlags, kTypeIsAbstract, kTypeIsSealed, kTypeIsEditorOnly, kTypeIsDeprecated
#define REGISTER_CLASS_TRAITS(...) public: struct kTypeFlags { enum { value = UNSIGNED_FLAGS(__VA_ARGS__) }; }; \
public: \
    class MISSING_SEMICOLON_AFTER_REGISTER_CLASS_TRAITS_MACRO


// ----------------------------------------------------------------------------


#define REGISTER_CLASS(TYPE_NAME_) \
public: \
    /* NOTE: do not change the order of these two typedefs */ \
    typedef ThisType Super; \
    typedef TYPE_NAME_ ThisType; \
\
    enum \
    { \
        /* Note: The flag below will be removed after all types are converted to new registration (sander) */ \
        kTempUsingLegacyRegistration = 0, \
    }; \
    /* Note: The methods below will be removed after all types are converted to new registration (sander) */ \
    static const char* GetClassStringStatic () { return TypeOf<TYPE_NAME_>()->GetName(); } \
    static const char* GetPPtrTypeString () { return "PPtr<"#TYPE_NAME_">"; } \
    static bool IsAbstract () { return TypeOf<TYPE_NAME_>()->IsAbstract(); } \
    static bool IsSealedClass () { return TypeOf<TYPE_NAME_>()->IsSealed(); } \
private: \
    virtual TypeInfo GetTypeInfoVirtualInternal() const { REGISTER_VALIDATE_TYPE(TYPE_NAME_); return GetTypeInfo<TYPE_NAME_>(); } \
protected: \
    ~TYPE_NAME_ () { ThreadedCleanup(); } \
    void ThreadedCleanup(); \
public: \
    class MISSING_SEMICOLON_AFTER_REGISTER_CLASS_MACRO


// ----------------------------------------------------------------------------


template<typename registeredClass, UInt32 typeID>
inline void PerformRegisterClassCompileTimeChecks()
{
    CompileTimeAssert(typeID > 0, "IMPLEMENT_REGISTER_CLASS: PersistentTypeID must be higher than 0.");
    CompileTimeAssert(typeID < 0x80000000, "IMPLEMENT_REGISTER_CLASS: PersistentTypeID must be lower than 0x80000000.");
    CompileTimeAssert((registeredClass::Super::kTypeFlags::value & kTypeIsSealed) == 0, "IMPLEMENT_REGISTER_CLASS: Inheriting from a class that has been marked as sealed.");
    CompileTimeAssert((registeredClass::kTempUsingLegacyRegistration == 0), "IMPLEMENT_REGISTER_CLASS: class has been registered using legacy registration macro, but uses new implementation macro.");
}

#define IMPLEMENT_REGISTER_CLASS_2(TYPE_NAME_, PERSISTENT_TYPE_ID) \
    IMPLEMENT_REGISTER_CLASS_3(,TYPE_NAME_, PERSISTENT_TYPE_ID)

#define IMPLEMENT_REGISTER_CLASS_3(NAMESPACE_, TYPE_NAME_, PERSISTENT_TYPE_ID) \
/* If defined get the TypeFlags for our type, otherwise return kTypeNoFlags. Ignores inherited TypeFlags. */ \
enum { k##NAMESPACE_##TYPE_NAME_##TypeFlags = SelectOnTypeEquality<NAMESPACE_::TYPE_NAME_::ThisType::kTypeFlags, NAMESPACE_::TYPE_NAME_::Super::kTypeFlags, kTypeNoFlags, NAMESPACE_::TYPE_NAME_::ThisType::kTypeFlags::value>::result }; \
IMPLEMENT_CLASS_VERIFY_OBJECT_IS_REGISTERED(PERSISTENT_TYPE_ID); \
static TypeRegistrationDesc NAMESPACE_##TYPE_NAME_##_TypeRegistrationDesc = \
{ \
    { /* RTTI */ \
        &TypeInfoContainer<NAMESPACE_::TYPE_NAME_::Super>::rtti, \
        NULL, \
        #TYPE_NAME_, \
        #NAMESPACE_, \
        PERSISTENT_TYPE_ID, \
        sizeof(NAMESPACE_::TYPE_NAME_), \
        { \
            static_cast<RuntimeTypeIndex>(RTTI::DefaultTypeIndex), \
            RTTI::DefaultDescendentCount, \
        }, \
        (k##NAMESPACE_##TYPE_NAME_##TypeFlags & kTypeIsAbstract) != 0, \
        (k##NAMESPACE_##TYPE_NAME_##TypeFlags & kTypeIsSealed) != 0, \
        (k##NAMESPACE_##TYPE_NAME_##TypeFlags & kTypeIsDeprecated) != 0, \
        (k##NAMESPACE_##TYPE_NAME_##TypeFlags & kTypeIsEditorOnly) != 0, \
        false, \
        NULL, \
        0 \
    }, \
    &TypeInfoContainer<NAMESPACE_::TYPE_NAME_>::rtti, \
    NULL, \
    NULL, \
    NULL, \
}; \
template<> void RegisterClass<NAMESPACE_::TYPE_NAME_>() \
{ \
    PerformRegisterClassCompileTimeChecks<NAMESPACE_::TYPE_NAME_, PERSISTENT_TYPE_ID>(); \
    \
    /* These parts of the struct are initialized within this method to make sure the linker removes */ \
    /* these methods when RegisterClass is not called. This is essential for Unity's stripping to work! */ \
    NAMESPACE_##TYPE_NAME_##_TypeRegistrationDesc.init.factory = ProduceHelper<NAMESPACE_::TYPE_NAME_, (k##NAMESPACE_##TYPE_NAME_##TypeFlags & kTypeIsAbstract) != 0 >::Produce; \
    NAMESPACE_##TYPE_NAME_##_TypeRegistrationDesc.initCallback = GetInitializeClassMethodFromType<NAMESPACE_::TYPE_NAME_>::GetMethod(); \
    NAMESPACE_##TYPE_NAME_##_TypeRegistrationDesc.postInitCallback = GetPostInitializeClassMethodFromType<NAMESPACE_::TYPE_NAME_>::GetMethod(); \
    NAMESPACE_##TYPE_NAME_##_TypeRegistrationDesc.cleanupCallback = GetCleanupClassMethodFromType<NAMESPACE_::TYPE_NAME_>::GetMethod(); \
    \
    TypeRegistrationDesc& desc = NAMESPACE_##TYPE_NAME_##_TypeRegistrationDesc ; \
    desc.init.attributes = RegisterAttributes<NAMESPACE_::TYPE_NAME_>(desc.init.attributeCount); \
    TypeInfoManager::Get().RegisterType(desc); \
} \
class MISSING_SEMICOLON_AFTER_IMPLEMENT_REGISTER_CLASS_MACRO


// Implements the registration of a class.
//
// Usage: IMPLEMENT_REGISTER_CLASS(MyNameSpace, MyTypeName, xxxxxxx)
//
// Where 'MyNameSpace' is optional and xxxxxxx is an unique persistent-type-id for this class
//
// To create a valid persistent-type-id use the following perl expression and copy/paste its result:
//      perl -e "printf('0x%08X', int(rand(0x80000000 - 20000)) + 20000)"
//
#define IMPLEMENT_REGISTER_CLASS(...) PP_VARG_SELECT_OVERLOAD(IMPLEMENT_REGISTER_CLASS_,(__VA_ARGS__))


// ----------------------------------------------------------------------------


template<typename T, bool isAbstract>
struct ProduceHelper
{
    static Object* Produce(MemLabelId label, ObjectCreationMode mode) { AssertFormatMsg(false, "Can't produce abstract class %s", TypeOf<T>()->GetName()); return NULL; }
};

template<typename T>
struct ProduceHelper<T, false>
{
    static Object* Produce(MemLabelId label, ObjectCreationMode mode) { return BaseObjectInternal::NewObject<T>(label, mode); }
};


// ----------------------------------------------------------------------------


// Should be placed in every serializable object derived class (DECLARE_OBJECT_SERIALIZE())
#if UNITY_EDITOR
    #define DECLARE_OBJECT_SERIALIZE(...) /* the "..." will be removed in the near future */ \
    public: \
        static const char* GetTypeString () { return TypeOf<ThisType>()->GetName(); } \
        static bool MightContainPPtr () { return true; } \
        static bool AllowTransferOptimization () { return false; } \
        template<class TransferFunction> void Transfer (TransferFunction& transfer); \
        virtual void VirtualRedirectTransfer (GenerateTypeTreeTransfer& transfer); \
        virtual void VirtualRedirectTransfer (SafeBinaryRead& transfer); \
        virtual void VirtualRedirectTransfer (StreamedBinaryWrite<false>& transfer);\
        virtual void VirtualRedirectTransfer (StreamedBinaryWrite<true>& transfer);\
        virtual void VirtualRedirectTransfer (StreamedBinaryRead<false>& transfer); \
        virtual void VirtualRedirectTransfer (StreamedBinaryRead<true>& transfer);  \
        virtual void VirtualRedirectTransfer (RemapPPtrTransfer& transfer); \
        virtual void VirtualRedirectTransfer (YAMLRead& transfer); \
        virtual void VirtualRedirectTransfer (YAMLWrite& transfer); \
        virtual void VirtualRedirectTransfer (JSONRead& transfer); \
        virtual void VirtualRedirectTransfer (JSONWrite& transfer); \
    public: \
        class MISSING_SEMICOLON_AFTER_DECLARE_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

    #define DECLARE_STRIPPED_OBJECT_SERIALIZE(...) /* the "..." will be removed in the near future */ \
    public: \
        void VirtualStrippedRedirectTransfer (GenerateTypeTreeTransfer& transfer); \
        void VirtualStrippedRedirectTransfer (SafeBinaryRead& transfer); \
        void VirtualStrippedRedirectTransfer (StreamedBinaryWrite<true>& transfer); \
        void VirtualStrippedRedirectTransfer (StreamedBinaryWrite<false>& transfer); \
        void VirtualStrippedRedirectTransfer (StreamedBinaryRead<true>& transfer); \
        void VirtualStrippedRedirectTransfer (StreamedBinaryRead<false>& transfer); \
        void VirtualStrippedRedirectTransfer (YAMLRead& transfer); \
        void VirtualStrippedRedirectTransfer (YAMLWrite& transfer); \
        void VirtualStrippedRedirectTransfer (JSONRead& transfer); \
        void VirtualStrippedRedirectTransfer (JSONWrite& transfer); \
    public: \
        class MISSING_SEMICOLON_AFTER_DECLARE_STRIPPED_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

#elif SUPPORT_ENDIAN_SWAP_SERIALIZATION
    #define DECLARE_OBJECT_SERIALIZE(...) /* the "..." will be removed in the near future */ \
    public: \
        static const char* GetTypeString () { return TypeOf<ThisType>()->GetName(); } \
        static bool MightContainPPtr () { return true; } \
        static bool AllowTransferOptimization () { return false; } \
        template<class TransferFunction> void Transfer (TransferFunction& transfer); \
        virtual void VirtualRedirectTransfer (GenerateTypeTreeTransfer& transfer); \
        virtual void VirtualRedirectTransfer (SafeBinaryRead& transfer); \
        virtual void VirtualRedirectTransfer (StreamedBinaryRead<false>& transfer); \
        virtual void VirtualRedirectTransfer (StreamedBinaryRead<true>& transfer);  \
        virtual void VirtualRedirectTransfer (StreamedBinaryWrite<false>& transfer); \
        virtual void VirtualRedirectTransfer (RemapPPtrTransfer& transfer); \
    public: \
        class MISSING_SEMICOLON_AFTER_DECLARE_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

// Only supported in editor
    #define DECLARE_STRIPPED_OBJECT_SERIALIZE(...) /* the "..." will be removed in the near future */ \
    public: \
        class MISSING_SEMICOLON_AFTER_DECLARE_STRIPPED_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

#elif SUPPORT_SERIALIZED_TYPETREES
    #define DECLARE_OBJECT_SERIALIZE(...) /* the "..." will be removed in the near future */ \
    public: \
        static const char* GetTypeString () { return TypeOf<ThisType>()->GetName(); } \
        static bool MightContainPPtr () { return true; } \
        static bool AllowTransferOptimization () { return false; } \
        template<class TransferFunction> void Transfer (TransferFunction& transfer); \
        virtual void VirtualRedirectTransfer (GenerateTypeTreeTransfer& transfer); \
        virtual void VirtualRedirectTransfer (SafeBinaryRead& transfer); \
        virtual void VirtualRedirectTransfer (StreamedBinaryRead<false>& transfer); \
        virtual void VirtualRedirectTransfer (StreamedBinaryWrite<false>& transfer); \
        virtual void VirtualRedirectTransfer (RemapPPtrTransfer& transfer); \
    public: \
        class MISSING_SEMICOLON_AFTER_DECLARE_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

// Only supported in editor
    #define DECLARE_STRIPPED_OBJECT_SERIALIZE(...) /* the "..." will be removed in the near future */ \
    public: \
        class MISSING_SEMICOLON_AFTER_DECLARE_STRIPPED_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

#else
    #define DECLARE_OBJECT_SERIALIZE(...) /* the "..." will be removed in the near future */ \
    public: \
        static const char* GetTypeString () { return TypeOf<ThisType>()->GetName(); } \
        static bool MightContainPPtr () { return true; } \
        static bool AllowTransferOptimization () { return false; } \
        template<class TransferFunction> void Transfer (TransferFunction& transfer); \
        virtual void VirtualRedirectTransfer (GenerateTypeTreeTransfer& transfer); \
        virtual void VirtualRedirectTransfer (StreamedBinaryRead<false>& transfer); \
        virtual void VirtualRedirectTransfer (StreamedBinaryWrite<false>& transfer); \
        virtual void VirtualRedirectTransfer (RemapPPtrTransfer& transfer); \
    public: \
        class MISSING_SEMICOLON_AFTER_DECLARE_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

// Only supported in editor
    #define DECLARE_STRIPPED_OBJECT_SERIALIZE(...) /* the "..." will be removed in the near future */ \
    public: \
        class MISSING_SEMICOLON_AFTER_DECLARE_STRIPPED_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

#endif

// ----------------------------------------------------------------------------


// Has to be placed in the .cpp file of a serializable class (IMPLEMENT_OBJECT_SERIALIZE (Transform))
// you also have to #include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"

#if UNITY_EDITOR // Editor needs to support swapped endian writing, player doesn't.

    #define INSTANTIATE_TEMPLATE_TRANSFER_WITH_DECL(FULL_TYPENAME_, DECL_, FUNCTION_NAME_, FUNCTION_RETURN_TYPE_) \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(GenerateTypeTreeTransfer& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(SafeBinaryRead& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryRead<false>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryRead<true>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryWrite<false>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryWrite<true>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(RemapPPtrTransfer& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(YAMLRead& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(YAMLWrite& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(JSONRead& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(JSONWrite& transfer); \
    class MISSING_SEMICOLON_AFTER_INSTANTIATE_TEMPLATE_TRANSFER; /* semicolon will be removed in the near future */

    #define IMPLEMENT_OBJECT_SERIALIZE_WITH_DECL(PREFIX_, DECL_) \
    DECL_ void PREFIX_ VirtualRedirectTransfer (GenerateTypeTreeTransfer& transfer)     { transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (SafeBinaryRead& transfer)               { SET_ALLOC_OWNER(this); transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryRead<false>& transfer)    { SET_ALLOC_OWNER(this); transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryRead<true>& transfer)     { SET_ALLOC_OWNER(this); transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (RemapPPtrTransfer& transfer)            { transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryWrite<false>& transfer)   { transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryWrite<true>& transfer)    { transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (YAMLRead& transfer)                     { SET_ALLOC_OWNER(this); transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (YAMLWrite& transfer)                    { transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (JSONRead& transfer)                     { SET_ALLOC_OWNER(this); transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (JSONWrite& transfer)                    { transfer.TransferBase (*this); }\
    class MISSING_SEMICOLON_AFTER_IMPLEMENT_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

#elif SUPPORT_ENDIAN_SWAP_SERIALIZATION
    #define INSTANTIATE_TEMPLATE_TRANSFER_WITH_DECL(FULL_TYPENAME_, DECL_, FUNCTION_NAME_, FUNCTION_RETURN_TYPE_) \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(GenerateTypeTreeTransfer& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(SafeBinaryRead& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryRead<false>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryRead<true>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryWrite<false>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(RemapPPtrTransfer& transfer); \
    class MISSING_SEMICOLON_AFTER_INSTANTIATE_TEMPLATE_TRANSFER; /* semicolon will be removed in the near future */


    #define IMPLEMENT_OBJECT_SERIALIZE_WITH_DECL(PREFIX_, DECL_) \
    DECL_ void PREFIX_ VirtualRedirectTransfer (GenerateTypeTreeTransfer& transfer)     { transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (SafeBinaryRead& transfer)               { SET_ALLOC_OWNER(this); transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryRead<false>& transfer)    { SET_ALLOC_OWNER(this); transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryRead<true>& transfer)     { SET_ALLOC_OWNER(this); transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryWrite<false>& transfer)   { transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (RemapPPtrTransfer& transfer)            { transfer.TransferBase (*this); }\
    class MISSING_SEMICOLON_AFTER_IMPLEMENT_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

#elif SUPPORT_SERIALIZED_TYPETREES
    #define INSTANTIATE_TEMPLATE_TRANSFER_WITH_DECL(FULL_TYPENAME_, DECL_, FUNCTION_NAME_, FUNCTION_RETURN_TYPE_) \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(GenerateTypeTreeTransfer& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(SafeBinaryRead& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryRead<false>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryWrite<false>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(RemapPPtrTransfer& transfer); \
    class MISSING_SEMICOLON_AFTER_INSTANTIATE_TEMPLATE_TRANSFER; /* semicolon will be removed in the near future */


    #define IMPLEMENT_OBJECT_SERIALIZE_WITH_DECL(PREFIX_, DECL_) \
    DECL_ void PREFIX_ VirtualRedirectTransfer (GenerateTypeTreeTransfer& transfer)     { transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (SafeBinaryRead& transfer)               { SET_ALLOC_OWNER(this); transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryRead<false>& transfer)    { SET_ALLOC_OWNER(this); transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryWrite<false>& transfer)   { transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (RemapPPtrTransfer& transfer)            { transfer.TransferBase (*this); }\
    class MISSING_SEMICOLON_AFTER_IMPLEMENT_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

#else
    #define INSTANTIATE_TEMPLATE_TRANSFER_WITH_DECL(FULL_TYPENAME_, DECL_, FUNCTION_NAME_, FUNCTION_RETURN_TYPE_) \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(GenerateTypeTreeTransfer& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryRead<false>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryWrite<false>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(RemapPPtrTransfer& transfer); \
    class MISSING_SEMICOLON_AFTER_INSTANTIATE_TEMPLATE_TRANSFER; /* semicolon will be removed in the near future */

    #define IMPLEMENT_OBJECT_SERIALIZE_WITH_DECL(PREFIX_, DECL_) \
    DECL_ void PREFIX_ VirtualRedirectTransfer (GenerateTypeTreeTransfer& transfer)     { transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryRead<false>& transfer)    { SET_ALLOC_OWNER(this); transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryWrite<false>& transfer)   { transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (RemapPPtrTransfer& transfer)            { transfer.TransferBase (*this); }\
    class MISSING_SEMICOLON_AFTER_IMPLEMENT_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

#endif


#define IMPLEMENT_OBJECT_SERIALIZE(TYPE_) IMPLEMENT_OBJECT_SERIALIZE_WITH_DECL(TYPE_::, )

#define INSTANTIATE_TEMPLATE_TRANSFER(FULL_TYPENAME_) INSTANTIATE_TEMPLATE_TRANSFER_WITH_DECL(FULL_TYPENAME_, ,Transfer,void)
#define INSTANTIATE_TEMPLATE_TRANSFER_EXPORTED(FULL_TYPENAME_) INSTANTIATE_TEMPLATE_TRANSFER_WITH_DECL(FULL_TYPENAME_, EXPORTDLL,Transfer,void)
#define INSTANTIATE_TEMPLATE_TRANSFER_FUNCTION(FULL_TYPENAME_, FUNCTION_NAME_) INSTANTIATE_TEMPLATE_TRANSFER_WITH_DECL(FULL_TYPENAME_, ,FUNCTION_NAME_,void)


// ----------------------------------------------------------------------------


// Use this to make a Generic C++ GET/SET function: GET_SET (float, Velocity, m_Velocity)
//  Implements GetVelocity, SetVelocity
#define GET_SET(TYPE_NAME_, PROP_NAME_, VAR_NAME_)    void Set##PROP_NAME_ (const TYPE_NAME_ val) { VAR_NAME_ = val; }  const TYPE_NAME_ Get##PROP_NAME_ () const {return (const TYPE_NAME_)VAR_NAME_; }
#define GET_SET_DIRTY(TYPE_NAME_, PROP_NAME_, VAR_NAME_)  void Set##PROP_NAME_ (const TYPE_NAME_ val) { VAR_NAME_ = val; SetDirty(); }  const TYPE_NAME_ Get##PROP_NAME_ () const {return (const TYPE_NAME_)VAR_NAME_; }
#define GET_SET_DIRTY_REF(TYPE_NAME_, PROP_NAME_, VAR_NAME_)  void Set##PROP_NAME_ (const TYPE_NAME_& val) { VAR_NAME_ = val; SetDirty(); } const TYPE_NAME_& Get##PROP_NAME_ () const {return VAR_NAME_; }
#define GET_SET_COMPARE_DIRTY(TYPE_NAME_, PROP_NAME_, VAR_NAME_)  void Set##PROP_NAME_ (const TYPE_NAME_ val) { if ((TYPE_NAME_)VAR_NAME_ == val) return; VAR_NAME_ = val; SetDirty(); }    const TYPE_NAME_ Get##PROP_NAME_ () const {return (const TYPE_NAME_)VAR_NAME_; }

#endif
