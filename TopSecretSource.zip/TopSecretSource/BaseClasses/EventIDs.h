#pragma once

enum EventIDs
{
    kBecameVisibleEvent,
    kBecameInvisibleEvent,
    kWillDestroyEvent,
    kAnimatorClearEvent,
};
