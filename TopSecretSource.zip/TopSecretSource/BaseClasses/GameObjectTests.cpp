#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS
#include "Runtime/Camera/Culler.h"
#include "Runtime/Interfaces/IPhysics.h"
#include "Runtime/Testing/Testing.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/BaseClasses/BaseObject.h"
#include "Runtime/Transform/RectTransform.h"

class GameObjectFixture
{
protected:
    typedef std::vector<PPtr<GameObject> > GameObjectsVector;
    typedef std::vector<PPtr<Unity::Component> > ComponentsVector;
    GameObjectsVector gameObjects;
    ComponentsVector components;
    GameObject* go;

    GameObjectFixture()
    {
        go = NewGameObject();
    }

    GameObject* NewGameObject()
    {
        GameObject* obj = NEW_OBJECT_RESET_AND_AWAKE(GameObject);
        gameObjects.push_back(PPtr<GameObject>(obj));
        return obj;
    }

    GameObject& CreateGameObject(const core::string& name, const char* componentName, ...)
    {
        va_list ap;
        va_start(ap, componentName);
        GameObject& result = ::CreateGameObjectWithVAList(name, componentName, ap);
        va_end(ap);

        gameObjects.push_back(PPtr<GameObject>(result.GetInstanceID()));
        return result;
    }

    Unity::Component* NewComponent()
    {
        Unity::Component* component = NEW_OBJECT_RESET_AND_AWAKE(Unity::Component);
        components.push_back(PPtr<Unity::Component>(component));
        return component;
    }

    ~GameObjectFixture()
    {
        for (GameObjectsVector::iterator it = gameObjects.begin(); it != gameObjects.end(); ++it)
        {
            if (!it->IsValid()) continue;

            if (!(*it)->IsDestroying())
                DestroyObjectHighLevel(*it);
        }

        for (ComponentsVector::iterator it = components.begin(); it != components.end(); ++it)
        {
            if (!it->IsValid()) continue;

            DestroyObjectHighLevel(*it);
        }
    }
};

UNIT_TEST_SUITE(GameObjectTests)
{
    TEST_FIXTURE(GameObjectFixture, AddComponentInternal_CalledOnce_IncreasesComponentCount)
    {
        Unity::Component* component = NewComponent();

        go->AddComponentInternal(component);

        CHECK_EQUAL(go->GetComponentCount(), 1);
    }

    TEST_FIXTURE(GameObjectFixture, RemoveComponentFromGameObjectInternal_CalledOnce_DecreasesComponentCount)
    {
        Unity::Component* component = NewComponent();
        go->AddComponentInternal(component);

        go->RemoveComponentFromGameObjectInternal(*component);

        CHECK_EQUAL(go->GetComponentCount(), 0);
    }

    TEST_FIXTURE(GameObjectFixture, RemoveComponentAtIndex_CalledOnce_DecreasesComponentCount)
    {
        Unity::Component* component = NewComponent();
        go->AddComponentInternal(component);

        go->RemoveComponentAtIndex(0);

        CHECK_EQUAL(go->GetComponentCount(), 0);
    }

    TEST_FIXTURE(GameObjectFixture, GetHideFlags_OnGameObject_ReturnsDefaultFlags)
    {
        int result = go->GetHideFlags();

        CHECK_EQUAL((int)Object::kHideFlagsNone, result);
    }

    TEST_FIXTURE(GameObjectFixture, GetHideFlags_OnGameObjectWithCustomFlag_ReturnsCustomFlag)
    {
        Object::HideFlags hideFlag = Object::kHideInHierarchy;
        go->SetHideFlags(hideFlag);

        int result = go->GetHideFlags();

        CHECK_EQUAL(hideFlag, result);
    }

    TEST_FIXTURE(GameObjectFixture, SetHideFlagsObjectOnly_OnGameObjectWithComponent_SetsTheFlagOnlyOnGameObject)
    {
        Unity::Component* component = NewComponent();
        go->AddComponentInternal(component);
        Object::HideFlags hideFlag = Object::kHideInHierarchy;
        go->SetHideFlags(hideFlag);
        Object::HideFlags anotherHideFlag = Object::kHideInspector;

        go->SetHideFlagsObjectOnly(anotherHideFlag);

        Object::HideFlags goFlags = go->GetHideFlags();
        Object::HideFlags componentFlags = go->GetComponentAtIndex(0).GetHideFlags();
        CHECK_EQUAL(anotherHideFlag, goFlags);
        CHECK_EQUAL(hideFlag, componentFlags);
    }

    TEST_FIXTURE(GameObjectFixture, SetHideFlags_OnGameObjectWithCustomFlag_AlsoSetsFlagsOnComponents)
    {
        Unity::Component* component1 = NewComponent();
        go->AddComponentInternal(component1);
        Unity::Component* component2 = NewComponent();
        go->AddComponentInternal(component2);
        Object::HideFlags hideFlag = Object::kHideInspector;

        go->SetHideFlags(hideFlag);
        Object::HideFlags result1 = go->GetComponentAtIndex(0).GetHideFlags();
        Object::HideFlags result2 = go->GetComponentAtIndex(1).GetHideFlags();

        CHECK_EQUAL(hideFlag, result1);
        CHECK_EQUAL(hideFlag, result2);
    }

    TEST_FIXTURE(GameObjectFixture, GetName_FromObject_ReturnsGameObjectName)
    {
        const char* name = "Test";
        go->SetName(name);

        CHECK_EQUAL(name, go->GetName());
    }

    TEST_FIXTURE(GameObjectFixture, GetName_ForNewComponent_ReturnsComponentClassName)
    {
        Unity::Component* component = NewComponent();

        CHECK_EQUAL(component->GetClassName(), component->GetName());
    }

    TEST_FIXTURE(GameObjectFixture, GetName_FromComponents_ReturnsGameObjectName)
    {
        AddComponents(*go, "Transform", "MeshRenderer", NULL);

        const char* name = "Test";
        go->SetName(name);

        CHECK_EQUAL(name, go->GetComponentAtIndex(0).GetName());
        CHECK_EQUAL(name, go->GetComponentAtIndex(1).GetName());
    }

    TEST_FIXTURE(GameObjectFixture, QueryComponent_WithSpecificComponent_ReturnsIt)
    {
        AddComponents(*go, "Transform", "MeshRenderer", NULL);

        Transform* transform = go->QueryComponent<Transform>();

        CHECK(transform != NULL);
    }

    TEST_FIXTURE(GameObjectFixture, SwapComponents_WithDifferentComponents_SwapsThem)
    {
        AddComponents(*go, "Transform", "MeshRenderer", NULL);
        Unity::Component* component1 = go->GetComponentPtrAtIndex(0);
        Unity::Component* component2 = go->GetComponentPtrAtIndex(1);

        go->SwapComponents(0, 1);

        CHECK_EQUAL(1, go->GetComponentIndex(component1));
        CHECK_EQUAL(0, go->GetComponentIndex(component2));
    }

    TEST_FIXTURE(GameObjectFixture, CheckConsistency_WithMultipleTransformComponents_RemovesAllDuplicates)
    {
        Unity::Component* primaryTransform = NEW_OBJECT_RESET_AND_AWAKE(Transform);
        go->AddComponentInternal(primaryTransform);
        go->AddComponentInternal(NEW_OBJECT_RESET_AND_AWAKE(Transform));
        go->AddComponentInternal(NEW_OBJECT_RESET_AND_AWAKE(Transform));

        EXPECT(Error, "GameObject has multiple Transform components! Merged into single one.");

        go->CheckConsistency();

        CHECK_EQUAL(0, go->GetComponentIndex(primaryTransform));
        CHECK_EQUAL(1, go->GetComponentCount());
    }

    // Check that during the consistency check we always ensure that not only is there a single Transform-derived component
    // and that it is always located at index #0 but also that the second transform found is parented correctly with
    // the correct transform state.
    TEST_FIXTURE(GameObjectFixture, CheckConsistency_WithMultipleTransformComponents_PresevesObjectParenting)
    {
        // Create a parent transform.
        GameObject* parentGO = NewGameObject();
        Transform* parentTransform = NEW_OBJECT(Transform);
        parentTransform->Reset();
        parentGO->AddComponentInternal(parentTransform);

        // Create a transform with no parent.
        Transform* firstTransform = NEW_OBJECT(UI::RectTransform);
        firstTransform->Reset();
        go->AddComponentInternal(firstTransform);

        // Create a second transform and parent it.
        Transform* secondTransform = NEW_OBJECT(Transform);
        secondTransform->Reset();
        go->AddComponentInternal(secondTransform);
        secondTransform->SetParent(parentTransform);

        // Set the transform state to be copied.
        const Vector3f position(10.0f, 20.0f, 30.0f);
        const Quaternionf rotation = NormalizeSafe(EulerToQuaternion(Vector3f(0.1f, 0.2f, 0.3f)));
        const Vector3f scale(2.0f, 3.0f, 4.0f);
        secondTransform->SetLocalTRS(position, rotation, scale);

        EXPECT(Error, "GameObject has multiple Transform components! Merged into single one.");

        // Perform the consistency check.
        go->CheckConsistency();

        // Check that there is only one transform-derived component.
        int transformCount = 0;
        for (size_t index = 0; index < go->GetComponentCount(); ++index)
        {
            if (go->GetComponentAtIndex(index).IsDerivedFrom<Transform>())
                ++transformCount;
        }
        CHECK_EQUAL(1, transformCount);

        // Check that the first transform is at the first position.
        CHECK_EQUAL(0, go->GetComponentIndex(firstTransform));

        // Check that the first transform is parented.
        CHECK_EQUAL(parentTransform, firstTransform->GetParent());

        // Check the first transform state.
        CHECK(CompareApproximately(position, firstTransform->GetLocalPosition()));
        CHECK(CompareApproximately(rotation, firstTransform->GetLocalRotation()));
        CHECK(CompareApproximately(scale, firstTransform->GetLocalScale()));

        DestroyObjectHighLevel(parentGO);
    }

    // Check that during the consistency check we always ensure that not only is there a single Transform-derived component
    // and that it is always located at index #0 but also that the first RectTransform discovered becomes the unique transform.
    TEST_FIXTURE(GameObjectFixture, CheckConsistency_WithMultipleTransformDerivedComponents_RemovesAllDuplicatesOfEachTransformDerivedType)
    {
        // Add a set of base transforms.
        for (int n = 0; n < 3; ++n)
        {
            Unity::Component* com = NEW_OBJECT(Transform);
            com->Reset();
            go->AddComponentInternal(com);
        }

        // Add a set of rect-transforms.
        Unity::Component* primaryTransform = NULL;
        for (int n = 0; n < 3; ++n)
        {
            Unity::Component* com = NEW_OBJECT(UI::RectTransform);
            com->Reset();
            go->AddComponentInternal(com);
            if (n == 0)
                primaryTransform = com;
        }

        EXPECT(Error, "GameObject has multiple Transform components! Merged into single one.");

        // Perform the consistency check.
        go->CheckConsistency();

        // Check that there is only one transform-derived component.
        int transformCount = 0;
        for (size_t index = 0; index < go->GetComponentCount(); ++index)
        {
            if (go->GetComponentAtIndex(index).IsDerivedFrom<Transform>())
                ++transformCount;
        }
        CHECK_EQUAL(1, transformCount);

        // Check that the primary transform is at the first position.
        CHECK_EQUAL(0, go->GetComponentIndex(primaryTransform));
    }

    TEST_FIXTURE(GameObjectFixture, CheckConsistency_OnComponentNotReferencedFromGameObject_FixesGameObjectReference)
    {
        Unity::Component* component = NewComponent();
        component->SetGameObjectInternal(go);

        CHECK_EQUAL(0, go->GetComponentCount());

        EXPECT(Error, "GameObject does not reference component");
        component->CheckConsistency();

        CHECK_EQUAL(1, go->GetComponentCount());
    }

    TEST_FIXTURE(GameObjectFixture, ActiveState_OnReparenting_UpdatesAccordingly)
    {
        GameObject& go1 = CreateGameObject("GO1", "Transform", NULL);
        GameObject& go2 = CreateGameObject("GO2", "Transform", NULL);

        go1.SetSelfActive(false);
        CHECK_MSG(!go1.IsActive(), "isActiveBeforeReparenting go1");
        CHECK_MSG(go2.IsActive(), "isActiveBeforeReparenting go2");

        go2.GetComponent<Transform>().SetParent(&go1.GetComponent<Transform>());
        CHECK_MSG(!go2.IsActive(), "isActiveAfterReparenting");

        go2.GetComponent<Transform>().SetParent(NULL);
        CHECK_MSG(go2.IsActive(), "isActiveAfterUnparenting");
    }

    TEST_FIXTURE(GameObjectFixture, ActiveState_OnReparenting_UpdatesAccordinglyDeep)
    {
        GameObject& go1 = CreateGameObject("GO1", "Transform", NULL);
        GameObject& go2 = CreateGameObject("GO2", "Transform", NULL);
        GameObject& go3 = CreateGameObject("GO2", "Transform", NULL);

        // go1 (inactive)
        // go2 (active)
        // go3 (active)
        go1.SetSelfActive(false);
        CHECK(!go1.IsActive());
        CHECK(go2.IsActive());
        CHECK(go3.IsActive());

        // go1 (inactive)
        // go2 (active)
        // - go3
        go3.GetComponent<Transform>().SetParent(&go2.GetComponent<Transform>());
        CHECK(!go1.IsActive());
        CHECK(go2.IsActive());
        CHECK(go3.IsActive());

        // go1 (inactive)
        // - go2
        // -- go3
        go2.GetComponent<Transform>().SetParent(&go1.GetComponent<Transform>());
        CHECK(!go1.IsActive());
        CHECK(!go2.IsActive());
        CHECK(!go3.IsActive());

        // go1 (inactive)
        // go2  (active)
        // - go3
        go2.GetComponent<Transform>().SetParent(NULL);
        CHECK(!go1.IsActive());
        CHECK(go2.IsActive());
        CHECK(go3.IsActive());
    }

    TEST_FIXTURE(GameObjectFixture, GetGameObjectPtr_OnComponent_ReturnsGameObjectToWhichComponentIsAttachedTo)
    {
        GameObject& go = CreateGameObject("TestGameObject", "Transform", "MeshRenderer", NULL);
        Unity::Component& component = go.GetComponentAtIndex(0);

        CHECK_EQUAL(&go, component.GetGameObjectPtr());
    }

    TEST_FIXTURE(GameObjectFixture, IsActive_OnNewComponent_ReturnsFalse)
    {
        go->Activate();
        Unity::Component* component = NewComponent();

        CHECK(!component->IsActive());
    }

    TEST_FIXTURE(GameObjectFixture, IsActive_OnNewComponentAddedToGameObject_ReturnsTrue)
    {
        go->Activate();
        Unity::Component* component = NewComponent();
        go->AddComponentInternal(component);

        CHECK(component->IsActive());
    }

#if !UNITY_RELEASE
    TEST_FIXTURE(GameObjectFixture, GetSupportedMessages_OnNewGameObject_ReturnsNoMessages)
    {
        CHECK_EQUAL(0, go->GetSupportedMessages());
    }

    TEST_FIXTURE(GameObjectFixture, GetSupportedMessages_OnObjectWithSpecificComponent_ReturnsMessagesSupportedByComponent)
    {
        AddComponents(*go, "Transform", "Tree", NULL);

        CHECK_EQUAL(go->GetSupportedMessages(), kOnWillRenderObject.GetOptimizedMask());
    }

    TEST_FIXTURE(GameObjectFixture, GetSupportedMessages_OnInactiveObjectWithSpecificComponent_ReturnsMessagesSupportedByComponent)
    {
        AddComponents(*go, "Transform", "Tree", NULL);
        go->Deactivate();

        CHECK_EQUAL(kOnWillRenderObject.GetOptimizedMask(), go->GetSupportedMessages());
    }

    TEST_FIXTURE(GameObjectFixture, GetSupportedMessages_OnObjectWithMultipleComponents_ReturnsMessagesSupportedByAllComponents)
    {
        AddComponents(*go, "Transform", "Tree", NULL);
        go->Activate();
        AddComponents(*go, "NavMeshObstacle", NULL);

        CHECK_EQUAL((kOnWillRenderObject.GetOptimizedMask() | kDidVelocityChange.GetOptimizedMask() | kTransformChanged.GetOptimizedMask()), go->GetSupportedMessages());
    }

    TEST_FIXTURE(GameObjectFixture, GetSupportedMessages_OnInactiveObjectWithTwoComponents_ReturnsMessagesSupportedByComponents)
    {
        AddComponents(*go, "Transform", "Tree", NULL);
        go->Deactivate();
        AddComponents(*go, "NavMeshObstacle", NULL);

        CHECK_EQUAL((kOnWillRenderObject.GetOptimizedMask() | kDidVelocityChange.GetOptimizedMask() | kTransformChanged.GetOptimizedMask()), go->GetSupportedMessages());
    }

    TEST_FIXTURE(GameObjectFixture, GetSupportedMessages_OnObjectAfterDestroyingComponent_ReturnsMessagesSupportedByOtherComponentsOnTheGameObject)
    {
        AddComponents(*go, "Transform", "Tree", NULL);
        go->Activate();
        AddComponents(*go, "NavMeshObstacle", NULL);
        DestroyObjectHighLevel(&go->GetComponentAtIndex(1));

        CHECK_EQUAL((kDidVelocityChange.GetOptimizedMask() | kTransformChanged.GetOptimizedMask()), go->GetSupportedMessages());
    }

    TEST_FIXTURE(GameObjectFixture, GetSupportedMessages_OnObjectAfterDestroyingAllItsComponents_ReturnsNoMessages)
    {
        AddComponents(*go, "Transform", "Tree", NULL);
        go->Activate();
        AddComponents(*go, "NavMeshObstacle", NULL);
        DestroyObjectHighLevel(&go->GetComponentAtIndex(1)); //removes Tree component
        DestroyObjectHighLevel(&go->GetComponentAtIndex(1)); //removes NavMeshObstacle component which is at index 1 after Tree component was destroyed
        go->Deactivate();

        CHECK_EQUAL(0, go->GetSupportedMessages());
    }

    TEST(AwakeFromLoadCheckTest)
    {
        // enforce awake after reset
        {
            GameObject* obj = NEW_OBJECT(GameObject);
            obj->Reset();
            obj->AwakeFromLoad(kDefaultAwakeFromLoad);
            obj->CheckCorrectAwakeUsage();
            DestroyObjectHighLevel(obj);
        }

        // Check internal setters are working
        {
            GameObject* obj = NEW_OBJECT(GameObject);
            obj->Reset();
            obj->SetAwakeCalledInternal();
            obj->CheckCorrectAwakeUsage();
            DestroyObjectHighLevel(obj);
        }

        {
            GameObject* obj = NEW_OBJECT(GameObject);
            obj->Reset();
            obj->AwakeFromLoad(kInstantiateOrCreateFromCodeAwakeFromLoad);
            obj->CheckCorrectAwakeUsage();
            DestroyObjectHighLevel(obj);
        }
    }
#endif
}
#endif
