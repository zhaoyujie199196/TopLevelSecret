// builtins
UNITY_KERNEL_BUILTIN(int, kClassIdOutOfHierarchy)
UNITY_KERNEL_BUILTIN(bool, kClassIdOutOfHierarchy + 1)
UNITY_KERNEL_BUILTIN(float, kClassIdOutOfHierarchy + 2)
UNITY_KERNEL_BUILTIN(void, kClassIdOutOfHierarchy + 11)

// non-hierarchy classes
UNITY_KERNEL_NONHIERARCHY_CLASS(Polygon2D, kClassIdOutOfHierarchy + 10)
UNITY_KERNEL_NONHIERARCHY_CLASS(Vector3f, kClassIdOutOfHierarchy + 5)

// non-hierarchy structs (generally message data)
UNITY_KERNEL_STRUCT(AudioMixerLiveUpdateBool, kClassIdOutOfHierarchy + 9)
UNITY_KERNEL_STRUCT(AudioMixerLiveUpdateFloat, kClassIdOutOfHierarchy + 8)
UNITY_KERNEL_STRUCT(Collision, kClassIdOutOfHierarchy + 4)
UNITY_KERNEL_STRUCT(Collision2D, kClassIdOutOfHierarchy + 7)
UNITY_KERNEL_STRUCT(MonoObject, kClassIdOutOfHierarchy + 3)
UNITY_KERNEL_STRUCT(RootMotionData, kClassIdOutOfHierarchy + 6)

UNITY_KERNEL_CLASS(AssetBundle)
UNITY_KERNEL_CLASS(AssetBundleManifest)
UNITY_KERNEL_CLASS(Behaviour)
UNITY_KERNEL_CLASS(BillboardAsset)
UNITY_KERNEL_CLASS(BillboardRenderer)
UNITY_KERNEL_CLASS(BuildSettings)
UNITY_KERNEL_CLASS(Camera)
UNITY_KERNEL_CLASS(ComputeShader)
UNITY_KERNEL_CLASS(Cubemap)
UNITY_KERNEL_CLASS(CustomRenderTexture)
UNITY_KERNEL_CLASS(CubemapArray)
UNITY_KERNEL_CLASS(CGProgram)
UNITY_KERNEL_CLASS(DelayedCallManager)
UNITY_KERNEL_CLASS(EditorExtension)
UNITY_KERNEL_CLASS(Flare)
UNITY_KERNEL_CLASS(FlareLayer)
UNITY_KERNEL_CLASS(GameObject)
UNITY_KERNEL_CLASS(GameManager)
UNITY_KERNEL_CLASS(GlobalGameManager)
UNITY_KERNEL_CLASS(GraphicsSettings)
UNITY_KERNEL_CLASS(GUIElement)
UNITY_KERNEL_CLASS(GUILayer)
UNITY_KERNEL_CLASS(GUITexture)
UNITY_KERNEL_CLASS(Halo)
UNITY_KERNEL_CLASS(HaloLayer)
UNITY_KERNEL_CLASS(InputManager)
UNITY_KERNEL_CLASS(LensFlare)
UNITY_KERNEL_CLASS(LevelGameManager)
UNITY_KERNEL_CLASS(Light)
UNITY_KERNEL_CLASS(LightProbeGroup)
UNITY_KERNEL_CLASS(LightProbeProxyVolume)
UNITY_KERNEL_CLASS(LightProbes)
UNITY_KERNEL_CLASS(LightmapSettings)
UNITY_KERNEL_CLASS(LineRenderer)
UNITY_KERNEL_CLASS(LODGroup)
UNITY_KERNEL_CLASS(Material)
UNITY_KERNEL_CLASS(Mesh)
UNITY_KERNEL_CLASS(MeshFilter)
UNITY_KERNEL_CLASS(MeshRenderer)
UNITY_KERNEL_CLASS(NamedObject)
UNITY_KERNEL_CLASS(OcclusionArea)
UNITY_KERNEL_CLASS(OcclusionCullingData)
UNITY_KERNEL_CLASS(OcclusionPortal)
UNITY_KERNEL_CLASS(PlayerSettings)
UNITY_KERNEL_CLASS(PreloadData)
UNITY_KERNEL_CLASS(ProceduralMaterial)
UNITY_KERNEL_CLASS(ProceduralTexture)
UNITY_KERNEL_CLASS(Projector)
UNITY_KERNEL_CLASS(ReflectionProbe)
UNITY_KERNEL_CLASS(Renderer)
UNITY_KERNEL_CLASS(RenderSettings)
UNITY_KERNEL_CLASS(RenderTexture)
UNITY_KERNEL_CLASS(ResourceManager)
UNITY_KERNEL_CLASS(RuntimeInitializeOnLoadManager)
UNITY_KERNEL_CLASS(ScriptMapper)
UNITY_KERNEL_CLASS(Shader)
UNITY_KERNEL_CLASS(ShaderVariantCollection)
UNITY_KERNEL_CLASS(SkinnedMeshRenderer)
UNITY_KERNEL_CLASS(Skybox)
UNITY_KERNEL_CLASS(SparseTexture)
UNITY_KERNEL_CLASS(SpeedTreeWindAsset)
UNITY_KERNEL_CLASS(SortingGroup)
UNITY_KERNEL_CLASS(SpriteRenderer)
UNITY_KERNEL_CLASS(Sprite)
UNITY_KERNEL_CLASS(SubstanceArchive)
UNITY_KERNEL_CLASS(TagManager)
UNITY_KERNEL_CLASS(TimeManager)
UNITY_KERNEL_CLASS(TextAsset)
UNITY_KERNEL_CLASS(Texture)
UNITY_KERNEL_CLASS(Texture2D)
UNITY_KERNEL_CLASS(Texture2DArray)
UNITY_KERNEL_CLASS(Texture3D)
UNITY_KERNEL_CLASS(TrailRenderer)
UNITY_KERNEL_CLASS(Transform)
UNITY_KERNEL_CLASS(QualitySettings)
UNITY_KERNEL_CLASS(WindZone)

UNITY_KERNEL_CLASS(Unity, Component)

UNITY_KERNEL_CLASS(UI, RectTransform)

UNITY_KERNEL_CLASS(MonoBehaviour)
UNITY_KERNEL_CLASS(MonoManager)
UNITY_KERNEL_CLASS(MonoScript)

UNITY_KERNEL_CLASS(LowerResBlitTexture)

#if ENABLE_RAKNET
UNITY_KERNEL_CLASS(MasterServerInterface)
UNITY_KERNEL_CLASS(NetworkManager)
UNITY_KERNEL_CLASS(NetworkView)
#endif

#if ENABLE_2D_COMMON
UNITY_KERNEL_CLASS(SpriteDataProvider)
UNITY_KERNEL_CLASS(BatchedSpriteRenderer)
#endif

#if ENABLE_MARSHALLING_TESTS
UNITY_KERNEL_CLASS(MarshallingTestObject)     // This is a object purely used for testing the bindings generator marshalling
#endif

#if UNITY_PS4
UNITY_KERNEL_CLASS(TextureRawPS4)
#endif


// Editor Only classes following :

#if UNITY_EDITOR
UNITY_KERNEL_CLASS(AnimatorState)
UNITY_KERNEL_CLASS(AnimatorStateMachine)
UNITY_KERNEL_CLASS(AnimatorStateTransition)
UNITY_KERNEL_CLASS(AnimatorTransition)
UNITY_KERNEL_CLASS(AnimatorTransitionBase)
UNITY_KERNEL_CLASS(AnnotationManager)
UNITY_KERNEL_CLASS(AssetDatabase)
UNITY_KERNEL_CLASS(AssetMetaData)
UNITY_KERNEL_CLASS(AssetImporter)
UNITY_KERNEL_CLASS(AssetServerCache)
UNITY_KERNEL_CLASS(AudioMixerController)
UNITY_KERNEL_CLASS(AudioMixerGroupController)
UNITY_KERNEL_CLASS(AudioMixerEffectController)
UNITY_KERNEL_CLASS(AudioMixerSnapshotController)
UNITY_KERNEL_CLASS(AudioImporter)
UNITY_KERNEL_CLASS(VideoClipImporter)
UNITY_KERNEL_CLASS(BlendTree)
UNITY_KERNEL_CLASS(CachedSpriteAtlas)
UNITY_KERNEL_CLASS(ComputeShaderImporter)
UNITY_KERNEL_CLASS(DefaultAsset)
UNITY_KERNEL_CLASS(DefaultImporter)
UNITY_KERNEL_CLASS(EditorExtensionImpl)
UNITY_KERNEL_CLASS(EditorBuildSettings)
UNITY_KERNEL_CLASS(EditorSettings)
UNITY_KERNEL_CLASS(EditorUserBuildSettings)
UNITY_KERNEL_CLASS(EditorUserSettings)
UNITY_KERNEL_CLASS(FBXImporter)
UNITY_KERNEL_CLASS(HierarchyState)
UNITY_KERNEL_CLASS(HumanTemplate)
UNITY_KERNEL_CLASS(InspectorExpandedState)
UNITY_KERNEL_CLASS(IHVImageFormatImporter)
UNITY_KERNEL_CLASS(LibraryAssetImporter)
UNITY_KERNEL_CLASS(Mesh3DSImporter)
UNITY_KERNEL_CLASS(ModelImporter)
UNITY_KERNEL_CLASS(MovieImporter)
UNITY_KERNEL_CLASS(PluginImporter)
UNITY_KERNEL_CLASS(Prefab)
UNITY_KERNEL_CLASS(MonoImporter)
UNITY_KERNEL_CLASS(NativeFormatImporter)
UNITY_KERNEL_CLASS(SceneAsset)
UNITY_KERNEL_CLASS(ShaderImporter)
UNITY_KERNEL_CLASS(SpeedTreeImporter)
UNITY_KERNEL_CLASS(SubstanceImporter)
UNITY_KERNEL_CLASS(TextScriptImporter)
UNITY_KERNEL_CLASS(TextureImporter)

#   if INCLUDE_GI && INCLUDE_DYNAMIC_GI
UNITY_KERNEL_CLASS(LightingDataAsset)
UNITY_KERNEL_CLASS(LightmapParameters)
#   endif

#if ENABLE_UNIT_TESTS
UNITY_KERNEL_CLASS(ActivationLogComponent)
#endif

#if ENABLE_UNIT_TESTS_WITH_FAKES
UNITY_KERNEL_CLASS(RendererFake)
UNITY_KERNEL_CLASS(TestObjectWithSerializedArray)
#endif

#endif // UNITY_EDITOR
