#pragma once

namespace Unity
{ class Type; }

template<typename T> const Unity::Type* TypeOf();

class VariantRef
{
public:
    VariantRef() : m_Type(NULL), m_Data(NULL)
    {
    }

    template<typename T>
    VariantRef(T& data) : m_Type(TypeOf<T>()), m_Data(&data)
    {
    }

    const Unity::Type* GetType() const
    {
        return m_Type;
    }

    bool HasValue() const
    {
        DebugAssert((m_Type != NULL) == (m_Data != NULL));
        return m_Type != NULL;
    }

    template<typename T>
    T& Get() const
    {
        Assert(m_Type == TypeOf<T>());
        Assert(m_Data != NULL);
        return *static_cast<T*>(m_Data);
    }

    bool operator==(const VariantRef& other) const
    {
        return m_Data == other.m_Data;
    }

    bool operator!=(const VariantRef& other) const
    {
        return !(*this == other);
    }

private:
    template<typename T>
    VariantRef(const T& data)
    {
        // const T& is disabled. Use ConstVariantRef for that case
    }

    const Unity::Type* m_Type;
    void* m_Data;
};


class ConstVariantRef
{
public:
    ConstVariantRef() : m_Type(NULL), m_Data(NULL)
    {
    }

    template<typename T>
    ConstVariantRef(const T& data) : m_Type(TypeOf<T>()), m_Data(&data)
    {
    }

    const Unity::Type* GetType() const
    {
        return m_Type;
    }

    bool HasValue() const
    {
        DebugAssert((m_Type != NULL) == (m_Data != NULL));
        return m_Type != NULL;
    }

    template<typename T>
    const T& Get() const
    {
        Assert(m_Type == TypeOf<T>());
        Assert(m_Data != NULL);
        return *static_cast<const T*>(m_Data);
    }

    bool operator==(const ConstVariantRef& other) const
    {
        return m_Data == other.m_Data;
    }

    bool operator!=(const ConstVariantRef& other) const
    {
        return !(*this == other);
    }

private:
    const Unity::Type* m_Type;
    const void* m_Data;
};
