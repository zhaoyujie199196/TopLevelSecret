#include "UnityPrefix.h"
#include "LightProbeProxyVolume.h"

#include "Runtime/BaseClasses/IsPlaying.h"
#include "Runtime/Camera/BaseRenderer.h"
#include "Runtime/Camera/RenderLoops/LightProbeContext.h"
#include "Runtime/Camera/LightProbes.h"
#include "Runtime/Camera/RenderSettings.h"
#include "Runtime/Core/Callbacks/GlobalCallbacks.h"
#include "Runtime/GfxDevice/GfxDevice.h"
#include "Runtime/Graphics/LightmapSettings.h"
#include "Runtime/Graphics/Renderer.h"
#include "Runtime/Graphics/Texture3D.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Jobs/Jobs.h"
#include "Runtime/ParticleSystem/ParticleSystemRenderer.h"
#include "Runtime/Shaders/GraphicsCaps.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Profiler/Profiler.h"

IMPLEMENT_REGISTER_CLASS(LightProbeProxyVolume, 259);
IMPLEMENT_OBJECT_SERIALIZE(LightProbeProxyVolume);

const UInt32 kLightProbeVolumeDefaultTextureResolution = 2;     // Used in Custom resolution mode
const UInt32 kLightProbeVolumeMaxTextureResolution = 32;
const float kLightProbeVolumeDefaultProbeDensity = 0.25f;       // Used in Automatic resolution mode
const float kLightProbeVolumeMinProbeDensity = 0.01f;
const float kLightProbeVolumeMaxProbeDensity = 1.0f;
const AABB kDefaultAABB(Vector3f(0.0f, 0.0f, 0.0f), Vector3f(0.5f, 0.5f, 0.5f));

PROFILER_INFORMATION(gLightProbeProxyVolumeManagerUpdate, "LightProbeProxyVolumeManager.Update", kProfilerRender)
PROFILER_INFORMATION(gBlendLightProbesJob, "BlendLightProbesJob", kProfilerRender);

namespace LightProbeProxyVolumeUtils
{
    // Computes a world-aligned bounding box containing a hierarchy of Renderers that use LPPVs
    static void ComputeGlobalAABBOnHierarchy(Transform& transform, MinMaxAABB& globalAABB)
    {
        GameObject& gameObject = transform.GetGameObject();
        if (gameObject.IsActive())
        {
            const int numComponents = gameObject.GetComponentCount();
            for (int compIndex = 0; compIndex < numComponents; compIndex++)
            {
                Renderer* renderer = gameObject.QueryComponentAtIndexT<Renderer>(compIndex);
                if (renderer && renderer->IsActive() && renderer->GetLightProbeUsage() == kLightProbeUseProxyVolume)
                {
                    const AABB& aabb = renderer->GetTransformInfoAndUpdateSlow().worldAABB;
                    if (SqrMagnitude(aabb.GetExtent()) > std::numeric_limits<float>::epsilon())
                        globalAABB.Encapsulate(aabb);
                }
            }

            const int childrenCount = transform.GetChildrenCount();
            for (int i = 0; i < childrenCount; i++)
            {
                Transform& child = transform.GetChild(i);
                ComputeGlobalAABBOnHierarchy(child, globalAABB);
            }
        }

        if (!globalAABB.IsValid())
        {
            const AABB defaultAABB(transform.GetPosition(), Vector3f(0.5f, 0.5f, 0.5f));
            globalAABB.Encapsulate(defaultAABB);
        }
    }

    // Computes a bounding box in the local space of a Renderer containing a hierarchy of Renderers that use LPPVs
    static void ComputeLocalAABBOnHierarchy(const Matrix4x4f& worldToLocalLPPV, Transform& transformChild, MinMaxAABB& localAABB)
    {
        GameObject& gameObject = transformChild.GetGameObject();
        if (gameObject.IsActive())
        {
            const int numComponents = gameObject.GetComponentCount();
            for (int compIndex = 0; compIndex < numComponents; compIndex++)
            {
                Renderer* renderer = gameObject.QueryComponentAtIndexT<Renderer>(compIndex);
                if (renderer && renderer->IsActive() && renderer->GetLightProbeUsage() == kLightProbeUseProxyVolume)
                {
                    const TransformInfo& info = renderer->GetTransformInfoAndUpdateSlow();
                    if (SqrMagnitude(info.localAABB.GetExtent()) > std::numeric_limits<float>::epsilon())
                    {
                        Matrix4x4f rendererLocalToLPPVLocal;
                        MultiplyMatrices4x4(&worldToLocalLPPV, &info.worldMatrix, &rendererLocalToLPPVLocal);

                        static Vector3f vertices[8];
                        info.localAABB.CalculateVertices(vertices);

                        for (UInt32 i = 0; i < 8; i++)
                        {
                            vertices[i] = rendererLocalToLPPVLocal.MultiplyPoint3(vertices[i]);
                            localAABB.Encapsulate(vertices[i]);
                        }
                    }
                }
            }

            const int childrenCount = transformChild.GetChildrenCount();
            for (int i = 0; i < childrenCount; i++)
            {
                Transform& transform = transformChild.GetChild(i);
                ComputeLocalAABBOnHierarchy(worldToLocalLPPV, transform, localAABB);
            }
        }

        if (!localAABB.IsValid())
        {
            localAABB.Encapsulate(kDefaultAABB);
        }
    }

    static void ComputeLocalAABBOnHierarchy(Transform& transformBase, MinMaxAABB& localAABB)
    {
        ComputeLocalAABBOnHierarchy(transformBase.GetWorldToLocalMatrix(), transformBase, localAABB);
    }

    // Searches through the hierarchy, finds a Renderer using Proxy Volumes and gets the tetrahedron index
    static void FindTetrahedronIndex(Transform& transform, int& inOutTetIndex)
    {
        if (inOutTetIndex != -1)
            return;

        GameObject& gameObject = transform.GetGameObject();
        if (gameObject.IsActive())
        {
            const int numComponents = gameObject.GetComponentCount();
            for (int compIndex = 0; compIndex < numComponents; compIndex++)
            {
                Renderer* renderer = gameObject.QueryComponentAtIndexT<Renderer>(compIndex);
                if (renderer && renderer->IsActive() && renderer->GetLightProbeUsage() == kLightProbeUseProxyVolume)
                {
                    inOutTetIndex = renderer->GetLastLightProbeTetIndex();
                    return;
                }
            }

            const int childrenCount = transform.GetChildrenCount();
            for (int i = 0; i < childrenCount; i++)
            {
                Transform& transformChild = transform.GetChild(i);
                FindTetrahedronIndex(transformChild, inOutTetIndex);
            }
        }
    }
} //namespace LightProbeProxyVolumeUtils

template<class T>
void LightProbeProxyVolume::Transfer(T& transfer)
{
    Super::Transfer(transfer);

    TRANSFER(m_BoundingBoxMode);
    TRANSFER(m_ResolutionX);
    TRANSFER(m_ResolutionY);
    TRANSFER(m_ResolutionZ);
    TRANSFER(m_ResolutionProbesPerUnit);
    TRANSFER(m_BoundingBoxSize);
    TRANSFER(m_BoundingBoxOrigin);
    TRANSFER(m_ResolutionMode);
    TRANSFER(m_ProbePositionMode);
    TRANSFER(m_RefreshMode);
}

LightProbeProxyVolume::LightProbeProxyVolume(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
    , m_FinalResolutionX(1)
    , m_FinalResolutionY(1)
    , m_FinalResolutionZ(1)
    , m_SHCoeffsTexSetIndex(0)
    , m_Handle(InvalidHandle)
    , m_IsDirty(true)
{
    for (UInt32 textureSet = 0; textureSet < kMaxSHCoeffsTextureSets; textureSet++)
    {
        m_SHCoeffsTex[textureSet] = NULL;
    }
}

void LightProbeProxyVolume::ThreadedCleanup()
{
    Super::ThreadedCleanup();
}

void LightProbeProxyVolume::MainThreadCleanup()
{
    for (UInt32 textureSet = 0; textureSet < kMaxSHCoeffsTextureSets; textureSet++)
    {
        DestroySingleObject(m_SHCoeffsTex[textureSet]);
        m_SHCoeffsTex[textureSet] = NULL;
    }

    Super::MainThreadCleanup();
}

void LightProbeProxyVolume::Reset()
{
    Super::Reset();

    m_ResolutionX = kLightProbeVolumeDefaultTextureResolution;
    m_ResolutionY = kLightProbeVolumeDefaultTextureResolution;
    m_ResolutionZ = kLightProbeVolumeDefaultTextureResolution;
    m_ResolutionProbesPerUnit = kLightProbeVolumeDefaultProbeDensity;
    m_BoundingBoxSize = Vector3f::infinityVec;
    m_BoundingBoxOrigin = Vector3f::zero;
    m_ResolutionMode = kResModeAutomatic;
    m_BoundingBoxMode = kBBModeAutomaticLocal;
    m_ProbePositionMode = kPositionCellCorner;
    m_RefreshMode = kAutomatic;
    m_IsDirty = true;
}

void LightProbeProxyVolume::ValidateBoundingBoxSettings()
{
    if (m_BoundingBoxMode == kBBModeCustom && (m_BoundingBoxSize == Vector3f::infinityVec))
    {
        MinMaxAABB localAABB;
        LightProbeProxyVolumeUtils::ComputeLocalAABBOnHierarchy(*GetTransform(), localAABB);

        m_BoundingBoxSize = localAABB.CalculateExtent() * 2;
        m_BoundingBoxOrigin = localAABB.CalculateCenter();

        SetDirty();
    }
}

void LightProbeProxyVolume::CheckConsistency()
{
    Super::CheckConsistency();

    m_ResolutionX = clamp(m_ResolutionX, 1u, kLightProbeVolumeMaxTextureResolution);
    m_ResolutionY = clamp(m_ResolutionY, 1u, kLightProbeVolumeMaxTextureResolution);
    m_ResolutionZ = clamp(m_ResolutionZ, 1u, kLightProbeVolumeMaxTextureResolution);

    m_ResolutionProbesPerUnit = std::max(kLightProbeVolumeMinProbeDensity, m_ResolutionProbesPerUnit);
    m_ResolutionProbesPerUnit = std::min(kLightProbeVolumeMaxProbeDensity, m_ResolutionProbesPerUnit);

    ValidateBoundingBoxSettings();
}

void LightProbeProxyVolume::AddToManager()
{
    GetLightProbeProxyVolumeManager().AddProxyVolume(this);
}

void LightProbeProxyVolume::RemoveFromManager()
{
    GetLightProbeProxyVolumeManager().RemoveProxyVolume(this);
}

Transform* LightProbeProxyVolume::GetTransform()
{
    return QueryComponent<Transform>();
}

AABB LightProbeProxyVolume::GetProbeAABB()
{
    AABB aabb = GetAABB();

    if (m_ProbePositionMode == kPositionCellCorner)
    {
        UInt32 resX, resY, resZ;
        GetResolution(resX, resY, resZ);

        aabb.m_Extent.x *= static_cast<float>(resX) / std::max(resX - 1, 1u);
        aabb.m_Extent.y *= static_cast<float>(resY) / std::max(resY - 1, 1u);
        aabb.m_Extent.z *= static_cast<float>(resZ) / std::max(resZ - 1, 1u);
    }

    return aabb;
}

bool LightProbeProxyVolume::GetLocalToWorldMatrix(Matrix4x4f& outMatrix)
{
    if (m_BoundingBoxMode == kBBModeAutomaticLocal || m_BoundingBoxMode == kBBModeCustom)
    {
        outMatrix = GetTransform()->GetLocalToWorldMatrix();

        if (m_BoundingBoxMode == kBBModeCustom)
        {
            Matrix4x4f translation;
            translation.SetTranslate(m_BoundingBoxOrigin);
            outMatrix *= translation;
        }
        return true;
    }

    outMatrix = Matrix4x4f::identity;

    return false;
}

Matrix4x4f LightProbeProxyVolume::GetWorldToLocalMatrix()
{
    if (m_BoundingBoxMode == kBBModeCustom)
    {
        // If local to world matrix is (M*T), the inverse would be (M*T)^-1 = T^-1 * M^-1, where T is the local offset set by the user in Custom BB Mode
        Matrix4x4f translation, worldToLocal, result;
        translation.SetTranslate(-m_BoundingBoxOrigin);
        worldToLocal = GetTransform()->GetWorldToLocalMatrix();
        MultiplyMatrices4x4(&worldToLocal, &translation, &result);
        return result;
    }
    else
    {
        return GetTransform()->GetWorldToLocalMatrix();
    }
}

void LightProbeProxyVolume::GetResolution(UInt32& resolutionX, UInt32& resolutionY, UInt32& resolutionZ) const
{
    resolutionX = m_FinalResolutionX;
    resolutionY = m_FinalResolutionY;
    resolutionZ = m_FinalResolutionZ;
}

Texture3D* LightProbeProxyVolume::GetSHCoefficientsTexture() const
{
    return m_SHCoeffsTex[m_SHCoeffsTexSetIndex];
}

void LightProbeProxyVolume::GetRenderData(LightProbeProxyVolumeSample& lppvSample)
{
    Texture3D* shCoeffsTex = GetSHCoefficientsTexture();
    if (shCoeffsTex)
    {
        lppvSample.shCoeffsTexId         = shCoeffsTex->GetTextureID();
        lppvSample.shCoeffsTexTexelSizeX = shCoeffsTex->GetTexelSizeX();
        lppvSample.aabb                  = GetProbeAABB();
        lppvSample.useLocalSpace         = (GetBoundingBoxMode() == kBBModeCustom) || (GetBoundingBoxMode() == kBBModeAutomaticLocal);
        lppvSample.worldToObjectMatrix   = GetWorldToLocalMatrix();
    }
    else
    {
        lppvSample.Invalidate();
    }
}

//-------------------------------------------------------------------------------------------------------------------------------

static LightProbeProxyVolumeManager* gLightProbeProxyVolumeManager = NULL;

static void OnLightProbesUpdate()
{
    if (GetLightProbeProxyVolumeManagerPtr())
        GetLightProbeProxyVolumeManager().OnLightProbesUpdate();
}

LightProbeProxyVolumeManager::LightProbeProxyVolumeManager()
    : m_UpdateContext(kMemRenderer)
{
}

LightProbeProxyVolumeManager& GetLightProbeProxyVolumeManager()
{
    return *gLightProbeProxyVolumeManager;
}

LightProbeProxyVolumeManager* GetLightProbeProxyVolumeManagerPtr()
{
    return gLightProbeProxyVolumeManager;
}

void LightProbeProxyVolumeManager::InitializeClass()
{
    DebugAssert(gLightProbeProxyVolumeManager == NULL);
    gLightProbeProxyVolumeManager = UNITY_NEW(LightProbeProxyVolumeManager, kMemDefault);

    GlobalCallbacks::Get().lightProbesUpdated.Register(::OnLightProbesUpdate);
}

void LightProbeProxyVolumeManager::CleanupClass()
{
    GlobalCallbacks::Get().lightProbesUpdated.Unregister(::OnLightProbesUpdate);

    DebugAssert(gLightProbeProxyVolumeManager != NULL);
    UNITY_DELETE(gLightProbeProxyVolumeManager, kMemDefault);
    gLightProbeProxyVolumeManager = NULL;
}

void LightProbeProxyVolumeManager::AddProxyVolume(LightProbeProxyVolume* proxyVolume)
{
    m_LightProbeVolumes.push_back(proxyVolume);
}

void LightProbeProxyVolumeManager::RemoveProxyVolume(LightProbeProxyVolume* proxyVolume)
{
    proxyVolume->m_Handle = LightProbeProxyVolume::InvalidHandle;
    LightProbeProxyVolumeArray::iterator it = m_LightProbeVolumes.begin();
    while (it != m_LightProbeVolumes.end())
    {
        if ((*it) == proxyVolume)
        {
            std::swap(*it, m_LightProbeVolumes.back());
            m_LightProbeVolumes.pop_back();
            break;
        }
        it++;
    }
}

Texture3D* LightProbeProxyVolumeManager::AllocateVolumeTexture(LightProbeProxyVolume& target, const char* debugName)
{
    UInt32 resX, resY, resZ;
    target.GetResolution(resX, resY, resZ);

    Texture3D* shCoeffVolTex = CreateObjectFromCode<Texture3D>();
    DebugAssert(shCoeffVolTex);

    // The SH coefficients textures are packed into 1 atlas. Only power of 2 textures allowed. Occ part of the texture will contain probe occlusion.
    // For RGB parts, each texel contains 4 SH coefficients for L1 lighting.
    // -------------------------
    // | ShR | ShG | ShB | Occ |
    // -------------------------
    shCoeffVolTex->SetHideFlags(Object::kHideAndDontSave);
    shCoeffVolTex->InitTexture(resX * 4, resY, resZ, kTexFormatARGBFloat, false);
    shCoeffVolTex->SetName(debugName);
    shCoeffVolTex->GetSettings().m_Aniso = 0;
    shCoeffVolTex->GetSettings().m_FilterMode = kTexFilterBilinear;
    shCoeffVolTex->GetSettings().m_WrapMode = kTexWrapClamp;
    shCoeffVolTex->ApplySettings();

    return shCoeffVolTex;
}

void LightProbeProxyVolumeManager::Update()
{
    PROFILER_AUTO(gLightProbeProxyVolumeManagerUpdate, NULL);

    if (m_LightProbeVolumes.empty())
        return;

    m_UpdateContext.Reset();

    SInt16 index = 0;
    for (LightProbeProxyVolumeArray::iterator it = m_LightProbeVolumes.begin(); it != m_LightProbeVolumes.end(); ++it, index++)
    {
        LightProbeProxyVolume& proxyVolume = **it;
        UpdateProxyVolume(proxyVolume, index);

        LightProbeProxyVolumeSample& sample = m_UpdateContext.samples.push_back();
        proxyVolume.GetRenderData(sample);
    }
}

void LightProbeProxyVolumeManager::UpdateSHCoeffsTextureData(LightProbeProxyVolume& proxyVolume)
{
    Texture3D* volumeTexture = proxyVolume.m_SHCoeffsTex[proxyVolume.m_SHCoeffsTexSetIndex];
    DebugAssert(volumeTexture);
    if (volumeTexture)
        volumeTexture->UpdateImageData(false);
}

// Keep this list in synch with the UNITY_LIGHT_PROBE_PROXY_VOLUME define from UnityShaderVariables.cginc
// and CanUseLightProbeProxyVolume in PlatformCapsKeywords.cpp
const GfxDeviceRenderer kSupportedRenderers[] =
{
    kGfxRendererD3D11,
    kGfxRendererD3D12,
    kGfxRendererOpenGLCore,
    kGfxRendererXboxOne,
    kGfxRendererPS4,
    kGfxRendererVulkan,
    kGfxRendererMetal
};

bool LightProbeProxyVolume::HasHardwareSupport()
{
    GraphicsCaps& gfxCaps = GetGraphicsCaps();
    GfxDeviceRenderer currentRenderer = GetGfxDevice().GetRenderer();

    for (UInt32 i = 0; i < ARRAY_SIZE(kSupportedRenderers); i++)
    {
        if (currentRenderer == kSupportedRenderers[i])
            return gfxCaps.has3DTexture && (gfxCaps.supportsTextureFormat[kTexFormatARGBFloat] || gfxCaps.supportsTextureFormat[kTexFormatRGBAFloat]);
    }

    return false;
}

//Swizzle the sh coefficients as in GetShaderConstantsFromNormalizedSH from SHConstantCache.cpp
static inline void GetShaderSHL1CoeffsFromNormalizedSH(const SphericalHarmonicsL2& probe, Vector4f outCoefficients[SphericalHarmonics::kColorChannelCount])
{
    //If the target platform doesn't have support for kTexFormatARGBFloat texture format then do the swizzle to RGBA here
    const bool needsChannelSwizzle = !GetGraphicsCaps().supportsTextureFormat[kTexFormatARGBFloat];

    // L1 coefficients only.
    if (needsChannelSwizzle)
    {
        for (SphericalHarmonics::ColorChannel ch = SphericalHarmonics::kColorChannelRed; ch < SphericalHarmonics::kColorChannelCount; ch++)
        {
            outCoefficients[ch].x = probe.GetCoefficient(ch, 0) - probe.GetCoefficient(ch, 6);
            outCoefficients[ch].y = probe.GetCoefficient(ch, 3);
            outCoefficients[ch].z = probe.GetCoefficient(ch, 1);
            outCoefficients[ch].w = probe.GetCoefficient(ch, 2);
        }
    }
    else
    {
        for (SphericalHarmonics::ColorChannel ch = SphericalHarmonics::kColorChannelRed; ch < SphericalHarmonics::kColorChannelCount; ch++)
        {
            outCoefficients[ch].x = probe.GetCoefficient(ch, 3);
            outCoefficients[ch].y = probe.GetCoefficient(ch, 1);
            outCoefficients[ch].z = probe.GetCoefficient(ch, 2);
            outCoefficients[ch].w = probe.GetCoefficient(ch, 0) - probe.GetCoefficient(ch, 6);
        }
    }
}

static inline Vector4f GetShaderProbeOcclusionMask(const Vector4f& probeOcclusion)
{
    //If the target platform doesn't have support for kTexFormatARGBFloat texture format then do the swizzle to RGBA here
    const bool needsChannelSwizzle = !GetGraphicsCaps().supportsTextureFormat[kTexFormatARGBFloat];

    if (needsChannelSwizzle)
    {
        return Vector4f(probeOcclusion.w, probeOcclusion.x, probeOcclusion.y, probeOcclusion.z);
    }

    return probeOcclusion;
}

struct BlendProbesJobInput
{
    struct ProbeData
    {
        Vector3f                worldPosition;
        UInt32                  shCoeffTexDataOffsetR;      // In Vector4f s
        UInt32                  shCoeffTexDataOffsetG;      // In Vector4f s
        UInt32                  shCoeffTexDataOffsetB;      // In Vector4f s
        UInt32                  probeOcclusionOffset;       // In Vector4f s
#if UNITY_EDITOR
        SphericalHarmonicsL2    shL2Coeffs;                 // Used to display the interpolated light probes for Gizmo rendering
        Vector4f                occlusionMask;              // Occlusion mask for each interpolated probe for a max of 4 lights
#endif
    };

    BlendProbesJobInput()
        : rendererTetIndex(-1)
        , probeData(kMemTempAlloc)
    {
        texData = NULL;
    }

    LightProbeContext           context;
    int                         rendererTetIndex;
    dynamic_array<ProbeData>    probeData;
    Vector4f*                   texData;
};

static void BlendLightProbesJob(BlendProbesJobInput* blendProbeJobData, UInt32 index)
{
    PROFILER_AUTO(gBlendLightProbesJob, NULL);

    BlendProbesJobInput& jobData = blendProbeJobData[index];
    SphericalHarmonicsL2 shL2;
    Vector4f outCoefficients[SphericalHarmonics::kColorChannelCount];

    DebugAssert(jobData.context.data);

    int tetIndex = jobData.rendererTetIndex;
    for (dynamic_array<BlendProbesJobInput::ProbeData>::iterator it = jobData.probeData.begin(); it != jobData.probeData.end(); ++it)
    {
        BlendProbesJobInput::ProbeData& probeData = *it;
        LightProbeSamplingCoordinates samplingCoord;

        CalculateLightProbeSamplingCoordinates(jobData.context, probeData.worldPosition, tetIndex, samplingCoord);
        InterpolateLightProbeCoefficients(jobData.context, samplingCoord, shL2);

        tetIndex = samplingCoord.tetrahedronIndex;

        Vector4f probeOcclusionMask(1.0f, 1.0f, 1.0f, 1.0);
        GetInterpolatedLightOcclusionMask(jobData.context, samplingCoord, probeOcclusionMask);

#if UNITY_EDITOR
        // We need the SphericalHarmonicsL2 coefficients, position and occlusion in the editor to display the light probes in the Gizmo
        probeData.shL2Coeffs        = shL2;
        probeData.occlusionMask     = probeOcclusionMask;
#endif
        GetShaderSHL1CoeffsFromNormalizedSH(shL2, outCoefficients);

        // Copy into texture data, stick all RGB channels and occlusion into one texture
        jobData.texData[probeData.shCoeffTexDataOffsetR] = outCoefficients[0];
        jobData.texData[probeData.shCoeffTexDataOffsetG] = outCoefficients[1];
        jobData.texData[probeData.shCoeffTexDataOffsetB] = outCoefficients[2];
        jobData.texData[probeData.probeOcclusionOffset] = GetShaderProbeOcclusionMask(probeOcclusionMask);
    }
}

void LightProbeProxyVolumeManager::BlendLightProbes(LightProbeProxyVolume& proxyVolume)
{
    UInt32 resX, resY, resZ;
    proxyVolume.GetResolution(resX, resY, resZ);

    const Vector3f invResolution(1.0f / resX, 1.0f / resY, 1.0f / resZ);

    // Get a new set of SH coefficient textures
    SwapVolumeTextureSets(proxyVolume);

    //////////////////////////////////////////////////////////////////////////////////
    // Prepare multi-threaded data

    // Get image data pointers for 3D textures before issuing jobs. Jobs will write into 3D textures(system memory).
    Texture3D* shCoeffTex = proxyVolume.GetSHCoefficientsTexture();
    DebugAssert(shCoeffTex);

    Vector4f* shCoeffTexData = (Vector4f*)shCoeffTex->GetImageDataPointer();
    DebugAssert(shCoeffTexData);

    const UInt32 shCoeffTexDataSize = shCoeffTex->GetImageDataSize();

    // Fill job info
    const UInt32 maxProbeBlendsPerJob = 64;
    const UInt32 jobCount = static_cast<UInt32>(ceil(static_cast<float>(resX * resY * resZ) / static_cast<float>(maxProbeBlendsPerJob)));

    dynamic_array<BlendProbesJobInput> blendProbesJobData(kMemTempAlloc);

    LightProbeContext context;
    context.Init(GetLightmapSettings(), GetRenderSettings());

    int tetIndex = -1;
    LightProbeProxyVolumeUtils::FindTetrahedronIndex(*proxyVolume.GetTransform(), tetIndex);
    for (UInt32 i = 0; i < jobCount; i++)
    {
        BlendProbesJobInput& jobInput = blendProbesJobData.push_back_construct();
        jobInput.rendererTetIndex = tetIndex;
        jobInput.context = context;
        jobInput.texData = shCoeffTexData;
    }

    // Compute interpolated probe positions
    const Vector3f half(0.5f, 0.5f, 0.5f);
    const AABB aabb = proxyVolume.GetProbeAABB();
    const Vector3f aabbMin = aabb.CalculateMin();
    Matrix4x4f transform;
    const bool transformProbePos = proxyVolume.GetLocalToWorldMatrix(transform);
    UInt32 jobIndex = 0;

    for (UInt32 z = 0; z < resZ; z++)
    {
        for (UInt32 y = 0; y < resY; y++)
        {
            for (UInt32 x = 0; x < resX; x++)
            {
                Vector3f nodeIndex, localPosition, localOffset;

                nodeIndex.Set(static_cast<float>(x), static_cast<float>(y), static_cast<float>(z));
                nodeIndex += half;

                localOffset = 2.0f * aabb.GetExtent();
                localOffset.Scale(nodeIndex);
                localOffset.Scale(invResolution);

                localPosition = aabbMin + localOffset;

                BlendProbesJobInput::ProbeData& probeData = blendProbesJobData[jobIndex].probeData.push_back();
                probeData.worldPosition = transformProbePos ? transform.MultiplyPoint3(localPosition) : localPosition;

                // Pack together into one atlas all the SH coefficients for all the channels and probe occlusion
                const UInt32 probeTexDataOffset = 4 * resX * resY * z + 4 * resX * y + x;
                probeData.shCoeffTexDataOffsetR = probeTexDataOffset;
                DebugAssert(probeData.shCoeffTexDataOffsetR * sizeof(Vector4f) < shCoeffTexDataSize);

                probeData.shCoeffTexDataOffsetG = probeTexDataOffset + resX;
                DebugAssert(probeData.shCoeffTexDataOffsetG * sizeof(Vector4f) < shCoeffTexDataSize);

                probeData.shCoeffTexDataOffsetB = probeTexDataOffset + 2 * resX;
                DebugAssert(probeData.shCoeffTexDataOffsetB * sizeof(Vector4f) < shCoeffTexDataSize);

                probeData.probeOcclusionOffset = probeTexDataOffset + 3 * resX;
                DebugAssert(probeData.probeOcclusionOffset * sizeof(Vector4f) < shCoeffTexDataSize);

                if (blendProbesJobData[jobIndex].probeData.size() == maxProbeBlendsPerJob)
                {
                    jobIndex++;
                }
            }
        }
    }

    //////////////////////////////////////////////////////////////////////////////////
    // Run multi-threaded probe interpolation jobs

    JobFence fence;
    ScheduleJobForEach(fence, BlendLightProbesJob, &blendProbesJobData.front(), jobCount);
    SyncFence(fence);

#if UNITY_EDITOR

    //////////////////////////////////////////////////////////////////////////////////
    // Gather data used for Gizmo rendering

    proxyVolume.GetEditorData().clear();

    for (UInt32 i = 0; i < jobCount; i++)
    {
        BlendProbesJobInput& jobData = blendProbesJobData[i];

        for (UInt32 p = 0; p < jobData.probeData.size(); p++)
        {
            LightProbeProxyVolume::LightProbeEditorData& data = proxyVolume.GetEditorData().push_back();
            data.shL2Coeffs         = jobData.probeData[p].shL2Coeffs;
            data.worldPosition      = jobData.probeData[p].worldPosition;
            data.occlusionMask      = jobData.probeData[p].occlusionMask;
        }
    }
#endif

    for (UInt32 i = 0; i < jobCount; i++)
    {
        BlendProbesJobInput& jobInput = blendProbesJobData[i];
        jobInput.probeData.clear();
    }
}

void LightProbeProxyVolumeManager::UpdateBoundingBox(LightProbeProxyVolume& proxyVolume)
{
    AABB aabb;

    proxyVolume.ValidateBoundingBoxSettings();

    switch (proxyVolume.m_BoundingBoxMode)
    {
        case LightProbeProxyVolume::kBBModeAutomaticLocal:
        {
            MinMaxAABB localAABB;
            LightProbeProxyVolumeUtils::ComputeLocalAABBOnHierarchy(*proxyVolume.GetTransform(), localAABB);
            aabb = AABB(localAABB);
        }
        break;

        case LightProbeProxyVolume::kBBModeAutomaticGlobal:
        {
            MinMaxAABB globalAABB;
            LightProbeProxyVolumeUtils::ComputeGlobalAABBOnHierarchy(*proxyVolume.GetTransform(), globalAABB);
            aabb = AABB(globalAABB);
        }
        break;

        case LightProbeProxyVolume::kBBModeCustom:
        {
            aabb = AABB(Vector3f::zero, 0.5f * proxyVolume.m_BoundingBoxSize);
        }
        break;

        default:
            AssertMsg(false, "Unhandled bounding box mode");
    }

    proxyVolume.m_AABB = aabb;

    // Get a world aligned AABB(in the case of Automatic Global, the AABB is already world-aligned)
    Matrix4x4f worldMatrix;
    proxyVolume.GetLocalToWorldMatrix(worldMatrix);

    AABB globalAABB;
    TransformAABBSlow(aabb, worldMatrix, globalAABB);

    if ((proxyVolume.GetRefreshMode() == LightProbeProxyVolume::kAutomatic) && ((proxyVolume.m_GlobalAABBCenter != globalAABB.GetCenter() || (proxyVolume.m_GlobalAABBExtents != globalAABB.GetExtent()))))
        proxyVolume.SetDirtyFlag(true);

    proxyVolume.m_GlobalAABBCenter = globalAABB.GetCenter();
    proxyVolume.m_GlobalAABBExtents = globalAABB.GetExtent();
}

void LightProbeProxyVolumeManager::UpdateResolution(LightProbeProxyVolume& proxyVolume)
{
    const AABB& aabb = proxyVolume.GetAABB();
    Vector3f aabbSize = 2.0f * aabb.GetExtent();

    if ((proxyVolume.m_BoundingBoxMode == LightProbeProxyVolume::kBBModeAutomaticLocal) ||
        (proxyVolume.m_BoundingBoxMode == LightProbeProxyVolume::kBBModeCustom))
    {
        aabbSize = Abs(Scale(proxyVolume.GetTransform()->GetLocalScale(), aabbSize));
    }

    UInt32 finalResolutionX, finalResolutionY, finalResolutionZ;
    if (proxyVolume.m_ResolutionMode == LightProbeProxyVolume::kResModeAutomatic)
    {
        const float probeDensity = FloatClamp(proxyVolume.m_ResolutionProbesPerUnit, kLightProbeVolumeMinProbeDensity, kLightProbeVolumeMaxProbeDensity);
        finalResolutionX = std::max(1u, ClosestPowerOfTwo(static_cast<UInt32>(aabbSize.x * probeDensity + 0.5f)));
        finalResolutionY = std::max(1u, ClosestPowerOfTwo(static_cast<UInt32>(aabbSize.y * probeDensity + 0.5f)));
        finalResolutionZ = std::max(1u, ClosestPowerOfTwo(static_cast<UInt32>(aabbSize.z * probeDensity + 0.5f)));
    }
    else
    {
        finalResolutionX = std::max(1u, proxyVolume.m_ResolutionX);
        finalResolutionY = std::max(1u, proxyVolume.m_ResolutionY);
        finalResolutionZ = std::max(1u, proxyVolume.m_ResolutionZ);
    }

    if ((proxyVolume.GetRefreshMode() == LightProbeProxyVolume::kAutomatic) &&
        ((finalResolutionX != proxyVolume.m_FinalResolutionX) || (finalResolutionY != proxyVolume.m_FinalResolutionY) || (finalResolutionZ != proxyVolume.m_FinalResolutionZ)))
        proxyVolume.SetDirtyFlag(true);

    proxyVolume.m_FinalResolutionX = std::min(kLightProbeVolumeMaxTextureResolution, finalResolutionX);
    proxyVolume.m_FinalResolutionY = std::min(kLightProbeVolumeMaxTextureResolution, finalResolutionY);
    proxyVolume.m_FinalResolutionZ = std::min(kLightProbeVolumeMaxTextureResolution, finalResolutionZ);
}

void LightProbeProxyVolumeManager::AllocateVolumeTextures(LightProbeProxyVolume& proxyVolume)
{
    static const char* textureName = {"LPPV_SHCoefficients"};
    for (UInt32 textureSet = 0; textureSet < LightProbeProxyVolume::kMaxSHCoeffsTextureSets; textureSet++)
    {
        if (proxyVolume.m_SHCoeffsTex[textureSet] &&
            (proxyVolume.m_FinalResolutionX * 4 != proxyVolume.m_SHCoeffsTex[textureSet]->GetDataWidth() ||
             proxyVolume.m_FinalResolutionY != proxyVolume.m_SHCoeffsTex[textureSet]->GetDataHeight() ||
             proxyVolume.m_FinalResolutionZ != proxyVolume.m_SHCoeffsTex[textureSet]->GetTextureLayerCount()))
        {
            DestroySingleObject(proxyVolume.m_SHCoeffsTex[textureSet]);
            proxyVolume.m_SHCoeffsTex[textureSet] = NULL;
        }

        if (!proxyVolume.m_SHCoeffsTex[textureSet])
        {
            proxyVolume.m_SHCoeffsTex[textureSet] = AllocateVolumeTexture(proxyVolume, textureName);
            DebugAssert(proxyVolume.m_SHCoeffsTex[textureSet]);
        }

#if UNITY_EDITOR
        proxyVolume.m_SHCoeffsTex[textureSet]->SetFilterMode(GetLightmapEditorSettings().GetFilterMode());
#endif
    }
}

void LightProbeProxyVolumeManager::SwapVolumeTextureSets(LightProbeProxyVolume& proxyVolume)
{
    UInt32& textureSet = proxyVolume.m_SHCoeffsTexSetIndex;
    textureSet = (textureSet + 1) % 2;
}

void LightProbeProxyVolumeManager::OnLightProbesUpdate()
{
    for (LightProbeProxyVolumeArray::iterator it = m_LightProbeVolumes.begin(); it != m_LightProbeVolumes.end(); ++it)
    {
        LightProbeProxyVolume& proxyVolume = **it;
        if (proxyVolume.GetRefreshMode() == LightProbeProxyVolume::kAutomatic)
            proxyVolume.SetDirtyFlag(true);
    }
}

void LightProbeProxyVolumeManager::UpdateProxyVolume(LightProbeProxyVolume& proxyVolume, size_t index)
{
    proxyVolume.SetHandle(index);

    UpdateBoundingBox(proxyVolume);
    UpdateResolution(proxyVolume);

    if (!m_UpdateContext.isProxyVolumeSupported)
    {
#if UNITY_EDITOR
        proxyVolume.GetEditorData().clear();
#endif
        return;
    }

    bool updateProbeVolume = false;

#if UNITY_EDITOR
    if (!IsWorldPlaying())
        updateProbeVolume = true;
#endif

    updateProbeVolume = updateProbeVolume || (proxyVolume.GetRefreshMode() == LightProbeProxyVolume::kEveryFrame) || proxyVolume.GetDirtyFlag();

    if (updateProbeVolume)
    {
        AllocateVolumeTextures(proxyVolume);
        BlendLightProbes(proxyVolume);
        UpdateSHCoeffsTextureData(proxyVolume);
        proxyVolume.SetDirtyFlag(false);
    }
}
