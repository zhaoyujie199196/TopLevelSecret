#pragma once

#include "Runtime/Threads/Thread.h"
#include "Runtime/Utilities/LinkedList.h"

enum AssetNotify
{
    kAssetNotifyAssetDeleted,
    kAssetNotifyBoundsChanged,
};

class AssetUser
{
public:
    virtual void OnAssetDeleted() = 0;
    virtual void OnAssetBoundsChanged() = 0;
};

class AssetUsers
{
public:
    void Notify(AssetNotify notify)
    {
        ASSERT_RUNNING_ON_MAIN_THREAD;
        AssetUserList::iterator i, iEnd;
        switch (notify)
        {
            case kAssetNotifyAssetDeleted:
                for (i = m_Users.begin(), iEnd = m_Users.end(); i != iEnd; ++i)
                    (*i)->OnAssetDeleted();
                break;
            case kAssetNotifyBoundsChanged:
                for (i = m_Users.begin(), iEnd = m_Users.end(); i != iEnd; ++i)
                    (*i)->OnAssetBoundsChanged();
                break;
            default:
                AssertString("unknown notification");
        }
    }

    void NotifyAndClear(AssetNotify notify) { Notify(notify); m_Users.clear(); }
    void AddUser(ListNode<AssetUser>& node) { m_Users.push_back(node); }

protected:
    typedef List<ListNode<AssetUser> > AssetUserList;
    AssetUserList m_Users;
};
