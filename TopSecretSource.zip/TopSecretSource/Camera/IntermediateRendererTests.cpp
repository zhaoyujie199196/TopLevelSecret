#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "IntermediateRenderer.h"
#include "Runtime/GfxDevice/SharedGfxBuffer.h"
#include "Runtime/Math/Matrix4x4.h"
#include "Runtime/Testing/Testing.h"
#include "Runtime/UI/Canvas.h"
#include "Runtime/Misc/GameObjectUtility.h"


REGRESSION_TEST_SUITE(IntermediateRendererRegressionTests)
{
    struct CanvasBatchFixture
    {
        CanvasBatchFixture()
        {
            vertexBuffer = SharedGfxBuffer::Create(NULL);
            indexBuffer = SharedGfxBuffer::Create(NULL);
            canvasBatch = new CanvasBatchIntermediateRenderer();
        }

        ~CanvasBatchFixture()
        {
            delete canvasBatch;
            CHECK_EQUAL(1, vertexBuffer->GetRefCount());
            CHECK_EQUAL(1, indexBuffer->GetRefCount());
            vertexBuffer->Release();
            indexBuffer->Release();
        }

        void InitializeCanvas(UI::Canvas* canvas)
        {
            Matrix4x4f matrix = Matrix4x4f::identity;
            AABB aabb(Vector3f::zero, Vector3f::one);
            canvasBatch->Initialize(canvas, vertexBuffer, NULL, 12, indexBuffer, matrix, 0, aabb, NULL, 0, kShadowCastingOff, false);
        }

        SharedGfxBuffer* vertexBuffer;
        SharedGfxBuffer* indexBuffer;
        CanvasBatchIntermediateRenderer* canvasBatch;
    };

    TEST_FIXTURE(CanvasBatchFixture, CanvasBatchRenderer_Initialize_AddsVertexIndexBufferReferences)
    {
        // initially VB/IB just has one refcount
        CHECK_EQUAL(1, vertexBuffer->GetRefCount());
        CHECK_EQUAL(1, indexBuffer->GetRefCount());

        // initializing canvas batch renderer with VB/IB should add a reference to them
        InitializeCanvas(NULL);
        CHECK_EQUAL(2, vertexBuffer->GetRefCount());
        CHECK_EQUAL(2, indexBuffer->GetRefCount());
    }

    TEST_FIXTURE(CanvasBatchFixture, CanvasBatchRenderer_CleanupSubBatchProperties_CalledTwice_SharedGfxBuffers_RefCounts_EqualOne)
    {
        GameObject* root = &CreateGameObject("", "Canvas", NULL);
        UI::Canvas* canvas = &root->GetComponent<UI::Canvas>();
        InitializeCanvas(canvas);
        canvas->MainThreadCleanup();
        DestroyObjectHighLevel(root);
    }
} // REGRESSION_TEST_SUITE(IntermediateRendererRegressionTests)

#endif // ENABLE_UNIT_TESTS
