#ifndef LIGHT_H
#define LIGHT_H

#include "SharedLightData.h"
#include "Runtime/GameCode/Behaviour.h"
#include "Runtime/Utilities/LinkedList.h"

class Texture;
class Flare;
class GfxDevice;

class Light : public Behaviour, public ListElement
{
    REGISTER_CLASS_TRAITS(kTypeIsSealed);
    REGISTER_CLASS(Light);
    DECLARE_OBJECT_SERIALIZE();
public:
    Light(MemLabelId label, ObjectCreationMode mode);
    // ~Light(); declared-by-macro

    static void InitializeClass();
    static void CleanupClass();

    virtual void Reset();
    virtual void MainThreadCleanup();

    // System interaction
    virtual void AddToManager();
    virtual void RemoveFromManager();
    virtual void CheckConsistency();
    virtual void AwakeFromLoad(AwakeFromLoadMode mode);

    void TransformChanged();


    LightType GetLightType() const { return GetData().GetLightType(); }
    void SetLightType(LightType type);

    /// Get the render mode hint for this light
    LightRenderMode GetRenderMode() const { return GetData().GetRenderMode(); }
    void SetRenderMode(LightRenderMode mode)   { GetWritableData().m_RenderMode = mode; SetDirty(); }

    LightmapBakeType GetBakeType() const { return GetData().GetLightBakeType(); }
    void SetBakeType(LightmapBakeType mode) { GetWritableData().m_Lightmapping = mode; SetDirty(); }

    LightmappingMask GetLightmappingMaskForRuntime() const { return GetData().GetLightmappingMaskForRuntime(); }

    void SetIsBakedFromScript(bool isBaked);

    bool IsActuallyBaked() const { return GetData().IsActuallyBaked(); }
    bool IsOcclusionSeparatelyBaked() const { return GetData().IsOcclusionSeparatelyBaked(); }
    void SetBakingOutput(const LightBakingOutput& output) { GetWritableData().m_BakingOutput = output; SetDirty();  }
    const LightBakingOutput& GetBakingOutput() const { return GetData().m_BakingOutput; }

    /// Get the full range of the light.
    float GetRange() const { return GetData().GetRange(); }
    void SetRange(float range) { GetWritableData().m_Range = std::max(0.0F, range); SetDirty(); Precalc(); }

    void SetAreaSize(const Vector2f& areaSize) { GetWritableData().m_AreaSize = areaSize; SetDirty(); Precalc(); }
    Vector2f GetAreaSize() const { return GetData().GetAreaSize(); }

    /// Get the spot angle in degrees.
    float GetSpotAngle() const { return GetData().GetSpotAngle(); }
    void SetSpotAngle(float angle) { GetWritableData().m_SpotAngle = angle; CheckConsistency(); SetDirty(); Precalc(); }

    float GetCookieSize() const { return GetData().GetCookieSize(); }
    void SetCookieSize(float size) { GetWritableData().m_CookieSize = size; CheckConsistency(); SetDirty(); Precalc(); }

    // range * this value = end side length
    float GetCotanHalfSpotAngle() const { return GetData().GetCotanHalfSpotAngle(); }
    // range * this value = diagonal side length
    float GetInvCosHalfSpotAngle() const { return GetData().GetInvCosHalfSpotAngle(); }

    /// Get/set the cookie used for the light
    void SetCookie(Texture *tex);
    Texture *GetCookie() const { return GetData().GetCookie(); }
    bool HasCookie() const { return GetData().HasCookie(); }

    /// Get/set the lens flare used
    void SetFlare(Flare *flare);
    Flare *GetFlare() const;

    const ColorRGBAf& GetColor() const { return GetData().GetColorFilter(); }
    void SetColor(const ColorRGBAf& c);

    ColorRGBAf GetFinalLightColorActiveSpace() const { return GetData().GetFinalLightColorActiveSpace(); }
    math::float4 GetFinalLightColorLinearSpace() const { return GetData().GetFinalLightColorLinearSpace(); }

    float GetColorTemperature() const { return GetData().GetColorTemperature(); }
    void SetColorTemperature(float cct) { GetWritableData().m_ColorTemperature = cct; SetDirty(); }

    bool GetUseColorTemperature() const { return GetData().GetUseColorTemperature(); }
    void SetUseColorTemperature(bool useCct) { GetWritableData().m_UseColorTemperature = useCct; SetDirty(); }

    float GetIntensity() const { return GetData().GetIntensity(); }
    void SetIntensity(float i);

    float GetShadowStrength() const { return GetData().GetShadowStrength(); }
    void  SetShadowStrength(float f) { GetWritableData().m_Shadows.m_Strength = f; SetDirty(); }
    ShadowType GetShadowType() const { return GetData().GetShadowType(); }
    void  SetShadowType(ShadowType v);
    int   GetShadowCustomResolution() const { return GetData().GetShadowCustomResolution(); }
    void  SetShadowCustomResolution(int v) { GetWritableData().m_Shadows.m_CustomResolution = v; SetDirty(); }
    int   GetShadowResolution() const { return GetData().GetShadowResolution(); }
    void  SetShadowResolution(int v) { GetWritableData().m_Shadows.m_Resolution = v; SetDirty(); }
    float GetShadowBias() const { return GetData().GetShadowBias(); }
    void  SetShadowBias(float v) { GetWritableData().m_Shadows.m_Bias = v; SetDirty(); }
    float GetShadowNormalBias() const { return GetData().GetShadowNormalBias(); }
    void  SetShadowNormalBias(float v) { GetWritableData().m_Shadows.m_NormalBias = v; SetDirty(); }
    float GetShadowNearPlane() const { return GetData().GetShadowNearPlane(); }
    void  SetShadowNearPlane(float v) { GetWritableData().m_Shadows.m_NearPlane = v; SetDirty(); }

    bool GetDrawHalo() const { return GetData().m_DrawHalo; }
    void SetDrawHalo(bool v) { GetWritableData().m_DrawHalo = v; SetDirty(); SetupHalo(); }

    int GetFinalShadowResolution() const { return GetData().GetFinalShadowResolution(); }

    #if UNITY_EDITOR
    float GetShadowRadius() const { return GetData().m_ShadowRadius; }
    void SetShadowRadius(float radius) { GetWritableData().m_ShadowRadius = radius; }
    float GetShadowAngle() const { return GetData().m_ShadowAngle; }
    void SetShadowAngle(float angle) { GetWritableData().m_ShadowAngle = angle; }
    #endif
    float GetBounceIntensity() const { return GetData().m_BounceIntensity; }
    void SetBounceIntensity(float intensity) { GetWritableData().m_BounceIntensity = intensity; }

    int GetFlareHandle() const { return m_FlareHandle; }
    void SetFlareHandle(int handle) { m_FlareHandle = handle; }

    // Set up the halo for the light.
    void SetupHalo();
    // Set up the flare for the light.
    void SetupFlare();

    UInt32 GetCullingMask() const { return GetData().GetCullingMask(); }
    void SetCullingMask(UInt32 mask) { GetWritableData().m_CullingMask.m_Bits = mask; SetDirty(); }

    // Precalc all non-changing shaderlab values.
    void Precalc();

    const Matrix4x4f& GetLocalToWorldMatrix() const { return GetData().GetLocalToWorldMatrix(); }
    const Matrix4x4f& GetWorldToLocalMatrix() const { return GetData().GetWorldToLocalMatrix(); }
    const Vector3f GetWorldDirection() const { return GetData().GetWorldDirection(); }
    const Vector3f GetWorldPosition() const { return GetData().GetWorldPosition(); }

    const GfxVertexLight& GetVertexLightData() const { return GetData().m_VertexLightData; }

    // Rendering command buffers set for specified light event
    void AddCommandBuffer(RenderLightEventType type, RenderingCommandBuffer* buffer, UInt32 shadowPassMask);
    void RemoveCommandBuffer(RenderLightEventType type, RenderingCommandBuffer* buffer) { GetWritableData().m_RenderEvents.RemoveCommandBuffer(type, buffer); }
    void RemoveCommandBuffers(RenderLightEventType type) { GetWritableData().m_RenderEvents.RemoveCommandBuffers(type); }
    void RemoveAllCommandBuffers() { GetWritableData().m_RenderEvents.RemoveAllCommandBuffers(); }
    const RenderEventsContext::CommandBufferArray& GetCommandBuffers(RenderLightEventType type) const { return GetData().GetCommandBuffers(type); }
    int GetCommandBufferCount() const { return GetData().GetCommandBufferCount(); }

    const SharedLightData* AcquireSharedLightData() const
    {
        m_LightData->AddRef();
        return m_LightData;
    }

    // Be careful not to pass this to jobs - use AcquireSharedLightData if you need thread-safety
    const SharedLightData& GetDataNoAcquire() const { return *m_LightData; }

    const SharedLightData& GetData() const { return *m_LightData; }

private:
    template<class TransferFunction>
    void RemapLightmapping(TransferFunction& transfer);

    SharedLightData& GetWritableData() { UnshareLightData(); return *m_LightData; }
    void UnshareLightData() const;

    mutable SharedLightData* m_LightData;
    PPtr<Flare> m_Flare;                ///< Does the light have a flare?

    #if UNITY_EDITOR
    float   m_ShadowRadius;         // radius of the light source for lightmapper shadow calculations (point and spot lights)
    float   m_ShadowAngle;          // angle of the cone for lightmapper shadow rays (directional lights)
    #endif

#if DOXYGEN
    int m_Lightmapping; ///< enum { Realtime=4, Mixed=1, Baked=2 }
#endif

    float   m_BounceIntensity;      // a multiplier for the indirect light

    int     m_HaloHandle, m_FlareHandle;
};

#endif
