#pragma once

#include "UnityPrefix.h"
#include "Runtime/Utilities/EnumFlags.h"
#include "Runtime/Camera/ShaderReplaceData.h"

class Camera;

namespace Umbra
{ class DebugRenderer; }

enum CullFlag
{
    kCullFlagNone                           = 0,
    kCullFlagForceEvenIfCameraIsNotActive   = 1 << 0,
    kCullFlagOcclusionCull                  = 1 << 1,
    kCullFlagNeedsLighting                  = 1 << 2,
    kCullFlagStereo                         = 1 << 3,
};

struct CameraCullingParameters
{
    Camera*               cullingCamera;
    ShaderReplaceData     explicitShaderReplace;
    CullFlag              cullFlag;
    Umbra::DebugRenderer* umbraDebugRenderer;
    UInt32                umbraDebugFlags;

    CameraCullingParameters(Camera& cam, CullFlag flag)
    {
        cullingCamera = &cam;
        cullFlag = flag;
        umbraDebugRenderer = NULL;
        umbraDebugFlags = 0;
    }
};

ENUM_FLAGS(CullFlag);
