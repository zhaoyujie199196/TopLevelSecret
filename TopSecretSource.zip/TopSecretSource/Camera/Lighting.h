#ifndef LIGHTING_H
#define LIGHTING_H

#include "Runtime/Utilities/EnumFlags.h"

// Light type
enum LightType
{
    kLightSpot,
    kLightDirectional,
    kLightPoint,
    kLightArea,
    kLightTypeLast = kLightArea // keep this last
};

const int kLightTypeCount = kLightTypeLast + 1;

// How to render a light
enum LightRenderMode
{
    kLightRenderModeAuto,
    kLightRenderModeImportant,
    kLightRenderModeNotImportant,
    kLightRenderModeLast =  kLightRenderModeNotImportant// keep this last!
};

const int kLightRenderModeCount = kLightRenderModeLast + 1;

enum LightmapMixedBakeMode
{
    kBakeIndirectOnly,
    kBakeLightmapsWithSubtractiveShadows,
    kBakeDirectAndIndirect,
    kBakeShadowMaskAndIndirect,
};

enum LightmapBakeType
{
    kLightRealtime  = 1 << 2,   // Light is realtime
    kLightBaked     = 1 << 1,   // light will always be fully baked
    kLightMixed     = 1 << 0,   // depends on selected LightmapMixedBakeMode
};

// Keep this in sync with LightEditor.cs::kLightmappingModes
enum LightmappingMask
{
    kLightmappingDirectRealtime                 = 1 << 0,
    kLightmappingDirectBaked                    = 1 << 1,
    kLightmappingDirectBakedSubtractiveShadow   = 1 << 2,
    kLightmappingDirectShadowMask               = 1 << 3,

    kLightmappingIndirectRealtimeGI     = 1 << 16,
    kLightmappingIndirectBakedGI        = 1 << 17,

    kLightmappingStaticBakedMask    = kLightmappingDirectBaked | kLightmappingIndirectBakedGI,
    kLightmappingRealtimeGIMask     = kLightmappingDirectRealtime | kLightmappingIndirectRealtimeGI,

    kLightmappingNoneMask               = 0,

    kLightmappingAllMask =
        kLightmappingDirectRealtime | kLightmappingDirectBaked | kLightmappingDirectBakedSubtractiveShadow | kLightmappingDirectShadowMask |
        kLightmappingIndirectRealtimeGI | kLightmappingIndirectBakedGI
};
ENUM_FLAGS(LightmappingMask);


enum LightmapModeForRender
{
    // Light should be rendered realtime
    // (Enlighten may or may not have dynamic gi for this light, but this never impacts any renderloops in regards to lights)
    kLightmapModeRealtime = 0,

    // dynamic (non-lightmapped) renderers should receive this light & should cast shadows.
    kLightmapModeRealtimeDynamicObjectsOnly = 1,

    // The light has been baked into lightmaps or for some other reason should not be rendered.
    kLightmapModeDontRenderLight = 2
};

enum ShadowType
{
    kShadowNone = 0,
    kShadowHard,
    kShadowSoft,
    kShadowTypeCount
};

// Match LightShadowResolution enum on C# side
enum LightShadowResolution
{
    kLightShadowResolutionFromQualitySettings = -1,
    kLightShadowResolutionLow = 0,
    kLightShadowResolutionMedium = 1,
    kLightShadowResolutionHigh = 2,
    kLightShadowResolutionVeryHigh = 3,
    kLightShadowResolutionCount = 4
};

inline bool IsSoftShadow(ShadowType shadowType)
{
    return (shadowType == kShadowSoft);
}

#endif
