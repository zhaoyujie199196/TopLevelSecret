#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS_WITH_FAKES

#include "Runtime/Testing/Testing.h"
#include "Runtime/Testing/TestFixtures.h"
#include "Runtime/BaseClasses/GameObject.h"
#include "Runtime/Graphics/DisplayManager.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/Camera/Camera.h"
#include "Runtime/Camera/CullResults.h"
#include "Runtime/Jobs/Jobs.h"
#include "Runtime/Graphics/RenderBufferManager.h"
#include "Runtime/Graphics/SpriteFrame.h"
#include "Runtime/Graphics/Texture2D.h"
#include "Runtime/Graphics/CubemapTexture.h"
#include "Runtime/Graphics/Mesh/SpriteRenderer.h"
#include "Runtime/Camera/LightProbeProxyVolume.h"
#include "Runtime/Camera/CameraStack.h"
#include "Runtime/Camera/IntermediateRenderer.h"

#if UNITY_EDITOR
#include "Runtime/Shaders/ShaderTags.h"
#include "Editor/Platform/Interface/EditorWindows.h"
#include "Runtime/Testing/Faking.h"
#include "Runtime/GfxDevice/fake/GfxDeviceFake.h"
#endif // #if UNITY_EDITOR

UNIT_TEST_SUITE(CameraUnitTests)
{
    static const float epsilon = 0.001f;

    class Fixture : public ObjectTestFixture<Camera>
    {
    public:
        FAKE_METHOD(Camera, ShouldUseVRFieldOfView, bool());

        float GetFovSafe()
        {
            // Camera::GetFov will dereference the IVRDevice if ShouldUseVRFieldOfView returns true.
            // To avoid null pointers and avoid having to fake out the IVRDevice, we can instead use
            // GetTemporarySettings which always retrieves the value of the internal state.
            CameraTemporarySettings settings;
            m_ObjectUnderTest->GetTemporarySettings(settings);
            return settings.fieldOfView;
        }
    };

    TEST_FIXTURE(Fixture, SetFovLogsWarningAndIgnoresValueIfVrOverridesFieldOfView)
    {
        Camera_ShouldUseVRFieldOfView.Returns(true);
        EXPECT(Warning, "Cannot set field of view on this camera while VR is enabled.");
        m_ObjectUnderTest->SetFov(23.0f);
        CHECK_CLOSE(60.0f, GetFovSafe(), epsilon);
    }

    TEST_FIXTURE(Fixture, SetFovAcceptsValueIfVrDoesNotOverrideFieldOfView)
    {
        Camera_ShouldUseVRFieldOfView.Returns(false);
        m_ObjectUnderTest->SetFov(23.0f);
        CHECK_CLOSE(23.0f, GetFovSafe(), epsilon);
    }
}

INTEGRATION_TEST_SUITE(CameraTests)
{
    // We had a bug where camera with non-existing target display would automatically and silently disabled.
    // This was confusing the users (especially if they want to modify the target display from script later),
    // and is not very useful -- particularly becuase higher level code already completely skips rendering
    // any cameras that have non-existing target displays on them.
    TEST(CameraWithNonExistingTargetDisplay_DoesNotGetSilentlyDisabled)
    {
#       if UNITY_EDITOR
        FAKE_STATIC_METHOD(GUIView, GetMainGameViewSize, Vector2f());
        GUIView_GetMainGameViewSize.Returns(Vector2f(1.0f, 1.0f));
#       endif // #if UNITY_EDITOR

        GameObject* go = &CreateGameObject("MainCamera", "Camera", NULL);
        Camera& cam = go->GetComponent<Camera>();
        cam.SetTargetDisplay(MAX_DISPLAYS_SUPPORTED); // target display to one right after max # we support

        go->Deactivate();
        go->Activate();
        CHECK(cam.GetEnabled());
        DestroyObjectHighLevel(go);
    }

    TEST(IntermediateRenderersAreClearedWhenDisabled)
    {
#       if UNITY_EDITOR
        FAKE_STATIC_METHOD(GUIView, GetMainGameViewSize, Vector2f());
        GUIView_GetMainGameViewSize.Returns(Vector2f(1.0f, 1.0f));
#       endif // #if UNITY_EDITOR
        GameObject* go = &CreateGameObject("MainCamera", "Camera", NULL);
        Camera& cam = go->GetComponent<Camera>();

        // Deletion of IntermediateRenderer will happen in the clean up of the intermediateList.
        IntermediateRenderer* renderer = new IntermediateRenderer();
        cam.GetIntermediateRenderers().Add(renderer);

        cam.Deactivate(kNormalDeactivate);

        CHECK_EQUAL(0, cam.GetIntermediateRenderers().GetRendererCount());
        CHECK_EQUAL(0, cam.GetIntermediateRenderers().GetRendererCount());

        DestroyObjectHighLevel(go);
    }

#if UNITY_EDITOR

    // This test uses GfxDeviceFake so we can invoke Camera::Render without
    // graphics being really available.  This device is not available on builds
    // other than editor, though, so we're limiting where the test runs.

    void RenderPlaneCallback(Camera& camera, void* target)
    {
        __FAKEABLE_FUNCTION__(RenderPlaneCallback, (camera, target));
    }

    TEST(Render_InvokesPostRenderCallback)
    {
        FAKE_STATIC_METHOD(GUIView, GetMainGameViewSize, Vector2f());
        GUIView_GetMainGameViewSize.Returns(Vector2f(1.0f, 1.0f));

        // Using the null graphics device for renders in these tests to avoid GL
        // errors.  We're only testing whether callbacks are invoked and don't
        // care about the render result itself.
        GfxDeviceFake fakeDevice;

        Camera& mainCamera = CreateGameObject("MainCamera", "Camera", NULL).GetComponent<Camera>();
        FAKE_FUNCTION_WITH_LOCAL_NAME(
            FakeRenderPlaneCallback, RenderPlaneCallback, void(Camera & camera, void* target));

        GetQualitySettings().SetAntiAliasing(1);
        // configure camera
        {
            AutoScopedCameraStackRenderingState scopedStackRenderState(mainCamera);
            // Prepare scene to be rendered
            CullResults cullResults;
            mainCamera.Cull(cullResults);
            ShaderPassContext& shaderPassContext = GetDefaultPassContext();

            // Just so we can check that it is correctly passed back to us in the
            // callback.
            void* const fakeHandler = static_cast<void*>(&fakeDevice);

            // Expecting three callbacks per render.
            mainCamera.AddRenderPlaneCallback(RenderPlaneCallback, fakeHandler, Camera::kBackPlane);
            mainCamera.AddRenderPlaneCallback(RenderPlaneCallback, fakeHandler, Camera::kFrontPlaneOpaque);
            mainCamera.AddRenderPlaneCallback(RenderPlaneCallback, fakeHandler, Camera::kFrontPlaneTransparent);

            mainCamera.Render(cullResults, shaderPassContext, Camera::kRenderFlagNone);
            CHECK_EQUAL(3, FakeRenderPlaneCallback.CallCount());
            CHECK_EQUAL(&mainCamera, &FakeRenderPlaneCallback.LastCallArguments().a1.Get());
            CHECK_EQUAL(fakeHandler, FakeRenderPlaneCallback.LastCallArguments().a2.Get());

            mainCamera.Render(cullResults, shaderPassContext, Camera::kRenderFlagNone);
            CHECK_EQUAL(6, FakeRenderPlaneCallback.CallCount());

            // Removing callback and re-rendering should not trigger callbacks anymore.
            mainCamera.RemoveRenderPlaneCallback(RenderPlaneCallback, fakeHandler, Camera::kBackPlane);
            mainCamera.RemoveRenderPlaneCallback(RenderPlaneCallback, fakeHandler, Camera::kFrontPlaneOpaque);
            mainCamera.RemoveRenderPlaneCallback(RenderPlaneCallback, fakeHandler, Camera::kFrontPlaneTransparent);

            mainCamera.Render(cullResults, shaderPassContext, Camera::kRenderFlagNone);
            CHECK_EQUAL(6, FakeRenderPlaneCallback.CallCount());
        }
        DestroyObjectHighLevel(mainCamera.GetGameObjectPtr());
    }

#endif
}

REGRESSION_TEST_SUITE(CameraRegressionTests)
{
    TEST(RenderDisabledCameraIntoTemporaryRT_FollowedByTemporaryRTCleanup_FollowedByRenderToCubemap_DoesNotCrash)
    {
#if UNITY_EDITOR
        FAKE_STATIC_METHOD(GUIView, GetMainGameViewSize, Vector2f());
        GUIView_GetMainGameViewSize.Returns(Vector2f(1.0f, 1.0f));
#endif

        // Create a disabled camera that renders into a RenderTexture (similar to what scene view does)
        GameObject* goDisabledCamera = &CreateGameObject("MainCamera", "Camera", NULL);
        Camera& camDisabled = goDisabledCamera->GetComponent<Camera>();
        camDisabled.SetEnabled(false);
        camDisabled.SetClearFlags(Camera::kSolidColor);
        RenderBufferManager& rbm = GetRenderBufferManager();
        RenderTexture* rt = rbm.GetTempBuffer(128, 128, kDepthFormatNone, kRTFormatARGB32, 0, kRTReadWriteDefault);
        camDisabled.SetTargetTexture(rt);

        // Another camera that will render into a cubemap
        GameObject* goCubeCamera = &CreateGameObject("CubeCamera", "Camera", NULL);
        Camera& camCube = goCubeCamera->GetComponent<Camera>();
        camCube.SetClearFlags(Camera::kSolidColor);
        Cubemap* cubemap = NEW_OBJECT(Cubemap);
        cubemap->Reset();
        cubemap->InitTexture(64, 64, kTexFormatRGBA32, Texture2D::kFlagNone, 6);

        // here goes ugly hack:
        // camCube.StandaloneRenderToCubemap will do RenderBufferManager::GetTempBuffer
        // and after GarbageCollect where we delete rt, GetTempBuffer might get *same* pointer from NEW_OBJECT(RenderTexture)
        // to prevent that we pre-alloc temp buffer with exact same params as needed by StandaloneRenderToCubemap
        // and we will keep it around to guarantee that it will be taken (and there are no valid objects in memory at address in rt)
        // NB: if you run without "-debugallocator" all this might still fail and we will simply read bogus data instead of crashing accessing dangling pointer
        RenderTexture* rt2 = rbm.GetTempBuffer(64, 64, kDepthFormatMin24bits_Stencil, GetGfxDevice().GetDefaultRTFormat(), 0, kRTReadWriteDefault);

        // Render the first camera
        {
            AutoScopedCameraStackRenderingState camDisabledStackState(camDisabled);
            CullResults cullResults;
            camDisabled.Cull(cullResults);
            camDisabled.Render(cullResults, GetDefaultPassContext(), Camera::kRenderFlagNone);
        }

        // Release the target render texture, and cleanup temporary RT pool
        rbm.ReleaseTempBuffer(rt);
        rbm.GarbageCollect(0);
        // Release rt2 only after GC so we keep object around and just mark it free
        rbm.ReleaseTempBuffer(rt2);

        // Now do rendering into a cubemap with the 2nd camera.
        // At one point this was crashing (case 840973) because it was saving + restoring previous camera state,
        // and was trying to access dangling m_CurrentTargetTexture pointer of camDisabled;
        // the actual render texture was already cleaned up by a step above.
        camCube.StandaloneRenderToCubemap(cubemap, 63);

        // Cleanup
        DestroyObjectHighLevel(goDisabledCamera);
        DestroyObjectHighLevel(goCubeCamera);
        DestroyObjectHighLevel(cubemap);
        rbm.GarbageCollect(0);
    }
} // REGRESSION_TEST_SUITE(CameraRegressionTests)


#endif
