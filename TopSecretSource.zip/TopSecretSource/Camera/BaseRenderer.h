#ifndef BASE_RENDERER_H
#define BASE_RENDERER_H

#include "Runtime/BaseClasses/BaseObject.h"
#include "Runtime/Camera/ReflectionProbeTypes.h"
#include "Runtime/Camera/RenderLoops/GlobalLayeringData.h"
#include "Runtime/Camera/SharedRendererData.h"
#include "Runtime/Modules/ExportModules.h"
#include "Runtime/Utilities/Hash128.h"
#include "Runtime/Camera/RenderNodeQueue.h"
#include "Runtime/GfxDevice/GfxDeviceTypes.h"

class InstancedPropInfo;
class Transform;
struct LightProbeContext;
struct LightProbeProxyVolumeContext;
struct CullingOutput;
struct ShadowCullData;

struct BatchInstanceData
{
    UInt32 nodeID;              // 4
    int subsetIndex;            // 4
};

struct RenderMultipleData
{
    const BatchInstanceData*    instances;
    UInt32                      count;
    bool                        enableDynamicBatching;
    bool                        materialDisablesInstancing;
    bool                        enableSpritesBatching;
    InstancedPropInfo*          instancedPropInfo;
};

// Abstract base class for renderers.
class EXPORT_COREMODULE BaseRenderer
{
public:
    BaseRenderer(RendererType type);
    virtual ~BaseRenderer();

    static UInt32 FlattenToRenderQueue(RenderNodeQueue& queue, const DeprecatedSourceData& sourceData);
    virtual UInt32 AddAsRenderNode(RenderNodeQueue& queue, const DeprecatedSourceData& sourceData) { return FlattenToRenderQueue(queue, sourceData); }
    virtual void RendererCullingCallback();

    /// Returns the cached version of TransformInfo.
    #if ENABLE_ASSERTIONS
    virtual void AssertIsTransformInfoUpToDate() const {}
    #endif

    const TransformInfo& GetTransformInfoExpectUpToDate() const
    {
        #if ENABLE_ASSERTIONS
        AssertIsTransformInfoUpToDate();
        #endif

        return m_RendererData.m_TransformInfo;
    }

    const TransformInfo& GetTransformInfoDoNotExpectUpToDate() const { return m_RendererData.m_TransformInfo; }
    TransformInfo& GetWritableTransformInfo() { return m_RendererData.m_TransformInfo; }

    virtual void RendererBecameVisible() { m_RendererData.m_IsVisible = true; }
    virtual void RendererBecameInvisible() { m_RendererData.m_IsVisible = false; }
    virtual int GetLayer() const = 0;

    virtual int GetMaterialCount() const = 0;
    virtual PPtr<Material> GetMaterial(int i) const = 0;
    virtual int GetSubsetIndex(int i) const { return i; }
    virtual int GetStaticBatchIndex() const { return 0; }

    RendererType GetRendererType() const { return static_cast<RendererType>(m_RendererData.m_RendererType); }

    UInt32 GetLayerMask() const { return 1 << GetLayer(); }

    ShadowCastingMode GetShadowCastingMode() const { return static_cast<ShadowCastingMode>(m_RendererData.m_CastShadows); }
    bool GetReceiveShadows() const { return m_RendererData.m_ReceiveShadows; }

    UInt16 GetLightmapIndex(LightmapType lightmapType = kStaticLightmap) const { return m_RendererData.m_LightmapIndex[lightmapType]; }
    int GetLightmapIndexInt(LightmapType lightmapType = kStaticLightmap) const;
    void SetLightmapIndexIntNoDirty(int index, LightmapType lightmapType = kStaticLightmap);


    LightmapIndices GetLightmapIndices() const { return m_RendererData.m_LightmapIndex; }
    void SetLightmapIndices(LightmapIndices indices) { m_RendererData.m_LightmapIndex = indices; }

    const Vector4f& GetLightmapST(LightmapType lightmapType = kStaticLightmap) const { return m_RendererData.m_LightmapST[lightmapType]; }
    const Vector4f* GetLightmapSTArray() const { return m_RendererData.m_LightmapST; }
    void SetLightmapSTNoDirty(const Vector4f& lightmapST, LightmapType lightmapType = kStaticLightmap);

    UInt32 GetCustomPropertiesHash() const { return m_RendererData.m_CustomProperties != NULL ? m_RendererData.m_CustomProperties->GetLastComputedHash() : 0; }
    const ShaderPropertySheet* GetCustomProperties() const { return m_RendererData.m_CustomProperties; }

    GlobalLayeringData GetGlobalLayeringData() const       { return m_RendererData.m_GlobalLayeringData; }
    void SetGlobalLayeringData(GlobalLayeringData data)    { m_RendererData.m_GlobalLayeringData = data; }

    ReflectionProbeUsage GetReflectionProbeUsage() const { return (ReflectionProbeUsage)m_RendererData.m_ReflectionProbeUsage; }
    void SetReflectionProbeUsage(ReflectionProbeUsage usage) { m_RendererData.m_ReflectionProbeUsage = usage; }

    const PPtr<Transform>& GetProbeAnchor() const { return m_ProbeAnchor; }
    void SetProbeAnchor(const PPtr<Transform>& anchor) { m_ProbeAnchor = anchor; }

    const PPtr<GameObject>& GetLightProbeProxyVolumeOverride() const { return m_LightProbeVolumeOverride; }
    void SetLightProbeProxyVolumeOverride(const PPtr<GameObject>& volumeOverride) { m_LightProbeVolumeOverride = volumeOverride; }

    LightProbeUsage GetLightProbeUsage() const { return (LightProbeUsage)m_RendererData.m_LightProbeUsage; }
    void SetLightProbeUsage(LightProbeUsage usage) { m_RendererData.m_LightProbeUsage = usage; }
    int& GetLastLightProbeTetIndex() { Assert(m_RendererData.m_LightProbeUsage != kLightProbeOff); return m_RendererData.m_LightProbeOrTetIndex; }
    int GetSpecifiedLightProbeIndex() const { Assert(m_RendererData.m_UseExplicitLightProbeIndex); return m_RendererData.m_LightProbeOrTetIndex; }
    bool IsUsingExplicitLightProbeIndex() const { return m_RendererData.m_UseExplicitLightProbeIndex; }
    static void ClearProbes(RenderNode& node);

    bool IsRenderer() const { return m_RendererData.m_RendererType < kRendererIntermediate; }
    bool IsIntermediateRenderer() const { return m_RendererData.m_RendererType >= kRendererIntermediate; }

    static void FlattenProbeData(BaseRenderer& renderer, const TransformInfo& transformInfo, const LightProbeContext& lightProbeContext, RenderNode& node);
    static void FlattenCommonData(BaseRenderer& renderer, const TransformInfo& transformInfo, float lodFade, RenderNode& node);
    template<bool kExecuteFromJob>
    static bool FlattenSharedMaterialData(BaseRenderer& renderer, PerThreadPageAllocator& allocator, RenderNode& node);

    virtual void UpdatePreviousFrameData(); // This is for fixing case 875948 and should be removed when a cleaner solution is found.
    SInt32 GetMotionVectorFrameIndex() const { return m_MotionVectorFrameIndex; }
    void SetMotionVectorFrameIndex(SInt32 frameIndex) { m_MotionVectorFrameIndex = frameIndex; }

    GET_SET(UInt32, SortingGroupID, m_RendererData.m_GlobalLayeringData.sortingGroup.id);
    GET_SET(UInt32, SortingGroupOrder, m_RendererData.m_GlobalLayeringData.sortingGroup.order);

protected:

    SInt32                  m_MotionVectorFrameIndex;

    SharedRendererData      m_RendererData;

    PPtr<GameObject>        m_LightProbeVolumeOverride;

    // Probe is interpolated at the center of the renderer's bounds or at the position of the anchor, if assigned.
    PPtr<Transform>         m_ProbeAnchor;
};


#endif
