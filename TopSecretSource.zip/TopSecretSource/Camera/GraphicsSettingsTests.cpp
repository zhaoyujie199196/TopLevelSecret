#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "Runtime/Camera/GraphicsSettings.h"
#include "Runtime/Shaders/ShaderNameRegistry.h"
#include "Runtime/Testing/Testing.h"
#include "Runtime/Testing/TestFixtures.h"

UNIT_TEST_SUITE(GraphicsSettingsTests)
{
    class GraphicsSettingsFixture : TestFixtureBase
    {
    protected:
        Shader* specularShader;

        GraphicsSettingsFixture()
        {
            specularShader = GetScriptMapper().FindShader("Specular");
        }

        ~GraphicsSettingsFixture()
        {
        #if UNITY_EDITOR
            GetGraphicsSettings().SetDefaultShaderReferences();
        #endif
        }
    };

#if UNITY_EDITOR
    TEST_FIXTURE(GraphicsSettingsFixture, IsAlwaysIncludedShaderOrDependency_WithNullEntry_DoesNotCrash)
    {
        // Add a null shader to list of "always included" shaders.
        GetGraphicsSettings().RegisterAlwaysIncludedShader(PPtr<Shader>());

        // We need to know that don't crash inside when we have a null shader
        bool res = IsAlwaysIncludedShaderOrDependency(specularShader->GetInstanceID());

        CHECK(!res);
    }

    TEST_FIXTURE(GraphicsSettingsFixture, IsAlwaysIncludedShaderOrDependency_WithShaderReferencedViaGraphicsSettingsVariable_ReturnsTrue)
    {
        // Set a shader to be referenced by graphics settings, but not
        // through m_AlwaysIncludedShaders. Instead, make it referenced via
        // "deferred shader to use".
        BuiltinShaderSettings& settings = GetGraphicsSettings().GetBuiltinShaderSettings(GraphicsSettings::kDeferredShading);
        settings.m_Mode = BuiltinShaderSettings::kBuiltinShaderCustom;
        settings.m_Shader = specularShader;

        // Check if we do detect it as shader that needs to be included.
        bool res = IsAlwaysIncludedShaderOrDependency(specularShader->GetInstanceID());

        CHECK(res);
    }
#endif // #if UNITY_EDITOR
}

#endif // #if ENABLE_UNIT_TESTS
