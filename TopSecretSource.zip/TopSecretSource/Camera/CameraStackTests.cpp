#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS_WITH_FAKES

#include "CameraStack.h"
#include "Runtime/Testing/Testing.h"
#include "Runtime/Testing/FakingScripts.h"
#include "Editor/Src/ComponentUtility.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/Camera/Camera.h"
#include "Runtime/Camera/CameraTestFixture.h"
#include "Runtime/Camera/Skybox.h"


INTEGRATION_TEST_SUITE(CameraStackTests)
{
    struct Fixture : public TestFixtureWithScriptingSupport
    {
        CameraTestFixture cameraTestFixture;

        ~Fixture()
        {
            for (size_t i = 0; i < m_Cameras.size(); ++i)
            {
                DestroyObjectHighLevel(m_Cameras[i]->GetGameObjectPtr());
            }
        }

        Camera* NewTestCamera()
        {
            GameObject& go = CreateGameObject("TestCamera", "Transform", "Camera", NULL);
            Camera* cam = &go.GetComponent<Camera>();
            m_Cameras.push_back(cam);
            m_CameraList.push_back(cam);
            return cam;
        }

        dynamic_array<Camera*> m_Cameras;
        CameraList m_CameraList;
        CameraStackArray m_Stacks;
    };

    TEST_FIXTURE(Fixture, FindCameraStacks_EmptyList_EmptyResult)
    {
        FindCameraStacks(m_CameraList, m_Stacks);
        CHECK(m_Stacks.empty());
    }

    TEST_FIXTURE(Fixture, FindCameraStacks_ClearsResultArray)
    {
        m_Stacks.push_back(CameraStack());
        FindCameraStacks(m_CameraList, m_Stacks); // will clear passed results array, existing entries removed
        CHECK(m_Stacks.empty());
    }

    TEST_FIXTURE(Fixture, FindCameraStacks_DisabledOrNullCameras_NotIncludedIntoResults)
    {
        // null camera
        m_CameraList.push_back(PPtr<Camera>()); // null camera
        // disabled camera
        Camera* cam = NewTestCamera();
        cam->SetEnabled(false);

        FindCameraStacks(m_CameraList, m_Stacks);
        CHECK(m_Stacks.empty());
    }

    TEST_FIXTURE(Fixture, FindCameraStacks_CamerasWithDifferentViewports_GetDifferentStacks)
    {
        // 3 cameras, with different viewport rects
        Camera* cam1 = NewTestCamera();
        Camera* cam2 = NewTestCamera(); cam2->SetNormalizedViewportRect(Rectf(0.1f, 0.1f, 0.5f, 0.5f));
        Camera* cam3 = NewTestCamera(); cam3->SetNormalizedViewportRect(Rectf(0.2f, 0.2f, 0.5f, 0.5f));

        // should get 3 stacks back, one for each camera
        FindCameraStacks(m_CameraList, m_Stacks);
        CHECK_EQUAL(3, m_Stacks.size());
        CHECK_EQUAL(cam1, m_Stacks[0].m_Cameras.front());
        CHECK_EQUAL(cam2, m_Stacks[1].m_Cameras.front());
        CHECK_EQUAL(cam3, m_Stacks[2].m_Cameras.front());
    }

    TEST_FIXTURE(Fixture, FindCameraStacks_CamerasWithSameViewport_GetSameStacks)
    {
        // 4 cameras: two with same viewport; two more with a different vieport
        Camera* cam1 = NewTestCamera();
        Camera* cam2 = NewTestCamera();
        Camera* cam3 = NewTestCamera(); cam3->SetNormalizedViewportRect(Rectf(0.2f, 0.2f, 0.5f, 0.5f));
        Camera* cam4 = NewTestCamera(); cam4->SetNormalizedViewportRect(Rectf(0.2f, 0.2f, 0.5f, 0.5f));

        // should get 2 stacks back, with two cameras in each
        FindCameraStacks(m_CameraList, m_Stacks);
        CHECK_EQUAL(2, m_Stacks.size());
        // first stack
        CHECK_EQUAL(cam1, m_Stacks[0].m_Cameras[0]);
        CHECK_EQUAL(cam2, m_Stacks[0].m_Cameras[1]);
        // second stack
        CHECK_EQUAL(cam3, m_Stacks[1].m_Cameras[0]);
        CHECK_EQUAL(cam4, m_Stacks[1].m_Cameras[1]);
    }

    TEST_FIXTURE(Fixture, FindCameraStacks_DifferentCamera_BetweenSameCameras_StillMergesTheStacks)
    {
        // 4 cameras: the 2nd one different, like "ABAA".
        // It's a good question on what even *should* happen: should it result in 3 stacks (A, B, AA),
        // should should it be two stacks (AAA, B)? For now, we're doing the 1st one, so verify
        // that is behaves like that.
        Camera* cam1 = NewTestCamera();
        Camera* cam2 = NewTestCamera(); cam2->SetNormalizedViewportRect(Rectf(0.2f, 0.2f, 0.5f, 0.5f));
        Camera* cam3 = NewTestCamera();
        Camera* cam4 = NewTestCamera();

        // should get 3 stacks back: 1, 2, 3+4
        FindCameraStacks(m_CameraList, m_Stacks);
        CHECK_EQUAL(3, m_Stacks.size());
        // first stack
        CHECK_EQUAL(cam1, m_Stacks[0].m_Cameras[0]);
        // second stack
        CHECK_EQUAL(cam2, m_Stacks[1].m_Cameras[0]);
        // third stack
        CHECK_EQUAL(cam3, m_Stacks[2].m_Cameras[0]);
        CHECK_EQUAL(cam4, m_Stacks[2].m_Cameras[1]);
    }
}

#endif // #if ENABLE_UNIT_TESTS
