#pragma once

void InitializeLightAnimationBindingInterface();
void CleanupLightAnimationBindingInterface();
