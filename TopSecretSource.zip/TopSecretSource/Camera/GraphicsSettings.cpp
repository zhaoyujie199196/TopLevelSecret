#include "UnityPrefix.h"
#include "GraphicsSettings.h"
#include "RenderManager.h"
#include "Runtime/Mono/MonoBehaviour.h"
#include "Runtime/Mono/MonoManager.h"
#include "Runtime/BaseClasses/ManagerContext.h"
#include "Runtime/Camera/Camera.h"
#include "Runtime/Camera/Light.h"
#include "Runtime/Shaders/Material.h"
#include "Runtime/Shaders/ShaderImpl/ShaderImpl.h"
#include "Runtime/Profiler/Profiler.h"

#if UNITY_EDITOR
#include "Runtime/Misc/PlayerSettings.h"
#include "Runtime/Misc/ResourceManager.h"
#include "Runtime/Serialize/BuildUsageTags.h"
#include "Runtime/Utilities/Argv.h"
#include "Editor/Src/EditorUserBuildSettings.h"
#endif

#if UNITY_EDITOR
// implemented in Editor/Src/EditorOnlyGraphicsSettings_TierSettings.cpp
TierGraphicsSettingsEditor DefaultTierSettings(BuildTargetPlatformGroup platform, GraphicsTier tier, const EditorOnlyGraphicsSettings& gs);
#endif


void BuiltinShaderSettings::CreateMaterialIfNeeded(Material** inoutMaterial, const int minPassCount) const
{
    Assert(inoutMaterial);

    // no shader support?
    Shader* s = m_Shader;
    if (s == NULL)
        return;

    const ShaderLab::IntShader* ss = s->GetShaderLabShader();
    if (ss->HasNoSubShaders() || ss->GetActiveSubShader().GetValidPassCount() < minPassCount)
    {
        ErrorStringObject(Format("This custom render path shader needs to have at least %i passes.", minPassCount), m_Shader);
        return;
    }

    // create material if needed
    if (*inoutMaterial == NULL)
        *inoutMaterial = Material::CreateMaterial(*s, Object::kHideAndDontSave);
    else
    {
        // we might have material created already, but it was for a different shader
        if ((*inoutMaterial)->GetShader() != s)
            (*inoutMaterial)->SetShader(s);
    }
}

GraphicsSettings::GraphicsSettings(MemLabelId label, ObjectCreationMode mode)
    :   Super(label, mode)
#if UNITY_EDITOR
    ,   m_NeedToInitializeDefaultShaderReferences(false)
    ,   m_NeedToInitializeDefaultuGUIShaders(false)
    ,   m_NeedToInitializeTierSettings(false)
#endif
    ,   m_LightsUseLinearIntensity(false)
    ,   m_LightsUseColorTemperature(false)
{
#if UNITY_EDITOR
    m_EditorOnly.Reset();
    // We want to fill in default shader references, but at construction
    // time resource files aren't loaded yet. So set up a flag
    // that we'll want to fill them in later. Unless we already have
    // serialized data for graphics settings in the project;
    // then we'll unset the flag in transfer function.
    m_NeedToInitializeDefaultShaderReferences = true;
#endif

    ::memset(&m_TierSettings, 0x00, sizeof(m_TierSettings));
    m_TransparencySortMode = Camera::kTransparencySortDefault;
    m_TransparencySortAxis = Vector3f(0.0f, 0.0f, 1.0f);
}

void GraphicsSettings::ThreadedCleanup()
{
}

void GraphicsSettings::InitializeClass()
{
    RenderManager::InitializeClass();
#if UNITY_EDITOR
    RegisterAllowNameConversion("GraphicsSettings", "m_BuildTargetShaderSettings", "m_TierSettings");
    RegisterAllowNameConversion("GraphicsSettings", "m_ShaderSettings_Tier1", "m_TierSettings_Tier1");
    RegisterAllowNameConversion("GraphicsSettings", "m_ShaderSettings_Tier2", "m_TierSettings_Tier2");
    RegisterAllowNameConversion("GraphicsSettings", "m_ShaderSettings_Tier3", "m_TierSettings_Tier3");

    // this is for EditorOnlyGraphicsSettings::TierSettings, it will use TierSettings name for serialization
    RegisterAllowNameConversion("TierSettings", "m_ShaderSettings", "m_Settings");
#endif
}

void GraphicsSettings::CleanupClass()
{
    RenderManager::CleanupClass();
}

const BuiltinShaderSettings& GraphicsSettings::GetBuiltinShaderSettings(BuiltinShaderType type) const
{
    switch (type)
    {
        case kDeferredShading:          return m_Deferred;
        case kDeferredReflections:      return m_DeferredReflections;
        case kLegacyDeferredLighting:   return m_LegacyDeferred;
        case kScreenSpaceShadows:       return m_ScreenSpaceShadows;
        case kDepthNormals:             return m_DepthNormals;
        case kMotionVectors:            return m_MotionVectors;
        case kLightHalo:                return m_LightHalo;
        case kLensFlare:                return m_LensFlare;
        default:                        AssertFormatMsg(false, "Unknown builtin shader type %i", type);
    }
    return m_Deferred; // fallback to return something
}

BuiltinShaderSettings& GraphicsSettings::GetBuiltinShaderSettings(BuiltinShaderType type)
{
    return const_cast<BuiltinShaderSettings&>(static_cast<const GraphicsSettings&>(*this).GetBuiltinShaderSettings(type));
}

#if UNITY_EDITOR
static void UpdateShaderAfterModeChange(BuiltinShaderSettings& shaderSettings, const char* builtinShaderName)
{
    switch (shaderSettings.m_Mode)
    {
        case BuiltinShaderSettings::kBuiltinShaderNone:     shaderSettings.m_Shader = NULL; return;
        case BuiltinShaderSettings::kBuiltinShaderCustom:   return;
        case BuiltinShaderSettings::kBuiltinShaderBuiltin:
            if (!IsBuildingBuiltinResources() && BuiltinResourceManager::AreResourcesInitialized())
                shaderSettings.m_Shader = GetBuiltinExtraResource<Shader>(builtinShaderName);
            return;
    }
    AssertFormatMsg(false, "Unknown builtin shader mode %i", shaderSettings.m_Mode);
}

#endif // #if UNITY_EDITOR

void GraphicsSettings::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);

#if UNITY_EDITOR
    UpdateShaderAfterModeChange(m_Deferred, "Internal-DeferredShading.shader");
    UpdateShaderAfterModeChange(m_LegacyDeferred, "Internal-PrePassLighting.shader");
    UpdateShaderAfterModeChange(m_DeferredReflections, "Internal-DeferredReflections.shader");
    UpdateShaderAfterModeChange(m_ScreenSpaceShadows, "Internal-ScreenSpaceShadows.shader");
    UpdateShaderAfterModeChange(m_DepthNormals, "Internal-DepthNormalsTexture.shader");
    UpdateShaderAfterModeChange(m_MotionVectors, "Internal-MotionVectors.shader");
    UpdateShaderAfterModeChange(m_LightHalo, "Internal-Halo.shader");
    UpdateShaderAfterModeChange(m_LensFlare, "Internal-Flare.shader");

    if (!IsBuildingBuiltinResources() && BuiltinResourceManager::AreResourcesInitialized())
        m_SpritesDefaultMaterial = GetBuiltinExtraResource<Material>("Sprites-Default.mat");
#endif // #if UNITY_EDITOR
}

PROFILER_INFORMATION(kProfileShaderPrewarm, "Prewarm Shaders", kProfilerRender);
void GraphicsSettings::WarmupPreloadedShaders()
{
    PROFILER_AUTO(kProfileShaderPrewarm, NULL);
    for (size_t i = 0, n = m_PreloadedShaders.size(); i != n; ++i)
    {
        ShaderVariantCollection* variants = m_PreloadedShaders[i];
        if (variants)
            variants->WarmupShaders();
    }
}

void GraphicsSettings::SmartReset()
{
    Super::SmartReset();
#if UNITY_EDITOR
    SetDefaultShaderReferences();
#endif

    m_Deferred.Reset();
    m_DeferredReflections.Reset();
    m_ScreenSpaceShadows.Reset();
    m_LegacyDeferred.Reset();
    m_DepthNormals.Reset();
    m_MotionVectors.Reset();
    m_LightHalo.Reset();
    m_LensFlare.Reset();

    m_PreloadedShaders.clear();

#if UNITY_EDITOR
    m_EditorOnly.Reset();
#endif

    ::memset(&m_TierSettings, 0x00, sizeof(m_TierSettings));
    m_TransparencySortMode = Camera::kTransparencySortDefault;
    m_TransparencySortAxis = Vector3f(0.0f, 0.0f, 1.0f);
    m_LightsUseLinearIntensity = false;
    m_LightsUseColorTemperature = false;
}

template<class TransferFunc>
void TierGraphicsSettings::Transfer(TransferFunc& transfer)
{
    TRANSFER_ENUM(renderingPath);
    TRANSFER_ENUM(hdrMode)
    TRANSFER_ENUM(realtimeGICPUUsage)
    TRANSFER(useCascadedShadowMaps);
    TRANSFER(enableLPPV);
    TRANSFER(useHDR);
    transfer.Align();
}

#if UNITY_EDITOR
template<class TransferFunc>
void TierGraphicsSettingsEditor::Transfer(TransferFunc& transfer)
{
    TRANSFER_ENUM(standardShaderQuality);
    TRANSFER_ENUM(renderingPath);
    TRANSFER_ENUM(hdrMode);
    TRANSFER_ENUM(realtimeGICPUUsage)

    TRANSFER(useReflectionProbeBoxProjection);
    TRANSFER(useReflectionProbeBlending);
    TRANSFER(useHDR);
    TRANSFER(useDetailNormalMap);

    TRANSFER(useCascadedShadowMaps);
    TRANSFER(enableLPPV);
    TRANSFER(useDitherMaskForAlphaBlendedShadows);
    transfer.Align();
}

template<class TransferFunc>
void EditorOnlyGraphicsSettings::TierSettings::Transfer(TransferFunc& transfer)
{
    transfer.SetVersion(4);

    TRANSFER_ENUM(m_BuildTarget);
    TRANSFER_ENUM(m_Tier);
    TRANSFER(m_Settings);
    TRANSFER(m_Automatic);

    if (!transfer.IsSerializingForGameRelease())
        TransferDeprecated(transfer);

    transfer.Align();
}

static BuildTargetPlatformGroup BuildTargetFromName(const core::string& name)
{
    // please note that this list needs no updates.
    // it has platform<->name mapping valid for 5.5 alpha, and anything newer will store enums
    if (name == "Standalone")
        return kPlatformStandalone;
    if (name == "Web")
        return kPlatformWebPlayer;
    if (name == "iPhone")
        return kPlatform_iPhone;
    if (name == "Android")
        return kPlatformAndroid;
    if (name == "WebGL")
        return kPlatformWebGL;
    if (name == "Windows Store Apps")
        return kPlatformMetro;
    if (name == "Tizen")
        return kPlatformTizen;
    if (name == "PSP2")
        return kPlatformPSP2;
    if (name == "PS4")
        return kPlatformPS4;
    if (name == "PSM")
        return kPlatformPSM;
    if (name == "XboxOne")
        return kPlatformXboxOne;
    if (name == "Samsung TV")
        return kPlatformSTV;
    if (name == "Nintendo 3DS")
        return kPlatformN3DS;
    if (name == "WiiU")
        return kPlatformWiiU;
    if (name == "tvOS")
        return kPlatformtvOS;

    DebugAssert(false && "Unknown platform was written in GraphicsSettings.asset");
    return kPlatformStandalone;
}

template<class TransferFunc>
void EditorOnlyGraphicsSettings::TierSettings::TransferDeprecated(TransferFunc& transfer)
{
    if (transfer.IsVersionSmallerOrEqual(1))
    {
        core::string buildTargetName; TRANSFER_WITH_NAME(buildTargetName, "m_BuildTarget");
        m_BuildTarget = BuildTargetFromName(buildTargetName);
    }

    // if we tweak TierGraphicsSettingsEditor and need custom loading of old data this is the place to do it
    // as we know platform/tier and can make (hopefully) educated decisions
    // we create all-default TierSettings for current platform/tier and just cherry-pick needed values
    TierGraphicsSettingsEditor defaultSettings = DefaultTierSettings(m_BuildTarget, m_Tier, *(EditorOnlyGraphicsSettings*)transfer.GetUserData());

    if (transfer.IsVersionSmallerOrEqual(1))
        m_Settings.renderingPath = defaultSettings.renderingPath;

    if (transfer.IsVersionSmallerOrEqual(2))
    {
        m_Settings.useHDR = defaultSettings.useHDR;
        m_Settings.hdrMode = defaultSettings.hdrMode;
    }

    if (transfer.IsVersionSmallerOrEqual(3))
    {
        m_Settings.realtimeGICPUUsage = defaultSettings.realtimeGICPUUsage;
    }
}

#endif

template<class TransferFunc>
void BuiltinShaderSettings::Transfer(TransferFunc& transfer)
{
    TRANSFER_ENUM(m_Mode);
    TRANSFER(m_Shader);
}

#if UNITY_EDITOR
template<class TransferFunction>
inline void EditorOnlyGraphicsSettings::AlbedoSwatchInfo::Transfer(TransferFunction& transfer)
{
    TRANSFER(name);
    TRANSFER(color);
    TRANSFER(minLuminance);
    TRANSFER(maxLuminance);
    transfer.Align();
}

template<class TransferFunction>
inline void EditorOnlyGraphicsSettings::Transfer(TransferFunction& transfer)
{
    TRANSFER_ENUM(m_DefaultRenderingPath);
    TRANSFER_ENUM(m_DefaultMobileRenderingPath);
    // we serialize EditorOnlyGraphicsSettings into GraphicsSettings directly so we must reuse GraphicsSettings' transfer version
    // we want to get rendering path from player settings only if read old data
    // as opposed to "we didnt read them because we create project from scratch" (they will keep default "forward" value)
    if (transfer.IsVersionSmallerOrEqual(8))
    {
        m_DefaultRenderingPath          = (RenderingPath)GetPlayerSettings().GetEditorOnly().deprecatedRenderingPath;
        m_DefaultMobileRenderingPath    = (RenderingPath)GetPlayerSettings().GetEditorOnly().deprecatedMobileRenderingPath;
    }

    // when we load deprecated tier settings we migh need EditorOnlyGraphicsSettings to make decisions
    transfer.SetUserData(this);
    TRANSFER(m_TierSettings);
    transfer.SetUserData(0);

    TRANSFER_ENUM(m_LightmapStripping);
    TRANSFER_ENUM(m_FogStripping);
    TRANSFER_ENUM(m_InstancingStripping);
    TRANSFER(m_LightmapKeepPlain);
    TRANSFER(m_LightmapKeepDirCombined);
    TRANSFER(m_LightmapKeepDynamicPlain);
    TRANSFER(m_LightmapKeepDynamicDirCombined);
    TRANSFER(m_LightmapKeepShadowMask);
    TRANSFER(m_LightmapKeepSubtractive);
    TRANSFER(m_FogKeepLinear);
    TRANSFER(m_FogKeepExp);
    TRANSFER(m_FogKeepExp2);
    transfer.Align();
    TRANSFER(m_AlbedoSwatchInfos);
}

#endif

template<class TransferFunction>
void GraphicsSettings::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);
    transfer.SetVersion(12);

    transfer.Transfer(m_Deferred, "m_Deferred");
    transfer.Transfer(m_DeferredReflections, "m_DeferredReflections");
    transfer.Transfer(m_ScreenSpaceShadows, "m_ScreenSpaceShadows");
    transfer.Transfer(m_LegacyDeferred, "m_LegacyDeferred");
    transfer.Transfer(m_DepthNormals, "m_DepthNormals");
    transfer.Transfer(m_MotionVectors, "m_MotionVectors");
    transfer.Transfer(m_LightHalo, "m_LightHalo");
    transfer.Transfer(m_LensFlare, "m_LensFlare");
#if UNITY_EDITOR
    if (transfer.IsSerializingForGameRelease())
    {
        // Internal shaders are added to user-specified always included shaders when doing a build,
        // but not when loading/saving GraphicsSettings in the editor.
        ShaderArray alwaysIncludedAndInternalShaders(m_AlwaysIncludedShaders);
        AddHiddenInternalShaders(alwaysIncludedAndInternalShaders);
        transfer.Transfer(alwaysIncludedAndInternalShaders, "m_AlwaysIncludedShaders");
    }
    else
#endif
    {
        transfer.Transfer(m_AlwaysIncludedShaders, "m_AlwaysIncludedShaders");
    }

    transfer.Transfer(m_PreloadedShaders, "m_PreloadedShaders");

    transfer.Transfer(m_SpritesDefaultMaterial, "m_SpritesDefaultMaterial");
    TRANSFER(m_CustomRenderPipeline);
    TRANSFER(m_TransparencySortMode);
    TRANSFER(m_TransparencySortAxis);

    // in editor we should serialize m_TierSettings only when building game
    // otherwise, as we change it every time we switch platform, VCS will be not happy
#if UNITY_EDITOR
    if (transfer.IsSerializingForGameRelease())
    {
#endif
    TRANSFER_WITH_NAME(m_TierSettings[0], "m_TierSettings_Tier1");
    TRANSFER_WITH_NAME(m_TierSettings[1], "m_TierSettings_Tier2");
    TRANSFER_WITH_NAME(m_TierSettings[2], "m_TierSettings_Tier3");
    CompileTimeAssert(kGraphicsTierCount == 3, "Update GraphicsSettings::Transfer if you change tier count");
#if UNITY_EDITOR
}

#endif


#if UNITY_EDITOR
    if (!transfer.IsSerializingForGameRelease())
    {
        m_EditorOnly.Transfer(transfer);
        TransferDeprecated(transfer);
    }
#endif


#if UNITY_EDITOR
    // We are reading data from existing shader file; no need
    // to go later and overwrite it with default set of shaders.
    if (transfer.IsReading())
        m_NeedToInitializeDefaultShaderReferences = false;
    if (transfer.IsVersionSmallerOrEqual(1))
        m_NeedToInitializeDefaultuGUIShaders = true;

    // if Editor is not yet fully inited (build settings are not loaded) we defer TierSettings/Default-Shaders initialization to Application::InitializeProject
    //   this happens when we load old project with newer editor
    // if Editor is already inited and build settings are available we init TierSettings/Default-Shaders right away to avoid broken behavior until project is reloaded
    //   this happens when we import old unity package with newer editor during editor lifetime
    bool areBuildSettingReady = (GetEditorUserBuildSettingsPtr() != NULL);
    if (transfer.IsVersionSmallerOrEqual(2))
    {
        if (areBuildSettingReady)
            SetDefaultShaderReferences();
        else
            m_NeedToInitializeDefaultShaderReferences = true;
    }
    // NB if you add members to (runtime) TierSettings you need to update version here
    if (transfer.IsVersionSmallerOrEqual(11))
    {
        if (areBuildSettingReady)
            InitializeTierSettings();
        else
            m_NeedToInitializeTierSettings = true;
    }

#endif // #if UNITY_EDITOR

    TRANSFER_PROPERTY(bool, m_LightsUseLinearIntensity, GetLightsUseLinearIntensity, SetLightsUseLinearIntensity);
    TRANSFER_PROPERTY(bool, m_LightsUseColorTemperature, GetLightsUseColorTemperature, SetLightsUseColorTemperature);
    // Unity 5.6 added ColorTemperature and linear intensity. Don't use on old projects as relighting would be required.
    if (transfer.IsVersionSmallerOrEqual(10))
    {
        m_LightsUseLinearIntensity = false;
        m_LightsUseColorTemperature = false;
    }
}

#if UNITY_EDITOR

template<class TransferFunc>
void GraphicsSettings::TransferDeprecated(TransferFunc& transfer)
{
    if (!transfer.IsReading())
        return;

    if (transfer.IsVersionSmallerOrEqual(3))
    {
        bool lightmapKeepDynamic = true;
        TRANSFER_WITH_NAME(lightmapKeepDynamic, "m_LightmapKeepDynamic");
        m_EditorOnly.m_LightmapKeepDynamicPlain         = lightmapKeepDynamic;
        m_EditorOnly.m_LightmapKeepDynamicDirCombined   = lightmapKeepDynamic;
    }

    // ver 6: we used BuildTargetPlatform with PlatformShaderSettings
    // ver 7: we used BuildTargetPlatformGroup with PlatformShaderSettings
    // ver 8: we use BuildTargetPlatformGroup with TierGraphicsSettingsEditor
    // 6 -> 7 happened during beta so we skip upgrade path
    if (transfer.IsVersionSmallerOrEqual(6))
        m_EditorOnly.m_TierSettings.clear();
}

#endif // #if UNITY_EDITOR

PPtr<Material> GraphicsSettings::GetBuiltinMaterial(GraphicsSettings::BuiltinMaterialType type)
{
    switch (type)
    {
        case kSpritesDefaultMat:
            return m_SpritesDefaultMaterial;
        default:
            AssertFormatMsg(false, "Unknown builtin material type %i", type);
            break;
    }
    return NULL;
}

void UpdateAllLights()
{
    dynamic_array<Light*> lights(kMemTempAlloc);
    Object::FindObjectsOfType(lights);
    for (size_t i = 0; i < lights.size(); ++i)
    {
        lights[i]->Precalc();
    }
}

void GraphicsSettings::SetLightsUseLinearIntensity(bool useLinearIntensity)
{
    if (m_LightsUseLinearIntensity == useLinearIntensity)
        return;
    m_LightsUseLinearIntensity = useLinearIntensity;
    SetDirty();
    UpdateAllLights();
}

void GraphicsSettings::SetLightsUseColorTemperature(bool useColorTemperature)
{
    if (m_LightsUseColorTemperature == useColorTemperature)
        return;
    m_LightsUseColorTemperature = useColorTemperature;
    SetDirty();
    UpdateAllLights();
}

PPtr<MonoBehaviour> GraphicsSettings::GetRenderPipeline() const
{
    return m_CustomRenderPipeline;
}

void GraphicsSettings::SetRenderPipeline(PPtr<MonoBehaviour> renderPipeline)
{
    if (!m_CustomRenderPipeline.IsNull())
        CleanupRenderPipeline();

    m_CustomRenderPipeline = renderPipeline;
    SetDirty();
}

void GraphicsSettings::CleanupRenderPipeline()
{
    if (GetMonoManagerPtr())
    {
        ScriptingInvocation invocation(GetCoreScriptingClasses().cleanupRenderPipeline);
        invocation.Invoke();
    }
}

IMPLEMENT_REGISTER_CLASS(GraphicsSettings, 30);
IMPLEMENT_OBJECT_SERIALIZE(GraphicsSettings);
GET_MANAGER(GraphicsSettings)
GET_MANAGER_PTR(GraphicsSettings)
