#pragma once

#if ENABLE_UNIT_TESTS_WITH_FAKES

#include "Runtime/Testing/FakingScripts.h"

// Fakes required by Camera component. Requires TestFixtureWithScriptingSupport.
struct CameraTestFixture : public TestFixtureCreatingScriptObjects
{
    // Creating a camera and waking it up will query the game view rect.
    FAKE_STATIC_SCRIPT_METHOD(GameView, GetMainGameViewTargetSize, Vector2f(), kEngineAssemblyName, "UnityEngine");
    FAKE_STATIC_METHOD(GUIView, GetMainGameViewSize, Vector2f());

    CameraTestFixture()
    {
        GameView_GetMainGameViewTargetSize.Returns(Vector2f(640, 480));
        GUIView_GetMainGameViewSize.Returns(Vector2f(640, 480));
    }
};

#endif // ENABLE_UNIT_TESTS_WITH_FAKES
