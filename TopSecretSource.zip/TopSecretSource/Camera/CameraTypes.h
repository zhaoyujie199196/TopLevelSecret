#pragma once

#include "Runtime/Math/Matrix4x4.h"

struct CameraTemporarySettings
{
    int   renderingPath;
    float fieldOfView;
    float aspect;
    bool  implicitAspect;
};

struct CameraRenderingParams
{
    Matrix4x4f matView;
    Matrix4x4f matProj;
    Vector3f worldPosition;
};
