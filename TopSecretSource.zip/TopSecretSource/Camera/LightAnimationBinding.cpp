#include "UnityPrefix.h"
#include "Runtime/Animation/GenericAnimationBindingCache.h"
#include "Runtime/Interfaces/IAnimation.h"
#include "Runtime/Interfaces/IAnimationBinding.h"
#include "Runtime/mecanim/generic/crc32.h"
#include "Runtime/Animation/AnimationClipBindings.h"
#include "Runtime/Misc/GenericPropertyBinding.h"
#include "Runtime/Camera/Light.h"

static void RegisterLightProperties(GenericPropertyBinding& genericBinding)
{
    REGISTER_ANIM_PROP_FLOAT_COLOR_AUTO(Light, Color);
    REGISTER_ANIM_PROP_FLOAT_AUTO(Light, CookieSize);
    REGISTER_ANIM_PROP_BOOL_AUTO(Light, DrawHalo);
    REGISTER_ANIM_PROP_FLOAT_AUTO(Light, Intensity);
    REGISTER_ANIM_PROP_FLOAT_AUTO(Light, Range);
    REGISTER_ANIM_PROP_FLOAT(Light, ShadowStrength, "m_Shadows.m_Strength", GetShadowStrength, SetShadowStrength);
    REGISTER_ANIM_PROP_FLOAT(Light, ShadowBias, "m_Shadows.m_Bias", GetShadowBias, SetShadowBias);
    REGISTER_ANIM_PROP_FLOAT(Light, ShadowNormalBias, "m_Shadows.m_NormalBias", GetShadowNormalBias, SetShadowNormalBias);
    REGISTER_ANIM_PROP_FLOAT(Light, ShadowNearPlane, "m_Shadows.m_NearPlane", GetShadowNearPlane, SetShadowNearPlane);
    REGISTER_ANIM_PROP_FLOAT_AUTO(Light, SpotAngle);
    REGISTER_ANIM_PROP_BOOL_AUTO(Light, ColorTemperature);
}

static GenericPropertyBinding* gGenericLightBinding = NULL;

void InitializeLightAnimationBindingInterface()
{
    if (GetIAnimation() != NULL)
    {
        gGenericLightBinding = UNITY_NEW(GenericPropertyBinding, kMemAnimation);
        RegisterLightProperties(*gGenericLightBinding);
        GetIAnimation()->RegisterIAnimationBinding(TypeOf<Light>(), UnityEngine::Animation::kLightPropertyBinding, gGenericLightBinding);
    }
}

void CleanupLightAnimationBindingInterface()
{
    UNITY_DELETE(gGenericLightBinding, kMemAnimation);
}
