#include "UnityPrefix.h"
#include "HaloManager.h"
#include "RenderManager.h"
#include "CullResults.h"
#include "Runtime/Allocator/BatchAllocator.h"
#include "Runtime/BaseClasses/ManagerContext.h"
#include "Runtime/Camera/Camera.h"
#include "Runtime/BaseClasses/MessageHandlerRegistration.h"
#include "Runtime/GfxDevice/GfxDevice.h"
#include "Runtime/GfxDevice/GeometryJob.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Graphics/Mesh/DynamicVBO.h"
#include "Runtime/Graphics/Mesh/MeshVertexFormat.h"
#include "Runtime/Graphics/GraphicsHelper.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Shaders/Material.h"
#include "Runtime/Shaders/ShaderNameRegistry.h"
#include "Runtime/Shaders/ShaderImpl/ShaderImpl.h"
#include "Runtime/Camera/GraphicsSettings.h"

IMPLEMENT_REGISTER_CLASS(Halo, 122);
IMPLEMENT_OBJECT_SERIALIZE(Halo);

static Material *s_HaloMaterial = NULL;
static HaloManager* s_Manager = NULL;

static DefaultMeshVertexFormat gHaloVertexFormat(VERTEX_FORMAT3(Vertex, TexCoord0, Color));

Halo::Halo(MemLabelId label, ObjectCreationMode mode)
    :   Super(label, mode)
{
    m_Handle = 0;
}

void Halo::ThreadedCleanup()
{
}

void Halo::Reset()
{
    Super::Reset();
    m_Color = ColorRGBA32(128, 128, 128, 255);
    m_Size = 5.0f;
}

void Halo::InitializeClass()
{
    REGISTER_MESSAGE_VOID(kTransformChanged, TransformChanged);
}

void Halo::CleanupClass()
{
    //  s_HaloMaterial is clean up by UnloadAllObjects()
}

template<class TransferFunc>
void Halo::Transfer(TransferFunc& transfer)
{
    Super::Transfer(transfer);
    TRANSFER(m_Color);
    TRANSFER(m_Size);
}

static void LoadHaloMaterial()
{
    GetGraphicsSettings().GetBuiltinShaderSettings(GraphicsSettings::kLightHalo).CreateMaterialIfNeeded(&s_HaloMaterial);
}

void Halo::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);
    if ((awakeMode & kDidLoadFromDisk) == 0 && m_Handle)
    {
        GetHaloManager().UpdateHalo(m_Handle, GetComponent<Transform>().GetPosition(), m_Color, m_Size, GetGameObject().GetLayerMask(), this);
    }
}

void Halo::TransformChanged()
{
    if (m_Handle)
    {
        GetHaloManager().UpdateHalo(m_Handle, GetComponent<Transform>().GetPosition(), m_Color, m_Size, GetGameObject().GetLayerMask(), this);
    }
}

void Halo::AddToManager()
{
    m_Handle = GetHaloManager().AddHalo();
    GetHaloManager().UpdateHalo(m_Handle, GetComponent<Transform>().GetPosition(), m_Color, m_Size, GetGameObject().GetLayerMask(), this);
}

void Halo::RemoveFromManager()
{
    GetHaloManager().DeleteHalo(m_Handle, this);
    m_Handle = 0;
}

HaloManager::Halo::Halo(int hdl)
    : position(Vector3f(0, 0, 0)), color(ColorRGBAf(0, 0, 0)), size(1), handle(hdl), layers(1)
{
}

HaloManager::Halo::Halo(const Vector3f &pos, const ColorRGBA32 &col, float s, int h, UInt32 _layers)
    : position(pos), color(col), size(s), handle(h), layers(_layers)
{
}

struct HaloVertex
{
    Vector3f vert;
    ColorRGBA32 color;
    Vector2f uv;
};
PROFILER_INFORMATION(gHaloRenderProfile, "Halo.Render", kProfilerRender)
PROFILER_INFORMATION(gHaloGeometryJobProfile, "Halo.GeometryJob", kProfilerRender)

struct HaloManagerGeometryJob
{
    HaloManagerGeometryJob() : m_NumJobsInBatch(0) {}

    static const int kNumInBatch = 64;
    HaloManager::Halo m_Halos[kNumInBatch];
    Vector3f m_CameraWorldPos;
    int m_NumJobsInBatch;
    bool m_renderStereoHalos;
};

void HaloManager::RenderHalos(const CullResults* cullResults, ShaderPassContext& passContext, const Matrix4x4f& worldToCamera)
{
    // Just bail if we have no visible halos or using shader replace
    if (m_Halos.empty() || (cullResults && cullResults->shaderReplaceData.replacementShader != NULL))
        return;

    LoadHaloMaterial();
    if (!s_HaloMaterial)
        return;

    Shader* shader = s_HaloMaterial->GetShader();
    const int ssIndex = shader->GetActiveSubShaderIndex();

    GfxDevice& device = GetGfxDevice();
    #if UNITY_EDITOR
    // don't draw when wireframe mode
    if (device.GetWireframe())
        return;
    #endif

    PROFILER_AUTO(gHaloRenderProfile, NULL)

    const int kHaloVertices = 21;
    int haloCount = m_Halos.size();
    if (!haloCount)
        return;

    // allocate geometry job data
    int jobsCount = 0;
    BatchAllocator batchAllocator;
    DynamicVBOGeometryJobData* geometryJobData = NULL;
    batchAllocator.AllocateRoot(geometryJobData, 1);
    batchAllocator.AllocateField(geometryJobData->data, haloCount);
    batchAllocator.AllocateField(geometryJobData->userData, RoundUpMultiple<size_t>(haloCount, HaloManagerGeometryJob::kNumInBatch) / HaloManagerGeometryJob::kNumInBatch, ALIGN_OF(HaloManagerGeometryJob), sizeof(HaloManagerGeometryJob));
    batchAllocator.Commit(kMemTempJobAlloc);

    Camera &cam = GetCurrentCamera();
    UInt32 layers = cam.GetCullingMask();
    Matrix4x4f cameraToWorld;
    Matrix4x4f::Invert_Full(worldToCamera, cameraToWorld);

    HaloManagerGeometryJob* job = (HaloManagerGeometryJob*)geometryJobData->userData;
    *job = HaloManagerGeometryJob();
    job->m_CameraWorldPos = cam.GetPosition();

    // Halos will render differently if the camera is stereo or mono
    bool renderStereoHalos = cam.GetStereoEnabled();
    job->m_renderStereoHalos = renderStereoHalos;

    UInt32 vertexCount = 0;

    for (int i = 0; i < haloCount; ++i)
    {
        // Check if halo is visible
        Halo& halo = m_Halos[i];
        halo.positionVS = worldToCamera.MultiplyPoint3(halo.position);
        const float s = halo.size;

        // Skip this halo if behind the camera or layers don't match
        if (halo.positionVS.z > -s || !(halo.layers & layers))
            continue;

        // Add halo
        job->m_Halos[job->m_NumJobsInBatch++] = halo;

        // Flush batch?
        if (job->m_NumJobsInBatch == HaloManagerGeometryJob::kNumInBatch)
        {
            geometryJobData->data[jobsCount] = GeometryJobData(sizeof(HaloVertex), kHaloVertices * job->m_NumJobsInBatch, 0);
            vertexCount += kHaloVertices * job->m_NumJobsInBatch;
            jobsCount++;
            *(++job) = HaloManagerGeometryJob();
            job->m_CameraWorldPos = cam.GetPosition();
            job->m_renderStereoHalos = renderStereoHalos;
        }
    }

    // Flush final batch
    if (job && job->m_NumJobsInBatch)
    {
        geometryJobData->data[jobsCount] = GeometryJobData(sizeof(HaloVertex), kHaloVertices * job->m_NumJobsInBatch, 0);
        vertexCount += kHaloVertices * job->m_NumJobsInBatch;
        jobsCount++;
    }

    if (!jobsCount)
    {
        ReleaseGeometryJobMem(geometryJobData);
        return;
    }

    DynamicVBOChunkHandle vboChunk;
    device.ScheduleDynamicVBOGeometryJobs(RenderGeometryJob, ReleaseGeometryJobMem, NULL, geometryJobData, jobsCount, kPrimitiveTriangleStrip, &vboChunk);
    geometryJobData = NULL; // the final job deallocates this, so prevent this thread from using the pointer again

    Matrix4x4f matView = device.GetViewMatrix();
    Matrix4x4f matWorld = device.GetWorldMatrix();

    if (!renderStereoHalos)
    {
        device.SetViewMatrix(Matrix4x4f::identity); // implicitly sets world to identity
    }

    device.SetWorldMatrix(Matrix4x4f::identity);

    // Output halos
    ShaderChannelMask channels = s_HaloMaterial->SetPassSlow(0, passContext, ssIndex);

    DynamicVBO::DrawParams params(sizeof(HaloVertex), 0, vertexCount, 0, 0);
    device.GetDynamicVBO().DrawChunk(vboChunk, channels, gHaloVertexFormat.GetVertexFormat()->GetAvailableChannels(), gHaloVertexFormat.GetVertexDecl(channels), &params, 1);
    GPU_TIMESTAMP();

    if (!renderStereoHalos)
    {
        device.SetViewMatrix(matView);
    }

    device.SetWorldMatrix(matWorld);
}

int HaloManager::AddHalo()
{
    int handle;
    if (!m_Halos.empty())
        handle = m_Halos.back().handle + 1;
    else
        handle = 1;
    m_Halos.push_back(Halo(handle));
    return handle;
}

void HaloManager::UpdateHalo(int h, Vector3f position, ColorRGBA32 color, float size, UInt32 layers, Object* context)
{
    for (HaloList::iterator i = m_Halos.begin(); i != m_Halos.end(); i++)
    {
        if (i->handle == h)
        {
            i->position = position;
            i->color = color;
            i->size = size;
            i->layers = layers;
            return;
        }
    }
    AssertMsg(false, Format("Unable to update Halo (handle=%d)", h), context);
}

void HaloManager::DeleteHalo(int h, Object* context)
{
    for (HaloList::iterator i = m_Halos.begin(); i != m_Halos.end(); i++)
    {
        if (i->handle == h)
        {
            m_Halos.erase(i);
            return;
        }
    }
    AssertMsg(false, Format("Unable to remove Halo (handle=%d)", h), context);
}

void GetHaloVertexPositionsStereo(Vector3f* positionBuffer, const Vector3f& haloPosWS, const Vector3f& cameraPosWS, float size)
{
    const Vector3f direction = cameraPosWS - haloPosWS;
    Matrix3x3f transformation;
    Vector3f pts[9];

    if (!LookRotationToMatrix(direction, Vector3f::yAxis, &transformation))
    {
        LookRotationToMatrix(direction, Vector3f::xAxis, &transformation);
    }

    Vector3f right(transformation.GetColumn(0) * size);
    Vector3f up(transformation.GetColumn(1) * size);
    Vector3f forward(transformation.GetColumn(2));

    pts[0] = haloPosWS - forward * (size * 0.333f); // Indent the middle a little bit
    pts[1] = haloPosWS - right;
    pts[2] = haloPosWS - right - up;
    pts[3] = haloPosWS - up;
    pts[4] = haloPosWS + right - up;
    pts[5] = haloPosWS + right;
    pts[6] = haloPosWS + right + up;
    pts[7] = haloPosWS + up;
    pts[8] = haloPosWS - right + up;

    int index = 0;
    positionBuffer[index].Set(pts[0].x, pts[0].y, pts[0].z);    ++index;
    positionBuffer[index].Set(pts[0].x, pts[0].y, pts[0].z);    ++index;
    positionBuffer[index].Set(pts[1].x, pts[1].y, pts[1].z);    ++index;
    positionBuffer[index].Set(pts[0].x, pts[0].y, pts[0].z);    ++index;
    positionBuffer[index].Set(pts[2].x, pts[2].y, pts[2].z);    ++index;
    positionBuffer[index].Set(pts[0].x, pts[0].y, pts[0].z);    ++index;
    positionBuffer[index].Set(pts[3].x, pts[3].y, pts[3].z);    ++index;
    positionBuffer[index].Set(pts[0].x, pts[0].y, pts[0].z);    ++index;
    positionBuffer[index].Set(pts[4].x, pts[4].y, pts[4].z);    ++index;
    positionBuffer[index].Set(pts[0].x, pts[0].y, pts[0].z);    ++index;
    positionBuffer[index].Set(pts[5].x, pts[5].y, pts[5].z);    ++index;
    positionBuffer[index].Set(pts[0].x, pts[0].y, pts[0].z);    ++index;
    positionBuffer[index].Set(pts[6].x, pts[6].y, pts[6].z);    ++index;
    positionBuffer[index].Set(pts[0].x, pts[0].y, pts[0].z);    ++index;
    positionBuffer[index].Set(pts[7].x, pts[7].y, pts[7].z);    ++index;
    positionBuffer[index].Set(pts[0].x, pts[0].y, pts[0].z);    ++index;
    positionBuffer[index].Set(pts[8].x, pts[8].y, pts[8].z);    ++index;
    positionBuffer[index].Set(pts[0].x, pts[0].y, pts[0].z);    ++index;
    positionBuffer[index].Set(pts[1].x, pts[1].y, pts[1].z);    ++index;
    positionBuffer[index].Set(pts[0].x, pts[0].y, pts[0].z);    ++index;
    positionBuffer[index].Set(pts[0].x, pts[0].y, pts[0].z);    ++index;

    DebugAssertMsg(index == 21, "Expected to write 21 vertices");
}

void GetHaloVertexPositionsMono(Vector3f* positionBuffer, const Vector3f& haloPosVS, float size, float viewspaceHaloDepth)
{
    const Vector3f& v = haloPosVS;
    float z2 = viewspaceHaloDepth + size * 0.333f;

    int index = 0;
    positionBuffer[index].Set(v.x, v.y, z2);                ++index;
    positionBuffer[index].Set(v.x, v.y, z2);                ++index;
    positionBuffer[index].Set(v.x - size, v.y, v.z);        ++index;
    positionBuffer[index].Set(v.x, v.y, z2);                ++index;
    positionBuffer[index].Set(v.x - size, v.y - size, v.z); ++index;
    positionBuffer[index].Set(v.x, v.y, z2);                ++index;
    positionBuffer[index].Set(v.x, v.y - size, v.z);        ++index;
    positionBuffer[index].Set(v.x, v.y, z2);                ++index;
    positionBuffer[index].Set(v.x + size, v.y - size, v.z); ++index;
    positionBuffer[index].Set(v.x, v.y, z2);                ++index;
    positionBuffer[index].Set(v.x + size, v.y, v.z);        ++index;
    positionBuffer[index].Set(v.x, v.y, z2);                ++index;
    positionBuffer[index].Set(v.x + size, v.y + size, v.z); ++index;
    positionBuffer[index].Set(v.x, v.y, z2);                ++index;
    positionBuffer[index].Set(v.x, v.y + size, v.z);        ++index;
    positionBuffer[index].Set(v.x, v.y, z2);                ++index;
    positionBuffer[index].Set(v.x - size, v.y + size, v.z); ++index;
    positionBuffer[index].Set(v.x, v.y, z2);                ++index;
    positionBuffer[index].Set(v.x - size, v.y, v.z);        ++index;
    positionBuffer[index].Set(v.x, v.y, z2);                ++index;
    positionBuffer[index].Set(v.x, v.y, z2);                ++index;

    DebugAssertMsg(index == 21, "Expected to write 21 vertices");
}

void HaloManager::RenderGeometryJob(DynamicVBOGeometryJobData* jobData, unsigned int index)
{
    PROFILER_AUTO(gHaloGeometryJobProfile, 0)

    GeometryJobData& data = jobData->data[index];
    HaloManagerGeometryJob& userData = ((HaloManagerGeometryJob*)jobData->userData)[index];

    if (data.mappedVertexData)
    {
        HaloVertex* vbPtr = (HaloVertex*)data.mappedVertexData;
        Vector3f tempVertPosBuffer[21];

        for (int i = 0; i < userData.m_NumJobsInBatch; ++i)
        {
            const Halo& halo = userData.m_Halos[i];
            const float& viewspaceHaloDepth = halo.positionVS.z;
            float s = halo.size;
            int index = 0;
            // Dim this halo if near the camera (to avoid ugly intersection thingies).
            ColorRGBA32 c;
            if (viewspaceHaloDepth <= -s * 2.0f)
            {
                c = halo.color;
            }
            else
            {
                int fac = RoundfToInt((-viewspaceHaloDepth * 255.0f / s) - 255.0f);
                c = halo.color * fac;
            }
            c = GammaToActiveColorSpace(c);
            // Swizzle color of the renderer requires it
            c = GfxDevice::ConvertToDeviceVertexColor(c);

            // Halo vertex creation will be done in world space for stereo rendering and view space for mono
            // to avoid warping artifacts
            if (userData.m_renderStereoHalos)
            {
                GetHaloVertexPositionsStereo(tempVertPosBuffer, halo.position, userData.m_CameraWorldPos, s);
            }
            else
            {
                GetHaloVertexPositionsMono(tempVertPosBuffer, halo.positionVS, s, viewspaceHaloDepth);
            }

            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(.5f, .5f);  ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(.5f, .5f);  ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(0.0f, .5f); ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(.5f, .5f);  ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(0, 0);      ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(.5f, .5f);  ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(.5f, 0);    ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(.5f, .5f);  ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(1, 0);      ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(.5f, .5f);  ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(1, .5f);    ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(.5f, .5f);  ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(1, 1);      ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(.5f, .5f);  ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(.5f, 1);    ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(.5f, .5f);  ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(0, 1);      ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(.5f, .5f);  ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(0.0f, .5f); ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(.5f, .5f);  ++vbPtr; ++index;
            vbPtr->vert = tempVertPosBuffer[index]; vbPtr->color = c; vbPtr->uv.Set(.5f, .5f);  ++vbPtr; ++index;
        }
    }
}

void HaloManager::ReleaseGeometryJobMem(DynamicVBOGeometryJobData* jobData)
{
    PROFILER_AUTO(gHaloGeometryJobProfile, 0)
    BatchAllocator::DeallocateRoot(kMemTempJobAlloc, jobData);
}

IMPLEMENT_REGISTER_CLASS(HaloLayer, 125);

HaloLayer::HaloLayer(MemLabelId label, ObjectCreationMode mode)
    :   Super(label, mode)
{
}

void HaloLayer::ThreadedCleanup()
{
}

void InitializeHaloManager()
{
    Assert(s_Manager == NULL);
    s_Manager = UNITY_NEW(HaloManager, kMemDefault) ();
}

void CleanupHaloManager()
{
    Assert(s_Manager != NULL);
    UNITY_DELETE(s_Manager, kMemDefault);
}

HaloManager& GetHaloManager()
{
    return *s_Manager;
}
