#pragma once

#include "Runtime/Camera/CullResults.h"
#include "Runtime/Geometry/AABB.h"
#include "Runtime/GfxDevice/GfxDeviceConfigure.h"
#include "Runtime/Utilities/LinkedList.h"

class Light;
struct ShadowCullData;
class ColorRGBAf;
class GfxDevice;
struct GfxVertexLight;
struct ShaderPassContext;
namespace Umbra
{ class OcclusionBuffer; }

const int kMaxForwardVertexLights = 4;

// We reserve light buffers for this number of lights per object (in forward rendering)
const int kEstimatedLightsPerObject = 3;


class LightManager
{
public:
    LightManager();
    ~LightManager();

    static void InitializeClass();
    static void CleanupClass();

    void AddLight(Light* source);
    void RemoveLight(Light* source);

    typedef List<Light> Lights;
    Lights& GetAllLights() { return m_Lights; }
    const Lights& GetAllLights() const { return m_Lights; }

    ///Terrain engine only
    UNITY_VECTOR(kMemRenderer, Light*) GetLights(LightType type, int layer);

private:
    Lights  m_Lights;
};

LightManager& GetLightManager();
