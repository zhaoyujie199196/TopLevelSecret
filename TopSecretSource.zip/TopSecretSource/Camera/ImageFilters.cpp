#include "UnityPrefix.h"
#include "ImageFilters.h"
#include "Runtime/Graphics/RenderTexture.h"
#include "Runtime/Shaders/Material.h"
#include "CameraUtil.h"
#include "RenderManager.h"
#include "Runtime/Camera/Camera.h"
#include "Runtime/Graphics/RenderBufferManager.h"
#include "Runtime/Graphics/RenderSurface.h"
#include "Runtime/Graphics/GraphicsHelper.h"
#include "Runtime/GfxDevice/GfxDevice.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Shaders/ShaderImpl/ShaderImpl.h"
#include "Runtime/Shaders/ApplyKeywords.h"
#include "Runtime/Shaders/Shader.h"
#include "Runtime/Shaders/ShaderNameRegistry.h"
#include "Runtime/BaseClasses/GameObject.h"
#include "Runtime/Profiler/ExternalGraphicsProfiler.h"
#include "Runtime/Utilities/LogUtility.h"
#include "Runtime/Camera/CameraStack.h"
#include "Runtime/Interfaces/IVRDevice.h"

#if UNITY_UAP && ENABLE_HOLOLENS_MODULE
#include "PlatformDependent/MetroPlayer/AppCallbacks.h"
#endif

PROFILER_INFORMATION(gImageFxProfile, "Camera.ImageEffects", kProfilerRender);
PROFILER_INFORMATION(gGraphicsBlitProfile, "Graphics.Blit", kProfilerRender);

namespace ImageFilters_Static
{
    static SHADERPROP(MainTex);
    static SHADERPROP(CameraDepthTexture_ST);
    static SHADERPROP(CameraDepthNormalsTexture_ST);
    static SHADERPROP(LastCameraDepthTexture_ST);
    static SHADERPROP(LastCameraDepthNormalsTexture_ST);
} // namespace ImageFilters_Static


static Material* s_BlitMaterial = NULL;
static Material* s_BlitFromTexArrayMaterial = NULL;
static Material* s_BlitDepthMaterial = NULL;
static Material* s_BlitMaterialExt = NULL;

static void CleanupImageFilterGlobals(void*)
{
    s_BlitMaterial = NULL;
    s_BlitFromTexArrayMaterial = NULL;
    s_BlitDepthMaterial = NULL;
    s_BlitMaterialExt = NULL;
}

static RegisterRuntimeInitializeAndCleanup gAutoCleanup(NULL, CleanupImageFilterGlobals);

class BlitStereoHelper
{
public:
    BlitStereoHelper(GfxDevice &device, ShaderPassContext& passContext, RenderTexture *dest) : m_Device(device), m_PassContext(passContext)
    {
        bool stereo = false;
#if GFX_SUPPORTS_SINGLE_PASS_STEREO
        stereo = (dest && dest->GetVRUsage() == kVRTextureUsageTwoEyes);
        m_OldSinglePassStereo = device.GetSinglePassStereo();
        if (stereo != (m_OldSinglePassStereo != kSinglePassStereoNone))
            device.SetSinglePassStereo(stereo ? GetGraphicsCaps().singlePassStereo : kSinglePassStereoNone);

        m_SinglePassStereo = device.GetSinglePassStereo();
        if (m_SinglePassStereo == kSinglePassStereoSideBySide)
            passContext.keywords.Set(keywords::kSinglePassStereo, stereo);
        else if (m_SinglePassStereo == kSinglePassStereoInstancing)
            passContext.keywords.Set(keywords::kStereoInstancingOn, stereo);
        else if (m_SinglePassStereo == kSinglePassStereoMultiview)
            passContext.keywords.Set(keywords::kStereoMultiviewOn, stereo);
        if (stereo)
            m_Device.SaveStereoConstants();
#endif
        m_Stereo = stereo;

        SetFullScreenOrthoMatrix();
    }

    ~BlitStereoHelper()
    {
#if GFX_SUPPORTS_SINGLE_PASS_STEREO
        if (m_Stereo)
        {
            m_Device.RestoreStereoConstants();
            m_Device.SetSinglePassStereoEyeMask(kTargetEyeMaskBoth);
        }
        if (m_SinglePassStereo != m_OldSinglePassStereo)
            m_Device.SetSinglePassStereo(m_OldSinglePassStereo);
        else if (m_OldSinglePassStereo == kSinglePassStereoSideBySide)
            m_PassContext.keywords.Set(keywords::kSinglePassStereo, m_OldSinglePassStereo != kSinglePassStereoNone);
        else if (m_OldSinglePassStereo == kSinglePassStereoInstancing)
            m_PassContext.keywords.Set(keywords::kStereoInstancingOn, m_OldSinglePassStereo != kSinglePassStereoNone);
        else if (m_OldSinglePassStereo == kSinglePassStereoMultiview)
            m_PassContext.keywords.Set(keywords::kStereoMultiviewOn, m_OldSinglePassStereo != kSinglePassStereoNone);
#endif
    }

    void SetFullScreenOrthoMatrix()
    {
        Matrix4x4f orthoMatrix;
        orthoMatrix.SetOrtho(0.0f, 1.0f, 0.0f, 1.0f, -1.0f, 100.0f);

#if GFX_SUPPORTS_SINGLE_PASS_STEREO
        if (m_Stereo)
        {
            m_Device.SetWorldMatrix(Matrix4x4f::identity);
            for (int eye = 0; eye < kStereoscopicEyeCount; ++eye)
            {
                m_Device.SetStereoMatrix(MonoOrStereoscopicEye(eye), kShaderMatProj, orthoMatrix);
                m_Device.SetStereoMatrix(MonoOrStereoscopicEye(eye), kShaderMatView, Matrix4x4f::identity);
            }
        }
        else
#endif
        {
            // Implicitly sets world to identity
            GraphicsHelper::SetWorldViewAndProjection(m_Device, NULL, &Matrix4x4f::identity, &orthoMatrix);
        }
    }

    int GetEyeCount()
    {
        return m_Stereo ? 2 : 1;
    }

    bool GetStereo()
    {
        return m_Stereo;
    }

    void PrepareEyeRender(int eye, ShaderPropertySheet const& matProperties, ShaderPropertySheet &properties, bool setPropMainTex, Vector2f const& mainTexScale, Vector2f const& mainTexOffset, VRTextureUsage mainTexVRUsage)
    {
        using namespace ImageFilters_Static;

        Vector4f stereoScaleAndOffset(1.0f, 1.0f, 0.0f, 0.0f);

        if (GetIVRDevice() && GetIVRDevice()->GetStereoRenderingEnabled())
        {
            float renderViewportScale = GetIVRDevice()->GetRenderViewportScale();
            stereoScaleAndOffset.x = renderViewportScale;
            stereoScaleAndOffset.y = renderViewportScale;

#if GFX_SUPPORTS_SINGLE_PASS_STEREO
            if (m_SinglePassStereo == kSinglePassStereoSideBySide)
            {
                m_Device.SetSinglePassStereoEyeMask(eye == 0 ? kTargetEyeMaskLeft : kTargetEyeMaskRight);
                stereoScaleAndOffset.x *= 0.5f;
                stereoScaleAndOffset.z = eye * 0.5f;
            }
#endif
        }

        // Scale and offset for main texture
        if (setPropMainTex)
        {
            Vector2f scale(mainTexScale);
            Vector2f offset(mainTexOffset);
            if (mainTexVRUsage != kVRTextureUsageNone)
            {
                scale.x *= stereoScaleAndOffset.x;
                scale.y *= stereoScaleAndOffset.y;
                offset.x = offset.x * stereoScaleAndOffset.x + stereoScaleAndOffset.z;
                offset.y = offset.y * stereoScaleAndOffset.y + stereoScaleAndOffset.w;
            }
            properties.SetTextureScaleAndOffset(kSLPropMainTex, scale, offset);
        }

        // Scale and offset for material's side-by-side stereo textures
        int textureBeginIndex = matProperties.GetTypeBeginIndex(ShaderPropertySheet::kTypeTexture);
        int textureEndIndex = matProperties.GetTypeEndIndex(ShaderPropertySheet::kTypeTexture);
        for (int t = textureBeginIndex; t < textureEndIndex; ++t)
        {
            const ShaderLab::FastPropertyName& texName = matProperties.GetPropertyName(t);
            int texOffset = matProperties.FindTextureOffset(texName);
            if (texOffset < 0)
                continue;

            const ShaderPropertySheet::TextureProperty& texProp = matProperties.GetTextureValue(texOffset);
            if ((texProp.scaleOffsetVectorIndex == -1) || (texProp.texEnv.GetVRUsage() == kVRTextureUsageNone))
                continue;

            int scaleOffsetPropIndex = matProperties.GetTypeBeginIndex(ShaderPropertySheet::kTypeVector) + texProp.scaleOffsetVectorIndex;
            const ShaderLab::FastPropertyName& name = matProperties.GetPropertyName(scaleOffsetPropIndex);
            properties.SetVector(name, stereoScaleAndOffset);
        }

        // Scale and offset for globals
        properties.SetVector(kSLPropCameraDepthTexture_ST, stereoScaleAndOffset);
        properties.SetVector(kSLPropCameraDepthNormalsTexture_ST, stereoScaleAndOffset);
        properties.SetVector(kSLPropLastCameraDepthTexture_ST, stereoScaleAndOffset);
        properties.SetVector(kSLPropLastCameraDepthNormalsTexture_ST, stereoScaleAndOffset);
    }

private:
    bool m_Stereo;
    GfxDevice &m_Device;
    ShaderPassContext& m_PassContext;
    SinglePassStereo m_SinglePassStereo;
    SinglePassStereo m_OldSinglePassStereo;
};

// -----------------------------------------------------------------------------

static int GetImageFilterSortIndex(Unity::Component* component)
{
    GameObject* go = component->GetGameObjectPtr();
    int count = go ? go->GetComponentCount() : 0;
    for (int i = 0; i < count; ++i)
    {
        if (&go->GetComponentAtIndex(i) == component)
            return i;
    }
    return -1;
}

void ImageFilters::AddImageFilter(const ImageFilter& filter)
{
    // Case: 814402 Remove image filter before adding to
    // prevent duplicates / allow movement between afteropaque / after everything.
    // Duplicate can happen when prefabs are intialized (as follows)
    // * Awake from load (happens in 5.4 due to resolution of case 767851) - Added here
    // * Then OnEnable is called - Also added here
    RemoveImageFilter(filter);

    Filters& filters = filter.afterOpaque ? m_AfterOpaque : m_AfterEverything;

    // Insert the image filter by sort index.
    // Search backwards because in most cases the filters are added in sorted order.
    int insertIndex = GetImageFilterSortIndex(filter.component);
    for (int i = filters.size() - 1; i >= 0; --i)
    {
        if (insertIndex >= GetImageFilterSortIndex(filters[i].component))
        {
            Filters::iterator insertion = filters.begin() + i + 1;
            filters.insert(insertion, filter);
            return;
        }
    }
    filters.insert(filters.begin(), filter);
}

void ImageFilters::RemoveImageFilter(const ImageFilter& filter)
{
    for (Filters::iterator i = m_AfterOpaque.begin(); i != m_AfterOpaque.end(); /**/)
    {
        if (*i == filter)
            i = m_AfterOpaque.erase(i);
        else
            ++i;
    }
    for (Filters::iterator i = m_AfterEverything.begin(); i != m_AfterEverything.end(); /**/)
    {
        if (*i == filter)
            i = m_AfterEverything.erase(i);
        else
            ++i;
    }
}

RenderTexture* GetTemporaryRT(const RenderTextureDesc& currentDesc, bool requestHDR)
{
    RenderBufferManager& rbm = GetRenderBufferManager();
    RenderTextureDesc desc = currentDesc;
    desc.depthFormat = kDepthFormatNone;
    desc.colorFormat = GetRenderTextureColorFormat(requestHDR, false);
    desc.antiAliasing = 1;
    RenderTexture* rt = rbm.GetTempBuffer(desc);

    if (rt)
    {
        rt->CorrectVerticalTexelSize(true);
        rt->SetName("ImageEffects Temp");
    }
    return rt;
}

RenderTexture* GetTemporaryRT(bool depthBuffer, bool requestHDR, int antiAliasing, bool halfWidth, bool halfHeight, bool useRTArrays)
{
    RenderBufferManager& rbm = GetRenderBufferManager();
    RenderTexture* rt = rbm.GetTempBuffer(
            halfWidth  ? RenderBufferManager::kHalfSize : RenderBufferManager::kFullSize,
            halfHeight ? RenderBufferManager::kHalfSize : RenderBufferManager::kFullSize,
            depthBuffer ? kDepthFormatMin24bits_Stencil : kDepthFormatNone,
            // by gl/gles spec blitting won't work if dst have components missing from src
            // which is the case often on mobiles
            GetRenderTextureColorFormat(requestHDR, false),
            useRTArrays ? RenderBufferManager::kRBArray : 0,
            useRTArrays ? 2 : 0,
            kRTReadWriteDefault,
            rbm.GetActiveVRUsage(),
            antiAliasing);

    if (rt)
    {
        rt->CorrectVerticalTexelSize(true);
        rt->SetName("ImageEffects Temp");
    }
    return rt;
}

static void GetRenderTargetSurfaces(RenderTexture* dest, RenderSurfaceHandle& outColor, RenderSurfaceHandle& outDepth)
{
    if (dest && dest->Create())
    {
        outColor = dest->GetColorSurfaceHandle();
        outDepth = dest->GetDepthSurfaceHandle();
    }
    else
    {
        outColor = GetGfxDevice().GetBackBufferColorSurface();
        outDepth = GetGfxDevice().GetBackBufferDepthSurface();
    }
}

RenderTexture* ImageFilters::ApplyAfterOpaqueFilters() const
{
    ShaderPassContext& passContext = GetDefaultPassContext();
    CameraStackRenderingState& state = GetCurrentCameraStackState();
    //src and dst are same here as we need to continue rendering after!
    RenderTexture* target = state.GetSrcTextureForImageFilters();
    DoRender(passContext, target, target, m_AfterOpaque);
    // return state version here because if we have no RT but a
    // valid RB bound then this is needed for MRT
    // (have to return NULL).
    return state.GetTargetTexture();
}

RenderTexture* ImageFilters::ApplyAfterTransparentFilters() const
{
    ShaderPassContext& passContext = GetDefaultPassContext();
    CameraStackRenderingState& state = GetCurrentCameraStackState();
    RenderTexture* src = state.GetSrcTextureForImageFilters();
    RenderTexture* target = state.GetDstTextureForImageFilters();

    DoRender(passContext, src, target, m_AfterEverything);

    if (state.IsRenderingLastCamera())
        return state.GetAfterFinalCameraTarget();
    return state.GetTargetTexture();
}

void DoBlit(RenderTexture* src, RenderTexture* dst, const ImageFilter& filter)
{
    PROFILER_AUTO_GFX(gImageFxProfile, filter.component);

    if (dst)
        dst->Create();

    // Invoke actual image effect function
    filter.renderFunc(filter.component, src, dst);

#if UNITY_EDITOR
    if (RenderTexture::GetActive(0) != dst)
    {
        LogRepeatingWarningString("OnRenderImage() possibly didn't write anything to the destination texture!");
    }
#endif // UNITY_EDITOR
}

static bool GetDestRenderTargetSurfaces(RenderTexture* dest, RenderSurfaceHandle& outColor, RenderSurfaceHandle& outDepth)
{
    if (dest)
    {
        if (!dest->Create())
            return false;
    }

    if (dest)
    {
        outColor = dest->GetColorSurfaceHandle();
        outDepth = dest->GetDepthSurfaceHandle();
    }
    else
    {
        outColor = GetGfxDevice().GetBackBufferColorSurface();
        outDepth = GetGfxDevice().GetBackBufferDepthSurface();
    }

    return true;
}

void ImageFilters::SetSurfaceUseResolvedBuffer(RenderSurfaceHandle& dstRsColor, RenderSurfaceHandle& dstRsDepth, bool value)
{
    if (dstRsColor.IsValid() && dstRsColor.object->samples > 1)
    {
        GfxDevice& device = GetGfxDevice();
        UInt32 flags = value ? GfxDevice::kSurfaceUseResolvedBuffer : 0;

        // Figuring out when to reset the flag is left to GfxDevice implementation
        device.SetSurfaceFlags(dstRsColor, flags);
        if (dstRsDepth.IsValid())
            device.SetSurfaceFlags(dstRsDepth, flags);
    }
}

void ImageFilters::SetSurfaceUseResolvedBuffer(RenderTexture* rt, bool value)
{
    RenderSurfaceHandle dstRsColor = rt ? rt->GetColorSurfaceHandle() : GetGfxDevice().GetBackBufferColorSurface();
    RenderSurfaceHandle dstRsDepth = rt ? rt->GetDepthSurfaceHandle() : GetGfxDevice().GetBackBufferDepthSurface();

    SetSurfaceUseResolvedBuffer(dstRsColor, dstRsDepth, value);
}

static void DiscardTarget(RenderTexture* target)
{
    RenderSurfaceHandle dstRsColor, dstRsDepth;
    if (!GetDestRenderTargetSurfaces(target, dstRsColor, dstRsDepth))
        return;

    GfxDevice& device = GetGfxDevice();

    if (!dstRsColor.object->backBuffer)
        device.DiscardContents(dstRsColor);

    device.IgnoreNextUnresolveOnRS(dstRsDepth);
}

// While rendering image effects, m_AfterOpaque/m_AfterEverything can be modified (for ex., if image effect is unsupported, it will be removed from the list)
// thus it's unsafe to access them directly in the loop. Case 689621
void ImageFilters::DoRender(ShaderPassContext& passContext, RenderTexture* initialRt, RenderTexture* finalRT, Filters filters) const
{
    // Ignore image filters if we can't use them
    if (GetGraphicsCaps().npotRT == kNPOTNone)
        return;

    PROFILER_AUTO_GFX(gImageFxProfile, NULL)
    GPU_AUTO_SECTION(kGPUSectionPostProcess);

    RenderBufferManager& rbm = GetRenderBufferManager();
    RenderTexture* srcRT = initialRt;
    RenderTexture* dstRT = finalRT;


    //  AssertMsg(srcRT == dstRT || srcRT != NULL, "Attempting to render image effects with the source buffer being the backbuffer");

    int filterCount = filters.size();
    // No filters, just blit if needed
    if (filterCount == 0)
    {
        if (srcRT != dstRT)
        {
            SetSurfaceUseResolvedBuffer(dstRT, true);
            DiscardTarget(dstRT);

            int destSlice = 0;
            if (dstRT != 0 && dstRT->GetDimension() == kTexDim2DArray)
            {
                destSlice = -1;
            }

            GfxDevice& device = GetGfxDevice();
            RectInt oldViewport = device.GetViewport();

            CameraStackRenderingState& state = GetCurrentCameraStackState();
            if (state.IsRenderingLastCamera() && dstRT != NULL)
            {
                device.SetViewport(state.GetCurrentCamera()->GetScreenViewportRectInt());
                ImageFilters::Blit(passContext, srcRT, dstRT, destSlice, true);
            }
            else
            {
                ImageFilters::Blit(passContext, srcRT, dstRT, destSlice);
            }
            device.SetViewport(oldViewport);
        }
        return;
    }

    bool buffersInHDR = srcRT ? IsHDRRTFormat(srcRT->GetColorFormat()) : false;

    RenderTexture* currentSource = srcRT;
    // do blits for n-1
    // do last blit manually
    for (int i = 0; i < filterCount - 1; i++)
    {
        // start by getting a target buffer
        // convert to ldr if not after opaque and requested
        if (filters[i].transformsToLDR && buffersInHDR)
            buffersInHDR = false;

        RenderTexture* currentDestination;
        if (currentSource)
        {
            RenderTextureDesc desc = currentSource->GetRenderTextureDesc();
            if (GetActiveColorSpace() == kLinearColorSpace)
                desc.flags |= kRTFlagSRGB;
            currentDestination = GetTemporaryRT(desc, buffersInHDR);
        }
        else
        {
            currentDestination = GetTemporaryRT(false, buffersInHDR, 1, false, false, false);
        }

        DiscardTarget(currentDestination);
        DoBlit(currentSource, currentDestination, filters[i]);

        if (currentSource != srcRT)
            rbm.ReleaseTempBuffer(currentSource);

        currentSource = currentDestination;
    }

    // last filter
    {
        RenderTexture* currentDestination = dstRT;
        bool dstAndSrcIsSame = (currentSource == currentDestination);
        if (dstAndSrcIsSame)
        {
            if (currentDestination)
                currentDestination = GetTemporaryRT(currentDestination->GetRenderTextureDesc(), buffersInHDR);
            else
                currentDestination = GetTemporaryRT(false, buffersInHDR, 1, false, false, false);
        }

        SetSurfaceUseResolvedBuffer(currentDestination, PlatformSupportsMSAABB());
        DiscardTarget(currentDestination);

        DoBlit(currentSource, currentDestination, filters[filterCount - 1]);

        if (currentSource != srcRT)
            rbm.ReleaseTempBuffer(currentSource);

        if (dstAndSrcIsSame)
        {
            SetSurfaceUseResolvedBuffer(currentDestination, true);
            DiscardTarget(dstRT);

            int destSlice = 0;
            if (dstRT != 0 && dstRT->GetDimension() == kTexDim2DArray)
            {
                destSlice = -1;
            }

            ImageFilters::Blit(passContext, currentDestination, dstRT, destSlice);

            rbm.ReleaseTempBuffer(currentDestination);
        }
    }
}

Material* ImageFilters::GetBlitCopyMaterial(bool blitFromTexArray)
{
    if (!blitFromTexArray)
    {
        if (!s_BlitMaterial)
        {
            Shader* shader = GetScriptMapper().FindShader("Hidden/BlitCopy");
            if (shader == NULL)
            {
                ErrorStringMsg("Unable to use Blit. Shader is not yet initialized!");
                return NULL;
            }
            s_BlitMaterial = Material::CreateMaterial(*shader, Object::kHideAndDontSave);
        }
        return s_BlitMaterial;
    }

    if (!s_BlitFromTexArrayMaterial)
    {
        Shader* shader = GetScriptMapper().FindShader("Hidden/VR/BlitCopyFromTexArray");
        if (shader == NULL)
        {
            ErrorStringMsg("Unable to use Blit from Texture Array. Shader is not yet initialized!");
            return NULL;
        }
        s_BlitFromTexArrayMaterial = Material::CreateMaterial(*shader, Object::kHideAndDontSave);
    }
    return s_BlitFromTexArrayMaterial;
}

Material* ImageFilters::GetBlitCopyDepthMaterial()
{
    if (!s_BlitDepthMaterial)
    {
        Shader* shader = GetScriptMapper().FindShader("Hidden/BlitCopyDepth");
        if (shader == NULL)
        {
            ErrorStringMsg("Unable to use Blit. Shader is not yet initialized!");
            return NULL;
        }
        s_BlitDepthMaterial = Material::CreateMaterial(*shader, Object::kHideAndDontSave);
    }

    return s_BlitDepthMaterial;
}

Material* ImageFilters::GetConvertTextureMaterial()
{
    if (!s_BlitMaterialExt)
    {
        Shader* shader = GetScriptMapper().FindShader("Hidden/ConvertTexture");
        if (shader == NULL)
        {
            ErrorStringMsg("Unable to use Blit. Shader is not yet initialized!");
            return NULL;
        }
        s_BlitMaterialExt = Material::CreateMaterial(*shader, Object::kHideAndDontSave);
    }

    return s_BlitMaterialExt;
}

// -----------------------------------------------------------------------------

void ImageFilters::Blit(ShaderPassContext& passContext, Texture* source, RenderTexture* dest, int destSlice, bool dontSetViewport)
{
    // If we're doing a blit from NULL ("backbuffer") into destination,
    // do it the GrabPass way (since we can't sample backbuffer in a shader).
    if (source == NULL && dest != NULL)
    {
        Camera* cam = GetCurrentCameraPtr();
        Rectf r = Rectf(0, 0, dest->GetGPUWidth(), dest->GetGPUHeight());
        if (cam != NULL)
            r = cam->GetRenderRectangle();
        RectInt rect = RectfToRectInt(r);
        dest->GrabPixels(rect.x, rect.y, rect.width, rect.height);
        return;
    }

    // If we blit from and to the same texture without a material we can just early out
    if (source == dest)
        return;

    bool useRTArrays = source->GetDimension() == kTexDim2DArray;
    // If we're doing a blit from a depth texture then we should use the BlitCopyDepth material, else we
    // can use BlitCopy, required for platforms that have to use a different texture sampling method when
    // sampling from a single component texture.
    Material* blitMaterial = source->IsDepthTexture() ? GetBlitCopyDepthMaterial() : GetBlitCopyMaterial(useRTArrays);
    if (blitMaterial == NULL)
        return;

    ImageFilters::BlitFlags flags = ImageFilters::kBlitFlagsSetRT;
    if (dontSetViewport)
        flags |= ImageFilters::kBlitFlagsDontSetViewport;

    Blit(passContext, source, dest, destSlice, blitMaterial, -1, flags);
}

void ImageFilters::DrawQuad(GfxDevice& device, ShaderChannelMask channels, bool invertY, const Rectf& texcoords)
{
    GraphicsHelper::DrawQuad(device, channels, invertY, texcoords);
    GPU_TIMESTAMP();
}

static void SetMultiTapTexCoords(GfxDevice& device, float invSourceSizeX, float invSourceSizeY, float x, float y, bool invertY, int count, const Vector2f* offsets)
{
    for (int i = 0; i < count; ++i)
    {
        Vector2f offset = offsets[i];
        if (invertY)
            offset.y = -offset.y;
        offset.x *= invSourceSizeX;
        offset.y *= invSourceSizeY;
        device.ImmediateTexCoord(i, x + offset.x, y + offset.y, 0.0f);
    }
}

static void SetCurrentRenderTarget(RenderTexture* dest, int destSlice, RenderTexture::SetActiveFlags flags, CubemapFace cubemapFace)
{
    RenderSurfaceHandle rsColor, rsDepth;
    GetRenderTargetSurfaces(dest, rsColor, rsDepth);

    bool needsDestSlice = dest && (dest->GetDimension() == kTexDim2DArray || dest->GetDimension() == kTexDim3D || dest->GetDimension() == kTexDimCubeArray);
    RenderTexture::SetActive(1, &rsColor, rsDepth, &dest, 0, cubemapFace, needsDestSlice ? destSlice : 0, flags);
}

static bool IsActiveRenderTextureMSAA()
{
    RenderTexture* rt = RenderTexture::GetActive();
    return (rt && rt->IsAntiAliased());
}

void ImageFilters::SetupRenderTargetCommon(GfxDevice& device, Texture* source, RenderTexture* dest, int destSlice, BlitFlags blitFlags, CubemapFace cubemapFace)
{
    bool setRT = (blitFlags & kBlitFlagsSetRT) != 0;
    bool dontSetViewport = (blitFlags & kBlitFlagsDontSetViewport) != 0;
    RenderTexture::SetActiveFlags rtFlags = RenderTexture::kFlagNone;

    // MSAA render targets must be resolved before they are used.
    if (IsActiveRenderTextureMSAA())
    {
        setRT = true;
        rtFlags |= RenderTexture::kFlagForceResolve;
    }
    // If random write targets are set, we must flush those changes (case 727743)
    if (device.HasActiveRandomWriteTarget())
    {
        setRT = true;
    }

    if (dontSetViewport)
        rtFlags |= RenderTexture::kFlagDontSetViewport;

    if (setRT)
        SetCurrentRenderTarget(dest, destSlice, rtFlags, cubemapFace);
}

//ImageFilter::Blit to be used from RenderingCommandBuffers
void ImageFilters::Blit(ShaderPassContext &passContext, Texture *source, RenderTexture *dest, int destSlice, const SharedMaterialData *mat, const char* matName, Shader* shader, int pass, BlitFlags flags, CubemapFace cubemapFace, Vector2f const &sourceScale, Vector2f const &sourceOffset)
{
    using namespace ImageFilters_Static;
    PROFILER_AUTO(gGraphicsBlitProfile, mat->shader)

    ShaderLab::SubShader& subshader = shader->GetShaderLabShader()->GetSubShader(0);
    int passCount = subshader.GetValidPassCount();
    int passBegin = 0;
    int passEnd = 0;

    if (pass == -1)
    {
        passBegin = 0;
        passEnd = passCount;
    }
    else if (pass >= 0 && pass < passCount)
    {
        passBegin = pass;
        passEnd = pass + 1;
    }
    else
    {
        ErrorStringMsg("Invalid pass number (%d) for Graphics.Blit (Material \"%s\" with %d passes)", pass, matName, passCount);
        return;
    }

    GfxDevice& device = GetGfxDevice();

    DeviceMVPMatricesState preserveMVP;

    // turn off any global wireframe & "scene view wireframe shader hijack" settings for doing blits:
    // we never want them to show up as wireframe
    SetAndRestoreWireframeMode turnoffWireframe(false);
#if UNITY_EDITOR
    extern const ShaderLab::ShaderState* g_EditorPixelShaderOverride;
    extern const ShaderLab::ShaderState* g_EditorPixelShaderOverrideSM3;
    const ShaderLab::ShaderState* prevPSOverride = g_EditorPixelShaderOverride;
    const ShaderLab::ShaderState* prevPSOverrideSM3 = g_EditorPixelShaderOverrideSM3;
    g_EditorPixelShaderOverride = NULL;
    g_EditorPixelShaderOverrideSM3 = NULL;
#endif

    BlitStereoHelper stereoHelper(device, passContext, dest);

    SetupRenderTargetCommon(device, source, dest, destSlice, flags, cubemapFace);

    bool invertY = source && source->GetTexelSizeY() < 0.0f;

#if UNITY_UAP && ENABLE_HOLOLENS_MODULE
    invertY = invertY || (device.GetSinglePassStereo() == kSinglePassStereoInstancing && UnityPlayer::AppCallbacks::IsRunningOnHoloLens() && dest && dest->IsEyeTexture());
#endif

    Rectf texcoords(0, 0, 1.0f, 1.0f);
    if (source && source->GetUsageMode() == kTexUsageAlwaysPadded)
    {
        texcoords.width = (float)source->GetDataWidth() / (float)source->GetGPUWidth();
        texcoords.height = (float)source->GetDataHeight() / (float)source->GetGPUHeight();
    }

    ApplyKeywords applyKeywords(mat->shaderKeywordSet, passContext);

    ShaderPropertySheet properties(kMemTempAlloc);

    if (flags & kBlitFlagsSetMainTex)
    {
        properties.SetTexture(kSLPropMainTex, source);
    }

    VRTextureUsage sourceVRUsage = (source != NULL) ? source->GetVRUsage() : kVRTextureUsageNone;
    bool useInstancing = (device.GetSinglePassStereo() == kSinglePassStereoInstancing || device.GetSinglePassStereo() == kSinglePassStereoMultiview);
    const int eyeCount = useInstancing ? 1 : stereoHelper.GetEyeCount();
    for (int eye = 0; eye < eyeCount; ++eye)
    {
        stereoHelper.PrepareEyeRender(eye, mat->properties, properties, flags & kBlitFlagsSetMainTex, sourceScale, sourceOffset, sourceVRUsage);

        for (int i = passBegin; i < passEnd; ++i)
        {
            ShaderLab::Pass* shaderPass = subshader.GetPass(i);
            ShaderChannelMask channels = shaderPass->ApplyPass(mat->stateKeyHash, &mat->properties, passContext, shader, i);
            device.SetShaderPropertiesCopied(properties);
            DrawQuad(device, channels, invertY, texcoords);
        }
    }

#if UNITY_EDITOR
    g_EditorPixelShaderOverride = prevPSOverride;
    g_EditorPixelShaderOverrideSM3 = prevPSOverrideSM3;
#endif
}

void ImageFilters::Blit(ShaderPassContext& passContext, Texture* source, RenderTexture* dest, int destSlice, Material* mat, int pass, BlitFlags flags, CubemapFace cubemapFace, Vector2f const &sourceScale, Vector2f const &sourceOffset)
{
    ASSERT_RUNNING_ON_MAIN_THREAD
    using namespace ImageFilters_Static;
    mat->UpdateHashesIfNeeded();
    const SharedMaterialData& materialData = mat->GetSharedMaterialData();
    Shader* shader = mat->GetShader();
    if (!(flags & kBlitFlagsSetMainTex))
    {
        if (mat->HasProperty(kSLPropMainTex))
            flags |= kBlitFlagsSetMainTex;
    }
    Blit(passContext, source, dest, destSlice, &materialData, mat->GetName(), shader, pass, flags, cubemapFace, sourceScale, sourceOffset);
}

void ImageFilters::BlitMultiTap(ShaderPassContext& passContext, Texture* source, RenderTexture* dest, int destSlice, Material* mat, int count, const Vector2f* offsets, CubemapFace cubemapFace)
{
    using namespace ImageFilters_Static;

    PROFILER_AUTO(gGraphicsBlitProfile, mat->GetShader())

    RenderTexture::SetActiveFlags rtFlags = RenderTexture::kFlagNone;

    // MSAA render targets must be resolved before they are used.
    if (IsActiveRenderTextureMSAA())
    {
        rtFlags |= RenderTexture::kFlagForceResolve;
    }
    SetCurrentRenderTarget(dest, destSlice, rtFlags, cubemapFace);

    ShaderPropertySheet properties(kMemTempAlloc);
    const bool setPropMainTex = source && mat->HasProperty(kSLPropMainTex);
    if (setPropMainTex)
    {
        properties.SetTexture(kSLPropMainTex, source);
    }

    bool invertY = source && source->GetTexelSizeY() < 0.0f;

    float uvX = 1.0f, uvY = 1.0f;
    int texWidth = 0, texHeight = 0;
    if (source)
    {
        texWidth = source->GetGPUWidth();
        texHeight = source->GetGPUHeight();
    }

    GfxDevice& device = GetGfxDevice();
    DeviceMVPMatricesState preserveMVP;
    BlitStereoHelper stereoHelper(device, passContext, dest);

    const int eyeCount = stereoHelper.GetEyeCount();
    ShaderPropertySheet const &matProperties = mat->GetProperties();

    VRTextureUsage sourceVRUsage = (source != NULL) ? source->GetVRUsage() : kVRTextureUsageNone;
    for (int eye = 0; eye < eyeCount; ++eye)
    {
        stereoHelper.PrepareEyeRender(eye, matProperties, properties, setPropMainTex, Vector2f(1.0f, 1.0f), Vector2f(0.0f, 0.0f), sourceVRUsage);

        int npasses = mat->GetPassCount();
        for (int i = 0; i < npasses; ++i)
        {
            float y1, y2;
            if (invertY)
            {
                y1 = uvY; y2 = 0.0f;
            }
            else
            {
                y1 = 0.0f; y2 = uvY;
            }
            float invSizeX = source ? 1.0f / texWidth : 0.0f;
            float invSizeY = source ? 1.0f / texHeight : 0.0f;

            mat->SetColor(ShaderLab::Property("_BlurOffsets"), ColorRGBAf(offsets[0].x, offsets[0].y, 0.0f, y1));
            ShaderChannelMask channels = mat->SetPassSlow(i, passContext);
            device.SetShaderPropertiesCopied(properties);
            device.ImmediateBegin(kPrimitiveQuads, channels);

            SetMultiTapTexCoords(device, invSizeX, invSizeY, 0.0f, y1, invertY, count, offsets);
            device.ImmediateVertex(0.0f, 0.0f, 0.1f);

            SetMultiTapTexCoords(device, invSizeX, invSizeY, 0.0f, y2, invertY, count, offsets);
            device.ImmediateVertex(0.0f, 1.0f, 0.1f);

            SetMultiTapTexCoords(device, invSizeX, invSizeY, uvX, y2, invertY, count, offsets);
            device.ImmediateVertex(1.0f, 1.0f, 0.1f);

            SetMultiTapTexCoords(device, invSizeX, invSizeY, uvX, y1, invertY, count, offsets);
            device.ImmediateVertex(1.0f, 0.0f, 0.1f);

            device.ImmediateEnd();
            GPU_TIMESTAMP();
        }
    }

    if (setPropMainTex)
        mat->SetTexture(kSLPropMainTex, NULL);
}
