#pragma once

#include "BaseRenderer.h"
#include "Lighting.h"
#include "ShaderReplaceData.h"
#include "SharedLightData.h"
#include "CullingParameters.h"
#include "Runtime/Math/Rect.h"
#include "Runtime/Geometry/Sphere.h"
#include "SceneNode.h"
#include "Runtime/Jobs/JobTypes.h"
#include "Runtime/Graphics/Texture.h"
#include "Runtime/Utilities/NonCopyable.h"

class SharedLightData;
struct ShadowCullData;
struct ShadowedLight;
struct SharedRendererScene;

namespace Umbra
{ class Visibility; class Tome; class ShadowCullerExt; }

struct ActiveLight
{
    const SharedLightData* light;

    LightBakingOutput   bakingOutput;
    int                shadowedLightIndex;

    bool insideShadowRange;

    // For vertex lights we have to keep all lights around when doing per-object culling.
    // This is because vertex lights can still affect objects (vertex interpolation on large triangles) although the light itself might be completely invisible.
    bool isVisibleInPrepass;
    LightmapModeForRender  lightmapModeForRendering;
    UInt32 cullingMask;
    bool intersectsNear;
    bool intersectsFar;
    AABB boundingBox;
    Rectf screenRects[kStereoscopicEyeCount];
    bool hasStereoScreenRects;
    bool hasCookie;
    TextureRef cookieTexRef;
    LightRenderMode lightRenderMode;
    LightType lightType;
    Vector4f lightBSphere;
    Sphere cullSphere;  //  Initialized once per light in SetupActiveLocalLight and used NumVisibleObject times in object<->light culling tests
    float luminance;
    // Some lights are offscreen
    bool  isOffscreenVertexLight;
    float visibilityFade;
};

struct ActiveLights
{
    typedef dynamic_array<ActiveLight> Array;
    Array lights;

    // If there is a main directional light, it will be the first one in lights.
    bool hasMainLight;

    // Lights are sorted by type in the following order
    size_t numDirLights;
    size_t numSpotLights;
    size_t numPointLights;
    size_t numOffScreenSpotLights;
    size_t numOffScreenPointLights;

    bool hasShadowedDirLights;
    bool hasShadowMaskInDirLights;
    bool hasShadowMaskInLocalLights;

    ActiveLights() : lights(kMemTempJobAlloc), hasMainLight(false), numDirLights(0), numSpotLights(0), numPointLights(0),
        numOffScreenSpotLights(0), numOffScreenPointLights(0), hasShadowedDirLights(false), hasShadowMaskInDirLights(false), hasShadowMaskInLocalLights(false) {}
    ~ActiveLights();
};

struct ShadowedLight
{
    // Index into CullResults.activeLights array
    int                     lightIndex;

    MinMaxAABB              visibleShadowCasterBounds;
    CullingOutput           visibleShadowCasters;
    JobFence                shadowCasterCullingOutputIsReady;

    SceneCullingParameters  sceneCullParameters;
    Umbra::ShadowCullerExt* shadowCuller;

    ShadowedLight() : shadowCuller(NULL) {}
};

struct CulledLight
{
    CulledLight(UInt32 index, float intensity)
    {
        lightIndex = index;
        sortIntensity = intensity;
    }

    UInt32 lightIndex;
    float sortIntensity;
    friend bool operator<(const CulledLight& lhs, const CulledLight& rhs)
    {
        return lhs.sortIntensity > rhs.sortIntensity;
    }
};


typedef dynamic_array<UInt32> ObjectLightIndices;
typedef dynamic_array<UInt32> ObjectLightOffsets;
typedef dynamic_array<CulledLight> ObjectCulledLights;
typedef dynamic_array<ShadowedLight> ShadowedLights;
typedef dynamic_array<BaseRenderer*> NeedsCullCallback;

/// CullResults lives during the entire duration of rendering one frame.
/// Shadow culling uses data from the frustum/occlusion cull pass
/// The render loop uses CullResults to render the scene.

///@TODO: Maybe it would make sense to turn this into a class protect all access and enforce correct fences through getters.

struct CullResults : public NonCopyable
{
    CullResults();
    ~CullResults();

    void Init(const Umbra::Tome* tome);
    void InitDynamic(const RendererCullData* rendererCullData);

    JobFence                occlusionBufferIsReady;
    JobFence                sceneCullingOutputIsReady;
    JobFence                addLocalLightsFence;
    JobFence                cullLocalLightsFence;
    CullingOutput           sceneCullingOutput;

    JobFence                nodesHaveBeenPrepared;
    NeedsCullCallback       needsCullCallback;
    NeedsCullCallback       rendererCullCallbacks[kRendererTypeCount];

    // All lights that might affect any visible objects
    //@TODO: Ownership in SharedRendererScene. No need to copy...
    ActiveLights           activeLights;
    dynamic_array<UInt8>   isShadowCastingLight;

    // All lights that cast shadows on any objects in the scene
    ShadowedLights         shadowedLights;

    SceneCullingParameters sceneCullParameters;

    dynamic_array<LODDataArray> lodDataArrays;

    //@TODO: This should really not be copied here
    // but instead the data should be laid out so we can simply reference it.
    dynamic_array<SceneNode> treeSceneNodes;
    dynamic_array<AABB> treeBoundingBoxes;

    ShadowCullData* shadowCullData;

    JobFence generateCombinedDynamicListReady;
    dynamic_array<int> visibleSceneIndexListCombined;
    dynamic_array<Vector3f> dynamicBounds;

    ShaderReplaceData shaderReplaceData;

    /// Whether the instance have been fully initialized with results from a culling process.
    /// This is mostly a gross hack to work around the fact that because the camera's culling
    /// and rendering code is scattered all over the place and called with the same patterns
    /// from many places, we don't have one place where we can prevent recursive rendering on
    /// cameras from one single point.
    bool isValid;

    SharedRendererScene* sharedRendererScene;

    const SharedRendererScene* GetOrCreateSharedRendererScene();
    void DestroySharedRendererScene();
};

void InitIndexList(IndexList& list, size_t count);
void DestroyIndexList(IndexList& list);

void CreateCullingOutput(const RendererCullData* rendererCullData, CullingOutput& cullingOutput);
void DestroyCullingOutput(CullingOutput& cullingOutput);

void CopyActiveLights(const ActiveLights& src, ActiveLights& dst);

inline const ActiveLight* GetMainActiveLight(const ActiveLights& activeLights)
{
    return activeLights.hasMainLight ? &activeLights.lights[0] : NULL;
}

void SetCullingPlanes(CullingParameters& parameters, const Plane* planes, int planeCount);

void CalculateCustomCullingParameters(CullingParameters& cullingParameters, const LODParameters& lodParams, UInt32 cullingMask, const Plane* planes, int planeCount);

void SyncFenceCullResults(CullResults& results);
