#pragma once

#include "Runtime/GfxDevice/GfxDeviceTypes.h"
#include "Runtime/Math/Rect.h"
#include "Runtime/Math/Vector2.h"
#include <Runtime/GfxDevice/GfxDeviceObjects.h>
#include <Runtime/Graphics/RenderSurface.h>

class GfxDevice;
class Material;
struct SharedMaterialData;
class RenderTexture;
class Texture;
class GfxDevice;
class Shader;
struct ShaderPassContext;

namespace Unity
{ class Component; }

typedef void RenderImageFilterFunc (Unity::Component* component, RenderTexture* source, RenderTexture* dest);

struct ImageFilter
{
    Unity::Component* component;
    RenderImageFilterFunc* renderFunc;

    bool transformsToLDR;
    bool afterOpaque;

    ImageFilter(Unity::Component* inComponent, RenderImageFilterFunc* inRenderFunc, bool inLDR, bool inAfterOpaque)
        : component(inComponent), renderFunc(inRenderFunc),  transformsToLDR(inLDR), afterOpaque(inAfterOpaque) {}

    bool operator==(const ImageFilter& o) const { return component == o.component && renderFunc == o.renderFunc; }
    bool operator!=(const ImageFilter& o) const { return component != o.component || renderFunc != o.renderFunc; }
};


// Image filters functionality. Only used internally by the camera (and other minor places).
class ImageFilters
{
private:
    typedef std::vector<ImageFilter> Filters;

public:
    ImageFilters() {}

    void AddImageFilter(const ImageFilter& filter);
    void RemoveImageFilter(const ImageFilter& filter);
    bool HasImageFilter() const { return !(m_AfterOpaque.empty() && m_AfterEverything.empty()); }
    bool HasAfterOpaqueFilters() const { return !m_AfterOpaque.empty(); }
    bool HasAfterEverythingFilters() const { return !m_AfterEverything.empty(); }

    RenderTexture* ApplyAfterOpaqueFilters() const;
    RenderTexture* ApplyAfterTransparentFilters() const;

    static void SetSurfaceUseResolvedBuffer(RenderSurfaceHandle& dstRsColor, RenderSurfaceHandle& dstRsDepth, bool value);
    static void SetSurfaceUseResolvedBuffer(RenderTexture* rt, bool value);

    enum BlitFlags
    {
        kBlitFlagsNone = 0,
        kBlitFlagsSetRT = 1 << 0,
        kBlitFlagsSetMainTex = 1 << 1,
        kBlitFlagsDontSetViewport = 1 << 2
    };

    static void SetupRenderTargetCommon(GfxDevice& device, Texture* source, RenderTexture* dest, int destSlice, BlitFlags blitFlags, CubemapFace cubemapFace);
    static void Blit(ShaderPassContext& passContext, Texture* source, RenderTexture* dest, int destSlice, bool dontSetViewport = false);
    static void Blit(ShaderPassContext& passContext, Texture* source, RenderTexture* dest, int destSlice, Material* mat, int pass, BlitFlags flags, CubemapFace cubemapFace = kCubeFaceUnknown, Vector2f const &sourceScale = Vector2f::one, Vector2f const &sourceOffset = Vector2f::zero);
    static void Blit(ShaderPassContext &passContext, Texture *source, RenderTexture *dest, int destSlice, const SharedMaterialData *mat, const char* matName, Shader* shader, int pass, BlitFlags flags, CubemapFace cubemapFace  = kCubeFaceUnknown, Vector2f const &sourceScale = Vector2f::one, Vector2f const &sourceOffset = Vector2f::zero);
    static void BlitMultiTap(ShaderPassContext& passContext, Texture* source, RenderTexture* dest, int destSlice, Material* mat, int count, const Vector2f* offsets, CubemapFace cubemapFace = kCubeFaceUnknown);
    static void DrawQuad(GfxDevice& device, ShaderChannelMask channels, bool invertY, const Rectf& texcoords);

    static Material* GetBlitCopyMaterial(bool blitFromTexArray = false);
    static Material* GetBlitCopyDepthMaterial();
    static Material* GetConvertTextureMaterial();

private:
    void DoRender(ShaderPassContext& passContext, RenderTexture* srcRT, RenderTexture* finalRT, Filters filters) const;

private:
    Filters         m_AfterOpaque;
    Filters         m_AfterEverything;
};

ENUM_FLAGS(ImageFilters::BlitFlags);
