#include "UnityPrefix.h"
#include "LightManager.h"
#include "LightUtil.h"
#include "LightTypes.h"
#include "Runtime/GfxDevice/GfxDevice.h"
#include "Runtime/Camera/LightProbes.h"
#include "Runtime/Misc/BuildSettings.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Profiler/ExternalGraphicsProfiler.h"
#include "Runtime/Graphics/LightmapSettings.h"
#include "Runtime/Transform/Transform.h"

PROFILER_INFORMATION(gCullLights, "Cull Lights", kProfilerRender)

static LightManager * s_LightManager = NULL;

LightManager& GetLightManager()
{
    DebugAssert(s_LightManager != NULL);
    return *s_LightManager;
}

void LightManager::InitializeClass()
{
    DebugAssert(s_LightManager == NULL);
    s_LightManager = new LightManager();
}

void LightManager::CleanupClass()
{
    DebugAssert(s_LightManager != NULL);
    delete s_LightManager;
    s_LightManager = NULL;
}

LightManager::LightManager()
{
}

LightManager::~LightManager()
{
}

void LightManager::AddLight(Light* source)
{
    DebugAssert(source);

    m_Lights.push_back(*source);
}

void LightManager::RemoveLight(Light* source)
{
    DebugAssert(source && source->IsInList());

    m_Lights.erase(source);
}

UNITY_VECTOR(kMemRenderer, Light*) LightManager::GetLights(LightType type, int layer)
{
    UNITY_VECTOR(kMemRenderer, Light*) lights;
    layer = 1 << layer;
    for (LightManager::Lights::iterator i = m_Lights.begin(); i != m_Lights.end(); i++)
    {
        Light* light = &*i;
        if (!light)
            continue;
        if (light->GetLightType() == type && (light->GetCullingMask() & layer) != 0)
            lights.push_back(light);
    }

    return lights;
}
