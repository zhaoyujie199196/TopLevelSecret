#pragma once

#include "Runtime/Math/Vector3.h"
#include "Runtime/Math/Color.h"
#include "Runtime/GameCode/Behaviour.h"

struct CullResults;
struct DynamicVBOGeometryJobData;
struct ShaderPassContext;
class Matrix4x4f;

class Halo : public Behaviour
{
    REGISTER_CLASS(Halo);
    DECLARE_OBJECT_SERIALIZE();
public:
    Halo(MemLabelId label, ObjectCreationMode mode);
    static void InitializeClass();
    static void CleanupClass();

    virtual void AddToManager();
    virtual void RemoveFromManager();
    virtual void Reset();
    void TransformChanged();
    virtual void AwakeFromLoad(AwakeFromLoadMode awakeMode);

private:
    ColorRGBA32 m_Color;
    float m_Size;
    int m_Handle;
};


class HaloManager
{
public:

    int AddHalo();
    void UpdateHalo(int h, Vector3f position, ColorRGBA32 color, float size, UInt32 layers, Object* context);
    void DeleteHalo(int h, Object* context);

    void RenderHalos(const CullResults* CullResults, ShaderPassContext& passContext, const Matrix4x4f& worldToCamera);

    struct Halo
    {
        Vector3f position;
        Vector3f positionVS;
        ColorRGBA32 color;
        float size;
        int handle;
        UInt32 layers;

        Halo() {}
        Halo(int hdl);
        Halo(const Vector3f &pos, const ColorRGBA32 &col, float s, int h, UInt32 _layers);
    };

private:

    static void RenderGeometryJob(DynamicVBOGeometryJobData* jobData, unsigned int index);
    static void ReleaseGeometryJobMem(DynamicVBOGeometryJobData* jobData);

    typedef std::vector<Halo> HaloList;
    HaloList m_Halos;
};

HaloManager& GetHaloManager();
void InitializeHaloManager();
void CleanupHaloManager();


// DEPRECATED
class HaloLayer : public Behaviour
{
    REGISTER_CLASS(HaloLayer);
public:
    HaloLayer(MemLabelId label, ObjectCreationMode mode);
    virtual void AddToManager() {}
    virtual void RemoveFromManager() {}
};
