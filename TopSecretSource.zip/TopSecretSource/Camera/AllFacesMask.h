#pragma once

enum { kAllFacesMask = 63 };
