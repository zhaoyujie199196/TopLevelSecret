#pragma once

#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Camera/CullingParameters.h"
#include "Runtime/BaseClasses/BaseObject.h"
#include "External/boost/dynamic_bitset.h"

class Transform;
struct JobFence;
class Vector4f;
class Camera;
struct CullingGroupEvent;

class CullingGroup
{
public:

    enum CullingUpdateType
    {
        kUpdateNothing                  = 0x00,
        kUpdateVisibility               = 0x01,
        kUpdateDistance                 = 0x02,
        kUpdateVisibilityAndDistance    = kUpdateVisibility | kUpdateDistance
    };

    enum QueryOptions
    {
        kNoOptions = 0,
        kIgnoreVisibility = 1,
        kIgnoreDistance = 2
    };

    enum
    {
        kDistanceIndexMask = (1 << 7) - 1,
        kIsVisible = 1 << 7
    };

    CullingGroup();
    ~CullingGroup();

    void            SetEnabled(bool enabled);
    bool            GetEnabled() const { return m_GroupIndex != -1; }

    void            SetBoundingSpheres(ScriptingArrayPtr array);
    void            SetBoundingSphereCount(UInt32 count);

    PPtr<Camera>    GetTargetCamera() const             { return m_TargetCamera; }
    void            SetTargetCamera(PPtr<Camera> val)   { m_TargetCamera = val; }

    void            EraseSwapBack(unsigned index);

    const Vector4f* GetBoundingSpheres() const         { return m_BoundingSpheres; }
    int             GetBoundingSphereCount() const     { return m_BoundingSphereCount; }

    UInt8*          GetCurrentStateBuffer()             { return &m_ThisFrameState[0]; }

    size_t          QueryIndices(bool visible, int distanceBand, QueryOptions options, UInt32* buffer, UInt32 firstIndex, size_t bufferSize) const;
    bool            IsVisible(UInt32 index) const;

    const math::float4*         GetBoundingDistances()          { return (math::float4*)(m_Distances.begin()); }
    size_t                      GetBoundingDistancesCount() const       { return m_Distances.size(); }
    bool                        GetLastBoundingDistanceIsInfinity() const { return m_LastDistanceIsInfinity; }

    void            SetBoundingDistances(const float* distances, size_t count);
    void            SetDistanceReferencePoint(const math::float3& point);
    void            SetDistanceReferenceTransform(const Transform* transform);
    math::float3    GetEffectiveDistanceReferencePoint() const;

    int             GetDistance(UInt32 index) const;

    CullingUpdateType GetUpdateType() const;

    void            SetScriptingObject(ScriptingObjectPtr object);

private:

    friend class CullingGroupManager;

    void NotifyVisible();
    void NotifyInvisible();
    void Init();

    void SendEvents(const CullingGroupEvent* events, size_t count);


    ScriptingGCHandle                   m_ScriptingWrapperGCHandle;
    bool                                m_ShouldSendEvents;

    int                                 m_GroupIndex;

    PPtr<Camera>                        m_TargetCamera;

    Vector4f*                           m_BoundingSpheres;
    UInt32                              m_BoundingSphereReservedSize;
    UInt32                              m_BoundingSphereCount;

    dynamic_array<UInt8>                m_ThisFrameState;
    dynamic_array<UInt8>                m_PrevFrameState;

    math::float3                        m_DistanceReferencePoint;
    PPtr<Transform>                     m_DistanceReferenceTransform;

    dynamic_array<math::float4_storage_aligned, 16>     m_Distances;
    bool                                m_LastDistanceIsInfinity;

    ScriptingGCHandle                   m_ManagedBoundingSphereArrayHandle;
};
