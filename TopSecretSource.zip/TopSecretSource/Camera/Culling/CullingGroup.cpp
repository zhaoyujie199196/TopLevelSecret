#include "UnityPrefix.h"
#include "CullingGroup.h"
#include "CullingGroupManager.h"
#include "Runtime/Scripting/ScriptingExportUtility.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Scripting/ScriptingInvocation.h"

using namespace Scripting;

// This needs to match CullingGroupEvent on the managed side, defined in CullingGroup.bindings
struct CullingGroupEvent
{
    int index;
    UInt8 prevState;
    UInt8 thisState;

    CullingGroupEvent(int i_Index, UInt8 i_PrevState, UInt8 i_ThisState) : index(i_Index), prevState(i_PrevState), thisState(i_ThisState) {}
};

CullingGroup::CullingGroup() : m_ScriptingWrapperGCHandle(), m_ManagedBoundingSphereArrayHandle()
{
    Init();
}

void CullingGroup::Init()
{
    m_BoundingSpheres = NULL;
    m_BoundingSphereCount = 0;
    m_BoundingSphereReservedSize = 0;
    m_GroupIndex = -1;

    m_ShouldSendEvents = false;

    CullingGroupManager::Get().AddCullingGroup(this);
}

CullingGroup::~CullingGroup()
{
    SetEnabled(false);

    m_ManagedBoundingSphereArrayHandle.ReleaseAndClear();
    m_ScriptingWrapperGCHandle.ReleaseAndClear();
}

void CullingGroup::SetScriptingObject(ScriptingObjectPtr object)
{
    m_ScriptingWrapperGCHandle.AcquireStrong(object);
}

void CullingGroup::SendEvents(const CullingGroupEvent* events, size_t count)
{
    ScriptingInvocation invoke(GetCoreScriptingClasses().sendEvents);
    invoke.AddObject(m_ScriptingWrapperGCHandle.Resolve());
    invoke.AddIntPtr(const_cast<CullingGroupEvent*>(events));
    invoke.AddInt(count);
    invoke.Invoke();
}

void CullingGroup::NotifyVisible()
{
    size_t nodeCount = m_BoundingSphereCount;

    dynamic_array<CullingGroupEvent> events(kMemTempAlloc);
    events.reserve(nodeCount);
    for (size_t i = 0; i < nodeCount; i++)
    {
        if ((m_ThisFrameState[i] != m_PrevFrameState[i]) && (m_ThisFrameState[i] & kIsVisible))
        {
            //@TODO: push_back_assume_capacity
            events.push_back() = CullingGroupEvent(i, m_PrevFrameState[i], m_ThisFrameState[i]);
            m_PrevFrameState[i] = m_ThisFrameState[i];
        }
    }

    SendEvents(events.begin(), events.size());
}

void CullingGroup::NotifyInvisible()
{
    size_t nodeCount = m_BoundingSphereCount;
    dynamic_array<CullingGroupEvent> events(kMemTempAlloc);
    events.reserve(nodeCount);

    for (size_t i = 0; i < nodeCount; i++)
    {
        if (m_ThisFrameState[i] != m_PrevFrameState[i])
        {
            //@TODO: push_back_assume_capacity
            events.push_back() = CullingGroupEvent(i, m_PrevFrameState[i], m_ThisFrameState[i]);
            m_PrevFrameState[i] = m_ThisFrameState[i];
        }
    }

    SendEvents(events.begin(), events.size());
}

void CullingGroup::EraseSwapBack(unsigned index)
{
    if (index < m_BoundingSphereCount)
    {
        m_BoundingSphereCount--;
        m_ThisFrameState[index] = m_ThisFrameState[m_BoundingSphereCount];
        m_PrevFrameState[index] = m_PrevFrameState[m_BoundingSphereCount];
        m_BoundingSpheres[index] = m_BoundingSpheres[m_BoundingSphereCount];
    }
    else
    {
        ErrorString("CullingGroup index is out of bounds");
    }
}

void CullingGroup::SetEnabled(bool enabled)
{
    bool isOldEnabled = m_GroupIndex != -1;
    if (isOldEnabled == enabled)
        return;

    if (enabled)
        CullingGroupManager::Get().AddCullingGroup(this);
    else
        CullingGroupManager::Get().RemoveCullingGroup(this);
}

void CullingGroup::SetBoundingSpheres(ScriptingArrayPtr array)
{
    Vector4f* newPtr = (array != SCRIPTING_NULL) ? GetScriptingArrayStart<Vector4f>(array) : NULL;
    if (newPtr != m_BoundingSpheres)
    {
        m_BoundingSpheres = newPtr;
        m_ManagedBoundingSphereArrayHandle.ReleaseAndClear();
        if (array != SCRIPTING_NULL)
            m_ManagedBoundingSphereArrayHandle.AcquireStrong((ScriptingObjectPtr)array);
    }

    UInt32 size = GetScriptingArraySize(array);
    m_BoundingSphereReservedSize = size;

    SetBoundingSphereCount(size);
}

void CullingGroup::SetBoundingSphereCount(UInt32 count)
{
    if (count > m_BoundingSphereReservedSize)
    {
        WarningString("Bounding sphere count must be less or equal to the bounding sphere array.");
        return;
    }

    // Round m_ThisFrameState/m_PrevFrameState sizes up to a multiple of 4 so we can deal with them
    // 4 elements at a time without worrying about overrun
    //m_ThisFrameState.resize_initialized(Align4(count), 0);
    //m_PrevFrameState.resize_initialized(Align4(count), 0);
    m_ThisFrameState.resize_initialized(count, 0);
    m_PrevFrameState.resize_initialized(count, 0);

    m_BoundingSphereCount = count;
}

size_t CullingGroup::QueryIndices(bool searchForVisible, int distance, QueryOptions options, UInt32* buffer, UInt32 firstIndex, size_t bufferSize) const
{
    size_t count = 0;
    size_t end = (buffer != NULL) ? std::min<size_t>(m_BoundingSphereCount, firstIndex + bufferSize) : m_BoundingSphereCount;

    for (size_t i = firstIndex; i < end; ++i)
    {
        UInt8 state = m_ThisFrameState[i];

        if (!(options & kIgnoreVisibility) && (bool)(state & kIsVisible) != searchForVisible)
            continue;

        if (!(options & kIgnoreDistance) && (state & kDistanceIndexMask) != distance)
            continue;

        if (buffer != NULL)
            buffer[count] = i;

        ++count;
    }

    return count;
}

void CullingGroup::SetDistanceReferencePoint(const math::float3& point)
{
    m_DistanceReferencePoint = point;
    m_DistanceReferenceTransform = PPtr<Transform>();
}

void CullingGroup::SetDistanceReferenceTransform(const Transform* transform)
{
    m_DistanceReferenceTransform = PPtr<Transform>(transform);
}

math::float3 CullingGroup::GetEffectiveDistanceReferencePoint() const
{
    if (m_DistanceReferenceTransform.IsValid())
    {
        Vector3f p = m_DistanceReferenceTransform->GetPosition();
        return math::vload3f(p.GetPtr());
    }
    return m_DistanceReferencePoint;
}

bool CullingGroup::IsVisible(UInt32 index) const
{
    // Use m_PrevFrameState so that we get a visibility bit which got updated across all cameras, not just the most recent one
    return (m_PrevFrameState[index] & kIsVisible) != 0;
}

int CullingGroup::GetDistance(UInt32 index) const
{
    return m_ThisFrameState[index] & kDistanceIndexMask;
}

void CullingGroup::SetBoundingDistances(const float* distances, size_t count)
{
    if (distances == NULL)
        count = 0;

    if (count > kDistanceIndexMask)
    {
        ErrorStringMsg("CullingGroup only supports a maximum of %i bounding distances.", (int)Log2(kDistanceIndexMask + 1));
        return;
    }

    for (size_t i = 1; i < count; ++i)
    {
        if (distances[i] < distances[i - 1])
        {
            ErrorString("CullingGroup bounding distances must be sorted in ascending order.");
            return;
        }
    }

    m_Distances.resize_uninitialized(count);
    for (size_t i = 0; i < count; ++i)
        m_Distances[i] = math::float4(distances[i] * distances[i]);

    m_LastDistanceIsInfinity = (count > 0) && (distances[count - 1] >= std::numeric_limits<float>::infinity());
}

CullingGroup::CullingUpdateType CullingGroup::GetUpdateType() const
{
    if (m_Distances.empty())
        return kUpdateVisibility;

    return kUpdateVisibilityAndDistance;
}
