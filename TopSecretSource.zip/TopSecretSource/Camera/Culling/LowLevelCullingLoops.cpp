#include "UnityPrefix.h"
#include "LowLevelCullingLoops.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Camera/CameraUtil.h"
#include "Runtime/Geometry/Intersection.h"
#include "../ShadowCulling.h"
#include "Runtime/Interfaces/IUmbra.h"
#include "Runtime/Utilities/Align.h"

PROFILER_INFORMATION(gCullShadowCastersDetailPoint          , "Shadows.CullShadowCastersDetailPoint", kProfilerRender)
PROFILER_INFORMATION(gCullShadowCastersDetailSpot           , "Shadows.CullShadowCastersDetailSpot", kProfilerRender)

PROFILER_INFORMATION(gCullDynamicObjectsWithUmbra           , "CullDynamicObjectsWithUmbra", kProfilerRender);
PROFILER_INFORMATION(gCullObjectsWithoutUmbra               , "CullObjectsWithoutUmbra", kProfilerRender);

static bool IsLayerDistanceCulled(UInt32 layer, const AABB& aabb, const SceneCullingParameters& params);
static bool IsNodeVisibleSlow(const SceneNode& node, const AABB& aabb, const SceneCullingParameters& params);


#define USE_SIMD_CULLING 1

// Shadow culling related loops and functions

void CullShadowCastersWithoutUmbra(IndexList& visibleObjects, const CullingParameters& cullingParams, const AABB* aabbs, size_t beginIndex, size_t endIndex)
{
    math::float4 optCullingPlanes[CullingParameters::kOptimizedCullingPlaneCount];
    PrepareOptimizedPlanes(cullingParams.cullingPlanes, cullingParams.cullingPlaneCount, optCullingPlanes, CullingParameters::kOptimizedCullingPlaneCount);

    int visibleIndex = 0;
    for (size_t i = beginIndex; i < endIndex; i++)
    {
        const AABB bounds = aabbs[i];
        #if USE_SIMD_CULLING
        if (IntersectAABBPlaneBoundsOptimized(bounds, optCullingPlanes, cullingParams.cullingPlaneCount))
        #else
        if (IntersectAABBPlaneBounds(bounds, cullingParams.cullingPlanes, cullingParams.cullingPlaneCount))
        #endif
            visibleObjects[visibleIndex++] = i;
    }

    visibleObjects.size = visibleIndex;
}

static bool CullCastersCommon(const ShadowCullContext& context, const SceneNode& node, const AABB& aabb)
{
    if (node.shadowCastingMode == kShadowCastingOff)
        return false;

    const BaseRenderer* renderer = node.renderer;
    if (context.excludeLightmapped && IsLightmappedForShadows(renderer->GetLightmapIndices()))
        return false;

    const int nodeLayer = node.layer;
    const int nodeLayerMask = 1 << nodeLayer;
    if (!(nodeLayerMask & context.cullLayers))
        return false;

    // For casters that use per-layer culling distance: check if they are behind cull distance.
    // If they are, don't cast shadows.
    const ShadowCullData& cullData = *context.camera;
    float layerCullDist = cullData.layerCullDistances[nodeLayer];
    if (layerCullDist)
    {
        if (cullData.layerCullSpherical)
        {
            float sqDist = SqrMagnitude(aabb.GetCenter() - cullData.eyePos);
            if (sqDist > Sqr(layerCullDist))
                return false;
        }
        else
        {
            Plane farPlane = cullData.shadowCullPlanes[kPlaneFrustumFar];
            farPlane.distance = layerCullDist + cullData.baseFarDistance;
            if (!IntersectAABBPlaneBounds(aabb, &farPlane, 1))
                return false;
        }
    }

    return true;
}

//
// Directional light shadow caster culling
static bool CullCastersDirectional(DirectionalCullContext* context, const SceneNode& node, const AABB& aabb)
{
    return CullCastersCommon(*context, node, aabb);
}

void CullDirectionalShadows(IndexList& visible, const SceneNode* nodes, const AABB* boundingBoxes, DirectionalCullContext &context)
{
    // Generate Visible nodes from all static & dynamic objects
    int visibleCount = 0;
    for (int i = 0; i < visible.size; i++)
    {
        const SceneNode& node = nodes[visible.indices[i]];
        const AABB& bounds = boundingBoxes[visible.indices[i]];

        if (CullCastersDirectional(&context, node, bounds))
            visible.indices[visibleCount++] = visible.indices[i];
    }
    visible.size = visibleCount;
}

//
// Point light shadow caster culling

static bool CullCastersPoint(PointCullContext* context, const SceneNode& node, const AABB& aabb)
{
    if (!CullCastersCommon(*context, node, aabb))
        return false;

    if (!IntersectAABBSphere(aabb, context->lightSphere))
        return false;

    return true;
}

void CullPointShadows(IndexList& visible, const SceneNode* nodes, const AABB* boundingBoxes, PointCullContext &context)
{
    PROFILER_AUTO(gCullShadowCastersDetailPoint, NULL);

    // Generate Visible nodes from all static & dynamic objects
    int visibleCount = 0;
    for (int i = 0; i < visible.size; i++)
    {
        const SceneNode& node = nodes[visible.indices[i]];
        const AABB& bounds = boundingBoxes[visible.indices[i]];

        if (CullCastersPoint(&context, node, bounds))
            visible.indices[visibleCount++] = visible.indices[i];
    }
    visible.size = visibleCount;
}

//
// Spot light shadow caster culling

static bool CullCastersSpot(SpotCullContext* context, const SceneNode& node, const AABB& aabb)
{
    if (!CullCastersCommon(*context, node, aabb))
        return false;

    // World space light frustum vs. global AABB
    if (!IntersectAABBFrustumFull(aabb, context->spotLightFrustum))
        return false;

    // Here we assume that before culling starts all renderer nodes have been fully updated.

    // TODO: FIX RACE CONDITION!
    // Shadow caster culling can happen in parallel OnWillRenderObject moving some transforms.
    // In this case GetTransformInfoExpectUpToDate might fire asserts because the transform
    // is being mutated in parallel to the ShadowCaster culling happening on jobs.
    // In the worst rare case this will lead to one frame delay in culling.
    //
    // Fixing it implies a culling performance regression by waiting on all culling jobs before calling scripts.
    // Doing that requires having a fastpath that sends no events at least, we want to enable this in SRP.
    // GraphicsFoundation team owns coming up with a full solution for this...
    // See fogbugs case 899009
    const TransformInfo& xformInfo = node.renderer->GetTransformInfoDoNotExpectUpToDate();

    Plane planes[6];
    // NOTE: it's important to multiply world->light and node->world matrices
    // before multiplying in the projection matrix. Otherwise when object/light
    // coordinates will approach 10 thousands range, we'll get culling errors
    // because of imprecision.
    //Matrix4x4f proj = context->projectionMatrix * (context->worldToLightMatrix * node->worldMatrix);
    Matrix4x4f temp, proj;
    MultiplyMatrices4x4(&context->worldToLightMatrix, &xformInfo.worldMatrix, &temp);
    MultiplyMatrices4x4(&context->projectionMatrix, &temp, &proj);
    ExtractProjectionPlanes(proj, planes);

    if (!IntersectAABBFrustumFull(xformInfo.localAABB, planes))
        return false;

    return true;
}

void CullSpotShadows(IndexList& visible, const SceneNode* nodes, const AABB* boundingBoxes, SpotCullContext &context)
{
    PROFILER_AUTO(gCullShadowCastersDetailSpot, NULL);

    // Generate Visible nodes from all static & dynamic objects
    int visibleCount = 0;
    for (int i = 0; i < visible.size; i++)
    {
        const SceneNode& node = nodes[visible.indices[i]];
        const AABB& bounds = boundingBoxes[visible.indices[i]];

        if (CullCastersSpot(&context, node, bounds))
            visible.indices[visibleCount++] = visible.indices[i];
    }
    visible.size = visibleCount;
}

// Scene culling related loops

void CullObjectsWithoutUmbra(const CullingParameters& cullingParams, const AABB* aabbs, IndexList& list)
{
    PROFILER_AUTO(gCullObjectsWithoutUmbra, NULL);

    int size = list.size;
    int visibleIndex = 0;

    math::float4 optCullingPlanes[CullingParameters::kOptimizedCullingPlaneCount];
    PrepareOptimizedPlanes(cullingParams.cullingPlanes, cullingParams.cullingPlaneCount, optCullingPlanes, CullingParameters::kOptimizedCullingPlaneCount);

    for (int i = 0; i < size; i++)
    {
        int index = list.indices[i];
        #if USE_SIMD_CULLING
        if (IntersectAABBPlaneBoundsOptimized(aabbs[index], optCullingPlanes, cullingParams.cullingPlaneCount))
        #else
        if (IntersectAABBPlaneBounds(aabbs[index], cullingParams.cullingPlanes, cullingParams.cullingPlaneCount))
        #endif
            list.indices[visibleIndex++] = index;
    }

    list.size = visibleIndex;
}

void CullDynamicObjectsUmbra(const AABB* aabbs, const Umbra::OcclusionBuffer* occlusionBuffer, IndexList& list)
{
    PROFILER_AUTO(gCullDynamicObjectsWithUmbra, NULL);

    GetIUmbra()->CullDynamicObjectsUmbra(aabbs, occlusionBuffer, list);
}

void CullBoundingSpheresWithoutUmbra(const CullingParameters& cullingParams, const Vector4f* boundingSpheres, size_t beginIndex, size_t endIndex, UInt8* output, UInt8 visibleFlag, bool clearFlagIfInvisible)
{
    math::float4 optCullingPlanes[CullingParameters::kOptimizedCullingPlaneCount];
    PrepareOptimizedPlanes(cullingParams.cullingPlanes, cullingParams.cullingPlaneCount, optCullingPlanes, CullingParameters::kOptimizedCullingPlaneCount);

    UInt8 invisibleFlag = clearFlagIfInvisible ? (~visibleFlag) : 0xFF;

    for (size_t i = beginIndex; i < endIndex; ++i)
    {
        math::float4 sphere = math::vload4f(boundingSpheres[i].GetPtr());

        if (IntersectSpherePlaneBoundsOptimized(sphere, optCullingPlanes, cullingParams.cullingPlaneCount))
            output[i] |= visibleFlag;
        else
            output[i] &= invisibleFlag;
    }
}

// Reduce the index list using Scene::IsNodeVisibleFast, IsNodeVisibleSlow or IsNodeVisible (full)
// Takes the index list as input and output, after the function the indices that are not visible will have been removed.

// Step1 is responsible for setting-up the list using fast culling (eg. load mask & culling mask)
void ProcessCameraIndexListIsNodeVisibleStep1(const SceneCullingParameters& params, const SceneNode* nodes, size_t beginIndex, size_t endIndex, IndexList& list)
{
    // Check layers and cull distances
    int visibleCountNodes = 0;
    for (size_t i = beginIndex; i < endIndex; ++i)
    {
        const SceneNode& node = nodes[i];
        if (IsNodeVisibleFast(node, params) && node.shadowCastingMode != kShadowCastingShadowsOnly)
            list.indices[visibleCountNodes++] = i;
    }

    list.size = visibleCountNodes;
}

// Step2 is responsible for further reduding the visible lists based on expensive queries
// For example layer based distance culling.
void ProcessIndexListIsNodeVisibleStep2(const SceneCullingParameters& params, const SceneNode* nodes, const AABB* bounds, IndexList& list)
{
    int size = list.size;
    // Check layers and cull distances
    int visibleCountNodes = 0;
    for (int i = 0; i < size; ++i)
    {
        int index = list.indices[i];
        const SceneNode& node = nodes[index];
        const AABB& aabb = bounds[index];
        if (IsNodeVisibleSlow(node, aabb, params))
            list.indices[visibleCountNodes++] = index;
    }

    list.size = visibleCountNodes;
}

// Combines IsNodeVisibleSlow & IsNodeVisibleFast in one step.
// Uses IndexList list as an input and output, basically reducing list.
void ProcessCameraIndexListIsNodeVisibleInOut(const SceneCullingParameters& params, const SceneNode* nodes, const AABB* bounds, IndexList& list)
{
    int size = list.size;
    // Check layers and cull distances
    int visibleCountNodes = 0;
    for (int i = 0; i < size; ++i)
    {
        int index = list.indices[i];
        const SceneNode& node = nodes[index];
        const AABB& aabb = bounds[index];
        if (IsNodeVisible(node, aabb, params) && node.shadowCastingMode != kShadowCastingShadowsOnly)
            list.indices[visibleCountNodes++] = index;
    }

    list.size = visibleCountNodes;
}

void ProcessShadowsIndexListIsNodeVisibleInOut(const SceneCullingParameters& params, const SceneNode* nodes, const AABB* bounds, IndexList& list)
{
    int size = list.size;
    // Check layers and cull distances
    int visibleCountNodes = 0;
    for (int i = 0; i < size; ++i)
    {
        int index = list.indices[i];
        const SceneNode& node = nodes[index];
        const AABB& aabb = bounds[index];
        if (IsNodeVisible(node, aabb, params))
            list.indices[visibleCountNodes++] = index;
    }

    list.size = visibleCountNodes;
}

bool IsNodeVisibleFast(const SceneNode& node, const SceneCullingParameters& params)
{
    UInt32 layermask = 1 << node.layer;
    if ((layermask & params.cullingMask) == 0)
        return false;

    // Static renderers are not deleted from the renderer objects list.
    // This is because we ensure that static objects come first and the pvxIndex in umbra matches the index in m_RendererNodes array.
    // However the layerMask is set to 0 thus it should be culled at this point
    if (node.renderer == NULL)
        return false;

    // Check if node was deleted but not removed from list yet.
    if (node.disable)
        return false;

    if (node.lodGroupIndex != 0)
    {
        UInt16 lodManager = node.lodManagerID;
        DebugAssert(node.lodGroupIndex < params.lodDataArrays[lodManager].count);
        if ((params.lodDataArrays[lodManager].masks[node.lodGroupIndex] & node.lodIndexMask) == 0)
            return false;
    }

    return true;
}

static bool IsNodeVisibleSlow(const SceneNode& node, const AABB& aabb, const SceneCullingParameters& params)
{
    return !IsLayerDistanceCulled(node.layer, aabb, params);
}

bool IsNodeVisible(const SceneNode& node, const AABB& aabb, const SceneCullingParameters& params)
{
    return IsNodeVisibleFast(node, params) && IsNodeVisibleSlow(node, aabb, params);
}

static bool IsLayerDistanceCulled(UInt32 layer, const AABB& aabb, const SceneCullingParameters& params)
{
    switch (params.layerCull)
    {
        case CullingParameters::kLayerCullPlanar:
        {
            Assert(params.cullingPlaneCount == kPlaneFrustumNum);
            Plane farPlane = params.cullingPlanes[kPlaneFrustumFar];
            farPlane.distance = params.layerFarCullDistances[layer];
            return !IntersectAABBPlaneBounds(aabb, &farPlane, 1);
        }
        case CullingParameters::kLayerCullSpherical:
        {
            float cullDist = params.layerFarCullDistances[layer];
            if (cullDist == 0.0f)
                return false;
            return (SqrMagnitude(aabb.GetCenter() - params.position) > Sqr(cullDist));
        }
        default:
            return false;
    }
}

MinMaxAABB CombineBoundingVolumes(const AABB* bounds, const IndexList& indexList)
{
    MinMaxAABB combined;
    for (size_t i = 0; i != indexList.size; i++)
        combined.Encapsulate(bounds[indexList[i]]);
    return combined;
}
