#pragma once

#include "Runtime/Interfaces/IUmbra.h"
#include "../CullResults.h"
#include "Runtime/Geometry/Sphere.h"

struct ShadowCullContext
{
    const ShadowCullData* camera;
    bool excludeLightmapped;
    UInt32 cullLayers;
};

struct DirectionalCullContext : public ShadowCullContext
{
};

struct PointCullContext : public ShadowCullContext
{
    Sphere lightSphere;
};

struct SpotCullContext : public ShadowCullContext
{
    Matrix4x4f worldToLightMatrix, projectionMatrix;
    Plane spotLightFrustum[6];
};

void CullShadowCastersWithoutUmbra(IndexList& visibleObjects, const CullingParameters& cullingParams, const AABB* aabbs, size_t beginIndex, size_t endIndex);
void CullDirectionalShadows(IndexList& visible, const SceneNode* nodes, const AABB* boundingBoxes, DirectionalCullContext &context);
void CullPointShadows(IndexList& visible, const SceneNode* nodes, const AABB* boundingBoxes, PointCullContext &context);
void CullSpotShadows(IndexList& visible, const SceneNode* nodes, const AABB* boundingBoxes, SpotCullContext &context);

void CullObjectsWithoutUmbra(const CullingParameters& cullingParams, const AABB* aabbs, IndexList& list);
void CullDynamicObjectsUmbra(const AABB* aabbs, const Umbra::OcclusionBuffer* occlusionBuffer, IndexList& list);

void CullBoundingSpheresWithoutUmbra(const CullingParameters& cullingParams, const Vector4f* boundingSpheres, size_t beginIndex, size_t endIndex, UInt8* output, UInt8 visibleFlag, bool clearFlagIfInvisible);

void ProcessCameraIndexListIsNodeVisibleStep1(const SceneCullingParameters& params, const SceneNode* nodes, size_t beginIndex, size_t endIndex, IndexList& list);
void ProcessIndexListIsNodeVisibleStep2(const SceneCullingParameters& params, const SceneNode* nodes, const AABB* bounds, IndexList& list);
void ProcessCameraIndexListIsNodeVisibleInOut(const SceneCullingParameters& params, const SceneNode* nodes, const AABB* bounds, IndexList& list);
void ProcessShadowsIndexListIsNodeVisibleInOut(const SceneCullingParameters& params, const SceneNode* nodes, const AABB* bounds, IndexList& list);

bool IsNodeVisibleFast(const SceneNode& node, const SceneCullingParameters& params);
bool IsNodeVisible(const SceneNode& node, const AABB& aabb, const SceneCullingParameters& params);

MinMaxAABB CombineBoundingVolumes(const AABB* bounds, const IndexList& indexList);
