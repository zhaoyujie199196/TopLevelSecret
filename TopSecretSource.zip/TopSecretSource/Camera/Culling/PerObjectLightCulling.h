#pragma once

#include "Runtime/Camera/CullResults.h"
#include "Runtime/Jobs/Jobs.h"
#include "External/boost/dynamic_bitset.h"

struct ShadowJobData;

struct PerObjectLightCullingOutput
{
    JobFence                fence;
    ObjectCulledLights      forwardCulledLights;
    ObjectLightIndices      forwardLightOffsets;

    PerObjectLightCullingOutput(MemLabelRef label) : forwardCulledLights(label), forwardLightOffsets(label) {}
};

void CullAllPerObjectLights(int renderPath, const RenderNodeQueue& queue, const ActiveLights& lights, PerObjectLightCullingOutput& output);


struct  ObjectLightDetails
{
    CulledLight*    lights;
    UInt32          count;
    bool            hasOffscreenLights;
};

inline void ClearObjectLightDetails(ObjectLightDetails& details)
{
    details.lights = NULL;
    details.count = 0;
    details.hasOffscreenLights = false;
}

enum { kHasOffscreenLightMask = 1 << 31, kOffsetMask = ~kHasOffscreenLightMask };

inline void GetObjectLightDetails(const PerObjectLightCullingOutput& perLightCullingData, UInt32 visibleNodeIndex, ObjectLightDetails& details)
{
    // Before calling GetObjectLightDetails you need to sync the fence. (outside of innerloops...)
    DebugAssert(IsFenceDone(perLightCullingData.fence));

    if (perLightCullingData.forwardLightOffsets.size() == 0)
    {
        details.lights = NULL;
        details.count = 0;
        details.hasOffscreenLights = false;
        return;
    }

    DebugAssert(visibleNodeIndex < (perLightCullingData.forwardLightOffsets.size() - 1));
    // We store an extra offset at the end of forwardLightOffsets
    // This means it's always safe to check next offset to get the size
    UInt32 lightOffsetAndOffscreenBit = perLightCullingData.forwardLightOffsets[visibleNodeIndex];
    UInt32 lightOffset = lightOffsetAndOffscreenBit & kOffsetMask;

    UInt32 nextLightOffset = perLightCullingData.forwardLightOffsets[visibleNodeIndex + 1] & kOffsetMask;
    DebugAssert(nextLightOffset >= lightOffset);
    DebugAssert(nextLightOffset <= perLightCullingData.forwardCulledLights.size());

    details.count = (nextLightOffset - lightOffset);
    details.lights = (CulledLight*)perLightCullingData.forwardCulledLights.data() + lightOffset;
    details.hasOffscreenLights = lightOffsetAndOffscreenBit & kHasOffscreenLightMask;
}

inline UInt32 GetPerObjectLightIndicesCount(const PerObjectLightCullingOutput& cullingOutput)
{
    JobFence fence = cullingOutput.fence;
    SyncFence(fence);

    return cullingOutput.forwardCulledLights.size();
}

inline void GetLightOffsetAndCount(const PerObjectLightCullingOutput& cullingOutput, int idx, UInt32& offset, UInt32& count)
{
    DebugAssertMsg(IsFenceDone(cullingOutput.fence), "Per object light culling jobs haven't completed, yet.");

    offset = cullingOutput.forwardLightOffsets[idx] & kOffsetMask;
    count = (cullingOutput.forwardLightOffsets[idx + 1] & kOffsetMask) - offset;
}

inline void GetLightOffsets(const PerObjectLightCullingOutput& cullingOutput, UInt32* pIndices, int indicesSize)
{
    DebugAssertMsg(IsFenceDone(cullingOutput.fence), "Per object light culling jobs haven't completed, yet.");
    DebugAssertMsg(cullingOutput.forwardCulledLights.size() <= indicesSize, "The passed in array is not large enough to hold the required light indices.");

    for (int i = 0, max = cullingOutput.forwardCulledLights.size(); i < max; i++)
    {
        *pIndices = cullingOutput.forwardCulledLights[i].lightIndex;
        pIndices++;
    }
}

inline bool SameOffsets(const PerObjectLightCullingOutput& cullingOutput, UInt32 parentOffset, UInt32 parentCount, UInt32 subrangeIndex, UInt32& subrangeOffset, UInt32& subrangeCount)
{
    UInt32 offset, count;
    GetLightOffsetAndCount(cullingOutput, subrangeIndex, offset, count);
    subrangeOffset = offset;
    subrangeCount = count;

    if (count != parentCount)
        return false;

    const ObjectCulledLights& indices = cullingOutput.forwardCulledLights;
    for (UInt32 end = offset + count; offset < end; parentOffset++, offset++)
    {
        if (indices[parentOffset].lightIndex != indices[offset].lightIndex)
            return false;
    }
    return true;
}

bool IsObjectWithinShadowRange(const ShadowJobData& shadowCullData, const AABB& bounds);
