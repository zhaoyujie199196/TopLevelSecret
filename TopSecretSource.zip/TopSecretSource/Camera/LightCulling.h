#pragma once

#include "CullResults.h"
#include "Light.h"
#include "Runtime/Jobs/BlockRangeJob.h"

struct ShadowJobData;

struct LocalLightCullJobOutputData
{
    IndexList*                      visibleLights;
    IndexList*                      offScreenLights;
    float*                          visibilityFades;
    Rectf*                          lightScreenRects;
    TargetEyeMask*                  lightVisibilityMasks;
};

struct LocalLightCullJobData
{
    const SceneCullingParameters*       cullingParams;
    const Vector4f*                     lightBSpheres;
    size_t                              lightBSpheresCount;
    const UInt8*                        isShadowCastingLocalLight;
    const Light**                       localLights;
    const ShadowCullData*               shadowCullData;
    LocalLightCullJobOutputData         output;

    // BlockRange is written to during jobs and consumed by the combine job
    BlockRange                          blockRanges[kMaximumBlockRangeCount];
    int                                 outputVisibleOffscreenLights[kMaximumBlockRangeCount];
    size_t                              blockRangeCount;
};

struct LocalLightCullingParameters
{
    Plane    eyePlane;
    float    farDistance;
    bool     enableShadows;
    UInt32   cullingMask;
};

void InitLocalLightCullingParameters(const CullResults& results, LocalLightCullingParameters& params);

// Cull all local lights. Performs frustum culling and occlusion cullings. Waits for waitForOcclusionBuffer to complete before the job runs.
// fence can be used to ensure that local light culling has completed.
void CullLocalLights(
    // Inputs
    JobFence& fence, JobFence& waitForOcclusionBuffer, const SceneCullingParameters& cullingParameters, int numLocalLights, const Vector4f* localLightBSpheres, const dynamic_array<UInt8>& isShadowCastingLocalLight,
    // Outputs
    IndexList& visibleLocalLightIndices, IndexList& offScreenLocalLightIndices, float* offScreenLocalLightvisibilityFades, Rectf* lightScreenRects, TargetEyeMask* lightVisibilityMasks, const Light** localLights, const ShadowCullData& shadowCullData);

// Figures out all lights that are visible in the scene
bool IsValidRealtimeLight(const SharedLightData& light, LightType lightType, UInt32 cullingMask);
void FindActiveLights(dynamic_array<const Light*>& directionalLights, const Light** localLights, Vector4f* localLightBSpheres, dynamic_array<UInt8>& isShadowCastingLocalLight, const ShadowCullData& cullData, unsigned int& localLightCount);
void AddDirectionalLights(const Light** lights, size_t count, ActiveLights& outLights);
void AddActiveCustomLights(const LocalLightCullingParameters& params, CullResults& results, ActiveLights& outCustomLights);
void AddActiveLocalLights(CullResults& results, LocalLightCullingParameters& localLightCullParameters, const Light** localLights, const Vector4f* localLightBSpheres, const IndexList& visibleLocalLightIndices,
    float* offScreenLocalLightvisibilityFades, IndexList& offScreenLocalLightIndices, ActiveLights& outLights, ActiveLights& customLights, Rectf* lightScreenRects, TargetEyeMask* lightVisibilityMasks);
void SetupActiveLocalLight(const LocalLightCullingParameters& params, const ShadowJobData& shadowCullData, const Vector4f& lightBSphere, const Rectf* lightScreenRects, bool stereo, bool isVisible, float visibilityFade, ActiveLight& outLight);
void CalculateLightScreenBounds(const ShadowJobData& cullData, const SharedLightData& light, Rectf* outScreenRects, TargetEyeMask& outVisibilityMask);

// Figures out single main light in the scene
Light* FindBrightestDirectionalLight(bool checkValid = true);
