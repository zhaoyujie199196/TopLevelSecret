#ifndef CULLING_PARAMETERS_H
#define CULLING_PARAMETERS_H

#include "Runtime/Geometry/Plane.h"
#include "Runtime/BaseClasses/TagManager.h"
#include "Runtime/Math/Matrix4x4.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Utilities/Align.h"
#include "Runtime/Utilities/EnumFlags.h"
#include "Runtime/Math/Simd/vec-types.h"

struct SceneNode;
class AABB;

namespace Umbra
{ class DebugRenderer; class Visibility; class Tome; class QueryExt; }

enum CullingType   { kNoOcclusionCulling = 0,  kOcclusionCulling = 1,         kShadowCasterOcclusionCulling = 2 };
enum CullFiltering { kFilterModeOff = 0,       kFilterModeShowFiltered = 1,   kFilterModeShowRest = 2 };
enum CameraType    { kCameraTypeGame = 1 << 0, kCameraTypeSceneView = 1 << 1, kCameraTypePreview = 1 << 2, kCameraTypeVR = 1 << 3 };

ENUM_FLAGS(CameraType)

enum { kMinCulledRendersPerJob = 256 };
enum { kMinCulledShadowCastersPerJob = 4096 };

struct IndexList
{
    int* indices;
    int  size;
    int  reservedSize;

    int& operator[](int index)
    {
        DebugAssert(index < reservedSize);
        return indices[index];
    }

    int operator[](int index) const
    {
        DebugAssert(index < reservedSize);
        return indices[index];
    }

    IndexList()
    {
        indices = NULL;
        reservedSize = size = 0;
    }

    IndexList(int* i, int sz, int rs)
    {
        indices = i;
        size = sz;
        reservedSize = rs;
    }

    void operator=(const IndexList& in)
    {
        indices = in.indices;
        size = in.size;
        reservedSize = in.reservedSize;
    }
};

enum
{
    kStaticRenderers = 0,
    kDynamicRenderer,
    kSceneIntermediate,
    kCameraIntermediate,
#if ENABLE_TERRAIN
    kTreeRenderer,
#endif
    kVisibleListCount
};

// Output for all culling operations.
// simple index list indexing into the different places where renderers can be found.
struct CullingOutput
{
    IndexList          visible[kVisibleListCount];

    bool                useUmbraOcclusionCulling;
    Umbra::Visibility*  umbraVisibility;

    CullingOutput() : useUmbraOcclusionCulling(false), umbraVisibility(NULL) {}
};

struct RendererCullData
{
    const AABB*      bounds;
    const SceneNode* nodes;
    size_t           rendererCount;

    RendererCullData() { bounds = NULL; nodes = NULL; rendererCount = 0; }
};

struct LODParameters
{
    bool        isOrthographic;
    Vector3f    cameraPosition;
    float       fieldOfView;
    float       orthoSize;
    int         cameraPixelHeight;
};

//NOTE: this must be kept in sync with
//      Managed CullingParameters / ScriptableCullingParameters
struct CullingParameters
{
    CullingParameters() {}
    enum { kMaxPlanes = 10 };
    enum { kOptimizedCullingPlaneCount = 12 };

    enum LayerCull
    {
        kLayerCullNone,
        kLayerCullPlanar,
        kLayerCullSpherical
    };

    int             isOrthographic; // bool for compatibility with script bindings
    LODParameters   lodParams;
    Plane           cullingPlanes[kMaxPlanes]; // Note: do not write to cullingPlanes directly. Use SetCullingPlanes
    int             cullingPlaneCount;
    UInt32          cullingMask;

    // Note: not supported in scriptable renderloops
    float           layerFarCullDistances[kNumLayers];
    LayerCull       layerCull;

    // Used for Umbra
    Matrix4x4f cullingMatrix;
    Vector3f  position;
};

struct LODDataArray
{
    UInt8* masks;
    float* fades;
    size_t count;
};

typedef void PostProcessCullResults (const SceneNode* nodes, const AABB* bounds, IndexList& list, void* userData);

struct SceneCullingParameters : CullingParameters
{
    SceneCullingParameters()
        : postProcessCullResults(NULL)
        , postProcessCullResultsUserData(NULL)
        , stereoSeparation(0.0f)
        , computeShadowCasterBounds(false)
    {}

    RendererCullData renderers[kVisibleListCount];

    LODDataArray*   lodDataArrays;

    bool            excludeLightmappedShadowCasters;
    bool            cullLights;
    bool            stereo;
    bool            computeShadowCasterBounds;

    int             renderPath;
    CullFiltering   filterMode;

    // used for stereo
    float           stereoSeparation;
    Matrix4x4f      stereoCombinedProj;
    Matrix4x4f      stereoCombinedView;

    /// This stores the visibility of previous culling operations.
    /// For example, shadow caster culling uses the visibility of the visible objects from the camera.
    const CullingOutput*    sceneVisbilityForShadowCulling;

    const Umbra::Tome*      umbraTome;
    const void*             umbraGateState;
    Umbra::DebugRenderer*   umbraDebugRenderer;
    UInt32                  umbraDebugFlags;

    PostProcessCullResults* postProcessCullResults;
    void*                   postProcessCullResultsUserData;
};


#endif
