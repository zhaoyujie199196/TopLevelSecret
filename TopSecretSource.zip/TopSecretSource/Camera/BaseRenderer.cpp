#include "UnityPrefix.h"
#include "BaseRenderer.h"
#include "Runtime/Camera/Camera.h"
#include "Runtime/Camera/CullResults.h"
#include "Runtime/Camera/LightProbeProxyVolume.h"
#include "Runtime/Camera/ReflectionProbes.h"
#include "Runtime/Camera/RenderSettings.h"
#include "Runtime/Camera/RenderLoops/LightProbeContext.h"
#include "Runtime/Camera/RendererProbeUtils.h"
#include "Runtime/Camera/ShadowCulling.h"
#include "Runtime/Core/Callbacks/GlobalCallbacks.h"
#include "Runtime/Graphics/LightmapSettings.h"
#include "Runtime/Graphics/Renderer.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Shaders/Material.h"
#include "Runtime/Shaders/Shader.h"
#include "Runtime/Shaders/ShaderImpl/ShaderImpl.h"
#include "Runtime/Shaders/SharedMaterialData.h"
#include "Runtime/Camera/RendererProbeUtils.h"

using namespace Unity;


template bool BaseRenderer::FlattenSharedMaterialData<true>(BaseRenderer& renderer, PerThreadPageAllocator& allocator, RenderNode& node);
template bool BaseRenderer::FlattenSharedMaterialData<false>(BaseRenderer& renderer, PerThreadPageAllocator& allocator, RenderNode& node);

BaseRenderer::BaseRenderer(RendererType type)
    : m_RendererData(type)
{
}

BaseRenderer::~BaseRenderer()
{
}

int BaseRenderer::GetLightmapIndexInt(LightmapType lightmapType) const
{
    return ::GetLightmapIndexInt(m_RendererData.m_LightmapIndex, lightmapType);
}

void BaseRenderer::SetLightmapIndexIntNoDirty(int index, LightmapType lightmapType)
{
    ::SetLightmapIndexInt(m_RendererData.m_LightmapIndex, lightmapType, index);
}

void BaseRenderer::SetLightmapSTNoDirty(const Vector4f& lightmapST, LightmapType lightmapType)
{
    m_RendererData.m_LightmapST[lightmapType] = lightmapST;
}

void BaseRenderer::ClearProbes(RenderNode& node)
{
    // Reset Probe Data.
    node.rendererData.m_ReflectionProbeUsage = kReflectionProbeOff;
    node.rendererData.m_LightProbeUsage = kLightProbeOff;
    node.lightProbeProxyVolHandle = LightProbeProxyVolume::InvalidHandle;
    node.reflectionProbeHandle = LightProbeProxyVolume::InvalidHandle;
}

void BaseRenderer::FlattenProbeData(BaseRenderer& renderer, const TransformInfo& transformInfo, const LightProbeContext& lightProbeContext, RenderNode& node)
{
    Transform* probeAnchor = PPtrToObjectDontLoadNoThreadCheck(renderer.m_ProbeAnchor);

    // Reflections
    FindReflectionProbeFromAnchor(probeAnchor, transformInfo.worldAABB, node.reflectionProbeAnchor, node.reflectionProbeHandle, node.reflectionProbeImportance);

    // Lightprobe volumes
    node.lightProbeProxyVolHandle = GetLightProbeProxyVolumeHandle(GetLightProbeProxyVolumeManager().GetContext(), renderer);

    // Force lightprobe usage to kLightProbeBlendProbes, if proxy volume was not available.
    LightProbeUsage lightProbeUsage = (LightProbeUsage)node.rendererData.m_LightProbeUsage;
    if (lightProbeUsage == kLightProbeUseProxyVolume && node.lightProbeProxyVolHandle == LightProbeProxyVolume::InvalidHandle)
        node.rendererData.m_LightProbeUsage = lightProbeUsage = kLightProbeBlendProbes;

    // Lightprobes
    if (lightProbeUsage == kLightProbeBlendProbes || lightProbeUsage == kLightProbeUseProxyVolume)
    {
        int& rendererProbeIndex = renderer.m_RendererData.m_LightProbeOrTetIndex;

        if (!node.rendererData.m_UseExplicitLightProbeIndex)
        {
            Vector3f position = probeAnchor != NULL ? probeAnchor->GetPosition() : transformInfo.worldAABB.m_Center;

            CalculateLightProbeSamplingCoordinates(lightProbeContext, position, rendererProbeIndex, node.lightprobeSamplingCoordinates);

            // Cache the index in the renderer to speed up next search.
            rendererProbeIndex = node.lightprobeSamplingCoordinates.tetrahedronIndex;
        }
        else
        {
            CalculateExplicitLightProbeCoordinates(rendererProbeIndex, node.lightprobeSamplingCoordinates);
        }
    }
}

void BaseRenderer::UpdatePreviousFrameData()
{
    m_RendererData.m_TransformInfo.prevWorldMatrix = m_RendererData.m_TransformInfo.worldMatrix;
}

static void ReleaseAquiredMaterials(MaterialInfo* materialsArray, size_t materialCount)
{
    for (int i = 0; i < materialCount; i++)
        materialsArray[i].sharedMaterialData->Release();
}

template<bool kExecuteFromJob>
bool BaseRenderer::FlattenSharedMaterialData(BaseRenderer& renderer, PerThreadPageAllocator& allocator, RenderNode& node)
{
    //@TODO: GetMaterialCount/GetMaterial Virtual calls...
    // Instead fix the renderer code where material is using virtuals...

    int materialCount = node.materialCount = renderer.GetMaterialCount();
    if (materialCount > 0)
    {
        MaterialInfo* materialsInfos = allocator.Allocate<MaterialInfo>(materialCount);
        node.materialInfos = materialsInfos;

        for (int i = 0; i < materialCount; i++)
        {
            Material* mat;
            PPtr<Material> matPPtr = renderer.GetMaterial(i);
            if (kExecuteFromJob)
            {
                mat = PPtrToObjectDontLoadNoThreadCheck(matPPtr);

                // The material is not yet loaded,
                // Thus we fail to FlattenSharedMaterialData completely, release already acquired materials
                if (mat == NULL && matPPtr.GetInstanceID() != InstanceID_None)
                {
                    ReleaseAquiredMaterials(materialsInfos, i);
                    return false;
                }
            }
            else
            {
                mat = matPPtr;
            }


            MaterialInfo& mi = materialsInfos[i];
            if (mat)
            {
                if (kExecuteFromJob)
                {
                    mi.sharedMaterialData = mat->AcquireSharedMaterialDataFromJob();
                    // The shared material couldn't be acquired.
                    // Thus we fail to FlattenSharedMaterialData completely, release already acquired materials
                    if (mi.sharedMaterialData == NULL)
                    {
                        ReleaseAquiredMaterials(materialsInfos, i);
                        return false;
                    }
                }
                else
                {
                    mi.sharedMaterialData = mat->AcquireSharedMaterialData();
                }

                mi.customRenderQueue = mat->GetCustomRenderQueue();
            }
            else
            {
                mi.sharedMaterialData = Material::GetDefault()->AcquireSharedMaterialData();
                mi.customRenderQueue = -1;
            }

            DebugAssert(mi.sharedMaterialData->shader != NULL);
            DebugAssert(mi.sharedMaterialData->smallMaterialIndex);
        }
    }
    else
        node.materialInfos = NULL;

    return true;
}

//@TODO: bool extractShadowCaster
void BaseRenderer::FlattenCommonData(BaseRenderer& renderer, const TransformInfo& transformInfo, float lodFade, RenderNode& node)
{
    // since we don't have a constructor anymore we need to add stuff by hand
    node.InitWithDefaultValues();

    node.rendererData = renderer.m_RendererData;
    if (node.rendererData.m_CustomProperties != NULL)
    {
        node.rendererData.m_CustomProperties->AddRef();
        node.customPropsHash = node.rendererData.m_CustomProperties->GetLastComputedHash();
        node.customPropsLayoutHash = node.rendererData.m_CustomProperties->GetLastComputedLayoutHash();
    }
    else
    {
        node.customPropsHash = 0;
        node.customPropsLayoutHash = 0;
    }

    node.baseType = RenderNode::kBaseRenderer;
    node.lodFade = lodFade;

    //@TODO: virtual (Value is also duplicated in scene node...)
    node.layer = renderer.GetLayer();

    node.rendererInstanceID = renderer.IsRenderer() ? static_cast<Renderer&>(renderer).GetInstanceID() : InstanceID_None;
    node.SetBaseRendererMainThread(&renderer);
}

UInt32 BaseRenderer::FlattenToRenderQueue(RenderNodeQueue& queue, const DeprecatedSourceData& sourceData)
{
    BaseRenderer& renderer = *const_cast<BaseRenderer*>(sourceData.renderer);
    const TransformInfo& transformInfo = renderer.GetTransformInfoExpectUpToDate();

    UInt32 nodeId = sourceData.outputIndex;
    Assert(RenderNode::kInvalid != nodeId);

    RenderNode& node = queue.GetNode(nodeId);
    FlattenCommonData(renderer, transformInfo, sourceData.lodFade, node);

    // create context every time, move to a better place.
    LightProbeContext lightProbeContext;
    lightProbeContext.Init(GetLightmapSettings(), GetRenderSettings());
    FlattenProbeData(renderer, transformInfo, lightProbeContext, node);
    FlattenSharedMaterialData<false>(renderer, *sourceData.allocator, node);

    node.rendererSpecificData = NULL;
    node.cleanupCallback = NULL;
    node.executeCallback = NULL;
    node.executeCallbackSendLastPosition = NULL;
    node.executeBatchedCallback = NULL;
    node.batchingFlags = kBatchingFlagNone;
    node.batchingKey = 0;
    return nodeId;
}

void BaseRenderer::RendererCullingCallback()
{
    // Some systems call Render without going via culling (Wireframe, Picking, RenderingCommandBuffer etc)
    // so we need to make sure we have built our render data
    BaseRenderer* baseRenderer = this;
    Camera* camera = GetCurrentCameraPtr();
    const Matrix4x4f& worldToCameraMatrix = camera ? camera->GetWorldToCameraMatrix() : Matrix4x4f::identity;
    GlobalCallbacks::Get().rendererCullingOutputReady[GetRendererType()].Invoke(&baseRenderer, 1, camera, worldToCameraMatrix);
}
