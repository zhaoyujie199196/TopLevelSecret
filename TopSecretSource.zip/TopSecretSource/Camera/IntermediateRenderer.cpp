#include "UnityPrefix.h"
#include "IntermediateRenderer.h"
#include "Runtime/Graphics/Mesh/Mesh.h"
#include "Runtime/Graphics/Mesh/SpriteRenderer.h"
#include "Camera.h"
#include "Runtime/Graphics/DrawUtil.h"
#include "Runtime/Camera/RenderNodeQueue.h"
#include "Runtime/Graphics/Mesh/MeshRenderingData.h"
#include "Runtime/GfxDevice/GfxDevice.h"
#include "Runtime/GfxDevice/BatchRendering.h"
#include "Runtime/GfxDevice/SharedGfxBuffer.h"
#include "Runtime/Profiler/ExternalGraphicsProfiler.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Utilities/RegisterRuntimeInitializeAndCleanup.h"
#include "Runtime/UI/Canvas.h"
#include "RendererScene.h"

PROFILER_INFORMATION(gRenderSubBatch, "Canvas.RenderSubBatch", kProfilerRender)

#if UNITY_EDITOR
// In the editor when user pauses the scene in play mode the data can exist for multiple frames.
MemLabelRef IntermediateRenderer::kMemShaderProperty = kMemShader;
#else
// ...but in players we can use kMemTempJobAlloc as the data only exists for one frame.
MemLabelRef IntermediateRenderer::kMemShaderProperty = kMemTempJobAlloc;
#endif

IntermediateRenderer::IntermediateRenderer()
    : BaseRenderer(kRendererIntermediate)
    , m_Properties(NULL)
#if UNITY_EDITOR
    , m_InstanceID(InstanceID_None)
#endif
{
}

void IntermediateRenderer::Initialize(const Matrix4x4f& matrix, const AABB& localAABB, PPtr<Material> material, int layer, ShadowCastingMode shadowCasting, bool receiveShadows)
{
    Assert(localAABB.IsFinite());

    m_Material = material;

    if (layer < 0 || layer >= 32)
    {
        AssertString("DrawMesh layer has to be from in [0..31] range!");
        layer = 0;
    }
    m_Layer = layer;

    SharedRendererData& srd = m_RendererData;
    srd.m_CastShadows = shadowCasting;
    srd.m_ReceiveShadows = receiveShadows;
    srd.m_HasLastPositionStream = false;
    srd.m_MotionVectors = kMotionVectorCamera;

    TransformInfo& transformInfo = GetWritableTransformInfo();
    transformInfo.worldMatrix = matrix;
    // detect uniform and non-uniform scale
    transformInfo.transformType = ComputeTransformType(matrix);
    transformInfo.localAABB = localAABB;
    TransformAABB(localAABB, matrix, transformInfo.worldAABB);

    RendererBecameVisible();
}

IntermediateRenderer::~IntermediateRenderer()
{
    RendererBecameInvisible();
    SAFE_RELEASE(m_Properties);
    SAFE_RELEASE(m_RendererData.m_CustomProperties);
}

void IntermediateRenderer::AssignExternalCustomProperties(ShaderPropertySheet* properties)
{
    if (properties != m_RendererData.m_CustomProperties)
    {
        SAFE_RELEASE(m_RendererData.m_CustomProperties);
        m_RendererData.m_CustomProperties = properties;
        if (properties != NULL)
            properties->AddRef();
    }
}

void IntermediateRenderer::CopyCustomPropertiesFrom(const ShaderPropertySheet& properties)
{
    if (m_Properties == NULL || properties.GetLastComputedHash() != m_Properties->GetLastComputedHash())
    {
        ShaderPropertySheet* writable = GetWritableSharedProperties();
        writable->CopyFrom(properties);
    }
    AssignExternalCustomProperties(m_Properties);
}

ShaderPropertySheet* IntermediateRenderer::GetWritableSharedProperties()
{
    UnshareProperties();
    if (m_Properties == NULL)
        m_Properties = UNITY_NEW(ShaderPropertySheet, kMemShaderProperty)(kMemShaderProperty);
    return m_Properties;
}

void IntermediateRenderer::UnshareProperties()
{
#if ENABLE_MULTITHREADED_CODE
    if (m_Properties && m_Properties->GetRefCount() != 1)
    {
        // Someone else holds a reference to the data and expects it to be immutable.
        // Create our own copy before we make any changes to it.
        ShaderPropertySheet* newProperties = UNITY_NEW(ShaderPropertySheet, kMemShaderProperty)(kMemShaderProperty, *m_Properties);
        SET_ALLOC_OWNER(this);
        m_Properties->Release();
        m_Properties = newProperties;
    }
#endif
}

// --------------------------------------------------------------------------


DEFINE_POOLED_ALLOC(MeshIntermediateRenderer, 64 * 1024);

void MeshIntermediateRenderer::StaticInitialize(void*)
{
    STATIC_INITIALIZE_POOL(MeshIntermediateRenderer, "MeshRenderers");
}

void MeshIntermediateRenderer::StaticDestroy(void*)
{
    STATIC_DESTROY_POOL(MeshIntermediateRenderer);
}

// order = -1: make sure that the pool is destroyed after RenderScene
static RegisterRuntimeInitializeAndCleanup s_MeshIntermediateRendererCallbacks(MeshIntermediateRenderer::StaticInitialize, MeshIntermediateRenderer::StaticDestroy, -1);


MeshIntermediateRenderer::MeshIntermediateRenderer()
    : m_Node(this)
    , m_Mesh(NULL)
    , m_SubMeshIndex(0)
{
}

MeshIntermediateRenderer::~MeshIntermediateRenderer()
{
    m_Node.RemoveFromList();
}

UInt32 MeshIntermediateRenderer::AddAsRenderNode(RenderNodeQueue& queue, const DeprecatedSourceData& sourceData)
{
    if (!m_Mesh)
        return RenderNode::kInvalid;

    // make sure the mesh gets updated before we get it
    Mesh& mesh = *m_Mesh;
    mesh.CreateMeshIfNeeded();

    UInt32 nodeID = BaseRenderer::AddAsRenderNode(queue, sourceData);

    RenderNode& node = queue.GetNode(nodeID);
    node.smallMeshIndex = mesh.GetInternalMeshID();
    node.rendererData.m_StaticBatchInfo.firstSubMesh = m_SubMeshIndex;
    node.rendererSpecificData = sourceData.ReserveAdditionalData(sizeof(MeshRenderingData));

    // need to overwrite the subsetIndex with m_SubsetIndex
    MaterialInfo* materialsArray = node.materialInfos;
    for (int i = 0; i < node.materialCount; i++)
    {
        if (materialsArray[i].sharedMaterialData)
            materialsArray[i].sharedMaterialData->Release();
    }
    node.materialInfos = (MaterialInfo*)sourceData.ReserveAdditionalData(sizeof(MaterialInfo));

    materialsArray = node.materialInfos;
    MaterialInfo& mi = materialsArray[0];

    Material* mat = GetMaterial(m_SubMeshIndex);
    if (mat)
    {
        mi.sharedMaterialData = mat->AcquireSharedMaterialData();
        mi.customRenderQueue = mat->GetCustomRenderQueue();
    }
    else
    {
        mi.sharedMaterialData = Material::GetDefault()->AcquireSharedMaterialData();
        mi.customRenderQueue = -1;
    }

    MeshRenderingData& renderingData = *(MeshRenderingData*)node.rendererSpecificData;
    renderingData.Init(&mesh, NULL, InstanceID_None);

#if GFX_ENABLE_DRAW_CALL_BATCHING
    node.batchingFlags = kBatchingFlagAllowInstancing | kBatchingFlagAllowBatching;
    node.executeBatchedCallback = RenderMultipleMeshes;
#endif

    node.executeCallback = DrawUtil::DrawMeshRawFromNodeQueue;
    node.cleanupCallback = DrawUtil::CleanupDrawMeshRawFromNodeQueue;

    return nodeID;
}

void MeshIntermediateRenderer::Initialize(const Matrix4x4f& matrix, Mesh* mesh, const AABB& localAABB, PPtr<Material> material, int layer, ShadowCastingMode shadowCasting, bool receiveShadows, int submeshIndex)
{
    m_Mesh = mesh;
    if (m_Mesh)
    {
        m_Mesh->AddAssetUser(m_Node);

        if (submeshIndex < 0 || submeshIndex >= (int)m_Mesh->GetSubMeshCount())
        {
            AssertString("Submesh index in intermediate renderer is out of bounds");
            submeshIndex = 0;
        }
    }

    m_SubMeshIndex = submeshIndex;

    IntermediateRenderer::Initialize(matrix, localAABB, material, layer, shadowCasting, receiveShadows);
}

// --------------------------------------------------------------------------

DEFINE_POOLED_ALLOC(CanvasBatchIntermediateRenderer, 64 * 1024);

struct CanvasBatchRenderingData
{
    SharedGfxBuffer* vertexBuffer;
    SharedGfxBuffer* indexBuffer;
    UInt32 vertexStride;
    VertexDeclaration* vertexDeclaration;
    UInt32 subBatchesCount;
    void* subBatches;
};

void CanvasBatchIntermediateRenderer::StaticInitialize(void*)
{
    STATIC_INITIALIZE_POOL(CanvasBatchIntermediateRenderer, "CanvasBatchRenderers");
}

void CanvasBatchIntermediateRenderer::StaticDestroy(void*)
{
    STATIC_DESTROY_POOL(CanvasBatchIntermediateRenderer);
}

// order = -1: make sure that the pool is destroyed after RenderScene
static RegisterRuntimeInitializeAndCleanup s_CanvasBatchIntermediateRendererCallbacks(CanvasBatchIntermediateRenderer::StaticInitialize, CanvasBatchIntermediateRenderer::StaticDestroy, -1);

CanvasBatchIntermediateRenderer::CanvasBatchIntermediateRenderer()
    : m_Node(this)
    , m_VertexBuffer(NULL)
    , m_IndexBuffer(NULL)
{
}

CanvasBatchIntermediateRenderer::~CanvasBatchIntermediateRenderer()
{
    CleanupSubBatchProperties();
    m_Node.RemoveFromList();
}

void CanvasBatchIntermediateRenderer::OnAssetDeleted()
{
    CleanupSubBatchProperties();
    m_SubBatches.clear();
}

void CanvasBatchIntermediateRenderer::CleanupSubBatchProperties()
{
    for (size_t i = 0, n = m_SubBatches.size(); i != n; ++i)
    {
        SAFE_RELEASE(m_SubBatches[i].properties);
    }
    SAFE_RELEASE(m_VertexBuffer);
    SAFE_RELEASE(m_IndexBuffer);
}

void CanvasBatchIntermediateRenderer::Initialize(UI::Canvas* canvas, SharedGfxBuffer* vertexBuffer, VertexDeclaration* vertexDeclaration, UInt32 vertexStride, SharedGfxBuffer* indexBuffer, const Matrix4x4f& matrix, UInt16 distanceSortingOrder, const AABB& localAABB, PPtr<Material> material, int layer, ShadowCastingMode shadowCasting, bool receiveShadows)
{
    DebugAssertMsg(m_VertexBuffer == 0, "CanvasBatchIntermediateRenderer is initialized more than once.");

    if (canvas)
        canvas->AddAssetUser(m_Node);

    m_SameDistanceSortPriority = distanceSortingOrder;
    m_VertexBuffer = SharedGfxBuffer::Acquire(vertexBuffer);
    m_IndexBuffer = SharedGfxBuffer::Acquire(indexBuffer);
    m_VertexDeclaration = vertexDeclaration;
    m_VertexStride = vertexStride;
    IntermediateRenderer::Initialize(matrix, localAABB, material, layer, shadowCasting, receiveShadows);
}

void CanvasBatchIntermediateRenderer::AddSubBatch(const DrawBuffersRange& drawCall, const ShaderPropertySheet* properties)
{
    InternalSubBatch& isb = m_SubBatches.push_back();
    isb.drawBufferRange = drawCall;

    properties->AddRef();
    isb.properties = properties;
}

void CanvasBatchIntermediateRenderer_Render(const RenderNodeQueue& queue, UInt32 nodeID, ShaderChannelMask channels, int materialIndex)
{
    const RenderNode& node = queue.GetNode(nodeID);
    const CanvasBatchRenderingData& renderingData = *(CanvasBatchRenderingData*)node.rendererSpecificData;

    VertexStreamSource vertSource;
    vertSource.buffer = renderingData.vertexBuffer->GetRealGfxBuffer();
    vertSource.stride = renderingData.vertexStride;

    const CanvasBatchIntermediateRenderer::InternalSubBatch* subBatches = (CanvasBatchIntermediateRenderer::InternalSubBatch*)renderingData.subBatches;
    for (int i = 0; i < renderingData.subBatchesCount; ++i)
    {
        PROFILER_AUTO_GFX(gRenderSubBatch, NULL);

        if (subBatches[i].properties)
            GetGfxDevice().SetShaderPropertiesCopied(*subBatches[i].properties);

        GetGfxDevice().DrawBuffers(renderingData.indexBuffer->GetRealGfxBuffer(), &vertSource, 1, &subBatches[i].drawBufferRange, 1, renderingData.vertexDeclaration, channels);
        GPU_TIMESTAMP();
    }
}

void CanvasBatchIntermediateRenderer_Cleanup(RenderNodeQueue& queue, UInt32 nodeID)
{
    RenderNode& node = queue.GetNode(nodeID);
    CanvasBatchRenderingData& renderingData = *(CanvasBatchRenderingData*)node.rendererSpecificData;
    CanvasBatchIntermediateRenderer::InternalSubBatch* subBatches = (CanvasBatchIntermediateRenderer::InternalSubBatch*)renderingData.subBatches;
    SAFE_RELEASE(renderingData.vertexBuffer);
    SAFE_RELEASE(renderingData.indexBuffer);
    for (int i = 0; i < renderingData.subBatchesCount; ++i)
    {
        if (subBatches[i].properties)
        {
            SAFE_RELEASE(subBatches[i].properties);
        }
    }
}

UInt32 CanvasBatchIntermediateRenderer::AddAsRenderNode(RenderNodeQueue& queue, const DeprecatedSourceData& sourceData)
{
    int subBatchesCount = m_SubBatches.size();
    if (!subBatchesCount)
        return RenderNode::kInvalid;

    UInt32 nodeID = BaseRenderer::FlattenToRenderQueue(queue, sourceData);
    RenderNode& node = queue.GetNode(nodeID);

    node.rendererSpecificData = sourceData.ReserveAdditionalData(sizeof(CanvasBatchRenderingData));
    node.sameDistanceSortPriority = m_SameDistanceSortPriority;

    void* subBatches = sourceData.ReserveAdditionalData(subBatchesCount * sizeof(InternalSubBatch));

    CanvasBatchRenderingData& renderingData = *(CanvasBatchRenderingData*)node.rendererSpecificData;
    node.executeCallback = CanvasBatchIntermediateRenderer_Render;
    node.cleanupCallback = CanvasBatchIntermediateRenderer_Cleanup;

    renderingData.vertexBuffer = SharedGfxBuffer::Acquire(m_VertexBuffer);
    renderingData.indexBuffer = SharedGfxBuffer::Acquire(m_IndexBuffer);
    renderingData.vertexStride = m_VertexStride;
    renderingData.vertexDeclaration = m_VertexDeclaration;
    renderingData.subBatchesCount = subBatchesCount;
    renderingData.subBatches = subBatches;

    InternalSubBatch* internalSubBatches = (InternalSubBatch*)subBatches;
    memcpy(internalSubBatches , &m_SubBatches[0], subBatchesCount * sizeof(InternalSubBatch));
    for (int i = 0; i < subBatchesCount; ++i)
    {
        if (m_SubBatches[i].properties)
            m_SubBatches[i].properties->AddRef();
    }

    return nodeID;
}

// --------------------------------------------------------------------------

void IntermediateRenderers::Clear(size_t startIndex)
{
    size_t n = m_SceneNodes.size();
    Assert(startIndex <= n);

    for (size_t i = startIndex; i < n; ++i)
    {
        IntermediateRenderer* renderer = static_cast<IntermediateRenderer*>(m_SceneNodes[i].renderer);
        delete renderer;
    }
    m_SceneNodes.resize_uninitialized(startIndex);
    m_BoundingBoxes.resize_uninitialized(startIndex);
}

const AABB* IntermediateRenderers::GetBoundingBoxes() const
{
    return m_BoundingBoxes.begin();
}

const SceneNode* IntermediateRenderers::GetSceneNodes() const
{
    return m_SceneNodes.begin();
}

void IntermediateRenderers::Add(IntermediateRenderer* renderer)
{
    m_SceneNodes.push_back(SceneNode());

    SceneNode& node = m_SceneNodes.back();
    node.renderer = renderer;
    node.layer = renderer->GetLayer();
    node.shadowCastingMode = renderer->GetShadowCastingMode();

    m_BoundingBoxes.push_back(renderer->GetCachedWorldAABB());
}

IntermediateRenderer* AddMeshIntermediateRenderer(const Matrix4x4f& matrix, Mesh* mesh, PPtr<Material> material, int layer, ShadowCastingMode shadowCasting, bool receiveShadows, int submeshIndex, Camera* camera)
{
    AABB bounds;
    if (mesh)
        bounds = mesh->GetBounds();
    else
        bounds.SetCenterAndExtent(Vector3f::zero, Vector3f::zero);

    return AddMeshIntermediateRenderer(matrix, mesh, bounds, material, layer, shadowCasting, receiveShadows, submeshIndex, camera);
}

IntermediateRenderer* AddMeshIntermediateRenderer(const Matrix4x4f& matrix, Mesh* mesh, const AABB& localAABB, PPtr<Material> material, int layer, ShadowCastingMode shadowCasting, bool receiveShadows, int submeshIndex , Camera* camera)
{
    MeshIntermediateRenderer* renderer = new MeshIntermediateRenderer();
    renderer->Initialize(matrix, mesh, localAABB, material, layer, shadowCasting, receiveShadows, submeshIndex);
    AddIntermediateRenderer(renderer, camera);
    return renderer;
}

CanvasBatchIntermediateRenderer* AddCanvasIntermediateRenderer(UI::Canvas* canvas, SharedGfxBuffer* vertexBuffer, VertexDeclaration* vertexDeclaration, UInt32 vertexStride, SharedGfxBuffer* indexBuffer, const Matrix4x4f& matrix, UInt16 distanceSortingOrder, const AABB& localAABB, PPtr<Material> material, int layer, ShadowCastingMode shadowCasting, bool receiveShadows, Camera* camera)
{
    CanvasBatchIntermediateRenderer* renderer = new CanvasBatchIntermediateRenderer();
    renderer->Initialize(canvas, vertexBuffer, vertexDeclaration, vertexStride, indexBuffer, matrix, distanceSortingOrder, localAABB, material, layer, shadowCasting, receiveShadows);
    IntermediateRenderers* renderers;
    if (camera != NULL)
        renderers = &camera->GetIntermediateRenderers();
    else
        renderers = &GetRendererScene().GetIntermediateRenderers();
    renderers->Add(renderer);

    return renderer;
}

void AddIntermediateRenderer(IntermediateRenderer* renderer , Camera* camera)
{
    (camera != NULL ? camera->GetIntermediateRenderers() : GetRendererScene().GetIntermediateRenderers()).Add(renderer);
}
