#pragma once

#include "Runtime/BaseClasses/GameManager.h"
#include "Runtime/Camera/RenderLoops/RenderLoopEnums.h"
#include "Runtime/Shaders/GraphicsCaps.h"
#include "Runtime/Shaders/Shader.h"
#include "Runtime/Shaders/GpuPrograms/ShaderVariantCollection.h"
#include <vector>

#include "Runtime/Serialize/SerializeUtility.h"

#if UNITY_EDITOR
    #include "Editor/Src/BuildPipeline/BuildTargetPlatformSpecific.h"
#endif

class Material;
class MonoBehaviour;

struct BuiltinShaderSettings
{
    // match C# Rendering.BuiltinShaderMode
    enum BuiltinShaderMode
    {
        kBuiltinShaderNone = 0,
        kBuiltinShaderBuiltin,
        kBuiltinShaderCustom,
    };
    PPtr<Shader>    m_Shader; ///< Shader to use
    BuiltinShaderMode m_Mode; ///< enum { No Support, Built-in shader, Custom shader } Shader mode

    DECLARE_SERIALIZE(BuiltinShaderSettings)

    BuiltinShaderSettings() { Reset(); }
    void Reset()            { m_Mode = kBuiltinShaderBuiltin; }

    void CreateMaterialIfNeeded(Material** inoutMaterial, const int minPassCount = 1) const;
    bool IsDisabled() const { return m_Mode == kBuiltinShaderNone; }
};


// must match C# UnityEditor.Rendering.ShaderQuality
enum ShaderQualityPreset
{
    kShaderQualityLow,
    kShaderQualityMedium,
    kShaderQualityHigh,
};

enum HDRMode
{
    kHDRModeFP16 = 1,
    kHDRModeR11G11B10Float = 2,
    KHDRModeCount = 3
};

enum RealtimeGICPUUsage // Realtime Global Illumination CPU Usage
{
    kRealtimeGICPUUsageLow = 25,
    kRealtimeGICPUUsageMedium = 50,
    kRealtimeGICPUUsageHigh = 75,
    kRealtimeGICPUUsageUnlimited = 100
};

// Per-Platform Per-Tier Graphics Settings
// TierGraphicsSettingsEditor: editor-side settings
// TierGraphicsSettingsEditorScript: helper to pass settings c++ <-> c# (due to bool being not-blittable)
// TierGraphicsSettings: runtime settings
// EditorOnlyGraphicsSettings::TierSettings: editor-side struct that holds settings alongside with platform/tier and is-automatic flag
//
// Data Flow:
// TierGraphicsSettingsEditor are inited with defaults values (check DefaultTierSettings in EditorOnlyGraphicsSettings.cpp)
// Editor uses array of EditorOnlyGraphicsSettings::TierSettings
// C# uses UnityEditor.Rendering.TierSettings which is blitted to TierGraphicsSettingsEditorScript and converted from/to TierGraphicsSettingsEditor
//  for conversion code check ConvertTierGraphicsSettingsScriptToNative and ConvertTierGraphicsSettingsNativeToScript
// At build time TierGraphicsSettingsEditor are used to make "decisions"
// most important are:
//   shader compiler defines. GraphicsSettings will be passed to platform_caps_keywords::Init and platform_caps_keywords::Update along with target platform/tier
//
// How to add your own member (5-7 are optional):
// 1. add to TierGraphicsSettingsEditor, TierGraphicsSettingsEditorScript, UnityEditor.Rendering.TierSettings
// 2. update TierGraphicsSettingsEditor::Transfer
// 3. update ConvertTierGraphicsSettingsScriptToNative, ConvertTierGraphicsSettingsNativeToScript
// 4. update DefaultTierSettings (and/or possibly SetDefaultTierShaderSettings if it impacts shader compilation)
//
// 5. if you want to have non-zero values on loading old data (missing new member)
//      update EditorOnlyGraphicsSettings::TierSettings transfer version
//      in EditorOnlyGraphicsSettings::TierSettings::TransferDeprecated add code path to handle init for old data
//      why we pick "update transfer version" over other methods of checking if some action is needed:
//        we cannot use DidReadLastProperty as we need to check when transfering TierGraphicsSettingsEditor but we dont know platform/tier at this point
//        and for "set some value and then check if it stays the same" i personally dont like it
//
// 6. if newly-added member impacts shader compilation:
//      update AreShaderSettingsSame in EditorOnlyGraphicsSettings.cpp
//      update platform_caps_keywords::Update
//
// 7. if newly-added member should be available at runtime (not necessarily directly)
//      update TierGraphicsSettings and TierGraphicsSettings::Transfer
//      update TierSettingsRuntimeFromEditor in EditorOnlyGraphicsSettings.cpp
//      update GraphicsSettings::Transfer, so that we set m_NeedToInitializeTierSettings to true (so m_TierSettings are reread from editor tier settings)
//        (This can be achived by increasing the GraphicsSettings version number along with the version number that is being checked when setting m_NeedToInitializeTierSettings)
//        what happens is that for TierSettings there is no upgrade path, so new members will be zero
//        and unlike editor tier settings we dont know target platform (build settings are not initied yet on startup)

struct TierGraphicsSettings
{
    RenderingPath       renderingPath;
    HDRMode             hdrMode;
    RealtimeGICPUUsage  realtimeGICPUUsage;
    bool                useCascadedShadowMaps;
    bool                enableLPPV;
    bool                useHDR;

    DECLARE_SERIALIZE(TierGraphicsSettings);
};

#if UNITY_EDITOR
struct TierGraphicsSettingsEditor
{
    // shaders
    ShaderQualityPreset standardShaderQuality;
    HDRMode             hdrMode;
    bool                useReflectionProbeBoxProjection;
    bool                useReflectionProbeBlending;
    bool                useHDR;
    bool                useDetailNormalMap;

    bool                useCascadedShadowMaps;
    bool                enableLPPV;
    bool                useDitherMaskForAlphaBlendedShadows;

    // lighting
    RenderingPath       renderingPath;
    RealtimeGICPUUsage  realtimeGICPUUsage;

    DECLARE_SERIALIZE(TierGraphicsSettingsEditor);
};

struct TierGraphicsSettingsEditorScript
{
    ShaderQualityPreset standardShaderQuality;
    HDRMode             hdrMode;
    ScriptingBool       useReflectionProbeBoxProjection;
    ScriptingBool       useReflectionProbeBlending;
    ScriptingBool       useHDR;
    ScriptingBool       useDetailNormalMap;

    ScriptingBool       useCascadedShadowMaps;
    ScriptingBool       enableLPPV;
    ScriptingBool       useDitherMaskForAlphaBlendedShadows;

    RenderingPath       renderingPath;
    RealtimeGICPUUsage  realtimeGICPUUsage;
};
TierGraphicsSettingsEditor          ConvertTierGraphicsSettingsScriptToNative(const TierGraphicsSettingsEditorScript& ps);
TierGraphicsSettingsEditorScript    ConvertTierGraphicsSettingsNativeToScript(const TierGraphicsSettingsEditor& ps);
#endif


#if UNITY_EDITOR || DOXYGEN
// We serialize EditorOnlyGraphicsSettings directly in GraphicsSettings.
// In order to not lose the enum parameters we do this hack
    #if DOXYGEN
struct GraphicsSettings
    #else
struct EditorOnlyGraphicsSettings
    #endif
{
    enum ShaderStrippingMode
    {
        kShaderStrippingAutomatic = 0,
        kShaderStrippingManual,
    };

    enum InstancingStrippingMode
    {
        kInstancingStrippingStripUnused = 0,
        kInstancingStrippingStripAll,
        kInstancingStrippingKeepAll,
    };

    struct TierSettings
    {
        BuildTargetPlatformGroup    m_BuildTarget;
        GraphicsTier                m_Tier;

        TierGraphicsSettingsEditor  m_Settings;
        bool                        m_Automatic;

        DECLARE_SERIALIZE(TierSettings)
        template<class TransferFunc> void TransferDeprecated(TransferFunc& transfer);
    };

    struct AlbedoSwatchInfo
    {
        core::string name;
        ColorRGBAf color;
        float minLuminance;
        float maxLuminance;
        DECLARE_SERIALIZE(AlbedoSwatchInfo)
    };

    std::vector<TierSettings>   m_TierSettings;

    ShaderStrippingMode m_LightmapStripping;     ///< enum { Automatic = 0, Manual } Build-time stripping of lightmap shader variants
    ShaderStrippingMode m_FogStripping;     ///< enum { Automatic = 0, Manual } Build-time stripping of fog shader variants
    InstancingStrippingMode m_InstancingStripping;     ///< enum { Strip Unused = 0, Strip All, Keep All } Build-time stripping of instancing variants

    // we need those only for upgrade path: before unity 5.5 we would specify rendering path in player settings
    // we had it separate for "mobile" platforms and non-"mobile" and we want to preserve these values as "default"
    // TODO: if we need this mechanism for more things,
    //   comment needs to be rewritten to be more general and moved to big comment block above
    RenderingPath       m_DefaultRenderingPath;
    RenderingPath       m_DefaultMobileRenderingPath;


    bool                m_LightmapKeepPlain;
    bool                m_LightmapKeepDirCombined;
    bool                m_LightmapKeepDynamicPlain;
    bool                m_LightmapKeepDynamicDirCombined;
    bool                m_LightmapKeepShadowMask;
    bool                m_LightmapKeepSubtractive;

    bool                m_FogKeepLinear;
    bool                m_FogKeepExp;
    bool                m_FogKeepExp2;

    //PBR Validator Albedo Comparision swatches
    std::vector<AlbedoSwatchInfo> m_AlbedoSwatchInfos;

    DECLARE_SERIALIZE(EditorOnlyGraphicsSettings)

    void Reset();

    BuildUsageTagGlobal GetBuildUsageTagGlobal() const;
    void ApplyShaderStrippingToBuildUsageTagGlobal(BuildUsageTagGlobal& inoutUsage) const;
    void CalculateLightmapStrippingFromCurrentScene();
    void CalculateFogStrippingFromCurrentScene();

    TierGraphicsSettingsEditor GetTierSettings(BuildTargetPlatformGroup platform, GraphicsTier tier) const;
    void SetTierSettings(BuildTargetPlatformGroup platform, GraphicsTier tier, const TierGraphicsSettingsEditor& settings);
    bool AreTierSettingsAutomatic(BuildTargetPlatformGroup platform, GraphicsTier tier) const;
    void MakeTierSettingsAutomatic(BuildTargetPlatformGroup platform, GraphicsTier tier, bool automatic);

    bool HasDifferentShaderSettingsPerTier(BuildTargetPlatformGroup platform) const;

    void SetAlbedoSwatches(std::vector<AlbedoSwatchInfo>& swatches) { m_AlbedoSwatchInfos = swatches; }
    std::vector<AlbedoSwatchInfo>& GetAlbedoSwatches() { return m_AlbedoSwatchInfos; }
};
#endif


class GraphicsSettings : public GlobalGameManager
{
    REGISTER_CLASS(GraphicsSettings);
    DECLARE_OBJECT_SERIALIZE();
public:
    // Match C# UnityEngine.Rendering.BuiltinShaderType
    enum BuiltinShaderType
    {
        kDeferredShading = 0,
        kDeferredReflections = 1,
        kLegacyDeferredLighting = 2,
        kScreenSpaceShadows = 3,
        kDepthNormals = 4,
        kMotionVectors = 5,
        kLightHalo = 6,
        kLensFlare = 7,
    };

    enum BuiltinMaterialType
    {
        kSpritesDefaultMat = 0
    };

public:
    typedef UNITY_VECTOR (kMemRenderer, PPtr<Shader>) ShaderArray;
    typedef UNITY_VECTOR (kMemRenderer, PPtr<ShaderVariantCollection>) ShaderVariantCollections;

    GraphicsSettings(MemLabelId label, ObjectCreationMode mode);

    static void InitializeClass();
    static void CleanupClass();

    virtual void SmartReset();
    virtual void AwakeFromLoad(AwakeFromLoadMode awakeMode);

    const BuiltinShaderSettings&    GetBuiltinShaderSettings(BuiltinShaderType type) const;
    BuiltinShaderSettings&          GetBuiltinShaderSettings(BuiltinShaderType type);

    const TierGraphicsSettings&     GetTierSettings() const { return m_TierSettings[GetGraphicsCaps().activeTier]; }
#if UNITY_EDITOR
    void UpdateTierSettingsForCurrentBuildTarget();
#endif

    void WarmupPreloadedShaders();


#if UNITY_EDITOR
    const EditorOnlyGraphicsSettings&   EditorOnly() const      { return m_EditorOnly; }
    EditorOnlyGraphicsSettings&         EditorOnlyForUpdate()   { SetDirty(); return m_EditorOnly; }
#endif

#if UNITY_EDITOR
    bool DoesNeedToInitializeDefaultShaderReferences() const    { return m_NeedToInitializeDefaultShaderReferences; }
    bool DoesNeedToInitializeDefaultuGUIShaders() const         { return m_NeedToInitializeDefaultuGUIShaders; }
    bool DoesNeedToInitializeTierSettings() const               { return m_NeedToInitializeTierSettings; }

    void SetDefaultShaderReferences();
    void SetDefaultAlwaysIncludeduGUIShaders();
    void InitializeTierSettings();
#endif

#if UNITY_EDITOR
    /// Return true if the given shader is in the list of shaders
    /// that should always be included in builds.
    bool IsAlwaysIncludedShader(PPtr<Shader> shader) const;

    /// Add/remove a shader to the list of shaders that are aways included in builds.
    void RegisterAlwaysIncludedShader(PPtr<Shader> shader);
    void UnregisterAlwaysIncludedShader(PPtr<Shader> shader);

    // Returns shaders referenced by graphics settings (built-in and
    // always included ones; NOTE: skips shaders in preload shaders list)
    void GetReferencedShaders(ShaderArray& outShaders) const;
#endif // if UNITY_EDITOR

    GET_SET_COMPARE_DIRTY(int, TransparencySortMode, m_TransparencySortMode);
    GET_SET_COMPARE_DIRTY(Vector3f, TransparencySortAxis, m_TransparencySortAxis);

    bool GetLightsUseLinearIntensity() const { return m_LightsUseLinearIntensity; }
    void SetLightsUseLinearIntensity(bool useLinearIntensity);
    bool GetLightsUseColorTemperature() const { return m_LightsUseColorTemperature; }
    void SetLightsUseColorTemperature(bool useColorTemperature);

    PPtr<Material> GetBuiltinMaterial(BuiltinMaterialType type);

    PPtr<MonoBehaviour> GetRenderPipeline() const;
    void SetRenderPipeline(PPtr<MonoBehaviour> renderPipeline);

    void CleanupRenderPipeline();

private:
#if UNITY_EDITOR
    template<class TransferFunc> void TransferDeprecated(TransferFunc& transfer);

    void AddHiddenInternalShaders(ShaderArray& dest) const;
#endif

    BuiltinShaderSettings       m_Deferred; ///< Deferred shading shader settings
    BuiltinShaderSettings       m_DeferredReflections; ///< Deferred Reflections shader settings
    BuiltinShaderSettings       m_ScreenSpaceShadows; ///< Screenspace cascaded shadows shader settings
    BuiltinShaderSettings       m_LegacyDeferred; ///< Legacy (light prepass) deferred shader settings
    BuiltinShaderSettings       m_MotionVectors; ///< MotionVectors shader settings
    BuiltinShaderSettings       m_DepthNormals; ///< Camera depth normal shader settings
    BuiltinShaderSettings       m_LightHalo; ///< Light halo shader settings
    BuiltinShaderSettings       m_LensFlare; ///< Lens flare shader settings

    ShaderArray                 m_AlwaysIncludedShaders;
    ShaderVariantCollections    m_PreloadedShaders;

    PPtr<Material>              m_SpritesDefaultMaterial;
    PPtr<MonoBehaviour>         m_CustomRenderPipeline;

    // per-tier graphics settings
    // at runtime we keep all of them to support switching tiers
    // at editor-side we dont use these (rather we get shader settings from platform+tier), but we keep it to simplify transfer function
    // in editor they will be updated in UpdateTierSettingsForCurrentBuildTarget()
    TierGraphicsSettings        m_TierSettings[kGraphicsTierCount];

    int                         m_TransparencySortMode; ///< enum { Default, Perspective, Orthographic, Custom Axis }
    Vector3f                    m_TransparencySortAxis;

#if UNITY_EDITOR
    EditorOnlyGraphicsSettings  m_EditorOnly;
    bool                        m_NeedToInitializeDefaultShaderReferences;
    bool                        m_NeedToInitializeDefaultuGUIShaders;
    bool                        m_NeedToInitializeTierSettings;
#endif

    bool m_LightsUseLinearIntensity;    ///< Should lights use physically correct intensity or legacy intensity calculations?
    bool m_LightsUseColorTemperature;   ///< Should lights use the Correlated Color Temperature slider? Correlated ColorTemperature is defined as the color of the electromagnetic radiation emitted from an ideal black body when its surface temperature is set to a temperature defined in Kelvin.
};


GraphicsSettings& GetGraphicsSettings();
GraphicsSettings* GetGraphicsSettingsPtr();
