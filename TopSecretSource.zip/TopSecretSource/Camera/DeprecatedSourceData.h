#pragma once

#include "Runtime/Allocator/PageAllocator.h"

class BaseRenderer;

/*
    Deprecated source data to create RenderQueueNode::Nodes from BaseRenderer*
    It will eventually go away once we implement threaded conversion for all Renderer types.
*/

struct DeprecatedSourceData
{
    BaseRenderer*   renderer;
    float           lodFade;

    UInt32                          outputIndex;
    mutable PerThreadPageAllocator* allocator;

    DeprecatedSourceData(PerThreadPageAllocator* additionalDataAllocator)
    {
        renderer = NULL;
        lodFade = 0.0f;
        outputIndex = -1;
        allocator = additionalDataAllocator;
    }

    DeprecatedSourceData(BaseRenderer* r, PerThreadPageAllocator* additionalDataAllocator)
    {
        renderer = r;
        lodFade = 0.0f;
        outputIndex = -1;
        allocator = additionalDataAllocator;
    }

    void* AllocateAdditionalData(void* data, size_t size) const
    {
        void* ptr = allocator->AllocateInternal(size);
        memcpy(ptr, data, size);
        return ptr;
    }

    void* ReserveAdditionalData(size_t size) const
    {
        return allocator->AllocateInternal(size);
    }
};
