#include "UnityPrefix.h"
#include "Camera.h"
#include "CameraRenderOldState.h"
#include "CameraStack.h"
#include "Runtime/Graphics/GraphicsHelper.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Serialize/TransferFunctions/TransferNameConversions.h"
#include "RendererScene.h"
#include "SharedRendererScene.h"
#include "Culler.h"
#include "SceneCulling.h"
#include "Culling/CullingGroupManager.h"
#include "ImageFilters.h"
#include "RenderSettings.h"
#include "Runtime/Shaders/ShaderPassContext.h"
#include "RenderManager.h"
#include "Skybox.h"
#include "Light.h"
#include "PersistentShadowMaps.h"
#include "Shadows.h"
#include "GraphicsSettings.h"
#include "Runtime/BaseClasses/IsPlaying.h"
#include "Runtime/BaseClasses/MessageHandlerRegistration.h"
#include "Runtime/Misc/BuildSettings.h"
#include "Runtime/Camera/Flare.h"
#include "Runtime/Camera/LightProbeProxyVolume.h"
#include "Runtime/Camera/RenderLayers/GUILayer.h"
#include "Runtime/Input/TimeManager.h"
#include "Runtime/GfxDevice/GfxDevice.h"
#include "CameraUtil.h"
#include "Runtime/Graphics/CubemapTexture.h"
#include "Runtime/Graphics/RenderTexture.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Profiler/ExternalGraphicsProfiler.h"
#include "RenderLoops/ReplacementRenderLoop.h"
#include "Runtime/Misc/PlayerSettings.h"
#include "Runtime/Mono/MonoManager.h"
#include "Runtime/Graphics/ScreenManager.h"
#include "Runtime/Shaders/ShaderNameRegistry.h"
#include "Configuration/UnityConfigure.h"
#include "ShadowCulling.h"
#include "Runtime/Graphics/QualitySettings.h"
#include "Runtime/Graphics/RenderSurface.h"
#include "Runtime/Graphics/DisplayManager.h"
#include "Runtime/Graphics/Renderer.h"
#include "Runtime/Graphics/LOD/LODGroupManager.h"
#include "Runtime/Graphics/RenderBufferManager.h"
#include "Runtime/Graphics/GraphicsScriptBindings.h"
#include "Runtime/Graphics/ScriptableRenderLoop/ScriptableRenderContext.h"
#include "Runtime/Shaders/ShaderImpl/ShaderImpl.h"
#include "Runtime/Interfaces/ITerrainManager.h"
#include "Runtime/Graphics/LightmapSettings.h"
#include "Runtime/Core/Callbacks/GlobalCallbacks.h"
#include "Runtime/Interfaces/IVRDevice.h"
#include "Runtime/Graphics/Billboard/BillboardBatchManager.h"
#include "Runtime/Camera/HaloManager.h"
#include "Runtime/Graphics/RendererUpdateManager.h"
#include "Runtime/Testing/Faking.h"
#include "Runtime/Mono/MonoBehaviour.h"

#if INCLUDE_GI && INCLUDE_DYNAMIC_GI && ENABLE_RUNTIME_GI
#include "Runtime/GI/Enlighten/OverlayManager.h"
#endif

#if UNITY_EDITOR
#include "Editor/Platform/Interface/EditorWindows.h"
#include "Editor/Platform/Interface/RepaintController.h"
#include "Editor/Src/EditorUserBuildSettings.h"
#endif

#include "Runtime/Misc/Player.h"

///@TODO: Ensure that we use cullingparameters.renderingPath, otherwise potential inconsistency when switching renderpath after culling.
RenderingPath CalculateRenderingPath(RenderingPath rp);

PROFILER_INFORMATION(gCameraClearProfile,               "Clear",                            kProfilerRender)
PROFILER_INFORMATION(gCameraRenderProfile,              "Camera.Render",                    kProfilerRender)
PROFILER_INFORMATION(gCameraRenderToCubemapProfile,     "Camera.RenderToCubemap",           kProfilerRender)
PROFILER_INFORMATION(gGUILayerProfile,                  "Camera.GUILayer",                  kProfilerRender)
PROFILER_INFORMATION(gCameraCullProfile,                "Culling",                          kProfilerRender)
PROFILER_INFORMATION(gCameraDrawProfile,                "Drawing",                          kProfilerRender)
PROFILER_INFORMATION(gCameraDrawMultiCustomPreProfile,  "DrawingMultiCustomPre",            kProfilerRender)
PROFILER_INFORMATION(gCameraDrawMultiCustomProfile,     "DrawingMultiCustom",               kProfilerRender)
PROFILER_INFORMATION(gCameraDrawMultiCustomPostProfile, "DrawingMultiCustomPost",           kProfilerRender)
PROFILER_INFORMATION(gCameraDepthTextureProfile,        "UpdateDepthTexture",               kProfilerRender)
PROFILER_INFORMATION(gCameraDepthNormalsTextureProfile, "UpdateDepthNormalsTexture",        kProfilerRender)
PROFILER_INFORMATION(gPrepareSceneCullingParameters,    "PrepareSceneCullingParameters",    kProfilerRender)

DEFINE_MESSAGE_IDENTIFIER(kPreCull, ("OnPreCull", MessageIdentifier::kSendToScripts | MessageIdentifier::kDontSendToDisabled));
DEFINE_MESSAGE_IDENTIFIER(kPostRender, ("OnPostRender", MessageIdentifier::kSendToScripts | MessageIdentifier::kDontSendToDisabled));
DEFINE_MESSAGE_IDENTIFIER(kPreRender, ("OnPreRender", MessageIdentifier::kSendToScripts | MessageIdentifier::kDontSendToDisabled));

static SHADERPROP(CameraDepthTexture);
static SHADERPROP(CameraDepthNormalsTexture);
static SHADERPROP(LastCameraDepthTexture);
static SHADERPROP(LastCameraDepthNormalsTexture);
static SHADERPROP(Reflection);

/////***@TODO: Write test for stressing multithreaded breaking when OnWillRenderObjects does nasty things...

void Camera::InitializeClass()
{
    REGISTER_MESSAGE_VOID(kTransformChanged, TransformChanged);
    RegisterAllowNameConversion(TypeOf<Camera>()->GetName(), "is ortho graphic", "orthographic");
}

void Camera::CleanupClass()
{
#if UNITY_EDITOR
    DestroyEditorCamera();
#endif

    DebugAssert(s_AllCamera.empty());
}

Camera::CopiableState::CopiableState()
    :   m_FieldOfViewBeforeEnablingVRMode(-1.0f)
    ,   m_TargetDisplay(0)
    ,   m_TargetEye(kTargetEyeMaskBoth)
    ,   m_DepthTextureMode(0)
    ,   m_DirtyWorldToCameraMatrix(true)
    ,   m_DirtyProjectionMatrix(true)
    ,   m_DirtyWorldToClipMatrix(true)
    ,   m_DirtySkyboxProjectionMatrix(true)
    ,   m_ClearStencilAfterLightingPass(false)
#if UNITY_EDITOR
    ,   m_AnimateMaterials(false)
    ,   m_AnimateMaterialsTime(0.0f)
#endif
{
    m_CullingMask.m_Bits = 0xFFFFFFFF;
    m_EventMask.m_Bits = 0xFFFFFFFF;

    for (int i = 0; i < 32; i++)
        m_LayerCullDistances[i] = 0;
    m_LayerCullSpherical = false;
    m_OpaqueSortMode = kOpaqueSortDefault;
    m_ImplicitProjectionMatrix = m_ImplicitWorldToCameraMatrix = true;
    m_ImplicitCullingMatrix = true;
    m_ImplicitAspect = true;
    m_ImplicitSkyboxProjectionMatrix = true;
    m_AllowHDR = true;
    m_UsingHDR = false;
    m_AllowMSAA = true;
    m_ForceIntoRT = false;
    m_Aspect = 1.0F;
    m_CameraType = kCameraTypeGame;
    m_TransparencySortMode = (TransparencySortMode)GetGraphicsSettings().GetTransparencySortMode();
    m_TransparencySortAxis = GetGraphicsSettings().GetTransparencySortAxis();
    m_ImplicitTransparencySortSettings = true;

    m_Velocity = Vector3f::zero;
    m_LastPosition = Vector3f::zero;
    m_WorldToCameraMatrix = m_WorldToClipMatrix = m_ProjectionMatrix = m_SkyboxProjectionMatrix = m_CullingMatrix = Matrix4x4f::identity;
    m_OcclusionCulling = true;

    m_TargetColorBufferCount = 1;
    ::memset(m_TargetColorBuffer, 0x00, sizeof(m_TargetColorBuffer));
    ::memset(m_TargetBuffersOriginatedFrom, 0x00, sizeof(m_TargetBuffersOriginatedFrom));

    m_TargetColorBuffer[0] = RenderSurfaceHandle();
    m_TargetDepthBuffer = RenderSurfaceHandle();

    m_StereoSeparation = 0.022f;
    m_StereoConvergence = 10.0f;
    m_StereoFrameCounter = 0;
    m_StereoMirrorMode = false;

    m_ImplicitStereoViewMatrices = true;
    m_ImplicitStereoProjectionMatrices = true;
    for (int i = 0; i < 2; ++i)
    {
        m_StereoViewMatrices[i] = Matrix4x4f::identity;
        m_StereoProjectionMatrices[i] = Matrix4x4f::identity;
    }
}

void Camera::CopiableState::Reset()
{
    m_NormalizedViewPortRect = Rectf(0, 0, 1, 1);

    m_BackGroundColor = ColorRGBA32(49, 77, 121, 0);
    m_Depth = 0.0F;
    m_NearClip = 0.3F;
    m_FarClip = 1000.0F;
    m_RenderingPath = -1;
    m_Aspect = 1.0F;
    m_Orthographic = false;
    m_AllowHDR = true;
    m_AllowMSAA = true;
    m_ForceIntoRT = false;
    m_OpaqueSortMode = kOpaqueSortDefault;
    m_TransparencySortMode = (TransparencySortMode)GetGraphicsSettings().GetTransparencySortMode();
    m_TransparencySortAxis = GetGraphicsSettings().GetTransparencySortAxis();
    m_ImplicitTransparencySortSettings = true;

    m_OrthographicSize = 5.0F;
    m_FieldOfView = 60.0F;
    m_FieldOfViewBeforeEnablingVRMode = -1.0f;
    m_ClearFlags = kSkybox;
    m_DirtyWorldToCameraMatrix = m_DirtyProjectionMatrix = m_DirtySkyboxProjectionMatrix = m_DirtyWorldToClipMatrix = true;
    m_TargetDisplay = 0;
    m_TargetEye = kTargetEyeMaskBoth;
}

Camera::Camera(MemLabelId label, ObjectCreationMode mode)
    :   Super(label, mode)
    ,   m_RenderEvents(kRenderEventCount)
#if UNITY_EDITOR
    ,   m_EditorCullResults(NULL)
    ,   m_FilterMode(0)
    ,   m_OnlyRenderIntermediateObjects(false)
    ,   m_IsSceneCamera(false)
    ,   m_StackState(NULL)
    ,   m_LastDrawingMode(kEditorDrawModeCount)
#endif
    ,   m_IsRendering(false)
    ,   m_IsRenderingStereo(false)
    ,   m_IsStandaloneCustomRendering(false)
    ,   m_IsCulling(false)
    ,   m_IsNonJitteredProjMatrixSet(false)
    ,   m_UseJitteredProjMatrixForTransparent(true)
    ,   m_BuffersSetFromScripts(false)
    ,   m_CurrentTargetTexture(NULL)
    ,   m_DepthTexture(NULL)
    ,   m_DepthNormalsTexture(NULL)
    ,   m_RenderPlaneCallbacks(GetMemoryLabel())
{
    m_RenderLoop = CreateRenderLoop(*this);
    m_ShadowCache = CreateShadowMapCache();
    m_IntermediateRenderers = UNITY_NEW(IntermediateRenderers, GetMemoryLabel());

    s_AllCamera.push_back(this);
}

void Camera::Reset()
{
    Super::Reset();

    m_State.Reset();
}

void Camera::CheckConsistency()
{
    Super::CheckConsistency();
    m_State.m_RenderingPath = clamp(m_State.m_RenderingPath, -1, kRenderPathCount - 1);
    if (!m_State.m_Orthographic && m_State.m_NearClip < 0.01F)
        m_State.m_NearClip = 0.01F;
    if (m_State.m_FarClip < m_State.m_NearClip + 0.01F)
        m_State.m_FarClip = m_State.m_NearClip + 0.01F;
}

void Camera::ThreadedCleanup()
{
    UNITY_DELETE(m_IntermediateRenderers, GetMemoryLabel());
    DeleteRenderLoop(m_RenderLoop);
    DestroyShadowMapCache(m_ShadowCache);
    m_ShadowCache = NULL;
}

void Camera::MainThreadCleanup()
{
    m_RenderEvents.RemoveAllCommandBuffers();
    if (m_State.m_TargetTexture)
        m_State.m_TargetTexture->Release();
    CleanupAfterRendering(NULL);

    // Destroy the LOD data stored in LODGroupManager for this camera
    dynamic_array<LODGroupManager*> lodGroupManagers(kMemTempAlloc);
    LODGroupManager::CollectAllLODGroupManagers(this, lodGroupManagers);
    for (size_t i = 0; i < lodGroupManagers.size(); ++i)
    {
        if (lodGroupManagers[i] != NULL)
            lodGroupManagers[i]->DestroyCameraLODData(this);
    }

    for (size_t i = 0, n = s_AllCamera.size(); i < n; ++i)
    {
        if (s_AllCamera[i] == this)
        {
            s_AllCamera.erase_swap_back(s_AllCamera.begin() + i);
            break;
        }
    }

    Super::MainThreadCleanup();
}

void Camera::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);
    if ((awakeMode & kDidLoadFromDisk) == 0 && IsAddedToManager())
    {
        GetRenderManager().RemoveCamera(this);
        GetRenderManager().AddCamera(this);
    }

    // Normally MonoBehaviour::AddToManager()/RemoveFromManager() handles the image effect callbacks.
    // However, if camera is instantiated/created from a script we need to add callbacks for
    // possible components that have been enabled & added to manager before the camera.
    if ((awakeMode & kInstantiateOrCreateFromCodeAwakeFromLoad))
    {
        GameObject& gameObject = GetGameObject();
        for (int i = 0; i < gameObject.GetComponentCount(); i++)
        {
            if (gameObject.GetComponentTypeAtIndex(i)->IsDerivedFrom<MonoBehaviour>())
            {
                MonoBehaviour& behaviour = static_cast<MonoBehaviour&>(gameObject.GetComponentAtIndex(i));
                if (behaviour.GetEnabled() && behaviour.IsAddedToManager())
                    behaviour.AddImageEffectCallbacksToManagers();
            }
        }
    }

    if (GetIVRDevice() && GetStereoEnabled())
        GetIVRDevice()->InsertCameraReferenceTransform(*this);

    m_State.m_DirtyWorldToCameraMatrix = m_State.m_DirtyProjectionMatrix = m_State.m_DirtyWorldToClipMatrix = m_State.m_DirtySkyboxProjectionMatrix = true;
    WindowSizeHasChanged();
}

void Camera::ClearIntermediateRenderers(size_t startIndex)
{
    m_IntermediateRenderers->Clear(startIndex);
}

void Camera::AddToManager()
{
    GetRenderManager().AddCamera(this);
    WindowSizeHasChanged();
    m_State.m_LastPosition = GetComponent<Transform>().GetPosition();
    m_State.m_Velocity.SetZero();
    UpdatePreviousViewProjectionMatrix();
}

void Camera::TransformChanged()
{
    m_State.m_DirtyWorldToCameraMatrix = true;
    m_State.m_DirtyWorldToClipMatrix = true;
}

void Camera::RemoveFromManager()
{
    // Clear IntermediateRenderers such that if the camera is disabled before rendering occurs we dont introduce a leak (case 819470)
    ClearIntermediateRenderers();
    GetRenderManager().RemoveCamera(this);
}

template<class TransferFunction>
void Camera::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);

    // Note: transfer code for version 1 was just removed. It was around Unity 1.2 times,
    // and now we're fine with losing project folder compatibility with that.
    transfer.SetVersion(2);

#define TRANSFER_STATE(x) transfer.Transfer (m_State.x, #x)

    TRANSFER_STATE(m_ClearFlags);
    TRANSFER_STATE(m_BackGroundColor);

    TRANSFER_STATE(m_NormalizedViewPortRect);
    transfer.Transfer(m_State.m_NearClip, "near clip plane");
    transfer.Transfer(m_State.m_FarClip, "far clip plane");
    transfer.Transfer(m_State.m_FieldOfView, "field of view");
    transfer.Transfer(m_State.m_Orthographic, "orthographic");
    transfer.Align();
    transfer.Transfer(m_State.m_OrthographicSize, "orthographic size");

    TRANSFER_STATE(m_Depth);
    TRANSFER_STATE(m_CullingMask);
    TRANSFER_STATE(m_RenderingPath);

    TRANSFER_STATE(m_TargetTexture);
    TRANSFER_STATE(m_TargetDisplay);    // Aligned
    TRANSFER_ENUM_WITH_NAME(m_State.m_TargetEye, "m_TargetEye");
    transfer.Transfer(m_State.m_AllowHDR, "m_HDR");
    TRANSFER_STATE(m_AllowMSAA);
    TRANSFER_STATE(m_ForceIntoRT);
    TRANSFER_STATE(m_OcclusionCulling);
    transfer.Align();
    TRANSFER_STATE(m_StereoConvergence);
    TRANSFER_STATE(m_StereoSeparation);
    TRANSFER_STATE(m_StereoMirrorMode);

#undef TRANSFER_STATE
}

// Returns true if this is a non-standard (e.g. off-center) projection.
static bool IsNonStandardProjection(const Matrix4x4f& mat)
{
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (i != j && mat.Get(i, j) != 0.0f)
                return true;
    return false;
}

// Returns true if this an "oblique clipping" projection, e.g. as used
// for water reflections to clip along the water surface.
static bool IsObliqueProjection(const Matrix4x4f& mat)
{
    // If third row's x or y aren't zero this is an oblique clipping
    // matrix. See "Oblique Near-Plane Clipping With Orthographic Camera"
    // for example http://aras-p.info/texts/obliqueortho.html
    if (mat.Get(2, 0) != 0)
        return true;
    if (mat.Get(2, 1) != 0)
        return true;
    return false;
}

static inline Rectf GetCameraTargetRect(const Camera& camera, bool zeroOrigin, bool isRenderingStereo)
{
    RenderTexture* target = camera.GetTargetTexture();
    if (target != NULL)
        return Rectf(0, 0, target->GetWidth(), target->GetHeight());

    RenderSurfaceHandle colorTarget = camera.GetTargetColorBuffer();
    if (colorTarget.IsValid() && !colorTarget.object->backBuffer)
        return Rectf(0, 0, colorTarget.object->width, colorTarget.object->height);

    if (isRenderingStereo)
    {
        IVRDevice* vrDevice = GetIVRDevice();
        if ((vrDevice != NULL) && vrDevice->GetActive())
        {
            int width = vrDevice->GetEyeTextureWidth();
            int height = vrDevice->GetEyeTextureHeight();
            return Rectf(0, 0, width, height);
        }
    }

#if UNITY_IPHONE || UNITY_TVOS
    // on ios display RS are marked as backbuffer, but have totally valid info
    if (colorTarget.IsValid())
        return Rectf(0, 0, colorTarget.object->width, colorTarget.object->height);
#endif

#if SUPPORT_MULTIPLE_DISPLAYS
    // If targeting an External/Secondary display get target coordinates.
    UInt32 targetDisplay = camera.GetTargetDisplay();
    const DisplayDevice* device = UnityDisplayManager_GetDisplayDeviceAt(targetDisplay);

    // Treat both screens the same (as main) on Wii U
    if ((targetDisplay != 0 || UNITY_WIIU) && device)
        return Rectf(0, 0, device->width, device->height);
#endif

    // Primary Monitor/Display held by Screen Manager
    Rectf rect = GetScreenManager().GetRect();

#if UNITY_EDITOR
    // In the editor, if we're trying to get rect of a regular camera (visible in hierarchy etc.),
    // use game view size instead of "whatever editor window was processed last" size.
    // Otherwise Camera.main.aspect would return aspect of inspector when repainting it, for example.
    //
    // Only do this for regular cameras however; keep hidden cameras (scene view, material preview etc.)
    // using the old behavior.
    GameObject* go = camera.GetGameObjectPtr();
    if (go && (go->GetHideFlags() & Object::kHideInHierarchy) != Object::kHideInHierarchy)
    {
        // If the current guiview is a GameView then GetScreenManager().GetRect() is already set up correctly and
        // we do not need to find first available game view to get a valid rect. Fix for case 517158
        bool isCurrentGUIViewAGameView = GUIView::GetCurrent() != NULL && GUIView::GetCurrent()->IsGameView();
        if (!isCurrentGUIViewAGameView)
        {
            Vector2f mainGameViewSize = GUIView::GetMainGameViewSize();
            rect = Rectf(0.0f, 0.0f, mainGameViewSize.x, mainGameViewSize.y);
        }
    }
#endif

    if (zeroOrigin)
        rect.x = rect.y = 0.0f;
    return rect;
}

Rectf Camera::GetCameraRect(bool zeroOrigin) const
{
    // Get the screen rect from either the target texture or the viewport we're inside
    Rectf screenRect = GetCameraTargetRect(*this, zeroOrigin, GetStereoEnabled());

    // Now figure out how large this camera is depending on the normalized viewRect.
    Rectf viewRect = m_State.m_NormalizedViewPortRect;
    viewRect.Scale(screenRect.width, screenRect.height);
    viewRect.Move(screenRect.x, screenRect.y);
    viewRect.Clamp(screenRect);
    return viewRect;
}

RectInt Camera::GetScreenViewportRectInt() const
{
    return RectfToRectInt(GetScreenViewportRect());
}

void Camera::SetScreenViewportRect(const Rectf& pixelRect)
{
    // Get the screen rect from either the target texture or the viewport we're inside
    // Use zero base the screen rect; all game code assumes that the visible viewport starts at zero.
    Rectf screenRect = GetCameraTargetRect(*this, true, GetStereoEnabled());

    // Now translate from pixel to viewport space
    Rectf viewRect = pixelRect;
    viewRect.Move(-screenRect.x, -screenRect.y);
    if (screenRect.width > 0.0f &&  screenRect.height > 0.0f)
        viewRect.Scale(1.0F / screenRect.width, 1.0F / screenRect.height);
    else
        viewRect.Reset();
    SetNormalizedViewportRect(viewRect);
}

static void InitShaderReplaceData(Shader* replacementShader, const core::string& shaderReplaceTag, ShaderReplaceData& output)
{
    // Shader replacement might be passed explicitly (camera.RenderWithShader) OR shader replacement can be setup as camera's state (camera.SetReplacementShader)
    if (replacementShader != NULL)
    {
        output.replacementShader = replacementShader;
        output.replacementTagID = shadertag::GetShaderTagID(shaderReplaceTag);
    }
    else
    {
        Assert(output.replacementShader == NULL);
    }
}

bool Camera::IsValidToRender() const
{
    if (m_State.m_NormalizedViewPortRect.IsEmpty())
        return false;
    if (m_State.m_NormalizedViewPortRect.x >= 1.0F || m_State.m_NormalizedViewPortRect.GetRight() <= 0.0F)
        return false;
    if (m_State.m_NormalizedViewPortRect.y >= 1.0F || m_State.m_NormalizedViewPortRect.GetBottom() <= 0.0F)
        return false;

    if (m_State.m_FarClip <= m_State.m_NearClip)
        return false;
    if (!m_State.m_Orthographic)
    {
        if (m_State.m_NearClip <= 0.0f)
            return false; // perspective camera needs positive near plane
        if (Abs(m_State.m_FieldOfView) < 1.0e-6f)
            return false; // field of view has to be non zero
    }
    else
    {
        if (Abs(m_State.m_OrthographicSize) < 1.0e-6f)
            return false; // orthographic size has to be non zero
    }
    return true;
}

void Camera::SetupRender(ShaderPassContext& passContext, RenderFlag renderFlags)
{
    SetupRender(passContext, ExtractCameraRenderingParams(), renderFlags);
}

bool Camera::CalculateUsingHDR() const
{
    return m_CurrentTargetTexture != NULL //backbuffer
        && IsHDRRTFormat(m_CurrentTargetTexture->GetColorFormat());
}

void Camera::SetupRender(ShaderPassContext& passContext, const CameraRenderingParams& params, RenderFlag renderFlags)
{
    GfxDevice& device = GetGfxDevice();

    SetActiveVRUsage();

    // Cache whether we use HDR for rendering.
    m_State.m_UsingHDR = CalculateUsingHDR();
    if (m_State.m_UsingHDR)
        passContext.keywords.Enable(keywords::kHDROn);
    else
        passContext.keywords.Disable(keywords::kHDROn);


    if (renderFlags & kRenderFlagSetRenderTarget)
        SetRenderTargetAndViewport();

    GraphicsHelper::SetWorldViewAndProjection(device, NULL, &params.matView, &params.matProj);
    SetCameraShaderProps(passContext, params);

    // Setup billboard rendering.
    BillboardBatchManager::SetBillboardShaderProps(
        passContext.keywords,
        device.GetBuiltinParamValues(),
        GetQualitySettings().GetCurrent().billboardsFaceCameraPosition,
        params.matView,
        params.worldPosition);


    GetRenderBufferManager().SetActiveVRUsage(kVRTextureUsageNone);
}

CameraRenderingParams Camera::ExtractCameraRenderingParams() const
{
    CameraRenderingParams params;
    params.matView = GetWorldToCameraMatrix();
    params.matProj = GetProjectionMatrix();
    params.worldPosition = GetCameraToWorldMatrix().GetPosition();
    return params;
}

void Camera::CalculateMatrixShaderProps(const Matrix4x4f& inView, Matrix4x4f& outWorldToCamera, Matrix4x4f& outCameraToWorld)
{
    // World to camera matrix
    outWorldToCamera.SetScale(Vector3f(1, 1, -1));
    outWorldToCamera *= inView;

    // Camera to world matrix
    InvertMatrix4x4_General3D(outWorldToCamera.GetPtr(), outCameraToWorld.GetPtr());
}

void Camera::SetCameraShaderProps(ShaderPassContext& passContext, const CameraRenderingParams& params)
{
    float overrideTime = -1.0f;
#   if UNITY_EDITOR
    if (m_State.m_AnimateMaterials)
        overrideTime = m_State.m_AnimateMaterialsTime;
#   endif // if UNITY_EDITOR
    ShaderLab::UpdateGlobalShaderProperties(overrideTime);

    GfxDevice& device = GetGfxDevice();
    BuiltinShaderParamValues& shaderParams = device.GetBuiltinParamValues();

    shaderParams.SetVectorParam(kShaderVecWorldSpaceCameraPos, Vector4f(params.worldPosition, 0.0f));

    Matrix4x4f worldToCamera;
    Matrix4x4f cameraToWorld;
    CalculateMatrixShaderProps(params.matView, worldToCamera, cameraToWorld);
    shaderParams.SetMatrixParam(kShaderMatWorldToCamera, worldToCamera);
    shaderParams.SetMatrixParam(kShaderMatCameraToWorld, cameraToWorld);

    // Get the matrix to use for cubemap reflections.
    // It's camera to world matrix; rotation only, and mirrored on Y.
    worldToCamera.SetPosition(Vector3f::zero);  // clear translation
    Matrix4x4f invertY;
    invertY.SetScale(Vector3f(1, -1, 1));
    Matrix4x4f reflMat;
    MultiplyMatrices4x4(&worldToCamera, &invertY, &reflMat);
    passContext.properties.SetMatrix(kSLPropReflection, reflMat);

    // Camera clipping planes
    SetClippingPlaneShaderProps();

    const float projNear = GetProjectionNear();
    const float projFar = GetProjectionFar();
    const float invNear = (projNear == 0.0f) ? 1.0f : 1.0f / projNear;
    const float invFar = (projFar == 0.0f) ? 1.0f : 1.0f / projFar;
    shaderParams.SetVectorParam(kShaderVecProjectionParams, Vector4f(device.GetInvertProjectionMatrix() ? -1.0f : 1.0f, projNear, projFar, invFar));

    Rectf view = GetScreenViewportRect();
    shaderParams.SetVectorParam(kShaderVecScreenParams, Vector4f(view.width, view.height, 1.0f + 1.0f / view.width, 1.0f + 1.0f / view.height));

    // From http://www.humus.name/temp/Linearize%20depth.txt
    // But as depth component textures on OpenGL always return in 0..1 range (as in D3D), we have to use
    // the same constants for both D3D and OpenGL here.
    double zc0, zc1;
    // OpenGL would be this:
    // zc0 = (1.0 - projFar / projNear) / 2.0;
    // zc1 = (1.0 + projFar / projNear) / 2.0;
    // D3D is this:
    zc0 = 1.0 - projFar * invNear;
    zc1 = projFar * invNear;

    Vector4f v = Vector4f(zc0, zc1, zc0 * invFar, zc1 * invFar);
    if (GetGraphicsCaps().usesReverseZ)
    {
        v.y += v.x;
        v.x = -v.x;
        v.w += v.z;
        v.z = -v.z;
    }
    shaderParams.SetVectorParam(kShaderVecZBufferParams, v);

    // Ortho params
    Vector4f orthoParams;
    const bool isPerspective = params.matProj.IsPerspective();
    orthoParams.x = m_State.m_OrthographicSize * m_State.m_Aspect;
    orthoParams.y = m_State.m_OrthographicSize;
    orthoParams.z = 0.0f;
    orthoParams.w = isPerspective ? 0.0f : 1.0f;
    shaderParams.SetVectorParam(kShaderVecOrthoParams, orthoParams);

    // Camera projection matrices
    Matrix4x4f invProjMatrix;
    InvertMatrix4x4_Full(params.matProj.GetPtr(), invProjMatrix.GetPtr());
    shaderParams.SetMatrixParam(kShaderMatCameraProjection, params.matProj);
    shaderParams.SetMatrixParam(kShaderMatCameraInvProjection, invProjMatrix);

#if GFX_SUPPORTS_SINGLE_PASS_STEREO
    // Set stereo matrices to make shaders with UNITY_SINGLE_PASS_STEREO enabled work in mono
    // View and projection are handled by the device
    device.SetStereoMatrix(kMonoOrStereoscopicEyeMono, kShaderMatCameraInvProjection, invProjMatrix);
    device.SetStereoMatrix(kMonoOrStereoscopicEyeMono, kShaderMatWorldToCamera, worldToCamera);
    device.SetStereoMatrix(kMonoOrStereoscopicEyeMono, kShaderMatCameraToWorld, cameraToWorld);
#endif
}

static const ColorRGBAf ConvertColorToActiveColorSpace(const ColorRGBAf& color)
{
    return GammaToActiveColorSpace(color);
}

static void ClearFramebuffer(GfxClearFlags gfxClearFlags, Rectf rect, ColorRGBAf const& color)
{
    PROFILER_AUTO_GFX(gCameraClearProfile, NULL);
    const float depth = 1.0f;
    const int stencil = 0;

    GfxDevice& device = GetGfxDevice();
    ShaderPassContext& passContext = GetDefaultPassContext();

    // If we're rendering into a temporary texture, we always have (0,0) in the bottom-left corner
    // No matter what the view coords say.

#if GFX_SUPPORTS_SINGLE_PASS_STEREO
    SinglePassStereo singlePassStereo = device.GetSinglePassStereo();

    if (singlePassStereo != kSinglePassStereoNone)
    {
        RectInt scissorRects[kStereoscopicEyeCount];
        const unsigned  rtw = std::max<unsigned>(device.GetActiveRenderSurfaceWidth(), 1);
        const unsigned  rth = std::max<unsigned>(device.GetActiveRenderSurfaceHeight(), 1);

        bool isStereoSideBySide = (singlePassStereo == kSinglePassStereoSideBySide);
        const int halfRenderTargetWidth = RoundfToInt(rtw * 0.5f);
        const int scissorRectWidth = isStereoSideBySide ? halfRenderTargetWidth : rtw;
        const int xOffset = isStereoSideBySide ? halfRenderTargetWidth : 0;

        for (int eye = 0; eye < kStereoscopicEyeCount; ++eye)
        {
            scissorRects[eye].width = scissorRectWidth;
            scissorRects[eye].height = rth;
            scissorRects[eye].x = eye * xOffset;
            scissorRects[eye].y = 0;
        }

        device.SetStereoScissorRects(scissorRects);
    }
    else
#endif // GFX_SUPPORTS_SINGLE_PASS_STEREO
    {
        // TODO: Take RectInt argument instead of converting from float
        if (GetIVRDevice())
            rect.SetPosition(Vector2f::zero);
        RectInt scissorRect = RectfToRectInt(rect);
        device.SetScissorRect(scissorRect);
    }


    // seems like the best place to time clear
    TimeFormat clearStart = GetProfilerTime();

    GraphicsHelper::Clear(gfxClearFlags, color, depth, stencil, passContext);
    GPU_TIMESTAMP();
    GetGfxDevice().GetFrameStats().AddClear(ELAPSED_TIME(clearStart));

    device.DisableScissor();
}

static void ClearFramebuffer(Camera::ClearMode clearMode, Rectf rect, ColorRGBAf const& color, bool hasSkybox, bool noDepth = false)
{
    UInt32 gfxClearFlags        = kGfxClearAll;
    GfxClearFlags skyboxClearFlags  = GetGraphicsCaps().hasTiledGPU ? kGfxClearAll : kGfxClearDepthStencil;
    switch (clearMode)
    {
        case Camera::kDontClear:
            return;
        case Camera::kDepthOnly:
            gfxClearFlags = kGfxClearDepthStencil;
            break;
        case Camera::kSolidColor:
            gfxClearFlags = kGfxClearAll;
            break;
        case Camera::kSkybox:
            gfxClearFlags = hasSkybox ? skyboxClearFlags : kGfxClearAll;
            break;
    }

    if (noDepth)
        gfxClearFlags &= ~kGfxClearDepthStencil;

    ClearFramebuffer(static_cast<GfxClearFlags>(gfxClearFlags), rect, color);
}

void Camera::Clear()
{
    //Do not need to convert background color to correct space as this is done in gamma space always.
    ClearFramebuffer(GetClearFlags(), GetRenderRectangle(), m_State.m_BackGroundColor, GetSkyboxMaterial() != NULL);
    RenderSkybox();
}

void Camera::ClearNoSkybox(bool noDepth)
{
    const bool hasSkybox = GetSkyboxMaterial() != NULL;
    const Camera::ClearMode clearMode = GetClearFlags();
    const ColorRGBAf clearColor = hasSkybox && clearMode == Camera::kSkybox ? ColorRGBAf(0, 0, 0, 0) : ConvertColorToActiveColorSpace(m_State.m_BackGroundColor);
    ClearFramebuffer(GetClearFlags(), GetRenderRectangle(), clearColor, hasSkybox, noDepth);
}

void Camera::AddRenderPlaneCallback(const RenderPlaneCallback cb, void* const userData, RenderPlane plane)
{
    if (cb == 0)
    {
        return;
    }

    const RenderPlaneCallbacks::value_type itemToAdd = {cb, userData, plane};
    const RenderPlaneCallbacks::iterator end = m_RenderPlaneCallbacks.end();
    if (std::find(m_RenderPlaneCallbacks.begin(), end, itemToAdd) == end)
        m_RenderPlaneCallbacks.push_back() = itemToAdd;
}

void Camera::RemoveRenderPlaneCallback(const RenderPlaneCallback cb, void* const userData, RenderPlane plane)
{
    const RenderPlaneCallbacks::value_type itemToRemove = {cb, userData, plane};
    const RenderPlaneCallbacks::iterator end = m_RenderPlaneCallbacks.end();
    const RenderPlaneCallbacks::iterator it = std::find(m_RenderPlaneCallbacks.begin(), end, itemToRemove);
    if (it != end)
        m_RenderPlaneCallbacks.erase(it);
}

void Camera::RenderSkybox()
{
    if (m_State.m_ClearFlags != kSkybox)
        return;

    Material* skybox = GetSkyboxMaterial();
    if (!skybox)
        return;
    RenderNodeQueue nodeQueue(kMemTempAlloc);
    ShaderPassContext& passContext = GetDefaultPassContext();
    InvokeRenderEventCB(kRenderEvent_BeforeSkybox, passContext, nodeQueue);
    Skybox::RenderSkybox(skybox, *this);
    InvokeRenderEventCB(kRenderEvent_AfterSkybox, passContext, nodeQueue);
}

Material *Camera::GetSkyboxMaterial() const
{
    Skybox *sb = QueryComponent<Skybox>();
    if (sb && sb->GetEnabled() && sb->GetMaterial())
        return sb->GetMaterial();
    else
        return GetRenderSettings().GetSkyboxMaterial();
}

Rectf Camera::GetRenderRectangle() const
{
    // when we setup camera thats how we determine m_CurrentTargetTexture:
    // 1. image filters customize if needed
    // 2. target RenderTexture otherwise
    // 3. we call Camera::ApplyRenderTexture where we handle case of targeting RenderBuffers
    // we want special processing ONLY in case of image filters tweaking it
    bool useRenderTargetSize = false;

    if (m_CurrentTargetTexture)
    {
        const bool renderToTargetRB = m_CurrentTargetTexture == m_State.m_TargetBuffersOriginatedFrom[0];
        const bool renderToTargetRT = m_CurrentTargetTexture == (RenderTexture*)m_State.m_TargetTexture;
        const bool isStereoTexture = m_CurrentTargetTexture->GetVRUsage() != kVRTextureUsageNone;
        const bool currentlyRenderingInStereo = isStereoTexture && m_IsRenderingStereo;

        if (!currentlyRenderingInStereo && !renderToTargetRB && !renderToTargetRT)
            useRenderTargetSize = true;
    }

    if (useRenderTargetSize)
        return Rectf(0, 0, m_CurrentTargetTexture->GetWidth(), m_CurrentTargetTexture->GetHeight());

    return GetPhysicalViewportRect();
}

void Camera::CalculateFrustumPlanes(Plane frustum[kPlaneFrustumNum], const Matrix4x4f& overrideWorldToClip, float overrideFarPlane, float& outBaseFarDistance, bool implicitNearFar) const
{
    ExtractProjectionPlanes(overrideWorldToClip, frustum);

    Plane& nearPlane = frustum[kPlaneFrustumNear];
    Plane& farPlane = frustum[kPlaneFrustumFar];

    if (IsImplicitWorldToCameraMatrix() || implicitNearFar)
    {
        // Extracted near and far planes may be unsuitable for culling.
        // E.g. oblique near plane for water refraction busts both planes.
        // Also very large far/near ratio causes precision problems.
        // Instead we calculate the planes from our position/direction.

        Matrix4x4f cam2world = GetCameraToWorldMatrix();
        Vector3f eyePos = cam2world.GetPosition();
        Vector3f viewDir = -NormalizeSafe(cam2world.GetAxisZ());

        nearPlane.SetNormalAndPosition(viewDir, eyePos);
        nearPlane.distance -= m_State.m_NearClip;

        farPlane.SetNormalAndPosition(-viewDir, eyePos);
        outBaseFarDistance = farPlane.distance;
        farPlane.distance += overrideFarPlane;
    }
    else
        outBaseFarDistance = farPlane.distance - overrideFarPlane;
}

void Camera::CalculateCullingParameters(CullingParameters& cullingParameters) const
{
    Plane frustum[kPlaneFrustumNum];
    float baseFarDistance;

    Matrix4x4f cullingMatrix = GetCullingMatrix();
    cullingParameters.cullingMatrix = cullingMatrix;
    cullingParameters.position = GetPosition();

    CalculateFrustumPlanes(frustum, cullingMatrix, m_State.m_FarClip, baseFarDistance, false);

    LODParameters lodParams;
    lodParams.cameraPosition = GetPosition();
    lodParams.fieldOfView = GetFov();
    lodParams.isOrthographic = GetOrthographic();
    lodParams.orthoSize = m_State.m_OrthographicSize;
    lodParams.cameraPixelHeight = int(GetPhysicalViewportRect().height);
    CalculateCustomCullingParameters(cullingParameters, lodParams, GetCullingMask(), frustum, kPlaneFrustumNum);

    if (m_State.m_LayerCullSpherical)
    {
        std::copy(m_State.m_LayerCullDistances, m_State.m_LayerCullDistances + kNumLayers, cullingParameters.layerFarCullDistances);
        cullingParameters.layerCull = CullingParameters::kLayerCullSpherical;
    }
    else
    {
        CalculateFarCullDistances(cullingParameters.layerFarCullDistances, baseFarDistance);
        cullingParameters.layerCull = CullingParameters::kLayerCullPlanar;
    }
}

void Camera::StandaloneCull(Shader* replacementShader, const core::string& replacementTag, CullResults& results)
{
    CameraCullingParameters parameters(*this, kCullFlagNeedsLighting | kCullFlagForceEvenIfCameraIsNotActive);
    if (GetUseOcclusionCulling())
        parameters.cullFlag |= kCullFlagOcclusionCull;

    InitShaderReplaceData(replacementShader, replacementTag, parameters.explicitShaderReplace);

    CustomCull(parameters, results);
}

void Camera::Cull(CullResults& results, CullFlag cullFlags)
{
    CameraCullingParameters parameters(*this, kCullFlagNeedsLighting | cullFlags);
    if (GetUseOcclusionCulling())
        parameters.cullFlag |= kCullFlagOcclusionCull;

    CustomCull(parameters, results);
}

void Camera::PrepareCullingParameters(const CameraCullingParameters& parameters, RenderingPath renderPath, CullResults& results)
{
    const Umbra::Tome* tomeData = NULL;
    if ((parameters.cullFlag & kCullFlagOcclusionCull) != 0)
        tomeData = GetRendererScene().GetUmbraTome();

    SceneCullingParameters& sceneCullParameters = results.sceneCullParameters;

    results.Init(tomeData);

    parameters.cullingCamera->CalculateCullingParameters(sceneCullParameters);

    sceneCullParameters.sceneVisbilityForShadowCulling = &results.sceneCullingOutput;
    sceneCullParameters.umbraDebugRenderer = parameters.umbraDebugRenderer;
    sceneCullParameters.umbraDebugFlags = parameters.umbraDebugFlags;
    sceneCullParameters.umbraTome = tomeData;
    sceneCullParameters.umbraGateState = GetRendererScene().GetUmbraGateState();
#if UNITY_EDITOR
    sceneCullParameters.filterMode = (CullFiltering)parameters.cullingCamera->m_FilterMode;
#endif

    sceneCullParameters.cullLights = (parameters.cullFlag & kCullFlagNeedsLighting) != 0;
    sceneCullParameters.stereo = (parameters.cullFlag & kCullFlagStereo) != 0;

    sceneCullParameters.excludeLightmappedShadowCasters = GetLightmapSettings().GetShadowMaskMode() == kShadowMaskMode_Full;
    sceneCullParameters.renderPath = renderPath;

    // Store this to sceneCullingOutput as the status may change if Umbra culling fails
    results.sceneCullingOutput.useUmbraOcclusionCulling = tomeData != NULL;
}

void Camera::PrepareCullingParametersRendererArrays(const Camera& cullingCamera, CullResults& results)
{
    PROFILER_AUTO(gPrepareSceneCullingParameters, NULL);

    SceneCullingParameters& sceneCullParameters = results.sceneCullParameters;

    if (cullingCamera.GetRenderImmediateObjects())
    {
        const IntermediateRenderers& cameraIntermediate = cullingCamera.GetIntermediateRenderers();
        sceneCullParameters.renderers[kCameraIntermediate].bounds = cameraIntermediate.GetBoundingBoxes();
        sceneCullParameters.renderers[kCameraIntermediate].nodes = cameraIntermediate.GetSceneNodes();
        sceneCullParameters.renderers[kCameraIntermediate].rendererCount = cameraIntermediate.GetRendererCount();
    }
    else
    {
        sceneCullParameters.renderers[kStaticRenderers].bounds = GetRendererScene().GetStaticBoundingBoxes();
        sceneCullParameters.renderers[kStaticRenderers].nodes = GetRendererScene().GetStaticSceneNodes();
        sceneCullParameters.renderers[kStaticRenderers].rendererCount = GetRendererScene().GetStaticObjectCount();

        sceneCullParameters.renderers[kDynamicRenderer].bounds = GetRendererScene().GetDynamicBoundingBoxes();
        sceneCullParameters.renderers[kDynamicRenderer].nodes = GetRendererScene().GetDynamicSceneNodes();
        sceneCullParameters.renderers[kDynamicRenderer].rendererCount = GetRendererScene().GetDynamicObjectCount();

        const IntermediateRenderers& sceneIntermediate = GetRendererScene().GetIntermediateRenderers();
        sceneCullParameters.renderers[kSceneIntermediate].bounds = sceneIntermediate.GetBoundingBoxes();
        sceneCullParameters.renderers[kSceneIntermediate].nodes = sceneIntermediate.GetSceneNodes();
        sceneCullParameters.renderers[kSceneIntermediate].rendererCount = sceneIntermediate.GetRendererCount();

        const IntermediateRenderers& cameraIntermediate = cullingCamera.GetIntermediateRenderers();
        sceneCullParameters.renderers[kCameraIntermediate].bounds = cameraIntermediate.GetBoundingBoxes();
        sceneCullParameters.renderers[kCameraIntermediate].nodes = cameraIntermediate.GetSceneNodes();
        sceneCullParameters.renderers[kCameraIntermediate].rendererCount = cameraIntermediate.GetRendererCount();

#if ENABLE_TERRAIN
        ITerrainManager* terrainManager = GetITerrainManager();
        if (terrainManager != NULL)
            terrainManager->CollectTreeRenderers(&cullingCamera, results.treeSceneNodes, results.treeBoundingBoxes);
        sceneCullParameters.renderers[kTreeRenderer].bounds = results.treeBoundingBoxes.data();
        sceneCullParameters.renderers[kTreeRenderer].nodes = results.treeSceneNodes.data();
        sceneCullParameters.renderers[kTreeRenderer].rendererCount = results.treeBoundingBoxes.size();
#endif
    }

    // Prepare cull results and allocate all culling memory
    results.InitDynamic(sceneCullParameters.renderers);

    PrepareLODCullingData(results, &cullingCamera);
}

void Camera::PrepareLODCullingData(CullResults& results, const Camera* cullingCamera)
{
    // Collect LODGroups
    dynamic_array<LODGroupManager*> lodGroupManagers(kMemTempAlloc);
    LODGroupManager::CollectAllLODGroupManagers(cullingCamera, lodGroupManagers, cullingCamera->GetRenderImmediateObjects());

    results.lodDataArrays.resize_uninitialized(lodGroupManagers.size());

    float deltaTime;
#if UNITY_EDITOR
    if (!IsWorldPlaying())
        deltaTime = 1.0f / 30.0f; // assume 30fps in editor
    else
#endif
    deltaTime = GetTimeManager().GetDeltaTime();

    for (size_t i = 0; i < lodGroupManagers.size(); ++i)
    {
        if (lodGroupManagers[i] == NULL)
        {
            results.lodDataArrays[i].count = 0;
            results.lodDataArrays[i].masks = NULL;
            results.lodDataArrays[i].fades = NULL;
            continue;
        }

        LODGroupManager& lodGroupManager = *lodGroupManagers[i];
        Assert(lodGroupManager.GetID() == i);
        results.lodDataArrays[i] = lodGroupManager.CalculateLODDataArray(results.sceneCullParameters.lodParams, cullingCamera, deltaTime);
        lodGroupManager.GarbageCollectCameraLODData();
    }

    results.sceneCullParameters.lodDataArrays = results.lodDataArrays.data();
}

static void CallStaticMethodTakingCamera(ScriptingMethodPtr method, Camera* camera)
{
    ScriptingInvocation invocation(method);
    invocation.AddObject(Scripting::ScriptingWrapperFor(camera));
    invocation.Invoke();
}

void Camera::CustomCull(const CameraCullingParameters& parameters, CullResults& results)
{
    Assert(results.sceneCullingOutput.umbraVisibility == NULL);

    PROFILER_AUTO(gCameraCullProfile, this)

    // Protect against culling being triggered recursively.  Most often happens
    // in response to the OnWillRender() message we send out as part of culling.
    if (m_IsCulling)
    {
        ErrorStringObject("Recursive culling with the same camera is not possible.", this);
        return;
    }

    // if camera's viewport rect is empty or invalid, do nothing
    if (!IsValidToRender())
    {
        return;
    }

    RenderManager& renderMgr = GetRenderManager();
    Camera* currentCamera = renderMgr.GetCurrentCameraPtr();
    CameraStackRenderingState* currentCameraStack = renderMgr.GetCurrentCameraStackStatePtr();

    // Send OnPreCull messages
    SendMessage(kPreCull);
    if (GetMonoManagerPtr()) // might not be there (e.g. unit tests)
    {
        CallStaticMethodTakingCamera(GetCoreScriptingClasses().fireOnPreCull, this);
    }


    // OnPreCull message might disable the camera!
    // So we check one last time.
    bool enabledAndActive = IsActive() && GetEnabled();
    if (!enabledAndActive && (parameters.cullFlag & kCullFlagForceEvenIfCameraIsNotActive) == 0)
        return;

    // OnPrecull message might disable and enable camera right after. [Case 876867]
    // In this case we need to save and restore rendermanager's current camera and stack.
    if (renderMgr.GetCurrentCameraPtr() != currentCamera)
    {
        renderMgr.SetCurrentCameraAndStackState(currentCamera, currentCameraStack);
    }

    m_IsCulling = true;

    const bool performSceneCulling = !GetRenderImmediateObjects();

    // Generate culling parameters &
    // Calculate parameters after OnPreCull (case 401765)
    // In case the user moves the camera in OnPreCull
    PrepareCullingParameters(parameters, CalculateRenderingPath(), results);

#if ENABLE_TERRAIN
    ITerrainManager* terrainManager = GetITerrainManager();
    if (terrainManager != NULL && performSceneCulling && results.sceneCullParameters.cullingMask != 0)
        terrainManager->CullAllTerrains(parameters.cullingCamera, results.sceneCullParameters);
#endif

    // kick off static occlusion culling
    if (performSceneCulling && results.sceneCullingOutput.useUmbraOcclusionCulling)
        CullStaticSceneWithUmbra(results.occlusionBufferIsReady, results.sceneCullParameters, results.sceneCullingOutput);

    // Perform culling group culling (depends on occlusion culling job)
    if (performSceneCulling)
    {
        CullingGroupManager::Get().CullAndSendEvents(results.sceneCullParameters, parameters.cullingCamera, results.sceneCullingOutput, results.occlusionBufferIsReady);
    }

    // Make sure that any moved or dirty renderers are up to date before culling
    GetRendererUpdateManager().UpdateAll(GetRendererScene());

    // Extract renderer data pointers
    PrepareCullingParametersRendererArrays(*parameters.cullingCamera, results);

    // Setup shader replacement
    if (parameters.explicitShaderReplace.replacementShader != NULL)
        results.shaderReplaceData = parameters.explicitShaderReplace;
    else
        InitShaderReplaceData(m_State.m_ReplacementShader, m_State.m_ReplacementTag, results.shaderReplaceData);

    // Prepare light culling information
    if (results.sceneCullParameters.cullLights)
    {
        ShadowProjection shadowProjection = (ShadowProjection)GetQualitySettings().GetCurrent().shadowProjection;

        ////@TODO: tons of data being extracted from cullingCamera directly here...
        // Should go through parameters struct...
        ShadowCullData& shadowCullData = *UNITY_NEW(ShadowCullData, kMemTempJobAlloc);
        SetupShadowCullData(*parameters.cullingCamera, results.shaderReplaceData, &results.sceneCullParameters, CalculateShadowDistance(), shadowProjection, shadowCullData);

        results.shadowCullData = &shadowCullData;
    }

    // Cull
    if (performSceneCulling)
        CullScene(results.sceneCullParameters, this, results);
    else
        CullIntermediateRenderersOnly(results.sceneCullParameters, results);

    results.isValid = true;

    m_IsCulling = false;
}

void Camera::CalculateFarCullDistances(float* farCullDistances, float baseFarDistance) const
{
    // baseFarDistance is the distance of the far plane shifted to the camera position
    // This is so layer distances work properly even if the far distance is very large
    for (int i = 0; i < kNumLayers; i++)
    {
        if (m_State.m_LayerCullDistances[i])
            farCullDistances[i] = baseFarDistance + m_State.m_LayerCullDistances[i];
        else
            farCullDistances[i] = baseFarDistance + m_State.m_FarClip;
    }
}

void Camera::SetDepthTextureMode(UInt32 mode)
{
    if (mode & kMotionVectorBit)
    {
        if (!(mode & kDepthTexDepthBit))
        {
            WarningStringObject("Motion vectors require depth texture. Adding this flag to depthTexureMode", this);
            mode |= kDepthTexDepthBit;
        }
    }
    m_State.m_DepthTextureMode = mode;
}

bool Camera::GetStereoEnabled() const
{
    __FAKEABLE_METHOD__(Camera, GetStereoEnabled, ());
    bool vrSupported = GetIVRDevice() && GetIVRDevice()->GetActive();
    vrSupported = vrSupported && (m_State.m_TargetEye != kTargetEyeMaskNone);
    return (GetCameraType() == kCameraTypeVR || GetTargetTexture() == NULL || m_IsRenderingStereo) &&
        (GetScreenManager().IsStereoscopic() || vrSupported);
}

bool Camera::IsRenderingToDoubleWideTarget() const
{
    IVRDevice* vrDevice = GetIVRDevice();
    if (vrDevice)
    {
        TextureDimension dim = vrDevice->GetEyeTextureDimension();
        return GetStereoEnabled() && (GetPlayerSettings().GetStereoRenderingPath() == kStereoRenderingSinglePass) && (dim == kTexDim2D);
    }
    else
    {
        return false;
    }
}

bool Camera::GetStereoSingleCullEnabled() const
{
    // We can cull just once if we're using the view/proj supplied by VRDevice, and we're rendering to both eyes
    return (GetStereoEnabled() && (m_State.m_ImplicitStereoViewMatrices && m_State.m_ImplicitStereoProjectionMatrices && m_State.m_TargetEye == kTargetEyeMaskBoth)) || m_State.m_StereoMirrorMode;
}

SinglePassStereo Camera::GetSinglePassStereo() const
{
#if GFX_SUPPORTS_SINGLE_PASS_STEREO
    // We can render just once for both eyes if we can single cull and we support either instancing or multiview
    if (GetStereoEnabled() && GetStereoSingleCullEnabled() && GetIVRDevice()->IsSinglePassStereoAllowed())
    {
        switch (GetPlayerSettings().GetStereoRenderingPath())
        {
            case kStereoRenderingInstancing:
                return GetGraphicsCaps().hasRenderTargetArrayIndexFromAnyShader ? kSinglePassStereoInstancing : kSinglePassStereoNone;
            case kStereoRenderingSinglePass:
                return GetGraphicsCaps().singlePassStereo;
            case kStereoRenderingMultiPass:
                return kSinglePassStereoNone;
        }
    }
#endif
    return kSinglePassStereoNone;
}

float Camera::GetStereoSeparation() const
{
    if (m_State.m_ImplicitStereoViewMatrices && GetIVRDevice() && GetIVRDevice()->GetOverrideStereoSeparation())
    {
        return GetIVRDevice()->GetStereoSeparation();
    }
    return m_State.m_StereoSeparation;
}

void Camera::RenderHaloAndLensFlare(const CullResults* cullResults, ShaderPassContext& passContext, const Matrix4x4f& worldToCamera)
{
    // render halos
    GetHaloManager().RenderHalos(cullResults, passContext, worldToCamera);

    // render flares
    FlareLayer* flareLayer = QueryComponent<FlareLayer>();
    if (flareLayer && flareLayer->GetEnabled())
    {
        GetFlareManager().RenderFlares(worldToCamera);
    }
}

void Camera::DoRenderPostLayers(const CullResults* cullResults, ShaderPassContext& passContext, RenderFlag renderFlags)
{
#if GFX_SUPPORTS_SINGLE_PASS_STEREO
    if (HasAnyFlags(renderFlags, kRenderFlagSinglePassStereo | kRenderFlagInstancingStereo | kRenderFlagMultiviewStereo))
    {
        for (int iEye = 0; iEye < kStereoscopicEyeCount; ++iEye)
        {
            GetGfxDevice().SetSinglePassStereoEyeMask(TargetEyeMask(1 << iEye));
            const Matrix4x4f& worldToCamera = GetStereoViewMatrix((StereoscopicEye)iEye);
            RenderHaloAndLensFlare(cullResults, passContext, worldToCamera);
        }
        GetGfxDevice().SetSinglePassStereoEyeMask(kTargetEyeMaskBoth);
    }
    else
#endif // GFX_SUPPORTS_SINGLE_PASS_STEREO
    {
        RenderHaloAndLensFlare(cullResults, passContext, GetWorldToCameraMatrix());
    }

    GetRenderManager().InvokeOnRenderObjectCallbacks();
}

void Camera::DoRenderGUILayer(ShaderPassContext& passContext, RenderFlag renderFlags)
{
    GUILayer* guiLayer = QueryComponent<GUILayer>();
    if ((guiLayer == NULL) || !guiLayer->GetEnabled())
        return;

    PROFILER_AUTO_GFX(gGUILayerProfile, this);

#if GFX_SUPPORTS_SINGLE_PASS_STEREO
    if (HasAnyFlags(renderFlags, kRenderFlagSinglePassStereo | kRenderFlagInstancingStereo | kRenderFlagMultiviewStereo))
    {
        GfxDevice& device = GetGfxDevice();
        device.SetCopyMonoTransformsToStereo(true);
        RectInt leftViewport = device.GetStereoViewport(kStereoscopicEyeLeft);
        Rectf viewport(leftViewport.x, leftViewport.y, leftViewport.width, leftViewport.height);
        guiLayer->RenderGUILayer(viewport, GetCullingMask(), passContext);
        device.SetCopyMonoTransformsToStereo(false);
    }
    else
#endif // GFX_SUPPORTS_SINGLE_PASS_STEREO
    {
        guiLayer->RenderGUILayer(GetScreenViewportRect(), GetCullingMask(), passContext);
    }
}

void Camera::ResolveLastTargetToCurrentTarget() const
{
    RenderBufferManager& rbm = GetRenderBufferManager();

    RenderTexture* toResolve = GetTargetTexture();

    if (GetStereoEnabled())
    {
        toResolve = GetIVRDevice()->GetActiveEyeTexture(GetGfxDevice().GetStereoActiveEye());
    }

    RenderTexture* target = GetCurrentTargetTexture();

    // situation we can not resolve
    if (target == NULL || toResolve == target)
        return;

    RectInt rect = RectfToRectInt(GetScreenViewportRect());

    // If are not pulling from the BB we need to change where we are
    // sampling from on dx :)
    if (!GetGraphicsCaps().usesOpenGLTextureCoords && toResolve)
        rect = RectInt(rect.x, toResolve->GetHeight() - rect.y - rect.height, rect.width, rect.height);

    RenderTexture* extraTarget = target;

    bool needsExtraBlit = !toResolve || target->GetAntiAliasing() != toResolve->GetAntiAliasing();
    if (needsExtraBlit)
    {
        extraTarget = rbm.GetTempBuffer(
                rect.Width(),
                rect.Height(),
                kDepthFormatNone,
                extraTarget ? extraTarget->GetColorFormat() : kRTFormatDefault,
                0,
                kRTReadWriteDefault,
                kVRTextureUsageNone,
                toResolve ? toResolve->GetAntiAliasing() : 1);
        extraTarget->Create();
    }

    int minWidth = std::min(rect.width, extraTarget->GetGPUWidth());
    int minHeight = std::min(rect.height, extraTarget->GetGPUHeight());

    RenderTexture* oldActive = RenderTexture::GetActive();
    RenderTexture::SetActive(toResolve, 0, kCubeFaceUnknown, 0, RenderTexture::kFlagNone);
    extraTarget->GrabPixels(rect.x, rect.y, minWidth, minHeight);

    // need to invert this buffer due to the amazing
    // and fun differences between GL / dx sampler
    // coordinates.... so gross.
    // D3D and GL use different notions of how Y texture coordinates go.
    if (needsExtraBlit)
    {
        ShaderPassContext& passContext = GetDefaultPassContext();
        extraTarget->CorrectVerticalTexelSize(false);
        ImageFilters::Blit(passContext, extraTarget, GetCurrentTargetTexture(), 0);
        rbm.ReleaseTempBuffer(extraTarget);
    }

    // color is copied from toResolve but depth contains garbage.
    // clear it in case camera won't do it itself (case 907391).
    if (m_State.m_ClearFlags == kDontClear)
    {
        RenderTexture::SetActive(target, 0, kCubeFaceUnknown, 0, RenderTexture::kFlagNone);
        GetGfxDevice().Clear(kGfxClearDepthStencil, ColorRGBAf(0, 0, 0, 0), 1.0f, 0);
    }

    ImageFilters::SetSurfaceUseResolvedBuffer(oldActive, true);
    RenderTexture::SetActive(oldActive, 0, kCubeFaceUnknown, 0, RenderTexture::kFlagNone);
}

void Camera::PreMultiCustomRender(CullResults& cullResults, RenderFlag renderFlags, bool bSkipMarkers /*= false*/)
{
    Assert(IsValidToRender());

    if (!bSkipMarkers)
    {
        PROFILER_AUTO_GFX(gCameraDrawMultiCustomPreProfile, this);
    }
    // Calling code should setup current camera stack rendering state, and current camera
    AssertFormatMsg(GetRenderManager().GetCurrentCameraStackStatePtr(), "Rendering camera '%s', but calling code did not setup camera stack render state", GetName());
    AssertFormatMsg(GetCurrentCameraPtr() == this, "Rendering camera '%s', but calling code does not set it up as current camera (current camera: '%s')", GetName(), GetCurrentCameraPtr() ? GetCurrentCameraPtr()->GetName() : "<null>");

    InitializeRenderLoopContext(this, *cullResults.sharedRendererScene, m_RenderLoop);

    GfxDevice& device = GetGfxDevice();
    ShaderPassContext& passContext = GetDefaultPassContext();

    BeginSinglePassStereo(device, passContext, renderFlags);

    // if we are wanting 'stacking' at this stage, but with a new stack
    // (implies different viewport). We need to resolve the target into a
    // rt so we can accumulate into it.
    // This would be much nicer to do in the stack manager but due to
    // stereo we need to do it per eye :(
    CameraStackRenderingState* stack = GetRenderManager().GetCurrentCameraStackStatePtr();
    if (stack->ShouldResolveLastTarget())
        ResolveLastTargetToCurrentTarget();
}

void Camera::MultiCustomRender(CullResults& cullResults, PerformRenderFunction* const* renderFunctionObjects, size_t count, bool bSkipMarkers /*= false*/)
{
    Assert(renderFunctionObjects != NULL);

    if (!bSkipMarkers)
    {
        PROFILER_AUTO_GFX(gCameraDrawMultiCustomProfile, this);
    }

#if ENABLE_ASSERTIONS
    int defaultRenderCount = 0;
#endif
    for (size_t i = 0; i < count; i++)
    {
#if ENABLE_ASSERTIONS
        if (renderFunctionObjects[i] == &DefaultPerformRenderFunction::Instance())
        {
            defaultRenderCount++;
        }
#endif
        (*renderFunctionObjects[i])(this, static_cast<RenderingPath>(cullResults.sceneCullParameters.renderPath), &cullResults);
    }

#if ENABLE_ASSERTIONS
    AssertMsg(defaultRenderCount <= 1, "MultiCustomRender has executed the inner render loop twice. As this path modifies the cullResults this is probably undesired.");
#endif
}

void Camera::PostMultiCustomRender(RenderFlag renderFlags, bool bSkipMarkers /*= false*/)
{
    if (!bSkipMarkers)
    {
        PROFILER_AUTO_GFX(gCameraDrawMultiCustomPostProfile, this);
    }

    // Shader replacement might be passed explicitly (camera.RenderWithShader), in which case we don't
    // send Pre/Post render events, and don't render image effects.
    // OR shader replacement can be setup as camera's state (camera.SetReplacementShader), in which case
    // camera functions as usually, just with shaders replaced.
    if ((renderFlags & kRenderFlagExplicitShaderReplace) == 0)
    {
        SendMessage(kPostRender);
        if (GetMonoManagerPtr()) // might not be there (e.g. unit tests)
        {
            CallStaticMethodTakingCamera(GetCoreScriptingClasses().fireOnPostRender, this);
        }
    }

#if ENABLE_OVERLAY_MANAGER
    // camera may be already disabled here (OnPostRender)
    if ((renderFlags & kRenderFlagStandalone) || GetEnabled())
    {
        if (OverlayManager::IsAvailable())
            OverlayManager::Get()->RenderOverlays();
    }
#endif

    GfxDevice& device = GetGfxDevice();
    EndSinglePassStereo(device, GetDefaultPassContext(), renderFlags);

    // The last renderer _might_ have toggled the back facing mode (to deal with mirrored geometry), so we reset this
    // in order to make the back facing well-defined.
    device.SetBackfaceMode(false);

    // After rendering loops, handle any shaders with errors discovered
    Shader::HandleShadersWithErrors();
}

void Camera::DoRender(CullResults& cullResults, const SharedRendererScene& sharedRendererScene, RenderFlag renderFlags, PerformRenderFunction* renderFunctionObj)
{
    if (!IsValidToRender())
        return;

    PROFILER_AUTO_GFX(gCameraDrawProfile, this)

    PreMultiCustomRender(cullResults, renderFlags, true);
    MultiCustomRender(cullResults, &renderFunctionObj, 1, true);
    PostMultiCustomRender(renderFlags, true);
}

static bool EnableSinglePassStereo(GfxDevice& device, ShaderPassContext& passContext, Camera::RenderFlag renderFlags)
{
    if (HasFlag(renderFlags, Camera::kRenderFlagSinglePassStereo))
    {
        device.SetSinglePassStereo(GetGraphicsCaps().singlePassStereo);
        passContext.keywords.Enable(keywords::kSinglePassStereo);
        return true;
    }
    else if (HasFlag(renderFlags, Camera::kRenderFlagInstancingStereo))
    {
        device.SetSinglePassStereo(kSinglePassStereoInstancing);
        passContext.keywords.Enable(keywords::kStereoInstancingOn);
        return true;
    }
    else if (HasFlag(renderFlags, Camera::kRenderFlagMultiviewStereo))
    {
        device.SetSinglePassStereo(GetGraphicsCaps().singlePassStereo);
        passContext.keywords.Enable(keywords::kStereoMultiviewOn);
        return true;
    }

    return false;
}

void Camera::BeginSinglePassStereo(GfxDevice& device, ShaderPassContext& passContext, RenderFlag renderFlags, float viewportScale)
{
#if GFX_SUPPORTS_SINGLE_PASS_STEREO
    if (!EnableSinglePassStereo(device, passContext, renderFlags))
        return;

    const StereoscopicEye eyeBegin = GetStereoEyeBegin();
    const StereoscopicEye eyeEnd = GetStereoEyeEnd();
    for (int eyeIndex = eyeBegin; eyeIndex < eyeEnd; eyeIndex++)
    {
        const StereoscopicEye eye = StereoscopicEye(eyeIndex);
        const MonoOrStereoscopicEye mEye = MonoOrStereoscopicEye(eye);

        // Calculate matrices
        Matrix4x4f proj = GetStereoProjectionMatrix(eye);
        Matrix4x4f view = GetStereoViewMatrix(eye);
        Matrix4x4f invProj;
        InvertMatrix4x4_Full(proj.GetPtr(), invProj.GetPtr());
        Matrix4x4f worldToCamera, cameraToWorld;
        CalculateMatrixShaderProps(view, worldToCamera, cameraToWorld);

        // Set projection before view
        device.SetStereoMatrix(mEye, kShaderMatProj, proj);
        device.SetStereoMatrix(mEye, kShaderMatView, view);
        device.SetStereoMatrix(mEye, kShaderMatCameraProjection, proj);
        device.SetStereoMatrix(mEye, kShaderMatCameraInvProjection, invProj);
        device.SetStereoMatrix(mEye, kShaderMatWorldToCamera, worldToCamera);
        device.SetStereoMatrix(mEye, kShaderMatCameraToWorld, cameraToWorld);

        Rectf normalizedViewport;
        if (GetIVRDevice()->GetViewportForEye(eye, GetNormalizedViewportRect(), normalizedViewport))
        {
            int rsWidth = device.GetActiveRenderSurfaceWidth();
            int rsHeight = device.GetActiveRenderSurfaceHeight();

            normalizedViewport.Scale(rsWidth, rsHeight);
            normalizedViewport.width /= viewportScale;
            normalizedViewport.height /= viewportScale;

            RectInt viewportToRender(RoundfToInt(normalizedViewport.x), RoundfToInt(normalizedViewport.y), RoundfToInt(normalizedViewport.width), RoundfToInt(normalizedViewport.height));
            device.SetStereoViewport(eye, viewportToRender);
        }
        else
        {
            RectInt monoViewport = device.GetViewport();
            device.SetStereoViewport(eye, monoViewport);
        }
    }
#endif
}

void Camera::EndSinglePassStereo(GfxDevice& device, ShaderPassContext& passContext, RenderFlag renderFlags)
{
#if GFX_SUPPORTS_SINGLE_PASS_STEREO
    if (device.GetSinglePassStereo() == kSinglePassStereoNone)
        return;

    // Change back stereo mode to none
    device.SetSinglePassStereo(kSinglePassStereoNone);
    if (HasFlag(renderFlags, kRenderFlagInstancingStereo))
    {
        passContext.keywords.Disable(keywords::kStereoInstancingOn);
    }
    else if (HasFlag(renderFlags, kRenderFlagMultiviewStereo))
    {
        passContext.keywords.Disable(keywords::kStereoMultiviewOn);
    }
    else
    {
        passContext.keywords.Disable(keywords::kSinglePassStereo);
    }
#endif
}

void Camera::SetActiveVRUsage() const
{
    GfxDevice& device = GetGfxDevice();
    bool isSinglePass = device.GetSinglePassStereo() != kSinglePassStereoNone;
    bool isStereo = GetStereoEnabled();

    VRTextureUsage newVrUsage = kVRTextureUsageNone;
    if (isStereo)
    {
        if (isSinglePass)
        {
            newVrUsage = kVRTextureUsageTwoEyes;
        }
        else
        {
            newVrUsage = kVRTextureUsageOneEye;
        }
    }

    GetRenderBufferManager().SetActiveVRUsage(newVrUsage);
}

bool Camera::CalculateCanDoShadows() const
{
    return ShouldUseShadows(true); // shadows enabled etc.
}

float Camera::CalculateShadowDistance() const
{
    float shadowDist = QualitySettings::GetShadowDistanceForRendering();
    float farDist = GetFar();
    return std::min(shadowDist, farDist);
}

RenderingPath Camera::CalculateRenderingPath() const
{
    // Get rendering path from builds settings or per-camera params
    RenderingPath rp = (m_State.m_RenderingPath == -1) ?
        GetGraphicsSettings().GetTierSettings().renderingPath :
        static_cast<RenderingPath>(m_State.m_RenderingPath);

    // Figure out what we can support on this hardware
    if (rp == kRenderPathPrePass || rp == kRenderPathDeferred)
    {
        bool gpuSupport =   (GetGraphicsCaps().hasPrePassRenderLoop && rp == kRenderPathPrePass) ||
            (GetGraphicsCaps().hasDeferredRenderLoop && rp == kRenderPathDeferred);

        bool canDoDeferred =
            gpuSupport &&
            !m_State.m_Orthographic &&                      // can't be ortho
            !IsObliqueProjection(GetProjectionMatrix()) // can't use oblique projection (no sane way to calculate position from depth)
        ;
        if (!canDoDeferred)
            rp = kRenderPathForward;
    }
    return rp;
}

void Camera::SaveMatrixState(Camera::MatrixState& state) const
{
    state.viewMatrix = m_State.m_WorldToCameraMatrix;
    state.projMatrix = m_State.m_ProjectionMatrix;
    state.skyboxProjMatrix = m_State.m_SkyboxProjectionMatrix;

    state.implicitViewMatrix = m_State.m_ImplicitWorldToCameraMatrix;
    state.implicitProjMatrix = m_State.m_ImplicitProjectionMatrix;
    state.implicitSkyboxProjMatrix = m_State.m_ImplicitSkyboxProjectionMatrix;
}

void Camera::RestoreMatrixState(const Camera::MatrixState& state)
{
    m_State.m_WorldToCameraMatrix = state.viewMatrix;
    m_State.m_ProjectionMatrix = state.projMatrix;
    m_State.m_SkyboxProjectionMatrix = state.skyboxProjMatrix;

    m_State.m_ImplicitWorldToCameraMatrix = state.implicitViewMatrix;
    m_State.m_ImplicitProjectionMatrix = state.implicitProjMatrix;
    m_State.m_ImplicitSkyboxProjectionMatrix = state.implicitSkyboxProjMatrix;

    m_State.m_DirtyWorldToClipMatrix = true;
    m_State.m_DirtyWorldToCameraMatrix = true;
    m_State.m_DirtyProjectionMatrix = true;
    m_State.m_DirtySkyboxProjectionMatrix = true;
}

void StoreRenderState(CameraRenderOldState& state, const ShaderPassContext& passContext)
{
    GfxDevice& device = GetGfxDevice();
    RenderManager& mgr = GetRenderManager();

    state.viewport = device.GetViewport();
    state.scissorRect = device.GetScissorRect();
    state.scissorEnabled = device.IsScissorEnabled();

    state.activeRT = RenderTexture::GetActive();
    state.sRGBWrite = device.GetSRGBWrite();
    state.camera = mgr.GetCurrentCameraPtr();
    state.cameraStackRenderState = mgr.GetCurrentCameraStackStatePtr();

    state.matView = device.GetViewMatrix();
    state.matWorld = device.GetWorldMatrix();
    state.matProj = device.GetProjectionMatrix();

    int offset;

    offset = passContext.properties.FindTextureOffset(kSLPropCameraDepthTexture);
    if (offset >= 0)
        state.depthTex = passContext.properties.GetTextureValue(offset);

    offset = passContext.properties.FindTextureOffset(kSLPropCameraDepthNormalsTexture);
    if (offset >= 0)
        state.depthNormalsTex = passContext.properties.GetTextureValue(offset);
}

void RestoreRenderState(CameraRenderOldState& state, ShaderPassContext& passContext)
{
    GfxDevice& device = GetGfxDevice();
    RenderManager& mgr = GetRenderManager();

    Camera* oldCamera = state.camera;
    mgr.SetCurrentCameraAndStackState(oldCamera, state.cameraStackRenderState);

    // We should not pass "prepare image effects" flag here, because we're restoring previous render texture
    // ourselves. I'm not sure if we should even call DoSetup on the camera; can't figure it out right now.
    //@TODO: ???
    if (oldCamera)
        oldCamera->SetupRender(passContext, oldCamera->ExtractCameraRenderingParams());

    RenderTexture::SetActive(state.activeRT, 0, kCubeFaceUnknown, 0, RenderTexture::kFlagNone);
    device.SetSRGBWrite(state.sRGBWrite);

    device.SetViewport(state.viewport);
    if (state.scissorEnabled)
        device.SetScissorRect(state.scissorRect);
    else
        device.DisableScissor();
    GraphicsHelper::SetWorldViewAndProjection(device, &state.matWorld, &state.matView, &state.matProj);
    SetClippingPlaneShaderProps();

    passContext.properties.SetTextureProperty(kSLPropCameraDepthTexture, state.depthTex);
    passContext.properties.SetTextureProperty(kSLPropCameraDepthNormalsTexture, state.depthNormalsTex);
}

void Camera::StandaloneRender(RenderFlag renderFlags, Shader* replacementShader, const core::string& replacementTag)
{
    DefaultPerformRenderFunction& renderFunctionObj = DefaultPerformRenderFunction::Instance();
    StandaloneCustomRender(renderFlags, replacementShader, replacementTag, &renderFunctionObj);
}

void Camera::StandaloneCustomRender(RenderFlag renderFlags, Shader* replacementShader, const core::string& replacementTag, PerformRenderFunction* renderFunctionObj)
{
    PROFILER_AUTO_GFX(gCameraRenderProfile, this)

    // StandaloneCull() & CustomRenderWithPipeline() are protected from recursion (they don't allow it), which means it will cull/render nothing - skip it altogether
    if (m_IsStandaloneCustomRendering)
        return;

    m_IsStandaloneCustomRendering = true;

    renderFlags |= kRenderFlagStandalone;

    ShaderPassContext& passContext = GetDefaultPassContext();

    RenderManager::UpdateAllRenderers();

    if (GetCameraType() != kCameraTypePreview)
    {
        // Make sure the UI canvas get updated and emitted for this render.
        // UI uses IntermediateRenderers so they will get cleared after the render is done.
        PlayerUpdateCanvases();

        // Emit the geometry (both world canvas and screen - space camera) for this camera.
        GlobalCallbacks::Get().emitCanvasDataForCamera.Invoke(this);
    }
    CameraRenderOldState state;
    if (!(renderFlags & kRenderFlagDontRestoreRenderState))
        StoreRenderState(state, passContext);

    {
        AutoScopedCameraStackRenderingState scopedStackRenderState(*this);
        WindowSizeHasChanged();

        CullResults cullResults;

        StandaloneCull(replacementShader, replacementTag, cullResults);

        // We may need BeginFrame() if we're called from script outside rendering loop (case 464376)
        AutoGfxDeviceBeginEndFrame frame;
        if (!frame.GetSuccess())
        {
            m_IsStandaloneCustomRendering = false;
            return;
        }

        // Shader replacement might be passed explicitly (camera.RenderWithShader), in which case we don't
        // send Pre/Post render events, and don't render image effects.
        // OR shader replacement can be setup as camera's state (camera.SetReplacementShader), in which case
        // camera functions as usually, just with shaders replaced.
        if (replacementShader != NULL)
            renderFlags |= kRenderFlagExplicitShaderReplace;

        // Render this camera
        UpdateVelocity();
        CustomRender(cullResults, passContext, NULL, renderFlags, renderFunctionObj);
        ClearIntermediateRenderers();
    }
    if (!(renderFlags & kRenderFlagDontRestoreRenderState))
    {
        RestoreRenderState(state, passContext);
    }

    m_IsStandaloneCustomRendering = false;
}

bool Camera::StandaloneRenderToCubemap(Texture* texture, int faceMask, PostProcessCullResults* postProcessCullResults, void* postProcessCullResultsData)
{
    PROFILER_AUTO_GFX(gCameraRenderToCubemapProfile, this)

    RenderTextureFormat tempRTColorFormat = GetGfxDevice().GetDefaultRTFormat();
    Cubemap* outputCubemap = dynamic_pptr_cast<Cubemap*>(texture);
    RenderTexture* outputRenderTexture = dynamic_pptr_cast<RenderTexture*>(texture);

    ShaderPassContext& passContext = GetDefaultPassContext();

    if (outputCubemap)
    {
        if (!outputCubemap->GetIsReadable())
        {
            ErrorString("Unable to render to cubemap, make sure it's marked as'Readable'");
            return false;
        }

        if (!IsSupportedReadPixelsFormat(outputCubemap->GetTextureFormat(), GetGfxDevice().GetRenderer()))
        {
            const char* kUnsupportedReadPixelsFormatMessage = "Unsupported texture format to render to cubemap - needs to be RGBA32, ARGB32, RGB24, RGBAFloat or RGBAHalf";
            ErrorStringObject(kUnsupportedReadPixelsFormatMessage, this);
            return false;
        }
    }
    else if (outputRenderTexture)
    {
        if (outputRenderTexture->GetDimension() != kTexDimCUBE)
        {
            ErrorStringObject("Render texture must be a cubemap", this);
            return false;
        }

        tempRTColorFormat = outputRenderTexture->GetColorFormat();
    }
    else
    {
        ErrorStringObject("A valid Cubemap texture or render texture must be provided", this);
        return false;
    }

    if (!GetGraphicsCaps().hasRenderToCubemap)
    {
        //ErrorString( "Render to cubemap is not supported on this hardware" );
        // Do not print the message; if returns false that means unsupported. No need to spam the console.
        return false;
    }

    // We may need BeginFrame() if we're called from script outside rendering loop (case 464376)
    AutoGfxDeviceBeginEndFrame frame;
    if (!frame.GetSuccess())
    {
        return false;
    }

    RenderManager::UpdateAllRenderers();

    int size = texture->GetDataWidth();
    int antiAliasingLevel = outputRenderTexture ? outputRenderTexture->GetAntiAliasing() : 1;

    RenderTexture* tempRT = GetRenderBufferManager().GetTempBuffer(size, size, kDepthFormatMin24bits_Stencil, tempRTColorFormat, 0, kRTReadWriteDefault, kVRTextureUsageNone, antiAliasingLevel);
    if (tempRT == NULL)
    {
        ErrorStringObject("Error while rendering to cubemap - failed to get temporary render texture", this);
        return false;
    }

    CameraRenderOldState state;
    StoreRenderState(state, passContext);
    PPtr<RenderTexture> oldTargetTexture = m_State.m_TargetTexture;
    SetTargetTexture(tempRT);
    AutoScopedCameraStackRenderingState scopedStackRenderState(*this);
    GetRenderManager().SetCurrentCameraAndStackState(this, &scopedStackRenderState.GetStackState());
    m_State.m_TargetTexture = tempRT;

    Matrix4x4f viewMatrix;

    // save FOV, aspect & render path (careful to not cause SetDirty)
    CameraTemporarySettings oldSettings;
    GetTemporarySettings(oldSettings);
    m_State.m_FieldOfView = 90.0f;
    m_State.m_FieldOfViewBeforeEnablingVRMode = -1.0f;
    m_State.m_Aspect = 1.0f;
    m_State.m_ImplicitAspect = false;
    m_State.m_DirtyProjectionMatrix = true;
    m_State.m_DirtySkyboxProjectionMatrix = true;
    m_State.m_DirtyWorldToClipMatrix = true;

    //Rendering reflection probes only fully suppported in forward or deferred render paths
    RenderingPath calculatedRenderingPath = CalculateRenderingPath();
    if (calculatedRenderingPath != kRenderPathForward && calculatedRenderingPath != kRenderPathDeferred)
    {
        calculatedRenderingPath = kRenderPathForward;
        m_State.m_RenderingPath = kRenderPathForward;
    }
    DebugAssert(CalculateRenderingPath() == kRenderPathForward || CalculateRenderingPath() == kRenderPathDeferred);

    GfxDevice& device = GetGfxDevice();

    // render each face
    Matrix4x4f translateMat;
    translateMat.SetTranslate(-GetComponent<Transform>().GetPosition());
    const bool oldUserBackfaceMode = device.GetUserBackfaceMode();
    device.SetUserBackfaceMode(true);

    if (!outputCubemap && outputRenderTexture)
        outputRenderTexture->DiscardContents();

    for (int i = 0; i < 6; ++i)
    {
        if (!(faceMask & (1 << i)))
            continue;

        SetCurrentTargetTexture(tempRT);

        // render the cubemap face
        viewMatrix.SetBasisTransposed(kCubemapOrthoBases[i * 3 + 0], kCubemapOrthoBases[i * 3 + 1], kCubemapOrthoBases[i * 3 + 2]);
        viewMatrix *= translateMat;
        SetWorldToCameraMatrix(viewMatrix);

        CullResults cullResults;
        cullResults.sceneCullParameters.postProcessCullResults = postProcessCullResults;
        cullResults.sceneCullParameters.postProcessCullResultsUserData = postProcessCullResultsData;
        StandaloneCull(NULL, "", cullResults);

        // Added kRenderFlagSetRenderTarget to fix Case 627881.
        // It seems if we don't pass kRenderFlagSetRenderTarget, rendering pipeline doesn't restores render textures
        // For a scene with no objects in sight, this was happening:
        // ...
        // * RenderTexture::SetActive(<DepthTexture>)
        // * Update shadow maps
        // * Restore active render texture <---- this wasn't occuring
        // * Render skybox
        UpdateVelocity();
        Render(cullResults, passContext, kRenderFlagStandalone | kRenderFlagSetRenderTarget);
        ClearIntermediateRenderers();

        if (outputCubemap)
        {
            // Read back render texture into the cubemap face.
            // If projection matrix is flipped (happens on D3D), we have to flip
            // the image vertically so that result is correct.
            outputCubemap->ReadPixels(i, 0, 0, size, size, 0, 0, device.GetInvertProjectionMatrix(), false);
        }
        else
        {
            // Why aren't we directly rendering to outputRenderTexture?
            // Joachim said "because that has bugs with shadows. (At least on os x OpenGL it does), you can see this on the chamber demo"

            RenderTexture::SetActive(outputRenderTexture, 0, (CubemapFace)i, 0, RenderTexture::kFlagDontRestore);

            // We're alternating between target that we render face into, and the destination render texture face,
            // so we'll always be un-resolving the destination RT.
            //@TODO: on tiled GPUs, maybe we should render all faces at once, and then blit them into destination?
            // Or some way to have "discard" functionality per-RT-face. If we had that, we could discard previous contents
            // of a particular destination RT face here.
            device.IgnoreNextUnresolveOnCurrentRenderTarget();
            ImageFilters::Blit(passContext, tempRT, outputRenderTexture, 0, ImageFilters::GetBlitCopyMaterial(), -1, ImageFilters::kBlitFlagsNone, (CubemapFace)i);
        }
    }

    ResetWorldToCameraMatrix();

    SetTemporarySettings(oldSettings);

    m_State.m_TargetTexture = oldTargetTexture;
    SetTargetTexture(oldTargetTexture);

    RestoreRenderState(state, passContext);

    device.SetUserBackfaceMode(oldUserBackfaceMode);

    GetRenderBufferManager().ReleaseTempBuffer(tempRT);

    if (outputCubemap)
    {
        // Rendering cubemaps takes place for a sRGB color space:
        outputCubemap->SetStoredColorSpace(kTexColorSpaceSRGB);
        outputCubemap->UpdateImageData();
    }

    return true;
}

void Camera::RenderDepthTexture(const CullResults& cullResults, const SharedRendererScene& rendererScene, ShaderPassContext& passContext, RenderFlag renderFlags)
{
    PROFILER_AUTO_GFX(gCameraDepthTextureProfile, this)
    GPU_AUTO_SECTION(kGPUSectionShadowPass);

    if (m_DepthTexture)
    {
        GetRenderBufferManager().ReleaseTempBuffer(m_DepthTexture);
        m_DepthTexture = NULL;
    }

    DepthBufferFormat depthFormat = kDepthFormatMin24bits_Stencil;

    int width = RenderBufferManager::kFullSize;
    int height = RenderBufferManager::kFullSize;
    bool needsArray = false;
    if (GetStereoEnabled())
    {
        Rectf normalizedRect = m_State.m_NormalizedViewPortRect;
        RenderTextureDesc eyeDesc = GetIVRDevice()->GetDefaultEyeTextureDesc();
        needsArray = (eyeDesc.dimension == kTexDim2DArray);
        width = RoundfToInt(eyeDesc.width * normalizedRect.width);
        height = RoundfToInt(eyeDesc.height * normalizedRect.height);
    }
    m_DepthTexture = GetRenderBufferManager().GetTempBuffer(width, height, depthFormat, kRTFormatDepth, needsArray ? RenderBufferManager::kRBArray : 0, needsArray ? kStereoscopicEyeCount : 0, kRTReadWriteLinear);


    if (!m_DepthTexture)
        return;

    m_DepthTexture->SetName("Camera DepthTexture");
    m_DepthTexture->SetFilterMode(kTexFilterNearest);

    GfxDevice& device = GetGfxDevice();
    RenderTexture::SetActive(m_DepthTexture, 0, kCubeFaceUnknown, 0, RenderTexture::kFlagNone);

    device.Clear(kGfxClearAll, ColorRGBAf(1, 1, 1, 1), 1.0f, 0);
    GPU_TIMESTAMP();
    SetupRender(passContext, ExtractCameraRenderingParams());

    float viewportScale = GetIVRDevice() ? GetIVRDevice()->GetRenderViewportScale() : 1.0f;
    BeginSinglePassStereo(device, passContext, renderFlags, viewportScale);

    RenderNodeQueue nodeQueue(kMemTempAlloc);

    if (GetIVRDevice())
        GetIVRDevice()->RenderOcclusionMesh(GetNormalizedViewportRect());

    InvokeRenderEventCB(kRenderEvent_BeforeDepthTexture, passContext, nodeQueue);
    RenderSceneDepthPass(rendererScene, cullResults.shaderReplaceData, false, passContext);

    EndSinglePassStereo(device, passContext, renderFlags);

    // The last renderer _might_ have toggled the back facing mode (to deal with mirrored geometry), so we reset this
    // in order to make the back facing well-defined.
    device.SetBackfaceMode(false);

    passContext.properties.SetTexture(kSLPropCameraDepthTexture, m_DepthTexture);
    passContext.properties.SetTexture(kSLPropLastCameraDepthTexture, m_DepthTexture);
    InvokeRenderEventCB(kRenderEvent_AfterDepthTexture, passContext, nodeQueue);
}

void Camera::RenderDepthNormalsTexture(const CullResults& cullResults, const SharedRendererScene& rendererScene, ShaderPassContext& passContext, RenderFlag renderFlags)
{
    const BuiltinShaderSettings& shaderSettings = GetGraphicsSettings().GetBuiltinShaderSettings(GraphicsSettings::kDepthNormals);
    if (shaderSettings.IsDisabled())
        return;

    Shader* shader = shaderSettings.m_Shader;
    if (!shader)
        return;

    PROFILER_AUTO_GFX(gCameraDepthNormalsTextureProfile, this)
    GPU_AUTO_SECTION(kGPUSectionShadowPass);

    if (m_DepthNormalsTexture)
    {
        GetRenderBufferManager().ReleaseTempBuffer(m_DepthNormalsTexture);
        m_DepthNormalsTexture = NULL;
    }

    DepthBufferFormat depthFormat = kDepthFormatMin24bits_Stencil;
    if (GetIVRDevice())
    {
        depthFormat = GetIVRDevice()->GetDepthBufferFormat();
    }

    m_DepthNormalsTexture = GetRenderBufferManager().GetTempBuffer(RenderBufferManager::kFullSize, RenderBufferManager::kFullSize, depthFormat, kRTFormatARGB32, 0, kRTReadWriteLinear);
    if (!m_DepthNormalsTexture)
        return;
    m_DepthNormalsTexture->SetName("Camera DepthNormalsTexture");
    m_DepthNormalsTexture->SetFilterMode(kTexFilterNearest);

    GfxDevice& device = GetGfxDevice();
    RenderTexture::SetActive(m_DepthNormalsTexture, 0, kCubeFaceUnknown, 0, RenderTexture::kFlagNone);

    GraphicsHelper::Clear(kGfxClearAll, ColorRGBAf(0.5f, 0.5f, 1, 1), 1.0f, 0, passContext);
    GPU_TIMESTAMP();
    SetupRender(passContext, ExtractCameraRenderingParams());
    BeginSinglePassStereo(device, passContext, renderFlags);

    RenderNodeQueue nodeQueue(kMemTempAlloc);
    InvokeRenderEventCB(kRenderEvent_BeforeDepthNormalsTexture, passContext, nodeQueue);

    RenderSceneShaderReplacement(rendererScene, shader, "RenderType", passContext);

    EndSinglePassStereo(device, passContext, renderFlags);

    // The last renderer _might_ have toggled the back facing mode (to deal with mirrored geometry), so we reset this
    // in order to make the back facing well-defined.
    device.SetBackfaceMode(false);

    passContext.properties.SetTexture(kSLPropCameraDepthNormalsTexture, m_DepthNormalsTexture);
    passContext.properties.SetTexture(kSLPropLastCameraDepthNormalsTexture, m_DepthNormalsTexture);

    InvokeRenderEventCB(kRenderEvent_AfterDepthNormalsTexture, passContext, nodeQueue);
}

RenderTexture* Camera::GetBuiltinRenderTexture(BuiltinRenderTextureType type)
{
    if (type == kBuiltinRTCameraTarget)
        return m_CurrentTargetTexture;
    CameraStackRenderingState* curState = GetCurrentCameraStackStatePtr();
    if (curState)
        return curState->GetBuiltinRT(type);
    return NULL;
}

void Camera::CleanupAfterRendering(const CullResults* cullResults)
{
    // Release temporary textures of all light command buffers.
    // Note: only shadow casting lights have command buffers now (RenderLightEventType is all shadow
    // related), so it's enough to loop over shadowed lights here.
    if (cullResults)
    {
        for (size_t i = 0, n = cullResults->shadowedLights.size(); i != n; ++i)
        {
            const ShadowedLight& shadowLight = cullResults->shadowedLights[i];
            AssertFormatMsg(shadowLight.lightIndex >= 0 && shadowLight.lightIndex < cullResults->activeLights.lights.size(), "Data inconsistency in active vs shadowed lights; bad active light index (got %i but only %i lights)", shadowLight.lightIndex, (int)cullResults->activeLights.lights.size());
            const ActiveLight& activeLight = cullResults->activeLights.lights[shadowLight.lightIndex];
            AssertMsg(activeLight.shadowedLightIndex == i, "Data inconsistency in active vs shadowed lights");
            AssertMsg(activeLight.light, "Data inconsistency in active lights; got NULL light");
            activeLight.light->CleanupCommandBuffer();
        }
    }

    // Release temporary textures of camera command buffers.
    m_RenderEvents.CleanupCommandBuffers();

    CleanupAfterRenderLoop(*m_RenderLoop);
    CleanupDepthTextures();
    if (!GetStereoEnabled())
        ClearShadowMapCache(m_ShadowCache);
}

void Camera::CleanupDepthTextures()
{
    if (m_DepthTexture != NULL)
    {
        GetRenderBufferManager().ReleaseTempBuffer(m_DepthTexture);
        m_DepthTexture = NULL;
    }
    if (m_DepthNormalsTexture != NULL)
    {
        GetRenderBufferManager().ReleaseTempBuffer(m_DepthNormalsTexture);
        m_DepthNormalsTexture = NULL;
    }
}

void Camera::UpdateDepthTextures(const CullResults& cullResults, const SharedRendererScene& rendererScene, RenderFlag renderFlags)
{
    ShaderPassContext& passContext = GetDefaultPassContext();

    passContext.keywords.Disable(keywords::kSoftParticlesOn);

    // Do not use soft particles in orthographic mode, since Z buffer decoding would need to be done
    // differently in the particles shader.
    const bool softParticles = !m_State.m_Orthographic && GetQualitySettings().GetCurrent().softParticles;

    UInt32 depthTexMask = m_State.m_DepthTextureMode;
    RenderingPath renderPath = CalculateRenderingPath();
    const bool isDeferred = renderPath == kRenderPathPrePass || renderPath == kRenderPathDeferred;

    if (softParticles && isDeferred)
        passContext.keywords.Enable(keywords::kSoftParticlesOn);

    // Prepass needs to generate depth texture if we don't have native capability
    if (!GetGraphicsCaps().hasStencilInDepthTexture && isDeferred)
        depthTexMask |= kDepthTexDepthBit;

    bool needDepthForShadows = false;

    const Shader* const replacementShader = cullResults.shaderReplaceData.replacementShader;
    const bool replacementShaderWithoutShadows = (replacementShader != NULL) && !replacementShader->GetShaderLabShader()->HasLightingPasses();

    // In forward rendering, if we have any directional shadow casting lights, we need z-prepass
    // to compute cascaded shadow maps later. Unless we're rendering with a replacement shader,
    // that doesn't do shadows. We also have to check that screen space shadows are supported
    if (!isDeferred
        && GetGraphicsSettings().GetTierSettings().useCascadedShadowMaps
        && !replacementShaderWithoutShadows
        && !GetGraphicsSettings().GetBuiltinShaderSettings(GraphicsSettings::kScreenSpaceShadows).IsDisabled())
    {
        const bool hasShadowLights = cullResults.activeLights.hasShadowedDirLights;
        const bool receiveShadows = CalculateCanDoShadows();
        if (hasShadowLights && receiveShadows)
        {
            depthTexMask |= kDepthTexDepthBit;
            needDepthForShadows = true;
        }
    }

    // In case we need depth texture:
    // If HW supports native depth textures AND we're going to use light pre-pass:
    //     it comes for free, nothing extra to do.
    if ((depthTexMask & kDepthTexDepthBit) && isDeferred && GetGraphicsCaps().hasStencilInDepthTexture)
        depthTexMask &= ~kDepthTexDepthBit;

    // In case we need depth+normals texture:
    // If we're going to use light pre-pass, it will built it for us. Nothing extra to do.
    if ((depthTexMask & kDepthTexDepthNormalsBit) && isDeferred)
        depthTexMask &= ~kDepthTexDepthNormalsBit;

    // No depth textures needed
    if (depthTexMask == 0)
        return;

    // Depth textures require some hardware support
    if (!GetGraphicsCaps().supportsRenderTextureFormat[kRTFormatDepth])
        return;

    // if camera's viewport rect is empty or invalid, do nothing
    if (!IsValidToRender())
        return;

    if (softParticles && (depthTexMask & kDepthTexDepthBit))
        passContext.keywords.Enable(keywords::kSoftParticlesOn);

    Assert(depthTexMask != 0);
    Assert(m_DepthTexture == NULL && m_DepthNormalsTexture == NULL);

    if (depthTexMask & kDepthTexDepthBit)
        RenderDepthTexture(cullResults, rendererScene, passContext, renderFlags);
    if (depthTexMask & kDepthTexDepthNormalsBit)
        RenderDepthNormalsTexture(cullResults, rendererScene, passContext, renderFlags);

#if GFX_SUPPORTS_OPENGL_UNIFIED
    // when we are prepping image filters we need current rt info to determine formats of intermediate RTs
    // so we should reset info from possible depth path
    GfxDeviceRenderer renderer = GetGfxDevice().GetRenderer();
    if (IsUnifiedGLRenderer(renderer))
    {
        if (depthTexMask & (kDepthTexDepthBit | kDepthTexDepthNormalsBit))
            RenderTexture::SetActive(m_CurrentTargetTexture, 0, kCubeFaceUnknown, 0, RenderTexture::kFlagNone);
    }
#endif
}

void Camera::StandaloneSetup(ShaderPassContext& passContext)
{
    GetRenderManager().SetCurrentCameraDeprecated(this);
    //@TODO: how to setup current stack state? need it?!

    // This does not setup image filters! The usage pattern (e.g. terrain engine impostors) is:
    // Camera old = Camera.current;
    // newcamera.RenderDontRestore();
    //   ... render our stuff
    // Camera.SetupCurrent(old);
    //
    // So the last call should preserve whatever image filters were used before.
    SetupRender(passContext, ExtractCameraRenderingParams(), kRenderFlagStandalone | kRenderFlagSetRenderTarget);
}

void Camera::UpdateVelocity()
{
    Vector3f curPosition = GetPosition();
    m_State.m_Velocity = (curPosition - m_State.m_LastPosition) * GetInvDeltaTime();
    m_State.m_LastPosition = curPosition;
}

void Camera::Render(CullResults& cullResults, ShaderPassContext& passContext, RenderFlag renderFlags)
{
    Render(cullResults, passContext, NULL, renderFlags);
}

void Camera::Render(CullResults& cullResults, ShaderPassContext& passContext, const CameraRenderingParams* params, RenderFlag renderFlags)
{
    DefaultPerformRenderFunction& renderFunctionObj = DefaultPerformRenderFunction::Instance();
    CustomRender(cullResults, passContext, params, renderFlags, &renderFunctionObj);
}

void Camera::CustomRender(CullResults& cullResults, ShaderPassContext& passContext, const CameraRenderingParams* params, RenderFlag renderFlags, PerformRenderFunction* renderFunctionObj)
{
    // If camera's viewport rect is empty or invalid or there's no
    // visible nodes, do nothing.
    if (!IsValidToRender() || !cullResults.isValid)
        return;

    if (m_IsRendering)
    {
        WarningStringObject("Attempting to render from a camera that is currently rendering. Create a copy of the camera (Camera.CopyFrom) if you wish to do this.", this);
        return;
    }

    // Begin the frame here instead of in the player loop so we can don't need to wait for the previous frame to start culling.
    GfxDevice& device = GetGfxDevice();
    if (!device.IsInsideFrame())
        device.BeginFrame();

    m_IsRendering = true;

    // Calling code should setup current camera stack renering state, and current camera
    AssertFormatMsg(GetRenderManager().GetCurrentCameraStackStatePtr(), "Rendering camera '%s', but calling code did not setup camera stack render state", GetName());
    Camera* currentCam = GetCurrentCameraPtr();
    AssertFormatMsg(currentCam == this, "Rendering camera '%s', but calling code does not set it up as current camera (current camera: '%s')", GetName(), currentCam ? currentCam->GetName() : "<null>");
    GlobalCallbacks::Get().beforeCameraRender.Invoke(*this);

    const bool explicitReplacement = (renderFlags & kRenderFlagExplicitShaderReplace) != 0;
    // Shader replacement might be passed explicitly (camera.RenderWithShader), in which case we don't
    // send Pre/Post render events, and don't render image effects.
    if (!explicitReplacement)
    {
        // Prevent adding/removing renderer scene nodes from inside prerender callbacks: our culling output is already computed,
        // and changing the scene arrays can lead to invalid indices or dangling pointers.
        GetRendererScene().SetPreventAddRemoveRenderer(true);

        Object::HideFlags oldFlags = GetHideFlags();
        SetHideFlags(oldFlags | kDontAllowDestruction);

        RenderTexture* prePreRenderRT = m_CurrentTargetTexture;
        SendMessage(kPreRender);
        if (m_CurrentTargetTexture != prePreRenderRT)
        {
            // camera's targetTexture was updated in OnPreRender. this is bad practice but we still preserve it for backwards compatibility
            SetRenderTargetAndViewport();
        }

        if (GetMonoManagerPtr()) // might not be there (e.g. unit tests)
            CallStaticMethodTakingCamera(GetCoreScriptingClasses().fireOnPreRender, this);

        // restore scene/object flags
        if (!HasFlag(oldFlags, kDontAllowDestruction))
            SetHideFlags(GetHideFlags() & (~kDontAllowDestruction));
        GetRendererScene().SetPreventAddRemoveRenderer(false);
    }

    // as we sent PreRender events, users had one more chance to tweak camera setup - make sure it is still valid to render
    if (!IsValidToRender())
    {
        WarningStringObject("After executing OnPreRender callback Camera is no longer valid to render.", this);
        return;
    }

    RenderManager::UpdateAllRenderers();

    // Extract SharedRendererScene state after all callbacks. (After this point it is completely locked down)
    const SharedRendererScene* sharedRendererScene = cullResults.GetOrCreateSharedRendererScene();

    // If we aren't rendering with specifically overriden projection parameters (e.g. VR/Stereo),
    // then calculate them here. Need to do this after any possible PreRender callbacks are done,
    // since they could modify camera parameters.
    CameraRenderingParams implicitParams;
    if (params == NULL)
    {
        implicitParams = ExtractCameraRenderingParams();
        params = &implicitParams;
    }

    // Make sure current RT is pointing to actual camera's target texture, and not some pointer that might be stale by now.
    m_CurrentTargetTexture = m_State.m_TargetTexture;

    // Don't execute scriptable renderloops on cubemap previews, etc
    bool executingScriptable = ScriptableRenderContext::ShouldUseRenderPipeline();
    if (GetCameraType() != kCameraTypePreview && executingScriptable)
    {
        dynamic_array<Camera*> cameras(kMemTempAlloc);
        cameras.push_back(this);
        ScriptableRenderContext::ExtractAndExecuteRenderPipeline(cameras);
    }
    if (!executingScriptable)
    {
        // Update depth textures if needed
        UpdateDepthTextures(cullResults, *sharedRendererScene, renderFlags);

        CameraStackRenderingState& currentState = GetCurrentCameraStackState();
        RenderTexture* target = currentState.GetTargetTexture();
        SetCurrentTargetTexture(target);
        SetupRender(GetDefaultPassContext(), renderFlags);

        DoRender(cullResults, *sharedRendererScene, renderFlags, renderFunctionObj); // Render all geometry
        if ((renderFlags & kRenderFlagStandalone) || GetEnabled()) // camera may be already disabled here (OnPostRender)
        {
            BeginSinglePassStereo(device, passContext, renderFlags);

            //@TODO: This is inconsistent with renderGUILayer.
            //       Is there any reason for it?
            bool renderPostLayers = cullResults.shaderReplaceData.replacementShader == NULL;
            if (renderPostLayers)
                DoRenderPostLayers(&cullResults, passContext, renderFlags);     // Handle any post-layer

            SetActiveVRUsage();
            RenderImageFilters(*m_RenderLoop, false);
            EndSinglePassStereo(device, passContext, renderFlags);
        }
    }

    // Note: we setup current target texture to point to final RT, after we have done rendering. This is somewhat
    // confusing, as the variable is supposed to only mean something while we're rendering. However looks like quite
    // some code might dependent on it's value being valid even after rendering is finished (hard to say why,
    // the code has existed since forever). Whenever Camera gets serious refactoring (so that is only stores "settings",
    // and all rendering state is in some sort of "context"), would be nice to clean this stateful mess.
    // Stereo rendering overrides m_CurrentTargetTexture, so we shouldn't restore it here.
    if (!m_IsRenderingStereo)
    {
        m_CurrentTargetTexture = m_State.m_TargetTexture;
    }

    m_IsRendering = false;

    if ((renderFlags & kRenderFlagStandalone) || GetEnabled())
    {
        // camera may be already disabled here (OnPostRender)
        // When camera is rendering with replacement that is part of state (and not explicitly passed in),
        // render GUI using regular shaders.
        if (!explicitReplacement)
        {
            BeginSinglePassStereo(device, passContext, renderFlags);
            DoRenderGUILayer(passContext, renderFlags);
            EndSinglePassStereo(device, passContext, renderFlags);
        }

        RenderNodeQueue nodeQueue(kMemTempAlloc);
        InvokeRenderEventCB(kRenderEvent_AfterEverything, passContext, nodeQueue);
    }

    // Before we destroy intermediate renderers we have to wait for all culling jobs to complete (They depend on the intermediate renderer data)
    SyncFenceCullResults(cullResults);

    CleanupAfterRendering(&cullResults);
}

StereoscopicEye Camera::GetStereoEyeBegin() const
{
    // Start from left eye if in mirror mode or left eye is enabled
    if (m_State.m_StereoMirrorMode || (m_State.m_TargetEye & kTargetEyeMaskLeft))
        return kStereoscopicEyeDefault;
    else
        return kStereoscopicEyeRight;
}

StereoscopicEye Camera::GetStereoEyeEnd() const
{
    // Skip rendering right eye if in mirror mode or eye disabled
    if (m_State.m_StereoMirrorMode || !(m_State.m_TargetEye & kTargetEyeMaskRight))
        return kStereoscopicEyeRight;
    else
        return kStereoscopicEyeCount;
}

const Matrix4x4f& Camera::GetStereoViewMatrix(StereoscopicEye eye) const
{
    if (m_State.m_ImplicitStereoViewMatrices)
    {
        if (GetStereoEnabled())
        {
            m_State.m_StereoViewMatrices[eye] = GetIVRDevice()->GetViewMatrix(this, (MonoOrStereoscopicEye)eye);
        }
    }

    return m_State.m_StereoViewMatrices[eye];
}

void Camera::SetStereoViewMatrix(StereoscopicEye eye, const Matrix4x4f& viewMatrix)
{
    m_State.m_StereoViewMatrices[eye] = viewMatrix;
    m_State.m_ImplicitStereoViewMatrices = false;
}

void Camera::ResetStereoViewMatrices()
{
    m_State.m_ImplicitStereoViewMatrices = true;
}

void Camera::SetStereoProjectionMatrix(StereoscopicEye eye, const Matrix4x4f& projMatrix)
{
    m_State.m_StereoProjectionMatrices[eye] = projMatrix;
    m_State.m_ImplicitStereoProjectionMatrices = false;
}

void Camera::ResetStereoProjectionMatrices()
{
    m_State.m_ImplicitStereoProjectionMatrices = true;
}

const Matrix4x4f& Camera::GetStereoProjectionMatrix(StereoscopicEye eye) const
{
    if (m_State.m_ImplicitStereoProjectionMatrices)
    {
        if (GetStereoEnabled())
        {
            m_State.m_StereoProjectionMatrices[eye] = GetIVRDevice()->GetProjectionMatrix(this, (MonoOrStereoscopicEye)eye);
        }
    }

    return m_State.m_StereoProjectionMatrices[eye];
}

const Matrix4x4f& Camera::GetStereoWorldToClipMatrix(StereoscopicEye eye) const
{
    const Matrix4x4f& proj = GetStereoProjectionMatrix(eye);
    const Matrix4x4f& view = GetStereoViewMatrix(eye);
    MultiplyMatrices4x4(&proj, &view, &m_State.m_StereoWorldToClipMatrices[eye]);
    return m_State.m_StereoWorldToClipMatrices[eye];
}

static Camera::RenderFlag GetStereoRenderFlag(SinglePassStereo singlePassStereo)
{
    switch (singlePassStereo)
    {
        case kSinglePassStereoSideBySide:
            return Camera::kRenderFlagSinglePassStereo;
        case kSinglePassStereoInstancing:
            return Camera::kRenderFlagInstancingStereo;
        case kSinglePassStereoMultiview:
            return Camera::kRenderFlagMultiviewStereo;
        default:
            return Camera::kRenderFlagNone;
    }
}

void Camera::RenderStereo(RenderFlag renderFlags, CullFlag cullFlags, PerformEyeRenderFunction* eyeRenderFunctionObj)
{
    if (eyeRenderFunctionObj == NULL)
        return;

    m_IsRenderingStereo = true;

    MatrixState matrixState;
    SaveMatrixState(matrixState);
    Rectf oldViewportRect = GetNormalizedViewportRect();

    IVRDevice* vrDevice = GetIVRDevice();

    if (!vrDevice)
        return;

    const StereoscopicEye eyeBegin = GetStereoEyeBegin();
    const StereoscopicEye eyeEnd = GetStereoEyeEnd();
    SinglePassStereo singlePassStereo = GetSinglePassStereo();

    float aspect = vrDevice->GetAspect(GetNormalizedViewportRect(), eyeBegin, singlePassStereo);
    SetAspect(aspect);

    // Culling
    const bool singleCull = GetStereoSingleCullEnabled();
    vrDevice->PreCull(this, singleCull);

    // In the case of single cull, we'll fill out just the first element of cullData
    // and both entries in cullPtrs will point to the first element
    CullResults cullData[2];

    if (singleCull)
    {
        CullResults& cullResults = cullData[0];

        vrDevice->GetCullingParameters(this, cullResults.sceneCullParameters.stereoCombinedView, cullResults.sceneCullParameters.stereoCombinedProj, cullResults.sceneCullParameters.stereoSeparation);

        SetWorldToCameraMatrix(cullResults.sceneCullParameters.stereoCombinedView);
        SetProjectionMatrix(cullResults.sceneCullParameters.stereoCombinedProj);

        Cull(cullResults, cullFlags | kCullFlagStereo);
    }
    else
    {
        // Don't do stereo optimizations that rely on combined frustum (single shadow render)
        m_IsRenderingStereo = false;

        for (int eye = eyeBegin; eye < eyeEnd; ++eye)
        {
            SetWorldToCameraMatrix(GetStereoViewMatrix((StereoscopicEye)eye));
            SetProjectionMatrix(GetStereoProjectionMatrix((StereoscopicEye)eye));

            Cull(cullData[eye], cullFlags);
        }
    }

    UpdateVelocity();

#if GFX_SUPPORTS_SINGLE_PASS_STEREO
    // Single-pass rendering with fallback to rendering one eye at a time
    const bool renderBothEyes = (eyeBegin == kStereoscopicEyeDefault && eyeEnd == kStereoscopicEyeCount);
    if (renderBothEyes && singleCull && singlePassStereo != kSinglePassStereoNone)
    {
        vrDevice->SetStereoRenderTarget(this, kStereoscopicEyeDefault, singlePassStereo);

        // Using the combined matrix breaks _ZBufferParams, so use the left eye's view and projection
        SetWorldToCameraMatrix(GetStereoViewMatrix(kStereoscopicEyeDefault));
        SetProjectionMatrix(GetStereoProjectionMatrix(kStereoscopicEyeDefault));

        // Current view and projection matrices are the stereo combined versions (set up for culling)
        (*eyeRenderFunctionObj)(this, &cullData[0], renderFlags | GetStereoRenderFlag(singlePassStereo));
        vrDevice->EndEye(this, kStereoscopicEyeLeft);
    }
    else
#endif
    {
        for (int eyeIndex = eyeBegin; eyeIndex < eyeEnd; eyeIndex++)
        {
            const StereoscopicEye eye = static_cast<StereoscopicEye>(eyeIndex);
            vrDevice->SetStereoRenderTarget(this, eye, kSinglePassStereoNone);

            ///@TODO: We should really not extract SharedRendererScene twice for stereo mode...

            SetWorldToCameraMatrix(GetStereoViewMatrix((StereoscopicEye)eye));
            SetProjectionMatrix(GetStereoProjectionMatrix((StereoscopicEye)eye));

            int cullIndex = singleCull ? 0 : eyeIndex;
            (*eyeRenderFunctionObj)(this, &cullData[cullIndex], renderFlags);

            vrDevice->EndEye(this, eye);
            SetNormalizedViewportRect(oldViewportRect);
        }
    }

    m_IsRenderingStereo = false;

    ClearIntermediateRenderers();

    // Switch to default target
    SetTargetTexture(NULL);
    m_CurrentTargetTexture = m_State.m_TargetTexture;
    ApplyRenderTexture();

    ClearShadowMapCache(m_ShadowCache);
    SetNormalizedViewportRect(oldViewportRect);
    RestoreMatrixState(matrixState);
    ResetAspect();
}

void Camera::AddImageFilter(const ImageFilter& filter)
{
    GetRenderLoopImageFilters(*m_RenderLoop).AddImageFilter(filter);
}

void Camera::RemoveImageFilter(const ImageFilter& filter)
{
    GetRenderLoopImageFilters(*m_RenderLoop).RemoveImageFilter(filter);
}

bool Camera::HasAnyImageFilters() const
{
    return GetRenderLoopImageFilters(*m_RenderLoop).HasImageFilter();
}

Ray Camera::ScreenPointToRay(const Vector2f& viewPortPos) const
{
    RectInt viewport = GetScreenViewportRectInt();

    Ray ray;
    Vector3f out;
    Matrix4x4f clipToWorld;
    GetClipToWorldMatrix(clipToWorld);

    const Matrix4x4f& camToWorld = GetCameraToWorldMatrix();
    if (!CameraUnProject(Vector3f(viewPortPos.x, viewPortPos.y, m_State.m_NearClip), camToWorld, clipToWorld, viewport, out, GetTargetTexture() != NULL))
    {
        if (viewport.x > 0 || viewport.y > 0 || viewport.width > 0 || viewport.height > 0)
        {
            AssertString(Format("Screen position out of view frustum (screen pos %f, %f) (Camera rect %d %d %d %d)", viewPortPos.x, viewPortPos.y, viewport.x, viewport.y, viewport.width, viewport.height));
        }
        return Ray(GetPosition(), Vector3f(0, 0, 1));
    }
    ray.SetOrigin(out);

    if (m_State.m_Orthographic)
    {
        // In orthographic projection we get better precision by circumventing the whole projection and subtraction.
        ray.SetDirection(Normalize(-camToWorld.GetAxisZ()));
    }
    else
    {
        // We need to sample a point much further out than the near clip plane to ensure decimals in the ray direction
        // don't get lost when subtracting the ray origin position.
        if (!CameraUnProject(Vector3f(viewPortPos.x, viewPortPos.y, m_State.m_NearClip + 1000), camToWorld, clipToWorld, viewport, out, GetTargetTexture() != NULL))
        {
            if (viewport.x > 0 || viewport.y > 0 || viewport.width > 0 || viewport.height > 0)
            {
                AssertString(Format("Screen position out of view frustum (screen pos %f, %f) (Camera rect %d %d %d %d)", viewPortPos.x, viewPortPos.y, viewport.x, viewport.y, viewport.width, viewport.height));
            }
            return Ray(GetPosition(), Vector3f(0, 0, 1));
        }
        Vector3f dir = out - ray.GetOrigin();
        ray.SetDirection(Normalize(dir));
    }
    return ray;
}

Vector3f Camera::WorldToScreenPoint(const Vector3f& v, bool* canProject) const
{
    RectInt viewport = GetScreenViewportRectInt();

    Vector3f out;
    bool ok = CameraProject(v, GetCameraToWorldMatrix(), GetWorldToClipMatrix(), viewport, out, GetTargetTexture() != NULL);
    if (canProject != NULL)
        *canProject = ok;
    return out;
}

Vector3f Camera::ScreenToWorldPoint(const Vector3f& v) const
{
    RectInt viewport = GetScreenViewportRectInt();

    Vector3f out;
    Matrix4x4f clipToWorld;
    GetClipToWorldMatrix(clipToWorld);
    if (!CameraUnProject(v, GetCameraToWorldMatrix(), clipToWorld, viewport, out, GetTargetTexture() != NULL))
    {
        AssertString(Format("Screen position out of view frustum (screen pos %f, %f, %f) (Camera rect %d %d %d %d)", v.x, v.y, v.z, viewport.x, viewport.y, viewport.width, viewport.height));
    }
    return out;
}

Vector3f Camera::WorldToViewportPoint(const Vector3f &worldPoint)  const
{
    bool tempBool;
    Vector3f screenPoint = WorldToScreenPoint(worldPoint, &tempBool);
    return ScreenToViewportPoint(screenPoint);
}

Vector3f Camera::ViewportToWorldPoint(const Vector3f &viewPortPoint) const
{
    Vector3f screenPoint = ViewportToScreenPoint(viewPortPoint);
    return ScreenToWorldPoint(screenPoint);
}

Vector3f Camera::ViewportToCameraPoint(const Vector3f &viewPort) const
{
    Vector3f ndc;
    Matrix4x4f invProjection;
    Matrix4x4f::Invert_Full(GetProjectionMatrix(), invProjection);

    ndc.x = Lerp(-1, 1, viewPort.x);
    ndc.y = Lerp(-1, 1, viewPort.y);
    ndc.z = Lerp(-1, 1, (viewPort.z - m_State.m_NearClip) / m_State.m_FarClip);

    Vector3f cameraPoint;
    invProjection.PerspectiveMultiplyPoint3(ndc, cameraPoint);

    cameraPoint.z = viewPort.z;

    return cameraPoint;
}

Ray Camera::ViewportPointToRay(const Vector2f& viewPortPos) const
{
    Vector3f screenPos = ViewportToScreenPoint(Vector3f(viewPortPos.x, viewPortPos.y, 0.0F));
    return ScreenPointToRay(Vector2f(screenPos.x, screenPos.y));
}

Vector3f Camera::ScreenToViewportPoint(const Vector3f& screenPos) const
{
    Rectf r = GetScreenViewportRect();
    float nx = (screenPos.x - r.x) / r.Width();
    float ny = (screenPos.y - r.y) / r.Height();
    return Vector3f(nx, ny, screenPos.z);
}

Vector3f Camera::ViewportToScreenPoint(const Vector3f& viewPos) const
{
    Rectf r = GetScreenViewportRect();
    float nx = viewPos.x * r.Width() + r.x;
    float ny = viewPos.y * r.Height() + r.y;
    return Vector3f(nx, ny, viewPos.z);
}

void Camera::CalculateViewportRayVectors(const Rectf& viewport, float z, MonoOrStereoscopicEye eye, Vector3f outRays[4]) const
{
    const Matrix4x4f& proj = (eye == kMonoOrStereoscopicEyeMono) ?  GetProjectionMatrix() : GetStereoProjectionMatrix(StereoscopicEye(eye));

    Matrix4x4f invProj;
    Matrix4x4f::Invert_Full(proj, invProj);

    // Convert [0,1] viewport coordinates to [-1,1] clip space.
    Rectf clipRect = viewport;
    clipRect.Scale(2.0f, 2.0f);
    clipRect.Move(-1.0f, -1.0f);

    // We transform a point further than near plane and closer than far plane, for precision reasons.
    // In a perspective camera setup (near=0.1, far=1000), a point at 0.95 projected depth is about
    // 5 units from the camera. See also CameraUnProject().
    const float projZ = 0.95f;
    invProj.PerspectiveMultiplyPoint3(Vector3f(clipRect.x, clipRect.y, projZ), outRays[0]);
    invProj.PerspectiveMultiplyPoint3(Vector3f(clipRect.x, clipRect.GetYMax(), projZ), outRays[1]);
    invProj.PerspectiveMultiplyPoint3(Vector3f(clipRect.GetXMax(), clipRect.GetYMax(), projZ), outRays[2]);
    invProj.PerspectiveMultiplyPoint3(Vector3f(clipRect.GetXMax(), clipRect.y, projZ), outRays[3]);

    // OpenGL view space is negative z forward but here we want positive z forward so flip.
    for (int r = 0; r < 4; ++r)
        outRays[r].z = -outRays[r].z;

    // Rescale vectors to have the desired z distance.
    // Using the inverse projected vectors directly causes precision issues for distant far planes,
    // like those used by the Scene view camera (20k+ far dist). See case 768097 and 769021.
    for (int r = 0; r < 4; ++r)
        outRays[r] *= z / outRays[r].z;
}

float Camera::CalculateFarPlaneWorldSpaceLength() const
{
    Rectf screenRect = GetScreenViewportRect();
    Vector3f p0 = ScreenToWorldPoint(Vector3f(screenRect.x, screenRect.y, m_State.m_FarClip));
    Vector3f p1 = ScreenToWorldPoint(Vector3f(screenRect.x + screenRect.width, screenRect.y, m_State.m_FarClip));

    return Magnitude(p0 - p1);
}

float Camera::CalculateNearPlaneWorldSpaceLength() const
{
    Rectf screenRect = GetScreenViewportRect();
    Vector3f p0 = ScreenToWorldPoint(Vector3f(screenRect.x, screenRect.y, m_State.m_NearClip));
    Vector3f p1 = ScreenToWorldPoint(Vector3f(screenRect.x + screenRect.width, screenRect.y, m_State.m_NearClip));
    return Magnitude(p0 - p1);
}

void Camera::SetDepth(float depth)
{
    SetDirty();
    m_State.m_Depth = depth;
    if (IsActive() && GetEnabled())
    {
        RemoveFromManager();
        AddToManager();
    }
}

void Camera::SetNormalizedViewportRect(const Rectf& normalizedRect)
{
    SetDirty();
    m_State.m_NormalizedViewPortRect = normalizedRect;
    WindowSizeHasChanged();
}

void Camera::WindowSizeHasChanged()
{
    if (m_State.m_ImplicitAspect)
        ResetAspect();
}

void Camera::SetAspect(float aspect)
{
    m_State.m_Aspect = aspect;
    m_State.m_DirtyProjectionMatrix = true;
    m_State.m_DirtySkyboxProjectionMatrix = true;
    m_State.m_DirtyWorldToClipMatrix = true;
    m_State.m_ImplicitAspect = false;
}

float Camera::GetAspect() const
{
    __FAKEABLE_METHOD__(Camera, GetAspect, ());
    return m_State.m_Aspect;
}

void Camera::ResetAspect()
{
    Rectf r = GetScreenViewportRect();
    if (r.Height() != 0)
        m_State.m_Aspect = (r.Width() / r.Height());
    else
        m_State.m_Aspect = 1.0f;

    m_State.m_DirtyProjectionMatrix = true;
    m_State.m_DirtySkyboxProjectionMatrix = true;
    m_State.m_DirtyWorldToClipMatrix = true;
    m_State.m_ImplicitAspect = true;
}

Vector3f Camera::GetPosition() const
{
    return GetComponent<Transform>().GetPosition();
}

inline bool IsMatrixValid(const Matrix4x4f& m)
{
    for (int i = 0; i < 16; i++)
    {
        if (!IsFinite(m.GetPtr()[i]))
            return false;
    }
    return true;
}

void Camera::GetImplicitWorldToCameraMatrix(Matrix4x4f& outMatrix) const
{
    outMatrix.SetScale(Vector3f(1.0F, 1.0F, -1.0F));
    outMatrix *= GetComponent<Transform>().GetWorldToLocalMatrixNoScale();
}

const Matrix4x4f& Camera::GetWorldToCameraMatrix() const
{
    if (m_State.m_DirtyWorldToCameraMatrix && m_State.m_ImplicitWorldToCameraMatrix)
    {
        GetImplicitWorldToCameraMatrix(m_State.m_WorldToCameraMatrix);
        m_State.m_DirtyWorldToCameraMatrix = false;
    }
    return m_State.m_WorldToCameraMatrix;
}

Matrix4x4f Camera::GetCameraToWorldMatrix() const
{
    Matrix4x4f m;
    Matrix4x4f::Invert_Full(GetWorldToCameraMatrix(), m);
    return m;
}

const Matrix4x4f& Camera::GetProjectionMatrix() const
{
    if (m_State.m_DirtyProjectionMatrix && m_State.m_ImplicitProjectionMatrix)
    {
        if (!m_State.m_Orthographic)
            m_State.m_ProjectionMatrix.SetPerspective(GetFov(), GetAspect(), m_State.m_NearClip, m_State.m_FarClip);
        else
            m_State.m_ProjectionMatrix.SetOrtho(-m_State.m_OrthographicSize * m_State.m_Aspect, m_State.m_OrthographicSize * m_State.m_Aspect, -m_State.m_OrthographicSize, m_State.m_OrthographicSize, m_State.m_NearClip, m_State.m_FarClip);

        m_State.m_DirtyProjectionMatrix = false;
    }
    return m_State.m_ProjectionMatrix;
}

void Camera::SetCullingMatrix(const Matrix4x4f& matrix)
{
    Assert(IsMatrixValid(matrix));
    m_State.m_CullingMatrix = matrix;
    m_State.m_ImplicitCullingMatrix = false;
}

const Matrix4x4f& Camera::GetCullingMatrix() const
{
    if (m_State.m_ImplicitCullingMatrix)
    {
        m_State.m_CullingMatrix = GetWorldToClipMatrix();
    }

    return m_State.m_CullingMatrix;
}

void Camera::UpdatePreviousViewProjectionMatrix()
{
    bool openGLStyle = GetGraphicsCaps().usesOpenGLTextureCoords;
    Matrix4x4f currProj = GetProjectionMatrix();
    GetUncheckedRealGfxDevice().CalculateDeviceProjectionMatrix(currProj, openGLStyle, !openGLStyle);
    MultiplyMatrices4x4(&currProj, &GetWorldToCameraMatrix(), &m_PrevFrameViewProj);
    m_IsNonJitteredProjMatrixSet = false;
}

const Matrix4x4f& Camera::GetNonJitteredProjectionMatrix() const
{
    return m_IsNonJitteredProjMatrixSet ? m_NonJitteredProjMatrix : GetProjectionMatrix();
}

void Camera::SetNonJitteredProjectionMatrix(const Matrix4x4f& projMatrix)
{
    m_IsNonJitteredProjMatrixSet = true;
    m_NonJitteredProjMatrix = projMatrix;
}

void Camera::GetSkyboxProjectionMatrix(float nearClip, Matrix4x4f& outMatrix) const
{
    if (m_State.m_ImplicitSkyboxProjectionMatrix && m_State.m_DirtySkyboxProjectionMatrix)
    {
        if (!m_State.m_Orthographic)
            m_State.m_SkyboxProjectionMatrix.SetPerspective(GetFov(), GetAspect(), m_State.m_NearClip, m_State.m_FarClip);
        else
            m_State.m_SkyboxProjectionMatrix.SetOrtho(-m_State.m_OrthographicSize * m_State.m_Aspect, m_State.m_OrthographicSize * m_State.m_Aspect, -m_State.m_OrthographicSize, m_State.m_OrthographicSize, m_State.m_NearClip, m_State.m_FarClip);

        m_State.m_DirtySkyboxProjectionMatrix = false;
    }

    outMatrix = m_State.m_SkyboxProjectionMatrix;
    outMatrix.AdjustDepthRange(m_State.m_NearClip, nearClip, m_State.m_FarClip);
}

void Camera::GetStereoSkyboxProjectionMatrix(StereoscopicEye eye, float nearClip, Matrix4x4f& outMatrix) const
{
    outMatrix = GetStereoProjectionMatrix(eye);
    outMatrix.AdjustDepthRange(m_State.m_NearClip, nearClip, m_State.m_FarClip);
}

void Camera::GetImplicitProjectionMatrix(float overrideNearPlane, Matrix4x4f& outMatrix) const
{
    if (!m_State.m_Orthographic)
        outMatrix.SetPerspective(GetFov(), GetAspect(), overrideNearPlane, m_State.m_FarClip);
    else
        outMatrix.SetOrtho(-m_State.m_OrthographicSize * m_State.m_Aspect, m_State.m_OrthographicSize * m_State.m_Aspect, -m_State.m_OrthographicSize, m_State.m_OrthographicSize, overrideNearPlane, m_State.m_FarClip);
}

void Camera::GetImplicitProjectionMatrix(float overrideNearPlane, float overrideFarPlane, float fov, float aspect, Matrix4x4f& outMatrix) const
{
    if (!m_State.m_Orthographic)
        outMatrix.SetPerspective(fov, aspect, overrideNearPlane, overrideFarPlane);
    else
        outMatrix.SetOrtho(-m_State.m_OrthographicSize * m_State.m_Aspect, m_State.m_OrthographicSize * m_State.m_Aspect, -m_State.m_OrthographicSize, m_State.m_OrthographicSize, overrideNearPlane, overrideFarPlane);
}

void Camera::SetWorldToCameraMatrix(const Matrix4x4f& matrix)
{
    Assert(IsMatrixValid(matrix));
    m_State.m_WorldToCameraMatrix = matrix;
    m_State.m_ImplicitWorldToCameraMatrix = false;
    m_State.m_DirtyWorldToClipMatrix = true;
}

void Camera::SetProjectionMatrix(const Matrix4x4f& matrix)
{
    Assert(IsMatrixValid(matrix));
    m_State.m_ProjectionMatrix = matrix;
    m_State.m_ImplicitProjectionMatrix = false;
    m_State.m_DirtyWorldToClipMatrix = true;

    // The skybox projection follows the camera's projection ONLY if it is not oblique
    // Water/reflection would set and oblique projection but requires the skybox to render with regular projection.
    if (!IsObliqueProjection(matrix))
    {
        m_State.m_ImplicitSkyboxProjectionMatrix = false;
        m_State.m_SkyboxProjectionMatrix = matrix;
    }
}

void Camera::ResetWorldToCameraMatrix()
{
    m_State.m_ImplicitWorldToCameraMatrix = true;
    m_State.m_DirtyWorldToCameraMatrix = true;
    m_State.m_DirtyWorldToClipMatrix = true;
}

void Camera::ResetProjectionMatrix()
{
    m_State.m_ImplicitProjectionMatrix = true;
    m_State.m_DirtyProjectionMatrix = true;
    m_State.m_DirtyWorldToClipMatrix = true;
    m_State.m_ImplicitSkyboxProjectionMatrix = true;
    m_State.m_DirtySkyboxProjectionMatrix = true;
}

const Matrix4x4f& Camera::GetWorldToClipMatrix() const
{
    if (m_State.m_DirtyWorldToClipMatrix)
    {
        MultiplyMatrices4x4(&GetProjectionMatrix(), &GetWorldToCameraMatrix(), &m_State.m_WorldToClipMatrix);
        m_State.m_DirtyWorldToClipMatrix = false;
    }
    return m_State.m_WorldToClipMatrix;
}

void Camera::GetClipToWorldMatrix(Matrix4x4f& outMatrix) const
{
    Matrix4x4f::Invert_Full(GetWorldToClipMatrix(), outMatrix);
}

template<typename T, size_t dstCount>
static inline void CopyCountAndNullTheRest(T(&dst)[dstCount], const T* src, size_t count)
{
    ::memcpy(dst, src, count * sizeof(T));
    if (count < dstCount)
        ::memset(&dst[count], 0x00, (dstCount - count) * sizeof(T));
}

void Camera::SetTargetTextureBuffers(RenderTexture* tex, int colorCount, RenderSurfaceHandle* color, RenderSurfaceHandle depth, RenderTexture** rbOrigin)
{
    // NB about usage of rbOrigin[0] or m_State.m_TargetBuffersOriginatedFrom[0]
    // we do extra checks when setting target buffers to not mix screen/RT buffers, so simply checking first buffer is enough

    if (m_State.m_TargetTexture == PPtr<RenderTexture>(tex))
    {
        bool buffSame =     colorCount == m_State.m_TargetColorBufferCount
            &&  ::memcmp(color, m_State.m_TargetColorBuffer, colorCount * sizeof(RenderSurfaceHandle)) == 0
            &&  depth == m_State.m_TargetDepthBuffer;

        if (tex != 0 || buffSame)
            return;
    }

    const bool isAdded = IsAddedToManager();

    bool wasCurrent = false;
    bool wasOffscreen = false;
    if (isAdded)
    {
        // Only do this for cameras that are enabled right now, particularly m_State.m_TargetTexture PPtr resolve
        // below is dangerous to do in case we might be destroying this camera at this very moment.
        wasCurrent = GetRenderManager().GetCurrentCameraPtr() == this;
        wasOffscreen = (RenderTexture*)m_State.m_TargetTexture != 0 || m_State.m_TargetBuffersOriginatedFrom[0] != 0;
    }

    m_CurrentTargetTexture = m_State.m_TargetTexture = tex;

    CopyCountAndNullTheRest(m_State.m_TargetColorBuffer, color, colorCount);
    CopyCountAndNullTheRest(m_State.m_TargetBuffersOriginatedFrom, rbOrigin, colorCount);

    m_State.m_TargetColorBufferCount = colorCount;
    m_State.m_TargetDepthBuffer = depth;

    // make sure we reset camera aspect if needed (when drawing to RT/RB with aspect different from current)
    WindowSizeHasChanged();

    SetDirty();
    if (isAdded)
    {
        // special case: if we were rendering to offscreen camera and changed rt in process - just update it
        // other possible cases:
        //    wasn't current: nothing changes (? maybe check that was rendered already, what was the intention?)
        //    onscreen -> offscreen: we shouldn'd draw in here in that pass (and if we really wants?)
        //    offscreen -> onscreen: will be correctly drawn next time we draw onscreen cameras
        if (wasCurrent && wasOffscreen && (tex || rbOrigin[0]))
        {
            DebugAssert(GetCurrentCameraStackState().GetCurrentCamera() == this);
            GetCurrentCameraStackState().UpdateCameraTargetTexture(tex);
        }
        else
        {
            GetRenderManager().RemoveCamera(this);
            GetRenderManager().AddCamera(this);
        }
    }
}

void Camera::SetTargetBuffers(int colorCount, RenderSurfaceHandle* color, RenderSurfaceHandle depth, RenderTexture** originatedFrom)
{
    SetTargetTextureBuffers(0, colorCount, color, depth, originatedFrom);
}

void Camera::SetTargetBuffersScript(int colorCount, const ScriptingRenderBuffer* colorScript, ScriptingRenderBuffer* depthScript)
{
    #define RETURN_WITH_ERROR(msg)  do { ErrorString(msg); return; } while(0)

    RenderSurfaceHandle color[kMaxSupportedRenderTargets];
    RenderTexture*      colorRT[kMaxSupportedRenderTargets] = {};
    for (int i = 0; i < colorCount; ++i)
    {
        RenderSurfaceBase*  rs = colorScript[i].m_BufferPtr;
        PPtr<RenderTexture> rt = PPtr<RenderTexture>(colorScript[i].m_RenderTextureInstanceID);

        color[i]    = rs ? RenderSurfaceHandle(rs) : GetGfxDevice().GetBackBufferColorSurface();
        colorRT[i]  = rt.IsNull() ? 0 : (RenderTexture*)rt;
    }

    RenderSurfaceHandle depth = depthScript->m_BufferPtr ? RenderSurfaceHandle(depthScript->m_BufferPtr) : GetGfxDevice().GetBackBufferDepthSurface();

    // check rt/screen originated (cant mix)
    // TODO: maybe we should simply check backBuffer flag?
    const bool colorRTIsNull    = colorRT[0] == 0;
    const bool depthRTIsNull    = PPtr<RenderTexture>(depthScript->m_RenderTextureInstanceID).IsNull();

    for (int i = 1; i < colorCount; ++i)
    {
        if ((colorRT[i] == 0) != colorRTIsNull)
            RETURN_WITH_ERROR("You're trying to mix color buffers from RenderTexture and from screen.");
    }
    if (colorRTIsNull != depthRTIsNull)
        RETURN_WITH_ERROR("You're trying to mix color and depth buffers from RenderTexture and from screen.");


    // check that we have matching exts
    {
        int colorW = color[0].object->width;
        int colorH = color[0].object->height;
        int depthW = depth.object->width;
        int depthH = depth.object->height;

        for (int i = 1; i < colorCount; ++i)
        {
            int w = color[i].object->width;
            int h = color[i].object->height;
            if (colorW != w || colorH != h)
                RETURN_WITH_ERROR("Camera.SetTargetBuffers can only accept RenderBuffers with same size.");
        }

        if (colorW != depthW || colorH != depthH)
            RETURN_WITH_ERROR("Camera.SetTargetBuffers can only accept RenderBuffers with same size.");
    }

    SetTargetTextureBuffers(0, colorCount, color, depth, colorRT);

    m_BuffersSetFromScripts = true; // camera should favour these texture buffer values over m_CurrentTargetTexture

    return;
    #undef RETURN_WITH_ERROR
}

void Camera::SetTargetTexture(RenderTexture *tex)
{
    if (tex)
        tex->Create();

    RenderSurfaceHandle color = tex ? tex->GetColorSurfaceHandle() : GetGfxDevice().GetBackBufferColorSurface();
    RenderSurfaceHandle depth = tex ? tex->GetDepthSurfaceHandle() : GetGfxDevice().GetBackBufferDepthSurface();
    SetTargetTextureBuffers(tex, 1, &color, depth, &tex);

    m_BuffersSetFromScripts = false;    // camera should favour the m_CurrentTargetTexture value
}

void Camera::CopyFrom(const Camera& other)
{
    // copy transform from other
    Transform& transform = GetComponent<Transform>();
    const Transform& otherTransform = other.GetComponent<Transform>();
    transform.SetLocalScale(otherTransform.GetLocalScale());
    transform.SetPosition(otherTransform.GetPosition());

    // normalize this... the camera can come from a very deep
    // hierarchy. This can lead to float rounding errors :(
    Quaternionf quat = Normalize(otherTransform.GetRotation());
    transform.SetRotation(quat);

    // copy layer of this gameobject from other
    GetGameObject().SetLayer(other.GetGameObject().GetLayer());

    // copy camera's variables from other
    m_State = other.m_State;

    SetDirty();
}

void Camera::GetTemporarySettings(CameraTemporarySettings& settings) const
{
    settings.renderingPath = m_State.m_RenderingPath;
    settings.fieldOfView = m_State.m_FieldOfView;
    settings.aspect = m_State.m_Aspect;
    settings.implicitAspect = m_State.m_ImplicitAspect;
}

void Camera::SetTemporarySettings(const CameraTemporarySettings& settings)
{
    m_State.m_RenderingPath = settings.renderingPath;
    m_State.m_FieldOfView = settings.fieldOfView;
    m_State.m_Aspect = settings.aspect;
    m_State.m_ImplicitAspect = settings.implicitAspect;
    m_State.m_DirtyProjectionMatrix = true;
    m_State.m_DirtySkyboxProjectionMatrix = true;
    m_State.m_DirtyWorldToClipMatrix = true;
}

void Camera::SetReplacementShader(Shader* shader, const core::string& replacementTag)
{
    m_State.m_ReplacementShader = shader;
    m_State.m_ReplacementTag = replacementTag;
}

void Camera::ResetReplacementShader()
{
    m_State.m_ReplacementShader.SetInstanceID(InstanceID_None);
    m_State.m_ReplacementTag.clear();
}

void Camera::SetFov(float deg)
{
    if (ShouldUseVRFieldOfView())
    {
        WarningStringObject("Cannot set field of view on this camera while VR is enabled.", this);
        return;
    }

    SetDirty();

    m_State.m_FieldOfView = deg;
    m_State.m_DirtyProjectionMatrix = true;
    m_State.m_DirtySkyboxProjectionMatrix = true;
    m_State.m_DirtyWorldToClipMatrix = true;
}

float Camera::GetFov() const
{
    __FAKEABLE_METHOD__(Camera, GetFov, ());
    if (ShouldUseVRFieldOfView())
    {
        float vrDeviceFieldOfView = GetIVRDevice()->GetFieldOfView();
        if (m_State.m_FieldOfView != vrDeviceFieldOfView)
        {
            m_State.m_FieldOfViewBeforeEnablingVRMode = m_State.m_FieldOfView;
        }
        m_State.m_FieldOfView = vrDeviceFieldOfView;
    }
    return m_State.m_FieldOfView;
}

void Camera::ResetFieldOfView()
{
    m_State.m_FieldOfView = 60.0f;
}

void Camera::RestoreFovToPreVRModeValue()
{
    if (m_State.m_FieldOfViewBeforeEnablingVRMode > 0.0f)
    {
        SetFov(m_State.m_FieldOfViewBeforeEnablingVRMode);
        m_State.m_FieldOfViewBeforeEnablingVRMode = -1.0f;
    }
}

void Camera::SetNear(float n)
{
    SetDirty();
    m_State.m_NearClip = n;
    m_State.m_DirtyProjectionMatrix = true;
    m_State.m_DirtySkyboxProjectionMatrix = true;
    m_State.m_DirtyWorldToClipMatrix = true;
}

float Camera::GetNear() const
{
    __FAKEABLE_METHOD__(Camera, GetNear, ());
    return m_State.m_NearClip;
}

void Camera::SetFar(float f)
{
    SetDirty();
    m_State.m_FarClip = f;
    m_State.m_DirtyProjectionMatrix = true;
    m_State.m_DirtySkyboxProjectionMatrix = true;
    m_State.m_DirtyWorldToClipMatrix = true;
}

float Camera::GetFar() const
{
    __FAKEABLE_METHOD__(Camera, GetFar, ());
    return m_State.m_FarClip;
}

float Camera::GetProjectionNear() const
{
    if (m_State.m_ImplicitProjectionMatrix)
        return m_State.m_NearClip;

    const Matrix4x4f& proj = GetProjectionMatrix();
    if (IsNonStandardProjection(proj))
        return m_State.m_NearClip;

    Vector4f nearPlane = proj.GetRow(3) + proj.GetRow(2);
    Vector3f nearNormal(nearPlane.x, nearPlane.y, nearPlane.z);
    return -nearPlane.w / Magnitude(nearNormal);
}

float Camera::GetProjectionFar() const
{
    if (m_State.m_ImplicitProjectionMatrix)
        return m_State.m_FarClip;

    const Matrix4x4f& proj = GetProjectionMatrix();
    if (IsNonStandardProjection(proj))
        return m_State.m_FarClip;

    Vector4f farPlane = proj.GetRow(3) - proj.GetRow(2);
    Vector3f farNormal(farPlane.x, farPlane.y, farPlane.z);
    return farPlane.w / Magnitude(farNormal);
}

void Camera::SetOrthographicSize(float f)
{
    SetDirty();
    m_State.m_OrthographicSize = f;
    m_State.m_DirtyProjectionMatrix = true;
    m_State.m_DirtySkyboxProjectionMatrix = true;
    m_State.m_DirtyWorldToClipMatrix = true;
}

void Camera::SetOrthographic(bool v)
{
    SetDirty();
    m_State.m_Orthographic = v;
    m_State.m_DirtyProjectionMatrix = true;
    m_State.m_DirtySkyboxProjectionMatrix = true;
    m_State.m_DirtyWorldToClipMatrix = true;
}

void Camera::SetBackgroundColor(const ColorRGBAf& color)
{
    m_State.m_BackGroundColor = color;
    SetDirty();
}

void Camera::SetClearFlags(int flags)
{
    m_State.m_ClearFlags = flags;
    SetDirty();
}

void Camera::SetCullingMask(UInt32 cullingMask)
{
    m_State.m_CullingMask.m_Bits = cullingMask;
    SetDirty();
}

void Camera::SetEventMask(UInt32 eventMask)
{
    m_State.m_EventMask.m_Bits = eventMask;
    SetDirty();
}

std::vector<core::string> Camera::GetCameraBufferWarnings() const
{
    std::vector<core::string> warnings;

    RenderingPath path = CalculateRenderingPath();
    if (GetQualitySettings().GetCurrent().antiAliasing == 0 && m_State.m_AllowMSAA)
        warnings.push_back("MSAA is requested by the camera but not enabled in quality settings. This camera will render without MSAA buffers. If you want MSAA enable it in the quality settings.");
    if (m_State.m_AllowMSAA && (path == kRenderPathDeferred || path == kRenderPathPrePass))
        warnings.push_back("Deferred and MultisampleAntiAliasing is not supported. This camera will render without MSAA buffers. Disable Deferred if you want to use MSAA.");
    if (!GetGraphicsCaps().supportsRenderTextureFormat[GetGfxDevice().GetDefaultHDRRTFormat()])
        warnings.push_back("HDR RenderTexture format is not supported on this platform. This camera will render without HDR buffers.");

    return warnings;
}

void Camera::OnRenderSurfaceDestroyed(RenderSurfaceHandle rs, RenderTexture* originRT)
{
    for (unsigned ci = 0, cn = s_AllCamera.size(); ci < cn; ++ci)
    {
        Camera* cam = s_AllCamera[ci]; CopiableState& state = cam->m_State;

        const bool sameTargetRT     = originRT && originRT->GetInstanceID() == state.m_TargetTexture.GetInstanceID();
        const bool sameCurrentRT    = originRT && cam->m_CurrentTargetTexture && originRT->GetInstanceID() == cam->m_CurrentTargetTexture->GetInstanceID();
        const bool sameDepthRS      = rs == state.m_TargetDepthBuffer;

        bool sameColorRS = false;
        {
            RenderSurfaceHandle* color = state.m_TargetColorBuffer;
            for (unsigned bi = 0, bn = state.m_TargetColorBufferCount; bi < bn && !sameColorRS; ++bi)
                sameColorRS = (rs == color[bi]);
        }

        if (sameTargetRT || sameColorRS || sameDepthRS)
        {
            state.m_TargetColorBuffer[0]    = RenderSurfaceHandle();
            state.m_TargetDepthBuffer       = RenderSurfaceHandle();
            state.m_TargetColorBufferCount = 1;
        }
        if (sameCurrentRT)
            cam->m_CurrentTargetTexture = 0;

        // special case: if we set Camera's RenderBuffers through Camera.SetTargetBuffers, targetTexture is null
        // so render buffers are becoming invalid without any way to automatically restore them.
        if (state.m_TargetTexture.GetInstanceID() == InstanceID_None && (sameColorRS || sameDepthRS) && cam->GetEnabled())
            ErrorStringObject("Releasing render texture whose render buffer is set as Camera's target buffer with Camera.SetTargetBuffers!", cam);
    }
}

void Camera::OnRenderTextureDestroyed(RenderTexture* rt)
{
    if (rt == 0)
        return;
#if UNITY_EDITOR
    // unlike player, editor might reimport RenderTexture on the fly which will involve deleting RT
    // to avoid corner cases we skip persistent RTs (PPtr magic will make sure that things do work)
    if (rt->IsPersistent())
        return;
#endif

    for (unsigned ci = 0, cn = s_AllCamera.size(); ci < cn; ++ci)
    {
        Camera* cam = s_AllCamera[ci];
        const bool sameRT = rt->GetInstanceID() == cam->m_State.m_TargetTexture.GetInstanceID();
        if (sameRT)
        {
            cam->SetTargetTexture((RenderTexture*)0);
            if (cam->GetEnabled())
                ErrorStringObject("Releasing render texture that is set as Camera.targetTexture!", cam);
        }
    }
}

bool Camera::GetRenderImmediateObjects() const
{
#if UNITY_EDITOR
    return m_OnlyRenderIntermediateObjects;
#else
    return false;
#endif
}

bool Camera::ApplyRenderTexture()
{
    // while we could return const ref (and grab address and use uniformly)
    // we pass non const pointer to SetActive (because surfaces can be reset internally)
    // so create local handle copy if we draw to real texture
    RenderSurfaceHandle rtcolor = m_CurrentTargetTexture ? m_CurrentTargetTexture->GetColorSurfaceHandle() : RenderSurfaceHandle();

    RenderSurfaceHandle defaultColor[kMaxSupportedRenderTargets];
    CompileTimeAssert(sizeof(defaultColor) == sizeof(m_State.m_TargetColorBuffer), "defaultColor array size needs to be updated!");
    memcpy(defaultColor, m_State.m_TargetColorBuffer, sizeof(defaultColor));

    if (!defaultColor[0].IsValid())
        defaultColor[0] = GetGfxDevice().GetBackBufferColorSurface();
    RenderSurfaceHandle defaultDepth = m_State.m_TargetDepthBuffer;
    if (!defaultDepth.IsValid())
        defaultDepth = GetGfxDevice().GetBackBufferDepthSurface();

    RenderSurfaceHandle* color  = m_CurrentTargetTexture ? &rtcolor : defaultColor;
    RenderSurfaceHandle  depth  = m_CurrentTargetTexture ? m_CurrentTargetTexture->GetDepthSurfaceHandle() : defaultDepth;
    int                  count  = m_CurrentTargetTexture ? 1 : m_State.m_TargetColorBufferCount;
    RenderTexture**      rt     = m_CurrentTargetTexture ? &m_CurrentTargetTexture : m_State.m_TargetBuffersOriginatedFrom;

    // if we have configured a depth buffer in scripts be sure to favour it over the m_CurrentTargetTexture or defaultDepth
    if (m_BuffersSetFromScripts)
        depth = m_State.m_TargetDepthBuffer;

    // if we have set buffers from scripts we don't want calls to ApplyRenderTexture to changes that behaviour (e.g. at end of RenderForwardShadowMaps)
    if ((!m_CurrentTargetTexture) && (!m_BuffersSetFromScripts))
        m_CurrentTargetTexture = rt[0];

    SinglePassStereo singlePassStereo = GetSinglePassStereo();
    bool bindAllSlices = (m_CurrentTargetTexture != NULL) && ((singlePassStereo == kSinglePassStereoInstancing) || (singlePassStereo == kSinglePassStereoMultiview));
    RenderTexture::SetActive(count, color, depth, rt, 0, kCubeFaceUnknown, bindAllSlices ? -1 : 0, RenderTexture::kFlagDontSetViewport);

    bool backBuffer = color->IsValid() && color[0].object->backBuffer;
    return backBuffer;
}

void Camera::SetRenderTargetAndViewport()
{
    m_CurrentTargetTexture = EnsureRenderTextureIsCreated(m_CurrentTargetTexture);
    bool backBuffer = ApplyRenderTexture();

    Rectf viewport = backBuffer ? GetPhysicalViewportRect() : GetRenderRectangle();
    if (GetRenderBufferManager().GetActiveVRUsage())
    {
        viewport.SetPosition(Vector2f::zero);
    }
    RectInt viewcoord = RectfToRectInt(viewport);
    GetGfxDevice().SetViewport(viewcoord);
}

void Camera::SetTargetDisplay(int targetDisplay)
{
    m_State.m_TargetDisplay = targetDisplay;
    SetDirty();
    WindowSizeHasChanged();
}

void Camera::SetStereoTargetEye(TargetEyeMask stereoTargetEye)
{
    if (stereoTargetEye == m_State.m_TargetEye)
        return;

    m_State.m_TargetEye = stereoTargetEye;

    if (!GetIVRDevice())
        return;

    if (stereoTargetEye == kTargetEyeMaskNone)
        GetIVRDevice()->RemoveCameraReferenceTransform(*this);
    else
        GetIVRDevice()->InsertCameraReferenceTransform(*this);
}

bool Camera::IsCurrentlyRendering() const
{
    return m_IsRendering;
}

#if UNITY_EDITOR
bool Camera::IsFiltered(GameObject& gameObject) const
{
    return IsGameObjectFiltered(gameObject, (CullFiltering)m_FilterMode);
}

#endif

void Camera::InvokeRenderPlaneCallbacks(const RenderPlane plane)
{
    const RenderPlaneCallbacks::iterator end = m_RenderPlaneCallbacks.end();
    for (RenderPlaneCallbacks::iterator it = m_RenderPlaneCallbacks.begin(); it != end; ++it)
    {
        if (it->plane == plane)
        {
            it->cb(*this, it->userData);
        }
    }
}

bool Camera::ShouldUseVRFieldOfView() const
{
    __FAKEABLE_METHOD__(Camera, ShouldUseVRFieldOfView, ());
    return GetIVRDevice() && GetIVRDevice()->GetOverrideFieldOfView() && GetStereoEnabled()
        && ((IsWorldPlaying() && GetCameraType() == kCameraTypeGame) || GetCameraType() == kCameraTypeVR);
}

IMPLEMENT_REGISTER_CLASS(Camera, 20);
IMPLEMENT_OBJECT_SERIALIZE(Camera);


void ClearWithSkybox(bool clearDepth, Camera const* camera)
{
    if (!camera)
        return;

    Material* skybox = camera->GetSkyboxMaterial();
    if (!skybox)
        return;

    Matrix4x4f projMatrix;
    camera->GetSkyboxProjectionMatrix(camera->GetNear(), projMatrix);
    const Matrix4x4f& viewMatrix = camera->GetWorldToCameraMatrix();
    GraphicsHelper::SetWorldViewAndProjection(GetGfxDevice(), NULL, &viewMatrix, &projMatrix);

    SetClippingPlaneShaderProps();

    if (clearDepth)
    {
        ColorRGBAf zero(0, 0, 0, 0);
        GraphicsHelper::Clear(kGfxClearDepthStencil, zero, 1.0f, 0, GetDefaultPassContext());
        GPU_TIMESTAMP();
    }
    Skybox::RenderSkybox(skybox, *camera);
}

Rectf GetCameraOrWindowRect(const Camera* camera)
{
    if (camera)
        return camera->GetScreenViewportRect();
    else
    {
        Rectf rect = GetScreenManager().GetRect();
        rect.x = rect.y = 0.0f;
        return rect;
    }
}

RenderTextureFormat GetRenderTextureColorFormat(bool wantsHDR, bool forDeferred, bool needsWideAlpha)
{
    const TierGraphicsSettings& settings = GetGraphicsSettings().GetTierSettings();
    bool hdr = settings.useHDR && wantsHDR;

    // gles 2 does not support mixed bit depth rendering
    // so stop that here!
    GfxDeviceRenderer renderer = GetGfxDevice().GetRenderer();
    if (forDeferred && renderer == kGfxRendererOpenGLES20)
        hdr = false;

    if (hdr)
    {
        const HDRMode hdrMode = settings.hdrMode;
        if (GetGraphicsCaps().supportsRenderTextureFormat[kRTFormatARGBHalf] && hdrMode == kHDRModeFP16)
            return kRTFormatARGBHalf;

        if (GetGraphicsCaps().supportsRenderTextureFormat[kRTFormatR11G11B10Float] && hdrMode == kHDRModeR11G11B10Float)
            return kRTFormatR11G11B10Float;

        // fallback
        if (GetGraphicsCaps().supportsRenderTextureFormat[kRTFormatARGBHalf])
            return kRTFormatARGBHalf;
    }

    RenderTextureFormat format = kRTFormatDefault;
    if (!needsWideAlpha && GetGraphicsCaps().supportsRenderTextureFormat[kRTFormatA2R10G10B10])
        format = kRTFormatA2R10G10B10;

    // If we are creating a temp texture, ensure that the temp texture's color format
    // matches the eye texture's format so that we can resolve the temp texture
    // directly into the eye texture.
    if (format == kRTFormatDefault && GetIVRDevice())
    {
        RenderTexture* activeEyeTex = GetIVRDevice()->GetActiveEyeTexture(kStereoscopicEyeLeft);
        if (activeEyeTex != NULL)
        {
            format = activeEyeTex->GetColorFormat();
        }
    }

    return format;
}

RenderTexture *Camera::GetTargetTexture() const { return m_State.m_TargetTexture; }
Shader *Camera::GetReplacementShader() const { return m_State.m_ReplacementShader; }

dynamic_array<Camera*> Camera::s_AllCamera;
