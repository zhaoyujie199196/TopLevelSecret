#ifndef INTERMEDIATE_RENDERER_H
#define INTERMEDIATE_RENDERER_H

#include "BaseRenderer.h"
#include "AssetUsers.h"
#include "SceneNode.h"
#include "Runtime/Shaders/Material.h"
#include "Runtime/Modules/ExportModules.h"
#include "Runtime/Utilities/MemoryPool.h"

class Camera;
class Matrix4x4f;
class Mesh;
class ShaderPropertySheet;
class SharedGfxBuffer;
namespace UI
{ class Canvas; }

class EXPORT_COREMODULE IntermediateRenderer : public BaseRenderer
{
public:
    static MemLabelRef kMemShaderProperty;

    IntermediateRenderer();
    virtual ~IntermediateRenderer();

    void Initialize(const Matrix4x4f& matrix, const AABB& localAABB, PPtr<Material> material, int layer, ShadowCastingMode shadowCasting, bool receiveShadows);

    // BaseRenderer
    virtual UInt32 GetLayerMask() const { return 1 << m_Layer; }
    virtual int GetLayer() const { return m_Layer; }
    virtual int GetMaterialCount() const { return 1; }
    virtual PPtr<Material> GetMaterial(int i) const { return m_Material; }

    // IntermediateRenderer won't own nor change the pointer.
    void AssignExternalCustomProperties(ShaderPropertySheet* properties);
    void CopyCustomPropertiesFrom(const ShaderPropertySheet& properties);  // Make sure properties hash is computed.

    #if UNITY_EDITOR
    InstanceID GetComponentInstanceID() const { return m_InstanceID; }
    void SetComponentInstanceID(InstanceID id) { m_InstanceID = id; }
    #endif

    const AABB& GetCachedWorldAABB() const { return m_RendererData.m_TransformInfo.worldAABB; }

protected:
    PPtr<Material>                  m_Material;
    ShaderPropertySheet*            m_Properties;
    int                             m_Layer;

    #if UNITY_EDITOR
    InstanceID                      m_InstanceID;
    #endif

    ShaderPropertySheet* GetWritableSharedProperties();
    void UnshareProperties();
};


class EXPORT_COREMODULE MeshIntermediateRenderer : public IntermediateRenderer, private AssetUser
{
public:
    MeshIntermediateRenderer();
    virtual ~MeshIntermediateRenderer();

    void Initialize(const Matrix4x4f& matrix, Mesh* mesh, const AABB& localAABB, PPtr<Material> material, int layer, ShadowCastingMode shadowCasting, bool receiveShadows, int submeshIndex);
    Mesh* GetMesh() { return m_Mesh; }

    // BaseRenderer
    virtual UInt32 AddAsRenderNode(RenderNodeQueue& queue, const DeprecatedSourceData& sourceData);

#if GFX_ENABLE_DRAW_CALL_BATCHING
    virtual bool AllowsBatching() const { return true; }
#endif
    virtual int GetSubsetIndex(int i) const { return m_SubMeshIndex; }

    static void StaticInitialize(void*);
    static void StaticDestroy(void*);

private:
    // Note: not using per-frame linear allocator, because in the editor
    // it can render multiple frames using single player loop run (e.g. when editor is paused).
    // Clearing per-frame data and then trying to use it later leads to Bad Things.
    DECLARE_POOLED_ALLOC(MeshIntermediateRenderer)

    // AssetUser
    virtual void OnAssetDeleted() { m_Mesh = NULL; }
    virtual void OnAssetBoundsChanged() {}

    ListNode<AssetUser> m_Node;
    Mesh* m_Mesh;
    int   m_SubMeshIndex;
};


class EXPORT_COREMODULE CanvasBatchIntermediateRenderer : public IntermediateRenderer, private AssetUser
{
public:
    struct InternalSubBatch
    {
        DrawBuffersRange drawBufferRange;
        const ShaderPropertySheet* properties; // Note: this is a copy of the passed in property sheet
    };

    CanvasBatchIntermediateRenderer();
    virtual ~CanvasBatchIntermediateRenderer();

    void Initialize(UI::Canvas* canvas, SharedGfxBuffer* vertexBuffer, VertexDeclaration* vertexDeclaration, UInt32 vertexStride, SharedGfxBuffer* indexBuffer, const Matrix4x4f& matrix, UInt16 distanceSortingOrder, const AABB& localAABB, PPtr<Material> material, int layer, ShadowCastingMode shadowCasting, bool receiveShadows);
    void AddSubBatch(const DrawBuffersRange&, const ShaderPropertySheet* properties);

    static void StaticInitialize(void*);
    static void StaticDestroy(void*);

    // BaseRenderer
    virtual UInt32 AddAsRenderNode(RenderNodeQueue& queue, const DeprecatedSourceData& sourceData);

private:
    virtual void OnAssetDeleted();
    virtual void OnAssetBoundsChanged() {}


    void CleanupSubBatchProperties();

    // Note: not using per-frame linear allocator, because in the editor
    // it can render multiple frames using single player loop run (e.g. when editor is paused).
    // Clearing per-frame data and then trying to use it later leads to Bad Things.
    DECLARE_POOLED_ALLOC(CanvasBatchIntermediateRenderer)

    ListNode<AssetUser> m_Node;
    SharedGfxBuffer* m_VertexBuffer;
    SharedGfxBuffer* m_IndexBuffer;
    UInt32 m_VertexStride;
    VertexDeclaration* m_VertexDeclaration;
    SInt16 m_SameDistanceSortPriority;
    dynamic_array<InternalSubBatch> m_SubBatches;
};

class IntermediateRenderers
{
public:
    void Clear(size_t startIndex = 0);

    const AABB*      GetBoundingBoxes() const;
    const SceneNode* GetSceneNodes() const;
    size_t           GetRendererCount() const { return m_BoundingBoxes.size(); }

    void Add(IntermediateRenderer* renderer);

private:
    dynamic_array<SceneNode> m_SceneNodes;
    dynamic_array<AABB>      m_BoundingBoxes;
};

IntermediateRenderer*  AddMeshIntermediateRenderer(const Matrix4x4f& matrix, Mesh* mesh, PPtr<Material> material, int layer, ShadowCastingMode shadowCasting, bool receiveShadows, int submeshIndex, Camera* camera);
IntermediateRenderer*  AddMeshIntermediateRenderer(const Matrix4x4f& matrix, Mesh* mesh, const AABB& localAABB, PPtr<Material> material, int layer, ShadowCastingMode shadowCasting, bool receiveShadows, int submeshIndex , Camera* camera);

CanvasBatchIntermediateRenderer*  AddCanvasIntermediateRenderer(UI::Canvas* canvas, SharedGfxBuffer* vertexBuffer, VertexDeclaration* vertexDeclaration, UInt32 vertexStride, SharedGfxBuffer* indexBuffer, const Matrix4x4f& matrix, UInt16 distanceSortOrder, const AABB& localAABB, PPtr<Material> material, int layer, ShadowCastingMode shadowCasting, bool receiveShadows, Camera* camera);

void AddIntermediateRenderer(IntermediateRenderer* renderer , Camera* camera);

#endif
