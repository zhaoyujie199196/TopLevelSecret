#include "UnityPrefix.h"
#include "CameraUtil.h"
#include "Runtime/GfxDevice/GfxDevice.h"
#include "RenderManager.h"
#include "Runtime/Graphics/ScreenManager.h"
#include "Runtime/Geometry/Plane.h"
#include "Runtime/Graphics/ScreenManager.h"
#include "Runtime/Graphics/RenderSurface.h"
#include "Runtime/Graphics/GraphicsHelper.h"

void LoadPixelMatrix(const Rectf& screenRect, GfxDevice& device, bool setMatrix)
{
    Matrix4x4f ortho;
    CalcPixelMatrix(screenRect, ortho);
    device.SetProjectionMatrix(ortho);
    if (setMatrix)
        device.SetViewMatrix(Matrix4x4f::identity);  // implicitly sets world to identity
}

void LoadFullScreenOrthoMatrix(float nearPlane, float farPlane, GfxDevice& device)
{
    Matrix4x4f matrix;
    matrix.SetOrtho(0.0f, 1.0f, 0.0f, 1.0f, nearPlane, farPlane);
    device.SetProjectionMatrix(matrix);
    device.SetViewMatrix(Matrix4x4f::identity);  // implicitly sets world to identity
}

void SetupPixelCorrectCoordinates()
{
    GfxDevice& device = GetGfxDevice();

    Rectf rect = GetScreenManager().GetRect();
    RectInt screenRect = RectfToRectInt(rect);
    device.SetViewport(screenRect);

    LoadPixelMatrix(rect, device, true);
}

Rectf RectIntToRectf(const RectInt& r)
{
    return Rectf(r.x, r.y, r.width, r.height);
}

RectInt RectfToRectInt(const Rectf& r)
{
    // We have to take care that the viewport doesn't exceed the buffer size (case 569703).
    // Bad rounding to integer makes D3D11 crash and burn.
    RectInt result;
    result.x = RoundfToInt(r.x);
    result.y = RoundfToInt(r.y);
    result.SetRight(RoundfToIntPos(r.GetRight()));
    result.SetBottom(RoundfToIntPos(r.GetBottom()));
    return result;
}

bool CameraProject(const Vector3f& p, const Matrix4x4f& cameraToWorld, const Matrix4x4f& worldToClip, const RectInt& viewport, Vector3f& outP, bool offscreen)
{
    Vector3f clipPoint;
    if (worldToClip.PerspectiveMultiplyPoint3(p, clipPoint))
    {
        Vector3f cameraPos = cameraToWorld.GetPosition();
        Vector3f dir = p - cameraPos;
        // The camera/projection matrices follow OpenGL convention: positive Z is towards the viewer.
        // So negate it to get into Unity convention.
        Vector3f forward = -cameraToWorld.GetAxisZ();
        float dist = Dot(dir, forward);

        outP.x = viewport.x + (1.0f + clipPoint.x) * viewport.width * 0.5f;
        outP.y = viewport.y + (1.0f + clipPoint.y) * viewport.height * 0.5f;
        //outP.z = (1.0f + clipPoint.z) * 0.5f;
        outP.z = dist;

        return true;
    }

    outP.Set(0.0f, 0.0f, 0.0f);
    return false;
}

bool CameraUnProject(const Vector3f& p, const Matrix4x4f& cameraToWorld, const Matrix4x4f& clipToWorld, const RectInt& viewport, Vector3f& outP, bool offscreen)
{
    // pixels to -1..1
    Vector3f in;
    in.x = (p.x - viewport.x) * 2.0f / viewport.width - 1.0f;
    in.y = (p.y - viewport.y) * 2.0f / viewport.height - 1.0f;
    // It does not matter where the point we unproject lies in depth; so we choose 0.95, which
    // is further than near plane and closer than far plane, for precision reasons.
    // In a perspective camera setup (near=0.1, far=1000), a point at 0.95 projected depth is about
    // 5 units from the camera.
    in.z = 0.95f;

    Vector3f pointOnPlane;
    if (clipToWorld.PerspectiveMultiplyPoint3(in, pointOnPlane))
    {
        // Now we have a point on the plane perpendicular to the viewing direction. We need to return the one that is on the line
        // towards this point, and at p.z distance along camera's viewing axis.
        Vector3f cameraPos = cameraToWorld.GetPosition();
        Vector3f dir = pointOnPlane - cameraPos;

        // The camera/projection matrices follow OpenGL convention: positive Z is towards the viewer.
        // So negate it to get into Unity convention.
        Vector3f forward = -cameraToWorld.GetAxisZ();
        float distToPlane = Dot(dir, forward);
        if (Abs(distToPlane) >= 1.0e-6f)
        {
            const bool isPerspective = clipToWorld.IsPerspective();
            if (isPerspective)
            {
                dir *= p.z / distToPlane;
                outP = cameraPos + dir;
            }
            else
            {
                outP = pointOnPlane - forward * (distToPlane - p.z);
            }
            return true;
        }
    }

    outP.Set(0.0f, 0.0f, 0.0f);
    return false;
}

void SetGLViewport(const Rectf& pixelRect)
{
    Rectf tempPixelRect(pixelRect);

    GfxDevice& device = GetGfxDevice();

#if UNITY_EDITOR
    // Handle game view's aspect ratio dropdown, but only if we're not rendering into a render
    // texture.
    if (device.IsRenderingToBackBuffer())
    {
        Rectf renderRect = GetScreenManager().GetRect();
        tempPixelRect.x += renderRect.x;
        tempPixelRect.y += renderRect.y;
        tempPixelRect.Clamp(renderRect);
    }
#endif

    RectInt viewport = RectfToRectInt(tempPixelRect);
    device.SetViewport(viewport);
}

void ExtractProjectionPlanes(const Matrix4x4f& finalMatrix, Plane* outPlanes)
{
    float tmpVec[4];
    float otherVec[4];

    tmpVec[0] = finalMatrix.Get(3, 0);
    tmpVec[1] = finalMatrix.Get(3, 1);
    tmpVec[2] = finalMatrix.Get(3, 2);
    tmpVec[3] = finalMatrix.Get(3, 3);

    otherVec[0] = finalMatrix.Get(0, 0);
    otherVec[1] = finalMatrix.Get(0, 1);
    otherVec[2] = finalMatrix.Get(0, 2);
    otherVec[3] = finalMatrix.Get(0, 3);

    // left & right
    outPlanes[kPlaneFrustumLeft].SetABCD(otherVec[0] + tmpVec[0],  otherVec[1] + tmpVec[1],  otherVec[2] + tmpVec[2],  otherVec[3] + tmpVec[3]);
    outPlanes[kPlaneFrustumLeft].NormalizeUnsafe();
    outPlanes[kPlaneFrustumRight].SetABCD(-otherVec[0] + tmpVec[0], -otherVec[1] + tmpVec[1], -otherVec[2] + tmpVec[2], -otherVec[3] + tmpVec[3]);
    outPlanes[kPlaneFrustumRight].NormalizeUnsafe();

    // bottom & top
    otherVec[0] = finalMatrix.Get(1, 0);
    otherVec[1] = finalMatrix.Get(1, 1);
    otherVec[2] = finalMatrix.Get(1, 2);
    otherVec[3] = finalMatrix.Get(1, 3);

    outPlanes[kPlaneFrustumBottom].SetABCD(otherVec[0] + tmpVec[0],  otherVec[1] + tmpVec[1],  otherVec[2] + tmpVec[2],  otherVec[3] + tmpVec[3]);
    outPlanes[kPlaneFrustumBottom].NormalizeUnsafe();
    outPlanes[kPlaneFrustumTop].SetABCD(-otherVec[0] + tmpVec[0], -otherVec[1] + tmpVec[1], -otherVec[2] + tmpVec[2], -otherVec[3] + tmpVec[3]);
    outPlanes[kPlaneFrustumTop].NormalizeUnsafe();

    otherVec[0] = finalMatrix.Get(2, 0);
    otherVec[1] = finalMatrix.Get(2, 1);
    otherVec[2] = finalMatrix.Get(2, 2);
    otherVec[3] = finalMatrix.Get(2, 3);

    // near & far
    outPlanes[kPlaneFrustumNear].SetABCD(otherVec[0] + tmpVec[0],  otherVec[1] + tmpVec[1],  otherVec[2] + tmpVec[2],  otherVec[3] + tmpVec[3]);
    outPlanes[kPlaneFrustumNear].NormalizeUnsafe();
    outPlanes[kPlaneFrustumFar].SetABCD(-otherVec[0] + tmpVec[0], -otherVec[1] + tmpVec[1], -otherVec[2] + tmpVec[2], -otherVec[3] + tmpVec[3]);
    outPlanes[kPlaneFrustumFar].NormalizeUnsafe();
}

void ExtractProjectionNearPlane(const Matrix4x4f& finalMatrix, Plane* outPlane)
{
    float tmpVec[4];
    float otherVec[4];

    tmpVec[0] = finalMatrix.Get(3, 0);
    tmpVec[1] = finalMatrix.Get(3, 1);
    tmpVec[2] = finalMatrix.Get(3, 2);
    tmpVec[3] = finalMatrix.Get(3, 3);

    otherVec[0] = finalMatrix.Get(2, 0);
    otherVec[1] = finalMatrix.Get(2, 1);
    otherVec[2] = finalMatrix.Get(2, 2);
    otherVec[3] = finalMatrix.Get(2, 3);

    // near
    outPlane->SetABCD(otherVec[0] + tmpVec[0],  otherVec[1] + tmpVec[1],  otherVec[2] + tmpVec[2],  otherVec[3] + tmpVec[3]);
    outPlane->NormalizeUnsafe();
}

void SetClippingPlaneShaderProps(GfxDevice& device)
{
    BuiltinShaderParamValues& params = device.GetBuiltinParamValues();

    const Matrix4x4f& viewMatrix = device.GetViewMatrix();
    const Matrix4x4f& deviceProjMatrix = device.GetDeviceProjectionMatrix();
    Matrix4x4f viewProj;
    MultiplyMatrices4x4(&deviceProjMatrix, &viewMatrix, &viewProj);
    Plane planes[6];
    ExtractProjectionPlanes(viewProj, planes);
    params.SetVectorParam(kShaderVecCameraWorldClipPlanes0, (const Vector4f&)planes[0]);
    params.SetVectorParam(kShaderVecCameraWorldClipPlanes1, (const Vector4f&)planes[1]);
    params.SetVectorParam(kShaderVecCameraWorldClipPlanes2, (const Vector4f&)planes[2]);
    params.SetVectorParam(kShaderVecCameraWorldClipPlanes3, (const Vector4f&)planes[3]);
    params.SetVectorParam(kShaderVecCameraWorldClipPlanes4, (const Vector4f&)planes[4]);
    params.SetVectorParam(kShaderVecCameraWorldClipPlanes5, (const Vector4f&)planes[5]);
}

DeviceMVPMatricesState::DeviceMVPMatricesState(GfxDevice& device) : m_Device(device)
{
    m_View = device.GetViewMatrix();
    m_World = device.GetWorldMatrix();
    m_Proj = device.GetProjectionMatrix();
}

DeviceMVPMatricesState::~DeviceMVPMatricesState()
{
    GraphicsHelper::SetWorldViewAndProjection(m_Device, &m_World, &m_View, &m_Proj);
    SetClippingPlaneShaderProps(m_Device);
}

DeviceViewProjMatricesState::DeviceViewProjMatricesState(GfxDevice& device) : m_Device(device)
{
    m_View = device.GetViewMatrix();
    m_Proj = device.GetProjectionMatrix();
}

DeviceViewProjMatricesState::~DeviceViewProjMatricesState()
{
    GraphicsHelper::SetWorldViewAndProjection(m_Device, NULL, &m_View, &m_Proj);
    SetClippingPlaneShaderProps(m_Device);
}

#if GFX_SUPPORTS_SINGLE_PASS_STEREO
DeviceStereoMatricesState::DeviceStereoMatricesState(GfxDevice& device) : m_Device(device)
{
    m_StereoMode = device.GetSinglePassStereo() != kSinglePassStereoNone;
    if (m_StereoMode)
        m_Device.SaveStereoConstants();
}

DeviceStereoMatricesState::~DeviceStereoMatricesState()
{
    if (m_StereoMode)
        m_Device.RestoreStereoConstants();
}

#endif
