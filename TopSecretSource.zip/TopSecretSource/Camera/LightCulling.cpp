#include "UnityPrefix.h"
#include "LightManager.h"
#include "LightUtil.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Camera/CameraUtil.h"
#include "Runtime/Camera/Camera.h"
#include "Runtime/Camera/Culling/PerObjectLightCulling.h"
#include "Runtime/Core/Callbacks/GlobalCallbacks.h"
#include "Runtime/Geometry/BoundingUtils.h"
#include "Runtime/Geometry/Intersection.h"
#include "Runtime/Interfaces/IUmbra.h"
#include "Runtime/Jobs/Jobs.h"
#include "ShadowCulling.h"
#include "Runtime/Profiler/Profiler.h"
#include "LightCulling.h"

PROFILER_INFORMATION(gFrustumAndOcculusionCullLocalLights, "FrustumAndOcculusionCullLocalLights", kProfilerRender);
PROFILER_INFORMATION(gFrustumAndOcculusionCullLocalLightsCombine, "FrustumAndOcculusionCullLocalLightsCombine", kProfilerRender);
PROFILER_INFORMATION(gOcclusionAndConnectivityCullLight, "OcclusionAndConnectivityCullLight", kProfilerRender);
PROFILER_INFORMATION(gCullLightFrustumLocal, "CullLightFrustumLocal", kProfilerRender);
PROFILER_INFORMATION(gFindActiveLights, "FindActiveLights", kProfilerRender);
PROFILER_INFORMATION(gFindBrightestDirectionalLight, "FindBrightestDirectionalLight", kProfilerRender);
PROFILER_INFORMATION(gAddDirectionalLights, "AddDirectionalLights", kProfilerRender);
PROFILER_INFORMATION(gAddActiveLocalLights, "AddActiveLocalLights", kProfilerRender);
PROFILER_INFORMATION(gAddCustomActiveLocalLights, "AddCustomActiveLocalLights", kProfilerRender);

static const float kMinLightIntensity = 0.001f;

static float CalculateIntensityForMainLight(const Light& source, bool& notImportant)
{
    DebugAssert(source.GetLightType() == kLightDirectional);

    notImportant = false;

    if (source.GetRenderMode() == kLightRenderModeNotImportant)
        notImportant = true;

    // TODO luminance is always calculated in gamma space. Use if (GetGraphicsSettings().GetLightsUseLinearIntensity()) source.GetFinalLightColorActiveSpace().GreyScaleValue(); instead
    float lum = source.GetColor().GreyScaleValue() * source.GetIntensity();
    if (source.GetShadowType() != kShadowNone)
        lum *= 16.0f;
    return lum;
}

static void OcclusionCullLocalLights(LocalLightCullJobData& cullData, BlockRange& range)
{
    PROFILER_AUTO(gOcclusionAndConnectivityCullLight, NULL);

    IUmbra *iumbra = GetIUmbra();
    if (iumbra)
        iumbra->OcclusionCullLocalLights(cullData, range);
}

// Returned rectangle is 0..1 coordinates
void CalculateLightScreenBounds(const ShadowJobData& cullData, const SharedLightData& light, Rectf* outScreenRects, TargetEyeMask& outVisibilityMask)
{
    Assert(light.GetLightType() != kLightDirectional);

    // Compute the hull of light's bounds
    const Matrix4x4f& lightMatrix = light.GetLocalToWorldMatrix();
    Vector3f lightPos = lightMatrix.GetPosition();

    UInt8 hullFaces;
    UInt8 hullCounts[6]; // 6 faces
    Vector3f hullPoints[24];    // this input hull has maximum of 6 faces x 4 points hence 24 vectors

    switch (light.GetLightType())
    {
        case kLightSpot:
            // Spot light's hull is the light position and four points on the plane at Range
        {
            SpotLightBounds spotBounds;
            CalculateSpotLightBounds(light.GetRange(), light.GetCotanHalfSpotAngle(), lightMatrix, spotBounds);
            const Vector3f* points = spotBounds.points;

            hullFaces = 5;
            hullCounts[0] = 4;
            hullCounts[1] = hullCounts[2] = hullCounts[3] = hullCounts[4] = 3;

            // far plane
            hullPoints[0] = points[4]; hullPoints[1] = points[3]; hullPoints[2] = points[2]; hullPoints[3] = points[1];

            // sides
            hullPoints[4] = points[0]; hullPoints[5] = points[1]; hullPoints[6] = points[2];
            hullPoints[7] = points[0]; hullPoints[8] = points[2]; hullPoints[9] = points[3];
            hullPoints[10] = points[0]; hullPoints[11] = points[3]; hullPoints[12] = points[4];
            hullPoints[13] = points[0]; hullPoints[14] = points[4]; hullPoints[15] = points[1];
        }
        break;

        case kLightPoint:
            // Point light's hull is the cube at position with half-size Range
        {
            float r = light.GetRange();
            Vector3f points[8];
            points[0].Set(lightPos.x - r, lightPos.y - r, lightPos.z - r);
            points[1].Set(lightPos.x + r, lightPos.y - r, lightPos.z - r);
            points[2].Set(lightPos.x + r, lightPos.y + r, lightPos.z - r);
            points[3].Set(lightPos.x - r, lightPos.y + r, lightPos.z - r);
            points[4].Set(lightPos.x - r, lightPos.y - r, lightPos.z + r);
            points[5].Set(lightPos.x + r, lightPos.y - r, lightPos.z + r);
            points[6].Set(lightPos.x + r, lightPos.y + r, lightPos.z + r);
            points[7].Set(lightPos.x - r, lightPos.y + r, lightPos.z + r);

            hullFaces = 6;
            hullCounts[0] = hullCounts[1] = hullCounts[2] = hullCounts[3] = hullCounts[4] = hullCounts[5] = 4;

            hullPoints[0] = points[0]; hullPoints[1] = points[1]; hullPoints[2] = points[2]; hullPoints[3] = points[3];
            hullPoints[4] = points[7]; hullPoints[5] = points[6]; hullPoints[6] = points[5]; hullPoints[7] = points[4];
            hullPoints[8] = points[0]; hullPoints[9] = points[3]; hullPoints[10] = points[7]; hullPoints[11] = points[4];
            hullPoints[12] = points[1]; hullPoints[13] = points[5]; hullPoints[14] = points[6]; hullPoints[15] = points[2];
            hullPoints[16] = points[4]; hullPoints[17] = points[5]; hullPoints[18] = points[1]; hullPoints[19] = points[0];
            hullPoints[20] = points[6]; hullPoints[21] = points[7]; hullPoints[22] = points[3]; hullPoints[23] = points[2];
        }
        break;

        default:
            hullFaces = 0;
            AssertString("Unknown light type");
            break;
    }

    // Clip hull by camera's near plane - needed because point behind near plane don't have
    // proper projection on the screen.
    // Extracting near plane from transform wouldn't work with oblique projections etc.
    Plane nearPlane;
    Vector3f offsetFromEye = cullData.viewDir * cullData.projectionNear;
    nearPlane.SetNormalAndPosition(cullData.viewDir, cullData.eyePos + offsetFromEye);

    // Push near plane forward a bit, by a small number proportional to plane's distance from the origin
    // plus the range of the light, in case the light range is significant. (case 671681)
    // Precision of the projection to screen space gets worse at larger numbers.
    nearPlane.distance -= (Abs(nearPlane.distance) + light.GetRange()) * 0.0001f;
    DebugAssert(IsNormalized(nearPlane.GetNormal()));

    outVisibilityMask = kTargetEyeMaskNone;
    const int eyeCount = cullData.stereo ? 2 : 1;
    for (int eye = 0; eye < eyeCount; ++eye)
    {
        // Use actualWorldToClip transform since cameraWorldToClip might be the implicit one (case 522223)
        const Matrix4x4f& worldToClip = cullData.stereo ? cullData.stereoWorldToClip[eye] : cullData.actualWorldToClip;

        MinMaxAABB aabb;
        CalcHullBounds(hullPoints, hullCounts, hullFaces, nearPlane, worldToClip, aabb);
        outScreenRects[eye].Set(
            (aabb.m_Min.x + 1.0f) * 0.5f,
            (aabb.m_Min.y + 1.0f) * 0.5f,
            (aabb.m_Max.x - aabb.m_Min.x) * 0.5f,
            (aabb.m_Max.y - aabb.m_Min.y) * 0.5f);

        // Is screen rect inside viewport [0,1]
        // Invisible rect may be used if other eye is visible
        if ((aabb.m_Max.x > aabb.m_Min.x) && (aabb.m_Max.y > aabb.m_Min.y))
            outVisibilityMask |= TargetEyeMask(1 << eye);
        else
            outScreenRects[eye].Reset();
    }
}

static void FrustumCullLocalLights(LocalLightCullJobData& cullData, BlockRange& range, int& offScreenLightRange)
{
    PROFILER_AUTO(gCullLightFrustumLocal, NULL);

    IndexList& visibleLights = *cullData.output.visibleLights;
    IndexList& offScreenLights = *cullData.output.offScreenLights;
    float* visibilityFades = cullData.output.visibilityFades;
    Rectf* lightScreenRects = cullData.output.lightScreenRects;
    TargetEyeMask* lightVisibilityMasks = cullData.output.lightVisibilityMasks;
    const Light** localLights = cullData.localLights;
    const ShadowCullData& shadowCullData = *cullData.shadowCullData;

    int visibleLightCount = range.startIndex;
    int offScreenLightCount = range.startIndex;
    const size_t endIndex = range.startIndex + range.rangeSize;
    const int eyeCount = shadowCullData.stereo ? 2 : 1;

    for (size_t i = range.startIndex; i < endIndex; ++i)
    {
        lightVisibilityMasks[i] = kTargetEyeMaskNone;

        float distance = PointDistanceToFrustum(cullData.lightBSpheres[i], cullData.cullingParams->cullingPlanes, cullData.cullingParams->cullingPlaneCount);

        // Light is inside or intersecting the frustum
        if (distance < cullData.lightBSpheres[i].w)
        {
            // lights that intersect or are inside the frustum
            DebugAssert(visibleLightCount < visibleLights.reservedSize);
            visibleLights.indices[visibleLightCount++] = i;
            const Light& light = *localLights[i];
            LightType lightType = light.GetLightType();
            if (lightType == kLightPoint || lightType == kLightSpot)
            {
                CalculateLightScreenBounds(shadowCullData, light.GetDataNoAcquire(), &lightScreenRects[i * eyeCount], lightVisibilityMasks[i]);
            }
        }
        // Light is outside of the frustum and must be faded out
        else if (distance < cullData.lightBSpheres[i].w + cullData.lightBSpheres[i].w)
        {
            //off screen lights whose distance from frustum is less than light radius
            DebugAssert(offScreenLightCount < offScreenLights.reservedSize);

            offScreenLights.indices[offScreenLightCount] = i;

            distance -= cullData.lightBSpheres[i].w;

            distance = distance / cullData.lightBSpheres[i].w;
            visibilityFades[offScreenLightCount++] = 1.0F - distance;
            DebugAssert(distance > 0.0f);
            DebugAssert(distance < 1.0f);
        }
    }
    range.rangeSize = visibleLightCount - range.startIndex;         // visibleLightRange
    offScreenLightRange = offScreenLightCount - range.startIndex;   // offScreenLightRange
}

static void FrustumAndOcculusionCullLocalLightsJob(LocalLightCullJobData* cullData, unsigned index)
{
    PROFILER_AUTO(gFrustumAndOcculusionCullLocalLights, NULL);

    FrustumCullLocalLights(*cullData, cullData->blockRanges[index], cullData->outputVisibleOffscreenLights[index]);
    OcclusionCullLocalLights(*cullData, cullData->blockRanges[index]);
}

static void FrustumAndOcculusionCullLocalLightsCombineJob(LocalLightCullJobData* data)
{
    PROFILER_AUTO(gFrustumAndOcculusionCullLocalLightsCombine, NULL);

    LocalLightCullJobOutputData& inputOutputArray = data->output;
    const BlockRange* blocks = data->blockRanges;

    // Combine visible light & offscreenLight with different ranges (one range for each job)
    // into a combined buffer, essentially cleaning up any gaps
    IndexList& visibleLights = *inputOutputArray.visibleLights;
    IndexList& offScreenLights = *inputOutputArray.offScreenLights;
    float* visibilityFades = inputOutputArray.visibilityFades;

    int visibleLightCount = 0, offSceenLightCount = 0;
    for (size_t i = 0; i < data->blockRangeCount; ++i)
    {
        size_t endIndexVisible = blocks[i].startIndex + blocks[i].rangeSize;
        for (size_t j = blocks[i].startIndex; j < endIndexVisible; ++j)
        {
            DebugAssert(visibleLightCount < visibleLights.reservedSize);
            visibleLights[visibleLightCount++] = visibleLights[j];
        }

        size_t endIndexOffScreen = blocks[i].startIndex + data->outputVisibleOffscreenLights[i];
        for (size_t j = blocks[i].startIndex; j < endIndexOffScreen; ++j)
        {
            DebugAssert(offSceenLightCount < offScreenLights.reservedSize);
            offScreenLights[offSceenLightCount] = offScreenLights[j];
            visibilityFades[offSceenLightCount++] = visibilityFades[j];
        }
    }
    visibleLights.size = visibleLightCount;
    offScreenLights.size = offSceenLightCount;

    UNITY_DELETE(data, kMemTempJobAlloc);
}

void CullLocalLights(JobFence& fence, JobFence& waitForOcclusionBuffer, const SceneCullingParameters& cullingParameters, int numLocalLights, const Vector4f* localLightBSpheres, const dynamic_array<UInt8>& isShadowCastingLocalLight, IndexList& visibleLocalLightIndices, IndexList& offScreenLocalLightIndices, float* offScreenLocalLightvisibilityFades, Rectf* lightScreenRects, TargetEyeMask* lightVisibilityMasks, const Light** localLights, const ShadowCullData& shadowCullData)
{
    // No lights to be culled
    if (numLocalLights == 0)
        return;

    LocalLightCullJobData& localLightCullingData = *UNITY_NEW(LocalLightCullJobData, kMemTempJobAlloc);

    localLightCullingData.cullingParams = &cullingParameters;
    localLightCullingData.lightBSpheres = localLightBSpheres;
    localLightCullingData.lightBSpheresCount = numLocalLights;
    localLightCullingData.isShadowCastingLocalLight = isShadowCastingLocalLight.begin();
    localLightCullingData.localLights = localLights;
    localLightCullingData.shadowCullData = &shadowCullData;

    localLightCullingData.output.visibleLights = &visibleLocalLightIndices;
    localLightCullingData.output.offScreenLights = &offScreenLocalLightIndices;
    localLightCullingData.output.visibilityFades = offScreenLocalLightvisibilityFades;
    localLightCullingData.output.lightScreenRects = lightScreenRects;
    localLightCullingData.output.lightVisibilityMasks = lightVisibilityMasks;

    localLightCullingData.blockRangeCount = ConfigureBlockRangesWithMinIndicesPerJob(localLightCullingData.blockRanges, numLocalLights, 16);

    ScheduleJobForEachDepends(fence, FrustumAndOcculusionCullLocalLightsJob, &localLightCullingData, localLightCullingData.blockRangeCount, waitForOcclusionBuffer, FrustumAndOcculusionCullLocalLightsCombineJob);
}

bool IsValidRealtimeLight(const SharedLightData& light, LightType lightType, UInt32 cullingMask)
{
    // If light has no realtime aspects - just skip it
    if (GetLightmapModeForRender(light) == kLightmapModeDontRenderLight)
        return false;

    // If light not visible in camera's culling mask - just skip it
    if ((light.GetCullingMask() & cullingMask) == 0)
        return false;

    // Light with zero intensity - just skip it
    if (light.GetIntensity() < kMinLightIntensity)
        return false;

    // Check if light has valid properties
    return IsLightValidToRender(light);
}

static void SetupActiveDirectionalLight(const Light& light, ActiveLight& outLight)
{
    outLight.light = light.AcquireSharedLightData();
    outLight.insideShadowRange = true;
    outLight.boundingBox = AABB(Vector3f::zero, Vector3f::infinityVec);

    // Baked-only lights are already rejected, so lightmaps are either off or static
    outLight.lightmapModeForRendering = GetLightmapModeForRender(*outLight.light);

    outLight.bakingOutput = light.GetBakingOutput();
    outLight.isVisibleInPrepass = true;
    outLight.shadowedLightIndex = -1;
    for (int eye = 0; eye < kStereoscopicEyeCount; ++eye)
        outLight.screenRects[eye] = Rectf(0, 0, 1, 1);
    outLight.cullingMask = light.GetCullingMask();
    outLight.hasCookie = light.HasCookie();
    outLight.cookieTexRef.Init(light.GetCookie(), true);
    outLight.lightRenderMode = light.GetRenderMode();
    outLight.lightType = light.GetLightType();
    outLight.isOffscreenVertexLight = false;
    outLight.visibilityFade = 1.0;
    // TODO luminance is always calculated in gamma space. Use if (GetGraphicsSettings().GetLightsUseLinearIntensity()) light.GetFinalLightColorActiveSpace().GreyScaleValue(); instead
    outLight.luminance = light.GetColor().GreyScaleValue() * light.GetIntensity();
}

static int GetBrightestDirectionalLightIndex(const Light* const * lights, size_t count)
{
    // Find main directional light based on intensity
    int mainLightIndex = -1;
    float brightestLightIntensity = -1.0f;

    for (size_t i = 0; i < count; i++)
    {
        const Light& light = *lights[i];
        bool notImportant = false;
        float mainLightIntensity = CalculateIntensityForMainLight(light, notImportant);
        if (!notImportant && mainLightIntensity > brightestLightIntensity)
        {
            mainLightIndex = i;
            brightestLightIntensity = mainLightIntensity;
        }
    }

    return mainLightIndex;
}

void AddDirectionalLights(const Light** lights, size_t count, ActiveLights& outLights)
{
    PROFILER_AUTO(gAddDirectionalLights, NULL);

    Assert(outLights.lights.size() == 0);

    outLights.hasShadowedDirLights = false;
    outLights.hasShadowMaskInDirLights = false;

    // Add main light as the first light!
    int mainLightIndex = GetBrightestDirectionalLightIndex(lights, count);
    if (mainLightIndex != -1)
    {
        SetupActiveDirectionalLight(*lights[mainLightIndex], outLights.lights.push_back());
        outLights.hasShadowMaskInDirLights = (outLights.lights.back().bakingOutput.lightmappingMask & kLightmappingDirectShadowMask) != 0;
        outLights.hasMainLight = true;
    }
    else
        outLights.hasMainLight = false;

    // Add any other lights
    for (size_t i = 0; i < count; i++)
    {
        if ((*lights[i]).GetShadowType() != kShadowNone)
            outLights.hasShadowedDirLights = true;

        if ((int)i == mainLightIndex)
            continue;

        SetupActiveDirectionalLight(*lights[i], outLights.lights.push_back());
        outLights.hasShadowMaskInDirLights |= (outLights.lights.back().bakingOutput.lightmappingMask & kLightmappingDirectShadowMask) != 0;
    }
    outLights.numDirLights = outLights.lights.size();
}

void SetupActiveLocalLight(const LocalLightCullingParameters& params, const ShadowJobData& shadowCullData, const Vector4f& lightBSphere, const Rectf* lightScreenRects, bool stereo, bool isVisible, float visibilityFade, ActiveLight& outLight)
{
    float radius = lightBSphere.w;
    Vector3f center = Vector3f(lightBSphere.x, lightBSphere.y, lightBSphere.z);
    float nearDistanceFudged = shadowCullData.cameraNear * 1.001f;
    float farDistanceFudged = shadowCullData.cameraFar * 0.999f;

    // Add to spot or point lights
    float viewDistance = params.eyePlane.GetDistanceToPoint(center);
    float closestDistance = std::numeric_limits<float>::infinity();
    float farthestDistance = -closestDistance;

    const SharedLightData& light = *outLight.light;
    const Matrix4x4f& lightMatrix = light.GetLocalToWorldMatrix();

    outLight.shadowedLightIndex = -1;
    outLight.isVisibleInPrepass = isVisible;
    outLight.hasStereoScreenRects = stereo;
    const int eyeCount = stereo ? 2 : 1;
    for (int eye = 0; eye < eyeCount; ++eye)
        outLight.screenRects[eye] = lightScreenRects[eye];
    outLight.visibilityFade = visibilityFade;
    outLight.lightBSphere = lightBSphere;
    Sphere sphere(light.GetWorldPosition(), light.GetRange());
    outLight.cullSphere = sphere;
    // TODO luminance is always calculated in gamma space. Use if (GetGraphicsSettings().GetLightsUseLinearIntensity()) light.GetFinalLightColorActiveSpace().GreyScaleValue(); instead
    outLight.luminance = light.GetColorFilter().GreyScaleValue() * light.GetIntensity();
    // If light survived from culling, but is not visible
    outLight.isOffscreenVertexLight = !isVisible;

    // Baked-only lights are already rejected, so lightmaps are either off or static
    const LightmapModeForRender lightmapModeForRendering = GetLightmapModeForRender(*outLight.light);
    outLight.lightmapModeForRendering = lightmapModeForRendering;
    outLight.bakingOutput = light.GetBakingOutput();

    // Keep cached copy of culling mask for efficiency
    outLight.cullingMask = light.GetCullingMask();
    outLight.hasCookie = light.HasCookie();
    outLight.cookieTexRef = light.GetCookieTexRef();
    outLight.lightRenderMode = light.GetRenderMode();

    LightType lightType = light.GetLightType();
    outLight.lightType = lightType;

    if (lightType == kLightSpot)
    {
        // Find nearest point
        SpotLightBounds spotBounds;
        CalculateSpotLightBounds(light.GetRange(), light.GetCotanHalfSpotAngle(), lightMatrix, spotBounds);
        const Vector3f* points = spotBounds.points;

        for (int i = 0; i < SpotLightBounds::kPointCount; i++)
        {
            float dist = params.eyePlane.GetDistanceToPoint(points[i]);
            closestDistance = std::min(closestDistance, dist);
            farthestDistance = std::max(farthestDistance, dist);
        }
        outLight.intersectsNear = closestDistance <= nearDistanceFudged;
        outLight.intersectsFar = farthestDistance >= farDistanceFudged;

        // Nearest point is also bounded by light radius (cull by far plane distance)
        float dist = viewDistance - radius;
        closestDistance = std::max(closestDistance, dist);
        if (closestDistance > params.farDistance)
        {
            outLight.isVisibleInPrepass = false;
            for (int eye = 0; eye < eyeCount; ++eye)
                outLight.screenRects[eye].Reset();
        }

        // Compute bounding box
        MinMaxAABB bounds(points[0], points[0]);
        for (int i = 1; i < SpotLightBounds::kPointCount; i++)
            bounds.Encapsulate(points[i]);
        outLight.boundingBox = AABB(bounds);
    }
    else
    {
        DebugAssert(lightType == kLightPoint);
        closestDistance = viewDistance - radius;
        Vector3f boxSize(radius, radius, radius);
        outLight.boundingBox = AABB(center, boxSize);

        // If we're drawing an icosphere or icosahedron, check for the radius of a sphere
        // circumscribed on an icosahedron, which was circumscribed on a unit sphere.
        const float proxyMeshSize = 1.27f;

        const float intersectionRadius = radius * proxyMeshSize;
        outLight.intersectsNear = (viewDistance - intersectionRadius) <= nearDistanceFudged;
        outLight.intersectsFar = (viewDistance + intersectionRadius) >= farDistanceFudged;
    }

    // TODO: tighter shadow culling for spot lights
    outLight.insideShadowRange = (closestDistance < shadowCullData.shadowDistance) && params.enableShadows && outLight.isVisibleInPrepass;
    if (outLight.insideShadowRange && shadowCullData.useSphereCulling)
    {
        float sumRadii = shadowCullData.shadowCullRadius + radius;
        if (SqrMagnitude(center - shadowCullData.shadowCullCenter) > Sqr(sumRadii))
            outLight.insideShadowRange = false;
        else if (!IsObjectWithinShadowRange(shadowCullData, outLight.boundingBox))
            outLight.insideShadowRange = false;
    }
}

void AddActiveCustomLights(const LocalLightCullingParameters& params, CullResults& results, ActiveLights& outCustomLights)
{
    PROFILER_AUTO(gAddCustomActiveLocalLights, NULL);

    LightType lightTypes[2] = { kLightSpot, kLightPoint };
    int lightCountOfType[2] = { 0, 0 };
    for (int lightType = 0; lightType < ARRAY_SIZE(lightTypes); lightType++)
    {
        GlobalCallbacks::Get().addCustomLights.Invoke(params, results, outCustomLights, lightCountOfType[lightType], lightTypes[lightType]);
    }

    outCustomLights.numSpotLights = lightCountOfType[0];
    outCustomLights.numPointLights = lightCountOfType[1];
}

//  Use this to verify the precalculated screen rectangle for each active light remains valid at the point of use
static void AddActiveLocalLights(const LocalLightCullingParameters& params, CullResults& results, const Vector4f* lightBSpheres, const Light** lights, const IndexList& visibleLocalLights, float* visibilityFades, IndexList& offScreenLocalLights, ActiveLights& outLights, ActiveLights& customLights, Rectf* lightScreenRects, TargetEyeMask* lightVisibilityMasks)
{
    int offScreenLightCount = offScreenLocalLights.size;
    outLights.hasShadowMaskInLocalLights = false;

    const ShadowCullData& shadowCullData = *results.shadowCullData;
    const bool stereo = shadowCullData.sceneCullParameters->stereo;
    const int eyeCount = stereo ? 2 : 1;

    //Add spot lights first, and point lights second
    LightType lightTypes[2] = { kLightSpot, kLightPoint };
    int lightCountOfType[2] = { 0, 0 };
    size_t customLightCountOfType[2] = { customLights.numSpotLights, customLights.numPointLights };
    for (int lightType = 0; lightType < ARRAY_SIZE(lightTypes); lightType++)
    {
        for (int visibleI = 0; visibleI < visibleLocalLights.size; visibleI++)
        {
            int lightIndex = visibleLocalLights[visibleI];
            const Light& light = *lights[lightIndex];
            if (light.GetLightType() == lightTypes[lightType])
            {
                // Setup visible local light if it is inside camera viewport and has a valid screen rectangle
                if (lightVisibilityMasks[lightIndex] != kTargetEyeMaskNone)
                {
                    ActiveLight& outLight = outLights.lights.push_back();
                    outLight.light = light.AcquireSharedLightData();
                    SetupActiveLocalLight(params, shadowCullData, lightBSpheres[lightIndex], &lightScreenRects[lightIndex * eyeCount], stereo, true, 1.0f, outLight);
                    outLights.hasShadowMaskInLocalLights |= (outLights.lights.back().bakingOutput.lightmappingMask & kLightmappingDirectShadowMask) != 0;
                    lightCountOfType[lightType]++;
                }
                else
                {
                    // Change visible light to off-screen light if it is outside camera viewport
                    visibilityFades[offScreenLightCount] = 1.0f;    // don't fade as the local light is close to the frustum
                    offScreenLocalLights[offScreenLightCount++] = lightIndex;
                }
            }
        }

        //All the lights need to be in order by type.
        //Merge in the custom lights that were found earlier in order.
        size_t numCustomLights = customLightCountOfType[lightType];
        int customLightOffset = 0;
        if (lightType == 1)
        {
            customLightOffset = customLightCountOfType[0];
        }

        for (size_t i = 0; i < numCustomLights; i++)
        {
            ActiveLight& outLight = outLights.lights.push_back();
            outLight = customLights.lights[i + customLightOffset];
            outLight.light->AddRef();
            lightCountOfType[lightType] += 1;
        }
    }

    outLights.numSpotLights = lightCountOfType[0];
    outLights.numPointLights = lightCountOfType[1];

    //Add off screen spot lights third, and off screen point lights fourth
    const Rectf zeroRects[kStereoscopicEyeCount];
    for (int lightType = 0; lightType < ARRAY_SIZE(lightTypes); lightType++)
    {
        lightCountOfType[lightType] = 0;
        for (int offscreenI = 0; offscreenI < offScreenLightCount; offscreenI++)
        {
            int lightIndex = offScreenLocalLights[offscreenI];
            const Light &light = *lights[lightIndex];
            if (light.GetLightType() == lightTypes[lightType])
            {
                ActiveLight& outLight = outLights.lights.push_back();
                outLight.light = light.AcquireSharedLightData();
                SetupActiveLocalLight(params, shadowCullData, lightBSpheres[lightIndex], zeroRects, false, false, visibilityFades[offscreenI], outLight);
                lightCountOfType[lightType]++;
            }
        }
    }
    outLights.numOffScreenSpotLights = lightCountOfType[0];
    outLights.numOffScreenPointLights = lightCountOfType[1];
}

void FindActiveLights(dynamic_array<const Light*>& directionalLights, const Light** localLights, Vector4f* localLightBSpheres, dynamic_array<UInt8>& isShadowCastingLocalLight, const ShadowCullData& cullData, unsigned int& localLightCount)
{
    PROFILER_AUTO(gFindActiveLights, NULL);

    const List<Light>& allLights = GetLightManager().GetAllLights();

    LightManager::Lights::const_iterator it, itEnd = allLights.end();
    for (it = allLights.begin(); it != itEnd; ++it)
    {
        const Light& light = *it;
        LightType lightType = light.GetLightType();

        if (!IsValidRealtimeLight(light.GetDataNoAcquire(), lightType, cullData.cullingMask))
            continue;

        // Add directional light
        if (lightType == kLightDirectional)
        {
            directionalLights.push_back(&light);
        }
        // Setup data necessary for culling point / spot lights
        else if (lightType == kLightPoint || lightType == kLightSpot)
        {
            float radius = light.GetRange();

            if (lightType == kLightSpot)
                radius *= light.GetInvCosHalfSpotAngle();

            // Set radius to negative by default, use it to skip lights in the next loop
            Vector3f lightPos = light.GetWorldPosition();
            localLightBSpheres[localLightCount] = Vector4f(lightPos.x, lightPos.y, lightPos.z, radius);
            localLights[localLightCount++] = &light;

            if (light.GetShadowType() != kShadowNone)
                isShadowCastingLocalLight.push_back(1);
            else
                isShadowCastingLocalLight.push_back(0);
        }
        else
        {
            ErrorStringObject("Unsupported light type", &light);
        }
    }
}

void InitLocalLightCullingParameters(const CullResults& results, LocalLightCullingParameters& params)
{
    const ShadowCullData& cullData = *results.shadowCullData;

    params.eyePlane.SetNormalAndPosition(cullData.viewDir, cullData.eyePos);
    params.farDistance = cullData.cameraFar;
    params.enableShadows = cullData.shadowDistance > cullData.cameraNear;
    params.cullingMask = cullData.cullingMask;
}

void AddActiveLocalLights(CullResults& results, LocalLightCullingParameters& localLightCullParameters, const Light** localLights, const Vector4f* localLightBSpheres, const IndexList& visibleLocalLightIndices,
    float* offScreenLocalLightvisibilityFades, IndexList& offScreenLocalLightIndices, ActiveLights& outLights, ActiveLights& customLights, Rectf* lightScreenRects, TargetEyeMask* lightVisibilityMasks)
{
    PROFILER_AUTO(gAddActiveLocalLights, NULL);

    // Add visible local lights and off screen local lights to the outlights...
    AddActiveLocalLights(localLightCullParameters, results, localLightBSpheres, localLights, visibleLocalLightIndices,
        offScreenLocalLightvisibilityFades, offScreenLocalLightIndices, outLights, customLights, lightScreenRects, lightVisibilityMasks);
}

Light* FindBrightestDirectionalLight(bool checkValid)
{
    PROFILER_AUTO(gFindBrightestDirectionalLight, NULL);

    LightManager::Lights& allLights = GetLightManager().GetAllLights();

    dynamic_array<Light*>   directionalLights(kMemTempAlloc);
    directionalLights.reserve(8); // Preallocate a bit more than sensible amount of directional lights for real-world scene

    LightManager::Lights::iterator it, itEnd = allLights.end();
    for (it = allLights.begin(); it != itEnd; ++it)
    {
        Light& light = *it;
        LightType lightType = light.GetLightType();

        if (checkValid && !IsValidRealtimeLight(light.GetDataNoAcquire(), lightType, ~0))
            continue;

        // Add directional light
        if (lightType == kLightDirectional)
            directionalLights.push_back(&light);
    }

    int mainLightIndex = GetBrightestDirectionalLightIndex(directionalLights.begin(), directionalLights.size());
    if (mainLightIndex == -1)
        return NULL;

    DebugAssert(mainLightIndex <= directionalLights.size());
    return directionalLights[mainLightIndex];
}
