#pragma once

#include "Runtime/Camera/RenderLoops/LightProbeProxyVolumeContext.h"
#include "Runtime/Camera/SharedRendererData.h"
#include "Runtime/GameCode/Behaviour.h"
#include "Runtime/Geometry/AABB.h"
#include "Runtime/GfxDevice/GfxDeviceTypes.h"
#include "Runtime/Graphics/GeneratedTextures.h"
#include "Runtime/Math/SphericalHarmonicsL1.h"
#include "Runtime/Math/SphericalHarmonicsL2.h"
#include "Runtime/Math/Vector3.h"
#include "Runtime/Utilities/BitUtility.h"

class Texture3D;

//--------------------------------------------------------------------------------------------------------
// Light Probe Proxy Volume component

class LightProbeProxyVolume : public Behaviour
{
    REGISTER_CLASS_TRAITS(kTypeIsSealed);
    REGISTER_CLASS(LightProbeProxyVolume);
    DECLARE_OBJECT_SERIALIZE();
public:
    // Match the enums from GraphicsEnums.cs
    enum BoundingBoxMode
    {
        kBBModeAutomaticLocal = 0,      // The AABB is computed in the local-space
        kBBModeAutomaticGlobal = 1,     // The AABB is world-space aligned
        kBBModeCustom = 2,              // The AABB is in local-space and is user-specified
    };

    enum ResolutionMode
    {
        kResModeAutomatic = 0,          // The resolution depends on the AABB size and probe density
        kResModeCustom = 1,             // The resolution is user-specified
    };

    enum RefreshMode
    {
        kAutomatic = 0,                 // Automatic update when the light probe coefficients are changed
        kEveryFrame = 1,
        kViaScripting = 2,              // Update via scripting - LightProbeProxyVolume.Update
    };

    enum ProbePositionMode
    {
        kPositionCellCorner = 0,        // Divide the volume in cells based on resolution and generate interpolated probe positions in the corner/edge of the cells
        kPositionCellCenter = 1,        // Divide the volume in cells based on resolution and generate interpolated probe positions in the center of the cells
    };

    static const SInt16 InvalidHandle = -1;

#if UNITY_EDITOR
    struct LightProbeEditorData
    {
        SphericalHarmonicsL2            shL2Coeffs;
        Vector3f                        worldPosition;
        Vector4f                        occlusionMask;
    };

    typedef dynamic_array<LightProbeEditorData> LightProbeEditorDataArray;
#endif

public:
    friend class LightProbeProxyVolumeManager;

    LightProbeProxyVolume(MemLabelId label, ObjectCreationMode mode);

    virtual void Reset();
    virtual void AddToManager();
    virtual void RemoveFromManager();
    virtual void CheckConsistency();
    virtual void MainThreadCleanup();

#define GET_SET_PROPERTY_COMPARE_SET_DIRTY(TYPE, PROP_NAME, VAR_NAME) void Set##PROP_NAME (const TYPE val) { if ((TYPE)VAR_NAME == val) return; VAR_NAME = val; SetDirtyFlag(true); }   const TYPE Get##PROP_NAME () const {return (const TYPE)VAR_NAME; }

    GET_SET_PROPERTY_COMPARE_SET_DIRTY(Vector3f, BoundingBoxSizeCustom, m_BoundingBoxSize);
    GET_SET_PROPERTY_COMPARE_SET_DIRTY(Vector3f, BoundingBoxOriginCustom, m_BoundingBoxOrigin);
    GET_SET_PROPERTY_COMPARE_SET_DIRTY(float, ProbeDensity, m_ResolutionProbesPerUnit);
    GET_SET_PROPERTY_COMPARE_SET_DIRTY(int, GridResolutionX, m_ResolutionX);
    GET_SET_PROPERTY_COMPARE_SET_DIRTY(int, GridResolutionY, m_ResolutionY);
    GET_SET_PROPERTY_COMPARE_SET_DIRTY(int, GridResolutionZ, m_ResolutionZ);
    GET_SET_PROPERTY_COMPARE_SET_DIRTY(int, BoundingBoxMode, m_BoundingBoxMode);
    GET_SET_PROPERTY_COMPARE_SET_DIRTY(int, ResolutionMode, m_ResolutionMode);
    GET_SET_PROPERTY_COMPARE_SET_DIRTY(int, ProbePositionMode, m_ProbePositionMode);
    GET_SET_PROPERTY_COMPARE_SET_DIRTY(int, RefreshMode, m_RefreshMode);

    void        SetDirtyFlag(bool isDirty) { m_IsDirty = isDirty; }
    bool        GetDirtyFlag() const { return m_IsDirty; }
    Vector3f    GetGlobalExtents() const { return m_GlobalAABBExtents; }
    Vector3f    GetGlobalCenter() const { return m_GlobalAABBCenter; }
    AABB        GetGlobalAABB() const { return AABB(m_GlobalAABBCenter, m_GlobalAABBExtents); }
    AABB        GetAABB() const { return m_AABB; }
    bool        GetLocalToWorldMatrix(Matrix4x4f& outMatrix);
    AABB        GetProbeAABB();
    inline int  GetHandle() const { return m_Handle; }
    void        GetRenderData(LightProbeProxyVolumeSample& renderData);

    static bool IsHandleValid(SInt16 handle) { return handle != InvalidHandle; }
    static bool HasHardwareSupport();

#if UNITY_EDITOR
    LightProbeEditorDataArray&          GetEditorData() { return m_EditorData; }
    const LightProbeEditorDataArray&    GetEditorData() const { return m_EditorData; }
#endif

private:
    Texture3D*  GetSHCoefficientsTexture() const;
    void        GetResolution(UInt32& resolutionX, UInt32& resolutionY, UInt32& resolutionZ) const;
    void        ValidateBoundingBoxSettings();
    Matrix4x4f  GetWorldToLocalMatrix();
    void        SetHandle(int handle) { m_Handle = handle; }

    Transform*  GetTransform();

private:
    // Serialized data
    int         m_BoundingBoxMode; ///< enum { AutomaticLocal = 0, AutomaticWorld = 1, Custom = 2 }
    int         m_ResolutionMode; ///< enum { Automatic = 0, Custom = 1 }
    int         m_RefreshMode; ///< enum { Automatic = 0, EveryFrame = 1, ViaScripting = 2 }
    UInt32      m_ResolutionX;
    UInt32      m_ResolutionY;
    UInt32      m_ResolutionZ;
    float       m_ResolutionProbesPerUnit;
    Vector3f    m_BoundingBoxSize;
    Vector3f    m_BoundingBoxOrigin;
    int         m_ProbePositionMode; ///< enum { CellCorner = 0, CellCenter = 1 }

    // Transient data
    AABB        m_AABB;
    Vector3f    m_GlobalAABBCenter;
    Vector3f    m_GlobalAABBExtents;
    UInt32      m_FinalResolutionX;
    UInt32      m_FinalResolutionY;
    UInt32      m_FinalResolutionZ;
    SInt16      m_Handle;
    bool        m_IsDirty;

#if UNITY_EDITOR
    LightProbeEditorDataArray   m_EditorData;
#endif

    enum { kMaxSHCoeffsTextureSets = 2 };
    PPtr<Texture3D>     m_SHCoeffsTex[kMaxSHCoeffsTextureSets];
    UInt32              m_SHCoeffsTexSetIndex;
};


typedef dynamic_array<LightProbeProxyVolume*> LightProbeProxyVolumeArray;

//--------------------------------------------------------------------------------------------------------
class LightProbeProxyVolumeManager
{
public:
    friend class LightProbeProxyVolume;

    LightProbeProxyVolumeManager();

    static void InitializeClass();
    static void CleanupClass();

    void        AddProxyVolume(LightProbeProxyVolume* proxyVolume);
    void        RemoveProxyVolume(LightProbeProxyVolume* proxyVolume);
    void        Update();
    void        OnLightProbesUpdate();

    const LightProbeProxyVolumeContext& GetContext() const { return m_UpdateContext; }

protected:
    static Texture3D*   AllocateVolumeTexture(LightProbeProxyVolume& target, const char* debugName);

    void UpdateProxyVolume(LightProbeProxyVolume& proxyVolume, size_t index);
    void AllocateVolumeTextures(LightProbeProxyVolume& proxyVolume);
    void BlendLightProbes(LightProbeProxyVolume& proxyVolume);
    void UpdateSHCoeffsTextureData(LightProbeProxyVolume& proxyVolume);
    void UpdateBoundingBox(LightProbeProxyVolume& proxyVolume);
    void UpdateResolution(LightProbeProxyVolume& proxyVolume);
    void SwapVolumeTextureSets(LightProbeProxyVolume& proxyVolume);

private:
    // All the LPPV components from all the scenes
    LightProbeProxyVolumeArray      m_LightProbeVolumes;

    // The update context containing data used by the render loops
    LightProbeProxyVolumeContext    m_UpdateContext;
};

LightProbeProxyVolumeManager& GetLightProbeProxyVolumeManager();
LightProbeProxyVolumeManager* GetLightProbeProxyVolumeManagerPtr();
