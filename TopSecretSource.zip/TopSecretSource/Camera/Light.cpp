#include "UnityPrefix.h"
#include "LightUtil.h"
#include "RenderSettings.h"
#include "HaloManager.h"
#include "Runtime/BaseClasses/MessageHandlerRegistration.h"
#include "Runtime/Camera/Flare.h"
#include "Runtime/Graphics/CommandBuffer/RenderingCommandBuffer.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Serialize/TransferFunctions/TransferNameConversions.h"
#include "Runtime/Camera/LightAnimationBinding.h"

#define LIGHT_VERSION_ADD_CCT_SUPPORT 7

Light::Light(MemLabelId label, ObjectCreationMode mode)
    :   Super(label, mode)
{
    m_HaloHandle = 0;
    m_FlareHandle = -1;
    m_LightData = UNITY_NEW(SharedLightData, label) (label);
}

void Light::ThreadedCleanup()
{
}

void Light::MainThreadCleanup()
{
    if (m_LightData)
        m_LightData->MainThreadCleanup();
    SAFE_RELEASE(m_LightData);
    Super::MainThreadCleanup();
}

void Light::InitializeClass()
{
    REGISTER_MESSAGE_VOID(kTransformChanged, TransformChanged);

    RegisterAllowNameConversion(TypeOf<Light>()->GetName(), "m_IndirectIntensity", "m_BounceIntensity");
    RegisterAllowNameConversion(TypeOf<Light>()->GetName(), "m_Color", "m_ColorFilter");
    InitializeLightAnimationBindingInterface();
}

void Light::CleanupClass()
{
    CleanupLightAnimationBindingInterface();
}

void Light::TransformChanged()
{
    if (IsAddedToManager())
    {
        GetWritableData().UpdateTransform(GetComponent<Transform>());
        Precalc();
    }
}

void Light::Reset()
{
    Super::Reset();
    GetWritableData().Reset();
}

void Light::CheckConsistency()
{
    GetWritableData().CheckConsistency();
}

void Light::AddToManager()
{
    DebugAssert(!IsInList());
    GetWritableData().UpdateTransform(GetComponent<Transform>());
    GetLightManager().AddLight(this);

    SetupHalo();
    SetupFlare();
}

void Light::RemoveFromManager()
{
    if (IsInList())
    {
        GetLightManager().RemoveLight(this);
    }

    if (m_HaloHandle)
    {
        GetHaloManager().DeleteHalo(m_HaloHandle, this);
        m_HaloHandle = 0;
    }

    if (m_FlareHandle != -1)
    {
        GetFlareManager().DeleteFlare(m_FlareHandle);
        m_FlareHandle = -1;
    }
}

void Light::Precalc()
{
    SharedLightData& writeableData = GetWritableData();

    // Store whether we have a cookie so we don't need a PPtr lookup
    writeableData.m_HasCookie = writeableData.m_Cookie.IsValid();

    writeableData.Precalc();

    SetupHalo();
    SetupFlare();
}

void Light::AddCommandBuffer(RenderLightEventType type, RenderingCommandBuffer* buffer, UInt32 shadowPassMask)
{
    if (buffer == NULL)
    {
        ErrorStringObject("null CommandBuffer passed to Light.AddCommandBuffer", this);
        return;
    }
    GetWritableData().m_RenderEvents.AddCommandBuffer(type, buffer, shadowPassMask);
}

void Light::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);
    SharedLightData& data = GetWritableData();
    data.m_InstanceID = GetInstanceID();
    if ((awakeMode & kDidLoadFromDisk) == 0 && GetEnabled() && IsActive())
        data.UpdateTransform(GetComponent<Transform>());

    Precalc();
    data.UpdateCookieTextureRef();
}

void Light::SetFlare(Flare *flare)
{
    if (m_Flare == PPtr<Flare>(flare))
        return;
    m_Flare = flare;
    if (GetEnabled() && IsActive())
        SetupFlare();
}

Flare *Light::GetFlare() const
{
    return m_Flare;
}

void Light::SetLightType(LightType type)
{
    SharedLightData& sld = GetWritableData();
    sld.m_Type = type;
    // area lights are always fully baked. Keep in sync with SharedLightData::CheckConsistency
    if (type == kLightArea)
        sld.m_Lightmapping = kLightBaked;

    SetDirty();
    Precalc();
}

void Light::SetColor(const ColorRGBAf& c)
{
    GetWritableData().m_ColorFilter = c;
    SetDirty();
    Precalc();
}

void Light::SetIntensity(float i)
{
    GetWritableData().m_Intensity = std::max(i, 0.0f);
    SetDirty();
    Precalc();
}

void Light::SetShadowType(ShadowType v)
{
    GetWritableData().m_Shadows.m_Type = v;
    SetDirty();
}

void Light::SetCookie(Texture *tex)
{
    if (GetCookie() == PPtr<Texture>(tex))
        return;

    GetWritableData().SetCookie(tex);
    SetDirty();
    CheckConsistency();
    Precalc();
}

void Light::SetIsBakedFromScript(bool isBaked)
{
    SharedLightData& data = GetWritableData();

    if (isBaked)
    {
        data.m_BakingOutput.InitStaticBaked();
    }
    else
    {
        // Just clear all baking output
        data.m_BakingOutput = LightBakingOutput();
    }
}

template<class TransferFunc>
void Light::RemapLightmapping(TransferFunc& transfer)
{
#if UNITY_EDITOR
    // Note that this backwards compatibility will not work for prefab property modifications
    // because they have no concept of versions.
    // When we restructure m_Lightmapping to not use kLightmappingStaticGI,
    // then we should probably revert to the same enum values as in 4.x.
    if (transfer.IsVersionSmallerOrEqual(3))
    {
        switch ((int)m_LightData->m_Lightmapping)
        {
            case 0: // kLightmappingRealtimeOnly (4.x)
                m_LightData->m_Lightmapping = kLightRealtime; // kLightmappingRealtimeOnly (5.0 beta)
                break;
            case 1: // kLightmappingAuto (4.x)
                m_LightData->m_Lightmapping = kLightMixed; // kLightmappingStaticGI (5.0 beta)
                break;
            case 2: // kLightmappingBakedOnly (4.x)
                m_LightData->m_Lightmapping = kLightBaked; //kLightmappingStaticGIOnly (5.0 beta)
                break;
            default:
                printf_console(Format("Unknown light lightmapping mode with value: %i. Using the default - StaticGI.\n", m_LightData->m_Lightmapping).c_str());
                m_LightData->m_Lightmapping = kLightMixed; //kLightmappingStaticGI (5.0 beta)
                break;
        }
    }
    else if (transfer.IsVersionSmallerOrEqual(4))
    {
        switch ((int)m_LightData->m_Lightmapping)
        {
            case 1: // kLightmappingRealtimeOnly (5.0 beta)
                m_LightData->m_Lightmapping = kLightRealtime;
                break;
            case 2: // kLightmappingDynamicGI (5.0 beta)
                m_LightData->m_Lightmapping = kLightRealtime;
                break;
            case 4: // kLightmappingStaticGI (5.0 beta)
                m_LightData->m_Lightmapping = kLightMixed;
                break;
            case 8: // kLightmappingStaticGIOnly (5.0 beta)
                m_LightData->m_Lightmapping = kLightBaked;
                break;
            default:
                printf_console(Format("Unknown light lightmapping mode with value: %i. Using the default - Realtime.\n", m_LightData->m_Lightmapping).c_str());
                m_LightData->m_Lightmapping = kLightRealtime;
                break;
        }
    }
#endif
}

template<class TransferFunc>
void Light::Transfer(TransferFunc& transfer)
{
    if (transfer.IsReading() || transfer.IsReadingPPtr())
        UnshareLightData();
    Super::Transfer(transfer);
    transfer.SetVersion(8);

    transfer.Transfer(m_LightData->m_Type, "m_Type");
    transfer.Transfer(m_LightData->m_ColorFilter, "m_Color");
    transfer.Transfer(m_LightData->m_Intensity, "m_Intensity");
    transfer.Transfer(m_LightData->m_Range, "m_Range");
    transfer.Transfer(m_LightData->m_SpotAngle, "m_SpotAngle");
    if (transfer.IsVersionSmallerOrEqual(2))
    {
        m_LightData->m_CookieSize = m_LightData->m_SpotAngle * 2.0f;
    }
    else
    {
        transfer.Transfer(m_LightData->m_CookieSize, "m_CookieSize");
    }

    #if UNITY_EDITOR
    if (transfer.IsVersionSmallerOrEqual(1))
    {
        transfer.Transfer(m_LightData->m_Shadows.m_Type, "m_Shadows");
        transfer.Transfer(m_LightData->m_Shadows.m_Resolution, "m_ShadowResolution");
        transfer.Transfer(m_LightData->m_Shadows.m_Strength, "m_ShadowStrength");
    }
    else
    {
        transfer.Transfer(m_LightData->m_Shadows, "m_Shadows");
    }
    #else
    transfer.Transfer(m_LightData->m_Shadows, "m_Shadows");
    #endif

    transfer.Transfer(m_LightData->m_Cookie, "m_Cookie");
    transfer.Transfer(m_LightData->m_DrawHalo, "m_DrawHalo");
    transfer.Align();

    if (transfer.IsSerializingForGameRelease() || (transfer.GetFlags() & kSerializeForInspector) != 0)
    {
        transfer.Transfer(m_LightData->m_BakingOutput, "m_BakingOutput");

        // In Unity 5.4 m_ActuallyLightmapped was replaced by m_BakedIndex to fix mixed mode lighting.
        if (transfer.IsVersionSmallerOrEqual(6))
        {
            bool actuallyLightmapped = IsActuallyBaked();
            transfer.Transfer(actuallyLightmapped, "m_ActuallyLightmapped", kDontAnimate | kHideInEditorMask);
            if (actuallyLightmapped)
                m_LightData->m_BakingOutput.InitStaticBaked();
            else
                m_LightData->m_BakingOutput = LightBakingOutput();
        }
    }

    transfer.Transfer(m_Flare, "m_Flare");
    transfer.Transfer(m_LightData->m_RenderMode, "m_RenderMode");
    transfer.Transfer(m_LightData->m_CullingMask, "m_CullingMask");
    TRANSFER_ENUM_WITH_NAME(m_LightData->m_Lightmapping, "m_Lightmapping");
    transfer.Transfer(m_LightData->m_AreaSize, "m_AreaSize");

    transfer.Transfer(m_LightData->m_BounceIntensity, "m_BounceIntensity");

    transfer.Transfer(m_LightData->m_ColorTemperature, "m_ColorTemperature");
    transfer.Transfer(m_LightData->m_UseColorTemperature, "m_UseColorTemperature");

    transfer.Align();

    TRANSFER_EDITOR_ONLY_WITH_NAME(m_LightData->m_ShadowRadius, "m_ShadowRadius");
    TRANSFER_EDITOR_ONLY_WITH_NAME(m_LightData->m_ShadowAngle, "m_ShadowAngle");

    RemapLightmapping(transfer);

    if (transfer.IsVersionSmallerOrEqual(5))
    {
        // Unity 4.x:
        // m_ConvertedFinalColor = GammaToActiveColorSpace (m_Color) * m_Intensity;
        // Shaders are doing a multiply 2x thus effectively:
        // m_ConvertedFinalColor = GammaToActiveColorSpace (m_Color) * m_Intensity * 2;

        // Unity 5.0 to 5.4:
        // m_ConvertedFinalColor = GammaToActiveColorSpace (m_Color * m_Intensity);
        // shader multiply 2x has been removed.

        Assert(GetActiveColorSpace() != kUninitializedColorSpace);
        if (GetActiveColorSpace() == kLinearColorSpace)
            m_LightData->m_Intensity = LinearToGammaSpace(m_LightData->m_Intensity * 2.0F);
        else
            m_LightData->m_Intensity = m_LightData->m_Intensity * 2.0f;
    }

    if (transfer.IsVersionSmallerOrEqual(LIGHT_VERSION_ADD_CCT_SUPPORT))
    {
        m_LightData->m_ColorTemperature = 6570.f;   // Set ColorTemperature as close to white as possible.
        m_LightData->m_UseColorTemperature = false;
    }
}

void Light::SetupHalo()
{
    if (m_LightData->m_DrawHalo && IsActive() && GetEnabled())
    {
        float haloStr = GetRenderSettings().GetHaloStrength();
        if (!m_HaloHandle)
            m_HaloHandle = GetHaloManager().AddHalo();

        if (m_HaloHandle)
        {
            ColorRGBAf color = ActiveToGammaColorSpace(GetFinalLightColorActiveSpace());
            color *= LinearToGammaSpace(haloStr);

            float size = GetRange();

            if (m_LightData->m_Type == kLightArea)
                size = std::max(m_LightData->m_AreaSize.x, m_LightData->m_AreaSize.y);

            GetHaloManager().UpdateHalo(m_HaloHandle, GetWorldPosition(), color, haloStr * size, GetGameObject().GetLayerMask(), this);
        }
    }
    else
    {
        if (m_HaloHandle)
        {
            GetHaloManager().DeleteHalo(m_HaloHandle, this);
            m_HaloHandle = 0;
        }
    }
}

void Light::SetupFlare()
{
    Flare *flare = m_Flare;
    if (!flare || !IsActive() || !GetEnabled())
    {
        if (m_FlareHandle != -1)
        {
            GetFlareManager().DeleteFlare(m_FlareHandle);
            m_FlareHandle = -1;
        }
        return;
    }

    bool inf;
    Vector3f pos;

    if (GetLightType() != kLightDirectional)
    {
        pos = GetWorldPosition();
        inf = false;
    }
    else
    {
        pos = GetWorldDirection();
        inf = true;
    }

    if (m_FlareHandle == -1)
        m_FlareHandle = GetFlareManager().AddFlare();

    GetFlareManager().UpdateFlare(m_FlareHandle, flare, pos, inf, GetRenderSettings().GetFlareStrength()
        , ActiveToGammaColorSpace(GetFinalLightColorActiveSpace()) // color in gamma space
        , GetRenderSettings().GetFlareFadeSpeed()
        , GetGameObject().GetLayerMask()
        , kNoFXLayerMask | kIgnoreRaycastMask
        );
}

void Light::UnshareLightData() const
{
    if (m_LightData->GetRefCount() != 1)
    {
        // Someone else holds a reference to the data and expects it to be immutable.
        // Create our own copy before we make any changes to it.
        SharedLightData* newLightData = UNITY_NEW(SharedLightData, GetMemoryLabel()) (*m_LightData);
        m_LightData->Release();
        m_LightData = newLightData;
    }
}

IMPLEMENT_REGISTER_CLASS(Light, 108);
IMPLEMENT_OBJECT_SERIALIZE(Light);
